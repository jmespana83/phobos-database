# PHOBOS Community Edition 1.0.0 — Test Results

Executed on Windows 11 x64 (build 26200). Final source routine workspace: **629 passed, 0 failed, 4 ignored**, exit 0, Rust 1.85.0. Strict Clippy across workspace/all targets passed under Rust 1.98.1, as did formatting. Release binaries use Rust 1.98.1; Studio uses .NET SDK 10.0.402 and locked dependencies.

| Area | Executed evidence |
|---|---|
| SQL/schema | Parser/AST/binder/execution/catalog, negative cases, transactions/savepoints, defaults/CHECK/PK, identity, RETURNING, FK, INSERT SELECT, UNION, correlation, views, ALTER and combinations |
| Identity | Concurrent allocation, rollback/savepoints, explicit/generated values, crash boundaries, restart, backup/PITR/replication and counter integrity |
| FK | Parent/child violations, NULL/composite/type/index restrictions, transaction conflicts and races, restart, replay and integrity |
| Durability | Existing WAL/MVCC/UNIQUE/crash/backup/PITR/replication/lifecycle campaigns; no weakened durability settings |
| New backup-base CLI | Missing/live source rejection, existing destination rejection, persistent owner lock, checkpoint marker, PITR and replica equivalence |
| Copy upgrade | Accepted-era and experimental-v4 consent tests; actual accepted older binaries used to create data; original 8 files byte-identical after copy upgrade; old server rejects catalog 5; new server reads rows/generates identities |
| Packaged client | Exact shipped Core DLL; typed values, scripts, independent transactions, cancellation/reconnect, budgets, malformed frames/streams, metadata compatibility and no credential persistence |
| Actual GUI | Instrumented Avalonia window, real server, selected SQL, F5/Ctrl+Enter, unsaved Cancel, independent tab transactions/results, multi-results, progressive 50K rows, failure preservation, reconnect, budgets, export/profile/completion dialogs, themes and catalog rendering |
| DPI | Actual RenderScaling=1; raster rendering at 1/1.25/1.5/2. This is not an OS DPI-switching certification |
| TLS/roles | Shipped Core and pre-clock-fix release server (TLS/auth modules unchanged): trusted TLS 1.3, certificate display, trusted-certificate hostname rejection, reader SELECT/write denial, writer INSERT RETURNING/DDL denial, integrity. Fixture root certificate removed, zero matches remain |
| Normal Windows setup | User completed visible normal configuration, installed Studio returned id=1/accepted from RETURNING and view SELECT; isolated service restart/integrity; normal repair and persisted row verified |
| Cancel/uninstall | Configuration Cancel yields incomplete exit 2, no service/database; uninstall removes owned service/binaries and preserves data/auth/config |
| One million rows | Public CLI imported 1,000,000 rows; count/sum, unique index, indexed lookup, 1,000 updates/deletes, restart and 999,000 retained rows; integrity clean, 0 stale/corrupt index entries |

Million-row diagnostic under concurrent validation: bulk 11.015 s; unique index creation 167.641 s; offline integrity 37.875 s. These are observations, not isolated throughput claims.

Earlier failures are retained, not relabeled passes: typed RETURNING/UNION routing, Windows parser-depth exhaustion, updated startup/upgrade fixtures, and the checkpointed-backup ownership test led to corrections and passing final reruns. An earlier certificate-trust attempt timed out; the final positive/negative TLS run passed. The temporary shared Start menu folder issue was fixed; missing original shortcuts were restored. Primary database/service testing was never destructive.

Routine ignored tests: deterministic_restart_soak, concurrent_writer_soak, phase6_external_sort_and_grouping_soak and delta_bench. The delta test is a microbenchmark, not a correctness gate. All three correctness soaks were subsequently run explicitly and passed (3 passed, 0 failed); only the delta microbenchmark remains unexecuted. No Linux/macOS execution or independent broad hardware/long-duration certification is claimed.

Reproduce routine gates from the source root:

```powershell
cargo +1.85.0 fmt --all -- --check
cargo +1.85.0 test --workspace --locked -- --test-threads=4
cargo +1.98.1 clippy --workspace --all-targets --locked -- -D warnings
```

The release report contains build/package commands. tools/release-1.0 contains isolated large-data, actual-upgrade and installer tests. tools/studio-validation contains real client/GUI/TLS/fault validation. Source evidence contains logs/summaries and benchmark measurements, never authentication files or private keys.

Published SQL code blocks from GETTING-STARTED, SQL-REFERENCE and MANAGEMENT-API executed unchanged on a persistent authenticated protocol session, followed by clean integrity. An initial attempt using separate short-lived CLI sessions hit a retriable schema-exclusive conflict during previous-connection cleanup; this diagnostic is retained.

A final regression reproduced CURRENT_TIMESTAMP disagreement across persisted parallel partitions. Propagating the parent statement clock into workers fixed it; the regression passed in debug and optimized release. The earlier nonpersisted fixture did not activate the parallel path and is retained as diagnostic evidence. Full workspace, formatting, strict Clippy, release build, shipped-Core connectivity and documented SQL examples were rerun against the corrected source/binaries. Historical GUI/TLS/interactive installer acceptance precedes this isolated engine correction; final automated installer evidence identifies the exact packaged setup hash.
