# PHOBOS 1.0.1 — Installer Repair Validation

Final Setup SHA-256: `3c391eb617a5602f094296c5d2e66e4cc1d35ddd0c1273444796765430ca5448`.
Final runtime SHA-256: `dc4b0d899890386f3566eafbbb373b3e15c1684cbaa695f9958dffc8385d7255`.

All fixtures are isolated. The primary `C:\Program Files\PHOBOS`, `C:\ProgramData\PHOBOS` and PHOBOSDatabase service were not replaced or reinitialized.

| Acceptance case | Evidence |
|---|---|
| Final exact fresh automated install | fixture 04, exit 0, PASS COMPLETE |
| Actual compatible 1.0.0 repair | fixture 05 starts from accepted 1.0.0 runtime/initializer, repairs with final Setup, exit 0, PASS COMPLETE |
| Service ownership and stop | Protected manifest, registry, paths, executable identity and owned service validated; service stopped before replacement and readiness/auth checked after restart |
| File lock before copy | Open Avalonia.Base.dll fixture causes friendly preflight rejection; running service remains untouched while blocked |
| Existing password / wrong password | Existing credentials accepted; wrong password rejected; no new initialization |
| Preservation | Instance ID, endpoint, data path, auth bytes, runtime config bytes and manifest extension field retained; rows, indexes, view, identity continuation and CHECK/FK enforcement verified |
| Crash / backup / integrity | Deliberate isolated service-host crash contained; WAL recovery, offline integrity, backup/restore and restored integrity passed |
| Uninstall | Fixtures 04/05 remove service and installed binaries while retaining data/auth/config |
| Interactive repair with Studio open | Final Setup Welcome visibly states repair and preservation; Restart Manager names PHOBOS Management Studio PID 2976, Retry/Cancel. User closes Studio, Retry continues, existing password succeeds |

The interactive fixture is PHOBOS-101-Interactive / PHOBOS101Interactive / port 55462. Its initial visible fresh install used the immediately preceding package; the only subsequent source changes before final packaging were installer-notice/upgrade-guide wording clarifying 1.0.0 compatibility. The final exact Setup then performed the observed normal interactive repair. Automated fresh and legacy-repair fixtures 04/05 used the final exact Setup hash above. The exact final Setup additionally passed visible fresh configuration at PHOBOS-101-FinalInteractive, port 55463: user confirmed success, Setup exited 0, instance state ready, service Running, version 1.0.1. Its configuration readiness probe authenticates and executes SELECT 1. After interactive repair on port 55462, the user confirmed the view row 1 / preserved and next identity 2 / after repair. Both interactive fixtures were then uninstalled successfully: service and binaries removed; data/auth/config retained byte-for-byte where applicable.

Restart Manager performs detection only, never shutdown/force-kill. There remains an unavoidable race if a different application opens files after preflight; this is documented. A service that cannot stop within the maintenance timeout blocks copy. Credentials use masked native UI or test-runner redirected input, never command arguments/environment/plaintext response files. Auth-store byte preservation includes user/role records; successful admin authentication and separate reader-denial client tests supplement that check. TLS runtime/config bytes are not rewritten, but this Windows repair fixture is loopback plaintext, not a TLS provisioning test.

## Exact isolated reproduction

In an elevated PowerShell, from source root, use a new evidence folder and unused suffix/port. This runner uses port 55461 sequentially; do not run two instances together. It preserves fixture databases and refuses ambiguous pre-existing state.

```powershell
$csc="$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$root=(Get-Location).Path
$evidence='C:\PHOBOS-101-Installer-Reproduction'
New-Item -ItemType Directory $evidence
& $csc /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /main:Validation /r:System.Web.Extensions.dll /r:System.Core.dll /r:System.dll /r:System.ServiceProcess.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "/out:$evidence\installer-validation.exe" "$root\packaging\windows\Common.cs" "$root\packaging\windows\InstanceManager.cs" "$root\tools\release-1.0.1\InstallerValidation.cs"
& "$evidence\installer-validation.exe" '<final-Setup.exe>' "$evidence\fresh.log" 91
& "$evidence\installer-validation.exe" '<final-Setup.exe>' "$evidence\legacy.log" 92 '<accepted-1.0.0-runtime-directory>'
```

The suffix creates separate PHOBOS-101-Validation91/92 directories and PHOBOSValidation10191/92 services, and `/INSTANCEKEY` isolates installer registration. Ordinary users omit these test switches; the default compatible primary installation retains its existing AppId.
