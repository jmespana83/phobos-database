# PHOBOS 0.3-E performance — acceptance gate unresolved

**Do not promote automatically. The candidate is held for write-performance validation.** Correctness passed, but the fresh-control autocommit signal exceeds the requested guardrail. No benchmark-score optimization, storage redesign, skipped workload or durability relaxation was used.

## Method and provenance

Unmodified external `C:\PHOBOS-BENCH-v1.3.2\benchmark_suite.py`; actual identity **PHOBOS Standard Benchmark 1.3.1-G56**, not official v1.3.2 or v1.4. Harness hashes are recorded in evidence-03e/benchmark-harness.json and rechecked during packaging. Frozen defaults: bulk 100k/1M/3M, query samples 3, point operations 3000, autocommit operations 500, OLTP clients 1/8/16 with 3000 operations/client, seed 8067. No skip flags, alternative micro-harness or optional certification/churn supplement was substituted.

Candidate and accepted 0.3-A control are release binaries built with Rust 1.98.1. Control binaries are the unchanged accepted engine distributed with 0.3-B/0.3-D; their hashes are recorded. Each run uses a fresh isolated instance, the same harness, ordinary synchronous server defaults, and the same host. No builds or test suites ran concurrently with these measurements. This is not a dedicated benchmark laboratory; normal host variation remains possible.

Order: control 1, candidate 1, control 2, candidate 2, then candidate 3, control 3. The reverse-order third pair investigated the initial read slowdown. Every measurement is retained; none was discarded. One orchestration directory filter initially mistook generated standard-data for a run directory after the first control finished; the filter was fixed and the completed result retained. The benchmark itself did not change.

All six runs: **38/38 raw rows status=ok, zero query errors, all six query hashes equal to the October 23 K.5 reference**. The final source manifest and runtime hashes establish measured code identity; the final archive includes later result documentation, so its whole-ZIP hash is generated after measurements.

Historical references:
- K.5: C:\PHOBOS-BENCH-v1.3.2\results\phobos-20261023-101256.
- Accepted 0.3-A: C:\Users\195doctor\Documents\Codex\2026-10-23\validation\standard-20261023-120804.

## All measurements

The aggregate is the median of three independent full-run measurements per binary. Positive percentages mean slower elapsed time/latency. Individual pairs remain visible because medians from separate samples can conceal ordering effects. Bulk/write/read thresholds are 5%; OLTP is 8%.

| Workload | Unit | K.5 Oct 23 | 0.3-A Oct 23 | Fresh control median | 0.3-E median | E vs fresh | E vs K.5 | E vs 0.3-A | Individual pair changes |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| bulk/100000 | s | 0.856535 | 0.986729 | 0.956359 | 0.977741 | +2.2% | +14.2% | -0.9% | -9.4% / +8.6% / -2.4% |
| bulk/1000000 | s | 7.652972 | 9.170931 | 9.254116 | 8.892614 | -3.9% | +16.2% | -3.0% | +4.8% / -3.9% / -2.5% |
| bulk/3000000 | s | 25.245647 | 30.613100 | 32.144578 | 32.178454 | +0.1% | +27.5% | +5.1% | -2.0% / +2.4% / +0.1% |
| read/indexed_point | ms | 0.140923 | 0.190682 | 0.166301 | 0.159235 | -4.2% | +13.0% | -16.5% | -1.3% / -4.6% / +0.3% |
| read/secondary_range_1pct | s | 0.037997 | 0.046374 | 0.043975 | 0.043799 | -0.4% | +15.3% | -5.6% | +0.2% / -6.9% / -0.4% |
| read/full_scan_zero_match | s | 0.075274 | 0.074689 | 0.066822 | 0.069024 | +3.3% | -8.3% | -7.6% | +8.8% / +2.8% / +0.7% |
| read/count_all | s | 0.031836 | 0.038760 | 0.033387 | 0.033313 | -0.2% | +4.6% | -14.1% | -0.2% / -0.2% / -2.7% |
| read/group_by_bucket | s | 0.107117 | 0.114329 | 0.108590 | 0.108963 | +0.3% | +1.7% | -4.7% | -0.7% / +0.6% / +0.5% |
| read/topk_payload | s | 0.078498 | 0.092821 | 0.082908 | 0.083570 | +0.8% | +6.5% | -10.0% | +0.8% / +0.1% / -1.2% |
| read/join_aggregate | s | 0.089904 | 0.099435 | 0.086221 | 0.088678 | +2.9% | -1.4% | -10.8% | +3.0% / +1.6% / +1.6% |
| write/autocommit_insert | s | 0.217338 | 0.233767 | 0.198231 | 0.209966 | +5.9% | -3.4% | -10.2% | +6.6% / -7.6% / +20.8% |
| write/single_transaction_insert | s | 0.005645 | 0.006787 | 0.005856 | 0.006581 | +12.4% | +16.6% | -3.0% | -4.9% / -1.2% / +486.3% |
| oltp/1 | s | 0.856149 | 0.986507 | 0.900497 | 0.913612 | +1.5% | +6.7% | -7.4% | +0.4% / -3.4% / +6.6% |
| oltp/8 | s | 2.337920 | 2.742254 | 3.011932 | 2.934398 | -2.6% | +25.5% | +7.0% | +1.0% / -6.4% / -2.6% |
| oltp/16 | s | 4.677305 | 5.869560 | 5.883228 | 5.846842 | -0.6% | +25.0% | -0.4% | +5.8% / -3.3% / +2.9% |

## Interpretation and investigation

- **Autocommit INSERT: +5.9% median against the fresh accepted control.** Pair changes were +6.6%, -7.6%, +20.8%. Two of three exceed 5%, so this is explicitly flagged; the performance gate is not cleared. The candidate is still 3.4% faster than the original K.5 reference and 10.2% faster than accepted October 23 0.3-A, but those historical comparisons do not erase the fresh-control signal.
- Single-transaction INSERT: aggregate +12.4%, with pair changes -4.9%, -1.2%, +486.3%. The third candidate run had a large short-duration outlier. It is retained and disclosed. This does not establish a stable 12.4% engine cost, and it does not justify claiming equivalence either.
- The zero-match scan initially showed +8.8%, then +2.8%, then +0.7%. Its three-run median difference is +3.3%, below the read guardrail. Other read median differences range from -4.2% to +2.9%.
- OLTP median differences against the fresh control: +1.5% (1 client), -2.6% (8), -0.6% (16), below the 8% guardrail. Bulk medians differ by -3.9% to +2.2%.
- Historical deficits remain: versus K.5, candidate 3M bulk takes 27.5% longer, point latency is 13.0% higher, range query time is 15.3% higher, and 8/16-client OLTP takes about 25% longer. Versus accepted 0.3-A, 3M bulk is +5.1% and 8-client OLTP +7.0%. The fresh accepted binary also shows material historical deficits on this host. This is evidence of run/environment differences, not proof of their exact cause. No claim is made that original reference performance was recovered.

Code inspection confirms new CHECK/default validation is on write paths, not the SELECT row loop. Unconstrained writes now perform a lookup in the empty definition map; catalog cloning also carries one additional Arc. Physical publication, WAL, storage/index codecs and frozen benchmark logic are unchanged. These observations identify candidate-specific overhead to profile next, but do not establish that it causes the measured durable-write gap. Three small paired runs with changing signs and a transaction outlier cannot provide a causal or statistical-equivalence conclusion. No speculative optimization or weakening of enforcement was introduced to force a passing score.

**Promotion recommendation: hold.** Keep accepted 0.3-D product / 0.3-A engine unchanged. Use the source and validation runtime for review and isolated acceptance testing. A follow-up should isolate the autocommit overhead with matched full Standard runs and profiling before promoting or building further engine milestones on this candidate.

## Exact reproduction

From the delivered source root:

```powershell
.\tools\enterprise-sql-v2-validation\benchmark-series.ps1 -Candidate 'C:\Users\195doctor\Documents\Codex\2026-10-26\target03e\release' -Control 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b\bin' -WorkRoot 'C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e' -SuiteRoot 'C:\PHOBOS-BENCH-v1.3.2' -Port 55436 -Pairs 2
.\tools\enterprise-sql-v2-validation\benchmark-series.ps1 -Candidate 'C:\Users\195doctor\Documents\Codex\2026-10-26\target03e\release' -Control 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b\bin' -WorkRoot 'C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e' -SuiteRoot 'C:\PHOBOS-BENCH-v1.3.2' -Port 55436 -Pairs 3 -CandidateFirst
python -X utf8 tools/enterprise-sql-v2-validation/report-performance.py 'C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e'
```

The series resumes completed entries. For a wholly new experiment, use a fresh WorkRoot and copy the two reference-standard JSON files from evidence-03e there before running the reporting script. The actual single-run wrapper can also take `-SourceArchive <delivered-source.zip>`. The manual `standard.ps1 -Suite "<explicit command>"` wrapper remains available.

## Run directories

- control 1: `C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e\standard-20261026-135715`
- candidate 1: `C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e\standard-20261026-140049`
- control 2: `C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e\standard-20261026-140308`
- candidate 2: `C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e\standard-20261026-140528`
- candidate 3: `C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e\standard-20261026-140953`
- control 3: `C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e\standard-20261026-141214`
