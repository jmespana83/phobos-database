# PHOBOS Community Edition 1.0.0 — Release Notes

Unified Server/Studio/CLI/Admin 1.0.0. Windows correctness, recovery, normal installer and Studio acceptance passed. The release report records the final packaging decision.

Promotes literal DEFAULT/CHECK/PK; adds durable identity/typed INSERT RETURNING, restricted FK, INSERT SELECT, constants/CURRENT_TIMESTAMP, UNION/ALL, qualified correlated EXISTS, read-only persistent views, ALTER defaults/nullability/empty-table ADD COLUMN, additive metadata, Studio recognition, explicit copy upgrade and unified Windows packaging.

Correctness changes: statement timestamps are propagated into parallel partition workers; parser depth 32 and incremental UNION bounds; proper typed write/set result delivery; explicit no-rollback-on-delivery-failure semantics; catalog 5 required at public startup. Storage/WAL/MVCC/recovery/PITR/replication/lifecycle are retained. No licensing restrictions or signing claim. Linux remains unqualified. See final tests/performance/report for the release decision.
