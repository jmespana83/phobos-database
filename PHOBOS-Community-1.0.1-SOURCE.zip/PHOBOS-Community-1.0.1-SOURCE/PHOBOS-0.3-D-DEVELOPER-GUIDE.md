# PHOBOS 0.3-D developer guide

## Reproduce this Windows build

The source root used for this release is:

`C:\Users\195doctor\Documents\Codex\2026-10-26\work\PHOBOS-Community-0.3-D-ManagementStudioV2-SOURCE`

Prerequisites used: SDK 10.0.402 (.NET runtime 10.0.13), Avalonia 11.3.13, AvaloniaEdit 11.3.0, Inno Setup 6.7.3. Dependencies are pinned in project files and NuGet lockfiles. Platform-neutral development uses `packages.lock.json`; Windows publishing uses the separate `packages.win-x64.lock.json`, preventing audit/development restores from invalidating the release graph. The tools below are reused read-only from the October 23 tool directory; engine source/binaries are not rebuilt.

```powershell
$root = 'C:\Users\195doctor\Documents\Codex\2026-10-26'
$source = Join-Path $root 'work\PHOBOS-Community-0.3-D-ManagementStudioV2-SOURCE'
$dotnet = 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\dotnet\dotnet.exe'
$iscc = 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\inno\ISCC.exe'
$env:DOTNET_ROOT = Split-Path $dotnet
Set-Location $source
& $dotnet restore studio/Phobos.Studio/Phobos.Studio.csproj --locked-mode
& $dotnet build studio/Phobos.Studio/Phobos.Studio.csproj -c Release -p:StudioValidation=true -p:UseSharedCompilation=false --no-restore
& $dotnet run --project tools/studio-validation/StudioValidation.csproj -c Release -- 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b\bin' (Join-Path $root 'validation\reproduce-fresh') (Join-Path $source 'studio\Phobos.Studio\bin\Release\net10.0\PHOBOS-Studio.exe')
& $dotnet run --project tools/studio-validation/StudioValidation.csproj -c Release -- --protocol-faults
& $dotnet list studio/Phobos.Studio/Phobos.Studio.csproj package --vulnerable --include-transitive
```

The integration runner refuses an existing fixture directory. Choose a fresh directory for each invocation. It initializes only its own data, generates credentials in memory, starts the accepted server, tests crash/recovery and cancellation, and checks offline integrity after shutdown. It does not touch production databases. The GUI evidence runner is compiled only with `StudioValidation=true`; ordinary packages set it false. The GUI screenshot suite intentionally pauses after the first batch so the receiving state can be inspected and another tab exercised.

## Package

```powershell
& .\packaging\studio\build.ps1 -Dotnet $dotnet -Iscc $iscc -StageDirectory (Join-Path $root 'runtime-03d-reproduce') -OutputDirectory (Join-Path $root 'outputs-reproduce')
& .\tools\studio-validation\package.ps1 -Installer (Join-Path $root 'outputs-reproduce\PHOBOS-Management-Studio-0.3-D-Windows-x64.exe') -TestDirectory (Join-Path $root 'validation\installed-reproduce') -Log (Join-Path $root 'validation\package-reproduce.log')
```

Use a fresh empty stage and install-test directory. Release publishing is self-contained win-x64, locked restore, no debug symbols, and no GUI validation entry path. Packaging includes product guides and third-party notices. The independent 0.3-D installer identity/path avoids replacing the accepted 0.3-C installation. It contains no server binaries. The 0.3-B server installer remains separate; a future orchestrator can invoke the two installers independently, preserve their uninstall identities and use registered endpoint discovery after installation.

Windows service qualification source is `tools/studio-validation/windows`. Build its csproj and run `RunLocal.ps1` elevated only for this isolated test. The recorded run uses `C:\Program Files\PHOBOS-03D-Validation`, `C:\ProgramData\PHOBOS-03D-Validation`, service `PHOBOSStudioV2Validation`, and port 55448. It refuses existing test paths. To reproduce, select new dedicated names/paths/port in the test source and wrapper first; never delete existing database state merely to rerun a test. The suite installs the accepted 0.3-B files-only package, configures its fixture, invokes Studio's SCM helper, reconnects, then uninstalls the test instance while retaining data.

The exact packaged Core DLL can be rechecked with:

```powershell
& .\tools\studio-validation\TestPackagedCore.ps1 -Dotnet $dotnet -RuntimeDirectory (Join-Path $root 'runtime-03d-reproduce') -EngineBin 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b\bin' -RunnerDirectory (Join-Path $root 'validation\packaged-runner-reproduce') -EvidenceDirectory (Join-Path $root 'validation\packaged-fixture-reproduce')
```

## Signing hook

Unsigned is the explicit default. Optional parameters are `-SignToolPath`, `-CertificateThumbprint`, and `-TimestampUrl`. They must all identify real operator-provided signing infrastructure. No password/private key is supplied on argv; the thumbprint selects the current-user certificate store/HSM-backed provider.

Order: publish → copy docs/notices → sign/verify PHOBOS-Studio.exe, PHOBOS-Studio.dll and Phobos.Studio.Core.dll → Inno signs its generated uninstaller and Setup → verify Setup → ZIP signed runtime → generate final SHA-256 manifest. SHA-256 file digests and RFC3161 SHA-256 timestamps are requested. Signing failure stops packaging. Do not sign or replace accepted engine artifacts as part of this Studio build. A future combined product should separately sign its newly built server EXEs, CLI/admin/instance helpers and installer.

The Inno hook uses the documented `$f`/`$q` substitutions and `SignedUninstaller=yes`: [SignTool](https://jrsoftware.org/ishelp/topic_setup_signtool.htm), [SignedUninstaller](https://jrsoftware.org/ishelp/topic_setup_signeduninstaller.htm). The real certificate signing branch is prepared but unqualified because no signing certificate was supplied. Do not describe this release as signed.

## Code map and extension points

- Core/Protocol.cs: strict decoder, TLS and bounded awaited batch callbacks.
- Core/Workspace.cs: session lifecycle, acknowledged transaction state, stable catalog reads, profiles, SQL files/templates.
- Core/Product.cs: lexical script boundaries, exact exports, bounded limits and layout settings.
- Studio/QueryPane.cs: per-tab state and incremental result views.
- Studio/MainWindow*.cs: captured-pane orchestration, UI workflows and validation helpers.
- Studio/SqlHighlighting.cs: bundled lexical highlighting definition.
- Studio/WindowsInstances.cs: unchanged platform interface and Windows discovery/SCM adapter.
- tools/studio-validation: Core/live server tests, malformed peers, GUI evidence and package/service tests.

Do not move passwords into profiles for convenience, auto-replay SQL after network loss, bypass TLS validation, call a shell with metadata, or replace public catalog queries with storage-file parsing. New platforms must pass a real native launch/connect/query/file/package gate before publication.

`tools/studio-validation/finalize.py` verifies the accepted baseline and unchanged engine/server packaging, copies selected non-secret evidence, writes the changed-file list, builds the source ZIP, verifies ZIP CRC/runtime content and emits the external final hash manifest. Its documented workspace argument is the October 26 root. The external hash manifest deliberately has no self-hash and is not recursively embedded in its own source archive.
