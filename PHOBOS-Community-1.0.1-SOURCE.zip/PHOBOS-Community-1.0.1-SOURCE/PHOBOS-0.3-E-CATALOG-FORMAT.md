# PHOBOS 0.3-E catalog format

## Version transition

PHOC versions 1/2/3 remain readable. New databases and legacy SQL without schema definitions continue writing v2 (or v3 with existing capabilities). New definition DDL writes v4 in the existing catalog.phc. Index catalog PHCI remains v1. No sidecar file, WAL record kind, page version, tuple layout, physical index codec or network protocol change is introduced.

The v4 prefix is exactly v3: magic, u16 version, next table ID, table/column schemas, partition metadata, and u32 capabilities. Existing LAZY_INDEX_PRUNING_V1 is unchanged. Version 4 itself is the incompatibility barrier; no additional capability bit is required. The existing final FNV-1a checksum covers the extension.

All integers below are little-endian. The extension, after capabilities and before checksum:

- u32 definition-table count.
- For each table: u64 stable table ID.
- u32 default count; each default has u32 column ordinal (zero-based), nullable-value encoding.
- u32 CHECK count; each CHECK has u32 column ordinal, u8 operator, nullable-value encoding.
- u64 primary backing index ID; zero means absent.

Nullable-value encoding: u8 0 for NULL, or u8 1 followed by the existing catalog typed-value encoding (1 integer, 2 Boolean, 3 float, 4 UTF-8 text, 5 binary, 6 date, 7 timestamp, 8 decimal). Text retains u16 byte length; binary uses u32 length. Operators: 0 =, 1 <>, 2 <, 3 <=, 4 >, 5 >=, 6 IS NULL, 7 IS NOT NULL. NULL predicates require a NULL stored operand.

Definitions are held in an Arc/BTreeMap by table ID. Defaults are unique by ordinal, CHECKs retain declaration order, and the PK references the actual unique index. Strings are not executable expressions. Existing column count and literal encoding bounds apply. Decoding consumes exactly the checksummed payload; truncation, duplicate default/table records, unknown tags/operators/versions, missing columns/tables/indexes, invalid PK nullability/ownership and incompatible types are rejected. Unknown future format versions fail closed.

## Transactions and migration

A schema owner clones the committed catalog into the existing private schema directory. Metadata is written there, then logged as existing FileId::Tables/Indexes/Statistics metadata images. Commit follows the existing durable WAL barrier and catalog generation publication. Rollback deletes staging. Renames preserve column ordinals and stable table IDs, including the PK index ID.

Opening an old catalog alone does not migrate it. The first successful new-definition DDL adopts v4 transactionally. The catalog retains v4 even after DROP DEFAULT removes the last default from a definition record. Rollback before the first successful publication leaves the prior committed version. No in-place downgrade tool is supplied: restore a pre-v4 backup using its matching accepted engine. Never manually decrement the version or delete definitions.

Online/offline backups copy catalog.phc and indexes.phc with their existing consistency rules. PITR and physical replication replay the same metadata images. A receiver must understand catalog v4 before serving the database. Catalog/schema identity must not be stripped from backups.

Future foreign keys, sequence allocators and view dependencies require a separately reviewed versioned extension. They are not represented by placeholder fields in this release.
