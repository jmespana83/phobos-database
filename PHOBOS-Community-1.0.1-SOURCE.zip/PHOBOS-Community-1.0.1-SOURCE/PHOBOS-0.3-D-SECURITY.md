# PHOBOS 0.3-D security review

## Preserved boundaries

The accepted engine, public protocol and Windows service adapter are unchanged. Normal Studio execution uses an asInvoker manifest. Windows SCM actions use the existing constrained elevated helper: fixed verbs and registered instance keys, with registry revalidation. No arbitrary shell command is built from server metadata. Test service installation used separate 0.3-D paths and registration and was uninstalled afterward; test data was intentionally retained.

Authentication passwords are not persisted to profiles/layout, argv, environment variables, registry, logs or evidence. Tests pass generated credentials through standard input and scan test artifacts for plaintext. Password fields clear after dialogs. Managed strings may remain transiently in process memory until garbage collection; Studio does not claim secure erasure or an encrypted credential vault. SQL itself can contain sensitive data; history is memory-only and Save/Export/Copy require explicit user action.

TLS continues to enforce OS trust, hostname and certificate revocation checks. No validation callback accepts untrusted peers. New display fields are informational only. Untrusted-certificate rejection is tested. A trusted PHOBOS TLS fixture and isolated hostname-mismatch qualification were not configured for this run; successful certificate display is code-reviewed but not claimed as end-to-end TLS-qualified. Custom CA selection and mTLS are deferred. No trust-store changes or validation bypass were made.

## New surfaces

- Script scanning: bounded size/count, quote/comment-aware, full boundary preflight, fail closed for unsupported ambiguous quoting. Server remains the SQL parser. Multi-statement scripts are sequential, not implicitly atomic. No automatic retry/replay.
- Streaming: 1 MiB strict frame limit, strict UTF-8, request IDs, sequence, typed values and end totals remain enforced. Awaited UI delivery limits queued work. Limits are bounded, and every partial result is marked Incomplete. Completed results are not relabelled on a later pre-submit script limit.
- Cancellation: scoped to the originating tab with a separate authenticated channel; concurrent cancel clicks are serialized. A request does not guarantee rollback.
- Profiles: no password field; 100-profile/1 MiB read bounds; corrupt input is preserved before repair. Endpoint values are not shell commands. Profile storage is not a vault and contains host/user names.
- Layout: a small, bounded whitelist of dimensions/theme/maximized state, at most 16 KiB input. No executable configuration or automatic SQL loading.
- Exports: typed exact values; explicit formula-safe CSV mode affects TEXT and headers, not numeric values. Exact CSV can contain active spreadsheet formulas. Temporary sibling output is moved to the explicit destination; no arbitrary recursive cleanup. CSV NULL convention is documented; typed JSON is preferred for portable type fidelity.
- History: 20 bounded entries/tab in memory, no disk persistence. OS paging/crash dumps and user-saved SQL/exports remain outside a secure-erasure guarantee.
- Catalog: repeated stable reads before publication, scoped-to-full fallback; no new server authority. Metadata labels are text, not executable markup. Unknown Management API versions disable metadata/templates while retaining SQL.

## Dependency and packaging review

Pinned dependency audit against the configured NuGet source reported no known vulnerable packages on 2026-10-26. This is a point-in-time feed result, not a security certification. Package lockfiles and upstream notices remain included.

The release is unsigned. SHA-256 manifests detect byte changes but do not establish publisher identity without a trusted distribution channel. Optional packaging inputs support a real certificate-store thumbprint and RFC3161 timestamp endpoint. First-party payload files are signed and verified before packaging; Inno signs Setup and its uninstaller. No certificate was fabricated and the signing path is not certificate-qualified. The unsigned build and install/uninstall path is tested.

No custom CA/private-key persistence, OS credential manager, remote log reader, new service adapter or combined server installer was introduced. The reviewed release has no known unresolved failure of the tested protocol isolation/budget boundaries. Remaining qualification gaps are listed in the Test Results and Cross-Platform documents.
