# PHOBOS Studio 0.3-C — Security review

## Credentials and local data

Passwords exist only in the connection dialog and transient managed strings/buffers while authenticating two sessions. The dialog is cleared after use; protocol authentication byte buffers are cleared after send. No passwords are written to profiles, argv, environment, registry, logs or SQL files by Studio. This is not a secure-heap guarantee: managed strings, OS paging, external crash dumps and process inspection by the same user/administrator remain possible. Studio adds no crash-dump collection or persistent application logging. Users can themselves type secrets into SQL; saving that SQL naturally saves its contents.

Profiles contain name/host/port/username/TLS preference only. Profile size is checked before load; saves use a temporary file then replace. Files remain protected by the user's normal account permissions. No hard-coded encryption or credential vault is invented. Multiple simultaneous Studio processes are not a coordinated profile database; last save wins.

Clipboard writes happen only through explicit Copy actions. They may be visible to clipboard history/other applications and are not automatically wiped. SQL and typed results remain in bounded session memory; closing/discarding does not cryptographically erase managed memory. Production logs do not include SQL, result rows or auth frames. Server error text is shown in the UI and may itself contain query details; it is not persisted by Studio.

## Transport and hostile peers

TLS uses SslStream with OS trust, normal hostname validation and online revocation checking. There is no accept-any-certificate callback or fake TLS checkbox. Untrusted self-signed certificate rejection is tested. A successful trusted-certificate connection to a separately deployed TLS PHOBOS server and mTLS UI are not qualified in this milestone. Plain connections are visibly identified in the dialog as suitable only for trusted networks/tunnels; they are not secure remote transport.

Protocol validation preserves the 1 MiB envelope cap before payload allocation, strict UTF-8, IDs, flags, stream state/sequence/counts, final totals and value encodings. Per-result row/memory budgets and deadlines bound malicious/accidental work. No partial result is advertised as complete. All protocol/stream/callback failures poison and close the connection. No automatic replay. Authentication errors are rendered generically so a malicious error response cannot reflect the submitted password.

## OS privilege separation

The Windows application manifest is asInvoker. HKLM discovery and SCM status are read-only in the normal app. Start/Stop/Restart launches the same installed executable with Windows runas, re-resolves the instance from administrator-owned HKLM, accepts only three fixed verbs and directly invokes SCM. It does not execute registry-provided binary paths, shell text, arbitrary service names, taskkill or user-supplied commands. A PHOBOS OS administrator controls registry/service configuration; this adapter is not a boundary against an already privileged administrator. The optional log-opening action is deferred to avoid unsafe elevation/path behavior.

The per-user Studio install directory is writable by its user. As with other per-user administration clients, approve UAC only for the Studio executable you trust. Signing is deferred; the published hashes identify delivered bytes. Do not use Studio as a privileged unattended service or run the whole GUI as administrator for ordinary queries.

## Dependency review

Avalonia 11.3.13 transitively selected Tmds.DBus.Protocol 0.21.2. It was explicitly pinned to the compatible patched 0.21.3 after NuGet reported GHSA-xrw6-gwf8-vvr9 (CVE-2026-39959). See https://github.com/advisories/GHSA-xrw6-gwf8-vvr9 . Final restore/build reports no vulnerability warning. Lock files pin dependency resolution; this is not a guarantee against future advisories. Self-contained .NET and framework updates require republishing Studio. Third-party package notices accompany the runtime.

## Validation and limits

Tests cover Unicode password authentication, wrong password handling, password-free profiles/artifacts, hostile frames/streams, TLS trust rejection, bounded results, cancellation, database integrity after client failures and real SCM lifecycle. Screenshots contain generated fixture data and no passwords. No penetration-test, complete accessibility, OS-hardening or memory-zeroization certification is claimed. Engine authentication, authorization, WAL, MVCC, recovery and storage files are unchanged.
