# PHOBOS 0.3-B — Windows Installer & Service Foundation

PHOBOS remains one cross-platform database engine. This milestone adds a Windows distribution boundary, not a Windows-only engine. The accepted 0.3-A baseline is `PHOBOS-Community-0.3-A-EnterpriseSQLFoundation-SOURCE.zip`, SHA-256 `c9907590f1003f7ee99c5e3fabb30c9de106b778d146fcba23414b8849ce4911`.

## Engine boundary

All Rust source, Cargo manifests/lockfile, SQL, execution, catalog, authentication, protocol, MVCC, WAL, recovery, replication, PITR and lifecycle code remain byte-identical to 0.3-A. No file format or wire format changes. The Windows runtime carries the exact measured 0.3-A release executables. Their hashes are checked during final packaging. The packaging product is 0.3-B; `SHOW CATALOG CAPABILITIES` still truthfully reports engine feature version 0.3-A and management API 1. Installer/native executable version resources and installation discovery report 0.3-B independently.

All new executable code lives under `packaging/windows`; it uses Windows/.NET Framework interfaces without adding dependencies to any Rust crate. The C# compiler ships with .NET Framework and is a build prerequisite only. End users run a single Inno Setup installer; no Rust/Cargo or PowerShell is needed for the interactive installation path. The existing CLI's Windows masked password prompt uses Windows PowerShell internally; this inherited CLI behavior is unchanged.

## Components

| Component | Responsibility |
|---|---|
| `phobos.iss` | Inno Setup 6.7.3 UI, binary directory, prerequisite check/install, files, shortcuts, uninstall hooks |
| `phobos-instance.exe` | Native configuration dialog; protected directory initialization; secure stdin auth setup; service registration; authenticated readiness checks; controlled same-version repair/removal |
| `phobos-service.exe` | Native Windows SCM dispatcher, separate normal server process, stdout/stderr logs, startup/stop/preshutdown state reporting, crash containment |
| `phobos-server.exe` | Unchanged PHOBOS engine and direct TCP listener |
| `phobos-cli.exe`, `phobos-admin.exe` | Unchanged client and administration interfaces |

Inno Setup is a mature installer framework with file rollback and uninstall tracking. PHOBOS does not implement a custom installer framework. A small native configuration dialog runs after the framework copies files so passwords never enter Inno command lines, response files or installer logs. Files-only installation is an explicit advanced mode and is not represented as a ready database installation.

The service does not proxy requests or introduce a query IPC layer. It starts the same server with explicit absolute `--config`, `--data-dir`, `--auth-file`, `--bind`, `--shutdown-file`, and `--wal-mode flush` arguments. It removes inherited PHOBOS and CLR instrumentation overrides and uses a restricted system PATH. Its only database wire traffic is a startup handshake; installation verification authenticates separately through the normal public protocol.

## Configuration and discovery

The existing engine runtime JSON remains authoritative for engine settings. The distribution adds a versioned **installation manifest**, not a second engine configuration parser. `instance.json` binds the binary/data/auth/runtime/log/control locations, service identity, loopback endpoint, product/engine versions and initialization state. Runtime settings are passed to the existing engine config loader unchanged. The default worker count is processor count clamped to 1–16; other engine defaults remain inherited. WAL is explicitly durable `flush` mode.

Default layout:

```text
C:\Program Files\PHOBOS\
  bin\                 server, cli, admin, service host, instance manager
  docs\                user, security, service and architecture guides
  config-location.txt  non-secret installation-manifest locator
C:\ProgramData\PHOBOS\
  config\instance.json
  config\runtime.json
  config\auth.txt       existing PHOBOS password-hash format, never plaintext
  data\                one primary database instance
  control\             shutdown marker
  logs\                timestamped server/service logs
```

Binary and data directories can be selected independently. Paths must be canonical, absolute, local, non-reparse, at most 200 characters, and under administrator-controlled parents. Data/config/log/control and binary directories cannot overlap. Fresh initialization requires empty instance directories. A durable `initializing` manifest is written before initialization; failure preserves data and refuses blind reinitialization. The existing `phobos-admin init` creates a staging instance beneath the chosen data directory; its data children are moved within that volume into the chosen data directory. The tiny initial migration backup/staging is retained for diagnosis.

Normal GUI discovery uses `HKLM\SOFTWARE\PHOBOS\Instances\<serviceName>` values: Manifest, ProductVersion, Host, Port, LogDirectory, ServiceName and Authentication. There are no passwords there. A non-administrator GUI can discover host/port/version and query SCM state without reading auth or internal engine files. It then prompts for credentials, connects using the public protocol, and uses Management API v1. Protected log/config access is an administrator operation; discovery is not authorization to read them.

## Lifecycle and failure semantics

LocalService is used with an unrestricted **per-service SID**. Only that SID receives Modify on data/log/control and Read/Execute on configuration. The executable directory is administrator/SYSTEM writable and Users read/execute. No Everyone/Full Control or shared LocalService write grant is used. Service account and binary path are verified before the management helper stops or starts an existing service.

Start reports START_PENDING with checkpoints while waiting for an owned listener and a PHOBOS handshake; only then reports RUNNING. Stop/preshutdown sets the existing shutdown marker and waits for server exit while reporting STOP_PENDING. Normal lifecycle never kills the database process. Windows preshutdown allowance is configured to 180 seconds; OS power loss or expiry of Windows' shutdown deadline is a crash, not a promised clean drain. Normal service stop does not impose a forced-kill deadline. Administrative helper waits time out rather than killing the engine.

A kill-on-close Windows Job object prevents an orphan server if the service host itself crashes. This is crash containment, not the normal stop mechanism. The next start relies on the unchanged WAL recovery path. A very small launch-to-job-assignment window remains because the normal managed process API is used; a host crash during that window can require administrator cleanup. Startup always refuses an occupied port and never kills its owner.

Recovery policy is explicitly **no automatic restart** in 0.3-B. Failures report nonzero SCM service status; operators inspect logs and restart after fixing the cause. Logs are timestamped per start and are not automatically rotated/pruned during a run; retention is an operator responsibility.

Same-version repair uses the same binary directory and manifest, stops the service first and preserves auth/data/config. Uninstall removes the service and installed files but retains all mutable instance directories and backups. Failed post-copy configuration leaves installed tools available for diagnosis and does not claim readiness. Arbitrary cross-version upgrades and transactional rollback of an already completed binary replacement are not claimed.

## Cross-platform continuation

Future Linux packages can install unchanged engine tools in `/usr/bin` or `/opt/phobos`, runtime config in `/etc/phobos`, data in `/var/lib/phobos`, logs in `/var/log/phobos`, and run under a dedicated `phobos` user/group with a systemd unit. `.deb`, `.rpm` and tarball builders belong in platform packaging modules. macOS can use a tarball/package and launchd where Rust/runtime dependencies support it. Native hosts must map their own path, identity, logging and graceful-control conventions to the same server/admin interfaces. The Windows manifest is not required by the core and does not constrain Unix filenames or configuration semantics.

Linux/macOS builds are not newly certified by this Windows-host milestone. Their source viability is preserved by zero engine changes; future platform packaging must run its own platform tests.

## Build and external dependencies

See `PHOBOS-0.3-B-INSTALLATION.md` for exact build commands and `PHOBOS-0.3-B-TEST-RESULTS.md` for what was actually run. Build inputs include Inno Setup 6.7.3 and Microsoft's signed Visual C++ x64 redistributable. The installer checks .NET Framework 4.8 and supplies the C++ prerequisite when needed. Windows ARM64, x86, older .NET, clean-VM prerequisite installation and other OS distributions are not certified by this milestone.

Primary references: [Inno Setup downloads](https://jrsoftware.org/isdl.php), [compiler command line](https://jrsoftware.org/ishelp/topic_compilercmdline.htm), [Microsoft runtime downloads](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170). Tool/input hashes are recorded with the build evidence; no PHOBOS Authenticode signature is claimed.
