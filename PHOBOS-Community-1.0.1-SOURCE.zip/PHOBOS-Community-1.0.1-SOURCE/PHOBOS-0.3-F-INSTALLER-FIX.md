# PHOBOS 0.3-F installer hotfix

Packaging 0.3-F contains accepted engine 0.3-A. The enterprise-schema engine remains separate pending its performance decision. Studio 0.3-D is installed separately and remains untouched by server uninstall.

Normal Setup launches `configure` visibly with `SW_SHOWNORMAL`, passes its owner window handle, and displays explicit progress instructions. The modal has taskbar presence, centers on Setup when a valid owner is available, and activates once when shown. No TopMost or periodic focus stealing is used. Noninteractive preparation/removal remain hidden.

Setup cancellation after file copy retains runtime files and reports incomplete configuration (exit 2). Uninstall the incomplete runtime before retrying. Initialization intent and database files are always retained on initialization failure. An initializing manifest blocks automatic reinitialization; inspect the actual error and retained data before manual recovery. Newly created owned services are removed on registration/startup failure where safe shutdown/ownership checks succeed. Cleanup must never delete a different service or database.

FILESONLY remains an advanced option. It never claims readiness. Credentials belong only in the visible masked fields or the explicit anonymous-stdin automation interface, never command arguments, environment variables, logs or plaintext response files.

Repair supports packaging 0.3-F and the compatible 0.3-B instance manifest schema 1 when engineVersion is 0.3-A. It keeps the original instance ID, authentication, data and paths. Other engine identities fail closed. Registry discovery records packaging and engine versions separately.

See PHOBOS-0.3-F-INSTALLER-TEST-RESULTS.md in the release outputs for the final acceptance matrix. This document describes behavior, not a claim that every interruption scenario was executed.
