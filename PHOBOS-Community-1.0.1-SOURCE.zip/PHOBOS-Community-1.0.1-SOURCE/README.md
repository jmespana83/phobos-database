# PHOBOS Community Edition 1.0.1

Focused Studio SQL-error resilience and Windows installer repair hotfix. Start with [Hotfix Report](PHOBOS-1.0.1-HOTFIX-REPORT.md), [Release Notes](PHOBOS-1.0.1-RELEASE-NOTES.md), [Getting Started](PHOBOS-1.0-GETTING-STARTED.md), [Installation](PHOBOS-1.0-INSTALLATION.md), and [Test Results](PHOBOS-1.0.1-TEST-RESULTS.md).

Cross-platform Rust source; Windows runtime and Avalonia Studio. Linux is unqualified. Protocol v1, Management API v1, catalog 5. Apache-2.0. No artificial Community Edition licensing limits. Historical 0.3 and 1.0 documents/evidence remain provenance; the 1.0.1 report describes this hotfix. All 205 Rust source files remain byte-identical to the accepted 1.0.0 source.
