# PHOBOS 0.3-E test results

Validation platform: Windows x64. Pinned source/test compiler: Rust 1.85.0. Release/benchmark compiler: installed stable Rust 1.98.1 (48a229cea, 2026-09-01), matching the accepted runtime compiler. .NET client validation uses the existing 10.0.402 SDK. Linux/macOS execution was not available and is not claimed.

## Gates

- `cargo test --workspace --locked --offline -- --test-threads=4`: PASS, 608 top-level tests, zero failures, four inherited ignored tests. The log also contains one successful nested parser subprocess result, so summing every printed summary yields 609 executions. Major crate counts: execution 216, server 101, WAL 76, storage 62, transaction 46, index 34, admin 23, SQL 9, catalog 6. Default workspace tests are not the same as running all ignored certification workloads.
- Focused `schema_v2` suite: PASS, 11 new top-level tests. Eight execution tests, one administration recovery test, one catalog corruption/migration test, one parser test.
- `cargo clippy --workspace --all-targets --all-features --locked --offline -- -D warnings`: PASS.
- `cargo fmt --all -- --check`: PASS.
- `cargo +stable build --release --locked --offline`: PASS with Rust 1.98.1.
- Release runtime schema smoke: PASS. Actual server/CLI/admin, DEFAULT/CHECK/PK, transactional rename, forced termination, restart, integrity, backup, restore, restored integrity and query/metadata comparison.
- Unchanged 0.3-D Core client compatibility: PASS on the exact final runtime; see final evidence `studio-compat-final.log`; the suite includes typed values, metadata extensions, scripts/tabs/results/export, limits, cancellation, auth failures, forced restart and offline integrity. No GUI/Core production source patch is required. Engine-specific templates remain conservatively disabled for the new server_version.
- Standard benchmark correctness: PASS for all six runs. Write-performance acceptance: HOLD (+5.9% autocommit median versus fresh control; two of three pairs above 5%). See PERFORMANCE and evidence; workloads are unchanged, with separate repeated accepted-control comparisons.

## New feature coverage

Parser/negative grammar; typed default binding/coercion; missing columns; duplicate PK/default/nullability declarations; unsupported expressions/identity/FK/ALTER forms; implicit PK NOT NULL; composite uniqueness; index-drop protection; omitted values versus explicit NULL; multiple-row atomic rejection; UPDATE atomic rejection; NULL/UNKNOWN CHECK semantics; scalar type defaults; exact BIGINT/DOUBLE CHECK boundaries; schema and data COMMIT/ROLLBACK; own writes; table/column rename; concurrent same-key insert; schema lease isolation; dedicated bulk rejection; restart; six real process-crash boundaries; repeated replay; online/offline backup; PITR before and after ALTER DEFAULT; physical standby replay; catalog/row integrity; old→new format; unknown versions; malformed references/operators; valid-checksum semantic corruption and every truncated catalog prefix.

## Initial attempts and corrections

Restricted sandbox fixture creation returned Windows AccessDenied; tests were rerun with normal local file access on isolated fixtures. An initial workspace TLS dependency build lacked the inherited prebuilt-NASM setting/short target directory; the documented build environment resolved it without changing dependencies. The first administration test used offline restore for an online-backup marker and correctly failed; its invocation was corrected. The first concurrency test expected concurrent catalog reads during a held schema lease; the inherited engine correctly returned a retryable schema-transaction error. The test expectation was corrected, not the locking semantics. Strict Clippy requested an else-if style cleanup. All final gates above use the corrected integrated source.

## Reproduction

From `C:\Users\195doctor\Documents\Codex\2026-10-26\work\PHOBOS-Community-0.3-E-EnterpriseSQLSchemaV2-SOURCE`:

```powershell
$env:AWS_LC_SYS_PREBUILT_NASM = '1'
$env:CARGO_TARGET_DIR = 'C:\Users\195doctor\Documents\Codex\2026-10-26\test03e'
& "$env:USERPROFILE\.cargo\bin\cargo.exe" test --workspace --locked --offline -- --test-threads=4
& "$env:USERPROFILE\.cargo\bin\cargo.exe" test -p phobos-catalog -p phobos-sql -p phobos-execution -p phobos-admin schema_v2 --locked --offline
& "$env:USERPROFILE\.cargo\bin\cargo.exe" clippy --workspace --all-targets --all-features --locked --offline -- -D warnings
& "$env:USERPROFILE\.cargo\bin\cargo.exe" fmt --all -- --check
$env:CARGO_TARGET_DIR = 'C:\Users\195doctor\Documents\Codex\2026-10-26\target03e'
& "$env:USERPROFILE\.cargo\bin\rustc.exe" +stable --version # measured version must be 1.98.1
& "$env:USERPROFILE\.cargo\bin\cargo.exe" +stable build --release --locked --offline
.\tools\enterprise-sql-v2-validation\run.ps1 -Mode Smoke -Binaries "$env:CARGO_TARGET_DIR\release" -WorkRoot 'C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e' -Port 55436
& 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\dotnet\dotnet.exe' run --project tools/enterprise-sql-v2-validation/client/StudioValidation.csproj -c Release -- "$env:CARGO_TARGET_DIR\release" '<fresh-absolute-evidence-directory>'
```

Use fresh fixture locations; do not reuse a production data directory. On a new build machine, install the pinned compiler/dependencies and omit --offline for the initial dependency acquisition. The test script also supplies a portable Rust invocation for other platforms, without claiming those platforms were run here.

`evidence-03e/tested-source-manifest.json` fixes the measured Rust/manifests. Packaging verifies those 186 files, recorded runtime hashes, protected subsystem sources and all 47 prior 0.3-D output hashes. No prior deliverable is overwritten. The new handoff is under outputs/0.3-E.
