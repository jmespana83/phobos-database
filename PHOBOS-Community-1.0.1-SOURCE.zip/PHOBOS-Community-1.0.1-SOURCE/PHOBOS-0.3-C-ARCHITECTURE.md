# PHOBOS 0.3-C — Management Studio V1

## Boundary and framework

PHOBOS Management Studio is a standalone Avalonia 11.3.13 / .NET 10 desktop application. AvaloniaEdit 11.3.0 supplies the multiline editor; Avalonia DataGrid supplies virtualized rows and keyboard navigation. Fluent dark/light themes, desktop file pickers, tree views and tab controls avoid a browser/server/Electron dependency. Framework references: https://v11.docs.avaloniaui.net/docs/overview/supported-platforms/ and https://github.com/AvaloniaUI/AvaloniaEdit . Windows x64 is qualified here; Linux/macOS are architectural targets, not qualified packages.

Authoritative baseline: PHOBOS-Community-0.3-B-WindowsInstaller-SOURCE.zip, SHA-256 9071b1da32a5d2ff675806e7c5db9dfe94bd9531c43e95bc4a447a77351723a0. All engine crates and root Cargo/toolchain inputs are unchanged. Studio does not ship a replacement server. Existing 0.3-A/K.5 performance evidence remains the reference; no Standard rerun or engine performance claim is made.

## Components

- `studio/Phobos.Studio.Core`: platform-neutral async TCP/TLS protocol, typed decoding, session/cancellation ownership, Management API mapping, password-free profile storage and SQL document state. No Avalonia, registry or SCM dependency.
- `studio/Phobos.Studio`: Avalonia window, dialogs, editor tabs, results/messages, clipboard and object SQL templates. A single SQL session is shared by all tabs. The busy state serializes ordinary queries and metadata refresh.
- `ILocalInstances`: optional local installation discovery/status/action interface. `WindowsInstances` is the sole production registry/SCM adapter; non-Windows systems use `NoLocalInstances`. Future systemd/launchd adapters can implement the same interface without changing protocol, editor or catalog logic.
- `packaging/studio`: separate per-user Inno installer and self-contained Windows runtime ZIP. Existing `packaging/windows` is preserved byte-for-byte.
- `tools/studio-validation`: real engine integration, hostile protocol peers, TLS rejection, GUI render/handler checks, and isolated elevated Windows integration. Validation entry points are enabled only with `StudioValidation=true`; automatic harness dispatch is absent from production builds.

## Protocol and session model

The managed client implements the existing public PHOBOS protocol directly from `docs/protocol.md`, `docs/streaming_protocol.md`, and the accepted Rust client. No CLI scraping, proxy, storage-file reads, alternate GUI protocol or engine change. Hello negotiates `stream=1`; authentication uses frames 5/6. Queries use typed stream frames 12–17. Header magic, version, zero flags, request ID, 1 MiB maximum payload, strict UTF-8, payload version, row counts, type tags, batch sequence, final totals and trailing bytes are checked before accepting a complete result.

All nine wire types retain their tag and value. BIGINT is Int64; DOUBLE uses round-trip formatting; decimal is decoded from signed i128 plus scale without passing through floating point or .NET decimal; binary is hex. Dates are epoch days and timestamps are UTC epoch microseconds, with a lossless numeric fallback outside .NET calendar range. NULL has a separate marker and type inspector.

Queries are read batch by batch into a bounded result: 50,000 rows and 32 MiB estimated retained memory, including conservative CLR/string overhead. The virtualized grid is populated off-thread only after a valid End. A progress counter updates while receiving. There is no million-row collection, partial-success display or silent truncation. Budget breach closes the session and instructs the user to narrow the query. The estimate is not an exact process-RSS cap; rendering/clipboard/metadata add overhead. Clipboard can hold another bounded text copy. Metadata expansions are lazy; more than 2,000 tables disables the explorer with an explicit message.

Cancellation reserves frame 40/41 before each query, then sends frame 42/43 over a second authenticated session of the same username. Credentials are discarded after opening these connections. Cancel acknowledgement is a request, not proof of rollback; the actual query outcome is reported. Streaming errors, cancellation, timeout, malformed frames and disconnects close the query session, matching the official Rust client contract. Reconnect is explicit and never replays SQL. Lost write responses can have uncertain commit outcomes. Closing a session rolls back an active uncommitted transaction on the server.

## Catalog and feature gating

Connect retrieves SHOW CATALOG CAPABILITIES. Management API v1 enables TABLES/COLUMNS/INDEXES/CONSTRAINTS. An unknown future API leaves SQL usable and disables metadata/templates. The known engine version 0.3-A plus API v1 gates Create Table, Create Index/Unique Index and Rename Table/Column templates because API v1 does not individually advertise those DDL features. Templates generate editable SQL and never execute immediately. No DROP TABLE, primary key, DEFAULT, CHECK, identity, FK or other unsupported action is offered.

The tree models one database per server connection. Opaque table IDs join metadata; index columns use ordinal order. NOT NULL and UNIQUE INDEX are displayed as reported, without fabricated names or keys. Refresh selected/Tables currently performs the same safe full catalog refresh as Refresh all. Refresh also runs after every successful statement, including DDL and transaction controls, so own transactional catalog changes are visible. The four catalog requests are separate statement snapshots, not one atomic metadata snapshot; concurrent DDL may require another refresh.

## Async UI and administration

Network/decoding/catalog retrieval and result-display projection run outside the UI thread. Service discovery/status use worker tasks; privileged action waits asynchronously. Files are read/written asynchronously. Queries have a two-minute overall deadline; connect/auth has a 15-second deadline. Busy state prevents overlapping SQL submissions. Results belong to the most recently executed tab; each tab retains its own SQL text, not a separate connection or result history.

Windows reads non-secret 64-bit HKLM SOFTWARE/PHOBOS/Instances values. The normal UI remains asInvoker. Only service actions relaunch the same executable with `runas`; the helper resolves a registry instance key again and directly calls SCM through ServiceController. It accepts only start/stop/restart and no arbitrary command or service name. Stop uses the existing graceful 0.3-B host. No taskkill, ACL weakening, firewall edits or automatic service restart policy changes. Local service status is shown in the Administration dialog rather than continuously polled in the main status bar. Log viewing is deferred.

## Build and future integration

See PHOBOS-0.3-C-DEVELOPER-GUIDE.md for exact commands. The server installer is untouched. A future combined installer may invoke the separate Studio package or copy its publish output as an independent component; it must not couple ordinary query execution to service elevation.

0.3-D should prioritize broader GUI usability/accessibility and DPI qualification, trusted-certificate TLS/mTLS workflows, export, incremental grid presentation, independent connections/results per tab, scoped catalog refresh, profile deletion/organization, persistent layout and signed distribution. Linux/macOS packages and native local-service adapters require real platform tests before claims.
