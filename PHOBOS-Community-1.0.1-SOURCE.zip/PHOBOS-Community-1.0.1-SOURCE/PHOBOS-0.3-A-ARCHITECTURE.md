# PHOBOS 0.3-A — Enterprise SQL Foundation

## Baseline and scope

Development began in `C:\Users\195doctor\Documents\Codex\2026-10-23` from the accepted `PHOBOS-Community-0.2-K.5-ReclaimPublicationV2-SOURCE.zip`, SHA-256 `af5eb5f5e9abd413652071bdc855072d60957018930862a6456e43f04c57989a`.

This release adds query composition, richer stored-table joins, transactional renaming, INSERT column binding, scalar functions and a management catalog interface. It deliberately leaves persistent constraint/view/type extensions for a subsequent increment. See the compatibility document for the complete implemented and deferred scope. Neither the installer nor Management Studio is included.

## Storage and transaction boundary

No heap, index, WAL, catalog binary version, recovery or replication format changes are introduced. The inherited `db1-diagnostics` build used a cache-shard method that no longer existed; a field-access correction restores all-feature compilation and does not affect default runtime behavior. There is no K-series reclamation/performance redesign. Positional INSERT remains the write operator: column lists resolve against one catalog generation, then feed existing type, nullability, unique-key and MVCC admission paths. Partition routing receives the expanded positional statement.

Renaming uses the existing exclusive schema lease, transaction-private catalog files, schema WAL metadata records and ordered publication. Table and index IDs, column positions and row encodings remain fixed. Index column names are rewritten in the same schema transaction. Statistics for the renamed table are invalidated rather than retaining stale column names.

A names-only heap-schema refresh occurs during schema preparation, within its existing serialized/fenced publication boundary. The refresh rejects changes to IDs, column counts, types or nullability. Previously acquired statement handles retain their own generation. This addresses index maintenance and reclamation code that legitimately reads logical names from the heap schema. Failed schema preparation retains the baseline's fencing/recovery behavior.

## Query architecture

AST relation aliases are distinct from physical table names. MVCC table collection always identifies physical tables; evaluation binds the relation's alias. This supports self joins without inventing storage objects. Duplicate qualifiers are rejected.

Simple existing SELECT and equality-join paths remain available. General ON/CROSS joins have a separate cancellable nested-loop path, with a result-memory guard. Outer ON predicates are evaluated before null extension, never moved into WHERE.

Scalar/EXISTS subqueries execute through the same statement database view, preserving snapshot visibility and own writes. Scalar results enforce one column and at most one row. The implementation does not claim correlated execution.

CTE references expand to query-local derived inputs. Their bodies remain SELECT-only. Physical read dependencies are recursively collected before building a statement view. Expansion is bounded and parser nesting remains bounded. Derived results use the existing projection, filtering, aggregate and sort operators. There is no persistent view catalog, temp heap creation or storage-side materialization.

Two related binding correctness fixes accompany aliases: ORDER BY resolves unambiguous short selected column names; GROUP BY compares resolved input columns rather than accepting equal suffixes from distinct relations. Partition-parent subquery execution is rejected instead of reading an empty parent heap.

## Management interface version 1

The interface consists of SQL commands returning ordinary typed rows through the existing protocol. It works with collecting and streaming clients, authentication, cancellation, errors and read-only prepared statements. Reader permission is sufficient. It exposes no file paths or credentials.

| Command | Columns, in order |
|---|---|
| SHOW CATALOG TABLES | table_id, table_name, table_type, column_count |
| SHOW CATALOG COLUMNS | table_id, table_name, ordinal_position, column_name, data_type, is_nullable |
| SHOW CATALOG INDEXES | table_id, table_name, index_id, index_name, is_unique, ordinal_position, column_name |
| SHOW CATALOG CONSTRAINTS | table_id, table_name, constraint_name, constraint_type, ordinal_position, column_name |
| SHOW CATALOG CAPABILITIES | capability_name, capability_value |

The first four commands accept `FROM table`; an absent table returns NotFound, not an empty misleading result. Ordinals are one-based. Composite index/unique-index columns occupy separate ordered rows. IDs are opaque strings. Catalog commands enumerate the statement's catalog, including its own staged DDL; they do not enumerate physical heap files. Capability `management_api_version=1` is the compatibility discriminator. The legacy wire handshake/Cargo package identifier is retained for compatibility; `server_version` in this interface identifies the 0.3-A feature release. Future incompatible column/type changes require a new interface version; clients should discover columns by name and tolerate additional capability rows.

The connection identifies the database: one database per server instance. There is no fabricated multi-database namespace. Management clients should retain connection identity alongside object IDs. Existing server metrics, result events, cancellation and structured errors complement this catalog interface. Client-side elapsed time can supply query duration without a new wire frame.

## Next milestones

0.3-B can wrap the existing server configuration, fresh-instance initialization, authentication and graceful shutdown entry points in a Windows installer/service host. It should preserve exclusive instance ownership, durable WAL settings and bounded shutdown; it does not require changes to this catalog API.

0.3-C can implement a connection profile, object explorer backed by SHOW CATALOG, SQL editor, Execute/Cancel, typed results grid and Messages pane. Object management must emit supported SQL and refresh metadata after success. Capability discovery and the compatibility document must drive disabled actions for unimplemented objects/constraints.

Further SQL increments should introduce a versioned durable definition catalog for views/defaults/checks, with dependency validation; foreign keys require concurrent parent/child write coordination and commit-time rules; identity requires durable allocation semantics; temp tables require session ownership and namespace/lifecycle rules. These are not safely represented as parser-only additions or unlogged sidecar files.

## Validation and performance evidence

See `evidence/` and the handoff for commands, final results and limitations. The October 23 K.5 reference is `C:\PHOBOS-BENCH-v1.3.2\results\phobos-20261023-101256`. Its own metadata identifies the suite as **1.3.1-G56**. The earlier October 23 run ending 095626 identifies 0.2-I and is not used as the K.5 comparison.


### Final verification (October 23, 2026)

The full workspace test suite passed with four test threads on the integrated implementation. Subsequent final changes (CTE expansion-depth protection, streaming LIMIT/OFFSET subquery routing, and explicit partition-parent query boundaries) passed the SQL parser suite, enterprise execution/function/protocol tests, and workspace partition tests. The final tree passes formatting and all-target/all-feature Clippy with warnings denied. Documentation builds successfully, with inherited private-link warnings. Correctness tests used the pinned Rust 1.85.0 Windows MSVC toolchain. Release builds also passed on Rust 1.98.1.

An initial highly concurrent workspace run hit the inherited slow-client timing assertion; the full rerun with four test threads passed without weakening tests. Logs preserve both results. The exact release binary passed authenticated protocol, transactional rename, committed crash/restart, UNIQUE, offline integrity, backup/restore, restored integrity, and restored query/catalog smoke checks (`smoke-release.log`). The full workspace covers the inherited recovery, replication, PITR and storage lifecycle tests; this is not a new exhaustive fault-injection certification of every feature combination.

The final frozen Standard suite completed with every raw status `ok`, zero query errors and all six query result hashes matching the October 23 K.5 reference and fresh control. Its internal identity is 1.3.1-G56, not 1.3.2 or 1.4. Workloads and synchronous durability were retained. Final run: `standard-20261023-120804`; fresh unchanged K.5 control: `standard-20261023-114707`. Both used Rust 1.98.1, release builds, the same machine and suite. The original reference compiler is not recorded. The earlier candidate runs and the original reference are retained for transparency.

The final candidate is faster than the fresh K.5 control on the reported bulk/read/OLTP measures; the single 500-row transaction is 4.3% slower (6.79 ms versus 6.51 ms). Most final measures remain slower than the original October 23 reference, including bulk loads (15–21% longer), point reads (32% higher median latency), and OLTP (14–25% longer equivalent time per operation). The current control also falls below that reference. These serial runs show substantial host/run variability and do not prove statistical equivalence or restoration of reference performance. No storage or benchmark-score optimization was attempted.

Positive slowdown means worse; throughput slowdown is control throughput divided by candidate throughput minus one. Timings are workload medians where the suite repeats them; the 500-row transaction is one short sample.

| Workload | Unit | Oct 23 reference | Fresh K.5 | Final 0.3-A | Slowdown vs fresh K.5 |
|---|---|---:|---:|---:|---:|
| bulk 100000 | seconds | 0.85653 | 1.0603 | 0.98673 | -6.9% |
| bulk 1000000 | seconds | 7.653 | 10.313 | 9.1709 | -11.1% |
| bulk 3000000 | seconds | 25.246 | 34.365 | 30.613 | -10.9% |
| indexed point p50 | ms | 0.1396 | 0.2043 | 0.1841 | -9.9% |
| secondary_range_1pct | seconds | 0.037997 | 0.050605 | 0.046374 | -8.4% |
| full_scan_zero_match | seconds | 0.075274 | 0.083192 | 0.074689 | -10.2% |
| count_all | seconds | 0.031836 | 0.042131 | 0.03876 | -8.0% |
| group_by_bucket | seconds | 0.10712 | 0.13537 | 0.11433 | -15.5% |
| topk_payload | seconds | 0.078498 | 0.10187 | 0.092821 | -8.9% |
| join_aggregate | seconds | 0.089904 | 0.10446 | 0.099435 | -4.8% |
| autocommit insert | ops/s | 2300.6 | 1855.8 | 2138.9 | -13.2% |
| 500-row transaction | seconds | 0.0056451 | 0.0065064 | 0.0067871 | +4.3% |
| OLTP 1 clients | ops/s | 3504.1 | 2610.8 | 3041 | -14.1% |
| OLTP 8 clients | ops/s | 10266 | 7340.1 | 8751.9 | -16.1% |
| OLTP 16 clients | ops/s | 10262 | 7474.2 | 8177.8 | -8.6% |

The initial candidate's optional full benchmark-database post-run integrity scan was stopped after the timed suite had completed; no pass is claimed for that scan. It is separate from the successful targeted integrity/restart/restore smoke checks. The runner now exposes `-CheckBenchmarkData` explicitly. See `initial-post-benchmark-scan-status.txt`.

`release-build-manifest.json` binds the measured binaries and compiler metadata to every Rust source file. `release-build-source.zip` outside the final archive preserves the measured snapshot; final packaging changes only documentation/evidence. The final ZIP is verified against every recorded Rust file hash.
