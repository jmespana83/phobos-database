# PHOBOS Community Edition 1.0.1 — Architecture

Cross-platform Rust Server/CLI/Admin; Avalonia/.NET Studio; Windows service and installer adapters. One database per server. Protocol v1 and Management API v1 are retained. Catalog format 5 adds identities, foreign keys and views to the transactional schema definitions.

The K.5 heap, indexes, MVCC/status store, commit admission, WAL durability/publication, recovery, backup/PITR, standby replay and reclaim lifecycle remain the foundation. No storage redesign or reclaim optimization campaign was undertaken.

Identity uses an ordinary hidden MVCC table and unique singleton index. Counter and user rows share admission/WAL/commit; never MAX(id)+1. Rollback/savepoints may reuse uncommitted values; committed allocation never rewinds. BY DEFAULT explicit values do not advance the generator. Internal allocator objects are excluded from SQL/catalog metadata.

FKs use immediate RESTRICT/NO ACTION. When any FK exists, writer transactions share an ownership lease and are serialized; validation checks the current committed graph plus own pending changes before publication. Snapshot writers reject stale snapshots. This is deliberately conservative and expensive; no-FK databases retain ordinary concurrent DML.

Views persist SQL, output schema and dependency IDs and expand into existing derived-query execution. Dependent incompatible DDL is rejected. Set queries and INSERT SELECT materialize through existing bounded paths. Qualified WHERE EXISTS correlation uses the same statement snapshot. CURRENT_TIMESTAMP is statement-stable.

Studio uses authenticated SHOW CATALOG, never internal engine files. Public startup requires catalog 5; older data uses an explicit backup-first copy upgrade. Source provenance: verified 0.3-F archive SHA-256 606632e701ee975b581c1eff6f7b0e3c85e487fc8c5c7cd14d6036accc53e6ed.
