# PHOBOS Community Edition 1.0.1 — Limits

PHOBOS Community Edition imposes no artificial licensing limits on CPU cores, RAM, database size, tables, indexes, users, client connections, backup/PITR, replication, Management Studio, or engine performance features. There are no paid database-count/query-parallelism tiers.

Technical limits: one database per server; 1 MiB protocol payload; parser/expression depth 32; 64 CTE bindings plus expansion budget; one BIGINT identity per table, maximum generated i64::MAX-1; FK writer serialization/full scans; physically-empty-only ADD COLUMN; materialization/collecting constraints. These are architectural limits, not licensing.

Configuration defaults include 64 connections, hardware-based workers capped at 16 by default, 4 parallel scan workers, 64 MiB query memory, 256 MiB page cache, 64 MiB write-spill threshold, 2 GiB write scratch, 8 GiB bulk scratch, 30-minute statement/15-minute idle/2-second lock timeouts. Worker/parallel worker settings currently validate 1..64 as an implementation bound. Consult shipped RuntimeConfig before changing controls.

Studio defaults: 50,000 rows, estimated 32 MiB results, 120 seconds. Technical UI limits: 8 tabs/16 connections, 32 statements/script, 100 profiles, 1 MiB SQL/profile files, 2,000-object explorer guard. These are safety bounds, not server license restrictions. WAL retention/history/scratch/backups require real disk space. No independent maximum-size/high-core certification is implied.
