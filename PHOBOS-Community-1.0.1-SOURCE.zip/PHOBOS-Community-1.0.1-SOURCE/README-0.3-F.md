# PHOBOS 0.3-F source bundle: stabilization and explicitly separated engine status

This bundle starts from the verified 0.3-E source candidate. Its Rust engine implementation is unchanged from that candidate; it must not be mistaken for the accepted engine in the Windows installer. Building the workspace produces the 0.3-E enterprise-schema candidate, whose Management API reports 0.3-E.

The Windows stabilization distribution is packaging 0.3-F with the accepted 0.3-A engine. Its build script pins all three accepted engine executable hashes and rejects substitution. Accepted Studio remains 0.3-D, unchanged and separately installed. See the final performance and promotion reports before treating the source engine candidate as accepted.

Start with PHOBOS-0.3-F-ARCHITECTURE.md, PHOBOS-0.3-F-INSTALLER-TEST-RESULTS.md, PHOBOS-0.3-F-PERFORMANCE.md and PHOBOS-0.3-F-SQL-COMPATIBILITY.md. New validation tools are in tools/release-stabilization-03f. The catalog example schema_access_profile measures isolated component costs, not Standard throughput.

No identity, sequence or RETURNING implementation is included. No storage/WAL/MVCC/recovery redesign or durability relaxation is included. Historical documents/evidence remain labeled with their original milestones.
