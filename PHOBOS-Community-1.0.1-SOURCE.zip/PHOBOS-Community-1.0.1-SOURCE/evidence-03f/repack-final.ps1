param([switch]$InspectOnly)
$ErrorActionPreference='Stop'
$root='C:\Users\195doctor\Documents\Codex\2026-10-26'
$src=Join-Path $root 'work03f\PHOBOS-Community-0.3-E-EnterpriseSQLSchemaV2-SOURCE'
$stage=Join-Path $root 'runtime03f-final'
$out=Join-Path $root 'build03f-final'
if($InspectOnly){
 $assembly=[Reflection.Assembly]::LoadFrom("$stage\bin\phobos-instance.exe")
 if($assembly.GetType('InstanceManager').GetField('TestCheckpoint')){throw 'Test callback leaked into production assembly'}
 exit 0
}
if(Test-Path -LiteralPath $stage){throw 'Final stage already exists'}
New-Item -ItemType Directory -Path $stage,$out | Out-Null
Copy-Item -LiteralPath "$root\runtime03f\bin" -Destination $stage -Recurse
Copy-Item -LiteralPath "$root\runtime03f\prerequisites" -Destination $stage -Recurse
New-Item -ItemType Directory -Path "$stage\docs" | Out-Null
Get-ChildItem -LiteralPath $src -Filter 'PHOBOS-0.3-F-*.md' | Copy-Item -Destination "$stage\docs"
Copy-Item -LiteralPath "$src\PHOBOS-0.3-A-SQL-COMPATIBILITY.md" -Destination "$stage\docs"
Copy-Item -LiteralPath "$src\LICENSE" -Destination "$stage\docs\LICENSE.txt"
Copy-Item -LiteralPath "$src\packaging\windows\QuickStart.html" -Destination "$stage\docs"
$notice=Get-Content -LiteralPath "$root\runtime03f\docs\INSTALLER-NOTICE.txt" -Raw
$notice.Replace('Only same-version repair is supported.','Compatible 0.3-B/0.3-F instance repair is limited to accepted engine 0.3-A.') | Set-Content -LiteralPath "$stage\docs\INSTALLER-NOTICE.txt" -Encoding utf8
$accepted=@{'phobos-server'='236ac6d7defa59fac7aab7009170bc49b84f549dc4bedf5deb627604fcd935d5';'phobos-cli'='187fca5fc7104729a694ffa10b8cd1e1c7dd81d1b92757cece897d0c2cd1773e';'phobos-admin'='73c7d6de9bd98007f5ac925fff81517dbe75868d7713389986b146310242d4cc'}
foreach($name in $accepted.Keys){if((Get-FileHash -LiteralPath "$stage\bin\$name.exe").Hash -ne $accepted[$name]){throw 'Engine hash mismatch'}}
foreach($file in Get-ChildItem -LiteralPath "$stage\bin" -File){if((Get-FileHash -LiteralPath $file.FullName).Hash -ne (Get-FileHash -LiteralPath "$root\runtime03f\bin\$($file.Name)").Hash){throw 'Validated runtime changed'}}
@{packaging_version='0.3-F';engine_version='0.3-A';engine_status='accepted';enterprise_schema_candidate='0.3-E experimental, not included';management_api_version=1;identity=$false;returning=$false;engine_sha256=$accepted} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$stage\docs\BUILD.json" -Encoding UTF8
& "$stage\bin\phobos-instance.exe" self-test
if($LASTEXITCODE -ne 0){throw 'Final runtime self-test failed'}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath -InspectOnly
if($LASTEXITCODE -ne 0){throw 'Production assembly inspection failed'}
'PASS production test callback absent, all validated runtime bytes unchanged, accepted engine hashes exact'
& 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\inno\ISCC.exe' "/DRuntimeDir=$stage" "/DOutputDir=$out" "$src\packaging\windows\phobos.iss"
if($LASTEXITCODE -ne 0){throw 'Final installer compilation failed'}
Compress-Archive -Path "$stage\*" -DestinationPath "$out\PHOBOS-Community-0.3-F-Windows-Runtime.zip"
'PASS final installer/runtime packaging'
