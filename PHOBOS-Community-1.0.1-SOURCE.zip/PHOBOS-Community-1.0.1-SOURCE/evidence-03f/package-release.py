"""Release packaging with explicit evidence allowlist and baseline preservation."""
from pathlib import Path
import hashlib,json,shutil,zipfile
r=Path(__file__).resolve().parent.parent
s=r/'work03f/PHOBOS-Community-0.3-E-EnterpriseSQLSchemaV2-SOURCE';v=r/'validation-03f';out=r/'outputs'
hash_file=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old={k.replace('\\','/'):value for k,value in json.loads((v/'prior-artifacts.json').read_text(encoding='utf-8-sig')).items()}
for rel,sha in old.items():assert hash_file(out/rel)==sha,rel
baseline=zipfile.ZipFile(out/'PHOBOS-Community-0.3-E-EnterpriseSQLSchemaV2-SOURCE.zip')
base={n.split('/',1)[1]:baseline.read(n) for n in baseline.namelist() if not n.endswith('/')}
assert all((s/p).is_file() for p in base)
assert all((s/p).read_bytes()==data for p,data in base.items() if p.startswith('crates/') and p.endswith('.rs'))
e=s/'evidence-03f';e.mkdir(exist_ok=False)
def copy(p):
 assert p.is_file(),p
 dest=e/p.relative_to(v);dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,dest)
for name in ['local.log','automated-all.log','interruption.log','interactive-install.log','interactive-repair.log','interactive-cancel.log','restart.log','uninstall.log','restore-original.log','standard-series.log','profile.csv','profile-build.log','micro.log','micro-retry.log','micro-final.log','micro-aa.log','micro-trace.log','micro-analysis.json','calibration-analysis.json','trace-analysis.json','workspace.log','release-smoke.log','studio-client.log','final-packaging-checks.log','final-repack.log','frozen-harness-hashes.json','test-summary.json','repack-final.ps1','package-release.py']:
 copy(v/name)
for name in ['installer-validation.log','service-config1.txt']:
 copy(v/'automated'/name)
for p in (v/'ui-evidence').iterdir():
 if p.name in ['normal-config-visible.jpg','installer-welcome.jpg','studio-after-repair.txt']:copy(p)
for folder in ['micro-final','micro-aa','micro-trace']:
 for name in ['micro.csv','micro.json','metadata.json']:copy(v/folder/name)
 for instance in (v/folder).iterdir():
  if instance.is_dir():
   copy(instance/'integrity.txt')
   if (instance/'request-trace.csv').exists():copy(instance/'request-trace.csv')
for p in (v/'standard').iterdir():
 if p.is_file() and p.suffix in ['.json','.csv','.md','.log']:copy(p)
 if p.is_dir() and (p/'results').is_dir():
  for name in ['summary.json','raw.csv','plans.json','environment.json','command.json']:copy(p/'results'/name)
for p in v.glob('smoke-*/result.txt'):copy(p)
# Evidence never includes auth files, live databases or profile stores.
assert not any(p.name in ['auth.txt','profiles.json','instance.json'] for p in e.rglob('*'))
files=[p for p in s.rglob('*') if p.is_file() and not any(x in {'.git','target','obj','__pycache__'} for x in p.relative_to(s).parts) and not ('bin' in p.relative_to(s).parts and p.relative_to(s).parts[0] in ['studio','tools'])]
changed=[p.relative_to(s).as_posix() for p in files if p.relative_to(s).as_posix() in base and p.read_bytes()!=base[p.relative_to(s).as_posix()]]
added=[p.relative_to(s).as_posix() for p in files if p.relative_to(s).as_posix() not in base]
added.append('PHOBOS-0.3-F-CHANGED-FILES.txt')
report='Relative to authoritative 0.3-E source. No baseline file removed; all 164 baseline Rust files unchanged.\n\nMODIFIED\n'+'\n'.join(sorted(changed))+'\n\nADDED\n'+'\n'.join(sorted(added))+'\n'
(s/'PHOBOS-0.3-F-CHANGED-FILES.txt').write_text(report,encoding='utf-8')
files.append(s/'PHOBOS-0.3-F-CHANGED-FILES.txt')
archive=out/'PHOBOS-Community-0.3-F-SOURCE.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,'PHOBOS-Community-0.3-F-SOURCE/'+p.relative_to(s).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 names={n.split('/',1)[1] for n in z.namelist()}
 assert set(base)<=names
 assert 'crates/phobos-validation/src/bin/beta-check.rs' in names
for p in s.glob('PHOBOS-0.3-F-*'):
 assert not (out/p.name).exists();shutil.copy2(p,out/p.name)
handoff=out/'0.3-F';handoff.mkdir(exist_ok=False);shutil.copy2(s/'PHOBOS-CODEX-HANDOFF.md',handoff/'PHOBOS-CODEX-HANDOFF.md')
for name in ['PHOBOS-Community-0.3-F-Windows-Installer-ENGINE-0.3-A.exe','PHOBOS-Community-0.3-F-Windows-Runtime.zip']:
 assert not (out/name).exists();shutil.copy2(r/'build03f-final'/name,out/name)
new=sorted(p for p in out.rglob('*') if p.is_file() and p.relative_to(out).as_posix() not in old)
manifest='SHA-256. Paths relative to outputs. This manifest excludes itself to avoid a circular hash.\n\n'+'\n'.join(hash_file(p)+'  '+p.relative_to(out).as_posix() for p in new)+'\n'
(out/'PHOBOS-0.3-F-FINAL-HASHES.txt').write_text(manifest)
for rel,sha in old.items():assert hash_file(out/rel)==sha,rel
print('PASS source ZIP CRC, all baseline files retained, all production Rust unchanged, accepted A-E artifacts unchanged, evidence allowlist, final hashes')
print(manifest)
