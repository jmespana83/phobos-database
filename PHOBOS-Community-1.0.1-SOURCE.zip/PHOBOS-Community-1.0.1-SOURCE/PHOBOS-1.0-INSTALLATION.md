# PHOBOS Community Edition 1.0.1 — Installation

Windows x64 Setup bundles Server, CLI/Admin, service tools and optional Management Studio. Server/tools are one required component because initialization depends on them. A standalone Studio package is also supported. Studio includes its .NET runtime; no SDK is required. Service tools require .NET Framework 4.8. The signed Microsoft VC++ x64 prerequisite is included. PHOBOS artifacts are unsigned.

Normal Setup requires UAC and uses an owned visible configuration dialog. FILESONLY is only an explicit automation mode. Default binary path is Program Files/PHOBOS; configuration/data/log/control paths are under ProgramData/PHOBOS. Service identity is LocalService with an isolated service SID. Setup binds loopback and adds no firewall exception. Credentials are masked and passed through memory/stdin, not argv.

The 1.0 installer registration is distinct from development releases. Incompatible manifests and unrelated nonempty binary paths are rejected before replacement. Repair requires matching 1.0 metadata and the original binary directory. Uninstall removes the owned service/binaries but always keeps data, auth, config, logs and backups. Studio retains profiles and saved SQL.

Isolated test options: /DIR=..., /INSTANCECONFIG=..., /SERVICENAME=PHOBOS10Acceptance /PORT=55449. Service/port overrides affect fresh setup only. Use distinct protected non-nested directories. /FILESONLY=1 allows unattended file installation; configure-stdin accepts a JSON instance line and then a password line through a pipe. Never use primary data for destructive testing.

Remote certificate/firewall provisioning is manual; the local wizard does not configure it. Linux is unqualified in this run. See TEST-RESULTS: a successfully built installer is not proof of normal clean-install/repair/uninstall acceptance.

Patch repair: 1.0.1 accepts protected compatible 1.0.0/1.0.1 instance metadata without catalog migration. Welcome and the pre-copy summary identify repair. Close Studio when requested and choose Retry; Setup never force-closes it. The owned service stops gracefully before file replacement, then the visible Repair instance dialog accepts the existing password and starts/authenticates the service. If shutdown cannot be confirmed, repair stops before replacing binaries. Cancellation or failed authentication never reinitializes data.

Dedicated isolated acceptance instances can use `/INSTANCEKEY=UniqueKey /DIR="C:\Program Files\PHOBOS-Test" /INSTANCECONFIG="C:\ProgramData\PHOBOS-Test\config\instance.json" /SERVICENAME=PHOBOSTest /PORT=55462`. The same key and paths are required on every repair. These instances have independent uninstall registration and Start menu groups. Ordinary primary installation keeps its original product registration.
