# PHOBOS Community Edition 1.0.1 — Security

Coarse server-side roles are enforced: reader reads; writer reads and performs DML; admin additionally performs DDL/administration. Authentication grants connection access subject to limits. SQL CREATE ROLE/GRANT/REVOKE and object-level ACLs are absent. No default password. Use offline user administration and restart to load changes.

Windows setup creates an authenticated loopback service with protected paths and a service SID. Portable development mode can permit unauthenticated loopback without an auth file; do not use it for sensitive data. Public listeners require configured authentication and TLS.

```text
phobos-server --data-dir DATA --auth-file AUTH --bind HOST:PORT --tls-cert FULL_CHAIN_PEM --tls-key PRIVATE_KEY_PEM --wal-mode flush --shutdown-file STOP_FILE
```

Use a SAN matching the client's DNS name, a complete chain and protected supported PEM key. Studio TLS uses OS trust, hostname verification and revocation checking. Provision organizational CA trust through normal administration. Fix untrusted-root/expiry/name errors; never bypass verification. There is no accept-any-certificate option.

Studio profiles do not save passwords. Managed credentials can remain transiently in memory; no secure-erasure/vault claim. SQL files, exports and backups can contain secrets. Cancellation uses a separate authenticated channel and cannot guarantee rollback after commit admission.

Actual PHOBOS/packaged Studio Core qualification passed trusted TLS 1.3, certificate display, rejection of a trusted certificate for the wrong hostname, reader SELECT/write denial, writer INSERT RETURNING/DDL denial, and post-shutdown integrity. Untrusted actual-server and mock-server rejection also pass. The temporary localhost-only test certificate was removed afterward. No validation bypass was introduced. PHOBOS is unsigned; verify the external SHA-256 manifest. Existing optional low-level mTLS/audit facilities are not newly qualified product features.

CLI TLS uses both PHOBOS_TLS_SERVER_NAME (certificate DNS name) and PHOBOS_TLS_CA (PEM trust anchor path). Never set only one. CLI scripted authentication uses PHOBOS_USER/PHOBOS_PASSWORD; prefer interactive shell or protected transient process configuration and clear secrets afterward.
