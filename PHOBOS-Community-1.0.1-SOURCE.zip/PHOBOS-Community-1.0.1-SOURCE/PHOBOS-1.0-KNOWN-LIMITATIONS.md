# PHOBOS Community Edition 1.0.1 — Known Limitations

Most significant limits: FK database-wide writer serialization and scan cost; materialized derived/view/set queries; empty-table ADD COLUMN; coarse external roles rather than SQL grants; one database/server; no sequence reset/advance-on-explicit-ID; no automatic HA.

Some operators retain collecting paths rather than strict streaming. Contention may require whole-transaction retry/backoff. Ambiguous commit/delivery must never be blindly replayed. Storage tuning is inherited. Windows artifacts are unsigned; Linux execution unavailable, so no Linux runtime/package qualification. Trusted Studio TLS/hostname rejection and normal interactive install/repair/cancel plus data-preserving uninstall are qualified. See TEST-RESULTS for exact coverage.

Deferred: temp tables, window functions, CASCADE, UPDATE/DELETE RETURNING, JSON/UUID, schemas/multiple databases, ODBC/JDBC/Node, full DB-API, encryption-at-rest, procedures/triggers, distributed/sharded/multi-master SQL, advanced optimizer/parallel redesign, columnar/vector/materialized views, automatic failover, cloud/Kubernetes control plane, macOS/mobile qualification.

Standard bulk loading was materially slower in two pairs; a bounded identical-data diagnostic did not reproduce the large gap. The cause remains unresolved, and no throughput parity claim is made. See PERFORMANCE for every sample. DDL may receive a retriable schema-exclusive conflict while another statement/transaction or disconnected session is still being cleaned up; wait for quiescence and retry a rejected operation. Never blindly replay an ambiguously committed write.
