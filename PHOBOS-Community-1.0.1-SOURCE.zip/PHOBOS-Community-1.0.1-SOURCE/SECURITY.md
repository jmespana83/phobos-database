# Security

Phobos is experimental alpha software and is not suitable for irreplaceable production data. Do not expose the alpha server to untrusted networks. Report suspected vulnerabilities privately to the project maintainers.


## Phase 7 security posture

Phase 7 introduces Argon2 password hashing, optional TLS via rustls, coarse roles, and a default loopback-only posture. G4 adds optional client-certificate authentication and a bounded JSONL audit sink. Non-loopback binds are refused unless TLS and authentication are configured. Object ACLs, certificate management/revocation, audit rotation, secret-management integration, and external security review remain incomplete. See [authorization and mTLS](docs/security_auth_mtls.md) and [audit logging](docs/audit_logging.md).
