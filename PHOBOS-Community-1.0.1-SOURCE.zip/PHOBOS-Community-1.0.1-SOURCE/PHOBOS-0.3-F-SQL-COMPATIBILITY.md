# PHOBOS 0.3-F SQL compatibility

## Installed stabilization runtime

The Windows installer/runtime use accepted engine **0.3-A**, unchanged. Packaging 0.3-F adds no SQL syntax. See the included PHOBOS-0.3-A-SQL-COMPATIBILITY.md for its complete supported/partial/unsupported matrix.

Verified installed-server example:

```sql
SHOW CATALOG CAPABILITIES;
CREATE TABLE acceptance03f (id BIGINT NOT NULL, label TEXT);
CREATE UNIQUE INDEX acceptance03f_pk ON acceptance03f (id);
INSERT INTO acceptance03f VALUES (1, 'persisted');
SELECT id, label FROM acceptance03f;
SHOW CATALOG INDEXES FROM acceptance03f;
```

The index named acceptance03f_pk above is a UNIQUE index, not a declarative SQL PRIMARY KEY. This distinction is retained in the acceptance report.

## Separate enterprise-schema source candidate

The Rust engine source remains the experimental 0.3-E implementation: literal DEFAULT, restricted CHECK, CREATE TABLE primary keys, transactional ALTER COLUMN SET/DROP DEFAULT and catalog v4. Its full compatibility matrix is PHOBOS-0.3-E-SQL-COMPATIBILITY.md. These features are not included in the accepted-engine Windows runtime merely because its packaging version is 0.3-F.

Example for the separate candidate only:

```sql
CREATE TABLE accounts (id BIGINT PRIMARY KEY, balance BIGINT DEFAULT 10 CHECK(balance>=0));
INSERT INTO accounts (id) VALUES (1);
ALTER TABLE accounts ALTER COLUMN balance SET DEFAULT 20;
```

CHECK remains limited to the documented column/literal or NULL predicates; DEFAULT remains literal. No broader expression or constraint grammar is implied.

## Unsupported/deferred

Identity columns, public sequences, NEXT VALUE FOR, INSERT/UPDATE/DELETE RETURNING and DEFAULT VALUES are not implemented by 0.3-F. No generated-key, allocator rollback, gaplessness, sequence replication or RETURNING result semantics are claimed. Do not use those forms in application templates.

## Version discovery limitations

The installed engine's SHOW CATALOG CAPABILITIES reports server_version=0.3-A and management_api_version=1. It does **not** expose explicit catalog_format_max, identity or returning rows. Missing feature keys must not be interpreted as support. Its catalog maximum remains 3 by inherited engine contract; docs/BUILD.json explicitly declares identity=false and returning=false. The unchanged separate E candidate reports server_version=0.3-E and catalog_format_max=4, with schema_definitions text, but likewise has no identity/RETURNING support.

This leaves the requested additional server capability rows deferred rather than modifying and relabeling an accepted binary solely for packaging. Future engine work should add stable explicit feature keys and test older clients against additive metadata. Studio 0.3-D successfully consumed the accepted runtime unchanged; no unsupported templates/keywords were added.
