# PHOBOS Community Edition 1.0.1 — Administration

Component identity: phobos-server --version, phobos-cli --version, phobos-admin --version. File administration commands take the data directory, usually INSTANCE/data.

```text
phobos-admin init NEW_INSTANCE
phobos-admin user-add-stdin AUTH USER admin|writer|reader
phobos-admin user-list AUTH
phobos-admin user-remove AUTH USER
phobos-admin check DATA
phobos-admin storage-lifecycle DATA
phobos-admin backup DATA NEW_BACKUP
phobos-admin backup-base DATA NEW_PITR_BASE
phobos-admin restore BACKUP NEW_DATA
phobos-admin upgrade-community-copy OLD_DATA BACKUP NEW_DATA [--accept-v4]
```

user-add-stdin reads one password line. Do not put production credentials in argv or saved scripts. The server loads users/roles at startup; restart after changing the auth store. Preserve an administrator. Windows helper verbs: configure, configure-stdin, start, stop, status, remove, with instance.json. Removal keeps data.

Stop via Services or --shutdown-file and wait for clean exit before offline operations. Tools enforce ownership locks. Do not kill a production instance to accelerate shutdown. JSON --config is explicit and rejects unknown fields. Worker/connection/time/memory/scratch controls are technical safety settings. Never edit engine files manually. Back up external auth/TLS/runtime/service metadata separately.
