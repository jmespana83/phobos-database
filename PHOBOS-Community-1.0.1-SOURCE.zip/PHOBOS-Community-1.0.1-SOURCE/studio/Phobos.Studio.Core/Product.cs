using System.Text;
using System.Text.Json;

namespace Phobos.Studio.Core;

public sealed record QueryLimits(int MaxRows=50000,int MemoryMiB=32,int TimeoutSeconds=120) {
    public void Validate(){if(MaxRows is <1 or >100000 || MemoryMiB is <1 or >64 || TimeoutSeconds is <1 or >600)throw new ArgumentException("Limits must be 1–100,000 rows, 1–64 MiB, and 1–600 seconds.");}
}

/// <summary>Statement boundaries only, matching the accepted PHOBOS lexer. The server still parses SQL.</summary>
public static class SqlScripts {
    public static IReadOnlyList<string> Split(string sql){
        if(Encoding.UTF8.GetByteCount(sql)>ProtocolClient.MaxFrame)throw new ArgumentException("Script exceeds 1 MiB.");
        var result=new List<string>();int start=0,depth=0;bool code=false;
        for(int i=0;i<sql.Length;i++){
            char c=sql[i];
            if(char.IsWhiteSpace(c))continue;
            if(c=='-'&&i+1<sql.Length&&sql[i+1]=='-'){i+=2;while(i<sql.Length&&sql[i]!='\n')i++;continue;}
            if(c=='/'&&i+1<sql.Length&&sql[i+1]=='*'){
                i+=2;bool ended=false;for(;i<sql.Length;i++){
                    if(i+1<sql.Length&&sql[i]=='/'&&sql[i+1]=='*')throw new ArgumentException("Nested block comments are not supported; no statements were submitted.");
                    if(i+1<sql.Length&&sql[i]=='*'&&sql[i+1]=='/'){i++;ended=true;break;}}
                if(!ended)throw new ArgumentException("Unterminated block comment; no statements were submitted.");continue;
            }
            if(c is '\'' or '"'){
                code=true;char quote=c;bool ended=false;for(i++;i<sql.Length;i++){if(sql[i]!=quote)continue;if(i+1<sql.Length&&sql[i+1]==quote){i++;continue;}ended=true;break;}
                if(!ended)throw new ArgumentException("Unterminated quoted string/identifier; no statements were submitted.");continue;
            }
            if(c is '`' or '[' or ']' || (c=='$'&&(i+1>=sql.Length||!char.IsAsciiDigit(sql[i+1]))))throw new ArgumentException("Unsupported quoting in script. Use PHOBOS single-quoted strings/double-quoted identifiers; no statements were submitted.");
            if(c=='(')depth++;if(c==')'&&--depth<0)throw new ArgumentException("Unbalanced parentheses; no statements were submitted.");
            if(c==';'){if(depth!=0)throw new ArgumentException("Semicolon inside parentheses; no statements were submitted.");if(code)result.Add(sql[start..i].Trim());start=i+1;code=false;}else code=true;
        }
        if(depth!=0)throw new ArgumentException("Unbalanced parentheses; no statements were submitted.");
        if(code)result.Add(sql[start..].Trim());if(result.Count>32)throw new ArgumentException("At most 32 statements per execution.");return result;
    }
}

public static class ResultExport {
    static string Quote(string text)=>"\""+text.Replace("\"","\"\"")+"\"";
    public static string Field(Cell cell,bool spreadsheetSafe){
        if(cell.Tag==0)return "\\N";string text=cell.Text;
        if(spreadsheetSafe&&cell.Tag==4&&text.TrimStart().FirstOrDefault() is '=' or '+' or '-' or '@')text="'"+text;
        return Quote(text);
    }
    // NULL is unquoted \N; every non-NULL field is quoted, including a literal text \N.
    public static async Task CsvAsync(TextWriter writer,string[] columns,IEnumerable<Cell[]> rows,bool spreadsheetSafe=false){
        await writer.WriteLineAsync(string.Join(',',columns.Select(c=>Field(new Cell(4,c),spreadsheetSafe))));
        foreach(var row in rows)await writer.WriteLineAsync(string.Join(',',row.Select(c=>Field(c,spreadsheetSafe))));
    }
    public static async Task JsonAsync(Stream stream,string[] columns,IEnumerable<Cell[]> rows){
        using var writer=new Utf8JsonWriter(stream,new JsonWriterOptions{Indented=true});writer.WriteStartObject();writer.WriteStartArray("columns");foreach(var c in columns)writer.WriteStringValue(c);writer.WriteEndArray();writer.WriteStartArray("rows");
        foreach(var row in rows){writer.WriteStartArray();foreach(var cell in row){writer.WriteStartObject();writer.WriteString("type",cell.Kind);if(cell.Tag==0)writer.WriteNull("value");else writer.WriteString("value",cell.Text);writer.WriteEndObject();}writer.WriteEndArray();}
        writer.WriteEndArray();writer.WriteEndObject();await writer.FlushAsync();
    }
    public static async Task FileAsync(string path,string[] columns,IEnumerable<Cell[]> rows,bool json,bool safe){
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try{await using(var stream=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None,65536,true)){
            if(json)await JsonAsync(stream,columns,rows);else{await using var writer=new StreamWriter(stream,new UTF8Encoding(false));await CsvAsync(writer,columns,rows,safe);}}
            File.Move(temp,path,true);
        }finally{if(File.Exists(temp))File.Delete(temp);}
    }
}

public sealed record LayoutSettings(double Width=1280,double Height=850,double ExplorerWidth=290,double EditorRatio=0.5,string Theme="System",bool Maximized=false) {
    public LayoutSettings Safe()=>new(Math.Clamp(double.IsFinite(Width)?Width:1280,900,3000),Math.Clamp(double.IsFinite(Height)?Height:850,620,2000),Math.Clamp(double.IsFinite(ExplorerWidth)?ExplorerWidth:290,180,800),Math.Clamp(double.IsFinite(EditorRatio)?EditorRatio:.6,.2,.8),Theme is "Dark" or "Light"?Theme:"System",Maximized);
}
public sealed class LayoutStore(string path) {
    public async Task<LayoutSettings> LoadAsync(){try{if(!File.Exists(path)||new FileInfo(path).Length>16384)return new();return (JsonSerializer.Deserialize<LayoutSettings>(await File.ReadAllTextAsync(path))??new()).Safe();}catch(Exception e)when(e is IOException or JsonException){return new();}}
    public async Task SaveAsync(LayoutSettings settings){Directory.CreateDirectory(Path.GetDirectoryName(path)!);string temp=path+".tmp";await File.WriteAllTextAsync(temp,JsonSerializer.Serialize(settings.Safe()));File.Move(temp,path,true);}
}
