using System.Buffers.Binary;
using System.Globalization;
using System.Net.Security;
using System.Net.Sockets;
using System.Numerics;
using System.Text;

namespace Phobos.Studio.Core;

public sealed record Profile(string Name, string Host, int Port, string Username, bool Tls = false);
public sealed class PhobosException(string code, string message) : IOException(message) { public string Code { get; } = code; public bool IsStatementError { get; internal init; } }
public sealed record Cell(byte Tag, object? Value) {
    public string Kind => new[]{"NULL","BIGINT","BOOLEAN","DOUBLE","TEXT","BINARY","DATE","TIMESTAMP","DECIMAL"}[Tag];
    public string Text => Tag switch {
        0 => "⟨NULL⟩", 2 => (bool)Value! ? "true" : "false",
        3 => ((double)Value!).ToString("R", CultureInfo.InvariantCulture),
        5 => "0x" + Convert.ToHexString((byte[])Value!),
        6 => DateText((int)Value!), 7 => TimestampText((long)Value!),
        _ => Convert.ToString(Value,CultureInfo.InvariantCulture) ?? ""
    };
    static string DateText(int v) { try{return DateOnly.FromDateTime(DateTime.UnixEpoch).AddDays(v).ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);}catch{return $"DATE({v} days since 1970-01-01)";} }
    static string TimestampText(long v) {try{return DateTime.UnixEpoch.AddTicks(checked(v*10)).ToString("yyyy-MM-dd HH:mm:ss.ffffff 'UTC'",CultureInfo.InvariantCulture);}catch{return $"TIMESTAMP({v} µs since epoch)";} }
}
public sealed record Result(string[] Columns, List<Cell[]> Rows, string? Command, ulong Affected, long WireBytes, long RetainedBytes=0);

// One serialized SQL session. A separate authenticated session carries cancellation.
public sealed class ProtocolClient : IDisposable {
    public const int MaxFrame = 1024*1024;
    static readonly UTF8Encoding Utf8 = new(false,true);
    readonly TcpClient socket; readonly Stream stream; uint next; bool disposed;
    public bool IsOpen => !disposed;
    public string TransportInfo {get;private set;}="Plaintext TCP — trusted network/tunnel only";
    public string Hello { get; private set; } = "";
    public TimeSpan Timeout { get; set; } = TimeSpan.FromMinutes(2);
    ProtocolClient(TcpClient socket, Stream stream) {this.socket=socket;this.stream=stream;}
    public static async Task<ProtocolClient> ConnectAsync(Profile p,string password,CancellationToken ct=default) {
        if(string.IsNullOrWhiteSpace(p.Host)||p.Port is <1 or >65535||p.Username.Contains('\0')||password.Contains('\0'))throw new ArgumentException("Invalid endpoint or credentials.");
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(TimeSpan.FromSeconds(15));
        var tcp=new TcpClient{NoDelay=true}; ProtocolClient? client=null;
        try {
            await tcp.ConnectAsync(p.Host,p.Port,deadline.Token); Stream transport=tcp.GetStream();
            if(p.Tls){var tls=new SslStream(transport,false);transport=tls;await tls.AuthenticateAsClientAsync(new SslClientAuthenticationOptions {TargetHost=p.Host,CertificateRevocationCheckMode=System.Security.Cryptography.X509Certificates.X509RevocationMode.Online},deadline.Token);}
            client=new(tcp,transport);
            if(transport is SslStream secure && secure.RemoteCertificate is not null){using var certificate=new System.Security.Cryptography.X509Certificates.X509Certificate2(secure.RemoteCertificate);client.TransportInfo=$"TLS {secure.SslProtocol} • Subject: {certificate.Subject} • Issuer: {certificate.Issuer} • Expires: {certificate.NotAfter:O} • SHA-256: {certificate.GetCertHashString(System.Security.Cryptography.HashAlgorithmName.SHA256)}";}
            client.Hello=await client.TextAsync(1,2,"phobos-studio/1.0.1;stream=1",deadline.Token);
            if(!client.Hello.Split(';').Contains("stream=1"))throw new PhobosException("Unsupported","Server does not support typed streaming protocol v1.");
            try{await client.TextAsync(5,6,p.Username+"\0"+password,deadline.Token);}catch(PhobosException){throw new PhobosException("Authentication","Authentication failed. Verify username, password and server policy.");}
            return client;
        }catch{client?.Dispose();tcp.Dispose();throw;}
    }
    public async Task<string> TextAsync(byte type,byte expected,string text,CancellationToken ct=default) {
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(Timeout);
        try{uint id=await Send(type,text,deadline.Token);var f=await Read(id,deadline.Token);if(f.Type==255)throw new PhobosException("Server",Utf8.GetString(f.Body));if(f.Type!=expected)throw Invalid("Unexpected response type.");return Utf8.GetString(f.Body);}
        catch{Dispose();throw;}
    }
    public Task<string> ReserveCancelAsync(CancellationToken ct=default)=>TextAsync(40,41,"",ct);
    public Task<string> CancelAsync(string handle,CancellationToken ct=default)=>TextAsync(42,43,handle,ct);
    async Task<uint> Send(byte type,string text,CancellationToken ct) {
        ObjectDisposedException.ThrowIf(disposed,this);
        int size=Utf8.GetByteCount(text);if(size>MaxFrame)throw new PhobosException("ClientLimit","Request exceeds 1 MiB.");
        byte[] body=Utf8.GetBytes(text),header=new byte[16];"PHOB"u8.CopyTo(header);header[4]=1;header[5]=type;
        uint id=++next;BinaryPrimitives.WriteUInt32BigEndian(header.AsSpan(8),id);BinaryPrimitives.WriteUInt32BigEndian(header.AsSpan(12),(uint)size);
        try{await stream.WriteAsync(header,ct);await stream.WriteAsync(body,ct);}finally{Array.Clear(body);}
        return id;
    }
    async Task<(byte Type,byte[] Body)> Read(uint id,CancellationToken ct) {
        byte[] h=new byte[16];await stream.ReadExactlyAsync(h,ct);
        if(!h.AsSpan(0,4).SequenceEqual("PHOB"u8)||h[4]!=1||h[6]!=0||h[7]!=0||BinaryPrimitives.ReadUInt32BigEndian(h.AsSpan(8))!=id)throw Invalid("Invalid header, version, flags or request ID.");
        uint length=BinaryPrimitives.ReadUInt32BigEndian(h.AsSpan(12));if(length>MaxFrame)throw Invalid("Response exceeds 1 MiB frame limit.");
        byte[] b=new byte[(int)length];await stream.ReadExactlyAsync(b,ct);return(h[5],b);
    }
    public async Task<Result> QueryAsync(string sql,Action<ulong>? progress=null,int rowLimit=50000,long byteLimit=32*1024*1024,CancellationToken ct=default,Func<string[],Task>? onStart=null,Func<IReadOnlyList<Cell[]>,Task>? onBatch=null) {
        if(rowLimit<1||byteLimit<1)throw new ArgumentOutOfRangeException(nameof(rowLimit));
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(Timeout);
        try{
            uint id=await Send(12,sql,deadline.Token);string[]? columns=null;var rows=new List<Cell[]>();ulong batches=0,total=0;long bytes=0,retained=0;
            while(true){
                var f=await Read(id,deadline.Token);bytes+=16+f.Body.Length;
                var d=new Decoder(f.Body);if(d.U8()!=1)throw Invalid("Invalid stream version.");
                switch(f.Type){
                    case 13:
                        if(columns!=null)throw Invalid("Duplicate result start.");int count=d.Count(4);if(count>4096)throw Invalid("Too many columns.");columns=new string[count];for(int i=0;i<count;i++)columns[i]=d.Text();d.End();if(onStart!=null)await onStart(columns);break;
                    case 14:
                        if(columns==null||d.U64()!=batches)throw Invalid("Missing start or invalid batch sequence.");int n=d.Count(4);if(n is <1 or >256)throw Invalid("Invalid batch size.");
                        // Bound both wire strings and CLR object overhead, before retaining a batch.
                        retained=checked(retained+f.Body.Length*4L+(long)n*(64+columns.Length*64L));
                        if(total+(ulong)n>(ulong)rowLimit||retained>byteLimit)throw new PhobosException("ClientLimit",$"Result exceeded Studio's {rowLimit:N0} row / {byteLimit/1048576} MiB retained-memory budget. No result is presented as complete. Session closed; use LIMIT and reconnect. Writes are never replayed.");
                        var batch=new List<Cell[]>(n);for(int i=0;i<n;i++){if(d.Count(1)!=columns.Length)throw Invalid("Column count mismatch.");var values=new Cell[columns.Length];for(int j=0;j<values.Length;j++)values[j]=d.Value();rows.Add(values);batch.Add(values);}
                        d.End();total+=(ulong)n;batches++;progress?.Invoke(total);if(onBatch!=null)await onBatch(batch);break;
                    case 15:
                        if(columns==null||d.U64()!=total||d.U64()!=batches)throw Invalid("Invalid result totals.");d.End();return new(columns,rows,null,0,bytes,retained);
                    case 16:
                        if(columns!=null)throw Invalid("Command after result start.");string tag=d.Text();ulong affected=d.U64();d.End();return new([],rows,tag,affected,bytes);
                    case 17:
                        string code=d.Text(),message=d.Text();d.End();
                        // Only a fully decoded terminal SQL error can leave this session reusable.
                        throw new PhobosException(code,message){IsStatementError=Recoverable(code)};
                    default:throw Invalid("Unexpected streaming frame.");
                }
            }
        }catch(PhobosException e) when(e.IsStatementError){throw;}
        catch{Dispose();throw;}
    }
    static bool Recoverable(string code)=>code is "SqlSyntax" or "ParserDepth" or "Semantic" or "TypeMismatch" or "NotFound" or "AlreadyExists" or "ConstraintViolation" or "Authorization" or "TransactionState" or "LockTimeout" or "ResourceLimit" or "Unsupported";
    public void Dispose(){if(disposed)return;disposed=true;stream.Dispose();socket.Dispose();}
    static PhobosException Invalid(string message)=>new("InvalidProtocol",message);
    sealed class Decoder(byte[] bytes) {
        int pos;
        ReadOnlySpan<byte> Take(int n){if(n<0||n>bytes.Length-pos)throw Invalid("Truncated payload.");var s=bytes.AsSpan(pos,n);pos+=n;return s;}
        public byte U8()=>Take(1)[0];public uint U32()=>BinaryPrimitives.ReadUInt32BigEndian(Take(4));public ulong U64()=>BinaryPrimitives.ReadUInt64BigEndian(Take(8));
        public int Count(int min){uint n=U32();if(n>(bytes.Length-pos)/min)throw Invalid("Invalid length/count.");return(int)n;}
        public string Text()=>Utf8.GetString(Take(Count(1)));
        public void End(){if(pos!=bytes.Length)throw Invalid("Trailing payload bytes.");}
        public Cell Value(){byte tag=U8();object? v=tag switch {
            0=>null,1=>BinaryPrimitives.ReadInt64BigEndian(Take(8)),2=>Boolean(),3=>BitConverter.Int64BitsToDouble(BinaryPrimitives.ReadInt64BigEndian(Take(8))),
            4=>Text(),5=>Take(Count(1)).ToArray(),6=>BinaryPrimitives.ReadInt32BigEndian(Take(4)),7=>BinaryPrimitives.ReadInt64BigEndian(Take(8)),8=>Decimal(),_=>throw Invalid("Unknown value type.")};return new(tag,v);}
        bool Boolean()=>U8() switch{0=>false,1=>true,_=>throw Invalid("Invalid Boolean.")};
        string Decimal(){var v=new BigInteger(Take(16),isUnsigned:false,isBigEndian:true);int scale=U8();string s=BigInteger.Abs(v).ToString(CultureInfo.InvariantCulture).PadLeft(scale+1,'0');if(scale>0)s=s.Insert(s.Length-scale,".");return v.Sign<0?"-"+s:s;}
    }
}
