using System.Text.Json;

namespace Phobos.Studio.Core;

public sealed class StudioSession : IDisposable {
    ProtocolClient? query, cancel; string? handle; readonly SemaphoreSlim gate=new(1,1);
    public Profile? Profile {get;private set;}
    public string TransportInfo=>query?.TransportInfo??"Disconnected";
    public bool TransactionActive {get;private set;}
    public bool Connected=>query?.IsOpen==true;
    public Dictionary<string,string> Capabilities {get;private set;}=[];
    public bool MetadataSupported=>Capabilities.GetValueOrDefault("management_api_version")=="1";
    public bool KnownDdl=>MetadataSupported && (Capabilities.GetValueOrDefault("ddl_core")=="true" || Capabilities.GetValueOrDefault("server_version")=="0.3-A");
    public bool CanCancel=>handle!=null&&cancel?.IsOpen==true;
    public async Task ConnectAsync(Profile profile,string password) {
        Dispose();var q=await ProtocolClient.ConnectAsync(profile,password);ProtocolClient? c=null;
        try {
            var caps=await q.QueryAsync("SHOW CATALOG CAPABILITIES");
            Capabilities=Records(caps).ToDictionary(r=>r["capability_name"],r=>r["capability_value"]);
            if(Capabilities.ContainsKey("cancel")) c=await ProtocolClient.ConnectAsync(profile,password);
            query=q;cancel=c;Profile=profile;
        }catch{q.Dispose();c?.Dispose();throw;}
    }
    public async Task<Result> ExecuteAsync(string sql,Action<ulong>? progress=null,QueryLimits? limits=null,Func<string[],Task>? onStart=null,Func<IReadOnlyList<Cell[]>,Task>? onBatch=null) {
        await gate.WaitAsync();try {
            if(query==null||!query.IsOpen)throw new IOException("Disconnected. Connect before executing SQL.");
            handle=cancel?.IsOpen==true?await query.ReserveCancelAsync():null;
            limits??=new QueryLimits();limits.Validate();query.Timeout=TimeSpan.FromSeconds(limits.TimeoutSeconds);
            var result=await query.QueryAsync(sql,progress,limits.MaxRows,limits.MemoryMiB*1048576L,onStart:onStart,onBatch:onBatch);
            if(result.Command=="BEGIN")TransactionActive=true;else if(result.Command is "COMMIT" or "ROLLBACK")TransactionActive=false;return result;
        }finally{handle=null;gate.Release();}
    }
    public async Task<string> CancelAsync(){var h=handle;var c=cancel;if(h==null||c==null) return "No active cancellation handle. The query may have completed.";await c.CancelAsync(h);return "Cancellation requested. Await the query's actual outcome; commit admission may already have occurred.";}
    public async Task<Dictionary<string,List<Dictionary<string,string>>>> CatalogAsync(string? table=null) {
        if(!MetadataSupported)throw new InvalidOperationException("Object Explorer requires Management API v1. SQL remains available.");
        async Task<Dictionary<string,List<Dictionary<string,string>>>> Read(){var all=new Dictionary<string,List<Dictionary<string,string>>>();foreach(string kind in new[]{"TABLES","COLUMNS","INDEXES","CONSTRAINTS"})all[kind]=Records(await ExecuteAsync("SHOW CATALOG "+kind+(table==null?"":" FROM "+SqlTemplates.QuotedIdentifier(table))));return all;}
        var first=await Read();var second=await Read();
        if(JsonSerializer.Serialize(first)!=JsonSerializer.Serialize(second))throw new PhobosException("CatalogChanged","Catalog changed during refresh. Refresh again; no mixed metadata was published.");
        return second;
    }
    public static List<Dictionary<string,string>> Records(Result result)=>result.Rows.Select(row=>result.Columns.Select((name,i)=>new KeyValuePair<string,string>(name,row[i].Text)).ToDictionary()).ToList();
    public void Dispose(){query?.Dispose();cancel?.Dispose();query=null;cancel=null;handle=null;Capabilities=[];TransactionActive=false;}
}

public sealed class ProfileStore(string path) {
    public string? LoadWarning {get;private set;}
    public async Task<List<Profile>> LoadAsync(){LoadWarning=null;try{if(!File.Exists(path))return [];if(new FileInfo(path).Length>1024*1024)throw new IOException("Profile file exceeds size limit.");var profiles=JsonSerializer.Deserialize<List<Profile>>(await File.ReadAllTextAsync(path))??[];if(profiles.Count>100||profiles.Any(p=>p==null||string.IsNullOrWhiteSpace(p.Name)||string.IsNullOrWhiteSpace(p.Host)||p.Port is <1 or >65535||p.Username==null))throw new JsonException("Invalid profile fields.");return profiles;}catch(Exception e)when(e is JsonException or IOException){LoadWarning="Profiles could not be read; defaults loaded. Original file retained. "+e.Message;return [];}}
    public async Task SaveAsync(IEnumerable<Profile> profiles){var snapshot=profiles.ToArray();if(snapshot.Length>100)throw new IOException("At most 100 profiles are supported.");Directory.CreateDirectory(Path.GetDirectoryName(path)!);if(LoadWarning!=null&&File.Exists(path))File.Copy(path,path+".corrupt-"+DateTime.UtcNow.Ticks);string temp=path+".tmp";await File.WriteAllTextAsync(temp,JsonSerializer.Serialize(snapshot,new JsonSerializerOptions{WriteIndented=true}));File.Move(temp,path,true);}
}
public sealed class SqlDocument {
    public string? Path {get;private set;} public string Text {get;set;}="";string saved="";
    public bool Modified=>Text!=saved;public string Title=>(Path==null?"New query":System.IO.Path.GetFileName(Path))+(Modified?" *":"");
    public async Task OpenAsync(string path){if(new FileInfo(path).Length>1024*1024)throw new IOException("SQL file exceeds 1 MiB editor limit.");Text=await File.ReadAllTextAsync(path);saved=Text;Path=path;}
    public async Task SaveAsync(string path){string snapshot=Text;await File.WriteAllTextAsync(path,snapshot);saved=snapshot;Path=path;}
}
public static class SqlTemplates {
    public static string QuotedIdentifier(string value)=>"\""+value.Replace("\"","\"\"")+"\"";
    public static string Identifier(string value){if(!System.Text.RegularExpressions.Regex.IsMatch(value,"^[A-Za-z_][A-Za-z0-9_]*$"))throw new ArgumentException("Use a simple SQL identifier (letters, digits, underscore; no leading digit).");return value;}
    public static string CreateTable(string name)=>$"CREATE TABLE {Identifier(name)} (\n    id BIGINT NOT NULL,\n    name TEXT\n);";
    public static string Index(string table,string name,string columns,bool unique)=>$"CREATE {(unique?"UNIQUE ":"")}INDEX {Identifier(name)} ON {Identifier(table)} ({string.Join(", ",columns.Split(',').Select(c=>Identifier(c.Trim())))});";
}
