using System.Collections.ObjectModel;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using Avalonia.Threading;
using Phobos.Studio.Core;
namespace Phobos.Studio;
public sealed partial class MainWindow:Window {
 readonly ILocalInstances platform=OperatingSystem.IsWindows()?new WindowsInstances():new NoLocalInstances();
 readonly ProfileStore profiles=new(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"PHOBOS","Studio","profiles.json"));
 readonly LayoutStore layoutStore=new(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"PHOBOS","Studio","layout-v2.json"));
 readonly ObservableCollection<TabItem> tabs=[]; readonly TabControl editors=new(); readonly TreeView explorer=new();
 readonly TextBox filter=new(){Watermark="Filter tables",Margin=new Thickness(4)};
 readonly TextBlock status=new(){Margin=new Thickness(10,6)};
 readonly Button execute=new(){Content="Execute  F5"},cancel=new(){Content="Cancel"},refresh=new(){Content="Refresh"},connect=new(){Content="Connect"};
 readonly Grid layout=new(){ColumnDefinitions=new ColumnDefinitions("290,5,*")};
 List<LocalInstance> locals=[]; bool closing; int nextTab; string theme="System"; string? selectedTable;
 QueryPane Active=>(QueryPane)((TabItem)editors.SelectedItem!).Content!;
 IEnumerable<QueryPane> Panes=>tabs.Select(t=>(QueryPane)t.Content!);
 public MainWindow(){
  Title="PHOBOS Management Studio · 1.0.1";Width=1280;Height=850;MinWidth=900;MinHeight=620;
  var root=new DockPanel();Content=root;
  var menu=new Menu{ItemsSource=new[]{
   Menu("File",Item("New independent query",NewConnectedQuery,"Ctrl+N"),Item("Open SQL…",OpenSql,"Ctrl+O"),Item("Save",()=>Save(false),"Ctrl+S"),Item("Save As…",()=>Save(true)),Item("Close tab",CloseTab,"Ctrl+W"),Item("Exit",()=>Close())),
   Menu("Edit",Item("Undo",()=>Active.Editor.Undo()),Item("Redo",()=>Active.Editor.Redo()),Item("Find…",Find,"Ctrl+F"),Item("Complete…",Complete,"Ctrl+Space")),
   Menu("Query",Item("Execute selected SQL / script",Execute,"F5"),Item("Cancel",Cancel),Item("Limits…",Limits),Item("In-memory history…",History)),
   Menu("View",Item("Dark",()=>ApplyTheme("Dark")),Item("Light",()=>ApplyTheme("Light")),Item("System",()=>ApplyTheme("System"))),
   Menu("Connection",Item("Connect…",Connect),Item("Disconnect",Disconnect),Item("Profiles…",Profiles),Item("Transport / certificate…",()=>Notice("Connection security",Active.Session.TransportInfo)),Item("Local administration…",Administration)),
   Menu("Objects",Item("Refresh connection",()=>Refresh()),Item("Refresh selected table",()=>Refresh(selectedTable)),Item("Create table…",()=>ObjectSql("table")),Item("Create index…",()=>ObjectSql("index")),Item("Create unique index…",()=>ObjectSql("unique")),Item("Rename table…",()=>ObjectSql("rename")),Item("Rename column…",()=>ObjectSql("column")),Item("SHOW CATALOG template",()=>NewQuery("SHOW CATALOG TABLES;\nSHOW CATALOG COLUMNS;",Active.PreferredProfile))),
   Menu("Help",Item("About",()=>Notice("PHOBOS Studio 1.0.1","Independent sessions per tab; at most 8 tabs / 16 connections. Scripts: at most 32 statements, stop on first error. No automatic SQL replay. Defaults: 50,000 rows / estimated 32 MiB / 120 seconds. Passwords and SQL history are not persisted. Community Edition; Management API v1.")))}};
  DockPanel.SetDock(menu,Dock.Top);root.Children.Add(menu);
  var toolbar=new WrapPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(8)};
  foreach(var b in new[]{connect,Button("New query",NewConnectedQuery),execute,cancel,refresh,Button("Profiles…",Profiles)}){b.Margin=new Thickness(3);toolbar.Children.Add(b);}
  DockPanel.SetDock(toolbar,Dock.Top);root.Children.Add(toolbar);DockPanel.SetDock(status,Dock.Bottom);root.Children.Add(status);root.Children.Add(layout);
  var left=new DockPanel{Margin=new Thickness(5)};var label=new TextBlock{Text="OBJECT EXPLORER",FontWeight=FontWeight.Bold,Margin=new Thickness(6)};DockPanel.SetDock(label,Dock.Top);left.Children.Add(label);DockPanel.SetDock(filter,Dock.Top);left.Children.Add(filter);left.Children.Add(explorer);layout.Children.Add(left);
  var splitter=new GridSplitter{Width=5,HorizontalAlignment=HorizontalAlignment.Stretch};Grid.SetColumn(splitter,1);layout.Children.Add(splitter);Grid.SetColumn(editors,2);layout.Children.Add(editors);editors.ItemsSource=tabs;
  explorer.SelectionChanged+=(_,_)=>selectedTable=(explorer.SelectedItem as TreeViewItem)?.Tag as string;
  filter.TextChanged+=(_,_)=>RenderCatalog();editors.SelectionChanged+=(_,_)=>{if(editors.SelectedItem!=null){selectedTable=null;RenderCatalog();UpdateState();}};
  connect.Click+=async(_,_)=>await Safe(Connect);execute.Click+=async(_,_)=>await Safe(Execute);cancel.Click+=async(_,_)=>await Safe(Cancel);refresh.Click+=async(_,_)=>await Safe(()=>Refresh());
  KeyDown+=async(_,e)=>{if(e.Key==Key.F5||(e.Key==Key.Enter&&e.KeyModifiers.HasFlag(KeyModifiers.Control))){e.Handled=true;await Safe(Execute);}else if(e.KeyModifiers.HasFlag(KeyModifiers.Control)){Func<Task>? action=e.Key switch{Key.N=>NewConnectedQuery,Key.W=>CloseTab,Key.O=>OpenSql,Key.S=>()=>Save(false),Key.F=>Find,Key.Space=>Complete,_=>null};if(action!=null){e.Handled=true;await Safe(action);}}};
  Closing+=async(_,e)=>{if(closing)return;e.Cancel=true;await Safe(async()=>{if(Panes.Any(p=>p.Busy)){await Notice("Operation active","Wait for completion or cancel before closing.");return;}foreach(var p in Panes.ToArray())if(!await ConfirmDocument(p))return;await SaveLayout();closing=true;foreach(var p in Panes)p.Dispose();Close();});};
  NewQuery();ActualThemeVariantChanged+=(_,_)=>UpdateBackground();ApplyTheme("System");
  Opened+=async(_,_)=>{await Safe(async()=>{var s=await layoutStore.LoadAsync();Width=s.Width;Height=s.Height;layout.ColumnDefinitions[0].Width=new GridLength(s.ExplorerWidth);SetRatio(Active,s.EditorRatio);ApplyTheme(s.Theme);if(s.Maximized)WindowState=WindowState.Maximized;locals=await platform.DiscoverAsync();});
#if STUDIO_VALIDATION
   var args=Environment.GetCommandLineArgs();if(args.Length>2&&args[1].StartsWith("--evidence",StringComparison.Ordinal))await StudioEvidence.Run(this,args[2]);
#endif
  };
 }
 static MenuItem Menu(string title,params MenuItem[] items)=>new(){Header=title,ItemsSource=items};
 MenuItem Item(string title,Action action,string? shortcut=null)=>Item(title,()=>{action();return Task.CompletedTask;},shortcut);
 MenuItem Item(string title,Func<Task> action,string? shortcut=null){var i=new MenuItem{Header=title};if(shortcut!=null)i.InputGesture=KeyGesture.Parse(shortcut);i.Click+=async(_,_)=>await Safe(action);return i;}
 Button Button(string title,Func<Task> action){var b=new Button{Content=title};b.Click+=async(_,_)=>await Safe(action);return b;}
 async Task Safe(Func<Task> action){var p=editors.SelectedItem==null?null:Active;try{await action();}catch(Exception e){p?.Log(Error(e),true);UpdateState();}}
 static string Error(Exception e)=>e is PhobosException p?(p.Message.StartsWith(p.Code+":",StringComparison.Ordinal)?p.Message:$"{p.Code}: {p.Message}"):e is OperationCanceledException?"Operation timed out or cancelled. Reconnect explicitly if disconnected.":e.Message;
 void UpdateState(){if(editors.SelectedItem==null)return;var p=Active;if(!p.Busy&&p.State=="Cancelling")p.SetState(p.Session.Connected?"Ready":"Disconnected");if(!p.Session.Connected){p.Catalog=[];explorer.ItemsSource=null;}connect.IsEnabled=!p.Busy;execute.IsEnabled=!p.Busy&&p.Session.Connected;cancel.IsEnabled=p.Busy&&!p.Cancelling&&p.Session.Connected;refresh.IsEnabled=!p.Busy&&p.Session.Connected&&p.Session.MetadataSupported;status.Text=$"{p.PreferredProfile?.Name??"No connection"} • {p.State} • {(p.Session.Connected?(p.Session.Profile!.Tls?"TLS validated":"Plaintext TCP"):"Disconnected — no automatic replay")}";}
 QueryPane NewQuery(string text="",Profile? profile=null){if(tabs.Count>=8)throw new InvalidOperationException("At most 8 independent query tabs. Close a tab first.");QueryPane? p=null;p=new QueryPane(mode=>Safe(()=>Copy(p!,mode)),()=>Safe(()=>Export(p!))){PreferredProfile=profile,Number=++nextTab};p.Document.Text=text;p.Editor.Text=text;var t=new TabItem{Content=p};p.Owner=t;p.Editor.TextChanged+=(_,_)=>{p.Document.Text=p.Editor.Text;p.SetState(p.State);};tabs.Add(t);editors.SelectedItem=t;p.SetState("Disconnected");p.Editor.Focus();return p;}
 async Task NewConnectedQuery(){var profile=Active.PreferredProfile;var p=NewQuery(profile:profile);if(profile!=null)await ConnectPane(p);}
 void ApplyTheme(string value){theme=value;Application.Current!.RequestedThemeVariant=value switch{"Dark"=>ThemeVariant.Dark,"Light"=>ThemeVariant.Light,_=>ThemeVariant.Default};UpdateBackground();}
 void UpdateBackground()=>Background=new SolidColorBrush(Color.Parse(ActualThemeVariant==ThemeVariant.Dark?"#20242c":"#f5f6f8"));
 static void SetRatio(QueryPane p,double ratio){p.RowDefinitions[0].Height=new GridLength(ratio,GridUnitType.Star);p.RowDefinitions[2].Height=new GridLength(1-ratio,GridUnitType.Star);}
 async Task SaveLayout(){var p=Active;double total=p.RowDefinitions[0].ActualHeight+p.RowDefinitions[2].ActualHeight;await layoutStore.SaveAsync(new(Width,Height,layout.ColumnDefinitions[0].ActualWidth,total>0?p.RowDefinitions[0].ActualHeight/total:.6,theme,WindowState==WindowState.Maximized));}
 Task Notice(string title,string text)=>Dialog(title,new TextBlock{Text=text,TextWrapping=TextWrapping.Wrap},"OK");
 async Task<string?> Dialog(string title,Control content,params string[] choices){var w=new Window{Background=new SolidColorBrush(Color.Parse(ActualThemeVariant==ThemeVariant.Dark?"#20242c":"#f5f6f8")),Title=title,Width=560,SizeToContent=SizeToContent.Height,MaxHeight=800,WindowStartupLocation=WindowStartupLocation.CenterOwner};var panel=new StackPanel{Spacing=14,Margin=new Thickness(20)};panel.Children.Add(content);var buttons=new WrapPanel{HorizontalAlignment=HorizontalAlignment.Right};foreach(var choice in choices){var b=new Button{Content=choice,Margin=new Thickness(4)};b.Click+=(_,_)=>w.Close(choice);buttons.Children.Add(b);}panel.Children.Add(buttons);w.Content=new ScrollViewer{Content=panel};return await w.ShowDialog<string?>(this);}
}
