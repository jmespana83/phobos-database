using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Media.Imaging;
using Phobos.Studio.Core;
namespace Phobos.Studio;
internal static class StudioEvidence {
 public static async Task Run(MainWindow window,string directory){
#if STUDIO_VALIDATION
  try{
   Directory.CreateDirectory(directory);var desktop=(IClassicDesktopStyleApplicationLifetime)Application.Current!.ApplicationLifetime!;
   async Task CaptureDialog(Task task,string name,string? choice=null){await Task.Delay(200);var dialog=desktop.Windows.Single(w=>w!=window);Save(dialog,Path.Combine(directory,name));dialog.Close(choice);await task;}
   if(Environment.GetCommandLineArgs()[1]=="--evidence-service"){await CaptureDialog(window.EvidenceAdministration(),"local-service-status.png");return;}
   Console.InputEncoding=new System.Text.UTF8Encoding(false);string secret=await Console.In.ReadLineAsync()??throw new Exception("Missing stdin credential.");int port=int.Parse(Environment.GetCommandLineArgs()[3]);
   await CaptureDialog(window.EvidenceConnectionDialog(),"connection-dialog.png","Cancel");
   await window.EvidenceConnect(new Profile("Studio validation","127.0.0.1",port,"admin"),secret);window.EvidenceExpand();await Task.Delay(200);Save(window,Path.Combine(directory,"object-explorer.png"));
   await window.EvidenceKeyboard();await window.EvidenceSelectedSql();await window.EvidenceUnsavedCancel();
   await window.EvidenceQuery("SELECT id, display_name, score, missing, day, stamp, amount\nFROM studio_types;\n");window.EvidenceExpand();await Task.Delay(200);Save(window,Path.Combine(directory,"results.png"));
   var first=window.EvidencePane;await window.EvidenceQuery("BEGIN; UPDATE studio_types SET score=99 WHERE id=1; SELECT score FROM studio_types;");
   if(first.Results.Single().Rows[0].Cells[0].Text!="99")throw new Exception("First tab transaction missing.");
   var second=window.EvidenceNew();await window.EvidenceConnect(new Profile("Independent second tab","127.0.0.1",port,"admin"),secret);
   await window.EvidenceQuery("SELECT score FROM studio_types; SELECT display_name FROM studio_types;");
   if(second.Results.Count!=2||second.Results[0].Rows[0].Cells[0].Text!="2.5"||first.Results[0].Rows[0].Cells[0].Text!="99")throw new Exception("GUI sessions/results not isolated.");
   await Task.Delay(150);Save(window,Path.Combine(directory,"independent-tabs.png"));window.EvidenceSelect(first);await window.EvidenceQuery("ROLLBACK;");window.EvidenceSelect(second);
   var batchGate=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);second.EvidenceBatchPause=()=>batchGate.Task;
   var streaming=window.EvidenceQuery("SELECT * FROM large_v2;");
   for(int n=0;n<1000&&!streaming.IsCompleted&&second.Results.FirstOrDefault()?.Rows.Count is not >0;n++)await Task.Delay(5);
   if(streaming.IsCompleted||second.Results.FirstOrDefault()?.Rows.Count is not >0)throw new Exception("No incremental GUI rows observed.");
   await Task.Delay(200);Save(window,Path.Combine(directory,"incremental-incomplete.png"));window.EvidenceSelect(first);await window.EvidenceQuery("SELECT id FROM studio_types;");if(!second.Busy||first.Results.Single().Rows.Count!=1)throw new Exception("Independent tab execution during streaming failed.");window.EvidenceSelect(second);batchGate.SetResult();await streaming;
   if(second.Results.Single().Rows.Count!=50000||!second.Results.Single().Complete)throw new Exception("50K GUI result incomplete.");
   await Task.Delay(150);Save(window,Path.Combine(directory,"50k-results.png"));await CaptureDialog(window.EvidenceExportDialog(),"export-workflow.png","Cancel");await CaptureDialog(window.EvidenceProfiles(),"profile-manager.png","Close");
   second.Editor.Text="SELECT studio_types.";second.Editor.CaretOffset=second.Editor.Text.Length;await CaptureDialog(window.EvidenceComplete(),"autocomplete.png","Cancel");
   window.EvidenceTheme();await Task.Delay(100);Save(window,Path.Combine(directory,"light-theme.png"));window.EvidenceTheme();await Task.Delay(100);Save(window,Path.Combine(directory,"dark-theme.png"));
   window.EvidenceSystemTheme();await Task.Delay(100);Save(window,Path.Combine(directory,"system-theme.png"));
   foreach(double scale in new[]{1.0,1.25,1.5,2.0})SaveScale(window,Path.Combine(directory,$"render-scale-{scale}.png"),scale);
   await window.EvidenceQuery("SELECT id FROM studio_types; SELECT * FROM table_that_does_not_exist; SELECT * FROM large_v2;");
   if(!second.Session.Connected||second.Results.Count!=1||second.Previous.Count!=1||!second.Messages.Text!.Contains("Later statements were not sent"))throw new Exception("GUI script failure/result preservation missing.");
   await Task.Delay(200);Save(window,Path.Combine(directory,"error-messages.png"));await window.EvidenceQuery("SELECT 1;");
   if(!second.Session.Connected||second.Results.Single().Rows[0].Cells[0].Text!="1")throw new Exception("Valid SQL after GUI error required reconnect.");
   foreach(var bad in new[]{"INSERT INTO customers_hotfix(name) VALUES ('')","INSERT INTO orders_hotfix VALUES (2,999)","INSERT INTO customers_hotfix VALUES (1,'duplicate')","CREATE TABLE customers_hotfix(id BIGINT)","SELECT * FROM missing_hotfix","SELECT missing_column FROM customers_hotfix","SELEC 1"}) {
    await window.EvidenceQuery(bad);
    if(!second.Session.Connected||string.IsNullOrWhiteSpace(second.Messages.Text)||second.State=="Disconnected")throw new Exception("Recoverable GUI error disconnected or lost its message.");
    await Task.Delay(200);
    if(second.Messages.Bounds.Height<20||second.Messages.Bounds.Width<100)throw new Exception("Messages text control is not laid out visibly.");
    Save(window,Path.Combine(directory,"hotfix-error-"+Array.IndexOf(new[]{"INSERT INTO customers_hotfix(name) VALUES ('')","INSERT INTO orders_hotfix VALUES (2,999)","INSERT INTO customers_hotfix VALUES (1,'duplicate')","CREATE TABLE customers_hotfix(id BIGINT)","SELECT * FROM missing_hotfix","SELECT missing_column FROM customers_hotfix","SELEC 1"},bad)+".png"));
    await window.EvidenceQuery("SELECT 1;");
    if(!second.Session.Connected||second.Results.Single().Rows[0].Cells[0].Text!="1")throw new Exception("Same-tab SQL recovery failed.");
   }
   await window.EvidenceQuery("BEGIN;");await window.EvidenceQuery("INSERT INTO orders_hotfix VALUES (2,999);");
   if(!second.Session.Connected||!second.Messages.Text!.Contains("ROLLBACK"))throw new Exception("Explicit transaction guidance missing.");
   await window.EvidenceQuery("ROLLBACK;");await window.EvidenceQuery("SELECT 1;");
   await window.EvidenceQuery("SELECT * FROM large_v2; SELECT id FROM studio_types;");
   if(second.Results.Count!=1||!second.Results[0].Complete||!second.Session.Connected)throw new Exception("Completed result changed to incomplete on later script budget stop.");secret="";
   second.Limits=new(300,32,120);await window.EvidenceQuery("SELECT * FROM large_v2;");
   if(second.Session.Connected||second.Results.Single().Complete||second.Results.Single().Rows.Count==0)throw new Exception("GUI partial result incorrectly complete.");
   second.Output.SelectedItem=second.Results.Single().Tab;await Task.Delay(200);Save(window,Path.Combine(directory,"budget-incomplete.png"));
   File.WriteAllText(Path.Combine(directory,"gui-evidence.log"),$"Actual window RenderScaling: {window.RenderScaling}\nPASS actual Avalonia: connection dialog, catalog, selected SQL, unsaved-close Cancel, independent GUI transactions and results, multi-result scripts, progressive 50K grid, previous results after failure, recoverable SQL errors without reconnect, explicit transaction rollback, incomplete budget, profile/export/completion dialogs, routed F5/Ctrl+Enter, light/dark/system. Render scaling 1/1.25/1.5/2 is raster qualification, not OS DPI switching.\n");
  }catch(Exception e){File.WriteAllText(Path.Combine(directory,"gui-failure.log"),e.ToString());Environment.ExitCode=1;}finally{window.EvidenceClose();}
#else
  await Task.CompletedTask;
#endif
 }
#if STUDIO_VALIDATION
 static void Save(Window w,string path)=>SaveScale(w,path,1);
 static void SaveScale(Window w,string path,double scale){using var bitmap=new RenderTargetBitmap(new PixelSize(Math.Max(1,(int)(w.Bounds.Width*scale)),Math.Max(1,(int)(w.Bounds.Height*scale))),new Vector(96*scale,96*scale));bitmap.Render(w);bitmap.Save(path);}
#endif
}
