using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml.Styling;
using Avalonia.Themes.Fluent;
namespace Phobos.Studio;
internal static class Program {
    [STAThread] public static void Main(string[] args){if(args.Length>0&&args[0]=="--service-action"){Environment.Exit(WindowsInstances.AdminAction(args));return;}BuildApp().StartWithClassicDesktopLifetime(args);}
    public static AppBuilder BuildApp()=>AppBuilder.Configure<App>().UsePlatformDetect().LogToTrace();
}
public sealed class App:Application {
    public override void Initialize(){Styles.Add(new FluentTheme());Styles.Add(new StyleInclude(new Uri("avares://PHOBOS-Studio")){Source=new Uri("avares://Avalonia.Controls.DataGrid/Themes/Fluent.xaml")});Styles.Add(new StyleInclude(new Uri("avares://PHOBOS-Studio")){Source=new Uri("avares://AvaloniaEdit/Themes/Fluent/AvaloniaEdit.xaml")});RequestedThemeVariant=Avalonia.Styling.ThemeVariant.Dark;}
    public override void OnFrameworkInitializationCompleted(){if(ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)desktop.MainWindow=new MainWindow();base.OnFrameworkInitializationCompleted();}
}
