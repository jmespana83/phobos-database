using System.Xml;
using AvaloniaEdit.Highlighting;
using AvaloniaEdit.Highlighting.Xshd;
namespace Phobos.Studio;
internal static class SqlHighlighting {
 public static IHighlightingDefinition Create()=>HighlightingLoader.Load(XmlReader.Create(new StringReader("""
<SyntaxDefinition name="PHOBOS SQL" xmlns="http://icsharpcode.net/sharpdevelop/syntaxdefinition/2008">
 <Color name="Keyword" foreground="#418AD4" fontWeight="bold"/>
 <Color name="String" foreground="#B47735"/>
 <Color name="Comment" foreground="#68915A" fontStyle="italic"/>
 <Color name="Number" foreground="#AD65AD"/>
 <RuleSet ignoreCase="true">
  <Span color="Comment" begin="--"/>
  <Span color="Comment" multiline="true" begin="/\*" end="\*/"/>
  <Span color="String" multiline="true" begin="'" end="'"><RuleSet><Span begin="''" end=""/></RuleSet></Span>
  <Span color="String" multiline="true" begin="&quot;" end="&quot;"><RuleSet><Span begin="&quot;&quot;" end=""/></RuleSet></Span>
  <Keywords color="Keyword"><Word>SELECT</Word><Word>INSERT</Word><Word>UPDATE</Word><Word>DELETE</Word><Word>CREATE</Word><Word>ALTER</Word><Word>INDEX</Word><Word>UNIQUE</Word><Word>TABLE</Word><Word>FROM</Word><Word>WHERE</Word><Word>JOIN</Word><Word>LEFT</Word><Word>INNER</Word><Word>CROSS</Word><Word>ON</Word><Word>GROUP</Word><Word>BY</Word><Word>ORDER</Word><Word>HAVING</Word><Word>LIMIT</Word><Word>OFFSET</Word><Word>WITH</Word><Word>EXISTS</Word><Word>BEGIN</Word><Word>COMMIT</Word><Word>ROLLBACK</Word><Word>SHOW</Word><Word>CATALOG</Word><Word>NULL</Word><Word>TRUE</Word><Word>FALSE</Word><Word>VALUES</Word><Word>SET</Word><Word>AS</Word><Word>AND</Word><Word>OR</Word><Word>NOT</Word><Word>INTO</Word></Keywords>
  <Rule color="Number">\b\d+(\.\d+)?([eE][+-]?\d+)?\b</Rule>
 </RuleSet>
</SyntaxDefinition>
""")),HighlightingManager.Instance);
}
