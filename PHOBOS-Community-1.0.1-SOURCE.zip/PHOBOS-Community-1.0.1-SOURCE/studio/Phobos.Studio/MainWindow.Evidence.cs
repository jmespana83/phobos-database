using Avalonia;
using Avalonia.Controls;
using Phobos.Studio.Core;
namespace Phobos.Studio;
public sealed partial class MainWindow {
 internal QueryPane EvidencePane=>Active;
 internal QueryPane EvidenceNew()=>NewQuery(profile:Active.PreferredProfile);
 internal void EvidenceSelect(QueryPane p)=>editors.SelectedItem=p.Owner;
 internal Task EvidenceProfiles()=>Profiles();
 internal Task EvidenceExportDialog()=>Export(Active);
 internal Task EvidenceComplete()=>Complete();
 internal async Task EvidenceConnect(Profile profile,string password){var p=Active;await Task.Run(()=>p.Session.ConnectAsync(profile,password));p.PreferredProfile=profile;p.SetState("Ready");await RefreshCore(p);UpdateState();}
 internal async Task EvidenceQuery(string sql){Active.Editor.Text=sql;await Execute();}
 internal Task EvidenceAdministration()=>Administration();
 internal Task EvidenceConnectionDialog()=>Connect();
 internal Task EvidenceNotice(string title,string text)=>Notice(title,text);
 internal void EvidenceClose(){closing=true;foreach(var p in Panes)p.Dispose();Close();}
 internal void EvidenceMessage(string text)=>Active.Log(text,true);
 internal async Task EvidenceSelectedSql(){var editor=Active.Editor;editor.Text="INVALID PREFIX\nSELECT id FROM studio_types;";editor.Select(15,editor.Text.Length-15);await Execute();if(Active.Results.Single().Rows.Count!=1)throw new Exception("Selected SQL failed.");editor.Select(0,0);}
 internal async Task EvidenceUnsavedCancel(){int count=tabs.Count;var before=Active;var p=NewQuery("-- modified SQL");var close=CloseTab();await Task.Delay(200);var desktop=(Avalonia.Controls.ApplicationLifetimes.IClassicDesktopStyleApplicationLifetime)Application.Current!.ApplicationLifetime!;var prompt=desktop.Windows.Single(w=>w!=this);if(prompt.Title!="Unsaved SQL")throw new Exception("Unsaved warning missing.");prompt.Close("Cancel");await close;if(tabs.Count!=count+1)throw new Exception("Cancel discarded tab.");p.Dispose();tabs.Remove(p.Owner);EvidenceSelect(before);}
 internal async Task EvidenceKeyboard(){foreach(var key in new[]{Avalonia.Input.Key.F5,Avalonia.Input.Key.Enter}){Active.Editor.Text="SELECT id FROM studio_types;";RaiseEvent(new Avalonia.Input.KeyEventArgs{RoutedEvent=Avalonia.Input.InputElement.KeyDownEvent,Key=key,KeyModifiers=key==Avalonia.Input.Key.Enter?Avalonia.Input.KeyModifiers.Control:Avalonia.Input.KeyModifiers.None});for(int n=0;n<1000&&Active.Busy;n++)await Task.Delay(10);if(Active.Busy||Active.Results.Single().Rows.Count!=1)throw new Exception("Keyboard execute failed.");}}
 internal void EvidenceSystemTheme()=>ApplyTheme("System");
 internal void EvidenceTheme()=>ApplyTheme(theme=="Light"?"Dark":"Light");
 internal void EvidenceExpand(){void Expand(TreeViewItem n){n.IsExpanded=true;if(n.ItemsSource is IEnumerable<TreeViewItem> children)foreach(var c in children)Expand(c);}if(explorer.ItemsSource is IEnumerable<TreeViewItem> roots)foreach(var r in roots)Expand(r);}
}
