using System.Collections.ObjectModel;
using System.Diagnostics;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Media;
using AvaloniaEdit;
using AvaloniaEdit.Highlighting;
using Phobos.Studio.Core;

namespace Phobos.Studio;

public sealed class ResultRow(Cell[] cells) {
    public Cell[] Cells {get;}=cells;
    public string[] Text {get;}=cells.Select(c=>c.Text).ToArray();
}
public sealed class ResultView {
    public string[] Columns {get;}
    public ObservableCollection<ResultRow> Rows {get;}=[];
    public DataGrid Grid {get;}=new(){IsReadOnly=true,AutoGenerateColumns=false,SelectionMode=DataGridSelectionMode.Extended,GridLinesVisibility=DataGridGridLinesVisibility.All};
    public TabItem Tab {get;}=new();
    public bool Complete {get;private set;}
    readonly int number;
    public ResultView(string[] columns,int number,Action<string> inspect){
        Columns=columns;this.number=number;Tab.Content=Grid;Tab.Header=$"Result {number} · Receiving (Incomplete)";Grid.ItemsSource=Rows;
        for(int n=0;n<columns.Length;n++)Grid.Columns.Add(new DataGridTextColumn{Header=columns[n],Binding=new Binding($"Text[{n}]"),Width=new DataGridLength(150)});
        void Selected(){if(Grid.SelectedItem is ResultRow row && Grid.CurrentColumn!=null){int index=Grid.Columns.IndexOf(Grid.CurrentColumn);if(index>=0&&index<row.Cells.Length)inspect(row.Cells[index].Kind+" • "+row.Cells[index].Text);}}
        Grid.SelectionChanged+=(_,_)=>Selected();Grid.CurrentCellChanged+=(_,_)=>Selected();
    }
    public void Finish(bool success){Complete=success;Tab.Header=$"Result {number} · {(success?"Complete":"Incomplete")} · {Rows.Count:N0} rows";}
}

public sealed class QueryPane:Grid,IDisposable {
    public int Number {get;set;}
    public StudioSession Session {get;}=new();
    public SqlDocument Document {get;set;}=new();
    public TextEditor Editor {get;}=new(){ShowLineNumbers=true,FontFamily=FontFamily.Parse("Cascadia Code,Consolas,monospace"),FontSize=14,Margin=new Thickness(6)};
    public TextBox Messages {get;}=new(){IsReadOnly=true,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,FontFamily=FontFamily.Parse("Consolas,monospace")};
    readonly TabItem messagesTab;
    public TabControl Output {get;}=new(); public ObservableCollection<TabItem> OutputTabs {get;}=[];
    public TextBlock Inspector {get;}=new(){Text="Select a cell for its full value and type. NULL: ⟨NULL⟩.",Margin=new Thickness(6),MaxHeight=70,TextWrapping=TextWrapping.Wrap};
    public TextBlock Progress {get;}=new(){Text="Disconnected",Margin=new Thickness(8,4),FontWeight=FontWeight.Bold};
    public List<ResultView> Results {get;set;}=[];
    public List<ResultView> Previous {get;set;}=[];
    public List<string> History {get;}=[];
    public Dictionary<string,List<Dictionary<string,string>>> Catalog {get;set;}=[];
    public Profile? PreferredProfile {get;set;}
    public QueryLimits Limits {get;set;}=new();
    internal Func<Task>? EvidenceBatchPause {get;set;}
    public bool Cancelling {get;set;}
    public bool Busy {get;set;} public bool CancelRequested {get;set;}
    public string State {get;set;}="Disconnected";
    public Stopwatch Watch {get;}=new();
    public TabItem Owner {get;set;}=null!;
    public ResultView? CurrentResult=>Results.Concat(Previous).FirstOrDefault(r=>ReferenceEquals(r.Tab,Output.SelectedItem));
    public QueryPane(Func<string,Task> copy,Func<Task> export){
        RowDefinitions=new RowDefinitions("1*,5,1*");Children.Add(Editor);Children.Add(new GridSplitter{Height=5,HorizontalAlignment=HorizontalAlignment.Stretch});SetRow(Children[^1],1);
        var bottom=new DockPanel();SetRow(bottom,2);Children.Add(bottom);var bar=new WrapPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(4)};
        foreach(var (label,action) in new[]{("Copy cell","cell"),("Copy selected rows","selected"),("Copy all (TSV)","all"),("Copy CSV","csv")}){var b=new Button{Content=label};b.Click+=async(_,_)=>await copy(action);bar.Children.Add(b);}
        var save=new Button{Content="Export…"};save.Click+=async(_,_)=>await export();bar.Children.Add(save);DockPanel.SetDock(bar,Dock.Top);bottom.Children.Add(bar);DockPanel.SetDock(Progress,Dock.Top);bottom.Children.Add(Progress);DockPanel.SetDock(Inspector,Dock.Bottom);bottom.Children.Add(Inspector);bottom.Children.Add(Output);
        messagesTab=new TabItem{Header="Messages",Content=Messages};Output.ItemsSource=OutputTabs;OutputTabs.Add(messagesTab);
        Editor.SyntaxHighlighting=SqlHighlighting.Create();
    }
    public void BeginResults(){var complete=Results.Where(r=>r.Complete).ToList();if(complete.Count>0)Previous=complete;Results=[];for(int n=OutputTabs.Count-1;n>=0;n--)if(!ReferenceEquals(OutputTabs[n],messagesTab))OutputTabs.RemoveAt(n);Output.SelectedItem=messagesTab;}
    public ResultView AddResult(string[] columns,int number){var view=new ResultView(columns,number,text=>Inspector.Text=text);Results.Add(view);OutputTabs.Insert(OutputTabs.Count-1,view.Tab);Output.SelectedItem=view.Tab;return view;}
    public void PreservePrevious(){foreach(var r in Previous){r.Tab.Header="Previous completed · "+r.Rows.Count+" rows";OutputTabs.Insert(OutputTabs.Count-1,r.Tab);}}
    public void Log(string message,bool select=false){Messages.Text=(Messages.Text+"\n"+message).TrimStart();if(Messages.Text.Length>64000)Messages.Text=Messages.Text[^64000..];Messages.CaretIndex=Messages.Text.Length;if(select)Output.SelectedItem=messagesTab;}
    public void SetState(string state){State=state;Progress.Text=$"{state}{(Session.Connected&&Session.TransactionActive?" • Transaction open":"")} • {Watch.Elapsed.TotalMilliseconds:N0} ms";Owner.Header=(Document.Path==null?$"Query {Number}{(Document.Modified?" *":"")}":Document.Title)+(Busy?" • ●":"")+(!Session.Connected?" · disconnected":"");}
    public void Dispose()=>Session.Dispose();
}
