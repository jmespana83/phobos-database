using System.Diagnostics;
using System.ServiceProcess;
using Microsoft.Win32;
namespace Phobos.Studio;

public sealed record LocalInstance(string Key,string Service,string Host,int Port,string Version,string Manifest,string Logs);
public interface ILocalInstances {Task<List<LocalInstance>> DiscoverAsync();Task<string> StatusAsync(LocalInstance i);Task ActAsync(LocalInstance i,string action);}
public sealed class NoLocalInstances:ILocalInstances {
    public Task<List<LocalInstance>> DiscoverAsync()=>Task.FromResult(new List<LocalInstance>());
    public Task<string> StatusAsync(LocalInstance i)=>Task.FromResult("Local administration unavailable on this platform.");
    public Task ActAsync(LocalInstance i,string action)=>Task.FromException(new PlatformNotSupportedException());
}
// This is the only OS-specific production component. Queries never enter it.
public sealed class WindowsInstances:ILocalInstances {
    const string Root=@"SOFTWARE\PHOBOS\Instances";
    public Task<List<LocalInstance>> DiscoverAsync()=>Task.Run(()=>{
        var found=new List<LocalInstance>();if(!OperatingSystem.IsWindows())return found;
        using var hklm=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64);using var root=hklm.OpenSubKey(Root);if(root==null)return found;
        foreach(var name in root.GetSubKeyNames()){using var k=root.OpenSubKey(name);if(k==null)continue;string S(string field)=>k.GetValue(field)?.ToString()??"";
            if(int.TryParse(S("Port"),out int port)&&port is >0 and <=65535)found.Add(new(name,S("ServiceName"),S("Host"),port,S("ProductVersion"),S("Manifest"),S("LogDirectory")));}
        return found;
    });
    public Task<string> StatusAsync(LocalInstance i)=>Task.Run(()=>{if(!OperatingSystem.IsWindows())return "Unavailable";using var s=new ServiceController(i.Service);return s.Status.ToString();});
    public async Task ActAsync(LocalInstance i,string action){if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException();var info=new ProcessStartInfo(Environment.ProcessPath!){UseShellExecute=true,Verb="runas",WindowStyle=ProcessWindowStyle.Hidden};info.ArgumentList.Add("--service-action");info.ArgumentList.Add(i.Key);info.ArgumentList.Add(action);using var p=Process.Start(info)??throw new IOException("Could not launch administration helper.");await p.WaitForExitAsync();if(p.ExitCode!=0)throw new IOException($"Local administration failed or was cancelled (code {p.ExitCode}). Inspect service status/logs.");}
    public static int AdminAction(string[] args){try {
        if(!OperatingSystem.IsWindows()||args.Length!=3||args[2] is not("start" or "stop" or "restart"))return 2;
        var i=new WindowsInstances().DiscoverAsync().GetAwaiter().GetResult().Single(x=>x.Key==args[1]);
        // Resolve service only from administrator-owned HKLM; never accept arbitrary service names/commands.
        using var s=new ServiceController(i.Service);
        if(args[2] is "stop" or "restart"){if(s.Status!=ServiceControllerStatus.Stopped){s.Stop();s.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromMinutes(10));}}
        if(args[2] is "start" or "restart"){s.Refresh();if(s.Status!=ServiceControllerStatus.Running){s.Start();s.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromMinutes(3));}}
        return 0;
    }catch{return 1;}}
}
