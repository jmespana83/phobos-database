# PHOBOS 0.3-B test results — October 23, 2026

This unsigned Windows installer/service foundation candidate passed the final elevated install/repair/recovery/uninstall cycle at 13:25 America/New_York on October 23. Final local boundary tests and installer builds also passed. Broad production qualification remains outside this milestone.

## Provenance / environment

- Accepted 0.3-A archive SHA-256: `c9907590f1003f7ee99c5e3fabb30c9de106b778d146fcba23414b8849ce4911`.
- All 194 files under core crates plus root build/toolchain manifests remain byte-identical. All three engine executables match the 0.3-A measured release manifest; no new engine tests are being substituted for code changes because there are no engine changes.
- Windows x64 host, .NET Framework compiler, Inno Setup 6.7.3. Engine binaries: recorded Rust 1.98.1 release builds. Vendor compiler/prerequisite signatures verified. PHOBOS artifacts are unsigned.
- Engineering began around 12:30 America/New_York, October 23. Work was bounded by the requested two-hour maximum.

## Completed elevated tests (initial integration build)

Evidence: `evidence-03b/elevated-validation.log`.

| Scenario | Observed result |
|---|---|
| Inno silent files-only install in custom protected binary path | Passed |
| Custom data directory containing a space, custom port, generated administrator credentials | Passed |
| Occupied port before initialization | Rejected without creating metadata/data or killing the owner |
| Real SCM service registration / automatic LocalService configuration / start | Passed |
| Owned listener, protocol handshake, administrator authentication, catalog API v1 | Passed |
| Wrong administrator password | Rejected |
| Create table, unique index, inserts and SELECT | Passed |
| SCM stop / graceful drain / listener release | Passed |
| Offline integrity | Passed |
| Stale shutdown marker / restart / row survival | Passed |
| Same-version installer repair/reinstall | Passed |
| Row/index query and catalog survival after repair | Passed |
| Authentication file preserved byte-for-byte | Passed |
| Post-repair integrity | Passed |
| Protected data/config/log/control ACL inheritance, no Users/Everyone ACE | Passed |
| Scan all instance artifacts for plaintext secret | **Harness failed** when reading a locked index while the server was running |
| Uninstall / service deletion / binary removal / retained-data verification | **Not reached** in this run |

## Final elevated qualification

Evidence: `evidence-03b/elevated-final/installer-validation.log`, service configuration and service logs. The corrected harness stops the server before scanning artifacts. The final hardened packaging passed all initial scenarios above, plus:

- Invalid runtime configuration rejected at service startup; recovery after restoring configuration preserved rows.
- Deliberate service-host crash left no orphan listener; restart/WAL recovery preserved committed rows.
- No generated plaintext administrator password found in closed instance artifacts and service logs.
- Actual installer uninstall stopped the running service, removed its SCM registration and server binary, and retained data/auth/config.

The initial scan failure was a harness defect, corrected before this successful run. The initial test installation was also removed while preserving its data. Final artifact repackaging updates documentation only; tested executable bytes remain unchanged. `elevated-final/tested-build.json` records the tested installer and runtime hashes.

## Final local tests

Evidence: `evidence-03b/local-final.log`, `build.log`, core verification output, and rendered setup/repair dialogs.

- Configuration self-tests: invalid password lengths/line breaks, nonlocal/root/noncanonical paths, invalid ports, remote bind, overlapping directories.
- Installer helper compilation with warnings treated as errors; Inno installer compilation.
- Secure stdin initialization/authentication using a generated Unicode password; no credential argv/environment/response file.
- Owned-listener readiness, stale-marker removal, handshake and authenticated API v1 discovery.
- Tiny installation create/insert/select transaction followed by rollback, with no leftover catalog table.
- 0.3-A CTE execution through the native public-protocol probe.
- Graceful direct launcher drain, restart, committed-row survival and offline integrity.
- Native Windows job-object crash containment and subsequent WAL recovery/committed-row survival.
- Oversized protocol response rejected before allocating its advertised payload.
- Retained local instance artifacts scanned after shutdown: generated password not present in plaintext.
- Configuration dialog rendered and visually checked at the host's default DPI. No full accessibility/high-DPI qualification is claimed.

The default-path values were inspected in the rendered dialog; an actual default-path GUI installation is not claimed. The first real installation used a custom protected Program Files path and ProgramData test directories.

## Performance

No engine source or binary changed, no TCP proxy or query IPC layer was introduced, and no reclaim/performance campaign was restarted. The final wrapper uses normal durable server flags and inherits engine defaults, with worker count recorded as processor count clamped to 1–16. The final elevated run measured 1,000 indexed reads: service-hosted mean 0.063234 ms, direct mean 0.060124 ms (about 5.2% / 0.003110 ms higher). This single short sample is insufficient to establish a meaningful regression. It is not a Standard benchmark; the full Standard suite was not rerun. No measured performance-equivalence claim is made. The 0.3-A Standard evidence remains historical reference material, not a 0.3-B certification run.

## Untested / deferred matrix

Actual machine reboot/preshutdown, full GUI click-through, clean VM without the Microsoft runtime, prerequisite reboot branch, interrupted file replacement/rollback, deliberate service-registration failure, exhaustive permission-denial permutations, full cross-version upgrades, Windows ARM64/x86, Linux/macOS packaging and long-duration logs remain unqualified. Remote binding/firewall creation and destructive uninstall are deliberately not implemented. Default behavior retains all data and creates no firewall rule.

## Test cleanup

Both isolated services (`PHOBOSValidation03B` and `PHOBOSValidation03B2`) and their installed server binaries were removed. A separate SCM enumeration confirmed both services absent. No user primary database was selected or deleted.

Retained test instances: `C:\ProgramData\PHOBOS-03B-Validation` and `C:\ProgramData\PHOBOS-03B-Validation2`. These retain test data/auth/config/logs; generated test passwords were not retained separately. No database directory was deleted. The test runner refuses existing paths; any future repetition must select fresh dedicated paths using its suffix parameter.
