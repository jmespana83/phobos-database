# PHOBOS Community Edition 1.0.1 — Replication

The existing base-backup/slot/WAL receive/replay architecture is retained:

```text
phobos-admin replication-init PRIMARY_DATA BASE_BACKUP NEW_STANDBY SLOT
phobos-admin replication-receive PRIMARY_DATA STANDBY
phobos-admin replication-replay STANDBY
phobos-admin replication-status PRIMARY_DATA STANDBY
phobos-admin check STANDBY
```

Tools require accessible paths, matching system identity and compatible formats. Stop the standby server before offline replay; ownership exclusion prevents replay while serving. Replay is idempotent and rejects gaps/corruption. Monitor retained WAL and space; dropping a slot can require a fresh replica base image. Identity/FK/view changes use ordinary WAL. This is not a network replication daemon, multi-master, automatic promotion/failover or topology GUI.

Create BASE_BACKUP with phobos-admin backup-base on the stopped primary. An ordinary offline backup lacks the required end-LSN marker. Retention must be established before resuming writes.
