# PHOBOS 0.3-E — final report

**Delivered as an experimental candidate. Promotion is held for unresolved write-performance results. The accepted 0.3-D product / 0.3-A engine remains unchanged.** All implemented feature semantics, recovery/integrity gates and compatibility tests passed. The scope is a coherent durable schema subset, not general enterprise SQL completion.

1. **Exact baseline and hash.** `C:\Users\195doctor\Documents\Codex\2026-10-26\outputs\PHOBOS-Community-0.3-D-ManagementStudioV2-SOURCE.zip`; SHA-256 `9b8411867080d6c8335b9ad1c6c829360980bb7fd94689ad93662c4f14aa057f`. All work began under the requested October 26 root. Prior deliverables were not overwritten.
2. **Implemented.** Durable typed schema definitions; literal column DEFAULT; restricted row CHECK; inline/composite PRIMARY KEY; transactional ALTER COLUMN SET/DROP DEFAULT; rename preservation; bulk enforcement; additive catalog metadata and integrity validation.
3. **Deferred.** Identity/sequences, foreign keys, physical ALTER, persistent views, INSERT SELECT, RETURNING, correlated subqueries, set operations, window functions, temporary tables, SELECT without FROM, new physical types and time-dependent/default functions. Unsupported syntax/expressions are rejected, not ignored.
4. **Catalog changes.** PHOC v4 extension in catalog.phc, with stable table-ID and column-ordinal definitions and primary-index references. v1/v2/v3 remain readable. Only successful new-definition DDL adopts v4. Unknown versions fail closed. Downgrade requires a pre-upgrade backup. Full encoding is in CATALOG-FORMAT.
5. **WAL/page changes.** None. Existing metadata WAL images and atomic publication carry new catalog bytes. Heap, index, tuple, WAL framing and index catalog formats remain unchanged.
6. **Management API.** Version 1, additive columns/rows. COLUMNS appends has_default/default_expression; CONSTRAINTS appends definition and distinguishes PRIMARY KEY/CHECK. CAPABILITIES reports server_version=0.3-E. The unchanged 0.3-D client passes integration; SQL/catalog remain usable, while its conservative object-template whitelist disables templates for this new engine version.
7. **DEFAULT semantics.** Literals with optional numeric negation and existing type coercions. Omitted INSERT column-list fields receive defaults; explicit NULL remains NULL, and explicit values override them. DDL validates types/nullability. No CURRENT_TIMESTAMP or arbitrary expressions. Definitions survive rollback/restart/restore/replay.
8. **CHECK semantics.** Column-to-literal comparison (=, <>, <, <=, >, >=), or column IS [NOT] NULL. Multiple clauses are conjunctive. Only FALSE rejects; UNKNOWN passes. INSERT/UPDATE/bulk enforce checks atomically. Exact BIGINT/DOUBLE comparison boundaries are preserved. Named constraints and arbitrary expression trees remain unsupported.
9. **Primary keys.** One inline or composite declaration on CREATE TABLE. Key columns are NOT NULL; existing unique-index ownership and canonical comparison enforce uniqueness under concurrent inserts. One generated index backs the new table's key. Independent deletion of that index is rejected. Metadata survives rename/restart.
10. **Identity/sequences.** Deferred; no MAX+1 or non-durable allocator.
11. **Foreign keys.** Deferred; no single-session-only or unenforced FK support.
12. **ALTER TABLE.** Existing table/column rename plus SET/DROP DEFAULT. Transactional, no stored-row rewrite. Add/drop columns, nullability/type changes and add/drop constraints are deferred. Definitions on partitioned tables are rejected in this release.
13. **Views.** Persistent views deferred; inherited query-local CTE/derived inputs remain available.
14. **INSERT SELECT.** Deferred.
15. **RETURNING.** Deferred.
16. **Correlated subqueries.** Deferred; inherited uncorrelated support preserved.
17. **Set operations.** Deferred.
18. **Window functions.** Deferred.
19. **Temporary tables.** Deferred; no orphan/session-lifecycle workaround.
20. **Transactions/concurrency.** Full workspace: 608 top-level tests pass, zero fail, four inherited ignored tests. Eleven new focused tests pass. Includes schema/data COMMIT/ROLLBACK, own writes, atomic multi-row failure, conflicting same-key clients, and existing schema-lease retry behavior. The milestone does not add online DDL.
21. **Crash/recovery.** Six actual process-exit commit/publication boundaries pass, with two reopen/replay checks per boundary. Durable outcomes retain all definitions and rows; pre-durability outcomes are valid old/new states. Final release-binary forced-restart smoke passes.
22. **Backup/restore/PITR/replication.** All new durable metadata kinds covered by online backup/online-PITR restore, offline backup/restore, PITR at CREATE and ALTER-default boundaries, physical standby receive/replay and repeated replay. Restored queries, metadata and enforcement pass.
23. **Integrity.** Catalog references/types/operators/PK backing are validated. Online/offline row CHECK validation and inherited index integrity pass. Unknown versions, truncation and valid-checksum semantic corruption are rejected. No semantic auto-repair is introduced.
24. **Standard comparison.** Six unchanged Standard 1.3.1-G56 runs (three matched pairs, final pair reversed); every raw row is ok, zero query errors, all six query hashes match. Fresh-control autocommit median is +5.9%, with pairs +6.6%, -7.6%, +20.8%: flagged and unresolved. Single-transaction timing has a +486% third-pair outlier, retained; aggregate +12.4%. Read medians range -4.2% to +3.3%; OLTP -2.6% to +1.5%. Historical K.5 deficits remain and are also seen in the fresh accepted control. PERFORMANCE includes every value and the investigation limits. **No promotion recommendation until the write gate is resolved.**
25. **Compatibility limits.** Restricted expressions; no named CHECK/PK alteration, DEFAULT VALUES, explicit DEFAULT in VALUES, schema definitions on partitions, or executable schema-script rendering contract. Legacy DDL entry points reject new schema DDL; use the MVCC/server path. Windows was tested; Linux/macOS execution was unavailable. New core code is portable Rust. No installer/GUI update is bundled.
26. **Changed files.** Exact baseline comparison is in PHOBOS-0.3-E-CHANGED-FILES.txt. Core changes are confined to SQL/catalog/execution/admin and permanent tests; tools/docs/evidence are added. 185 protected storage/WAL/transaction/index/protocol/client/server/type/config/auth/Studio/packaging files are byte-identical. All 47 prior 0.3-D output hashes remain valid.
27. **Final hashes.** PHOBOS-0.3-E-FINAL-HASHES.txt is the external SHA-256 manifest for source ZIP, separate Windows validation runtime, documents, handoff and evidence. It deliberately has no self/circular hash. Measured source and binary manifests are retained in evidence-03e. The source/runtime archive hashes are also returned in the delivery message.
28. **Exact reproduction commands.** See the complete TEST-RESULTS and PERFORMANCE command blocks. Core commands from the source root are:

```powershell
$env:AWS_LC_SYS_PREBUILT_NASM='1'
$env:CARGO_TARGET_DIR='C:\Users\195doctor\Documents\Codex\2026-10-26\test03e'
& "$env:USERPROFILE\.cargo\bin\cargo.exe" test --workspace --locked --offline -- --test-threads=4
& "$env:USERPROFILE\.cargo\bin\cargo.exe" clippy --workspace --all-targets --all-features --locked --offline -- -D warnings
& "$env:USERPROFILE\.cargo\bin\cargo.exe" fmt --all -- --check
$env:CARGO_TARGET_DIR='C:\Users\195doctor\Documents\Codex\2026-10-26\target03e'
& "$env:USERPROFILE\.cargo\bin\cargo.exe" +stable build --release --locked --offline
.\tools\enterprise-sql-v2-validation\run.ps1 -Mode Smoke -Binaries "$env:CARGO_TARGET_DIR\release" -WorkRoot 'C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e' -Port 55436
.\tools\enterprise-sql-v2-validation\run.ps1 -Mode Standard -Binaries "$env:CARGO_TARGET_DIR\release" -WorkRoot 'C:\Users\195doctor\Documents\Codex\2026-10-26\validation-03e' -SuiteRoot 'C:\PHOBOS-BENCH-v1.3.2' -Port 55436
```

The measured +stable compiler was 1.98.1, not an unspecified future stable. Fixtures must remain isolated. The source contains a portable Rust test script and the manual Standard `-Suite "<command>"` wrapper.

29. **Recommended 0.3-F scope.** First resolve/accept the 0.3-E write-performance gate. Then durable identity/sequence allocation plus INSERT RETURNING, with concurrency, rollback, crash, PITR and replication semantics. Extend the bound catalog deliberately; add named/richer CHECKs and executable schema scripting as separate documented contracts. Foreign keys require tested parent/child conflict ownership and should not be rushed for syntax coverage.

Deliverables are under `C:\Users\195doctor\Documents\Codex\2026-10-26\outputs`. The updated handoff is in `outputs/0.3-E/PHOBOS-CODEX-HANDOFF.md`, preserving the earlier root handoff. Runtime binaries are explicitly labeled VALIDATION-RUNTIME and are not an installer or deployment action.
