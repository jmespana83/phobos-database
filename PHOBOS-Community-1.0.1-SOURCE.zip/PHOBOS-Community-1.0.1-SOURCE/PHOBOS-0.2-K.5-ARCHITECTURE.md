# PHOBOS 0.2-K.5 — Reclaim Publication V2 / Write Locality Recovery

Date: 2026-10-06. Status: **experimental continuation candidate; performance acceptance FAILED**.

The source is based exclusively on `PHOBOS-Community-0.2-K.4-LazyIndexPruningV1-SOURCE.zip`, verified SHA-256 `cdb243bd37b3ad13b0f9cd93b1cc4054b76f49c14c3b9b548b1484dfeb390086`. K.4 remains the accepted reference. K.5 is a reviewable implementation with measured improvements and explicit remaining failures, not a certified replacement.

## Verdict

Windows quick A/B, medians of three alternating worker ON/OFF rounds, ordinary release build:

| Workload | Worker ON ops/s | Worker OFF ops/s | Gap | Limit | Result | Errors ON/OFF, all rounds |
|---|---:|---:|---:|---:|---|---:|
| OLTP1 | 2017.1 | 2166.6 | 6.90% | 5% | MISS | 0 / 0 |
| OLTP8 | 2805.1 | 3026.1 | 7.30% | 8% | PASS | 0 / 2 |
| OLTP16 | 2187.5 | 2578.5 | 15.16% | 8% | MISS | 0 / 1 |

The three errors were retryable wait-die write conflicts, all with worker OFF. No correctness error was reported by the harness. Gap = `100 * (1 - median(ON)/median(OFF))`; it is not the median of pairwise gaps. These are the included quick harness results, not the frozen Standard suite.

User-supplied authoritative Windows K.4 results remain 4285.9/4828.6, 5074.7/6707.9, and 4149.1/5899.3 ops/s (11.2%, 24.3%, 29.7% gaps). They were measured in another session. The lower absolute K.5 rates cannot be attributed solely to this change. No claim of an absolute throughput win or elimination of reclaim overhead is justified.

## 1. What K.4 was doing

An instrumented K.4 micro run reclaimed 6000 versions, then freed those 6000 slots. Across 1970 changed heap-page visits, only **18,000 slot-directory bytes** changed: 9.14 bytes per page visit, or 3 bytes per reclaimed version counting both lifecycle phases. The ordinary private-page path processed **16,138,240 bytes of full page images**, 896.6 times the directory change volume. There were no compactions in this workload.

Thus, yes: an 8192-byte image was processed for roughly nine bytes of directory change. That does not mean WAL contained 8192 bytes per page: K.4 already used compact PageDelta WAL. Lifecycle WAL was only 235,186 bytes in the later scoped measurement. The waste was primarily whole-image private staging, scratch spill/readback, page decode/validation and repeated checksum/materialization work surrounding existing compact WAL.

The 12,000 lifecycle edits average 6.09 edits per changed page visit. Five reclaim commits carried lifecycle work: 2400 edits per lifecycle publication; including two sweep-only publications gives 1714.3 edits per durable maintenance publication. These are workload averages, not per-page distributions.

The originally quoted 0.415 page deltas/version is the **all-page** count in the harness (2493 deltas). The scoped heap count is 1970, or 0.3283/version. Index page mutation calls (1877) need not equal distinct index pages installed (523).

## 2. K.5 implementation

### Prepared lifecycle patches

`HeapTable::prepare_lifecycle_delta` prepares ordinary inline RETIRE/FREE operations from the statement image before commit-order ownership. It validates the expected slot headers, applies the existing lifecycle rules in a private image, calculates the checksum, and records a small set of header/directory byte edits plus the exact plan, predecessor LSN and predecessor checksum.

Inside the serialized stage, `reclaim_lifecycle_prepared` reads the current committed image and validates it. It accepts the prepared edits only when the plan, base LSN and base checksum still match. A changed predecessor uses the existing per-slot revalidation path; it never overwrites a foreground change with an old prepared image. Overflow release and reset cases also retain that path. The fallback now checks the tuple header without decoding payload columns unnecessarily.

Horizon eligibility still comes from the existing reclaim planner. The publication horizon is monotonic; a plan is prepared under the pinned statement view. FREE still requires the horizon to exceed the retirement publication. OCCUPIED → RETIRED → FREE is unchanged. UNIQUE deletion remains in the same maintenance transaction; non-unique stale references retain K.4 read revalidation and lazy pruning.

### Bounded private patch storage

`PrivatePageStore` can retain an immutable predecessor `Arc` plus sparse edits instead of an ordinary private scratch image. The path allows at most 1024 lifecycle pages and 1024 edited bytes per page; otherwise it falls back. Retained predecessor images can pin up to 8 MiB per maintenance generation, plus patch metadata. The shared cache default remains 256 MiB.

The current WAL visitor reconstructs an image, stamps its LSN/checksum and derives the existing PageDelta. Publication reconstructs an image again and installs it through the unchanged durable-receipt protocol. Ordinary writes can convert a patch into the normal private-page representation. Rollback discards either representation.

This eliminates lifecycle scratch spill in the measured workload. It **does not eliminate 8 KiB memory materializations, checksum validation, or 8 KiB durable heap-page installation**. Serialized work is cheaper but has not reached a pure tiny-edit publication path.

### Compatibility

No WAL record, page format, catalog capability, replication encoding or backup format changed. `LAZY_INDEX_PRUNING_V1`, eager UNIQUE cleanup, stale classification, sweeper trigger and policy are unchanged. Existing PageDelta predecessor/result checksums and LSNs provide redo validation and idempotence; WAL force still precedes durable page installation. No new migration is needed.

## 3. Locality policy

For ordinary versioned inserts, allocation prefers:

1. A sufficiently spacious page already dirty in this transaction, in recent-use order.
2. The recent write frontier when it has room.
3. A known reusable page with at least `max(required_bytes, 1024)` free capacity.
4. The existing bounded unknown-page probe, then a new tail page.

It avoids repeatedly selecting isolated small holes on cold pages. It is not append-only: capacity accumulates until a page becomes worth reusing. The cold-page threshold can leave less than 1 KiB of deliberately unused reusable capacity per skipped page. There is no general cache-hot ranking beyond transaction residency and the recent frontier. Legacy and bulk allocation paths are unchanged. Deferred compaction remains in place.

## 4. Microbenchmark

Windows, 60,000 live rows, 6000 updates, worker disabled, explicit reclaim through RETIRE and FREE. Both comparison binaries had the same scoped WAL/checksum/install probes. Each is one run; times are noisy and instrumentation adds cost. Additional K.5-specific byte counters are absent on the matched K.4 build; the separate earlier K.4 byte-profile run supplies the byte-amplification evidence above.

| Metric, per reclaimed version | User Windows K.4 | Scoped K.4 rerun | K.5 |
|---|---:|---:|---:|
| Full reclaim, µs | 105.1 | 263.906 | 179.283 |
| Serialized reclaim prepare, µs | 31.0 | 73.801 | 42.512 |
| Heap prepare, µs | 12.3 | 27.354 | 4.573 |
| Index prepare, µs | 18.7 | 46.445 | 37.937 |
| Commit-order hold, µs | 46.5 | 108.012 | 57.682 |
| Heap WAL preparation, µs | — | 26.153 | 6.059 |
| Heap installation, µs | — | 7.716 | 2.889 |
| Ordered publication, µs | — | 11.233 | 7.127 |
| Preparation outside order, µs | — | — | 6.639 |
| Lifecycle WAL, bytes | — | 39.198 | 39.198 |
| Total WAL, bytes | 214 | 214.058 | 214.058 |
| Heap installed pages | — | 0.3283 | 0.3283 |
| All installed pages | 0.415 | 0.4155 | 0.4155 |
| Lifecycle checksum evaluations | — | 1.970 | 2.298 |

K.5 accepted all 1970 prepared pages in this micro run; none had a changed predecessor. Sparse prepared edits totaled 26,996 bytes, including header/checksum edits. Initial private scratch-page writes fell from 2384 to 414, exactly 1970 fewer; 26 rewrite calls remained. The index path still accounts for most serialized reclaim preparation.

Checksums **increased by one per lifecycle page visit**, from 11,820 to 13,790. The scoped counter counts checksum evaluations, including verification, not only checksums persisted to a page. Additional preparation outside order is not included in that scoped count. Cache counters are call counts: scoped clean hits rose 3940→5910; dirty hits and misses were zero for both micro runs. These are not counts of unique resident/cold pages.

Heap prepare + heap WAL + installation fell 61.223→13.521 µs/version (77.9%). Installation alone fell 62.6%; both exceed the requested 50% reduction in this single matched experiment. Commit-order hold fell only 46.6%. Against the original user Windows hold of 46.5 µs/version, the requested half-cost threshold is 23.25 µs; K.5 also misses that threshold. Serialized prepare exceeds 15 µs/version. WAL bytes and installed page counts did not improve.

## 5. Piggyback and preemption

No foreground piggyback reclaim was implemented. Its implemented contribution is zero. The current patch path preserves maintenance fault isolation and eager UNIQUE atomicity; coupling those operations to arbitrary user transactions needs additional design and measurements.

A diagnostic profiled OLTP run applied 7576 prepared page edits and rebased 55 (0.72% of 7631 attempts). This measures predecessor changes between planning and serialization. **It does not measure simultaneous foreground ownership or the fraction of reclaim that could safely piggyback. That requested opportunity metric remains unquantified.** No unsupported piggyback percentage is claimed.

No adaptive preemption, worker timing, batch-size or scheduling change was made. Diagnostic maxima included 14.405 seconds in ordered publication and 14.196 seconds in the status-write scope; heap installation's maximum was about 4 ms. A 2.634-second commit-order maximum coincided with a 2.624-second checkpoint force scope. These nested scopes identify where time was observed, not an OS/root-cause diagnosis. Status lifecycle is outside the requested milestone. Reducing lifecycle batches would not establish that those stalls are solved and could add publication overhead. The approximate 1 ms maintenance-hold aspiration is **not met**.

## 6. Locality and boundedness

The locality workload is a single profiling run per case, 20,000 updates. It is separate from the authoritative unprofiled OLTP gate.

| Hot rows | Worker | Heap pages before→after | Heap installs/update | All installs/update | WAL bytes/update | FREE reuses | Tail appends |
|---:|---|---:|---:|---:|---:|---:|---:|
| 100 | OFF | 2→305 | 1.736 | 3.757 | 788.016 | 0 | 303 |
| 100 | ON | 2→5 | 1.738 | 3.724 | 992.120 | 18,103 | 3 |
| 10,000 | OFF | 152→455 | 1.997 | 4.013 | 812.960 | 0 | 303 |
| 10,000 | ON | 152→167 | 2.432 | 4.836 | 1401.188 | 17,967 | 15 |

At 100 rows ON there were 577 compactions and three skipped-cold decisions; at 10,000 rows ON, 1847 compactions and 206,385 skipped-cold decisions. The latter count includes repeated allocator decisions about the same pages. It is not a count of distinct pages skipped. Index writes/update were 2.021, 1.990, 2.016 and 2.510 in table order. All four integrity checks passed.

The worker still adds material WAL/write work at 10K rows. Without a matched K.4 locality A/B, these numbers do not prove that this allocator alone recovered throughput. Installs measure page publication events, including background work, rather than all reads or unique pages touched per update. Distinct touched-page tracking was not added; that measurement remains a limitation.

Longer constant-cardinality tests:

| Workload | Work done | Heap result | Final live rows | Final RETIRED / FREE | Final index pages / entries |
|---|---|---|---:|---:|---:|
| 100-row hot set | 100,000 updates, ten windows | 5 pages in every window | 100 | 131 / 152 | 12 / 840 |
| 10K-row hot set | 100,000 updates, ten windows | 166→167, stable at 167 | 10,000 | 307 / 1293 | 109 / 22,621 |
| Delete/insert | 100 generations, 2000 live rows | 61→71, stable by generation 10 | 2000 | 2000 / 1865 | 187 / 7480 |

All final checks passed with zero corrupt index entries. Snapshot census fields can race the worker between individual observations, so `occupied` can exceed logical live rows and index totals need not align with a later integrity snapshot. The CSV preserves every window/generation and the hot-update write/WAL counters. The unprofiled delete/insert test does not collect per-update write counters; its corresponding CSV cells are blank. A 1M-update soak was not run.

Index entries oscillate under lazy pruning. Index pages grew **41→187** over delete/insert generations, compared with the user's historical K.4 41→192. This is the known no-merge drift, not proof of bounded index page count. Leaf merge/rebalance is deliberately unchanged. Heap boundedness and bounded stale-entry behavior were observed for the tested duration; unlimited-duration behavior is not proven by finite tests.

### Append-counter correction

The measured profiling binary accidentally counted both the existing `heap.append_page` span and a newly added event under that name. The new event was removed from the delivered source. Locality and hot-churn CSVs explicitly report raw counts and corrected appends (`raw / 2`). In these ordinary insert workloads the corrected counts agree with heap growth. Original logs are retained unchanged. A post-fix smoke test observed exactly three append calls for heap growth 2→5. Other timing, WAL, installation and reuse counters are unaffected by this accounting correction.

## 7. Correctness and recovery

Validation covered the existing execution, storage, transaction, index, WAL, server, administration and other workspace suites. New tests exercise sparse patches beyond the normal private-cache capacity, immutable predecessors, WAL stamping/reconstruction, conversion back to ordinary mutation, and fallback after a foreground insert changes the base page. A stale lifecycle retry is rejected and the inserted row survives.

The reclaim subprocess crash test now runs both RETIRE and FREE phases at six boundaries: before private preparation, after lifecycle WAL append, before WAL force, after WAL force, before visibility publication and during heap installation. Before durable force it permits either complete old or complete new state; durable outcomes must recover atomically. Existing tests cover horizon pinning, checkpoint lifecycle transitions, recovery with RETIRED/FREE slots, RID reuse, stale-index reads, overflow, uniqueness, rollback and maintenance fault isolation.

A new administration test records exact WAL positions before/after RETIRE and FREE, checks checkpoint publication, replays standby WAL twice, PITR-recovers to all four cut points, restarts each recovered database twice and checks integrity. It passed. Existing backup/PITR/replication reuse tests also passed. No new WAL redo implementation was introduced.

The specifically requested `compact_redo_tests::v3_crash_at_commit_pipeline_boundaries_is_atomic` passed in both full execution runs; its prior flake was not reproduced.

One different test remains timing-sensitive: the server's automatic-reclaim boundedness test failed in a concurrent suite with heap samples `[15,15,20,21,21,21,25,25,25,25]`, exceeding its late-growth tolerance. The unchanged test passed in isolation, ending at 30 stable pages after 60K updates. The new isolated 100K-update measurements also plateaued. This is an unresolved concurrency/timing test failure, not a clean all-workspace pass and not a diagnosed root cause.

Other initial failures were fixed: a reclaim test assumed first-fit page zero; the explicit ON/OFF server test raced its worker; a Windows marker test expected Unix unlink behavior; and a storage fixture used a noncanonical path for one registered file. Minimal pre-existing Clippy issues were repaired or narrowly annotated. Production marker/error handling was not changed.

Final completed gates include execution 201 tests, index 34, storage 62, transaction 46, types 3, validation 9 (three long soaks ignored), WAL 76 (one fixture-dependent benchmark ignored), administration 21 existing tests plus the new exact-boundary test, and the server integration tests (one startup and two C.6 tests). Server library results and the isolated retry are recorded separately; do not aggregate them into a claimed single green workspace invocation. Strict workspace Clippy and rustfmt passed. The separate benchmark harness retains dead-code warnings from shared legacy harness functions.

## 8. Acceptance ledger

| Requirement | Result |
|---|---|
| Windows OLTP1 ≤5% | MISS, 6.90% |
| Windows OLTP8 ≤8% | PASS, 7.30% |
| Windows OLTP16 ≤8% | MISS, 15.16% |
| Serialized prepare ≤15 µs/version | MISS, 42.512 |
| Commit-order hold reduced ≥50% | MISS, 46.6% reduction in scoped comparison; also misses user-baseline threshold |
| Heap publication cost reduced ≥50% | Observed PASS, 62.6% installation / 77.9% combined heap stages, one matched run |
| Fewer installed heap pages / WAL bytes | No improvement |
| Less checksum work | No improvement; scoped evaluations increased |
| Bounded heap in requested finite workloads | Observed PASS |
| Index leaf-page boundedness | Known no-merge drift remains, out of scope |
| Recovery/integrity | Focused and broad tests passed; separate server timing flake retained |
| Frozen Standard suite | NOT RUN; manual wrapper ready |
| Piggyback opportunity / distinct touched-page metric | Not quantified |

## 9. Reproduction and artifacts

Host: Windows NT 10.0.26200.0; AMD64 Family 25 Model 33 Stepping 2; 32 logical processors; Rust 1.85.0; cache 268,435,456 bytes. All final measured workloads ran sequentially with no concurrent builds/tests initiated by this task. This does not exclude unrelated host activity. Earlier prototype and contaminated logs are retained and labeled in the evidence README.

From an extracted source root, in PowerShell:

```powershell
& .\tools\k5-validation\build.ps1
& .\tools\k5-validation\reclaim-micro.ps1 -Out .\reclaim-micro-results.csv
& .\tools\k5-validation\quick-ab.ps1 -Rounds 3 -Out .\quick-ab-results.csv
& .\tools\k5-validation\locality.ps1 -Out .\locality-results.csv
& .\tools\k5-validation\bounded-churn.ps1 -Generations 100 -HotWindows 10 -UpdatesPerWindow 10000 -Out .\bounded-churn-results.csv
& .\tools\k5-validation\crash-lifecycle.ps1
& .\tools\k5-validation\integrity-check.ps1
cargo test --release --locked -p phobos-server --test a5_startup --test c6_acceptance
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
```

Optional baseline build: `& .\tools\k5-validation\build.ps1 -Baseline 'C:\path\to\extracted-K4-source'`. This runs the same harness against K.4; new counters unsupported by pristine K.4 will print zero and must be treated as unavailable. The evidence archive includes the modified K.4 scoped-instrumentation overlay for reproducing the scoped comparison. Apply that overlay only to a disposable copy of the verified K.4 source.

The frozen suite lives at `C:\PHOBOS-BENCH-v1.4-Lite15`, but its internal identity is **PHOBOS Standard Benchmark v1.3.1-G56**. No exact suite invocation was confirmed, and no official v1.4 result is claimed. Once its command is verified, run:

```powershell
& .\tools\k5-validation\standard.ps1 -Suite "<command>" -Out .\standard-results
```

`<command>` is intentionally a placeholder supplied by the user, not an executable command invented here. The wrapper runs it with worker ON and OFF, captures separate logs, and restores the prior worker setting. The supplied command must select the intended K.5 binaries and any required suite working directory.

The source ZIP excludes build products, databases and local absolute-path settings. `PHOBOS-0.2-K.5-CHANGED-FILES.txt` lists every changed/added source file and its SHA-256 relative to K.4. `PHOBOS-0.2-K.5-evidence.tar.gz` contains original logs, raw CSVs, reproducibility scripts and the baseline instrumentation overlay. `PHOBOS-0.2-K.5-FINAL-HASHES.txt` hashes every deliverable except itself, avoiding a self-referential hash. The four report CSVs distinguish unavailable values from measured zeros and preserve provenance notes.
