# PHOBOS 0.3-E recovery validation

## New permanent coverage

`crates/phobos-execution/src/mvcc_runtime/schema_v2_tests.rs` runs actual child processes that exit without shutdown while committing one transaction containing CREATE TABLE with DEFAULT, CHECK and PRIMARY KEY plus an inserted row. The six boundaries are:

1. c6_private_redo_staged
2. wal.before_force
3. wal.after_force
4. mvcc.before_publication
5. c5_schema_metadata_installed
6. mvcc.after_publication

Each child must exit at the requested hook. Two successive opens inspect the resulting state. Before durability, the transaction may be absent or completely present. At/after the durable/publication boundaries, the schema and row must be present. Recovered CHECK rejection, default metadata, duplicate-key rejection and online integrity must all agree. Hooks are inherited test-only instrumentation, not production crash behavior.

The runtime tests also verify own CREATE/INSERT, complete rollback, schema/default COMMIT and ROLLBACK, omitted versus explicit NULL, atomic multi-row failure, atomic UPDATE failure, composite PKs, stable definitions across table/column rename, typed defaults, exact numeric comparison boundaries, bulk rejection and restart. A barrier starts two clients competing for one primary key: exactly one succeeds. A held schema lease rejects competing catalog/schema operations with the inherited retryable error; after commit a new INSERT uses the new default.

`crates/phobos-admin/src/schema_v2_tests.rs` starts from an old-format migrated fixture and takes an online backup before new schema DDL. It verifies:

- DEFAULT/CHECK/PK created and populated in one transaction.
- Later ALTER DEFAULT and insertion.
- Physical standby receive/replay, replay repeated, query and constraint metadata equality.
- PITR from the pre-definition backup to both the CREATE/INSERT boundary and the later default-change boundary.
- Online backup taken after definitions and restored through the existing online/PITR path.
- Offline backup/restore through the existing PHOBOS_BACKUP_1 path.
- Restored default application, CHECK rejection and PK uniqueness.
- Offline integrity on source, standby, PITR and restored images.

The existing online and offline backup formats have different restore paths. The first test attempt incorrectly passed a PHOBOS_BACKUP_2 image to restore_offline, which correctly rejected its missing offline marker. The test now uses pitr_recover_to for online images. No backup semantics were weakened to make a test pass.

Catalog tests verify v2→v4 migration, persistence, invalid references/operators, duplicate definitions, every truncated prefix of a v4 image, valid-checksum semantic corruption, and unknown versions. Rejected definition changes preserve the previous in-memory definition. Catalog checksum and exact payload framing remain mandatory.

## Release-binary coverage

The isolated PowerShell smoke wrapper uses actual admin/server/CLI binaries. It creates DEFAULT/CHECK/PK metadata, verifies default use and CHECK rejection, performs transactional renames, force-terminates only its own server child, restarts, compares metadata/data, verifies constraints, performs offline integrity, backup/restore, restored integrity and restored queries. Credentials/test instances are excluded from artifacts.

The unchanged 0.3-D Core integration suite also force-terminates its isolated server and reconnects, exercises typed results and metadata, and performs offline integrity. The workspace regression suite retains inherited WAL, MVCC, UNIQUE, lifecycle, partition, backup, replication and crash tests.

## Limits

These are deterministic targeted crash points and software process failures, not a physical power-loss certification across all hardware/filesystems. Foreign keys, identity, views and other deferred objects have no purported recovery coverage because they are not implemented. Linux/macOS executions were unavailable; new logic remains portable Rust. Windows is the actual runtime validation platform.

The final TEST-RESULTS and evidence logs identify exact successful runs and compiler versions. No format downgrade is attempted: restore a pre-v4 backup with its matching accepted engine.
