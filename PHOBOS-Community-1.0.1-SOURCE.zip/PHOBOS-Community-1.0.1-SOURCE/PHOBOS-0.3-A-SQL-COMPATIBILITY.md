# PHOBOS 0.3-A SQL compatibility

This is an incremental Enterprise SQL Foundation release on the accepted K.5 storage engine. It is not a claim of full SQL-standard or full enterprise feature coverage.

## Newly supported

- Explicit and implicit table aliases (`FROM employees AS e`, `FROM employees e`), including self joins. The alias hides the underlying table name within that query scope. Distinct relation qualifiers are required.
- INNER and LEFT JOIN with general ON expressions, including compound predicates, inequalities, functions, and uncorrelated subqueries. Simple column equality joins retain the existing hash/spill execution path. Parenthesized ON expressions are accepted.
- CROSS JOIN between stored tables.
- Uncorrelated scalar SELECT subqueries in SELECT expressions, WHERE, HAVING and LIMIT/OFFSET. Zero rows yield NULL; more than one row or more than one column is an error.
- Uncorrelated EXISTS / NOT EXISTS in expressions. Existing IN subqueries remain supported.
- Non-recursive WITH: one or several sequential CTE definitions; a later definition may use an earlier one. Read-only SELECT bodies only.
- Derived SELECT inputs in FROM, with a required alias. Nested derived inputs and CTEs can filter, project, aggregate, sort and limit their input.
- INSERT column lists, including reordered columns and omitted nullable columns. Missing columns receive NULL. Existing NOT NULL, types and UNIQUE enforcement remain authoritative; this does not implement DEFAULT constraints.
- `ALTER TABLE old RENAME TO new` and `ALTER TABLE t RENAME COLUMN old TO new` through the MVCC/server route. Existing IDs, column ordinals and index definitions are preserved. These changes are transactional and survive restart. Renaming partition parents/children is rejected.
- `TRIM`, `LTRIM`, `RTRIM` (one text argument, ASCII space trimming), `CHAR_LENGTH`, `CHARACTER_LENGTH`, `OCTET_LENGTH`, `SUBSTRING` / `SUBSTR` (comma argument syntax), `REPLACE`, `CONCAT`, `FLOOR`, `CEIL`, `CEILING`, `ROUND`.
- `SHOW CATALOG TABLES|COLUMNS|INDEXES|CONSTRAINTS [FROM table]` and `SHOW CATALOG CAPABILITIES`, using the ordinary authenticated result protocol.

## Partial support and limits

- CTEs and derived inputs are materialized, not optimized or persisted. Joins over their outputs are rejected; place the stored-table join inside the CTE/derived SELECT. CTE column-name lists, recursive/self-referencing definitions (including names that shadow a physical table), and data-modifying CTEs are unsupported. At most 64 CTE bindings and 1 MiB of cumulative expanded AST debug representation are allowed. Existing parser nesting limit 64 remains in force.
- General predicate/CROSS joins use a cancellable nested-loop operator. Output is bounded by `query_memory_bytes`; exceeding it returns ResourceLimit. This operator does not spill. Existing simple equality joins retain their established hash/spill paths. General joins are intended for manageable input sizes, not a claim of a cost-based enterprise optimizer.
- Correlated subqueries, LATERAL and subqueries over partition parents are unsupported. Partition parents retain the baseline simple SELECT and COUNT routes (including aliased COUNT); advanced aliased projections and joins over parents are rejected rather than reading their empty physical heaps. Query-local derived inputs do not add a storage object. Materialization still inherits the existing collecting executor's limitations.
- ORDER BY can refer to a selected qualified column by an unambiguous short name. Existing result labels remain unchanged. Use explicit AS aliases for stable client column labels, especially aggregates and expressions.
- GROUP BY resolves the actual input column; matching just the last component of two different relation qualifiers is no longer accepted. This corrects a potential wrong-result case for self joins.
- SUBSTRING uses one-based Unicode character positions. A start before 1 consumes the requested length; negative lengths error. TRIM does not implement the SQL BOTH/LEADING/TRAILING grammar. CHAR_LENGTH follows the existing LENGTH behavior, including binary byte counts. CONCAT accepts text/NULL only and ignores NULL arguments. REPLACE with an empty search string leaves text unchanged. CONCAT/REPLACE output is capped at 16 MiB.
- FLOOR/CEIL/ROUND accept BIGINT, DOUBLE or NULL; ROUND rounds halfway away from zero and only supports one argument. No implicit string-to-number conversions are introduced. Existing COALESCE/NULLIF evaluation behavior remains unchanged.
- ALTER only renames. Legacy non-MVCC direct Database execution rejects ALTER. Schema generations and the existing DDL admission/commit rules still govern concurrent DDL.
- Catalog metadata is instance-local. A server owns one database; table/index IDs are opaque decimal strings, not globally unique IDs. There is no SQL database/schema namespace. NOT NULL is reported without a fabricated constraint name; a unique index is reported as UNIQUE INDEX, not as a primary key.
- Name and expression validation otherwise retains the baseline's execution-time behavior. This is not a complete static SQL type checker. PREPARE retains the existing parameterless read-only behavior.

## Unsupported in 0.3-A

Persistent views; DEFAULT and CHECK constraints; foreign keys; primary-key declaration syntax; identity/auto-increment/sequences; temporary tables; ALTER ADD/DROP/type-change/default/nullability operations; DROP TABLE; RIGHT/FULL/NATURAL joins; JOIN USING; joins over derived inputs; recursive CTEs; correlated subqueries; UNION/INTERSECT/EXCEPT; window functions; INSERT SELECT; RETURNING; SELECT without FROM; multiple databases or SQL schemas; information_schema SELECT views; stored procedures/triggers.

No new physical SQL data types are introduced. Existing BIGINT/INTEGER, BOOLEAN, DOUBLE/FLOAT/REAL, TEXT/VARCHAR, BINARY/BLOB, DATE, TIMESTAMP and DECIMAL/NUMERIC(p,s) are retained with their baseline semantics. VARCHAR is not a new length-enforced type.

## Examples

```sql
CREATE TABLE employees (id BIGINT NOT NULL, manager BIGINT, name TEXT);
CREATE UNIQUE INDEX employees_id ON employees (id);
INSERT INTO employees (name,id) VALUES ('Ada',1);
INSERT INTO employees (id,manager,name) VALUES (2,1,'Lin');
SELECT e.name AS employee, m.name AS manager
FROM employees e LEFT JOIN employees m
ON e.manager=m.id AND m.name IS NOT NULL;

WITH cleaned AS (
  SELECT id, TRIM(name) AS name FROM employees
), selected AS (
  SELECT id, UPPER(name) AS display_name FROM cleaned WHERE id>0
)
SELECT s.display_name FROM selected s ORDER BY s.display_name;

SELECT e.id FROM employees e
WHERE e.id=(SELECT MAX(id) FROM employees)
AND EXISTS (SELECT id FROM employees WHERE manager IS NULL);

BEGIN;
ALTER TABLE employees RENAME COLUMN name TO display_name;
SHOW CATALOG COLUMNS FROM employees;
ROLLBACK;
SHOW CATALOG INDEXES FROM employees;
SHOW CATALOG CONSTRAINTS FROM employees;
SHOW CATALOG CAPABILITIES;
```
