# PHOBOS Management Studio 0.3-C — User guide

## Install and launch

Run PHOBOS-Management-Studio-0.3-C-Windows-x64.exe, or extract the Runtime ZIP and run PHOBOS-Studio.exe. The self-contained Windows x64 package needs no installed .NET SDK, browser or database server in its directory. The installer is per-user and unsigned. It installs Start menu shortcuts and does not change the accepted PHOBOS server installation. Verify the external SHA-256 manifest before installation. Windows/Linux/macOS share the GUI architecture; only Windows is packaged and tested here.

## Connect and profiles

Choose Connect (or Connection → Connect / Manage Profiles). Enter host, port, username and password. Default: 127.0.0.1:54321; a local 0.3-B registry installation may supply the endpoint. Arbitrary remote host/port values are accepted. Saving a profile stores only name, host, port, username and TLS preference under the platform application-data directory, PHOBOS/Studio/profiles.json. Reusing its name replaces that profile; select a saved profile to edit it. Passwords are requested every connection. Profile deletion has no V1 UI; edit the password-free profile file while Studio is closed if needed.

TLS uses OS certificate trust, hostname checking and online revocation checks. Private CAs must already be trusted by the OS; V1 has no custom CA picker or client-certificate/mTLS control. Without TLS, credentials, SQL and results travel in plaintext: use a trusted network or tunnel. The 0.3-B installer itself configures loopback; Studio does not reconfigure remote listeners or firewalls.

A connection opens a SQL session and a separate cancellation session. Capabilities determine Management API/engine compatibility. An unsupported future metadata API disables Object Explorer and object templates while leaving SQL usable. An incompatible wire/stream protocol refuses connection with an error.

## Object Explorer

Expand the connection → Tables → table → Columns, Indexes or Constraints. Widen the left panel or use horizontal scrolling for long names. Columns show ordinal, type and nullability; indexes show uniqueness and ordered columns; constraints show only real NOT NULL/UNIQUE INDEX metadata. One connection represents one database; there is no invented database/schema hierarchy.

Refresh all and Refresh selected rebuild catalog metadata; the latter currently refreshes the whole connection as well. Successful SQL automatically refreshes metadata. A disconnected session clears the tree. For concurrent schema changes, refresh again if needed.

Objects menu templates support Create Table, Create Index/Unique Index and Rename Table/Column on known 0.3-A engines. Select a table first to prefill its name. Enter simple identifiers and review generated SQL in a new tab. Create Table supplies an editable id/name starting definition; add existing SQL types/nullability in the editor. No object-management statement runs until Execute. Unsupported SQL features are omitted. See the included 0.3-A SQL compatibility document.

## SQL documents and execution

Ctrl+N creates a tab. Ctrl+O opens a .sql file (1 MiB editor file limit). Ctrl+S saves; File → Save As chooses another file. Modified tabs carry an asterisk. File → Close Tab or Exit prompts Save / Discard / Cancel for unsaved changes. The editor supports line numbers, selection, clipboard, undo/redo, Ctrl+A and Ctrl+F Find next (case-insensitive, wraps). SQL highlighting/completion and autosave are not implemented.

F5, Ctrl+Enter, Query → Execute or the toolbar executes selected SQL, otherwise the document contents. Submit one statement per execution: the server protocol provides one collected stream per request and Studio does not split scripts or fabricate multiple result sets. Select individual statements within a document.

All tabs share one SQL session and ordinary BEGIN / COMMIT / ROLLBACK semantics. Do not treat tabs as independent transactions. There is no automatic reconnection/replay. Connecting to another endpoint or disconnecting closes the current session; uncommitted work is rolled back. The UI prevents overlapping submissions.

## Results, Messages and timing

The read-only grid has headers, scrolling, resizable columns, keyboard navigation and extended row selection. Use Copy cell, Copy selected rows or Copy all. A click on a cell exposes its exact type and full value in the inspector, even when the visible column is narrow. Text can be empty; NULL displays as ⟨NULL⟩. Dates/timestamps and exact decimals retain their type. Binary displays 0x hexadecimal. Clipboard copies are explicitly requested and not automatically cleared; protect sensitive results as you would in other database tools.

Messages displays command tags/affected counts, structured server error codes and client errors without stack traces. Timing is client elapsed query time, not server CPU time; automatic metadata refresh occurs afterward. The status bar shows endpoint/user/state and duration. Previous messages are retained in a bounded 64,000-character in-memory pane; no persistent SQL/result log is written.

Rows stream in bounded batches, with visible receiving progress. The grid appears after successful completion. Limits: 50,000 rows, estimated 32 MiB retained result budget, two-minute query deadline. Limit breaches close the session with an explicit error, never silent truncation. Use SELECT ... LIMIT to narrow results. Object Explorer has a 2,000-table UI budget.

## Cancel and reconnect

Press Cancel during a query. Studio sends the existing out-of-band cancellation handle. A requested cancellation may race a completed query or irreversible commit; only the final query result establishes the outcome. If cancellation cannot be confirmed, Studio says so and continues waiting for the actual result/deadline.

Streaming errors (including SQL errors), cancellation, timeout or broken sockets close the query session. Reconnect through the connection dialog. A lost response to a write can be uncertain: inspect database state before retrying. Studio never silently resends SQL. A healthy successful transaction can span multiple Execute operations.

## Windows local administration

Connection → Local Administration displays discovered service name, Running/Stopped/etc., packaging version and endpoint. Start, Stop and Restart request confirmation and Windows UAC elevation for a separate helper; normal SQL remains unelevated. SCM Stop preserves 0.3-B graceful shutdown. After a service action, reconnect explicitly. Remote connections have no remote service-control feature. A missing local installation does not prevent host/port connections. Log-folder access is deferred; use the existing server administration documentation without weakening ACLs.

## Uninstall

Uninstall PHOBOS Studio from its Start menu entry or Windows Installed Apps. It removes Studio binaries/shortcuts only. Saved profiles, SQL files, server installations and database data remain. Production signing, complete accessibility/high-DPI certification, Linux/macOS qualification and a full GUI user-interaction matrix are not claimed.
