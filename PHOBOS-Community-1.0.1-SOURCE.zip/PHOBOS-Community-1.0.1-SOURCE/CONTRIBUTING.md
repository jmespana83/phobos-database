# Contributing

Use Rust 1.85.0. Before submitting changes run `cargo fmt --all -- --check`, `cargo clippy --workspace --all-targets --all-features -- -D warnings`, `cargo test --workspace`, and `cargo doc --workspace --no-deps`. Keep subsystem dependencies narrow and add tests for durable formats.
