# PHOBOS Community Edition 1.0.1 — Upgrade

For an existing compatible 1.0.0 installation, run the 1.0.1 installer at the same paths and use Repair with the existing password. Catalog 5 is unchanged; no destructive migration is required. The copy-upgrade instructions below apply to earlier catalog formats.

Keep old binaries/data/auth/config. Stop the old instance gracefully. Use the NEW admin executable and separate fresh sibling destinations:

```text
phobos-admin upgrade-community-copy OLD_DATA NEW_BACKUP NEW_DATA
```

The command checks source integrity, creates a consistent offline backup, restores a new copy, checks it, publishes format 5 through ordinary schema WAL/commit and checks integrity afterward. Original data is preserved. Failed output remains for diagnosis. External credentials/certificates/service metadata are not migrated.

Accepted-era format 2/3 MVCC data uses this explicit path. Experimental format 4 is refused unless --accept-v4 is supplied after provenance review/independent backup. Legacy non-MVCC migration is separately migrate-mvcc-copy. Fresh 1.0 init creates format 5 transactionally; public server startup refuses older formats. Older executables reject format 5; no downgrade converter exists.

Start the new copy with protected copied auth/config on an unused endpoint, validate application behavior, then cut over deliberately. Windows service adoption requires administrator configuration; the fresh wizard does not adopt populated data automatically. Rollback uses preserved old data/binaries; new writes are not merged back. Never overwrite primary data during a rehearsal.
