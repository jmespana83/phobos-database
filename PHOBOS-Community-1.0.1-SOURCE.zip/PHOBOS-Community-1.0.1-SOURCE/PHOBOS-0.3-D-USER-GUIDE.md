# PHOBOS Studio 0.3-D user guide

## Install and connect

Use the standalone Windows x64 installer or extract the portable runtime ZIP. Studio does not bundle the database server. This milestone installs separately under `%LOCALAPPDATA%\Programs\PHOBOS Studio 0.3-D`, with its own installer identity and Start Menu group; older milestone artifacts/installers are not overwritten. Normal use does not need administrator privileges. Uninstall retains profiles, SQL files and server data.

Choose Connect, supply a profile name, host, port, username and password. TLS uses OS certificate trust and hostname validation, with no bypass. Plaintext TCP is only appropriate on a trusted network or tunnel. Connection → Transport / certificate shows negotiated TLS, certificate subject/issuer/expiry and SHA-256 after a successful TLS connection. No certificate is trusted merely because its fingerprint is displayed.

Profiles → New, Edit / Rename, Duplicate, Delete manages non-secret endpoint settings. Passwords are prompted per connection and are not saved. Deleting or renaming a profile does not alter an already-open SQL session. Corrupt profile files load an empty list with a warning; a later save preserves the original as a `.corrupt-<ticks>` backup.

## Query tabs

Each tab has its own authenticated SQL session, transaction, results, Messages and timer. New Query opens an independent tab and asks for authentication when a preferred profile exists. At most eight tabs are supported. Opened SQL files and generated templates are disconnected until you choose Connect.

F5 or Ctrl+Enter executes selected SQL; with no selection, it executes the entire script. Ctrl+N opens a query, Ctrl+O opens SQL, Ctrl+S saves, Ctrl+W closes a tab, Ctrl+F finds text, and Ctrl+Space opens completion. Unsaved SQL is never silently discarded. SQL files are limited to 1 MiB on open; scripts are limited to 1 MiB on execution.

Example:

```sql
CREATE TABLE studio_demo (id BIGINT, name TEXT);
INSERT INTO studio_demo VALUES (1, 'semi;colon');
SELECT * FROM studio_demo;
SELECT id FROM studio_demo;
```

Semicolons inside strings/comments are preserved. Up to 32 statements are submitted sequentially. Each SELECT has a result tab. Commands report affected rows. Scripts stop at the first error; earlier autocommits remain committed and later statements are not sent. Use BEGIN/COMMIT/ROLLBACK deliberately. Another tab is never inside this tab's transaction.

Cancel targets the active tab, requests cancellation of its current statement, and prevents later script statements. Cancellation acknowledgement is not proof that a write was rolled back: await the actual outcome. If the response is lost, commit outcome may be uncertain. Inspect database state before retrying. Reconnect is explicit and never replays SQL.

## Results, copy and export

Rows appear progressively. A receiving result is Incomplete until the final protocol totals validate. A failed stream retains only validated displayed rows, labelled Incomplete. Previous completed results remain available after a failed execution. Switching tabs preserves each tab's results.

Query → Limits configures per-tab bounds. Defaults are 50,000 rows, estimated 32 MiB per script, and 120 seconds per statement. Limits cannot be disabled. Reaching a budget closes the streaming session; reconnect and narrow the query with LIMIT. Reaching the aggregate script budget before another statement stops the script without sending that statement.

Select a result tab. Copy Cell copies its full displayed value; Copy selected rows and Copy all (TSV) include headers. Copy CSV uses exact-value mode. Clipboard writes are explicit. The inspector shows a selected cell's type and value; wide text is also available through Copy Cell.

Export supports all displayed rows of the selected result, or its selected rows only. It never retrieves omitted rows. CSV correctly quotes commas, quotes, CR/LF and Unicode. Every non-NULL field is quoted. NULL is the unquoted token `\N`; a literal text `\N` is quoted. Exact decimal and timestamp text is retained. Generic CSV importers may ignore the distinction between quoted/unquoted NULL tokens: use typed JSON when type/null fidelity matters. Dates/timestamps outside the CLR calendar range use the explicit epoch-based representation shown by Studio.

Exact CSV preserves formula-like TEXT. Before opening in a spreadsheet, select **Spreadsheet-safe CSV** to explicitly prefix text/header values beginning with `=`, `+`, `-`, or `@` (after leading whitespace) with an apostrophe. This changes exported text and never changes the database. Numeric negative values are not altered. Spreadsheet importers differ; typed JSON avoids formula evaluation.

Typed JSON stores column names and rows of `{type,value}` objects. Non-NULL values are exact strings, NULL is JSON null, binary is hexadecimal. Duplicate column names remain distinct because rows are positional arrays. Exports write to a temporary sibling file then atomically replace the chosen destination. Incomplete exports are explicitly identified in the export dialog and Messages; CSV/JSON files themselves contain only the selected data, not a completeness metadata field.

## Explorer and editor

Filter tables by name. Tables are alphabetically sorted; children load on expansion. Right-click a table or its groups to refresh that table and all related groups, copy the table name, or generate SELECT with LIMIT 100. Refresh connection reloads all collections. Group refresh deliberately refreshes the whole selected table to maintain a coherent cache. During concurrent DDL, a detected mismatch broadens refresh; if the catalog keeps changing, retry later.

Objects menu generates supported CREATE TABLE/INDEX/UNIQUE INDEX and rename templates. Review generated SQL before connecting/executing. Full CREATE reconstruction, INSERT/UPDATE wizards and unsupported SQL templates are not claimed. Ctrl+Space offers cached names and keywords, including columns after an exact table name plus dot. It is dismissible and never executes SQL. It does not resolve aliases or quote complex identifiers automatically; review insertions.

## Layout, history and local administration

View offers Dark, Light and System. Window size/maximized state, Explorer width and editor/results split persist in `layout-v2.json` next to `profiles.json` under the OS application-data PHOBOS/Studio directory. Corrupt layout settings fall back to bounded defaults. Window position, grid widths, documents, SQL history, query results, passwords and transactions are not restored.

Query → In-memory history shows the last 20 runs in the current tab. SQL may contain sensitive data; history is never saved automatically. Save SQL and export only to destinations you intend.

Connection → Local administration discovers registered Windows instances and offers Start/Stop/Restart with confirmation and UAC. Service actions may disconnect affected local tabs; reconnect explicitly. No local log viewer or Open Log Folder action is added in this milestone. Linux/macOS desktop execution has not been qualified.
