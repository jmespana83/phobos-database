# PHOBOS Community Edition 1.0.1 — Protocol

Protocol v1 is unchanged. TCP may be wrapped in TLS before framing. Header is 16 bytes: PHOB (4 ASCII bytes), version=1 (u8), type (u8), zero flags/reserved (2), request ID (u32 big-endian), payload length (u32 big-endian). Payload maximum: 1 MiB. Validate all fields and reject truncation/malformed input. One active request stream per connection.

Types: 1/2 Hello/HelloAck (UTF-8 capabilities, include stream=1); 3/4 Ping/Pong; 5/6 Auth/AuthOk (username NUL password); 10/11 legacy SQL/text result; 12 typed SQL stream; 13 start, 14 rows, 15 end, 16 command, 17 stream error; 20/21 metrics; 30/31 bulk; 40/41 reserve cancel handle; 42/43 cancel; 255 ordinary error.

Stream payload starts with u8 version=1. Start: u32 column count and length-prefixed UTF-8 labels. Rows: u64 batch sequence, u32 row count, rows. Row: u32 value count then typed values. End: u64 rows and batches. Command: length-prefixed tag plus u64 affected rows. Error: length-prefixed code/message. Strings/bytes use u32 byte lengths. Numeric encodings are big-endian. Batches contain 1..256 rows and target about 64 KiB.

Tags: 0 NULL; 1 i64; 2 Boolean byte; 3 IEEE f64 bits; 4 UTF-8 text; 5 binary; 6 signed i32 DATE days; 7 signed i64 TIMESTAMP microseconds; 8 signed i128 DECIMAL unscaled plus u8 scale. Date/time uses Unix epoch representation. Preserve decimal precision and NULL versus empty text. Source of truth: crates/phobos-protocol/src/streaming.rs and shipped .NET Core decoder.

Only valid End completes a result. Errors/disconnect/budget interruption leave partial rows incomplete. INSERT RETURNING uses the same typed stream; autocommit publication precedes delivery, so delivery failure does not imply rollback. Never automatically replay writes. Cancellation handles are opaque and session-scoped; use a separate authenticated channel. Cancellation can lose the race with commit admission. Discover features through Hello and SHOW CATALOG CAPABILITIES. Management is not a separate HTTP API. No ODBC/JDBC compatibility is claimed.

Studio 1.0.1 preserves a session after a fully decoded terminal statement-error frame with a recognized recoverable SQL code. Malformed framing/payloads, unknown/fatal codes, transport failures, cancellation and client result-budget interruption still dispose the unsafe session. Scripts stop at the failed statement; SQL is never replayed. Explicit transactions remain owned until COMMIT/ROLLBACK under the existing server contract; an aborted transaction requires ROLLBACK.
