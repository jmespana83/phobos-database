import struct
import unittest
from types import SimpleNamespace
import streaming

def blob(value):
    if isinstance(value,str):value=value.encode()
    return struct.pack('!I',len(value))+value

def frame(kind,payload,request=1):
    return [struct.pack('!4sBBHII',b'PHOB',1,kind,0,request,len(payload)),payload]

class Fake:
    def __init__(self,parts):
        self.parts=iter(parts);self.ident=0;self.closed=False
        self.sock=SimpleNamespace(sendall=lambda data:None)
    def receive(self,n):
        value=next(self.parts)
        if len(value)!=n:raise RuntimeError('truncated test transport')
        return value
    def close(self):self.closed=True

class StreamTests(unittest.TestCase):
    def test_all_types_and_embedded_delimiters(self):
        names=['n','i','b','f','t','x','d','ts','dec']
        start=b'\1'+struct.pack('!I',len(names))+b''.join(blob(n) for n in names)
        values=(b'\0'+b'\1'+struct.pack('!q',-7)+b'\2\1'+b'\3'+struct.pack('!d',1.5)
                +b'\4'+blob('a\t\n\0🙂')+b'\5'+blob(b'\0\xff')+b'\6'+struct.pack('!i',-1)
                +b'\7'+struct.pack('!q',2)+b'\10'+(-999).to_bytes(16,'big',signed=True)+b'\2')
        rows=b'\1'+struct.pack('!QI',0,1)+struct.pack('!I',len(names))+values
        end=b'\1'+struct.pack('!QQ',1,1)
        client=Fake(frame(13,start)+frame(14,rows)+frame(15,end))
        self.assertEqual(streaming.query(client,'SELECT * FROM t'),[['NULL','-7','true','1.5','a\t\n\0🙂','0x00ff','DATE(-1)','TIMESTAMP(2)','-9.99']])
        self.assertFalse(client.closed)
    def test_empty_and_command(self):
        start=b'\1'+struct.pack('!I',1)+blob('id')
        self.assertEqual(streaming.query(Fake(frame(13,start)+frame(15,b'\1'+struct.pack('!QQ',0,0))),'SELECT id FROM t'),[])
        self.assertEqual(streaming.query(Fake(frame(16,b'\1'+blob('UPDATE')+struct.pack('!Q',2))),'UPDATE t SET id=2'),[])
    def test_bad_peer_poisoned(self):
        start=b'\1'+struct.pack('!I',1)+blob('id')
        row=b'\1'+struct.pack('!QI',0,1)+struct.pack('!I',1)+b'\1'+struct.pack('!q',1)
        for parts in [
            frame(13,b'\2'),frame(13,b'\1'+struct.pack('!I',0xffffffff)),
            frame(13,start,request=99),frame(14,row),frame(13,start)+frame(13,start),
            frame(13,start)+frame(15,b'\1'+struct.pack('!QQ',1,0)),
            frame(13,start)+frame(17,b'\1'+blob('Io')+blob('late error')),
            frame(13,start)+frame(14,row[:-1]),
        ]:
            client=Fake(parts)
            with self.assertRaises((RuntimeError,StopIteration)):streaming.query(client,'SELECT * FROM t')
            self.assertTrue(client.closed)

if __name__=='__main__':unittest.main()
