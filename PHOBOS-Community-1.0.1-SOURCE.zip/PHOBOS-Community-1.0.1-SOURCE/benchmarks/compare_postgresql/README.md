# PostgreSQL comparison — measured campaign

PostgreSQL 18.6 was measured with this unchanged TCP driver at 100K, 1M, and 10M rows.
See `docs/postgresql_comparison_report.md` from the repository root and
`benchmarks/postgresql-results/` for raw results, settings, failures, and matched ratios.
Phobos full-result rejections are retained; this is not a complete parity or beta claim.
The recorded campaign used three samples, three operations, and four concurrent connections
on each engine. The five-sample examples below remain configurable reproduction examples.
The supplied cluster is already configured; do not rerun initialization against it.

Install the latest PostgreSQL 18.x maintenance release (18.6 at campaign date). Version 18
is supported through November 2030. [Version policy](https://www.postgresql.org/support/versioning/),
[Windows installer](https://www.postgresql.org/download/windows/),
[durability settings](https://www.postgresql.org/docs/18/runtime-config-wal.html).

Dedicated local setup; use an empty directory and check every command's exit code:

```powershell
$pg='C:\Program Files\PostgreSQL\18\bin'
& "$pg\initdb.exe" -D C:\phobos-benchmark\pgdata --data-checksums -U postgres -A scram-sha-256 -W
& "$pg\pg_ctl.exe" -D C:\phobos-benchmark\pgdata -l C:\phobos-benchmark\postgres.log -o '-p 55432 -h 127.0.0.1' start
& "$pg\createuser.exe" -h 127.0.0.1 -p 55432 -U postgres --pwprompt phobos_bench
& "$pg\createdb.exe" -h 127.0.0.1 -p 55432 -U postgres -O phobos_bench phobos_bench
```

Enter passwords interactively. Port 55432 avoids an installer-created service. Set in this
dedicated cluster's postgresql.conf and restart with pg_ctl:

```text
fsync = on
synchronous_commit = on
full_page_writes = on
shared_buffers = '128MB'
work_mem = '4MB'
max_connections = 20
max_parallel_workers_per_gather = 0
```

These memory settings are recorded configurations, not equivalent buffer architectures.
Place both databases on the same storage/filesystem. Match schemas, indexes, constraints,
datasets, batching, connections and TCP loopback transport. Driver selects PostgreSQL
SERIALIZABLE; Phobos uses coarse transaction-owner locking. Disclose this distinction and
never suppress serialization errors or silently retry them.

Install Python 3.11+, create a venv and retain the exact dependency versions:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install 'psycopg[binary]>=3.2,<4'
.\.venv\Scripts\python.exe -m pip freeze > benchmarks/results/python-lock.txt
$env:PGDATABASE='phobos_bench'
$env:PGUSER='phobos_bench'
$env:PGPASSFILE='C:\phobos-benchmark\pgpass.conf'
.\.venv\Scripts\python.exe benchmarks/compare_postgresql/compare.py --engine postgresql --host 127.0.0.1 --port 55432 --rows 100000 --samples 5 --operations 10 --connections 4 --out benchmarks/results/pg-100k
```

Secure pgpass.conf per libpq documentation; never commit it. Start a fresh Phobos server
and use the same driver from another terminal:

```powershell
cargo build --release --workspace
.\target\release\phobos-server.exe --bind 127.0.0.1:54321 --data-dir C:\phobos-benchmark\phobos-100k
.\.venv\Scripts\python.exe benchmarks/compare_postgresql/compare.py --engine phobos --host 127.0.0.1 --port 54321 --rows 100000 --samples 5 --operations 10 --connections 4 --out benchmarks/results/phobos-tcp-100k
```

Transport defaults to plaintext loopback. Phobos auth uses optional PHOBOS_USER /
PHOBOS_PASSWORD environment variables; PostgreSQL uses SCRAM. Connection setup is excluded.
This driver does not benchmark TLS. Configure equivalent security before authenticated/TLS
claims; do not disable configured engine security. Keep benchmark servers on loopback.

Phobos's 1MiB response limit makes some 100K+ full-result TCP queries fail. The driver
records failures and ends unsuccessfully with raw data retained. No silent pagination or
replacement of scans by COUNT hides these losses. Never compare embedded or Coordinator
timings directly with PostgreSQL TCP results. Both TCP adapters materialize all results.

Repeat from fresh databases at every scale. Keep raw output, versions, hardware, commands
and failures. Driver verifies fsync/full_page_writes/synchronous_commit/data_checksums=on.
Measure pg_stat_wal.wal_bytes deltas on an otherwise idle dedicated instance; pg_wal size
is not emitted volume. Startup/recovery require separate pg_ctl lifecycle experiments and
matched crash points; connection timing is not startup. These measurements remain pending.
