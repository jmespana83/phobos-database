import unittest
import compare

class GeneratorTests(unittest.TestCase):
    def test_same_seed_and_sql_as_rust(self):
        self.assertEqual(compare.insert('bench',0,1), "INSERT INTO bench VALUES (0,0,'p0000000000001f83')")
        self.assertEqual(compare.insert('bench',1,1), "INSERT INTO bench VALUES (1,1,'p5851f42d4c959eb0')")
    def test_batch_boundaries(self):
        text=compare.insert('bench',99,2)
        self.assertTrue(text.startswith('INSERT INTO bench VALUES (99,99,'))
        self.assertIn('),(100,0,',text)
    def test_error_frame_is_not_accepted(self):
        import struct
        client=object.__new__(compare.Phobos)
        client.ident=0
        class FakeSocket:
            def sendall(self,data): pass
        client.sock=FakeSocket()
        chunks=iter([struct.pack('!4sBBHII',b'PHOB',1,255,0,1,4),b'fail'])
        client.receive=lambda size: next(chunks)
        with self.assertRaisesRegex(RuntimeError,'fail'):
            client.message(10,b'SELECT 1')
    def test_mismatched_response_is_not_accepted(self):
        import struct
        client=object.__new__(compare.Phobos);client.ident=0
        class FakeSocket:
            def sendall(self,data): pass
        client.sock=FakeSocket()
        client.receive=lambda size: struct.pack('!4sBBHII',b'PHOB',1,11,0,99,0)
        with self.assertRaisesRegex(RuntimeError,'invalid Phobos response'):
            client.message(10,b'SELECT 1')

if __name__=='__main__': unittest.main()
