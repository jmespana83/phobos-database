"""Negotiated typed-result adapter for the existing collecting TCP comparison.
It preserves the SQL workload and deliberately collects, like the PostgreSQL adapter.
This is separate from the incremental-client memory acceptance harness.
"""
import math
import struct
from decimal import Decimal

class Reader:
    def __init__(self, data): self.data, self.offset = data, 0
    def take(self, size):
        if size < 0 or size > len(self.data)-self.offset: raise RuntimeError('truncated stream payload')
        value=self.data[self.offset:self.offset+size];self.offset+=size
        return value
    def number(self, code): return struct.unpack('!'+code,self.take(struct.calcsize('!'+code)))[0]
    def blob(self): return self.take(self.number('I'))
    def text(self): return self.blob().decode('utf-8')
    def end(self):
        if self.offset != len(self.data): raise RuntimeError('trailing stream bytes')
    def value(self):
        tag=self.number('B')
        if tag==0:return 'NULL'
        if tag==1:return str(self.number('q'))
        if tag==2:
            value=self.number('B')
            if value not in (0,1):raise RuntimeError('invalid stream boolean')
            return 'true' if value else 'false'
        if tag==3:
            value=self.number('d')
            if math.isnan(value):return 'NaN'
            if math.isinf(value):return str(value)
            text=format(Decimal(repr(value)),'f')
            return text.rstrip('0').rstrip('.') if '.' in text else text
        if tag==4:return self.text()
        if tag==5:return '0x'+self.blob().hex()
        if tag==6:return f"DATE({self.number('i')})"
        if tag==7:return f"TIMESTAMP({self.number('q')})"
        if tag==8:
            value=int.from_bytes(self.take(16),'big',signed=True);scale=self.number('B')
            digits=str(abs(value)).zfill(scale+1)
            return ('-' if value<0 else '')+(digits[:-scale]+'.'+digits[-scale:] if scale else digits)
        raise RuntimeError('unknown stream value type')

def query(client,sql):
    payload=sql.encode('utf-8')
    if len(payload)>1024*1024:raise RuntimeError('request exceeds Phobos protocol limit')
    client.ident+=1
    columns=None;rows=[];batches=0
    try:
        client.sock.sendall(struct.pack('!4sBBHII',b'PHOB',1,12,0,client.ident,len(payload))+payload)
        while True:
            magic,version,kind,flags,request,size=struct.unpack('!4sBBHII',client.receive(16))
            if (magic,version,flags,request)!=(b'PHOB',1,0,client.ident) or not 0<size<=1024*1024:
                raise RuntimeError('invalid stream frame')
            reader=Reader(bytes(client.receive(size)))
            if reader.number('B')!=1:raise RuntimeError('unsupported stream payload version')
            if kind==13:
                if columns is not None:raise RuntimeError('duplicate stream start')
                count=reader.number('I')
                if count>(len(reader.data)-reader.offset)//4:raise RuntimeError('invalid column count')
                columns=[reader.text() for _ in range(count)]
            elif kind==14:
                if columns is None or reader.number('Q')!=batches:raise RuntimeError('invalid stream sequence')
                count=reader.number('I')
                if not 0<count<=256:raise RuntimeError('invalid batch count')
                for _ in range(count):
                    if reader.number('I')!=len(columns):raise RuntimeError('invalid row width')
                    rows.append([reader.value() for _ in columns])
                batches+=1
            elif kind==15:
                if columns is None or (reader.number('Q'),reader.number('Q'))!=(len(rows),batches):raise RuntimeError('invalid stream totals')
                reader.end();return rows
            elif kind==16:
                if columns is not None:raise RuntimeError('command after stream start')
                reader.text();reader.number('Q');reader.end();return []
            elif kind==17:
                code,message=reader.text(),reader.text();reader.end()
                raise RuntimeError(code+': '+message)
            else:raise RuntimeError('unexpected stream message')
            reader.end()
    except Exception:
        client.close()
        raise
