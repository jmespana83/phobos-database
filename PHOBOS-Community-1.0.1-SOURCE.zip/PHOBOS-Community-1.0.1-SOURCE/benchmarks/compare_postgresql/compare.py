"""Matched TCP SQL workload driver. PostgreSQL results remain pending until actually run.
python compare.py --engine phobos --host 127.0.0.1 --port 54321 --rows 100000 --out results-phobos
python compare.py --engine postgresql --host 127.0.0.1 --port 5432 --rows 100000 --out results-pg
PG uses libpq environment variables PGDATABASE, PGUSER and PGPASSFILE (no passwords in logs).
Use fresh, dedicated databases on both engines. This script never drops existing tables.
"""
import argparse
import concurrent.futures
import csv
import json
import os
import platform
import socket
import struct
import threading
import time
from pathlib import Path

SEED = 8067
SCHEMA = 'CREATE TABLE bench (id BIGINT NOT NULL, bucket BIGINT NOT NULL, payload TEXT NOT NULL)'

def insert(table, start, count):
    return 'INSERT INTO ' + table + ' VALUES ' + ','.join(
        f"({i},{i%100},'p{(i*6364136223846793005+SEED)&((1<<64)-1):016x}')" for i in range(start, start+count))

class Phobos:
    def __init__(self, args):
        self.sock = socket.create_connection((args.host, args.port), timeout=120)
        self.ident = 0
        self.message(1, b'phase8-comparison')
        self.streaming = bool(getattr(args, 'phobos_streaming', False))
        if self.streaming:
            hello = self.message(1, b'phase8-comparison;stream=1')
            if 'stream=1' not in hello.split(';'):
                self.close()
                raise RuntimeError('server did not negotiate streaming')
            import importlib.util
            spec = importlib.util.spec_from_file_location('phobos_comparison_stream', Path(__file__).with_name('streaming.py'))
            self.stream_adapter = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.stream_adapter)
        if os.environ.get('PHOBOS_USER'):
            self.message(5, (os.environ['PHOBOS_USER']+'\0'+os.environ['PHOBOS_PASSWORD']).encode())
    def receive(self, size):
        data = bytearray()
        while len(data) < size:
            part = self.sock.recv(size-len(data))
            if not part:
                raise RuntimeError('Phobos closed the connection')
            data.extend(part)
        return data
    def message(self, kind, payload):
        self.ident += 1
        if len(payload) > 1024*1024:
            raise RuntimeError('request exceeds Phobos protocol limit')
        self.sock.sendall(struct.pack('!4sBBHII', b'PHOB', 1, kind, 0, self.ident, len(payload))+payload)
        magic, version, response, flags, request, length = struct.unpack('!4sBBHII', self.receive(16))
        if magic != b'PHOB' or version != 1 or request != self.ident or length > 1024*1024:
            raise RuntimeError('invalid Phobos response frame')
        text = self.receive(length).decode()
        if response == 255:
            raise RuntimeError(text)
        if response != {1:2,5:6,10:11}[kind]:
            raise RuntimeError('unexpected Phobos response type')
        return text
    def query(self, sql):
        if getattr(self, 'streaming', False):
            return self.stream_adapter.query(self, sql)
        text = self.message(10, sql.encode())
        if sql.lstrip().upper().startswith(('SELECT', 'EXPLAIN')):
            return [line.split('\t') for line in text.splitlines()[1:]]
        return []
    def close(self):
        self.sock.close()

class PostgreSQL:
    def __init__(self, args):
        import psycopg
        self.connection = psycopg.connect(host=args.host, port=args.port, autocommit=True)
        self.query("SET default_transaction_isolation = 'serializable'")
        self.query("SET synchronous_commit = on")
    def query(self, sql):
        with self.connection.cursor() as cursor:
            cursor.execute(sql)
            return [[str(v) if v is not None else 'NULL' for v in row] for row in cursor.fetchall()] if cursor.description else []
    def close(self):
        self.connection.close()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--engine', choices=['phobos','postgresql'], required=True)
    p.add_argument('--host',default='127.0.0.1')
    p.add_argument('--port',type=int,required=True)
    p.add_argument('--rows',type=int,default=100000)
    p.add_argument('--samples',type=int,default=5)
    p.add_argument('--operations',type=int,default=10)
    p.add_argument('--connections',type=int,default=4)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--phobos-streaming',action='store_true',help='Explicit negotiated Phobos transport; still collects like the PostgreSQL adapter')
    args=p.parse_args()
    if args.rows<100 or args.samples<1 or args.operations<1 or args.operations>args.rows or args.connections<1:
        p.error('invalid rows/samples/operations/connections')
    if args.phobos_streaming and args.engine!='phobos':p.error('--phobos-streaming requires --engine phobos')
    args.out.mkdir(parents=True,exist_ok=False)
    factory=Phobos if args.engine=='phobos' else PostgreSQL
    db=factory(args)
    metadata=dict(engine=args.engine,platform=platform.platform(),python=platform.python_version(),rows=args.rows,seed=SEED,samples=args.samples,operations=args.operations,connections=args.connections,transport=('TCP loopback, negotiated typed streaming; client materializes all results' if args.phobos_streaming else 'TCP loopback, client materializes all results'),authentication='connection setup excluded; configure equivalent TLS/auth policy',isolation='Phobos strict transaction-owner locking; PostgreSQL SERIALIZABLE',cache='warm query run, no OS cache eviction',postgresql_results='not run; use the frozen historical baseline' if args.engine=='phobos' else 'measured by this run')
    if args.engine=='postgresql':
        metadata['version']=db.query('SELECT version()')
        for setting in ['fsync','full_page_writes','synchronous_commit','default_transaction_isolation','shared_buffers','work_mem','max_connections','wal_level','data_checksums','max_parallel_workers_per_gather']:
            metadata[setting]=db.query('SHOW '+setting)[0][0]
        for setting in ['fsync','full_page_writes','synchronous_commit','data_checksums']:
            if metadata[setting]!='on':
                raise RuntimeError('durability/integrity mismatch: '+setting)
    else:
        metadata['version']='Phobos alpha; record source hash from run-benchmarks.ps1'
    (args.out/'environment.json').write_text(json.dumps(metadata,indent=2))
    errors=[]
    with (args.out/'raw.csv').open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['engine','workload','sample','rows','operations','elapsed_ns','status','detail'])
        def timed(name,sample,fn,operations=1):
            start=time.perf_counter_ns()
            try:
                value=fn()
            except Exception as exc:
                writer.writerow([args.engine,name,sample,args.rows,operations,time.perf_counter_ns()-start,'error',str(exc)])
                f.flush()
                raise
            writer.writerow([args.engine,name,sample,args.rows,operations,time.perf_counter_ns()-start,'ok',''])
            f.flush()
            return value
        db.query(SCHEMA)
        db.query('CREATE UNIQUE INDEX bench_id ON bench (id)')
        # Pre-generate exactly the same 1000-row INSERT statements on both engines.
        statements=[insert('bench',i,min(1000,args.rows-i)) for i in range(0,args.rows,1000)]
        def load():
            db.query('BEGIN')
            for sql in statements: db.query(sql)
            db.query('COMMIT')
        timed('bulk_load',0,load,len(statements))
        assert db.query('SELECT COUNT(*) AS n FROM bench')==[[str(args.rows)]]
        db.query('CREATE TABLE dimension (id BIGINT NOT NULL, bucket BIGINT NOT NULL, payload TEXT NOT NULL)')
        db.query(insert('dimension',0,100))
        queries=[('indexed_point',f'SELECT * FROM bench WHERE id={args.rows//2}',1),('indexed_range','SELECT * FROM bench WHERE id>=10 AND id<30',20),('full_scan','SELECT * FROM bench',args.rows),('scan_aggregate','SELECT COUNT(*) AS n FROM bench',1),('join','SELECT bench.id AS id FROM bench INNER JOIN dimension ON bench.bucket=dimension.id',args.rows),('group_aggregate','SELECT bucket AS bucket, COUNT(*) AS n FROM bench GROUP BY bucket',100),('sort_spill','SELECT id AS id, payload AS payload FROM bench ORDER BY payload DESC',args.rows)]
        for name,sql,expected in queries:
            try:
                warm=db.query(sql)
                assert len(warm)==expected
                for sample in range(args.samples):
                    value=timed(name,sample,lambda: db.query(sql))
                    assert len(value)==expected
            except Exception as exc:
                errors.append((name,str(exc)))
                writer.writerow([args.engine,name,-1,args.rows,1,0,'unsupported_or_failed',str(exc)])
                # A protocol-size error is a reported loss/limitation, never silently paginated.
                db.close(); db=factory(args)
        next_id=args.rows
        for name in ['autocommit_insert','transaction_insert','update','delete']:
            for sample in range(args.samples):
                first=next_id
                statements=[insert('bench',first+i,1) if 'insert' in name else (f"UPDATE bench SET payload='updated' WHERE id={i}" if name=='update' else f'DELETE FROM bench WHERE id={i}') for i in range(args.operations)]
                def mutate():
                    if name=='transaction_insert': db.query('BEGIN')
                    for sql in statements: db.query(sql)
                    if name=='transaction_insert': db.query('COMMIT')
                timed(name,sample,mutate,args.operations)
                expected=args.rows+(args.operations if 'insert' in name else -args.operations if name=='delete' else 0)
                assert db.query('SELECT COUNT(*) AS n FROM bench')==[[str(expected)]]
                if 'insert' in name: db.query(f'DELETE FROM bench WHERE id>={first}')
                elif name=='delete': db.query(insert('bench',0,args.operations))
                else:
                    for i in range(args.operations): db.query(f"UPDATE bench SET payload='p{(i*6364136223846793005+SEED)&((1<<64)-1):016x}' WHERE id={i}")
                next_id+=args.operations
        for name in ['concurrent_readers','concurrent_writers','mixed']:
            for sample in range(args.samples):
                first=next_id
                barrier=threading.Barrier(args.connections+1, timeout=120)
                clients=[factory(args) for _ in range(args.connections)]
                def worker(index):
                    client=clients[index]
                    statements=[f'SELECT id FROM bench WHERE id={(i*7919+index)%args.rows}' if name=='concurrent_readers' or (name=='mixed' and index%2==0) else insert('bench',first+index*args.operations+i,1) for i in range(args.operations)]
                    barrier.wait()
                    for sql in statements: client.query(sql)
                with concurrent.futures.ThreadPoolExecutor(max_workers=args.connections) as pool:
                    futures=[pool.submit(worker,i) for i in range(args.connections)]
                    def run_concurrent():
                        barrier.wait()
                        for future in futures: future.result()
                    timed(name,sample,run_concurrent,args.operations*args.connections)
                for client in clients: client.close()
                writers=0 if name=='concurrent_readers' else args.connections//2 if name=='mixed' else args.connections
                assert db.query('SELECT COUNT(*) AS n FROM bench')==[[str(args.rows+writers*args.operations)]]
                if writers: db.query(f'DELETE FROM bench WHERE id>={first}')
                next_id+=args.connections*args.operations
    db.close()
    (args.out/'limitations.json').write_text(json.dumps({'failed_workloads':errors,'startup_recovery':'Use dedicated service lifecycle runs; not SQL session connection time. PostgreSQL lifecycle comparison pending.','wal_volume':'Use pg_stat_wal delta on an otherwise idle dedicated instance; Phobos profile event wal.bytes counts emitted records. Do not compare retained WAL file sizes.','physical_limits':('Phobos negotiated stream: 1MiB cap per frame, bounded batches; comparison client intentionally collects all rows.' if args.phobos_streaming else 'Phobos protocol max payload is 1MiB. Full result workloads exceeding it are recorded as failures, not changed into aggregates.'),'comparison':'Only compare matched TCP driver results; embedded Rust benchmark is a separate engine-only experiment.'},indent=2))
    if errors: raise SystemExit('Some workloads failed; see raw.csv and limitations.json. No complete comparison claim.')

if __name__=='__main__': main()
