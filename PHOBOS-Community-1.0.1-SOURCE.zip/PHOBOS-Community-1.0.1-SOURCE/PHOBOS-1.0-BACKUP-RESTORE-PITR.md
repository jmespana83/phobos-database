# PHOBOS Community Edition 1.0.1 — Backup Restore Pitr

Use fresh destinations and stop/wait for clean shutdown before offline operations:

```text
phobos-admin check DATA
phobos-admin backup DATA BACKUP
phobos-admin restore BACKUP RESTORED_DATA
phobos-admin check RESTORED_DATA
```

Identity counters travel as ordinary transactional rows; FK/view/default/check/PK metadata travels with catalog/WAL. External auth, TLS, runtime and service configuration is separate and must be preserved securely. Restores require compatible binaries/catalogs.

PITR requires a valid base backup, complete retained/archived WAL and a target committed LSN. Targets are LSN-based, not an invented wall-clock conversion. Establish retention before WAL retirement. Missing/corrupt segments fail closed. Rehearse into a new directory, run integrity/application queries, then deliberately switch traffic. Never overwrite the primary for a rehearsal. Exact command syntax is in phobos-admin usage/source and REPLICATION. No scheduler or automatic failover is added.

CLI PITR workflow (stop the primary for backup-base and offline administrative steps):

```text
phobos-admin backup-base DATA NEW_BASE
phobos-admin wal-retain DATA NEW_BASE pitr_slot
# Resume the primary, perform desired work, then stop it gracefully.
phobos-admin replication-status DATA
phobos-admin wal-archive DATA NEW_ARCHIVE
phobos-admin recover-to NEW_BASE NEW_ARCHIVE NEW_RECOVERED TARGET_COMMITTED_LSN
phobos-admin check NEW_RECOVERED
```

backup-base exposes the existing checkpointed online-backup implementation through an offline CLI owner; it creates the PHOBOS_BACKUP_2 end-LSN marker required by PITR/replication. Ordinary backup remains an offline restore image and is not a substitute for that marker. Keep retention until recovery/replica requirements are satisfied.
