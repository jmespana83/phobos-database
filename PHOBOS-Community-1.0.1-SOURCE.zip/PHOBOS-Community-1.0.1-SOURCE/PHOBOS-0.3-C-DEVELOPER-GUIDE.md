# PHOBOS Studio 0.3-C — Developer guide

Read the architecture document for protocol/session/UI/platform separation. The core targets net10.0 with no Windows dependency. The Avalonia app selects its platform at runtime. Windows API calls are isolated in WindowsInstances.cs. A future systemd/launchd implementation replaces only ILocalInstances; it must preserve least privilege and graceful native lifecycle.

## Exact Windows build commands

From the extracted source directory, with the validated workspace tools:

```powershell
$dotnet = 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\dotnet\dotnet.exe'
& $dotnet build .\studio\Phobos.Studio\Phobos.Studio.csproj -c Release
& .\packaging\studio\build.ps1 `
  -Dotnet $dotnet `
  -Iscc 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\inno\ISCC.exe' `
  -StageDirectory 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03c' `
  -OutputDirectory 'C:\Users\195doctor\Documents\Codex\2026-10-23\outputs'
```

SDK: 10.0.402. Inno: 6.7.3. Use the specified SDK executable or install the compatible SDK normally. NuGet needs network access on first restore. Committed packages.lock.json files pin the application dependencies. Publish is self-contained win-x64, without trimming, single-file extraction or ReadyToRun; server binaries are not included. Production dispatch does not enable the GUI evidence harness. Never overwrite the accepted 0.3-A/0.3-B artifacts.

For development on a supported Linux/macOS host, use `dotnet run --project studio/Phobos.Studio/Phobos.Studio.csproj`. Publishing for another RID is structurally possible with normal .NET publish, but requires target-specific package/GUI testing. No Linux/macOS binary is delivered or qualified here. The Windows installer script is not the cross-platform build system.

## Client / integration validation

```powershell
$env:DOTNET_ROOT = 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\dotnet'
& "$env:DOTNET_ROOT\dotnet.exe" build .\studio\Phobos.Studio\Phobos.Studio.csproj -c Release -p:StudioValidation=true
& "$env:DOTNET_ROOT\dotnet.exe" run --project .\tools\studio-validation\StudioValidation.csproj -c Release -- `
  'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b\bin' `
  'C:\Users\195doctor\Documents\Codex\2026-10-23\validation-03c\NEW-RUN' `
  'C:\Users\195doctor\Documents\Codex\2026-10-23\work\PHOBOS-Community-0.3-C-ManagementStudio-SOURCE\studio\Phobos.Studio\bin\Release\net10.0\PHOBOS-Studio.exe'
& "$env:DOTNET_ROOT\dotnet.exe" run --project .\tools\studio-validation\StudioValidation.csproj -c Release -- --protocol-faults
```

Use a genuinely fresh evidence directory; the harness refuses existing state. It generates the password in memory, initializes a private instance with the accepted admin tool, passes credentials through anonymous stdin to the GUI harness, and uses only the public protocol for database operations. It deliberately kills only its own isolated test server to verify disconnect/WAL recovery, then shuts down and runs offline integrity. Do not point it at a primary database. The compiled validation-only UI dispatch renders actual controls; production builds must use StudioValidation=false.

## Windows local-service validation

Build `tools/studio-validation/windows/WindowsValidation.csproj`. The runner arguments are: accepted 0.3-B installer, Studio validation executable, evidence directory. It requires an elevated Windows token and only targets fixed `C:\Program Files\PHOBOS-03C-Validation` and `C:\ProgramData\PHOBOS-03C-Validation` paths. It refuses preexisting paths. The included run-local.ps1 records the exact command used on this host. Because retained test data now exists, do not repeat it without explicitly choosing new dedicated paths in a reviewed test fixture; never delete the old data silently.

The runner installs the accepted server package, configures credentials over stdin, exercises the production adapter/helper and reconnect, captures service status, and invokes the accepted uninstaller. Data is always retained. A fresh primary server installation must never be selected by a fixture.

## Packaging verification / source archive

The release finalizer verifies the complete 0.3-A and 0.3-B output hash manifests, compares every baseline crate/build input and Windows packaging file, copies selected non-secret evidence, creates the changed-file manifest and source ZIP, checks ZIP CRCs and produces an external SHA-256 manifest. It excludes build outputs, local databases, auth files and NuGet caches. See `tools/studio-validation/finalize.py`; invoke with the workspace root as its argument. It assumes the accepted outputs and runtime-03c publish stage are present.

Inno is only a standalone distribution wrapper; a future combined installer should offer Studio as a separate optional component. Do not modify the accepted server installer's AppId, lifecycle or data-retention semantics to add the GUI.

## Maintenance

No network call may block the UI dispatcher. No protocol operation may parse database files or invoke the CLI. Preserve strict framing and fail-closed stream state; do not reuse poisoned sessions. Add capability gating instead of guessing new server SQL support. Keep credentials absent from profiles and logs. Do not automatically replay failed SQL. Test typed values and cancellation against an unchanged real engine after protocol-layer edits.

Source hyperlinks and dependency notices are included in PHOBOS-0.3-C-THIRD-PARTY-NOTICES.md and packaging/studio/licenses. The D-Bus 0.21.3 override is security-motivated; do not drop it without a verified newer safe dependency graph.
