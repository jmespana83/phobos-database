# PHOBOS Community Edition 1.0.1 — Sql Compatibility

Baseline retained: CREATE TABLE, CREATE [UNIQUE] INDEX, DROP INDEX; INSERT VALUES/column lists, UPDATE, DELETE; SELECT projection/filter/order/limit/offset, DISTINCT, aggregates/GROUP BY/HAVING; aliases and INNER/LEFT/CROSS stored-table joins; scalar/IN subqueries; read-only nonrecursive CTEs/derived inputs; transactions/savepoints; SHOW CATALOG.

| New/promoted SQL | Supported scope |
|---|---|
| DEFAULT / CHECK / PRIMARY KEY | Literal defaults; column-versus-literal checks; single/composite PK |
| IDENTITY | One BIGINT BY DEFAULT or ALWAYS column per table |
| INSERT RETURNING | Columns or *, multi-row VALUES/SELECT, typed result stream |
| FOREIGN KEY | Table-level single/composite keys to an exact unique/PK index; immediate RESTRICT/NO ACTION |
| INSERT SELECT | Snapshot materialization, type/default/identity/constraint checking and atomic writes |
| SELECT without FROM | Constants/functions and statement-stable CURRENT_TIMESTAMP |
| UNION / UNION ALL | Column/type compatibility, NULL deduplication, INT/DOUBLE promotion |
| Correlated EXISTS | Practical WHERE EXISTS/NOT EXISTS with qualified outer references |
| CREATE/DROP VIEW | Durable read-only SELECT/CTE definitions and dependency protection |
| ALTER TABLE | Rename; SET/DROP DEFAULT; SET/DROP NOT NULL; ADD COLUMN on physically empty tables |

Partial: views/derived inputs/CTEs materialize; joins over their outputs are unsupported (put stored-table joins inside the definition). Correlated scalar/IN/LATERAL is not implemented. Use unique AS labels for view expressions. ADD COLUMN rejects populated tables and retained physical tuple versions; no backfill/rewrite. Nullability checks visible rows. UNION global ORDER/LIMIT/OFFSET belongs to the final operand; decimal scales must be compatible. RETURNING accepts no arbitrary expressions/aliases. General joins/set queries retain memory/collecting limitations.

Identity rollback/savepoint rollback may reuse uncommitted numbers; deletes do not reset the counter. Explicit BY DEFAULT IDs do not advance it and may collide with future generated IDs; PK/UNIQUE catches the collision. ALWAYS rejects explicit INSERT and identity UPDATE. Maximum generated value is i64::MAX-1. No public reset/start/increment/sequence syntax.

FKs use MATCH SIMPLE: any NULL child component skips checking. All writer transactions serialize in FK databases; validation scans can be expensive. Bulk import is rejected in FK databases and on identity tables; use INSERT/INSERT SELECT. CASCADE/SET NULL/deferred constraints and ALTER ADD/DROP CONSTRAINT are unsupported.

Types: BIGINT/INTEGER (64-bit), BOOLEAN, DOUBLE/FLOAT/REAL, TEXT/VARCHAR, BINARY/BLOB, DATE, TIMESTAMP, DECIMAL/NUMERIC(p,s). VARCHAR is not length-enforced. No UUID/JSON types.

Unsupported: SQL CREATE ROLE/GRANT/REVOKE (external coarse roles exist), temp tables, RIGHT/FULL/NATURAL/USING joins, recursive/writable CTEs, UPDATE/DELETE RETURNING, INTERSECT/EXCEPT, window functions, DROP COLUMN, arbitrary type conversion, DROP TABLE, schemas/multiple databases, stored procedures/triggers, materialized views, information_schema SELECT views.

Parser/expression nesting is now limited to 32, a correctness-driven reduction from 64 to avoid Windows stack exhaustion. Long UNION chains fail incrementally. Existing 64-CTE-binding/expanded-AST budgets remain. This is not full SQL-standard compatibility.
