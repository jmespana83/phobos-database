# PHOBOS 0.3-F test results

Executed on Windows x64, October 26, 2026. **Decision B: installer hotfix accepted with engine A; E engine promotion held by performance.** No identity/RETURNING implementation is included.

## Fresh engine and client checks

- Pinned Rust 1.85.0 workspace: **608 passed, 0 failed, 4 inherited ignored**. Top-level harness results are counted once; one nested subprocess result is not double-counted as another independent test.
- `cargo fmt --all --check`: PASS.
- `cargo clippy --workspace --all-targets --all-features --locked --offline -- -D warnings`: PASS.
- All eleven schema-v2 parser/catalog/execution/recovery integration tests: PASS.
- Release-binary schema/default/CHECK/PK/transactional rename/crash/restart/backup/restore/integrity smoke: PASS.
- Unchanged Studio D Core client against E: PASS COMPLETE. Covered typed values, metadata, new default/constraint metadata, scripts, transaction isolation/rollback, cancellation, result budgets, malformed frames, wrong authentication, abrupt fixture-server termination, explicit reconnect, no replay, documents/profiles without credentials and final offline integrity. This client harness is distinct from the actual installed-Studio acceptance against A.

| Test target | Passed | Ignored |
|---|---:|---:|
| phobos-admin | 23 | 0 |
| phobos-auth | 2 | 0 |
| phobos-bench | 1 | 0 |
| phobos-catalog | 6 | 0 |
| phobos-cli | 2 | 0 |
| phobos-client | 2 | 0 |
| phobos-config | 3 | 0 |
| phobos-error | 1 | 0 |
| phobos-execution | 216 | 0 |
| Running tests\enterprise_functions.rs | 2 | 0 |
| phobos-index | 34 | 0 |
| phobos-protocol | 5 | 0 |
| phobos-server | 101 | 0 |
| Running tests\a5_startup.rs | 1 | 0 |
| Running tests\c6_acceptance.rs | 2 | 0 |
| phobos-sql | 9 | 0 |
| Running tests\a2_depth.rs | 2 | 0 |
| phobos-storage | 62 | 0 |
| phobos-txn | 46 | 0 |
| phobos-types | 3 | 0 |
| phobos-validation | 9 | 3 |
| phobos-wal | 76 | 1 |

Inherited optional tests not executed:

- tests::concurrent_writer_soak ... ignored, longer concurrent write soak; run from tools/full-validation.ps1
- tests::deterministic_restart_soak ... ignored, longer deterministic restart/transaction soak; run from tools/full-validation.ps1
- tests::phase6_external_sort_and_grouping_soak ... ignored, Phase 6 spill/aggregate soak; run explicitly after routine gates
- v2::delta::delta_bench ... ignored, benchmark: needs PHOBOS_DELTA_PAIRS

## Installer and product acceptance

The real normal elevated default-path clean-install journey passed with user participation: visible configuration, initialized service, authenticated readiness, actual Studio SQL/catalog/results, restart/reconnect/data survival, normal repair, and server uninstall preserving data and Studio. The original user instance was backed up before testing, restored/verified afterward, and remains running with its original credentials.

Custom-path FILESONLY lifecycle, occupied-port/wrong-password/runtime-config cases, service crash containment, protected ACLs and plaintext-secret absence checks passed. Six deterministic configure interruption boundaries passed. Final-code normal interactive cancellation passed with no instance/service and an explicit incomplete-setup notice. The build guard rejects experimental E binaries before compilation/packaging. Detailed provenance and gaps are in INSTALLER-TEST-RESULTS.md; these are not automated-only claims.

Final packaging preserves the exact already validated runtime executable bytes, verifies accepted engine hashes, runs the native self-test and confirms no public test callback field exists in the production manager. The final installer is repacked with final documentation. Its source visibility/owner/progress/FILESONLY/exit-status regression assertions pass. Initial real clean/repair acceptance preceded service compensation; later lifecycle/fault automation and normal interactive cancel used the final compensation code. The full initial journey was not repeated byte-for-byte on the final documentation-repacked installer.

## Performance and correctness evidence

- Five balanced full Standard pairs: ten successful runs, 380 raw records ok, zero query errors, all six query hashes matched on every run.
- Seven schema-feature microbenchmark pairs: 140 samples, 133,007 attempted operations, 7,007 expected CHECK rejections, count/sum and offline integrity pass in all 14 instances.
- Seven accepted-A/A calibration pairs: 28 samples, identical server hash on both labels, all 14 instances pass integrity.
- Three separate trace pairs: 12 samples, six fresh instances pass integrity; trace windows contain exactly 3,000 autocommit and 3,006 batch request records per role.
- Native catalog/Arc/component profile: seven samples per component, release build; diagnostic only.

Performance gate remains HELD: fresh Standard autocommit median +13.8%, single-transaction INSERT +6.1%. Large identical-binary variability does not override the failed gate. Detailed raw runs, all outliers and failed early micro harness attempts remain available. No durability change or speculative engine optimization was made.

## Known gaps

Four inherited optional soak/benchmark tests were not run. Abrupt file-copy interruption, OS/process termination at every installer boundary and successful custom-path interactive initialization remain untested. Linux/macOS runtime/GUI/installer qualification was not executed. Explicit A-server catalog-format/identity/RETURNING capability rows remain deferred. Identity/sequences/RETURNING have no implementation or test claim.

The source archive retains every baseline file and every inherited Rust file unchanged. Source ZIP CRC and accepted A–E artifact hashes are checked during final packaging. The final hash manifest is external to avoid circular self-hashing. Evidence uses an explicit file allowlist: no auth files, databases or credential/profile stores are published.
