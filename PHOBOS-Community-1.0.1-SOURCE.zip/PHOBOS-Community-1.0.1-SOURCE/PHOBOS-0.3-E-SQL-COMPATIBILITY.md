# PHOBOS 0.3-E SQL compatibility

This is a restricted enterprise-schema increment, not enterprise SQL completion. New durable DDL requires the MVCC/server route. Existing 0.3-A queries and 0.3-B/D product boundaries remain inherited.

| Feature | Status | Scope |
|---|---|---|
| Durable schema definitions | Supported | Catalog v4, transactional WAL metadata publication |
| DEFAULT | Partial | Column literals, optional numeric negation, existing assignment coercions; omitted INSERT column lists only |
| CHECK | Partial | column = / <> / < / <= / > / >= literal; column IS NULL / IS NOT NULL; inline or table-level; multiple clauses |
| PRIMARY KEY | Supported within CREATE TABLE | Inline single column or table-level ordered composite key; one key/table; generated backing unique index; implicit NOT NULL |
| ALTER DEFAULT | Supported | ALTER TABLE t ALTER COLUMN c SET DEFAULT literal / DROP DEFAULT; transactionally; no row rewrite |
| ALTER rename | Supported, inherited | Table/column rename preserves new definitions by ID/ordinal |
| ALTER add/drop column, nullability, constraints, types | Deferred | Rejected; needs physical/dependency work |
| Identity / sequences | Deferred | Rejected; no MAX+1 implementation |
| Foreign keys | Deferred | Rejected; no unenforced declarations |
| Persistent views | Deferred | Rejected |
| INSERT SELECT | Deferred | Rejected |
| RETURNING | Deferred | Rejected |
| Correlated subqueries | Deferred | Outer references are rejected |
| UNION / UNION ALL / INTERSECT / EXCEPT | Deferred | Rejected |
| Window functions | Deferred | Rejected |
| Temporary tables | Deferred | Rejected |
| SELECT without FROM | Deferred | Rejected |
| CURRENT_TIMESTAMP / CURRENT_DATE defaults | Deferred | Nonliteral default expressions rejected |
| New physical data types/functions | Deferred | No additions in 0.3-E |
| Aliases, self/INNER/LEFT/CROSS joins | Supported within inherited 0.3-A scope | Existing query binding/resource rules |
| Uncorrelated scalar/EXISTS subqueries, CTEs, derived SELECT | Partial, inherited | Nonrecursive, read-only; see 0.3-A compatibility limits |
| UNIQUE indexes, transactions, savepoints, MVCC | Supported, inherited | Schema transactions retain existing savepoint restrictions |

## Examples

```sql
CREATE TABLE accounts (
  tenant BIGINT,
  id BIGINT,
  balance DECIMAL(18,2) DEFAULT 0,
  active BOOLEAN DEFAULT TRUE,
  label TEXT DEFAULT 'new',
  PRIMARY KEY (tenant,id),
  CHECK (balance >= 0)
);
INSERT INTO accounts (tenant,id) VALUES (1,10);
INSERT INTO accounts (tenant,id,balance) VALUES (1,11,NULL);
-- Explicit NULL remains NULL; CHECK comparison is UNKNOWN and passes.
-- NOT NULL, if declared, would independently reject it.
BEGIN;
ALTER TABLE accounts ALTER COLUMN balance SET DEFAULT 25;
INSERT INTO accounts (tenant,id) VALUES (1,12);
ROLLBACK;
-- Both the row and the default change are rolled back.
ALTER TABLE accounts RENAME COLUMN balance TO amount;
ALTER TABLE accounts ALTER COLUMN amount DROP DEFAULT;
SHOW CATALOG COLUMNS FROM accounts;
SHOW CATALOG CONSTRAINTS FROM accounts;
```

Literal defaults include numeric, Boolean, text and NULL; DATE/TIMESTAMP/DECIMAL/BINARY use the existing assignment conversions from literals. Overflow and incompatible types are rejected at DDL. DEFAULT NULL on a NOT NULL or primary-key column is rejected at DDL. Defaults do not bypass CHECK or NOT NULL. A default may satisfy its type yet violate a CHECK; CREATE/ALTER is allowed, and an INSERT using that value fails. SET DEFAULT does not backfill existing rows. DROP DEFAULT on a column without a default is an idempotent operation.

CHECKs use existing canonical comparison semantics, including exact mixed BIGINT/DOUBLE boundaries. IS NULL and IS NOT NULL produce true/false; ordinary comparisons involving NULL produce UNKNOWN and pass. Each violating INSERT/UPDATE is atomic, and existing explicit-transaction error handling remains unchanged. No constraint is silently skipped by bulk imports.

Not supported: named CONSTRAINT syntax, explicit DEFAULT in VALUES, INSERT DEFAULT VALUES, expressions/functions in DEFAULT, arbitrary Boolean/arithmetic CHECK trees, adding/dropping a CHECK/PK after CREATE, deferrable constraints, identity overrides, or schema definitions on partitioned parents/children. Use multiple simple CHECK clauses for conjunction. Primary-key generated indexes appear in metadata and cannot be dropped directly. Generated names may collide with user-created index names; the entire CREATE then fails atomically.

Catalog v4 cannot be opened by an older engine. Keep a pre-upgrade backup; never point an older binary at an upgraded live directory. New DDL does not modify heap/index/WAL/protocol formats. Management metadata is additive API v1; 0.3-D Studio disables its engine-specific templates on the unknown feature version while retaining SQL/catalog operations.
