//! Targeted writeback runs without database ownership. A completion reports a
//! conservative recovery frontier, never permission to discard a transaction
//! containing an outstanding page dependency.
use super::*;

#[derive(Clone, Copy)]
pub(super) struct Checkpoint {
    target: u64,
    file_cursor: u64,
}

impl CommittedStore {
    pub fn request_checkpoint(&self, target: u64) -> Result<()> {
        let mut state = self.inner.lock()?;
        state.check()?;
        if state.checkpoint.is_none() && state.checkpoint_ready.is_none() {
            state.checkpoint = Some(Checkpoint {
                target,
                file_cursor: 0,
            });
            state.wake_requested = true;
            self.inner.changed.notify_one();
            phobos_observability::event("checkpoint.requests", 1);
        }
        Ok(())
    }

    /// Called under publication ownership. Later publications can only add
    /// dependencies beyond this captured target.
    pub fn take_checkpoint(&self) -> Result<Option<(u64, u64)>> {
        let mut state = self.inner.lock()?;
        state.check()?;
        Ok(state.checkpoint_ready.take())
    }

    /// 0.2-C: (a page checkpoint is requested or running, a completed one
    /// awaits `take_checkpoint`). Read-only; used to schedule quiescent
    /// checkpoint advancement without draining the commit pipeline needlessly.
    pub fn checkpoint_progress(&self) -> Result<(bool, bool)> {
        let state = self.inner.lock()?;
        state.check()?;
        Ok((state.checkpoint.is_some(), state.checkpoint_ready.is_some()))
    }

    pub fn cancel_checkpoint(&self) -> Result<()> {
        let mut state = self.inner.lock()?;
        state.check()?;
        state.checkpoint = None;
        state.checkpoint_ready = None;
        Ok(())
    }
}

impl Inner {
    pub(super) fn checkpoint_batch(&self) -> Result<bool> {
        let Some(job) = self.lock()?.checkpoint else {
            return Ok(false);
        };
        let _span = phobos_observability::span("checkpoint.background");
        let _activity = phobos_observability::trace::activity(
            &phobos_observability::trace::CHECKPOINT_ACTIVITY,
        );
        phobos_observability::synchronization_boundary(
            "checkpoint.target_captured",
            &self.directory,
        );
        phobos_observability::synchronization_boundary("c4_before_target_flush", &self.directory);
        phobos_observability::certification_crash("c4_before_target_flush");
        for _ in 0..self.config.batch_pages {
            if !self.flush_target(None, "checkpoint_drain", Some(job.target))? {
                break;
            }
            phobos_observability::event("checkpoint.batch_pages", 1);
        }
        // At most one file force per batch. No directory mutex is held across
        // I/O; the file guard orders concurrent eviction/writeback and forcing.
        let selected = {
            let mut state = self.lock()?;
            if state.frames.values().any(|f| f.page_lsn <= job.target) {
                return Ok(true);
            }
            let selected = state
                .files
                .range((
                    std::ops::Bound::Excluded(job.file_cursor),
                    std::ops::Bound::Unbounded,
                ))
                .next()
                .map(|(id, f)| (*id, Arc::clone(&f.handle)));
            if let Some((id, _)) = &selected {
                if state.inflight.iter().any(|(file, _)| file == id) {
                    return Ok(true);
                }
                state.forcing.insert(*id);
            }
            selected
        };
        if let Some((id, handle)) = selected {
            let io = handle.snapshot()?;
            if self
                .lock()?
                .files
                .get(&id)
                .is_some_and(|f| f.unforced_rec_lsn.is_some())
            {
                phobos_observability::measure("checkpoint.data_force", || {
                    io.sync_all().map_err(PhobosError::from)
                })?;
                if let Some(file) = self.lock()?.files.get_mut(&id) {
                    file.unforced_rec_lsn = None;
                }
            }
            let mut state = self.lock()?;
            state.forcing.remove(&id);
            if let Some(current) = state.checkpoint.as_mut().filter(|c| c.target == job.target) {
                current.file_cursor = id;
            }
        } else {
            let mut state = self.lock()?;
            if state.checkpoint.is_some_and(|c| c.target == job.target) {
                let minimum = state
                    .frames
                    .values()
                    .map(|f| f.rec_lsn)
                    .chain(state.files.values().filter_map(|f| f.unforced_rec_lsn))
                    .min();
                let safe = minimum.map_or(job.target, |lsn| job.target.min(lsn.saturating_sub(1)));
                state.checkpoint_ready = Some((job.target, safe));
                state.checkpoint = None;
                phobos_observability::event("checkpoint.page_completions", 1);
                drop(state);
                phobos_observability::synchronization_boundary(
                    "c4_after_target_flush",
                    &self.directory,
                );
                phobos_observability::certification_crash("c4_after_target_flush");
            }
        }
        Ok(true)
    }
}
