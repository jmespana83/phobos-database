#![forbid(unsafe_code)]
//! Page-oriented storage primitives, row codec, bounded buffer pool, and heap tables.
//! Phase 1 is single-process/single-writer; WAL ordering is introduced in Phase 3.

use phobos_error::{ErrorCode, PhobosError};
use phobos_types::{DataType, PageId, RecordId, Row, SlotId, TableSchema, Value, ValueRef};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::OpenOptions,
    path::{Path, PathBuf},
};

#[derive(Default)]
struct FreeSpaceMap {
    by_bytes: BTreeMap<usize, BTreeSet<PageId>>,
    unknown: BTreeSet<PageId>,
    inspected: u64,
    write_frontier: Option<PageId>,
}

impl FreeSpaceMap {
    fn from_hints(hints: &[usize]) -> Self {
        let mut map = Self::default();
        for (page, free) in hints.iter().copied().enumerate() {
            if free == usize::MAX {
                map.unknown.insert(page as PageId);
            } else {
                map.push(page as PageId, free);
            }
        }
        map
    }

    fn remove(&mut self, page: PageId, free: usize) {
        if free == usize::MAX {
            self.unknown.remove(&page);
            return;
        }
        if let Some(pages) = self.by_bytes.get_mut(&free) {
            pages.remove(&page);
            if pages.is_empty() {
                self.by_bytes.remove(&free);
            }
        }
    }

    fn update(&mut self, page: PageId, old: usize, free: usize) {
        self.remove(page, old);
        self.push(page, free);
    }

    fn push(&mut self, page: PageId, free: usize) {
        if free == usize::MAX {
            self.unknown.insert(page);
            return;
        }
        self.by_bytes.entry(free).or_default().insert(page);
    }

    fn take_known(&mut self, needed: usize) -> Option<PageId> {
        // Preserve the old first-fit page preference while inspecting only the
        // fixed 0..PAGE_SIZE free-byte classes, never the heap-page vector.
        let (free, page) = self
            .by_bytes
            .range(needed..)
            .filter_map(|(free, pages)| pages.first().map(|page| (*free, *page)))
            .min_by_key(|(_, page)| *page)?;
        self.remove(page, free);
        Some(page)
    }

    fn take_unknown(&mut self) -> Option<PageId> {
        self.unknown.pop_first()
    }
}

pub mod committed_pages;
/// 0.2-I.1: offline detection/repair of overflow pages holding ordinary tuples.
pub mod overflow_safety;
pub mod page_io;
pub mod private_pages;
pub mod tuple_version;
mod versioned_heap;
pub use versioned_heap::{
    HeapReadHandle, HintCache, LifecyclePage, OverlaySource, PageHeaders, PageLifecycleView,
    PageVersions, PreparedLifecycle, ReclaimPage, StatementOverlay, hint_bits_enabled,
    set_hint_bits_enabled,
};

pub const PAGE_SIZE: usize = 8192;
/// Heap page header bytes (the slot directory starts here).
pub const HEADER_SIZE: usize = 40;
/// Bytes of one slot-directory entry.
pub const SLOT_SIZE: usize = 4;
const MAGIC: [u8; 4] = *b"PHOP";
const FORMAT_VERSION: u16 = 1;
const CHECKSUM_OFFSET: usize = 32;
/// 0.1.9-C1: spare header byte carrying page flags. Bit 0 means "this page
/// MAY hold versions worth checking for reclamation" (set whenever a version
/// on the page gains a deleter; cleared by a reclaim pass that found nothing
/// left to defer). Conservative: a stale flag only costs one inspection.
const FLAGS_OFFSET: usize = 30;
pub const PAGE_FLAG_RECLAIM_CANDIDATE: u8 = 0b1;
pub const PAGE_FLAG_OVERFLOW: u8 = 0b10;
/// 0.2-K Storage Lifecycle V1: conservative hint "this page MAY hold FREE
/// slots" (set whenever a slot becomes FREE; cleared by the allocator when a
/// scan of the slot directory finds none). A stale bit costs one directory
/// scan; a missing bit would only delay reuse, never break it, because FREE
/// slots are never created without setting it. Older binaries ignore it.
pub const PAGE_FLAG_FREE_SLOTS: u8 = 0b100;

/// 0.2-K: lifecycle state of one heap slot-directory entry (see
/// `docs/storage_lifecycle_0_2_k.md`). The encoding uses the existing 4-byte
/// `(offset, len)` entry only:
///
/// | state    | len  | offset                    |
/// |----------|------|---------------------------|
/// | Occupied | > 0  | inside the tuple area     |
/// | Retired  | == 0 | >= HEADER_SIZE (stale)    |
/// | Free     | == 0 | == 0                      |
///
/// `Retired` is bit-identical to every tombstone written before 0.2-K (a
/// tombstone keeps the offset of the tuple it replaced, always >= 44).
/// `Free` never existed before 0.2-K and is written only by the horizon-gated
/// reclaim transition on ordinary versioned pages. `Vacant` is a slot id at or
/// beyond `slot_count` (trimmed or reset away, or never allocated).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SlotState {
    Occupied,
    Retired,
    Free,
    Vacant,
}

/// 0.2-K per-page slot-directory census (diagnostics and reclaim planning).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct SlotCensus {
    pub slots: u16,
    pub occupied: u16,
    pub retired: u16,
    pub free: u16,
}

/// 0.2-K: what one lifecycle rewrite of a page did.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct PageLifecycleOutcome {
    pub retired: usize,
    pub freed: usize,
    pub trimmed: usize,
    /// Pages reset to a fresh empty page.
    pub reset: usize,
}

fn checksum(bytes: &[u8]) -> u32 {
    let _measurement = phobos_observability::span("heap.checksum");
    phobos_wal::page_checksum::checksum(bytes, CHECKSUM_OFFSET)
}

/// Fixed-size slotted heap page. Slot IDs remain stable when tuple bytes are compacted later.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SlottedPage {
    bytes: [u8; PAGE_SIZE],
}

/// 0.2-B: borrowed view of an owned row restricted to `required` columns
/// (`ValueRef::Absent` elsewhere), for adapting owned rows to v2 operators.
pub fn project_owned_row<'a>(row: &'a Row, required: &[bool]) -> Vec<ValueRef<'a>> {
    versioned_heap::project_owned(row, required)
}

/// 0.2-B: a validated heap page image, shared with the committed cache or
/// owned (private/legacy paths). Read-only.
// Transient (one per page visit, never stored); boxing the owned variant
// would add an allocation to every private/legacy page read.
#[allow(clippy::large_enum_variant)]
pub(crate) enum PageRef {
    /// Image plus whether the committed store validated it on entry.
    Shared(std::sync::Arc<[u8; PAGE_SIZE]>, bool),
    Owned(SlottedPage),
}
impl PageRef {
    pub(crate) fn bytes(&self) -> &[u8; PAGE_SIZE] {
        match self {
            Self::Shared(image, _) => image,
            Self::Owned(page) => &page.bytes,
        }
    }
    pub(crate) fn is_overflow(&self) -> bool {
        self.bytes()[FLAGS_OFFSET] & PAGE_FLAG_OVERFLOW != 0
    }
    pub(crate) fn slot_count(&self) -> u16 {
        image_slot_count(self.bytes())
    }
    pub(crate) fn get(&self, slot: SlotId) -> Result<Option<&[u8]>, PhobosError> {
        image_get(self.bytes(), slot)
    }
    /// Validation for shared images (owned pages were validated on copy).
    fn check(&self, id: PageId, expected_versioned: Option<bool>) -> Result<(), PhobosError> {
        let bytes = self.bytes();
        if let Self::Shared(_, false) = self {
            validate_page_image(bytes)?;
        }
        if u64::from_le_bytes(bytes[8..16].try_into().expect("page id")) != id {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "heap page identity does not match its position",
            ));
        }
        if expected_versioned
            .is_some_and(|versioned| (u16::from_le_bytes([bytes[4], bytes[5]]) == 3) != versioned)
        {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "heap tuple capability mismatch",
            ));
        }
        Ok(())
    }
}

impl SlottedPage {
    #[must_use]
    pub fn new(page_id: PageId) -> Self {
        let mut page = Self {
            bytes: [0; PAGE_SIZE],
        };
        page.bytes[0..4].copy_from_slice(&MAGIC);
        page.put_u16(4, FORMAT_VERSION);
        page.bytes[6] = 1; // heap page
        page.put_u64(8, page_id);
        page.put_u16(24, HEADER_SIZE as u16);
        page.put_u16(26, PAGE_SIZE as u16);
        page.put_u16(28, 0);
        page.refresh_checksum();
        page
    }

    #[must_use]
    pub fn new_versioned(page_id: PageId) -> Self {
        let mut page = Self::new(page_id);
        page.put_u16(4, 3);
        page.refresh_checksum();
        page
    }
    #[must_use]
    pub(crate) fn new_overflow(page_id: PageId) -> Self {
        let mut page = Self::new_versioned(page_id);
        page.set_flag(PAGE_FLAG_OVERFLOW, true);
        page.refresh_checksum();
        page
    }
    #[must_use]
    pub(crate) fn is_overflow(&self) -> bool {
        self.flags() & PAGE_FLAG_OVERFLOW != 0
    }
    #[must_use]
    pub fn page_id(&self) -> PageId {
        self.get_u64(8)
    }
    /// Legacy pages have no LSN. V2 LSN bytes are covered by the page checksum.
    #[must_use]
    pub fn page_lsn(&self) -> u64 {
        if self.get_u16(4) >= 2 {
            self.get_u64(16)
        } else {
            0
        }
    }

    #[must_use]
    pub fn slot_count(&self) -> u16 {
        self.get_u16(28)
    }

    #[must_use]
    pub fn free_space(&self) -> usize {
        usize::from(self.get_u16(26)) - usize::from(self.get_u16(24))
    }

    pub fn insert(&mut self, record: &[u8]) -> Result<SlotId, PhobosError> {
        let slot = self.insert_unsealed(record)?;
        self.refresh_checksum();
        Ok(slot)
    }

    /// Bulk-build primitive: insert without refreshing the page checksum.
    /// Only for a page the caller owns exclusively and has not exposed; the
    /// caller must `seal` it before the page is stored in a buffer frame,
    /// written to private/base storage, logged, or otherwise handed out.
    /// Until then `from_bytes` on its bytes reports a checksum mismatch.
    ///
    /// 0.2-K: the single allocation primitive of every heap tuple. A FREE slot
    /// (horizon-gated, see `free_retired_slots`) is reused before the slot
    /// directory is extended; RETIRED slots are never reused. Nothing is
    /// modified when an error is returned.
    pub(crate) fn insert_unsealed(&mut self, record: &[u8]) -> Result<SlotId, PhobosError> {
        if record.is_empty() || record.len() > u16::MAX as usize {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "invalid record length",
            ));
        }
        let reusable = if self.flags() & PAGE_FLAG_FREE_SLOTS != 0 {
            self.first_free_slot()
        } else {
            None
        };
        let needed = record.len() + if reusable.is_some() { 0 } else { SLOT_SIZE };
        if self.free_space() < needed {
            // 0.2-K.3 deferred compaction: reclamation no longer repacks a
            // page when it retires/frees slots; the space of dropped tuples
            // stays fragmented until an insertion actually needs it. Repack
            // here only if that makes the record fit; slot identifiers are
            // unchanged (`compact` keeps every surviving RecordId).
            if self.free_space() + self.reclaimable_fragment() < needed {
                return Err(PhobosError::new(
                    ErrorCode::InvalidPage,
                    "page has insufficient free space",
                ));
            }
            let moved = self.compact_moved_bytes();
            self.compact()?;
            phobos_observability::event("heap.compactions", 1);
            phobos_observability::event("heap.compaction_bytes_moved", moved as u64);
            if self.free_space() < needed {
                return Err(PhobosError::new(
                    ErrorCode::InvalidPage,
                    "page has insufficient free space",
                ));
            }
        }
        let old_upper = usize::from(self.get_u16(26));
        let new_upper = old_upper - record.len();
        self.bytes[new_upper..old_upper].copy_from_slice(record);
        let slot = match reusable {
            Some(slot) => {
                phobos_observability::event("heap.free_slot_reused", 1);
                slot
            }
            None => {
                // A FREE hint that found nothing is retired here (the page is
                // being modified anyway; the caller seals it).
                self.set_flag(PAGE_FLAG_FREE_SLOTS, false);
                let slot = self.slot_count();
                self.put_u16(
                    24,
                    (HEADER_SIZE + (usize::from(slot) + 1) * SLOT_SIZE) as u16,
                );
                self.put_u16(28, slot + 1);
                slot
            }
        };
        let slot_offset = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
        self.put_u16(slot_offset, new_upper as u16);
        self.put_u16(slot_offset + 2, record.len() as u16);
        self.put_u16(26, new_upper as u16);
        Ok(slot)
    }

    /// Lowest FREE slot (`len == 0 && offset == 0`), if any.
    fn first_free_slot(&self) -> Option<SlotId> {
        (0..self.slot_count()).find(|slot| self.slot_state(*slot) == SlotState::Free)
    }

    /// 0.2-K: lifecycle state of `slot` (see `SlotState`).
    #[must_use]
    pub fn slot_state(&self, slot: SlotId) -> SlotState {
        image_slot_state(&self.bytes, slot)
    }

    /// 0.2-K: census of the slot directory.
    #[must_use]
    pub fn slot_census(&self) -> SlotCensus {
        image_slot_census(&self.bytes)
    }

    /// 0.2-K phase 1 (LIVE -> RETIRED): drop the tuple of an occupied slot.
    /// The entry keeps its (non-zero) offset, i.e. it becomes exactly the
    /// tombstone every earlier release wrote. The caller refreshes the checksum.
    fn retire_slot(&mut self, slot: SlotId) -> Result<(), PhobosError> {
        if self.slot_state(slot) != SlotState::Occupied {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "only an occupied slot can be retired",
            ));
        }
        let offset = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
        self.put_u16(offset + 2, 0);
        Ok(())
    }

    /// 0.2-K phase 2 (RETIRED -> FREE). Only the horizon-gated reclaim
    /// transition may call this (see `HeapTable::reclaim_lifecycle`), and
    /// only for slots it observed RETIRED in published state. Ordinary
    /// versioned pages only. The caller refreshes the checksum.
    fn free_retired_slot(&mut self, slot: SlotId) -> Result<(), PhobosError> {
        if self.is_overflow() || self.get_u16(4) != 3 {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "FREE slots exist only on ordinary versioned heap pages",
            ));
        }
        if self.slot_state(slot) != SlotState::Retired {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "only a RETIRED slot can become FREE",
            ));
        }
        let offset = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
        self.put_u16(offset, 0);
        self.set_flag(PAGE_FLAG_FREE_SLOTS, true);
        Ok(())
    }

    /// 0.2-K Part F: remove trailing FREE entries (`slot_count` shrinks,
    /// `lower` moves down, the released directory bytes are zeroed). Occupied
    /// and RETIRED entries are never renumbered or removed. Returns the number
    /// of entries removed. The caller refreshes the checksum.
    fn trim_trailing_free(&mut self) -> usize {
        let mut trimmed = 0;
        let mut count = self.slot_count();
        while count > 0 && self.slot_state(count - 1) == SlotState::Free {
            count -= 1;
            let offset = HEADER_SIZE + usize::from(count) * SLOT_SIZE;
            self.bytes[offset..offset + SLOT_SIZE].fill(0);
            trimmed += 1;
        }
        if trimmed > 0 {
            self.put_u16(28, count);
            self.put_u16(24, (HEADER_SIZE + usize::from(count) * SLOT_SIZE) as u16);
            if self.first_free_slot().is_none() {
                self.set_flag(PAGE_FLAG_FREE_SLOTS, false);
            }
        }
        trimmed
    }

    /// 0.2-K Part G: whether every slot is FREE (vacuously true for an empty
    /// directory) on an ordinary versioned page, i.e. the page may be reset.
    fn all_slots_free(&self) -> bool {
        !self.is_overflow()
            && self.get_u16(4) == 3
            && (0..self.slot_count()).all(|slot| self.slot_state(slot) == SlotState::Free)
    }

    /// 0.2-I.1 overflow safety: bytes usable by an ORDINARY heap tuple.
    /// Invariant: an overflow page may never store an ordinary heap tuple, so
    /// it always reports 0 here regardless of its raw `free_space()` (a short
    /// last chunk or a released chunk leaves most of the page empty).
    #[must_use]
    pub fn ordinary_free_space(&self) -> usize {
        if self.is_overflow() {
            0
        } else {
            self.free_space() + self.reclaimable_fragment()
        }
    }

    /// 0.2-K.3: bytes of the tuple area (`upper..PAGE_SIZE`) no OCCUPIED
    /// slot references, i.e. space of retired/freed tuples that reclamation
    /// left in place (deferred compaction). Ordinary versioned pages only;
    /// legacy and overflow pages report 0 (their behavior is unchanged).
    #[must_use]
    pub fn reclaimable_fragment(&self) -> usize {
        if self.is_overflow() || self.get_u16(4) != 3 {
            return 0;
        }
        let upper = usize::from(self.get_u16(26));
        let live: usize = (0..self.slot_count())
            .map(|slot| usize::from(self.get_u16(HEADER_SIZE + usize::from(slot) * SLOT_SIZE + 2)))
            .sum();
        (PAGE_SIZE - upper).saturating_sub(live)
    }

    /// Bytes `compact` would move (tuples stored below the highest gap).
    fn compact_moved_bytes(&self) -> usize {
        (0..self.slot_count())
            .map(|slot| usize::from(self.get_u16(HEADER_SIZE + usize::from(slot) * SLOT_SIZE + 2)))
            .sum()
    }

    /// 0.2-I.1: `insert_unsealed` for an ordinary heap tuple. Fail-safe: an
    /// overflow page is refused with an error instead of being corrupted, even
    /// if a caller's free-space bookkeeping is wrong. Overflow chunk records
    /// are written only by the overflow writer through `insert`.
    pub(crate) fn insert_ordinary_unsealed(
        &mut self,
        record: &[u8],
    ) -> Result<SlotId, PhobosError> {
        if self.is_overflow() {
            return Err(overflow_page_refused(self.page_id()));
        }
        self.insert_unsealed(record)
    }

    /// 0.2-I.1: `insert` (checksum refreshed) for an ordinary heap tuple.
    pub(crate) fn insert_ordinary(&mut self, record: &[u8]) -> Result<SlotId, PhobosError> {
        let slot = self.insert_ordinary_unsealed(record)?;
        self.refresh_checksum();
        Ok(slot)
    }

    /// Refresh the page checksum once after a run of `insert_unsealed`.
    pub(crate) fn seal(&mut self) {
        self.refresh_checksum();
    }

    pub fn get(&self, slot: SlotId) -> Result<Option<&[u8]>, PhobosError> {
        image_get(&self.bytes, slot)
    }

    pub fn delete(&mut self, slot: SlotId) -> Result<bool, PhobosError> {
        if slot >= self.slot_count() {
            return Ok(false);
        }
        let offset = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
        if self.get_u16(offset + 2) == 0 {
            return Ok(false);
        }
        self.put_u16(offset + 2, 0);
        self.refresh_checksum();
        Ok(true)
    }

    /// Whether `slot` exists in the slot array but holds no tuple (RETIRED or
    /// FREE). 0.2-K: slot identifiers ARE reused, but only after the
    /// reclamation horizon passed the publication that retired them, and
    /// every RecordId dereference that can hold a stale reference re-validates
    /// identity (see `HeapTable::slot_reclaimed`).
    #[must_use]
    pub fn slot_is_empty(&self, slot: SlotId) -> bool {
        slot < self.slot_count()
            && self.get_u16(HEADER_SIZE + usize::from(slot) * SLOT_SIZE + 2) == 0
    }

    #[must_use]
    pub fn flags(&self) -> u8 {
        self.bytes[FLAGS_OFFSET]
    }
    /// Sets or clears header flag bits; the caller refreshes the checksum.
    pub fn set_flag(&mut self, flag: u8, on: bool) {
        if on {
            self.bytes[FLAGS_OFFSET] |= flag;
        } else {
            self.bytes[FLAGS_OFFSET] &= !flag;
        }
    }

    /// 0.1.9-C2: repack tuple bytes so the space of empty slots becomes free
    /// space again. Slot identifiers and the slot array are unchanged, so
    /// every surviving RecordId keeps its identity; empty slots stay empty
    /// (never reused). Returns the bytes recovered.
    pub fn compact(&mut self) -> Result<usize, PhobosError> {
        let old_upper = usize::from(self.get_u16(26));
        let mut live = Vec::new();
        for slot in 0..self.slot_count() {
            if let Some(bytes) = self.get(slot)? {
                live.push((slot, bytes.to_vec()));
            }
        }
        let mut upper = PAGE_SIZE;
        for (slot, bytes) in &live {
            upper -= bytes.len();
            self.bytes[upper..upper + bytes.len()].copy_from_slice(bytes);
            let offset = HEADER_SIZE + usize::from(*slot) * SLOT_SIZE;
            self.put_u16(offset, upper as u16);
        }
        let lower = usize::from(self.get_u16(24));
        self.bytes[lower..upper].fill(0);
        self.put_u16(26, upper as u16);
        self.refresh_checksum();
        Ok(upper - old_upper)
    }

    #[must_use]
    pub fn to_bytes(&self) -> [u8; PAGE_SIZE] {
        self.bytes
    }

    pub fn from_bytes(bytes: [u8; PAGE_SIZE]) -> Result<Self, PhobosError> {
        validate_page_image(&bytes)?;
        Ok(Self { bytes })
    }

    fn get_u16(&self, offset: usize) -> u16 {
        u16::from_le_bytes([self.bytes[offset], self.bytes[offset + 1]])
    }
}

/// 0.2-I.1: the error raised when an ordinary tuple would be placed on an
/// overflow page. Reaching it means free-space bookkeeping went wrong; the
/// statement fails and the page is left untouched.
fn overflow_page_refused(page: PageId) -> PhobosError {
    PhobosError::new(
        ErrorCode::InvalidPage,
        format!("refusing to place an ordinary heap tuple on overflow page {page}"),
    )
}

/// 0.2-B: every check `SlottedPage::from_bytes` performs, over a borrowed
/// image, so shared committed frames can be validated without an 8 KiB copy.
pub(crate) fn validate_page_image(bytes: &[u8; PAGE_SIZE]) -> Result<(), PhobosError> {
    validate_page_image_checked(bytes, true)
}
/// 0.2-G: `validate_page_image` for an image whose complete checksum was
/// just verified on the same borrow (`committed_pages::VerifiedImage`).
pub(crate) fn validate_page_structure(bytes: &[u8; PAGE_SIZE]) -> Result<(), PhobosError> {
    validate_page_image_checked(bytes, false)
}
fn validate_page_image_checked(
    bytes: &[u8; PAGE_SIZE],
    verify_checksum: bool,
) -> Result<(), PhobosError> {
    if bytes[0..4] != MAGIC {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "invalid page magic",
        ));
    }
    let version = u16::from_le_bytes([bytes[4], bytes[5]]);
    if !matches!(version, FORMAT_VERSION | 2 | 3) {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "unsupported page format",
        ));
    }
    phobos_wal::page_checksum::validate_scheme(bytes)?;
    let expected = u32::from_le_bytes(
        bytes[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4]
            .try_into()
            .expect("fixed checksum field"),
    );
    if verify_checksum && checksum(bytes) != expected {
        return Err(PhobosError::new(
            ErrorCode::ChecksumMismatch,
            "page checksum mismatch",
        ));
    }
    if version == 2 && u64::from_le_bytes(bytes[16..24].try_into().expect("page LSN")) == 0 {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "V2 heap page has zero LSN",
        ));
    }
    let lower = u16::from_le_bytes([bytes[24], bytes[25]]) as usize;
    let upper = u16::from_le_bytes([bytes[26], bytes[27]]) as usize;
    let slots = u16::from_le_bytes([bytes[28], bytes[29]]) as usize;
    if lower != HEADER_SIZE + slots * SLOT_SIZE || lower > upper || upper > PAGE_SIZE {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "invalid free-space boundaries",
        ));
    }
    let ordinary_versioned = version == 3 && bytes[FLAGS_OFFSET] & PAGE_FLAG_OVERFLOW == 0;
    for slot in 0..image_slot_count(bytes) {
        let _ = image_get(bytes, slot)?;
        // 0.2-K Part B invalid combinations: an empty entry is either RETIRED
        // (offset >= HEADER_SIZE, every pre-0.2-K tombstone) or FREE
        // (offset 0, ordinary versioned pages only). Nothing else.
        let entry = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
        let offset = usize::from(u16::from_le_bytes([bytes[entry], bytes[entry + 1]]));
        let len = u16::from_le_bytes([bytes[entry + 2], bytes[entry + 3]]);
        if len == 0
            && ((offset != 0 && offset < HEADER_SIZE) || (offset == 0 && !ordinary_versioned))
        {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "invalid heap slot state",
            ));
        }
    }
    Ok(())
}

/// Slot count of a validated heap page image.
pub(crate) fn image_slot_count(bytes: &[u8; PAGE_SIZE]) -> u16 {
    u16::from_le_bytes([bytes[28], bytes[29]])
}

/// 0.2-K: lifecycle state of `slot` in a validated heap page image.
pub(crate) fn image_slot_state(bytes: &[u8; PAGE_SIZE], slot: SlotId) -> SlotState {
    if slot >= image_slot_count(bytes) {
        return SlotState::Vacant;
    }
    let entry = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
    let offset = u16::from_le_bytes([bytes[entry], bytes[entry + 1]]);
    let len = u16::from_le_bytes([bytes[entry + 2], bytes[entry + 3]]);
    match (len, offset) {
        (0, 0) => SlotState::Free,
        (0, _) => SlotState::Retired,
        _ => SlotState::Occupied,
    }
}

/// 0.2-K: slot census of a validated heap page image.
pub(crate) fn image_slot_census(bytes: &[u8; PAGE_SIZE]) -> SlotCensus {
    let mut census = SlotCensus {
        slots: image_slot_count(bytes),
        ..SlotCensus::default()
    };
    for slot in 0..census.slots {
        match image_slot_state(bytes, slot) {
            SlotState::Occupied => census.occupied += 1,
            SlotState::Retired => census.retired += 1,
            SlotState::Free => census.free += 1,
            SlotState::Vacant => {}
        }
    }
    census
}

/// Borrowed tuple bytes of `slot`; identical bounds rules to `SlottedPage::get`.
pub(crate) fn image_get(
    bytes: &[u8; PAGE_SIZE],
    slot: SlotId,
) -> Result<Option<&[u8]>, PhobosError> {
    if slot >= image_slot_count(bytes) {
        return Ok(None);
    }
    let offset = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
    let start = usize::from(u16::from_le_bytes([bytes[offset], bytes[offset + 1]]));
    let len = usize::from(u16::from_le_bytes([bytes[offset + 2], bytes[offset + 3]]));
    if len == 0 {
        return Ok(None);
    }
    let end = start
        .checked_add(len)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidPage, "slot overflow"))?;
    if start < usize::from(u16::from_le_bytes([bytes[26], bytes[27]])) || end > PAGE_SIZE {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "slot points outside tuple area",
        ));
    }
    Ok(Some(&bytes[start..end]))
}

impl SlottedPage {
    fn put_u16(&mut self, offset: usize, value: u16) {
        self.bytes[offset..offset + 2].copy_from_slice(&value.to_le_bytes());
    }

    fn get_u64(&self, offset: usize) -> u64 {
        u64::from_le_bytes(
            self.bytes[offset..offset + 8]
                .try_into()
                .expect("fixed field"),
        )
    }

    fn put_u64(&mut self, offset: usize, value: u64) {
        self.bytes[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }

    fn refresh_checksum(&mut self) {
        self.bytes[7] = phobos_wal::page_checksum::CRC32C;
        self.bytes[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4].fill(0);
        let value = checksum(&self.bytes);
        self.bytes[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4].copy_from_slice(&value.to_le_bytes());
    }
}

/// Positional page file. Every durable page is checksum-validated when read.
pub struct PageFile {
    file: page_io::PageIo,
}

impl PageFile {
    pub fn open(path: impl AsRef<Path>) -> Result<Self, PhobosError> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(path)?;
        Ok(Self {
            file: page_io::PageIo::new(file),
        })
    }

    pub fn page_count(&self) -> Result<u64, PhobosError> {
        let _measurement = phobos_observability::span("fs.heap_metadata");
        let len = self.file.len()?;
        if len % PAGE_SIZE as u64 != 0 {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "file length is not page aligned",
            ));
        }
        Ok(len / PAGE_SIZE as u64)
    }

    pub fn append(&mut self, page: &SlottedPage) -> Result<PageId, PhobosError> {
        let _measurement = phobos_observability::span("heap.append_page");
        let id = self.page_count()?;
        if page.page_id() != id {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "page id does not match append position",
            ));
        }
        self.file.write(id, &page.to_bytes())?;
        if !self.file.is_private() {
            let _sync = phobos_observability::span("heap.fsync");
            self.file.sync_data()?;
        }
        Ok(id)
    }

    pub fn read(&mut self, id: PageId) -> Result<SlottedPage, PhobosError> {
        if id >= self.page_count()? {
            return Err(PhobosError::new(ErrorCode::NotFound, "page does not exist"));
        }
        let bytes = self.file.read(id)?;
        let page = SlottedPage::from_bytes(bytes)?;
        if page.page_id() != id {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "heap page identity does not match its position",
            ));
        }
        Ok(page)
    }

    pub fn write(&mut self, page: &SlottedPage) -> Result<(), PhobosError> {
        let _measurement = phobos_observability::span("heap.write_page");
        if page.page_id() >= self.page_count()? {
            return Err(PhobosError::new(ErrorCode::NotFound, "page does not exist"));
        }
        self.file.write(page.page_id(), &page.to_bytes())?;
        Ok(())
    }

    pub fn sync(&mut self) -> Result<(), PhobosError> {
        if self.file.is_private() {
            return self.file.sync_data();
        }
        {
            let _sync = phobos_observability::span("heap.fsync");
            self.file.sync_data()?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone)]
struct BufferFrame {
    page: SlottedPage,
    dirty: bool,
    pin_count: u32,
    last_use: u64,
    /// 0.2-H dirty-page state. `false` = dirty-unverified: mutated in place
    /// through `BufferPool::modify_page` and its stored checksum is stale.
    /// Every path that hands the bytes out (clone for a reader, write to the
    /// private file, eviction) seals first, so a stale checksum is never
    /// observable; a page is never stamped, logged or published unsealed.
    sealed: bool,
}
impl BufferFrame {
    fn seal(&mut self) {
        if !self.sealed {
            self.page.refresh_checksum();
            self.sealed = true;
            phobos_observability::event("heap.frame_seals", 1);
        }
    }
}

/// Small deterministic LRU buffer pool with explicit dirty tracking and bounded page count.
pub struct BufferPool {
    expected_versioned: Option<bool>,
    file: PageFile,
    capacity: usize,
    clock: u64,
    frames: BTreeMap<PageId, BufferFrame>,
}

impl BufferPool {
    pub fn open(path: impl AsRef<Path>, capacity: usize) -> Result<Self, PhobosError> {
        if capacity == 0 {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "buffer pool capacity must be non-zero",
            ));
        }
        Ok(Self {
            file: PageFile::open(path)?,
            expected_versioned: None,
            capacity,
            clock: 0,
            frames: BTreeMap::new(),
        })
    }

    pub fn page_count(&self) -> Result<u64, PhobosError> {
        self.file.page_count()
    }

    #[must_use]
    pub fn cached_pages(&self) -> usize {
        self.frames.len()
    }

    pub fn read_page(&mut self, id: PageId) -> Result<SlottedPage, PhobosError> {
        self.read_page_with_admission(id, false)
    }

    pub fn read_page_scan(&mut self, id: PageId) -> Result<SlottedPage, PhobosError> {
        self.read_page_with_admission(id, true)
    }

    /// 0.2-B: validated page for read-only traversal without the 8 KiB copy
    /// when the page comes from the shared committed cache. Validation is
    /// identical to `read_page`/`read_page_scan` (checksum, header, slots,
    /// page identity and tuple capability).
    pub(crate) fn read_page_ref(&mut self, id: PageId, scan: bool) -> Result<PageRef, PhobosError> {
        self.file.file.ensure_readable()?;
        if self.file.file.uses_shared_cache() {
            let _profile = phobos_observability::span("storage.read_page");
            if let Some((image, validated)) = self.file.file.read_shared(id, scan)? {
                let page = PageRef::Shared(image, validated);
                page.check(id, self.expected_versioned)?;
                return Ok(page);
            }
        }
        Ok(PageRef::Owned(self.read_page_with_admission(id, scan)?))
    }

    fn read_page_with_admission(
        &mut self,
        id: PageId,
        scan: bool,
    ) -> Result<SlottedPage, PhobosError> {
        self.file.file.ensure_readable()?;
        let _profile = phobos_observability::span("storage.read_page");
        if self.file.file.uses_shared_cache() {
            let bytes = if scan {
                self.file.file.read_scan(id)?
            } else {
                self.file.file.read(id)?
            };
            let page = SlottedPage::from_bytes(bytes)?;
            if page.page_id() != id {
                return Err(PhobosError::new(
                    ErrorCode::InvalidPage,
                    "heap page identity does not match its position",
                ));
            }
            if self
                .expected_versioned
                .is_some_and(|versioned| (page.get_u16(4) == 3) != versioned)
            {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "heap tuple capability mismatch",
                ));
            }
            return Ok(page);
        }
        self.clock = self.clock.wrapping_add(1);
        if let Some(frame) = self.frames.get_mut(&id) {
            phobos_observability::event("buffer.hit", 1);
            frame.last_use = self.clock;
            frame.seal();
            return Ok(frame.page.clone());
        }
        self.make_room()?;
        phobos_observability::event("buffer.miss", 1);
        let page = self.file.read(id)?;
        if self
            .expected_versioned
            .is_some_and(|versioned| (page.get_u16(4) == 3) != versioned)
        {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "heap tuple capability mismatch",
            ));
        }
        self.frames.insert(
            id,
            BufferFrame {
                page: page.clone(),
                dirty: false,
                pin_count: 0,
                last_use: self.clock,
                sealed: true,
            },
        );
        Ok(page)
    }

    pub fn put_dirty(&mut self, page: SlottedPage) -> Result<(), PhobosError> {
        self.file.file.ensure_writable()?;
        self.clock = self.clock.wrapping_add(1);
        let id = page.page_id();
        let pin_count = if let Some(frame) = self.frames.get(&id) {
            frame.pin_count
        } else {
            self.make_room()?;
            0
        };
        self.frames.insert(
            id,
            BufferFrame {
                page,
                dirty: true,
                pin_count,
                last_use: self.clock,
                sealed: true,
            },
        );
        Ok(())
    }

    /// 0.2-H heap mutation fast path: run `operation` on the buffered page
    /// `id` in place — no 8 KiB copy out of and back into the frame, no
    /// checksum refresh per mutation. Only while the file is private
    /// (`!uses_shared_cache`): the frame then holds this generation's own
    /// copy (loaded from the private/pending/committed image with full
    /// validation on first use); a committed `Arc` image is never mutated.
    /// `operation` returns `(value, modified)`; a modified frame becomes
    /// dirty (once) and dirty-unverified until sealed (see `BufferFrame`).
    /// The borrow cannot escape the closure.
    // make_room borrows the entire pool before insertion, so an Entry cannot
    // be held across that call (including with the pinned 1.85 Clippy).
    #[allow(clippy::map_entry)]
    pub(crate) fn modify_page<T>(
        &mut self,
        id: PageId,
        operation: impl FnOnce(&mut SlottedPage) -> Result<(T, bool), PhobosError>,
    ) -> Result<T, PhobosError> {
        self.file.file.ensure_readable()?;
        if self.file.file.uses_shared_cache() {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "in-place page mutation requires a private heap",
            ));
        }
        let _profile = phobos_observability::span("storage.read_page");
        self.clock = self.clock.wrapping_add(1);
        if !self.frames.contains_key(&id) {
            self.make_room()?;
            phobos_observability::event("buffer.miss", 1);
            let page = self.file.read(id)?;
            if self
                .expected_versioned
                .is_some_and(|versioned| (page.get_u16(4) == 3) != versioned)
            {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "heap tuple capability mismatch",
                ));
            }
            self.frames.insert(
                id,
                BufferFrame {
                    page,
                    dirty: false,
                    pin_count: 0,
                    last_use: self.clock,
                    sealed: true,
                },
            );
        } else {
            phobos_observability::event("buffer.hit", 1);
        }
        let frame = self.frames.get_mut(&id).expect("loaded frame");
        frame.last_use = self.clock;
        let (value, modified) = operation(&mut frame.page)?;
        if modified {
            frame.dirty = true;
            frame.sealed = false;
            phobos_observability::event("heap.in_place_mutations", 1);
        }
        Ok(value)
    }

    pub fn append(&mut self, page: SlottedPage) -> Result<PageId, PhobosError> {
        let id = self.file.append(&page)?;
        self.clock = self.clock.wrapping_add(1);
        if !self.frames.contains_key(&id) {
            self.make_room()?;
        }
        self.frames.insert(
            id,
            BufferFrame {
                page,
                dirty: false,
                pin_count: 0,
                last_use: self.clock,
                sealed: true,
            },
        );
        Ok(id)
    }

    pub fn pin(&mut self, id: PageId) -> Result<(), PhobosError> {
        let _ = self.read_page(id)?;
        let frame = self.frames.get_mut(&id).expect("page loaded");
        frame.pin_count = frame.pin_count.saturating_add(1);
        Ok(())
    }

    pub fn unpin(&mut self, id: PageId) -> Result<(), PhobosError> {
        let frame = self
            .frames
            .get_mut(&id)
            .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "page is not cached"))?;
        if frame.pin_count == 0 {
            return Err(PhobosError::new(ErrorCode::Semantic, "page is not pinned"));
        }
        frame.pin_count -= 1;
        Ok(())
    }

    pub fn flush_all(&mut self) -> Result<(), PhobosError> {
        let _profile = phobos_observability::span("storage.flush_all");
        self.flush_frames()?;
        self.file.sync()
    }
    fn flush_frames(&mut self) -> Result<(), PhobosError> {
        let dirty_ids: Vec<PageId> = self
            .frames
            .iter()
            .filter_map(|(id, frame)| frame.dirty.then_some(*id))
            .collect();
        for id in dirty_ids {
            // 0.2-G: write the frame's page in place (disjoint field borrows)
            // instead of cloning 8 KiB first.
            let frame = self.frames.get_mut(&id).expect("known frame");
            frame.seal();
            self.file.write(&frame.page)?;
            frame.dirty = false;
        }
        Ok(())
    }

    fn make_room(&mut self) -> Result<(), PhobosError> {
        if self.frames.len() < self.capacity {
            return Ok(());
        }
        let victim = self
            .frames
            .iter()
            .filter(|(_, frame)| frame.pin_count == 0)
            .min_by_key(|(_, frame)| frame.last_use)
            .map(|(id, _)| *id)
            .ok_or_else(|| PhobosError::new(ErrorCode::Semantic, "all buffer pages are pinned"))?;
        let std::collections::btree_map::Entry::Occupied(mut entry) = self.frames.entry(victim)
        else {
            unreachable!("victim exists");
        };
        entry.get_mut().seal();
        let frame = entry.get();
        if frame.dirty {
            self.file.write(&frame.page)?;
            self.file.sync()?;
        }
        // Keep the only dirty copy resident until both write and force succeed.
        entry.remove();
        Ok(())
    }
}

impl Drop for BufferPool {
    fn drop(&mut self) {
        let _ = self.flush_all();
    }
}

/// `PHOBOS_HEAP_IN_PLACE=0` keeps the 0.2-G read/copy/put_dirty heap insert
/// (A/B switch).
fn heap_in_place_enabled() -> bool {
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ENABLED.get_or_init(|| std::env::var("PHOBOS_HEAP_IN_PLACE").map_or(true, |v| v != "0"))
}

/// Schema-aware row binary codec. The layout starts with a column count and NULL bitmap,
/// followed by non-null values in schema order.
pub struct RowCodec;

impl RowCodec {
    pub fn encode(schema: &TableSchema, row: &Row) -> Result<Vec<u8>, PhobosError> {
        let _profile = phobos_observability::span("storage.encode");
        if row.values.len() != schema.columns.len() {
            return Err(PhobosError::new(
                ErrorCode::TypeMismatch,
                "row column count does not match schema",
            ));
        }
        let count = u16::try_from(schema.columns.len())
            .map_err(|_| PhobosError::new(ErrorCode::TypeMismatch, "too many columns"))?;
        let null_bytes = schema.columns.len().div_ceil(8);
        let mut out = Vec::with_capacity(32);
        out.extend_from_slice(&count.to_le_bytes());
        let null_start = out.len();
        out.resize(null_start + null_bytes, 0);
        for (index, (column, value)) in schema.columns.iter().zip(&row.values).enumerate() {
            if value.is_null() {
                if !column.nullable {
                    return Err(PhobosError::new(
                        ErrorCode::ConstraintViolation,
                        format!("column {} does not allow NULL", column.name),
                    ));
                }
                out[null_start + index / 8] |= 1 << (index % 8);
                continue;
            }
            encode_value(&mut out, &column.data_type, value)?;
        }
        Ok(out)
    }

    pub fn decode(schema: &TableSchema, bytes: &[u8]) -> Result<Row, PhobosError> {
        let _profile = phobos_observability::span("storage.decode");
        if bytes.len() < 2 {
            return Err(PhobosError::new(ErrorCode::InvalidPage, "truncated row"));
        }
        let count = usize::from(u16::from_le_bytes([bytes[0], bytes[1]]));
        if count != schema.columns.len() {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "row schema column count mismatch",
            ));
        }
        let null_bytes = count.div_ceil(8);
        if bytes.len() < 2 + null_bytes {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "truncated row null bitmap",
            ));
        }
        let bitmap = &bytes[2..2 + null_bytes];
        let mut cursor = 2 + null_bytes;
        let mut values = Vec::with_capacity(count);
        for (index, column) in schema.columns.iter().enumerate() {
            if bitmap[index / 8] & (1 << (index % 8)) != 0 {
                values.push(Value::Null);
            } else {
                values.push(decode_value(bytes, &mut cursor, &column.data_type)?);
            }
        }
        if cursor != bytes.len() {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "row contains trailing bytes",
            ));
        }
        Ok(Row::new(values))
    }

    /// 0.2-B single-pass selective decode into borrowed values. `required[i]`
    /// selects column `i`; every other position is `ValueRef::Absent`. The row
    /// structure (column count, null bitmap, every length prefix, bounds and
    /// trailing bytes) is validated exactly as [`RowCodec::decode`] does, and
    /// every decoded TEXT is UTF-8 validated; skipped TEXT/BINARY payloads are
    /// bounds-checked but not copied. `out` is cleared and reused by callers.
    pub fn decode_projected<'a>(
        schema: &TableSchema,
        bytes: &'a [u8],
        required: &[bool],
        out: &mut Vec<ValueRef<'a>>,
    ) -> Result<(), PhobosError> {
        out.clear();
        if bytes.len() < 2 {
            return Err(PhobosError::new(ErrorCode::InvalidPage, "truncated row"));
        }
        let count = usize::from(u16::from_le_bytes([bytes[0], bytes[1]]));
        if count != schema.columns.len() || required.len() != count {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "row schema column count mismatch",
            ));
        }
        let null_bytes = count.div_ceil(8);
        if bytes.len() < 2 + null_bytes {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "truncated row null bitmap",
            ));
        }
        let bitmap = &bytes[2..2 + null_bytes];
        let mut cursor = 2 + null_bytes;
        for (index, column) in schema.columns.iter().enumerate() {
            if bitmap[index / 8] & (1 << (index % 8)) != 0 {
                out.push(if required[index] {
                    ValueRef::Null
                } else {
                    ValueRef::Absent
                });
                continue;
            }
            if !required[index] {
                skip_value(bytes, &mut cursor, &column.data_type)?;
                out.push(ValueRef::Absent);
                continue;
            }
            out.push(match &column.data_type {
                DataType::Int64 => {
                    ValueRef::Int64(i64::from_le_bytes(take_array::<8>(bytes, &mut cursor)?))
                }
                DataType::Boolean => match take_array::<1>(bytes, &mut cursor)?[0] {
                    0 => ValueRef::Boolean(false),
                    1 => ValueRef::Boolean(true),
                    _ => {
                        return Err(PhobosError::new(
                            ErrorCode::InvalidPage,
                            "invalid boolean encoding",
                        ));
                    }
                },
                DataType::Float64 => ValueRef::Float64(f64::from_bits(u64::from_le_bytes(
                    take_array::<8>(bytes, &mut cursor)?,
                ))),
                DataType::Text => ValueRef::Text(
                    std::str::from_utf8(take_bytes(bytes, &mut cursor)?).map_err(|_| {
                        PhobosError::new(ErrorCode::InvalidPage, "invalid UTF-8 text row value")
                    })?,
                ),
                DataType::Binary => ValueRef::Binary(take_bytes(bytes, &mut cursor)?),
                DataType::Date => {
                    ValueRef::Date(i32::from_le_bytes(take_array::<4>(bytes, &mut cursor)?))
                }
                DataType::Timestamp => {
                    ValueRef::Timestamp(i64::from_le_bytes(take_array::<8>(bytes, &mut cursor)?))
                }
                DataType::Decimal { scale, .. } => ValueRef::Decimal {
                    unscaled: i128::from_le_bytes(take_array::<16>(bytes, &mut cursor)?),
                    scale: *scale,
                },
            });
        }
        if cursor != bytes.len() {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "row contains trailing bytes",
            ));
        }
        Ok(())
    }
}

/// Advance over one encoded non-NULL value with the same bounds checks as a decode.
fn skip_value(bytes: &[u8], cursor: &mut usize, data_type: &DataType) -> Result<(), PhobosError> {
    match data_type {
        DataType::Int64 | DataType::Float64 | DataType::Timestamp => {
            take_array::<8>(bytes, cursor)?;
        }
        DataType::Boolean => {
            if take_array::<1>(bytes, cursor)?[0] > 1 {
                return Err(PhobosError::new(
                    ErrorCode::InvalidPage,
                    "invalid boolean encoding",
                ));
            }
        }
        DataType::Date => {
            take_array::<4>(bytes, cursor)?;
        }
        DataType::Decimal { .. } => {
            take_array::<16>(bytes, cursor)?;
        }
        DataType::Text | DataType::Binary => {
            take_bytes(bytes, cursor)?;
        }
    }
    Ok(())
}

fn encode_value(out: &mut Vec<u8>, data_type: &DataType, value: &Value) -> Result<(), PhobosError> {
    match (data_type, value) {
        (DataType::Int64, Value::Int64(value)) => out.extend_from_slice(&value.to_le_bytes()),
        (DataType::Boolean, Value::Boolean(value)) => out.push(u8::from(*value)),
        (DataType::Float64, Value::Float64(value)) => {
            out.extend_from_slice(&value.to_bits().to_le_bytes())
        }
        (DataType::Text, Value::Text(value)) => put_bytes(out, value.as_bytes())?,
        (DataType::Binary, Value::Binary(value)) => put_bytes(out, value)?,
        (DataType::Date, Value::Date(value)) => out.extend_from_slice(&value.to_le_bytes()),
        (DataType::Timestamp, Value::Timestamp(value)) => {
            out.extend_from_slice(&value.to_le_bytes())
        }
        (
            DataType::Decimal { scale, .. },
            Value::Decimal {
                unscaled,
                scale: value_scale,
            },
        ) if scale == value_scale => {
            out.extend_from_slice(&unscaled.to_le_bytes());
        }
        _ => {
            return Err(PhobosError::new(
                ErrorCode::TypeMismatch,
                "value does not match column type",
            ));
        }
    }
    Ok(())
}

fn decode_value(
    bytes: &[u8],
    cursor: &mut usize,
    data_type: &DataType,
) -> Result<Value, PhobosError> {
    match data_type {
        DataType::Int64 => Ok(Value::Int64(i64::from_le_bytes(take_array::<8>(
            bytes, cursor,
        )?))),
        DataType::Boolean => {
            let value = take_array::<1>(bytes, cursor)?[0];
            match value {
                0 => Ok(Value::Boolean(false)),
                1 => Ok(Value::Boolean(true)),
                _ => Err(PhobosError::new(
                    ErrorCode::InvalidPage,
                    "invalid boolean encoding",
                )),
            }
        }
        DataType::Float64 => Ok(Value::Float64(f64::from_bits(u64::from_le_bytes(
            take_array::<8>(bytes, cursor)?,
        )))),
        DataType::Text => String::from_utf8(take_bytes(bytes, cursor)?.to_vec())
            .map(Value::Text)
            .map_err(|_| PhobosError::new(ErrorCode::InvalidPage, "invalid UTF-8 text row value")),
        DataType::Binary => Ok(Value::Binary(take_bytes(bytes, cursor)?.to_vec())),
        DataType::Date => Ok(Value::Date(i32::from_le_bytes(take_array::<4>(
            bytes, cursor,
        )?))),
        DataType::Timestamp => Ok(Value::Timestamp(i64::from_le_bytes(take_array::<8>(
            bytes, cursor,
        )?))),
        DataType::Decimal { scale, .. } => Ok(Value::Decimal {
            unscaled: i128::from_le_bytes(take_array::<16>(bytes, cursor)?),
            scale: *scale,
        }),
    }
}

fn put_bytes(out: &mut Vec<u8>, bytes: &[u8]) -> Result<(), PhobosError> {
    let len = u32::try_from(bytes.len())
        .map_err(|_| PhobosError::new(ErrorCode::TypeMismatch, "variable value is too large"))?;
    out.extend_from_slice(&len.to_le_bytes());
    out.extend_from_slice(bytes);
    Ok(())
}

fn take_bytes<'a>(bytes: &'a [u8], cursor: &mut usize) -> Result<&'a [u8], PhobosError> {
    let len = u32::from_le_bytes(take_array::<4>(bytes, cursor)?) as usize;
    let end = cursor
        .checked_add(len)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidPage, "row offset overflow"))?;
    if end > bytes.len() {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "truncated variable row value",
        ));
    }
    let value = &bytes[*cursor..end];
    *cursor = end;
    Ok(value)
}

fn take_array<const N: usize>(bytes: &[u8], cursor: &mut usize) -> Result<[u8; N], PhobosError> {
    let end = cursor
        .checked_add(N)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidPage, "row offset overflow"))?;
    if end > bytes.len() {
        return Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "truncated fixed row value",
        ));
    }
    let value = bytes[*cursor..end].try_into().expect("fixed slice length");
    *cursor = end;
    Ok(value)
}

/// Heap table backed by a page file. Free space is discovered once at open and then maintained
/// in memory, so inserts do not scan every data page.
pub struct HeapTable {
    overlay: Option<std::sync::Arc<versioned_heap::StatementOverlay>>,
    schema: TableSchema,
    path: PathBuf,
    pool: BufferPool,
    free_space: Vec<usize>,
    free_space_map: FreeSpaceMap,
    flush_each_insert: bool,
    versioned: bool,
    statement: Option<std::sync::Arc<phobos_txn::mvcc::sessions::Statement>>,
    private_original: Option<(usize, bool)>,
    /// 0.1.9-B1 settled-visibility hints, shared with statement readers.
    hints: std::sync::Arc<versioned_heap::HintCache>,
}

impl HeapTable {
    pub fn attach_committed(
        &mut self,
        store: &std::sync::Arc<committed_pages::CommittedStore>,
        identity: phobos_wal::v2::FileId,
    ) -> Result<(), PhobosError> {
        self.pool.frames.clear();
        self.pool
            .file
            .file
            .attach_committed(store, &self.path, identity)
    }
    pub fn open(
        path: impl AsRef<Path>,
        schema: TableSchema,
        buffer_pages: usize,
    ) -> Result<Self, PhobosError> {
        Self::open_format(path.as_ref(), schema, buffer_pages, false)
    }
    pub fn open_versioned(
        path: impl AsRef<Path>,
        schema: TableSchema,
        buffer_pages: usize,
    ) -> Result<Self, PhobosError> {
        Self::open_format(path.as_ref(), schema, buffer_pages, true)
    }
    fn open_format(
        path: &Path,
        schema: TableSchema,
        buffer_pages: usize,
        versioned: bool,
    ) -> Result<Self, PhobosError> {
        let path = path.to_path_buf();
        let mut pool = BufferPool::open(&path, buffer_pages)?;
        let page_count = pool.page_count()?;
        pool.expected_versioned = Some(versioned);
        // Unknown free-space hints are resolved when an insert considers a page.
        // Startup verifies structure and endpoints; ordinary reads verify interiors.
        let mut free_space = vec![usize::MAX; page_count as usize];
        if page_count != 0 {
            for id in [0, page_count - 1] {
                if free_space[id as usize] != usize::MAX {
                    continue;
                }
                let page = pool.read_page(id)?;
                free_space[id as usize] = page.ordinary_free_space();
            }
        }
        let free_space_map = FreeSpaceMap::from_hints(&free_space);
        Ok(Self {
            schema,
            overlay: None,
            path,
            pool,
            free_space,
            free_space_map,
            flush_each_insert: true,
            versioned,
            statement: None,
            private_original: None,
            hints: std::sync::Arc::new(versioned_heap::HintCache::new()),
        })
    }

    #[must_use]
    pub fn path(&self) -> &Path {
        &self.path
    }

    #[must_use]
    pub fn schema(&self) -> &TableSchema {
        &self.schema
    }

    /// Refresh catalog metadata under the exclusive schema lease. Nullability
    /// has no effect on row encoding. Appending columns is allowed only when
    /// there are no physical tuple versions; existing layouts are never rewritten.
    pub fn rebind_names(&mut self, schema: &TableSchema) -> Result<(), PhobosError> {
        if self.schema.id != schema.id
            || self.schema.columns.len() > schema.columns.len()
            || self
                .schema
                .columns
                .iter()
                .zip(&schema.columns)
                .any(|(a, b)| a.data_type != b.data_type)
        {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "catalog refresh cannot change existing physical columns",
            ));
        }
        if self.schema.columns.len() != schema.columns.len() {
            let mut occupied = false;
            self.scan_versions(|_, _, _| {
                occupied = true;
                Ok(false)
            })?;
            if occupied {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "cannot append physical columns to occupied heap",
                ));
            }
        }
        self.schema = schema.clone();
        Ok(())
    }

    /// Only for private transaction staging. The owner must explicitly call `flush`
    /// before snapshotting these files. New-page and eviction synchronization remain
    /// unchanged, and the bounded buffer remains readable before flushing.
    pub fn defer_insert_flushes(&mut self) {
        self.flush_each_insert = false;
    }

    /// Enter private mode without cloning heap pages or the free-space vector.
    pub fn begin_private(
        &mut self,
        scratch: &Path,
        txn_id: u64,
        database: &Path,
    ) -> Result<(), PhobosError> {
        if self.private_original.is_some() {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "heap already private",
            ));
        }
        self.pool.flush_frames()?;
        self.pool.file.file.sync_before_private()?;
        self.pool
            .file
            .file
            .begin_private(scratch, txn_id, database)?;
        self.private_original = Some((self.free_space.len(), self.flush_each_insert));
        self.flush_each_insert = false;
        Ok(())
    }

    pub fn prepare_private(
        &mut self,
        visitor: impl FnMut(u64, &[u8; PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush()?;
        self.pool.file.file.prepare_private(visitor)
    }
    pub fn prepare_private_deferred(
        &mut self,
        visitor: impl FnMut(u64, &[u8; PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush()?;
        self.pool.file.file.prepare_private_deferred(visitor)
    }

    pub fn install_private(
        &mut self,
        receipt: &phobos_wal::v2::DurableCommit,
    ) -> Result<(), PhobosError> {
        // B1: republished pages drop their cache-resident hints first
        // (defensive; slot identities do not change, see `HintCache`).
        for page in self.pool.file.file.private_dirty_pages()? {
            self.hints.invalidate(page);
        }
        self.pool.file.file.install_private(receipt)?;
        if receipt.page_format() >= 2 {
            // Frames predating WAL preparation contain old version/LSN bytes.
            // HeapTable exposes no pin handles; invalidate its bounded cache.
            self.pool.frames.clear();
        }
        let (_, flush) = self
            .private_original
            .take()
            .expect("installed private heap");
        self.flush_each_insert = flush;
        Ok(())
    }

    pub fn prepare_private_redo(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush()?;
        self.pool.file.file.prepare_private_redo(file, visitor)
    }
    pub fn prepare_private_redo_phased(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; PAGE_SIZE],
            bool,
            page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush()?;
        self.pool
            .file
            .file
            .prepare_private_redo_phased(file, visitor)
    }
    /// 0.2-D: `prepare_private_redo_phased` with each page's base image.
    pub fn prepare_private_redo_based(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; PAGE_SIZE],
            Option<&[u8; PAGE_SIZE]>,
            bool,
            page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush()?;
        self.pool
            .file
            .file
            .prepare_private_redo_based(file, visitor)
    }
    pub fn force_committed(&mut self) -> Result<(), PhobosError> {
        self.pool.flush_frames()?;
        self.pool.file.file.force_committed()
    }

    pub fn stage_private(&mut self) -> Result<(), PhobosError> {
        self.pool.file.file.stage_private()?;
        self.pool.frames.clear();
        let (_, flush) = self.private_original.take().expect("staged private heap");
        self.flush_each_insert = flush;
        Ok(())
    }

    pub fn private_page_count(&mut self) -> Result<u64, PhobosError> {
        self.flush()?;
        self.pool.file.file.private_page_count()
    }
    pub fn prepare_pending_redo(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.pool
            .file
            .file
            .prepare_pending_redo(transaction, file, visitor)
    }
    pub fn prepare_pending_redo_phased(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; PAGE_SIZE],
            bool,
            page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.pool
            .file
            .file
            .prepare_pending_redo_phased(transaction, file, visitor)
    }
    /// 0.2-D: `prepare_pending_redo_phased` with each page's base image.
    pub fn prepare_pending_redo_based(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; PAGE_SIZE],
            Option<&[u8; PAGE_SIZE]>,
            bool,
            page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.pool
            .file
            .file
            .prepare_pending_redo_based(transaction, file, visitor)
    }

    pub fn install_pending(
        &mut self,
        receipt: &phobos_wal::v2::DurableCommit,
    ) -> Result<(), PhobosError> {
        self.pool.file.file.install_pending(receipt)?;
        self.pool.frames.clear();
        Ok(())
    }
    pub fn defer_private_cleanup(&mut self) -> Result<(), PhobosError> {
        self.pool.file.file.defer_private_cleanup()
    }

    /// On any error the owner must fence/reopen the database. Partial metadata
    /// restoration must never be exposed to a subsequent statement.
    pub fn rollback_private(&mut self) -> Result<(), PhobosError> {
        let (original_len, flush) = self
            .private_original
            .ok_or_else(|| PhobosError::new(ErrorCode::TransactionState, "heap is not private"))?;
        // Include dirty buffer frames that have not yet reached private scratch.
        self.flush()?;
        let free_space = &mut self.free_space;
        self.pool.file.file.visit_original_private(|id, bytes| {
            let page = SlottedPage::from_bytes(*bytes)?;
            let entry = free_space.get_mut(id as usize).ok_or_else(|| {
                PhobosError::new(ErrorCode::InvalidPage, "rollback free-space entry missing")
            })?;
            *entry = page.ordinary_free_space();
            Ok(())
        })?;
        self.pool.file.file.rollback_private()?;
        self.pool.frames.clear();
        self.free_space.truncate(original_len);
        self.free_space_map = FreeSpaceMap::from_hints(&self.free_space);
        self.flush_each_insert = flush;
        self.private_original = None;
        Ok(())
    }

    pub fn insert(&mut self, row: &Row) -> Result<RecordId, PhobosError> {
        self.require_legacy()?;
        self.insert_encoded(RowCodec::encode(&self.schema, row)?)
    }
    fn insert_encoded(&mut self, encoded: Vec<u8>) -> Result<RecordId, PhobosError> {
        self.pool.file.file.ensure_writable()?;
        if encoded.len() + SLOT_SIZE > PAGE_SIZE - HEADER_SIZE {
            return Err(PhobosError::new(
                ErrorCode::ConstraintViolation,
                "row is too large for a page",
            ));
        }
        let needed = encoded.len() + SLOT_SIZE;
        let mut learned_unknown = false;
        loop {
            let candidate = {
                let _lookup = phobos_observability::span("heap.free_space_lookup");
                let known = if self.versioned {
                    // K.5: finish pages already touched by this transaction,
                    // then the recent write frontier. Cold reuse must amortize
                    // a page touch over at least 1 KiB of reusable capacity.
                    // Sparse slack is bounded per page; dense pages are always
                    // consumed before allocating another page.
                    let local = self
                        .pool
                        .frames
                        .iter()
                        .filter(|(id, frame)| {
                            frame.dirty && self.free_space[**id as usize] >= needed
                        })
                        .max_by_key(|(_, frame)| frame.last_use)
                        .map(|(id, _)| *id)
                        .or_else(|| {
                            self.free_space_map.write_frontier.filter(|id| {
                                self.free_space
                                    .get(*id as usize)
                                    .is_some_and(|free| *free != usize::MAX && *free >= needed)
                            })
                        });
                    if let Some(id) = local {
                        self.free_space_map.remove(id, self.free_space[id as usize]);
                        phobos_observability::event("heap.reuse_local_page", 1);
                        Some(id)
                    } else {
                        if phobos_observability::profiling_enabled() && needed < 1024 {
                            phobos_observability::event(
                                "heap.reuse_skipped_cold",
                                self.free_space_map
                                    .by_bytes
                                    .range(needed..1024)
                                    .map(|(_, pages)| pages.len() as u64)
                                    .sum(),
                            );
                        }
                        self.free_space_map.take_known(needed.max(1024))
                    }
                } else {
                    self.free_space_map.take_known(needed)
                };
                known.or_else(|| {
                    if learned_unknown {
                        None
                    } else {
                        learned_unknown = true;
                        self.free_space_map.take_unknown()
                    }
                })
            };
            let Some(id) = candidate else {
                break;
            };
            {
                let index = id as usize;
                self.free_space_map.inspected += 1;
                phobos_observability::event("heap.selection_pages_inspected", 1);
                if !self.pool.file.file.uses_shared_cache() && heap_in_place_enabled() {
                    // 0.2-H: same selection, placement and free-space rules
                    // as below, applied to the private frame in place.
                    let (actual, inserted) = self.pool.modify_page(id, |page| {
                        // 0.2-I.1: accept only ordinary-tuple space (0 on
                        // overflow pages); a page learned from an unknown
                        // post-restart probe may be an overflow page.
                        let actual = page.ordinary_free_space();
                        if actual < needed {
                            return Ok(((actual, None), false));
                        }
                        let slot = page.insert_ordinary_unsealed(&encoded)?;
                        Ok(((actual, Some((slot, page.ordinary_free_space()))), true))
                    })?;
                    let old = self.free_space[index];
                    self.free_space[index] = actual;
                    self.free_space_map.update(id, old, actual);
                    let Some((slot, free)) = inserted else {
                        if learned_unknown {
                            break;
                        }
                        continue;
                    };
                    self.free_space_map.write_frontier = Some(id);
                    let old = self.free_space[index];
                    self.free_space[index] = free;
                    self.free_space_map.update(id, old, free);
                    // 0.2-K: the slot may have had an earlier occupant.
                    self.hints.forget_slot(id, slot);
                    if self.flush_each_insert {
                        self.pool.flush_all()?;
                    } else {
                        phobos_observability::certification_crash("dirty_staging");
                    }
                    return Ok(RecordId {
                        page_id: id,
                        slot_id: slot,
                    });
                }
                let mut page = self.pool.read_page(id)?;
                // 0.2-I.1: same overflow-aware rule as the in-place branch.
                let actual = page.ordinary_free_space();
                let old = self.free_space[index];
                self.free_space[index] = actual;
                self.free_space_map.update(id, old, actual);
                if actual < needed {
                    if learned_unknown {
                        break;
                    }
                    continue;
                }
                let slot = page.insert_ordinary(&encoded)?;
                self.free_space_map.write_frontier = Some(id);
                let free = page.ordinary_free_space();
                self.pool.put_dirty(page)?;
                let old = self.free_space[index];
                self.free_space[index] = free;
                self.free_space_map.update(id, old, free);
                self.hints.forget_slot(id, slot);
                if self.flush_each_insert {
                    self.pool.flush_all()?;
                } else {
                    phobos_observability::certification_crash("dirty_staging");
                }
                return Ok(RecordId {
                    page_id: id,
                    slot_id: slot,
                });
            }
        }
        let id = self.pool.page_count()?;
        let mut page = if self.versioned {
            SlottedPage::new_versioned(id)
        } else {
            SlottedPage::new(id)
        };
        let slot = page.insert_ordinary(&encoded)?;
        let free = page.free_space();
        self.pool.append(page)?;
        self.free_space.push(free);
        self.free_space_map.push(id, free);
        self.free_space_map.write_frontier = Some(id);
        Ok(RecordId {
            page_id: id,
            slot_id: slot,
        })
    }

    /// D5 diagnostic used by focused release tests.
    pub fn take_selection_pages_inspected(&mut self) -> u64 {
        std::mem::take(&mut self.free_space_map.inspected)
    }

    pub fn get(&mut self, rid: RecordId) -> Result<Option<Row>, PhobosError> {
        if let Some(overlay) = &self.overlay {
            if let Some(row) = overlay.row(rid)? {
                return Ok(Some(row));
            }
            if overlay.is_hidden(rid)? {
                return Ok(None);
            }
        }
        if let Some(statement) = self.statement.clone() {
            return self.get_visible(rid, statement.snapshot(), &mut statement.lookup_scope());
        }
        self.require_legacy()?;
        if rid.page_id >= self.pool.page_count()? {
            return Ok(None);
        }
        let page = self.pool.read_page(rid.page_id)?;
        match page.get(rid.slot_id)? {
            Some(bytes) => Ok(Some(RowCodec::decode(&self.schema, bytes)?)),
            None => Ok(None),
        }
    }

    pub fn scan(&mut self) -> Result<Vec<(RecordId, Row)>, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        if let Some(statement) = self.statement.clone() {
            let mut rows = Vec::new();
            let overlay = self.overlay.clone();
            self.scan_visible(
                statement.snapshot(),
                &mut statement.lookup_scope(),
                |rid, row| {
                    let hidden = match &overlay {
                        Some(overlay) => overlay.is_hidden(rid)?,
                        None => false,
                    };
                    if !hidden {
                        rows.push((rid, row));
                    }
                    Ok(true)
                },
            )?;
            if let Some(overlay) = &self.overlay {
                overlay.visit(|rid, row| {
                    cancellation_poll.checkpoint_at("lib.scan")?;
                    rows.push((rid, row));
                    Ok(true)
                })?;
            }
            return Ok(rows);
        }
        self.require_legacy()?;
        let _profile = phobos_observability::span("storage.scan");
        let mut rows = Vec::new();
        for id in 0..self.pool.page_count()? {
            cancellation_poll.checkpoint_at("lib.scan")?;
            let page = self.pool.read_page_scan(id)?;
            for slot in 0..page.slot_count() {
                cancellation_poll.checkpoint_at("lib.scan")?;
                if let Some(bytes) = page.get(slot)? {
                    let row = RowCodec::decode(&self.schema, bytes)?;
                    rows.push((
                        RecordId {
                            page_id: id,
                            slot_id: slot,
                        },
                        row,
                    ));
                }
            }
        }
        Ok(rows)
    }

    pub fn scan_visit<F>(&mut self, mut visitor: F) -> Result<(), PhobosError>
    where
        F: FnMut(RecordId, Row) -> Result<bool, PhobosError>,
    {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        if let Some(statement) = self.statement.clone() {
            let overlay = self.overlay.clone();
            let mut stopped = false;
            self.scan_visible(
                statement.snapshot(),
                &mut statement.lookup_scope(),
                |rid, row| {
                    let hidden = match &overlay {
                        Some(overlay) => overlay.is_hidden(rid)?,
                        None => false,
                    };
                    if hidden {
                        return Ok(true);
                    }
                    let more = visitor(rid, row)?;
                    stopped = !more;
                    Ok(more)
                },
            )?;
            if !stopped {
                self.visit_overlay(visitor)?;
            }
            return Ok(());
        }
        self.require_legacy()?;
        for id in 0..self.pool.page_count()? {
            cancellation_poll.checkpoint_at("lib.scan_visit")?;
            let page = self.pool.read_page_scan(id)?;
            for slot in 0..page.slot_count() {
                cancellation_poll.checkpoint_at("lib.scan_visit")?;
                if let Some(bytes) = page.get(slot)? {
                    let row = RowCodec::decode(&self.schema, bytes)?;
                    if !visitor(
                        RecordId {
                            page_id: id,
                            slot_id: slot,
                        },
                        row,
                    )? {
                        return Ok(());
                    }
                }
            }
        }
        Ok(())
    }

    /// 0.2-B Execution Engine v2 scan: visible rows with only `required`
    /// columns decoded as borrowed values (`ValueRef::Absent` elsewhere).
    /// Committed statement reads use the zero-copy projected kernel; any
    /// transaction-local overlay or legacy heap keeps the established owned
    /// traversal (own writes, hidden base rows) and is adapted to the same
    /// visitor, so both paths deliver identical rows in identical order.
    pub fn scan_visit_projected<F>(
        &mut self,
        required: &[bool],
        mut visitor: F,
    ) -> Result<(), PhobosError>
    where
        F: FnMut(RecordId, &[ValueRef<'_>]) -> Result<bool, PhobosError>,
    {
        if self.overlay.is_none() {
            if let Some(statement) = self.statement.clone() {
                return self.scan_visible_projected(
                    statement.snapshot(),
                    &mut statement.lookup_scope(),
                    required,
                    visitor,
                );
            }
        }
        self.scan_visit(|rid, row| visitor(rid, &versioned_heap::project_owned(&row, required)))
    }

    /// 0.2-B projected point fetch with `get` semantics (own writes first,
    /// hidden base rows skipped, then snapshot visibility). Returns whether a
    /// row was delivered to `visitor`.
    pub fn get_projected(
        &mut self,
        rid: RecordId,
        required: &[bool],
        visitor: &mut dyn FnMut(&[ValueRef<'_>]) -> Result<(), PhobosError>,
    ) -> Result<bool, PhobosError> {
        if let Some(overlay) = &self.overlay {
            if let Some(row) = overlay.row(rid)? {
                visitor(&versioned_heap::project_owned(&row, required))?;
                return Ok(true);
            }
            if overlay.is_hidden(rid)? {
                return Ok(false);
            }
        }
        if let Some(statement) = self.statement.clone() {
            return self.get_visible_projected(
                rid,
                statement.snapshot(),
                &mut statement.lookup_scope(),
                required,
                visitor,
            );
        }
        match self.get(rid)? {
            Some(row) => {
                visitor(&versioned_heap::project_owned(&row, required))?;
                Ok(true)
            }
            None => Ok(false),
        }
    }

    /// Fast committed COUNT(*) path. Transaction-local overlays retain the
    /// ordinary decoded scan so own writes and hidden base rows keep their
    /// established semantics.
    pub fn count_visible(&mut self) -> Result<u64, PhobosError> {
        if self.overlay.is_some() {
            let mut count = 0u64;
            self.scan_visit(|_, _| {
                phobos_observability::event("count_row_decodes", 1);
                count = count.saturating_add(1);
                Ok(true)
            })?;
            return Ok(count);
        }
        if let Some(statement) = self.statement.clone() {
            return self
                .count_visible_versions(statement.snapshot(), &mut statement.lookup_scope());
        }
        let mut count = 0u64;
        self.scan_visit(|_, _| {
            phobos_observability::event("count_row_decodes", 1);
            count = count.saturating_add(1);
            Ok(true)
        })?;
        Ok(count)
    }

    pub fn delete(&mut self, rid: RecordId) -> Result<bool, PhobosError> {
        self.require_legacy()?;
        self.pool.file.file.ensure_writable()?;
        if rid.page_id >= self.pool.page_count()? {
            return Ok(false);
        }
        let mut page = self.pool.read_page(rid.page_id)?;
        let deleted = page.delete(rid.slot_id)?;
        if deleted {
            self.pool.put_dirty(page)?;
        }
        Ok(deleted)
    }

    pub fn replace(&mut self, rid: RecordId, row: &Row) -> Result<RecordId, PhobosError> {
        if !self.delete(rid)? {
            return Err(PhobosError::new(
                ErrorCode::NotFound,
                "record does not exist",
            ));
        }
        self.insert(row)
    }

    #[must_use]
    pub fn cached_pages(&self) -> usize {
        self.pool.cached_pages()
    }

    pub fn flush(&mut self) -> Result<(), PhobosError> {
        self.pool.flush_all()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_types::ColumnSchema;
    use std::{
        env, fs,
        time::{SystemTime, UNIX_EPOCH},
    };

    #[test]
    fn dirty_replacement_preserves_all_pins_until_explicit_unpin() {
        let path = temp();
        let mut pool = BufferPool::open(&path, 1).unwrap();
        pool.append(SlottedPage::new(0)).unwrap();
        pool.append(SlottedPage::new(1)).unwrap();
        pool.pin(0).unwrap();
        pool.pin(0).unwrap();
        let mut page = pool.read_page(0).unwrap();
        page.insert(b"pinned update").unwrap();
        pool.put_dirty(page).unwrap();
        assert!(pool.read_page(1).is_err());
        pool.unpin(0).unwrap();
        assert!(pool.read_page(1).is_err());
        pool.unpin(0).unwrap();
        pool.read_page(1).unwrap();
        assert_eq!(
            pool.read_page(0).unwrap().get(0).unwrap(),
            Some(b"pinned update".as_slice())
        );
        drop(pool);
        fs::remove_file(path).unwrap();
    }

    #[test]
    fn failed_dirty_eviction_retains_the_only_modified_copy() {
        let path = temp();
        let mut pool = BufferPool::open(&path, 1).unwrap();
        pool.append(SlottedPage::new(0)).unwrap();
        pool.append(SlottedPage::new(1)).unwrap();
        let mut page = pool.read_page(0).unwrap();
        page.insert(b"retained after failure").unwrap();
        pool.put_dirty(page).unwrap();
        // A read-only handle deterministically rejects writes on every platform.
        pool.file.file = page_io::PageIo::new(fs::File::open(&path).unwrap());
        assert!(pool.read_page(1).is_err());
        assert!(pool.frames.get(&0).unwrap().dirty);
        assert_eq!(
            pool.read_page(0).unwrap().get(0).unwrap(),
            Some(b"retained after failure".as_slice())
        );
        pool.file = PageFile::open(&path).unwrap();
        pool.read_page(1).unwrap();
        drop(pool);
        let mut file = PageFile::open(&path).unwrap();
        assert_eq!(
            file.read(0).unwrap().get(0).unwrap(),
            Some(b"retained after failure".as_slice())
        );
        drop(file);
        fs::remove_file(path).unwrap();
    }

    /// 0.2-H heap mutation fast path (HP1–HP4, HP8, HP12): in-place
    /// mutation of the private frame leaves it dirty-unverified (stale
    /// checksum) until a sealing path hands the bytes out; every image that
    /// leaves the pool validates and equals the page the 0.2-G
    /// read/copy/insert/put_dirty sequence builds; eviction (spill to the
    /// private file), rollback and commit/reopen keep their behaviour.
    #[test]
    fn h_in_place_private_heap_mutation_seals_before_any_exposure() {
        use phobos_wal::v2::{Body, FileId, PageAction, Wal};
        let dir = temp();
        let mut wal = Wal::create(&dir).unwrap();
        let path = dir.join(FileId::Heap(2).name());
        let schema = TableSchema {
            id: 2,
            name: "inplace".into(),
            columns: vec![ColumnSchema {
                name: "value".into(),
                data_type: DataType::Text,
                nullable: false,
            }],
        };
        let mut heap = HeapTable::open(&path, schema.clone(), 2).unwrap();
        let committed = heap
            .insert(&Row::new(vec![Value::Text("base".into())]))
            .unwrap();
        let committed_bytes = fs::read(&path).unwrap();
        let id = wal.begin().unwrap();
        heap.begin_private(&dir.join("private"), id, &dir).unwrap();
        // HP1/HP2: mutate in place; the frame is dirty-unverified.
        let records = (0..20)
            .map(|n| Row::new(vec![Value::Text(format!("row-{n}"))]))
            .collect::<Vec<_>>();
        for row in &records {
            heap.insert(row).unwrap();
        }
        let frame = heap.pool.frames.get(&committed.page_id).unwrap();
        assert!(frame.dirty && !frame.sealed);
        assert!(
            validate_page_image(&frame.page.to_bytes()).is_err(),
            "stale checksum"
        );
        // The same page built by the 0.2-G sequence (insert + refresh each time).
        let mut expected =
            SlottedPage::from_bytes(committed_bytes[..PAGE_SIZE].try_into().unwrap()).unwrap();
        for row in &records {
            expected
                .insert(&RowCodec::encode(&schema, row).unwrap())
                .unwrap();
        }
        // A reader sees a sealed, valid copy equal to the expected page.
        let read = heap.pool.read_page(committed.page_id).unwrap();
        assert_eq!(read.to_bytes(), expected.to_bytes());
        assert!(heap.pool.frames.get(&committed.page_id).unwrap().sealed);
        // HP3/HP8: many more rows — new pages, eviction to the private file.
        for n in 0..2000 {
            heap.insert(&Row::new(vec![Value::Text(format!(
                "{n:04}{}",
                "y".repeat(200)
            ))]))
            .unwrap();
        }
        heap.flush().unwrap();
        assert!(
            heap.pool
                .frames
                .values()
                .all(|frame| frame.sealed && !frame.dirty)
        );
        // HP12: the committed base file is untouched by private mutation.
        assert_eq!(fs::read(&path).unwrap(), committed_bytes);
        // HP5: rollback discards every in-place change.
        heap.rollback_private().unwrap();
        wal.abort().unwrap();
        assert_eq!(heap.scan().unwrap().len(), 1);
        // HP4: publish — every logged image validates (sealed) and reopen
        // returns the rows.
        let id = wal.begin().unwrap();
        heap.begin_private(&dir.join("private"), id, &dir).unwrap();
        for row in &records {
            heap.insert(row).unwrap();
        }
        heap.prepare_private(|page, bytes, allocated| {
            validate_page_image(bytes)?;
            wal.append(Body::Page {
                action: if allocated {
                    PageAction::Initialize
                } else {
                    PageAction::HeapInsert
                },
                file: FileId::Heap(2),
                page,
                image: Box::new(*bytes),
            })?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        heap.install_private(&receipt).unwrap();
        assert_eq!(heap.scan().unwrap().len(), 21);
        drop(heap);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        let mut reopened = HeapTable::open(&path, schema, 2).unwrap();
        assert_eq!(reopened.scan().unwrap().len(), 21);
        drop(reopened);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn private_heap_rollback_restores_free_space_and_commit_survives_reopen() {
        use phobos_wal::v2::{Body, FileId, PageAction, Wal};
        let dir = temp();
        let mut wal = Wal::create(&dir).unwrap();
        let path = dir.join(FileId::Heap(1).name());
        let schema = TableSchema {
            id: 1,
            name: "private".into(),
            columns: vec![ColumnSchema {
                name: "value".into(),
                data_type: DataType::Text,
                nullable: false,
            }],
        };
        let mut heap = HeapTable::open(&path, schema.clone(), 2).unwrap();
        let original = Row::new(vec![Value::Text("original".into())]);
        let rid = heap.insert(&original).unwrap();
        let bytes = fs::read(&path).unwrap();
        let free = heap.free_space.clone();
        let scratch = dir.join("private");
        let id = wal.begin().unwrap();
        heap.begin_private(&scratch, id, &dir).unwrap();
        heap.delete(rid).unwrap();
        for _ in 0..2000 {
            heap.insert(&Row::new(vec![Value::Text("x".repeat(300))]))
                .unwrap();
        }
        heap.flush().unwrap();
        assert_eq!(fs::read(&path).unwrap(), bytes);
        heap.rollback_private().unwrap();
        wal.abort().unwrap();
        assert_eq!(heap.free_space, free);
        assert_eq!(heap.scan().unwrap(), vec![(rid, original.clone())]);
        assert!(!scratch.exists());

        let id = wal.begin().unwrap();
        heap.begin_private(&scratch, id, &dir).unwrap();
        let second = Row::new(vec![Value::Text("committed".into())]);
        heap.insert(&second).unwrap();
        heap.prepare_private(|page, bytes, allocated| {
            wal.append(Body::Page {
                action: if allocated {
                    PageAction::Initialize
                } else {
                    PageAction::HeapInsert
                },
                file: FileId::Heap(1),
                page,
                image: Box::new(*bytes),
            })?;
            Ok(())
        })
        .unwrap();
        assert!(heap.insert(&original).is_err());
        assert!(heap.delete(rid).is_err());
        let receipt = wal.commit().unwrap();
        heap.install_private(&receipt).unwrap();
        assert_eq!(heap.scan().unwrap().len(), 2);
        drop(heap);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        let mut heap = HeapTable::open(&path, schema, 2).unwrap();
        assert_eq!(
            heap.scan()
                .unwrap()
                .into_iter()
                .map(|(_, row)| row)
                .collect::<Vec<_>>(),
            vec![original, second]
        );
        drop(heap);
        fs::remove_dir_all(dir).unwrap();
    }

    fn temp() -> PathBuf {
        let value = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        env::temp_dir().join(format!("phobos-storage-{value}.phdb"))
    }

    fn schema() -> TableSchema {
        TableSchema {
            id: 1,
            name: "items".to_string(),
            columns: vec![
                ColumnSchema {
                    name: "id".to_string(),
                    data_type: DataType::Int64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "name".to_string(),
                    data_type: DataType::Text,
                    nullable: true,
                },
                ColumnSchema {
                    name: "amount".to_string(),
                    data_type: DataType::Decimal {
                        precision: 12,
                        scale: 2,
                    },
                    nullable: false,
                },
            ],
        }
    }

    #[test]
    fn insert_get_delete() {
        let mut page = SlottedPage::new(7);
        let slot = page.insert(b"hello").unwrap();
        assert_eq!(page.get(slot).unwrap(), Some(&b"hello"[..]));
        assert!(page.delete(slot).unwrap());
        assert_eq!(page.get(slot).unwrap(), None);
    }

    #[test]
    fn encoded_page_round_trip() {
        let mut page = SlottedPage::new(3);
        page.insert(b"abc").unwrap();
        let decoded = SlottedPage::from_bytes(page.to_bytes()).unwrap();
        assert_eq!(decoded.page_id(), 3);
        assert_eq!(decoded.get(0).unwrap(), Some(&b"abc"[..]));
    }

    /// The bulk primitive defers the checksum: an unsealed page is rejected by
    /// `from_bytes` exactly like corruption, and sealing makes it byte-identical
    /// to a page built with per-tuple `insert`.
    #[test]
    fn unsealed_bulk_inserts_are_rejected_until_sealed_and_then_match_insert() {
        let mut deferred = SlottedPage::new_versioned(7);
        let mut eager = SlottedPage::new_versioned(7);
        for record in [&b"one"[..], b"two", b"three"] {
            deferred.insert_unsealed(record).unwrap();
            eager.insert(record).unwrap();
        }
        assert_eq!(
            SlottedPage::from_bytes(deferred.to_bytes())
                .unwrap_err()
                .code,
            ErrorCode::ChecksumMismatch
        );
        deferred.seal();
        assert_eq!(deferred.to_bytes(), eager.to_bytes());
        let decoded = SlottedPage::from_bytes(deferred.to_bytes()).unwrap();
        assert_eq!(decoded.get(2).unwrap(), Some(&b"three"[..]));
        // Corruption of a sealed bulk page is still detected.
        let mut bytes = deferred.to_bytes();
        bytes[PAGE_SIZE - 2] ^= 0x01;
        assert_eq!(
            SlottedPage::from_bytes(bytes).unwrap_err().code,
            ErrorCode::ChecksumMismatch
        );
    }

    #[test]
    fn corruption_is_detected() {
        let page = SlottedPage::new(0);
        let mut bytes = page.to_bytes();
        bytes[100] ^= 0x80;
        assert_eq!(
            SlottedPage::from_bytes(bytes).unwrap_err().code,
            ErrorCode::ChecksumMismatch
        );
    }

    #[test]
    fn empty_page_golden_header() {
        let page = SlottedPage::new(0);
        let bytes = page.to_bytes();
        assert_eq!(&bytes[0..8], &[b'P', b'H', b'O', b'P', 1, 0, 1, 1]);
        assert_eq!(
            u32::from_le_bytes(bytes[32..36].try_into().unwrap()),
            0xea51_d28f
        );
    }

    #[test]
    fn row_codec_round_trip_all_phase1_types() {
        let schema = TableSchema {
            id: 9,
            name: "types".to_string(),
            columns: vec![
                ColumnSchema {
                    name: "i".to_string(),
                    data_type: DataType::Int64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "b".to_string(),
                    data_type: DataType::Boolean,
                    nullable: false,
                },
                ColumnSchema {
                    name: "f".to_string(),
                    data_type: DataType::Float64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "t".to_string(),
                    data_type: DataType::Text,
                    nullable: true,
                },
                ColumnSchema {
                    name: "bin".to_string(),
                    data_type: DataType::Binary,
                    nullable: false,
                },
                ColumnSchema {
                    name: "d".to_string(),
                    data_type: DataType::Date,
                    nullable: false,
                },
                ColumnSchema {
                    name: "ts".to_string(),
                    data_type: DataType::Timestamp,
                    nullable: false,
                },
                ColumnSchema {
                    name: "n".to_string(),
                    data_type: DataType::Decimal {
                        precision: 10,
                        scale: 2,
                    },
                    nullable: false,
                },
            ],
        };
        let row = Row::new(vec![
            Value::Int64(-44),
            Value::Boolean(true),
            Value::Float64(3.5),
            Value::Null,
            Value::Binary(vec![0, 1, 255]),
            Value::Date(20_000),
            Value::Timestamp(123_456_789),
            Value::Decimal {
                unscaled: 12345,
                scale: 2,
            },
        ]);
        let encoded = RowCodec::encode(&schema, &row).unwrap();
        assert_eq!(RowCodec::decode(&schema, &encoded).unwrap(), row);
    }

    #[test]
    fn restart_readback() {
        let path = temp();
        {
            let mut table = HeapTable::open(&path, schema(), 2).unwrap();
            table
                .insert(&Row::new(vec![
                    Value::Int64(1),
                    Value::Text("persistent".to_string()),
                    Value::Decimal {
                        unscaled: 999,
                        scale: 2,
                    },
                ]))
                .unwrap();
        }
        {
            let mut table = HeapTable::open(&path, schema(), 2).unwrap();
            let rows = table.scan().unwrap();
            assert_eq!(rows.len(), 1);
            assert_eq!(rows[0].1.values[1], Value::Text("persistent".to_string()));
        }
        let _ = fs::remove_file(path);
    }

    #[test]
    fn table_can_exceed_buffer_pool() {
        let path = temp();
        let mut table = HeapTable::open(&path, schema(), 2).unwrap();
        for id in 0..2_000 {
            table
                .insert(&Row::new(vec![
                    Value::Int64(id),
                    Value::Text("x".repeat(120)),
                    Value::Decimal {
                        unscaled: i128::from(id),
                        scale: 2,
                    },
                ]))
                .unwrap();
        }
        assert!(table.scan().unwrap().len() == 2_000);
        assert!(table.cached_pages() <= 2);
        let _ = fs::remove_file(path);
    }
    #[test]
    fn staged_inserts_survive_eviction_and_explicit_flush() {
        let path = temp();
        {
            let mut table = HeapTable::open(&path, schema(), 2).unwrap();
            let make_row = |id: i64| {
                Row::new(vec![
                    Value::Int64(id),
                    Value::Text("x".repeat(120)),
                    Value::Decimal {
                        unscaled: i128::from(id),
                        scale: 2,
                    },
                ])
            };
            table.insert(&make_row(0)).unwrap();
            table.insert(&make_row(1)).unwrap();
            {
                // Ordinary heap insertion must remain visible on disk before Drop.
                let mut disk = HeapTable::open(&path, schema(), 2).unwrap();
                assert_eq!(disk.scan().unwrap().len(), 2);
            }
            table.defer_insert_flushes();
            for id in 2..2000 {
                table.insert(&make_row(id)).unwrap();
            }
            assert!(table.pool.frames.values().any(|frame| frame.dirty));
            assert!(table.cached_pages() <= 2);
            table.flush().unwrap();
            // Observe disk through an independent pool before Drop can flush anything.
            let mut disk = HeapTable::open(&path, schema(), 2).unwrap();
            assert_eq!(disk.scan().unwrap().len(), 2000);
            for (id, (_, row)) in disk.scan().unwrap().iter().enumerate() {
                assert_eq!(
                    row.values,
                    vec![
                        Value::Int64(id as i64),
                        Value::Text("x".repeat(120)),
                        Value::Decimal {
                            unscaled: id as i128,
                            scale: 2
                        }
                    ]
                );
            }
        }
        {
            let mut table = HeapTable::open(&path, schema(), 2).unwrap();
            for (id, (_, row)) in table.scan().unwrap().iter().enumerate() {
                assert_eq!(row.values[0], Value::Int64(id as i64));
            }
            assert_eq!(table.scan().unwrap().len(), 2000);
        }
        fs::remove_file(path).unwrap();
    }

    #[test]
    fn d5_free_space_candidates_are_bounded_and_stale_hints_self_correct() {
        let path = temp();
        let row = |id, bytes| {
            Row::new(vec![
                Value::Int64(id),
                Value::Text("x".repeat(bytes)),
                Value::Decimal {
                    unscaled: id as i128,
                    scale: 2,
                },
            ])
        };
        let mut table = HeapTable::open(&path, schema(), 2).unwrap();
        for id in 0..5 {
            table.insert(&row(id, 6000)).unwrap();
        }
        assert_eq!(table.pool.page_count().unwrap(), 5);
        table.take_selection_pages_inspected();
        let rid = table.insert(&row(10, 32)).unwrap();
        assert!(rid.page_id < 5);
        assert_eq!(table.take_selection_pages_inspected(), 1);
        eprintln!("D5_COUNTERS populated_pages=5 pages_inspected=1");

        let old = table.free_space[0];
        table.free_space_map.update(0, old, PAGE_SIZE);
        table.free_space[0] = PAGE_SIZE;
        let rid = table.insert(&row(11, 7000)).unwrap();
        assert_eq!(rid.page_id, 5);
        assert_eq!(table.take_selection_pages_inspected(), 1);
        assert_ne!(table.free_space[0], PAGE_SIZE);
        drop(table);

        let mut reopened = HeapTable::open(&path, schema(), 2).unwrap();
        let rid = reopened.insert(&row(12, 16)).unwrap();
        assert!(rid.page_id < 6);
        assert_eq!(reopened.take_selection_pages_inspected(), 1);
        drop(reopened);
        fs::remove_file(path).unwrap();
    }
}

#[cfg(test)]
mod lifecycle_tests;
#[cfg(test)]
mod phase_b_tests;
