//! 0.2-I.1 overflow safety: offline detection and repair of heap overflow
//! pages that received ordinary heap tuples (0.2-I post-restart free-space
//! defect, see `docs/overflow_safety_0_2_i_1.md`).
//!
//! Invariant: an overflow page holds exactly one slot, slot 0, which is either
//! a `PHOV` overflow chunk record or a tombstone (released chunk). Anything
//! else is a violation.
//!
//! Repair never moves an ordinary tuple, so no RecordId, index entry, UNIQUE
//! reference or `previous` pointer changes. Instead:
//! * a live chunk on a damaged page is copied verbatim to a new overflow page
//!   appended to the heap, and the single reference to it (the previous
//!   chunk's `next` field, or the row envelope's `first_page` for the first
//!   chunk) is redirected;
//! * the damaged page then becomes an ordinary heap page: slot 0 is
//!   tombstoned (it never was a RecordId target), the overflow flag is cleared
//!   and the page is compacted.
//!
//! Everything here works on page images of a heap file that the caller has
//! taken offline; nothing is written except through [`write_repaired_heap`],
//! which writes a temporary file and atomically renames it.
use crate::tuple_version::TupleVersion;
use crate::{
    FLAGS_OFFSET, HEADER_SIZE, PAGE_FLAG_OVERFLOW, PAGE_FLAG_RECLAIM_CANDIDATE, PAGE_SIZE,
    SLOT_SIZE, SlottedPage,
};
use phobos_error::{ErrorCode, PhobosError};
use phobos_types::PageId;
use std::{
    collections::BTreeMap,
    fmt,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
};

const NO_OVERFLOW_PAGE: u64 = u64::MAX;
const CHUNK_MAGIC: &[u8; 4] = b"PHOV";
/// Offsets inside an overflow chunk record (`write_overflow`).
const CHUNK_NEXT: std::ops::Range<usize> = 8..16;
const CHUNK_ORDINAL: std::ops::Range<usize> = 16..20;
/// Offset of `first_page` inside a version-2 (overflow) tuple envelope.
const ENVELOPE_FIRST_PAGE: std::ops::Range<usize> = 48..56;

fn error(message: impl Into<String>) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}

/// State of slot 0 of an overflow page.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChunkState {
    /// Live `PHOV` chunk record with its chain ordinal.
    Live { ordinal: u32 },
    /// Released chunk (tombstone).
    Released,
    /// Slot 0 holds something that is not an overflow chunk.
    Foreign,
    /// The page has no slots at all.
    Missing,
}

/// One overflow page that breaks the overflow-page invariant.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OverflowViolation {
    pub page_id: PageId,
    pub slot_count: u16,
    pub chunk: ChunkState,
    /// Slots (other than slot 0) that hold ordinary heap tuple envelopes.
    pub ordinary_slots: Vec<u16>,
    /// Non-empty slots (other than slot 0) that are not tuple envelopes.
    pub foreign_slots: Vec<u16>,
}

impl fmt::Display for OverflowViolation {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "page {} kind=overflow slot_count={} (valid overflow pages have exactly 1) slot0={:?} ordinary_tuple_slots={:?}",
            self.page_id, self.slot_count, self.chunk, self.ordinary_slots
        )?;
        if !self.foreign_slots.is_empty() {
            write!(f, " unrecognised_slots={:?}", self.foreign_slots)?;
        }
        Ok(())
    }
}

/// Streams every page of a heap file (checksums and structure validated),
/// holding one page at a time. Returns the page count.
fn visit_pages(
    path: &Path,
    mut visit: impl FnMut(SlottedPage) -> Result<(), PhobosError>,
) -> Result<u64, PhobosError> {
    let mut file = File::open(path)?;
    let length = file.metadata()?.len();
    if length % PAGE_SIZE as u64 != 0 {
        return Err(error("heap file length is not page aligned"));
    }
    let pages = length / PAGE_SIZE as u64;
    for id in 0..pages {
        let mut bytes = [0u8; PAGE_SIZE];
        file.read_exact(&mut bytes)?;
        let page = SlottedPage::from_bytes(bytes)?;
        if page.page_id() != id {
            return Err(error(format!(
                "heap page {id} carries identity {}",
                page.page_id()
            )));
        }
        visit(page)?;
    }
    Ok(pages)
}

/// Reads every page of a heap file into memory. Used only by the offline
/// repair, which needs random access to patch references; memory use is
/// about the size of the heap file.
fn read_pages(path: &Path) -> Result<Vec<SlottedPage>, PhobosError> {
    let mut pages = Vec::new();
    visit_pages(path, |page| {
        pages.push(page);
        Ok(())
    })?;
    Ok(pages)
}

fn chunk_state(page: &SlottedPage) -> Result<ChunkState, PhobosError> {
    if page.slot_count() == 0 {
        return Ok(ChunkState::Missing);
    }
    Ok(match page.get(0)? {
        None => ChunkState::Released,
        Some(record) if record.len() >= 32 && &record[..4] == CHUNK_MAGIC => ChunkState::Live {
            ordinal: u32::from_le_bytes(record[CHUNK_ORDINAL].try_into().expect("ordinal")),
        },
        Some(_) => ChunkState::Foreign,
    })
}

fn is_tuple_envelope(record: &[u8]) -> bool {
    TupleVersion::decode_header(record).is_ok()
}

/// Inspects one page; `None` when it is not an overflow page or is valid.
fn violation(page: &SlottedPage) -> Result<Option<OverflowViolation>, PhobosError> {
    if !page.is_overflow() {
        return Ok(None);
    }
    let chunk = chunk_state(page)?;
    let mut ordinary_slots = Vec::new();
    let mut foreign_slots = Vec::new();
    for slot in 1..page.slot_count() {
        if let Some(record) = page.get(slot)? {
            if is_tuple_envelope(record) {
                ordinary_slots.push(slot);
            } else {
                foreign_slots.push(slot);
            }
        }
    }
    let valid =
        page.slot_count() == 1 && matches!(chunk, ChunkState::Live { .. } | ChunkState::Released);
    Ok((!valid).then_some(OverflowViolation {
        page_id: page.page_id(),
        slot_count: page.slot_count(),
        chunk,
        ordinary_slots,
        foreign_slots,
    }))
}

/// Read-only audit of a heap file: every overflow page that violates the
/// overflow-page invariant. An empty result means the file is healthy.
/// Streams the file; memory use is one page plus the violations found.
pub fn scan_overflow_violations(path: &Path) -> Result<Vec<OverflowViolation>, PhobosError> {
    let mut found = Vec::new();
    visit_pages(path, |page| {
        if let Some(v) = violation(&page)? {
            found.push(v);
        }
        Ok(())
    })?;
    Ok(found)
}

/// Where the single reference to an overflow chunk lives.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChunkReference {
    /// `first_page` of an overflow tuple envelope at (page, slot).
    Envelope { page: PageId, slot: u16 },
    /// `next` field of the chunk record on this overflow page.
    PreviousChunk { page: PageId },
}

/// One action taken (or planned) by the repair.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RepairAction {
    /// Live chunk copied verbatim from `from` to new overflow page `to`;
    /// `reference` redirected from `from` to `to`.
    RelocateChunk {
        from: PageId,
        to: PageId,
        ordinal: u32,
        reference: ChunkReference,
    },
    /// Damaged page turned into an ordinary heap page; its ordinary tuples
    /// keep their slots (RecordIds unchanged).
    ConvertToOrdinary {
        page: PageId,
        dropped_chunk_slot: bool,
        ordinary_slots: Vec<u16>,
    },
}

impl fmt::Display for RepairAction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RelocateChunk {
                from,
                to,
                ordinal,
                reference,
            } => write!(
                f,
                "relocate overflow chunk ordinal {ordinal} from page {from} to new page {to}; redirect {reference:?}"
            ),
            Self::ConvertToOrdinary {
                page,
                dropped_chunk_slot,
                ordinary_slots,
            } => write!(
                f,
                "convert page {page} to an ordinary heap page (slot 0 {}; ordinary tuples kept in slots {ordinary_slots:?}, RecordIds unchanged)",
                if *dropped_chunk_slot {
                    "tombstoned after relocation"
                } else {
                    "already a released tombstone"
                }
            ),
        }
    }
}

/// A computed, not yet written repair of one heap file.
pub struct OverflowRepair {
    pub violations: Vec<OverflowViolation>,
    pub actions: Vec<RepairAction>,
    pub original_pages: u64,
    pages: Vec<SlottedPage>,
}

impl OverflowRepair {
    #[must_use]
    pub fn final_pages(&self) -> u64 {
        self.pages.len() as u64
    }
}

/// Maps every live overflow chunk page to the one place that references it.
/// More than one reference to a page is reported as an error (no guessing).
fn chunk_references(
    pages: &[SlottedPage],
) -> Result<BTreeMap<PageId, ChunkReference>, PhobosError> {
    let mut references = BTreeMap::new();
    let mut add = |target: PageId, reference: ChunkReference| -> Result<(), PhobosError> {
        if references.insert(target, reference).is_some() {
            return Err(error(format!(
                "overflow page {target} is referenced more than once; refusing to repair"
            )));
        }
        Ok(())
    };
    for page in pages {
        let first_tuple_slot = if page.is_overflow() {
            if let Some(record) = page.get(0)? {
                if record.len() >= 32 && &record[..4] == CHUNK_MAGIC {
                    let next = u64::from_le_bytes(record[CHUNK_NEXT].try_into().expect("next"));
                    if next != NO_OVERFLOW_PAGE {
                        add(
                            next,
                            ChunkReference::PreviousChunk {
                                page: page.page_id(),
                            },
                        )?;
                    }
                }
            }
            // A damaged overflow page may itself hold misplaced tuples,
            // including overflow-row envelopes, in slots 1.. .
            1
        } else {
            0
        };
        for slot in first_tuple_slot..page.slot_count() {
            let Some(record) = page.get(slot)? else {
                continue;
            };
            if let Some((_, reference)) = TupleVersion::decode_overflow(record)? {
                add(
                    reference.first_page,
                    ChunkReference::Envelope {
                        page: page.page_id(),
                        slot,
                    },
                )?;
            }
        }
    }
    Ok(references)
}

/// Rebuilds the overflow page `id` holding exactly `record` (a chunk copied
/// verbatim), stamped with `lsn`.
fn chunk_page(id: PageId, record: &[u8], lsn: u64) -> Result<SlottedPage, PhobosError> {
    let mut page = SlottedPage::new_overflow(id);
    page.insert(record)?;
    page.put_u64(16, lsn);
    page.refresh_checksum();
    Ok(page)
}

fn patch_reference(
    pages: &mut [SlottedPage],
    reference: ChunkReference,
    to: PageId,
) -> Result<(), PhobosError> {
    let (page_id, slot, field) = match reference {
        ChunkReference::Envelope { page, slot } => (page, slot, ENVELOPE_FIRST_PAGE),
        ChunkReference::PreviousChunk { page } => (page, 0, CHUNK_NEXT),
    };
    let page = pages
        .get_mut(page_id as usize)
        .ok_or_else(|| error("overflow reference points outside the heap"))?;
    let offset = HEADER_SIZE + usize::from(slot) * SLOT_SIZE;
    let start = usize::from(page.get_u16(offset));
    let length = usize::from(page.get_u16(offset + 2));
    if length < field.end {
        return Err(error("overflow reference record is too short"));
    }
    page.bytes[start + field.start..start + field.end].copy_from_slice(&to.to_le_bytes());
    page.refresh_checksum();
    Ok(())
}

/// Plans and applies (in memory) the repair of one heap file. Refuses, with
/// an error and without side effects, any state it cannot explain exactly.
pub fn plan_overflow_repair(path: &Path) -> Result<OverflowRepair, PhobosError> {
    let mut pages = read_pages(path)?;
    let original_pages = pages.len() as u64;
    let mut violations = Vec::new();
    for page in &pages {
        if let Some(v) = violation(page)? {
            violations.push(v);
        }
    }
    let mut actions = Vec::new();
    if violations.is_empty() {
        return Ok(OverflowRepair {
            violations,
            actions,
            original_pages,
            pages,
        });
    }
    for v in &violations {
        if !v.foreign_slots.is_empty() {
            return Err(error(format!(
                "{v}: unrecognised records; refusing to repair"
            )));
        }
        if matches!(v.chunk, ChunkState::Foreign | ChunkState::Missing) {
            return Err(error(format!(
                "{v}: slot 0 is not an overflow chunk; refusing to repair"
            )));
        }
    }
    let references = chunk_references(&pages)?;
    // Relocate live chunks first, recording where each damaged page's chunk
    // went so a reference held by another damaged page is patched correctly.
    let mut relocated: BTreeMap<PageId, PageId> = BTreeMap::new();
    for v in &violations {
        if let ChunkState::Live { ordinal } = v.chunk {
            let reference = *references.get(&v.page_id).ok_or_else(|| {
                error(format!(
                    "{v}: live chunk is not referenced by any overflow row; refusing to repair"
                ))
            })?;
            let source = &pages[v.page_id as usize];
            let record = source.get(0)?.expect("live chunk").to_vec();
            let to = pages.len() as PageId;
            pages.push(chunk_page(to, &record, source.page_lsn())?);
            relocated.insert(v.page_id, to);
            actions.push(RepairAction::RelocateChunk {
                from: v.page_id,
                to,
                ordinal,
                reference,
            });
        }
    }
    for action in &actions {
        if let RepairAction::RelocateChunk { to, reference, .. } = *action {
            // A previous-chunk reference held by a page that was itself
            // relocated lives in the relocated copy.
            let reference = match reference {
                ChunkReference::PreviousChunk { page } => ChunkReference::PreviousChunk {
                    page: relocated.get(&page).copied().unwrap_or(page),
                },
                envelope => envelope,
            };
            patch_reference(&mut pages, reference, to)?;
        }
    }
    for v in &violations {
        let page = &mut pages[v.page_id as usize];
        let dropped = matches!(v.chunk, ChunkState::Live { .. });
        if dropped && !page.delete(0)? {
            return Err(error("chunk slot vanished during repair"));
        }
        page.bytes[FLAGS_OFFSET] &= !PAGE_FLAG_OVERFLOW;
        // The ordinary tuples may hold reclaimable versions that no reclaim
        // pass could inspect while the page was flagged as overflow.
        page.bytes[FLAGS_OFFSET] |= PAGE_FLAG_RECLAIM_CANDIDATE;
        page.compact()?;
        actions.push(RepairAction::ConvertToOrdinary {
            page: v.page_id,
            dropped_chunk_slot: dropped,
            ordinary_slots: v.ordinary_slots.clone(),
        });
    }
    // Self-check before anything is written: invariant restored, every chain
    // walks cleanly, every page validates.
    for page in &pages {
        SlottedPage::from_bytes(page.bytes)?;
        if let Some(v) = violation(page)? {
            return Err(error(format!("repair self-check failed: {v}")));
        }
    }
    verify_chains(&pages)?;
    Ok(OverflowRepair {
        violations,
        actions,
        original_pages,
        pages,
    })
}

/// Walks every overflow chain from its envelope: each page must be a valid
/// overflow page with a live chunk of the expected ordinal.
fn verify_chains(pages: &[SlottedPage]) -> Result<(), PhobosError> {
    for page in pages.iter().filter(|page| !page.is_overflow()) {
        for slot in 0..page.slot_count() {
            let Some(record) = page.get(slot)? else {
                continue;
            };
            let Some((_, reference)) = TupleVersion::decode_overflow(record)? else {
                continue;
            };
            let mut next = reference.first_page;
            for ordinal in 0..reference.page_count {
                let chunk = pages
                    .get(next as usize)
                    .ok_or_else(|| error("overflow chain leaves the heap"))?;
                if !chunk.is_overflow() || chunk.slot_count() != 1 {
                    return Err(error(format!(
                        "overflow chain page {next} is not a valid overflow page"
                    )));
                }
                let record = chunk
                    .get(0)?
                    .ok_or_else(|| error(format!("overflow chain page {next} is released")))?;
                if &record[..4] != CHUNK_MAGIC
                    || u32::from_le_bytes(record[CHUNK_ORDINAL].try_into().expect("ordinal"))
                        != ordinal
                {
                    return Err(error(format!(
                        "overflow chain page {next} has the wrong chunk"
                    )));
                }
                next = u64::from_le_bytes(record[CHUNK_NEXT].try_into().expect("next"));
            }
            if next != NO_OVERFLOW_PAGE {
                return Err(error("overflow chain is longer than its envelope declares"));
            }
        }
    }
    Ok(())
}

fn temporary_path(path: &Path) -> PathBuf {
    let mut name = path.file_name().unwrap_or_default().to_os_string();
    name.push(".overflow-repair.tmp");
    path.with_file_name(name)
}

/// Writes the repaired image of `path` crash-safely: a complete temporary
/// file is written and forced, then atomically renamed over the heap file and
/// the directory is forced. A crash leaves either the old or the new file.
pub fn write_repaired_heap(path: &Path, repair: &OverflowRepair) -> Result<(), PhobosError> {
    let temporary = temporary_path(path);
    let _ = fs::remove_file(&temporary);
    {
        let mut file = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&temporary)?;
        for page in &repair.pages {
            file.write_all(&page.bytes)?;
        }
        file.sync_all()?;
    }
    // Re-read (streaming: checksum, structure, identity) and re-audit what
    // actually reached the disk before replacing.
    let mut damaged = 0usize;
    let written = visit_pages(&temporary, |page| {
        damaged += usize::from(violation(&page)?.is_some());
        Ok(())
    })?;
    if written != repair.pages.len() as u64 || damaged != 0 {
        let _ = fs::remove_file(&temporary);
        return Err(error(
            "repaired heap image failed verification; original untouched",
        ));
    }
    fs::rename(&temporary, path)?;
    sync_parent(path)
}

/// Forces the directory entry of `path` after a rename. On POSIX this is
/// what makes the rename durable. The standard library cannot fsync a
/// directory on Windows, so there the rename's durability relies on the
/// file system's metadata journaling and is NOT verified by this release.
pub fn sync_parent(path: &Path) -> Result<(), PhobosError> {
    #[cfg(not(windows))]
    if let Some(parent) = path.parent() {
        File::open(parent)?.sync_all()?;
    }
    #[cfg(windows)]
    let _ = path;
    Ok(())
}

/// Removes a temporary file left by an interrupted repair.
pub fn remove_stale_repair_file(path: &Path) -> Result<bool, PhobosError> {
    let temporary = temporary_path(path);
    if temporary.exists() {
        fs::remove_file(temporary)?;
        return Ok(true);
    }
    Ok(false)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tuple_version::OverflowReference;
    use crate::{HeapTable, RowCodec};
    use phobos_txn::mvcc::Version;
    use phobos_types::{ColumnSchema, DataType, RecordId, Row, TableSchema, Value};

    const CHUNK: usize = PAGE_SIZE - HEADER_SIZE - SLOT_SIZE - 32;

    fn root(label: &str) -> PathBuf {
        let path = std::env::temp_dir().join(format!(
            "phobos-i1-1-{label}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&path).unwrap();
        path
    }
    fn schema() -> TableSchema {
        TableSchema {
            id: 1,
            name: "t".into(),
            columns: vec![
                ColumnSchema {
                    name: "id".into(),
                    data_type: DataType::Int64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "pad".into(),
                    data_type: DataType::Text,
                    nullable: true,
                },
            ],
        }
    }
    fn row(id: i64, len: usize) -> Row {
        Row {
            values: vec![Value::Int64(id), Value::Text("x".repeat(len))],
        }
    }
    fn tuple(logical_row: u64) -> TupleVersion {
        TupleVersion {
            logical_row,
            visibility: Version {
                creator: 1,
                deleter: None,
            },
            previous: None,
        }
    }
    fn inline(id: i64, len: usize) -> Vec<u8> {
        tuple(id as u64).encode(&schema(), &row(id, len)).unwrap()
    }
    fn chunk_record(next: u64, ordinal: u32, chunk: &[u8], total: usize) -> Vec<u8> {
        let mut record = vec![0; 32];
        record[..4].copy_from_slice(CHUNK_MAGIC);
        record[4..6].copy_from_slice(&1u16.to_le_bytes());
        record[8..16].copy_from_slice(&next.to_le_bytes());
        record[16..20].copy_from_slice(&ordinal.to_le_bytes());
        record[20..24].copy_from_slice(&(chunk.len() as u32).to_le_bytes());
        record[24..32].copy_from_slice(&(total as u64).to_le_bytes());
        record.extend_from_slice(chunk);
        record
    }
    fn write(path: &Path, pages: &[SlottedPage]) {
        let mut bytes = Vec::new();
        for page in pages {
            bytes.extend_from_slice(&page.to_bytes());
        }
        fs::write(path, bytes).unwrap();
    }
    fn wide_row() -> Row {
        row(1, 12_000)
    }
    /// Page 0: wide-row envelope (slot 0) + inline row 2 (slot 1);
    /// pages 1-2: the wide row's two-chunk overflow chain. With
    /// `damage`, page 2 (short last chunk) also holds an ordinary tuple in
    /// slot 1 — exactly the 0.2-I post-restart state.
    fn wide_heap(path: &Path, damage: bool) {
        let payload = RowCodec::encode(&schema(), &wide_row()).unwrap();
        assert_eq!(payload.len().div_ceil(CHUNK), 2);
        let reference = OverflowReference {
            first_page: 1,
            page_count: 2,
            total_length: payload.len() as u32,
            checksum: phobos_wal::page_checksum::scratch_checksum(&payload),
        };
        let mut page0 = SlottedPage::new_versioned(0);
        page0
            .insert(&tuple(1).encode_overflow(reference).unwrap())
            .unwrap();
        page0.insert(&inline(2, 40)).unwrap();
        let mut page1 = SlottedPage::new_overflow(1);
        page1
            .insert(&chunk_record(2, 0, &payload[..CHUNK], payload.len()))
            .unwrap();
        let mut page2 = SlottedPage::new_overflow(2);
        page2
            .insert(&chunk_record(
                NO_OVERFLOW_PAGE,
                1,
                &payload[CHUNK..],
                payload.len(),
            ))
            .unwrap();
        if damage {
            // What 0.2-I's unchecked `insert` did on a probed overflow page.
            page2.insert(&inline(3, 40)).unwrap();
        }
        write(path, &[page0, page1, page2]);
    }
    fn get(path: &Path, rid: RecordId) -> Row {
        let mut heap = HeapTable::open_versioned(path, schema(), 8).unwrap();
        heap.get_version(rid).unwrap().unwrap().1
    }

    #[test]
    fn ordinary_insert_refuses_overflow_pages() {
        let mut page = SlottedPage::new_overflow(7);
        assert!(page.free_space() > 1000);
        assert_eq!(page.ordinary_free_space(), 0);
        let error = page.insert_ordinary(&inline(1, 40)).unwrap_err();
        assert_eq!(error.code, ErrorCode::InvalidPage);
        assert_eq!(page.slot_count(), 0);
        let ordinary = SlottedPage::new_versioned(8);
        assert_eq!(ordinary.ordinary_free_space(), ordinary.free_space());
    }

    #[test]
    fn post_reopen_insert_never_selects_an_unknown_overflow_page() {
        let dir = root("probe");
        let path = dir.join("table.heap");
        let record = inline(10, 1600);
        let full = |id: PageId, first: i64| {
            let mut page = SlottedPage::new_versioned(id);
            let mut n = first;
            while page.free_space() >= record.len() + SLOT_SIZE {
                page.insert(&inline(n, 1600)).unwrap();
                n += 1;
            }
            page
        };
        // Page 1: released overflow chunk — almost the whole page is free.
        let mut released = SlottedPage::new_overflow(1);
        released
            .insert(&chunk_record(NO_OVERFLOW_PAGE, 0, &[7; 100], 100))
            .unwrap();
        released.delete(0).unwrap();
        released.compact().unwrap();
        assert!(released.free_space() > record.len() + SLOT_SIZE);
        write(&path, &[full(0, 100), released, full(2, 200)]);
        // Reopen: pages 0 and 2 are probed at open, page 1 is "unknown".
        let mut heap = HeapTable::open_versioned(&path, schema(), 8).unwrap();
        heap.begin_private(&dir.join("txn.private"), 1, &dir)
            .unwrap();
        let rid = heap.insert_version(tuple(10), &row(10, 1600)).unwrap();
        assert_ne!(rid.page_id, 1, "ordinary tuple placed on overflow page");
        assert_eq!(heap.pool.read_page(1).unwrap().slot_count(), 1);
        assert_eq!(heap.get_version(rid).unwrap().unwrap().1, row(10, 1600));
        heap.rollback_private().unwrap();
        drop(heap);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn healthy_overflow_chain_has_no_violations() {
        let dir = root("healthy");
        let path = dir.join("table.heap");
        wide_heap(&path, false);
        assert!(scan_overflow_violations(&path).unwrap().is_empty());
        let repair = plan_overflow_repair(&path).unwrap();
        assert!(repair.actions.is_empty());
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 0,
                    slot_id: 0
                }
            ),
            wide_row()
        );
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn damaged_live_chunk_is_detected_and_repaired_without_moving_tuples() {
        let dir = root("live");
        let path = dir.join("table.heap");
        wide_heap(&path, true);
        let violations = scan_overflow_violations(&path).unwrap();
        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].page_id, 2);
        assert_eq!(violations[0].slot_count, 2);
        assert_eq!(violations[0].chunk, ChunkState::Live { ordinal: 1 });
        assert_eq!(violations[0].ordinary_slots, vec![1]);
        // The damaged representation is what 0.2-I readers reject.
        let mut heap = HeapTable::open_versioned(&path, schema(), 8).unwrap();
        assert_eq!(
            heap.get_version(RecordId {
                page_id: 0,
                slot_id: 0
            })
            .unwrap_err()
            .message,
            "overflow page kind is invalid"
        );
        drop(heap);
        let repair = plan_overflow_repair(&path).unwrap();
        assert_eq!(
            repair.actions,
            vec![
                RepairAction::RelocateChunk {
                    from: 2,
                    to: 3,
                    ordinal: 1,
                    reference: ChunkReference::PreviousChunk { page: 1 },
                },
                RepairAction::ConvertToOrdinary {
                    page: 2,
                    dropped_chunk_slot: true,
                    ordinary_slots: vec![1],
                },
            ]
        );
        write_repaired_heap(&path, &repair).unwrap();
        assert!(scan_overflow_violations(&path).unwrap().is_empty());
        // Wide row readable through the redirected chain; every ordinary
        // tuple still at its original RecordId.
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 0,
                    slot_id: 0
                }
            ),
            wide_row()
        );
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 0,
                    slot_id: 1
                }
            ),
            row(2, 40)
        );
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 2,
                    slot_id: 1
                }
            ),
            row(3, 40)
        );
        // Idempotent: a second plan finds nothing.
        assert!(plan_overflow_repair(&path).unwrap().actions.is_empty());
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn first_chunk_reference_in_envelope_is_redirected() {
        // Damage on a FIRST chunk page (reachable only synthetically: a first
        // chunk is full unless the row has a single chunk) exercises the
        // envelope `first_page` redirect.
        let dir = root("first");
        let path = dir.join("table.heap");
        let payload = RowCodec::encode(&schema(), &row(1, 5000)).unwrap();
        let reference = OverflowReference {
            first_page: 1,
            page_count: 1,
            total_length: payload.len() as u32,
            checksum: phobos_wal::page_checksum::scratch_checksum(&payload),
        };
        let mut page0 = SlottedPage::new_versioned(0);
        page0
            .insert(&tuple(1).encode_overflow(reference).unwrap())
            .unwrap();
        let mut page1 = SlottedPage::new_overflow(1);
        page1
            .insert(&chunk_record(NO_OVERFLOW_PAGE, 0, &payload, payload.len()))
            .unwrap();
        page1.insert(&inline(4, 40)).unwrap();
        write(&path, &[page0, page1]);
        let repair = plan_overflow_repair(&path).unwrap();
        assert_eq!(
            repair.actions[0],
            RepairAction::RelocateChunk {
                from: 1,
                to: 2,
                ordinal: 0,
                reference: ChunkReference::Envelope { page: 0, slot: 0 },
            }
        );
        write_repaired_heap(&path, &repair).unwrap();
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 0,
                    slot_id: 0
                }
            ),
            row(1, 5000)
        );
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 1,
                    slot_id: 1
                }
            ),
            row(4, 40)
        );
        assert!(scan_overflow_violations(&path).unwrap().is_empty());
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn released_chunk_page_is_converted_in_place() {
        let dir = root("released");
        let path = dir.join("table.heap");
        let mut page0 = SlottedPage::new_versioned(0);
        page0.insert(&inline(2, 40)).unwrap();
        let mut page1 = SlottedPage::new_overflow(1);
        page1
            .insert(&chunk_record(NO_OVERFLOW_PAGE, 0, &[9; 64], 64))
            .unwrap();
        page1.delete(0).unwrap();
        page1.compact().unwrap();
        page1.insert(&inline(5, 40)).unwrap();
        page1.insert(&inline(6, 40)).unwrap();
        write(&path, &[page0, page1]);
        let violations = scan_overflow_violations(&path).unwrap();
        assert_eq!(violations[0].chunk, ChunkState::Released);
        assert_eq!(violations[0].ordinary_slots, vec![1, 2]);
        let repair = plan_overflow_repair(&path).unwrap();
        assert_eq!(repair.final_pages(), 2);
        write_repaired_heap(&path, &repair).unwrap();
        assert!(scan_overflow_violations(&path).unwrap().is_empty());
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 1,
                    slot_id: 1
                }
            ),
            row(5, 40)
        );
        assert_eq!(
            get(
                &path,
                RecordId {
                    page_id: 1,
                    slot_id: 2
                }
            ),
            row(6, 40)
        );
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn unexplained_damage_is_refused_without_changes() {
        let dir = root("refuse");
        let path = dir.join("table.heap");
        // A live chunk that no row references, plus a misplaced tuple.
        let mut page0 = SlottedPage::new_versioned(0);
        page0.insert(&inline(2, 40)).unwrap();
        let mut page1 = SlottedPage::new_overflow(1);
        page1
            .insert(&chunk_record(NO_OVERFLOW_PAGE, 0, &[9; 64], 64))
            .unwrap();
        page1.insert(&inline(5, 40)).unwrap();
        write(&path, &[page0, page1]);
        let before = fs::read(&path).unwrap();
        let error = plan_overflow_repair(&path).err().unwrap();
        assert!(
            error.message.contains("not referenced"),
            "{}",
            error.message
        );
        assert_eq!(fs::read(&path).unwrap(), before);
        fs::remove_dir_all(dir).unwrap();
    }
}
