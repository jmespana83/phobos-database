//! Explicit versioned-heap API. Legacy row methods cannot bypass visibility.
use super::*;
use phobos_txn::mvcc::{Hints, Snapshot, StatusLookup};
use std::{
    collections::HashMap,
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering},
    },
};
use tuple_version::{Envelope, OverflowReference, TupleVersion};

const OVERFLOW_RECORD_HEADER: usize = 32;
const OVERFLOW_CHUNK_BYTES: usize = PAGE_SIZE - HEADER_SIZE - SLOT_SIZE - OVERFLOW_RECORD_HEADER;
const NO_OVERFLOW_PAGE: u64 = u64::MAX;

/// C1/C2: one page's physical versions as `(slot, version, row)`.
pub type PageVersions = Vec<(SlotId, TupleVersion, Row)>;
/// C2: a page to rewrite: `(page, dead slots with expected versions, keep
/// the candidate flag)`.
pub type ReclaimPage = (PageId, Vec<(SlotId, TupleVersion)>, bool);

/// 0.2-K: one page of a storage-lifecycle rewrite (see
/// `HeapTable::reclaim_lifecycle`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LifecyclePage {
    pub page: PageId,
    /// LIVE -> RETIRED: globally dead slots with their expected versions.
    pub dead: Vec<(SlotId, TupleVersion)>,
    /// RETIRED -> FREE: slots observed RETIRED and proved past the horizon.
    pub free: Vec<SlotId>,
    /// The page still holds versions a live snapshot may need.
    pub keep_candidate: bool,
}

/// K.5: a checked slot/header patch prepared on a committed statement image.
/// It is usable only against the identical LSN/checksum base. Fields are private
/// so callers cannot manufacture a patch or change its lifecycle expectations.
pub struct PreparedLifecycle {
    plan: LifecyclePage,
    base_lsn: u64,
    base_checksum: [u8; 4],
    patches: Vec<(usize, Vec<u8>)>,
    free_bytes: usize,
    outcome: PageLifecycleOutcome,
}

/// 0.2-K diagnostics: one page's census and version headers.
#[derive(Debug, Clone)]
pub struct PageHeaders {
    pub flags: u8,
    pub overflow: bool,
    pub census: SlotCensus,
    /// `upper - lower` (raw, also on overflow pages).
    pub free_bytes: usize,
    /// Bytes held by occupied slots.
    pub live_bytes: usize,
    pub versions: Vec<TupleVersion>,
}

/// 0.2-K: lifecycle view of one heap page (`HeapTable::page_lifecycle`).
#[derive(Debug, Clone)]
pub struct PageLifecycleView {
    pub flags: u8,
    pub overflow: bool,
    pub census: SlotCensus,
    pub versions: PageVersions,
    pub retired: Vec<SlotId>,
    pub free_bytes: usize,
}

/// 0.1.9-B1: process-wide switch for settled-visibility hints
/// (`hint_bits_enabled`, default true). Off means ordinary status resolution
/// for every tuple; the hint cache is neither read nor written.
static HINT_BITS_ENABLED: AtomicBool = AtomicBool::new(true);
pub fn set_hint_bits_enabled(enabled: bool) {
    HINT_BITS_ENABLED.store(enabled, Ordering::Relaxed);
}
#[must_use]
pub fn hint_bits_enabled() -> bool {
    HINT_BITS_ENABLED.load(Ordering::Relaxed)
}

const HINT_SHARDS: usize = 16;
/// Pages retained per shard before the shard is cleared. 0.2-B: raised from
/// 512 (a hard 8,192-page / ~64 MiB-heap ceiling per table, beyond which every
/// scan cleared shards continuously and resolved every tuple's status through
/// the shared status cache) to 8,192 per shard: up to 131,072 pages (~1 GiB
/// of heap) per table at roughly 70 bytes per page, i.e. <= ~9 MiB.
const HINT_PAGES_PER_SHARD: usize = 8192;

/// 0.1.9-B1 cache-resident settled-visibility hints for one heap: two bits
/// per slot, per page, sharded by page. Shared by every statement reader of
/// the heap through `HeapReadHandle`. A slot's tuple identity never changes
/// once published (creator fixed, deleter set at most once, no slot reuse or
/// compaction), so a settled hint stays true for the slot; pages republished
/// by a commit are still dropped defensively. Not persisted: restart or
/// eviction costs status lookups only.
pub struct HintCache {
    shards: Vec<Mutex<HashMap<u64, Vec<u8>>>>,
}
impl Default for HintCache {
    fn default() -> Self {
        Self::new()
    }
}
impl HintCache {
    #[must_use]
    pub fn new() -> Self {
        Self {
            shards: (0..HINT_SHARDS)
                .map(|_| Mutex::new(HashMap::new()))
                .collect(),
        }
    }
    fn shard(&self, page: u64) -> &Mutex<HashMap<u64, Vec<u8>>> {
        &self.shards[(page % HINT_SHARDS as u64) as usize]
    }
    /// Flag bitmap of `page` (two bits per slot), empty when unknown.
    #[must_use]
    pub fn page(&self, page: u64) -> Vec<u8> {
        self.shard(page)
            .lock()
            .ok()
            .and_then(|shard| shard.get(&page).cloned())
            .unwrap_or_default()
    }
    /// ORs `bits` into the page's bitmap (hints only ever accumulate).
    pub fn merge(&self, page: u64, bits: &[u8]) {
        if bits.iter().all(|byte| *byte == 0) {
            return;
        }
        let Ok(mut shard) = self.shard(page).lock() else {
            return;
        };
        if !shard.contains_key(&page) && shard.len() >= HINT_PAGES_PER_SHARD {
            shard.clear();
        }
        let entry = shard.entry(page).or_default();
        if entry.len() < bits.len() {
            entry.resize(bits.len(), 0);
        }
        for (target, source) in entry.iter_mut().zip(bits) {
            *target |= source;
        }
    }
    pub fn invalidate(&self, page: u64) {
        if let Ok(mut shard) = self.shard(page).lock() {
            shard.remove(&page);
        }
    }
    /// 0.2-K: forget the settled bits of one slot because it receives a new
    /// occupant (FREE-slot reuse, or re-extension of a trimmed or reset
    /// directory). Bits only accumulate (`merge` ORs), so without this a
    /// settled `DELETER_COMMITTED`/`CREATOR_COMMITTED` of the previous
    /// occupant would apply to the new tuple. No reader can still be learning
    /// bits of the previous occupant at this point: it was RETIRED in a
    /// publication the reclamation horizon has since passed (every reader that
    /// could have seen it has finished), so nothing re-adds them afterwards.
    /// Poisoned shards drop the whole page, which is equally safe.
    pub fn forget_slot(&self, page: u64, slot: u16) {
        match self.shard(page).lock() {
            Ok(mut shard) => {
                if let Some(bits) = shard.get_mut(&page) {
                    let index = usize::from(slot);
                    if let Some(byte) = bits.get_mut(index / 4) {
                        *byte &= !(Hints::MASK << ((index % 4) * 2));
                    }
                }
            }
            Err(poisoned) => {
                poisoned.into_inner().remove(&page);
            }
        }
    }
    pub fn clear(&self) {
        for shard in &self.shards {
            if let Ok(mut shard) = shard.lock() {
                shard.clear();
            }
        }
    }
    /// Hints recorded for `(page, slot)`.
    #[must_use]
    pub fn get(&self, page: u64, slot: u16) -> Hints {
        // 0.2-B: read the slot's bits in place (no per-lookup bitmap clone).
        self.shard(page)
            .lock()
            .ok()
            .and_then(|shard| shard.get(&page).map(|bits| slot_hints(bits, slot)))
            .unwrap_or_else(|| slot_hints(&[], slot))
    }
    /// Pages currently holding hints (tests/diagnostics).
    #[must_use]
    pub fn hinted_pages(&self) -> usize {
        self.shards
            .iter()
            .map(|shard| shard.lock().map_or(0, |shard| shard.len()))
            .sum()
    }
}
fn slot_hints(bits: &[u8], slot: u16) -> Hints {
    let index = usize::from(slot);
    bits.get(index / 4).map_or_else(Default::default, |byte| {
        Hints::from_bits((byte >> ((index % 4) * 2)) & Hints::MASK)
    })
}
fn set_slot_hints(bits: &mut Vec<u8>, slot: u16, hints: Hints) {
    let index = usize::from(slot);
    if bits.len() <= index / 4 {
        bits.resize(index / 4 + 1, 0);
    }
    bits[index / 4] |= hints.bits() << ((index % 4) * 2);
}

/// Immutable own-write image for one statement. Synthetic RIDs never enter heap
/// pages or WAL; commit preparation resolves them against current physical pages.
///
/// 0.1.9-A4: `hidden` and `rows` hold the in-memory part of the transaction's
/// pending writes; `spilled`, when present, answers for writes the session has
/// spilled to scratch files with bounded I/O instead of resident entries. The
/// in-memory part shadows the spilled part.
#[derive(Clone, Default)]
pub struct StatementOverlay {
    pub hidden: std::collections::BTreeSet<RecordId>,
    pub rows: BTreeMap<RecordId, Row>,
    pub spilled: Option<std::sync::Arc<dyn OverlaySource>>,
}

/// Bounded-memory source of spilled own writes for one table (0.1.9-A4).
pub trait OverlaySource: Send + Sync {
    /// Whether the committed row `rid` is replaced or deleted by a spilled write.
    fn hidden(&self, rid: RecordId) -> Result<bool, PhobosError>;
    /// The spilled own row `rid`, unless the in-memory part shadows it.
    fn row(&self, rid: RecordId) -> Result<Option<Row>, PhobosError>;
    /// Every spilled own row not shadowed by the in-memory part, streamed.
    fn visit(
        &self,
        visitor: &mut dyn FnMut(RecordId, Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError>;
}

impl StatementOverlay {
    pub fn is_hidden(&self, rid: RecordId) -> Result<bool, PhobosError> {
        if self.hidden.contains(&rid) {
            return Ok(true);
        }
        match &self.spilled {
            Some(spilled) => spilled.hidden(rid),
            None => Ok(false),
        }
    }
    pub fn row(&self, rid: RecordId) -> Result<Option<Row>, PhobosError> {
        if let Some(row) = self.rows.get(&rid) {
            return Ok(Some(row.clone()));
        }
        match &self.spilled {
            Some(spilled) => spilled.row(rid),
            None => Ok(None),
        }
    }
    /// Visits the in-memory rows, then the spilled rows; stops when the
    /// visitor returns `false`.
    pub fn visit(
        &self,
        mut visitor: impl FnMut(RecordId, Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        for (rid, row) in &self.rows {
            cancellation_poll.checkpoint_at("versioned_heap.visit_overlay")?;
            if !visitor(*rid, row.clone())? {
                return Ok(());
            }
        }
        match &self.spilled {
            Some(spilled) => spilled.visit(&mut visitor),
            None => Ok(()),
        }
    }
}

/// Immutable committed-page routing metadata. Cloning never opens files or
/// retains the mutable heap owner; statement caches are created independently.
#[derive(Clone)]
pub struct HeapReadHandle {
    pages: committed_pages::CommittedReader,
    path: PathBuf,
    schema: TableSchema,
    capacity: usize,
    hints: Arc<HintCache>,
    /// 0.2-C: canonical database directory, resolved once per handle
    /// (statement readers previously paid a realpath per statement).
    directory: Arc<std::sync::OnceLock<PathBuf>>,
    /// 0.2-F: one opened handle of the heap file per read handle; a reader
    /// `PageIo` never reads through its base file, so statements share it
    /// via `try_clone` instead of opening the path for every statement.
    base: Arc<std::sync::OnceLock<Arc<std::fs::File>>>,
}
impl HeapReadHandle {
    pub fn statement_reader(
        &self,
        statement: std::sync::Arc<phobos_txn::mvcc::sessions::Statement>,
    ) -> Result<HeapTable, PhobosError> {
        let directory = match self.directory.get() {
            Some(directory) => directory,
            None => {
                let _canonicalize = phobos_observability::span("view.canonicalize");
                let resolved = std::fs::canonicalize(self.path.parent().ok_or_else(|| {
                    PhobosError::new(ErrorCode::InvalidPage, "heap has no database directory")
                })?)?;
                self.directory.get_or_init(|| resolved)
            }
        };
        statement.check_database(directory)?;
        // 0.2-G: readers share the handle (`Arc`); no descriptor dup/close
        // per statement.
        let base = match self.base.get() {
            Some(file) => {
                phobos_observability::event("view.file_reuse", 1);
                file.clone()
            }
            None => {
                phobos_observability::event("view.file_open", 1);
                let file = Arc::new(std::fs::OpenOptions::new().read(true).open(&self.path)?);
                let _ = self.base.set(file.clone());
                file
            }
        };
        Ok(HeapTable {
            overlay: None,
            schema: self.schema.clone(),
            path: self.path.clone(),
            pool: BufferPool {
                expected_versioned: Some(true),
                file: PageFile {
                    file: page_io::PageIo::new_reader_shared(base, self.pages.clone())?,
                },
                capacity: self.capacity,
                clock: 0,
                frames: BTreeMap::new(),
            },
            free_space: Vec::new(),
            free_space_map: super::FreeSpaceMap::default(),
            flush_each_insert: false,
            versioned: true,
            statement: Some(statement),
            private_original: None,
            hints: self.hints.clone(),
        })
    }
    /// The heap's shared hint cache (tests/diagnostics).
    #[must_use]
    pub fn hints(&self) -> &Arc<HintCache> {
        &self.hints
    }
}

impl HeapTable {
    /// D3: a statement reader keeps a small frame cache; dropping it makes
    /// the next page access observe pages published since the reader was
    /// built (the committed store itself is always current). Admission
    /// reuses one reader across a whole statement and refreshes it after
    /// each ownership acquisition instead of rebuilding every reader.
    pub fn refresh_committed_view(&mut self) -> Result<(), PhobosError> {
        if self.statement.is_none() || self.private_original.is_some() {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "only statement readers refresh their committed view",
            ));
        }
        self.pool.frames.clear();
        Ok(())
    }

    /// Fill private heap pages sequentially, updating the free-space entry once
    /// per filled page. Input is one bounded, pre-encoded tuple batch.
    pub fn insert_version_batch(
        &mut self,
        encoded: &[Vec<u8>],
    ) -> Result<Vec<RecordId>, PhobosError> {
        self.require_versioned()?;
        let owner = self.pool.file.file.private_owner()?;
        if encoded.len() > 1024 || encoded.iter().map(Vec::len).sum::<usize>() > 1024 * 1024 {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "bulk heap batch limit",
            ));
        }
        let mut result = Vec::with_capacity(encoded.len());
        let mut next = 0;
        while next < encoded.len() {
            if encoded[next].len() + SLOT_SIZE > PAGE_SIZE - HEADER_SIZE {
                let (tuple, row) = TupleVersion::decode(&self.schema, &encoded[next])?;
                if tuple.visibility.creator != owner
                    || tuple.visibility.deleter.is_some()
                    || tuple.previous.is_some()
                {
                    return Err(stale_version());
                }
                result.push(self.insert_version(tuple, &row)?);
                next += 1;
                continue;
            }
            let _cost = phobos_observability::span("bulk.heap_allocate_fill");
            let count = self.pool.page_count()?;
            // 0.2-K Part E: bulk/COPY allocates exactly like single-row
            // inserts: a page with known room (reclaimed bytes, FREE slots,
            // or the tail) is filled through the same primitive before a page
            // is appended. 0.2-I.1: only ordinary pages qualify
            // (`ordinary_free_space` is 0 on overflow pages), so an overflow
            // page is never filled.
            let needed = encoded[next].len() + SLOT_SIZE;
            let mut chosen = None;
            while let Some(id) = self.free_space_map.take_known(needed) {
                let page = self.pool.read_page(id)?;
                let actual = page.ordinary_free_space();
                let old = self.free_space[id as usize];
                self.free_space[id as usize] = actual;
                self.free_space_map.update(id, old, actual);
                if actual >= needed {
                    chosen = Some((page, id));
                    break;
                }
            }
            let (mut page, id) = match chosen {
                Some((page, id)) => (page, id),
                None => (SlottedPage::new_versioned(count), count),
            };
            let start = next;
            // The page is a local, exclusively owned copy while it is filled:
            // insert without per-tuple checksum refreshes and seal it exactly
            // once before it enters the buffer pool / private overlay below.
            // Every error path drops the unsealed page without exposing it.
            while next < encoded.len()
                && page.ordinary_free_space() >= encoded[next].len() + SLOT_SIZE
            {
                let (tuple, _) = TupleVersion::decode(&self.schema, &encoded[next])?;
                if tuple.visibility.creator != owner
                    || tuple.visibility.deleter.is_some()
                    || tuple.previous.is_some()
                {
                    return Err(stale_version());
                }
                let slot_id = page.insert_ordinary_unsealed(&encoded[next])?;
                // 0.2-K: the slot may have had an earlier occupant.
                self.hints.forget_slot(id, slot_id);
                result.push(RecordId {
                    page_id: id,
                    slot_id,
                });
                next += 1;
            }
            if next == start {
                return Err(PhobosError::new(
                    ErrorCode::ConstraintViolation,
                    "bulk row exceeds page",
                ));
            }
            page.seal();
            let free = page.free_space();
            if id == count {
                self.pool.append(page)?;
                self.free_space.push(free);
                self.free_space_map.push(id, free);
            } else {
                self.pool.put_dirty(page)?;
                let old = self.free_space[id as usize];
                self.free_space[id as usize] = free;
                self.free_space_map.update(id, old, free);
            }
            phobos_observability::event("bulk.heap_page_updates", 1);
        }
        Ok(result)
    }
    /// Read an empty, session-created table before its first committed version.
    /// All rows are supplied by the immutable own-write overlay, never this file.
    pub fn empty_statement_reader(
        path: &std::path::Path,
        schema: TableSchema,
        statement: std::sync::Arc<phobos_txn::mvcc::sessions::Statement>,
    ) -> Result<Self, PhobosError> {
        let mut heap = Self::open_versioned(path, schema, 1)?;
        if heap.pool.page_count()? != 0 {
            return Err(stale_version());
        }
        heap.statement = Some(statement);
        Ok(heap)
    }
    pub fn set_statement_overlay(
        &mut self,
        overlay: std::sync::Arc<StatementOverlay>,
    ) -> Result<(), PhobosError> {
        if self.statement.is_none() {
            return Err(stale_version());
        }
        self.overlay = Some(overlay);
        Ok(())
    }
    pub fn has_visibility_context(&self) -> bool {
        self.statement.is_some()
    }
    pub fn overlay_ids(&self) -> Result<Vec<RecordId>, PhobosError> {
        let mut ids = Vec::new();
        self.visit_overlay(|rid, _| {
            ids.push(rid);
            Ok(true)
        })?;
        Ok(ids)
    }
    pub fn visit_overlay(
        &self,
        visitor: impl FnMut(RecordId, Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        match &self.overlay {
            Some(overlay) => overlay.visit(visitor),
            None => Ok(()),
        }
    }
    /// Independent committed read path for one statement. Shared statement
    /// ownership retains its snapshot through all heap scans and result delivery.
    /// No private/pending page, free-space map or long-lived execution guard is
    /// copied. Each statement starts with a fresh bounded page cache.
    pub fn statement_reader(
        &self,
        statement: std::sync::Arc<phobos_txn::mvcc::sessions::Statement>,
    ) -> Result<Self, PhobosError> {
        self.read_handle()?.statement_reader(statement)
    }
    pub fn read_handle(&self) -> Result<HeapReadHandle, PhobosError> {
        self.require_versioned()?;
        Ok(HeapReadHandle {
            pages: self.pool.file.file.committed_reader()?,
            path: self.path.clone(),
            schema: self.schema.clone(),
            capacity: self.pool.capacity,
            hints: self.hints.clone(),
            directory: Arc::default(),
            base: Arc::default(),
        })
    }
    /// The heap's shared hint cache (tests/diagnostics).
    #[must_use]
    pub fn hint_cache(&self) -> &Arc<HintCache> {
        &self.hints
    }
    pub(super) fn require_legacy(&self) -> Result<(), PhobosError> {
        if self.versioned {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "versioned heap requires a statement visibility context",
            ));
        }
        Ok(())
    }

    fn require_versioned(&self) -> Result<(), PhobosError> {
        if !self.versioned {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "legacy heap requires explicit offline migration",
            ));
        }
        Ok(())
    }

    pub fn insert_version(
        &mut self,
        tuple: TupleVersion,
        row: &Row,
    ) -> Result<RecordId, PhobosError> {
        self.require_versioned()?;
        if self.pool.file.file.is_private()
            && self.pool.file.file.private_owner()? != tuple.visibility.creator
        {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "tuple creator differs from private owner",
            ));
        }
        let encoded = tuple.encode(&self.schema, row)?;
        if encoded.len() + SLOT_SIZE <= PAGE_SIZE - HEADER_SIZE {
            return self.insert_encoded(encoded);
        }
        let payload = RowCodec::encode(&self.schema, row)?;
        let reference = self.write_overflow(&payload)?;
        self.insert_encoded(tuple.encode_overflow(reference)?)
    }

    fn physical_page(&mut self, page_id: PageId) -> Result<SlottedPage, PhobosError> {
        if self.pool.file.file.is_statement_reader() {
            let bytes = self
                .pool
                .file
                .file
                .read_statement_reference(page_id)?
                .ok_or_else(|| overflow_invalid("overflow page is truncated"))?;
            SlottedPage::from_bytes(bytes)
        } else {
            if page_id >= self.pool.page_count()? {
                return Err(overflow_invalid("overflow page is truncated"));
            }
            self.pool.read_page(page_id)
        }
    }

    fn decode_record(&mut self, bytes: &[u8]) -> Result<(TupleVersion, Row), PhobosError> {
        let Some((tuple, reference)) = TupleVersion::decode_overflow(bytes)? else {
            return TupleVersion::decode(&self.schema, bytes);
        };
        let payload = self.read_overflow(reference)?;
        Ok((tuple, RowCodec::decode(&self.schema, &payload)?))
    }

    fn read_overflow(&mut self, reference: OverflowReference) -> Result<Vec<u8>, PhobosError> {
        let expected_pages = usize::try_from(reference.page_count)
            .map_err(|_| overflow_invalid("overflow page count is invalid"))?;
        let total = usize::try_from(reference.total_length)
            .map_err(|_| overflow_invalid("overflow length is invalid"))?;
        let maximum = expected_pages
            .checked_mul(OVERFLOW_CHUNK_BYTES)
            .ok_or_else(|| overflow_invalid("overflow length overflow"))?;
        if total > maximum || total <= maximum.saturating_sub(OVERFLOW_CHUNK_BYTES) {
            return Err(overflow_invalid("overflow length/page count mismatch"));
        }
        let mut payload = Vec::with_capacity(total);
        let mut page_id = reference.first_page;
        let mut visited = std::collections::BTreeSet::new();
        for index in 0..expected_pages {
            if page_id == NO_OVERFLOW_PAGE || !visited.insert(page_id) {
                return Err(overflow_invalid("overflow chain cycle or truncation"));
            }
            let page = self.physical_page(page_id)?;
            if !page.is_overflow() || page.slot_count() != 1 {
                return Err(overflow_invalid("overflow page kind is invalid"));
            }
            let record = page
                .get(0)?
                .ok_or_else(|| overflow_invalid("overflow page is free"))?;
            if record.len() < OVERFLOW_RECORD_HEADER
                || &record[..4] != b"PHOV"
                || record[4..6] != [1, 0]
                || record[6..8] != [0, 0]
            {
                return Err(overflow_invalid("overflow record header is invalid"));
            }
            let next = u64::from_le_bytes(record[8..16].try_into().expect("next page"));
            let ordinal = u32::from_le_bytes(record[16..20].try_into().expect("ordinal"));
            let chunk = u32::from_le_bytes(record[20..24].try_into().expect("chunk")) as usize;
            let declared = u64::from_le_bytes(record[24..32].try_into().expect("total"));
            if ordinal as usize != index
                || declared != u64::from(reference.total_length)
                || chunk != record.len() - OVERFLOW_RECORD_HEADER
                || chunk == 0
                || chunk > OVERFLOW_CHUNK_BYTES
                || (index + 1 == expected_pages) != (next == NO_OVERFLOW_PAGE)
            {
                return Err(overflow_invalid("overflow record bounds are invalid"));
            }
            payload.extend_from_slice(&record[OVERFLOW_RECORD_HEADER..]);
            page_id = next;
        }
        if payload.len() != total
            || phobos_wal::page_checksum::scratch_checksum(&payload) != reference.checksum
        {
            return Err(overflow_invalid("overflow payload checksum mismatch"));
        }
        Ok(payload)
    }

    fn write_overflow(&mut self, payload: &[u8]) -> Result<OverflowReference, PhobosError> {
        self.pool.file.file.private_owner()?;
        let chunks = payload.len().div_ceil(OVERFLOW_CHUNK_BYTES);
        let page_count = u32::try_from(chunks)
            .map_err(|_| overflow_invalid("overflow page count exceeds format"))?;
        let total_length = u32::try_from(payload.len())
            .map_err(|_| overflow_invalid("overflow row exceeds 4 GiB"))?;
        let mut reusable = Vec::new();
        let count = self.pool.page_count()?;
        for id in 0..count {
            let page = self.pool.read_page(id)?;
            if page.is_overflow() && page.slot_count() == 1 && page.slot_is_empty(0) {
                reusable.push(id);
                if reusable.len() == chunks {
                    break;
                }
            }
        }
        while reusable.len() < chunks {
            reusable.push(
                count + (reusable.len() - reusable.iter().filter(|id| **id < count).count()) as u64,
            );
        }
        for (index, chunk) in payload.chunks(OVERFLOW_CHUNK_BYTES).enumerate() {
            let id = reusable[index];
            let next = reusable.get(index + 1).copied().unwrap_or(NO_OVERFLOW_PAGE);
            let mut record = vec![0; OVERFLOW_RECORD_HEADER];
            record[..4].copy_from_slice(b"PHOV");
            record[4..6].copy_from_slice(&1u16.to_le_bytes());
            record[8..16].copy_from_slice(&next.to_le_bytes());
            record[16..20].copy_from_slice(&(index as u32).to_le_bytes());
            record[20..24].copy_from_slice(&(chunk.len() as u32).to_le_bytes());
            record[24..32].copy_from_slice(&u64::from(total_length).to_le_bytes());
            record.extend_from_slice(chunk);
            let mut page = SlottedPage::new_overflow(id);
            page.insert(&record)?;
            if id < count {
                self.pool.put_dirty(page)?;
                let old = self.free_space[id as usize];
                self.free_space[id as usize] = 0;
                self.free_space_map.update(id, old, 0);
            } else {
                self.pool.append(page)?;
                self.free_space.push(0);
                self.free_space_map.push(id, 0);
            }
        }
        Ok(OverflowReference {
            first_page: reusable[0],
            page_count,
            total_length,
            checksum: phobos_wal::page_checksum::scratch_checksum(payload),
        })
    }

    fn release_overflow(&mut self, reference: OverflowReference) -> Result<usize, PhobosError> {
        // Validate the complete chain before mutating any page.
        self.read_overflow(reference)?;
        let mut page_id = reference.first_page;
        for _ in 0..reference.page_count {
            let mut page = self.pool.read_page(page_id)?;
            let record = page
                .get(0)?
                .ok_or_else(|| overflow_invalid("overflow page is free"))?;
            let next = u64::from_le_bytes(record[8..16].try_into().expect("next page"));
            page.delete(0)?;
            page.compact()?;
            self.pool.put_dirty(page)?;
            page_id = next;
        }
        Ok(reference.page_count as usize)
    }

    /// Preserve the old payload/RID and link a new physical version. The caller
    /// owns the logical row and has rechecked visibility under that ownership.
    /// Any error requires aborting the private transaction, as for legacy DML.
    pub fn update_version(
        &mut self,
        rid: RecordId,
        expected: TupleVersion,
        row: &Row,
    ) -> Result<RecordId, PhobosError> {
        let owner = self.pool.file.file.private_owner()?;
        self.check_version_head(rid, expected)?;
        let successor = TupleVersion {
            logical_row: expected.logical_row,
            visibility: phobos_txn::mvcc::Version {
                creator: owner,
                deleter: None,
            },
            previous: Some(rid),
        };
        let successor = self.insert_version(successor, row)?;
        self.delete_version(rid, expected)?;
        Ok(successor)
    }

    /// Logical deletion changes only the deleting identity. Physical tuple bytes
    /// and index references remain available to statements with older snapshots.
    pub fn delete_version(
        &mut self,
        rid: RecordId,
        expected: TupleVersion,
    ) -> Result<(), PhobosError> {
        let owner = self.pool.file.file.private_owner()?;
        self.check_version_head(rid, expected)?;
        let mut page = self.pool.read_page(rid.page_id)?;
        // Only fixed-size envelope metadata changes: no slot reuse/compaction
        // and an overflow reference continues to name the same immutable chain.
        let length = page.get(rid.slot_id)?.ok_or_else(stale_version)?.len();
        let offset = HEADER_SIZE + usize::from(rid.slot_id) * SLOT_SIZE;
        let start = usize::from(page.get_u16(offset));
        if length < 24 {
            return Err(stale_version());
        }
        page.bytes[start + 16..start + 24].copy_from_slice(&owner.to_le_bytes());
        // C1: the page now holds a version that may become reclaimable.
        page.set_flag(PAGE_FLAG_RECLAIM_CANDIDATE, true);
        page.refresh_checksum();
        self.pool.put_dirty(page)
    }

    /// C1/C2 page inspection: every version on `page` with its slot, plus the
    /// page's candidate flag. Statement readers see the current committed
    /// image; the private owner sees its private image.
    pub fn page_versions(
        &mut self,
        page_id: PageId,
    ) -> Result<Option<(u8, PageVersions)>, PhobosError> {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            let Some(bytes) = self.pool.file.file.read_statement_reference(page_id)? else {
                return Ok(None);
            };
            SlottedPage::from_bytes(bytes)?
        } else {
            if page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(page_id)?
        };
        if page.is_overflow() {
            return Ok(Some((page.flags(), Vec::new())));
        }
        let mut versions = Vec::new();
        for slot in 0..page.slot_count() {
            if let Some(bytes) = page.get(slot)? {
                let (tuple, row) = self.decode_record(bytes)?;
                versions.push((slot, tuple, row));
            }
        }
        Ok(Some((page.flags(), versions)))
    }

    /// Whether `rid` names a slot that holds no tuple on an ordinary heap
    /// page: RETIRED, FREE, or (0.2-K) past the end of a trimmed or reset slot
    /// directory. Index readers that copied an entry before a reclaim
    /// publication skip such references instead of reporting a missing tuple.
    /// A RecordId into an overflow page or past the end of the heap is not
    /// vacant (`false`): that is corruption, never a stale reference.
    pub fn slot_reclaimed(&mut self, rid: RecordId) -> Result<bool, PhobosError> {
        Ok(matches!(
            self.slot_state(rid)?,
            Some(SlotState::Retired | SlotState::Free | SlotState::Vacant)
        ))
    }

    /// 0.2-K: lifecycle state of the slot `rid` names, on the current
    /// committed image for statement readers. `None` when the page does not
    /// exist or is an overflow page.
    pub fn slot_state(&mut self, rid: RecordId) -> Result<Option<SlotState>, PhobosError> {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            let Some(bytes) = self.pool.file.file.read_statement_reference(rid.page_id)? else {
                return Ok(None);
            };
            SlottedPage::from_bytes(bytes)?
        } else {
            if rid.page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(rid.page_id)?
        };
        if page.is_overflow() {
            return Ok(None);
        }
        Ok(Some(page.slot_state(rid.slot_id)))
    }

    /// C2: physically remove globally dead versions from private page images.
    /// Each entry names a page, the `(slot, expected version)` pairs to drop
    /// and whether the page must stay a reclaim candidate (deferred versions
    /// remain). A slot whose version differs from the expectation aborts the
    /// maintenance transaction: nothing is dropped on a guess. Surviving slots
    /// keep their identifiers; freed bytes become insertable space.
    pub fn reclaim_versions(&mut self, pages: &[ReclaimPage]) -> Result<usize, PhobosError> {
        let pages = pages
            .iter()
            .map(|(page, dead, keep_candidate)| LifecyclePage {
                page: *page,
                dead: dead.clone(),
                free: Vec::new(),
                keep_candidate: *keep_candidate,
            })
            .collect::<Vec<_>>();
        Ok(self.reclaim_lifecycle(&pages)?.retired)
    }

    /// 0.2-K Storage Lifecycle V1: one private rewrite per page of
    /// * phase 1, LIVE -> RETIRED: `dead` slots whose version still equals the
    ///   expectation lose their tuple bytes (the exact index entries are
    ///   removed by the caller in the same private publication, C3);
    /// * phase 2, RETIRED -> FREE: `free` slots, which the caller observed
    ///   RETIRED in published state and proved past the reclamation horizon,
    ///   become reusable. A slot that is not RETIRED here aborts the pass
    ///   (nothing is freed on a guess; in particular a slot retired by this
    ///   very call can never be freed by it, because `free` is applied first);
    /// * Part F: trailing FREE entries are trimmed;
    /// * Part G: a page whose every slot is FREE becomes a fresh empty page.
    ///
    /// Overflow pages are never planned here and are refused. The page keeps
    /// `PAGE_FLAG_RECLAIM_CANDIDATE` while it still holds deferred versions
    /// or RETIRED slots, so a post-restart header scan rediscovers them.
    pub fn reclaim_lifecycle(
        &mut self,
        pages: &[LifecyclePage],
    ) -> Result<PageLifecycleOutcome, PhobosError> {
        self.require_versioned()?;
        self.pool.file.file.private_owner()?;
        let mut total = PageLifecycleOutcome::default();
        for plan in pages {
            phobos_observability::event("reclaim.heap_pages_touched", 1);
            phobos_observability::event("reclaim.retire_edits", plan.dead.len() as u64);
            phobos_observability::event("reclaim.free_edits", plan.free.len() as u64);
            let page_id = plan.page;
            let mut page = self.pool.read_page(page_id)?;
            let before = phobos_observability::profiling_enabled().then(|| page.clone());
            if page.is_overflow() {
                return Err(overflow_invalid(
                    "storage lifecycle never rewrites an overflow page",
                ));
            }
            for slot in &plan.free {
                page.free_retired_slot(*slot).map_err(|_| stale_version())?;
                total.freed += 1;
            }
            let mut overflow = Vec::new();
            for (slot, expected) in &plan.dead {
                let bytes = page.get(*slot)?.ok_or_else(stale_version)?;
                let actual = TupleVersion::decode_header(bytes)?;
                if actual != *expected {
                    return Err(stale_version());
                }
                if let Some((_, reference)) = TupleVersion::decode_overflow(bytes)? {
                    overflow.push(reference);
                }
                page.retire_slot(*slot).map_err(|_| stale_version())?;
                total.retired += 1;
            }
            // 0.2-K.3: no compaction here (deferred until an insertion
            // needs the space, see `SlottedPage::insert_unsealed`): retire
            // and free change only slot-directory entries, so the page delta
            // stays a few bytes instead of every moved tuple.
            phobos_observability::event("heap.compaction_deferred", 1);
            let trimmed = page.trim_trailing_free();
            total.trimmed += trimmed;
            let reset = page.all_slots_free();
            if reset {
                // Part G: equivalent to a freshly allocated versioned page
                // (header, bounds, flags and zeroed body); the page LSN is
                // stamped by WAL redo preparation like any other image.
                page = SlottedPage::new_versioned(page_id);
                total.reset += 1;
                phobos_observability::event("heap.page_reset", 1);
            } else {
                let census = page.slot_census();
                page.set_flag(
                    PAGE_FLAG_RECLAIM_CANDIDATE,
                    plan.keep_candidate || census.retired > 0,
                );
                page.set_flag(PAGE_FLAG_FREE_SLOTS, census.free > 0);
            }
            page.refresh_checksum();
            phobos_observability::event("reclaim.prepare_checksums", 1);
            if let Some(before) = before {
                phobos_observability::event(
                    "reclaim.heap_pages_changed",
                    u64::from(page.bytes != before.bytes),
                );
                let directory_end = HEADER_SIZE + before.slot_count() as usize * SLOT_SIZE;
                phobos_observability::event(
                    "reclaim.slot_directory_bytes_changed",
                    before.bytes[HEADER_SIZE..directory_end]
                        .iter()
                        .zip(&page.bytes[HEADER_SIZE..directory_end])
                        .filter(|(a, b)| a != b)
                        .count() as u64,
                );
            }
            phobos_observability::event("reclaim.private_image_bytes", PAGE_SIZE as u64);
            if reset || trimmed > 0 {
                // Slot numbers past the new directory end will be handed out
                // again; their bits are cleared on allocation as well.
                self.hints.invalidate(page_id);
            }
            // 0.2-I.1: never publish ordinary space for an overflow page.
            let free = page.ordinary_free_space();
            self.pool.put_dirty(page)?;
            if let Some(entry) = self.free_space.get_mut(page_id as usize) {
                let old = *entry;
                *entry = free;
                self.free_space_map.update(page_id, old, free);
            }
            for reference in overflow {
                self.release_overflow(reference)?;
            }
        }
        if total.freed > 0 {
            phobos_observability::event("heap.slots_freed", total.freed as u64);
        }
        if total.trimmed > 0 {
            phobos_observability::event("heap.slots_trimmed", total.trimmed as u64);
        }
        Ok(total)
    }

    /// Prepare ordinary slot-only changes outside commit order. Overflow release
    /// and page resets retain the existing general path. No shared image changes.
    pub fn prepare_lifecycle_delta(
        &mut self,
        plan: &LifecyclePage,
    ) -> Result<Option<PreparedLifecycle>, PhobosError> {
        self.require_versioned()?;
        let before = self.physical_page(plan.page)?;
        if before.is_overflow() {
            return Ok(None);
        }
        let mut page = before.clone();
        for slot in &plan.free {
            page.free_retired_slot(*slot).map_err(|_| stale_version())?;
        }
        for (slot, expected) in &plan.dead {
            let bytes = page.get(*slot)?.ok_or_else(stale_version)?;
            if TupleVersion::decode_header(bytes)? != *expected {
                return Err(stale_version());
            }
            if TupleVersion::decode_overflow(bytes)?.is_some() {
                return Ok(None);
            }
            page.retire_slot(*slot)?;
        }
        let trimmed = page.trim_trailing_free();
        if page.all_slots_free() {
            return Ok(None);
        }
        let census = page.slot_census();
        page.set_flag(
            PAGE_FLAG_RECLAIM_CANDIDATE,
            plan.keep_candidate || census.retired > 0,
        );
        page.set_flag(PAGE_FLAG_FREE_SLOTS, census.free > 0);
        page.refresh_checksum();
        let mut patches = Vec::new();
        let end = HEADER_SIZE + before.slot_count() as usize * SLOT_SIZE;
        let mut at = 0;
        while at < end {
            if before.bytes[at] == page.bytes[at] {
                at += 1;
                continue;
            }
            let start = at;
            while at < end && before.bytes[at] != page.bytes[at] {
                at += 1;
            }
            patches.push((start, page.bytes[start..at].to_vec()));
        }
        Ok(Some(PreparedLifecycle {
            plan: plan.clone(),
            base_lsn: before.page_lsn(),
            base_checksum: before.bytes[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4]
                .try_into()
                .expect("checksum"),
            patches,
            free_bytes: page.ordinary_free_space(),
            outcome: PageLifecycleOutcome {
                retired: plan.dead.len(),
                freed: plan.free.len(),
                trimmed,
                reset: 0,
            },
        }))
    }

    /// Validate the base before applying a prepared patch. A foreground writer
    /// changing any byte forces normal per-slot revalidation on its latest image.
    pub fn reclaim_lifecycle_prepared(
        &mut self,
        plans: &[LifecyclePage],
        prepared: &BTreeMap<PageId, PreparedLifecycle>,
    ) -> Result<PageLifecycleOutcome, PhobosError> {
        self.require_versioned()?;
        self.pool.file.file.private_owner()?;
        self.pool.flush_frames()?;
        let mut total = PageLifecycleOutcome::default();
        for plan in plans {
            let mut applied = None;
            if let Some(delta) = prepared.get(&plan.page).filter(|delta| delta.plan == *plan) {
                let (base, _) = self.pool.file.file.read_trusted(plan.page)?;
                let mut page = SlottedPage::from_bytes(*base)?;
                if page.page_lsn() == delta.base_lsn
                    && page.bytes[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4] == delta.base_checksum
                {
                    for (at, bytes) in &delta.patches {
                        page.bytes[*at..*at + bytes.len()].copy_from_slice(bytes);
                    }
                    // The checksum was computed on exactly this base, off pipeline.
                    if !self.pool.file.file.write_lifecycle_patch(
                        plan.page,
                        base,
                        delta.patches.clone(),
                    )? {
                        self.pool.put_dirty(page)?;
                    } else {
                        // A cached pre-patch frame must not mask this overlay.
                        self.pool.frames.remove(&plan.page);
                    }
                    let old = self.free_space[plan.page as usize];
                    self.free_space[plan.page as usize] = delta.free_bytes;
                    self.free_space_map.update(plan.page, old, delta.free_bytes);
                    if delta.outcome.trimmed > 0 {
                        self.hints.invalidate(plan.page);
                    }
                    phobos_observability::event("reclaim.prepared_applied", 1);
                    phobos_observability::event("reclaim.heap_pages_touched", 1);
                    phobos_observability::event("reclaim.heap_pages_changed", 1);
                    phobos_observability::event(
                        "reclaim.retire_edits",
                        delta.outcome.retired as u64,
                    );
                    phobos_observability::event("reclaim.free_edits", delta.outcome.freed as u64);
                    phobos_observability::event("heap.slots_freed", delta.outcome.freed as u64);
                    phobos_observability::event("heap.slots_trimmed", delta.outcome.trimmed as u64);
                    phobos_observability::event("heap.compaction_deferred", 1);
                    phobos_observability::event(
                        "reclaim.slot_directory_bytes_changed",
                        delta
                            .patches
                            .iter()
                            .map(|(at, b)| {
                                (*at + b.len()).saturating_sub((*at).max(HEADER_SIZE)) as u64
                            })
                            .sum(),
                    );
                    phobos_observability::event(
                        "reclaim.prepared_patch_bytes",
                        delta.patches.iter().map(|(_, b)| b.len() as u64).sum(),
                    );
                    applied = Some(delta.outcome);
                } else {
                    phobos_observability::event("reclaim.prepared_base_changed", 1);
                }
            }
            let outcome = match applied {
                Some(outcome) => outcome,
                None => self.reclaim_lifecycle(std::slice::from_ref(plan))?,
            };
            total.retired += outcome.retired;
            total.freed += outcome.freed;
            total.trimmed += outcome.trimmed;
            total.reset += outcome.reset;
        }
        Ok(total)
    }

    /// 0.2-K: one page's lifecycle view for reclaim planning and
    /// diagnostics: header flags, occupied versions, RETIRED slot ids and the
    /// slot census. Statement readers see the current committed image.
    /// `None` past the end of the heap. Overflow pages report no versions.
    /// 0.2-K Part K/L: `page_lifecycle` for reclaim planning that decodes
    /// the row (and reads overflow chains) only of versions `dead` selects;
    /// every other version is decoded header-only. The view's `versions` is
    /// empty; the versions are returned beside it, with `Some(row)` exactly
    /// for the selected ones.
    #[allow(clippy::type_complexity)]
    pub fn page_lifecycle_selective(
        &mut self,
        page_id: PageId,
        mut dead: impl FnMut(&TupleVersion) -> Result<bool, PhobosError>,
    ) -> Result<Option<(PageLifecycleView, Vec<(SlotId, TupleVersion, Option<Row>)>)>, PhobosError>
    {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            let Some(bytes) = self.pool.file.file.read_statement_reference(page_id)? else {
                return Ok(None);
            };
            SlottedPage::from_bytes(bytes)?
        } else {
            if page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(page_id)?
        };
        let census = page.slot_census();
        let mut view = PageLifecycleView {
            flags: page.flags(),
            overflow: page.is_overflow(),
            census,
            versions: Vec::new(),
            retired: Vec::new(),
            free_bytes: page.ordinary_free_space(),
        };
        let mut versions = Vec::new();
        if view.overflow {
            return Ok(Some((view, versions)));
        }
        for slot in 0..page.slot_count() {
            match page.slot_state(slot) {
                SlotState::Occupied => {
                    let bytes = page
                        .get(slot)?
                        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidPage, "occupied slot"))?;
                    let header = TupleVersion::decode_header(bytes)?;
                    if dead(&header)? {
                        let (tuple, row) = self.decode_record(bytes)?;
                        versions.push((slot, tuple, Some(row)));
                    } else {
                        versions.push((slot, header, None));
                    }
                }
                SlotState::Retired => view.retired.push(slot),
                SlotState::Free | SlotState::Vacant => {}
            }
        }
        Ok(Some((view, versions)))
    }

    pub fn page_lifecycle(
        &mut self,
        page_id: PageId,
    ) -> Result<Option<PageLifecycleView>, PhobosError> {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            let Some(bytes) = self.pool.file.file.read_statement_reference(page_id)? else {
                return Ok(None);
            };
            SlottedPage::from_bytes(bytes)?
        } else {
            if page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(page_id)?
        };
        let census = page.slot_census();
        let mut view = PageLifecycleView {
            flags: page.flags(),
            overflow: page.is_overflow(),
            census,
            versions: Vec::new(),
            retired: Vec::new(),
            free_bytes: page.ordinary_free_space(),
        };
        if view.overflow {
            return Ok(Some(view));
        }
        for slot in 0..page.slot_count() {
            match page.slot_state(slot) {
                SlotState::Occupied => {
                    let bytes = page.get(slot)?.expect("occupied slot");
                    let (tuple, row) = self.decode_record(bytes)?;
                    view.versions.push((slot, tuple, row));
                }
                SlotState::Retired => view.retired.push(slot),
                SlotState::Free | SlotState::Vacant => {}
            }
        }
        Ok(Some(view))
    }

    /// 0.2-K diagnostics: census plus the version headers (no payload
    /// decoding) and live tuple bytes of one page. `None` past the end.
    pub fn page_headers(&mut self, page_id: PageId) -> Result<Option<PageHeaders>, PhobosError> {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            let Some(bytes) = self.pool.file.file.read_statement_reference(page_id)? else {
                return Ok(None);
            };
            SlottedPage::from_bytes(bytes)?
        } else {
            if page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(page_id)?
        };
        let mut headers = PageHeaders {
            flags: page.flags(),
            overflow: page.is_overflow(),
            census: page.slot_census(),
            free_bytes: page.free_space(),
            live_bytes: 0,
            versions: Vec::new(),
        };
        if headers.overflow {
            return Ok(Some(headers));
        }
        for slot in 0..page.slot_count() {
            if let Some(bytes) = page.get(slot)? {
                headers.live_bytes += bytes.len();
                headers.versions.push(TupleVersion::decode_header(bytes)?);
            }
        }
        Ok(Some(headers))
    }

    /// 0.2-K: cheap header-only census of one page (diagnostics), without
    /// decoding tuples. `None` past the end of the heap.
    pub fn page_census(
        &mut self,
        page_id: PageId,
    ) -> Result<Option<(u8, bool, SlotCensus, usize)>, PhobosError> {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            let Some(bytes) = self.pool.file.file.read_statement_reference(page_id)? else {
                return Ok(None);
            };
            SlottedPage::from_bytes(bytes)?
        } else {
            if page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(page_id)?
        };
        Ok(Some((
            page.flags(),
            page.is_overflow(),
            page.slot_census(),
            page.ordinary_free_space(),
        )))
    }

    fn check_version_head(
        &mut self,
        rid: RecordId,
        expected: TupleVersion,
    ) -> Result<Row, PhobosError> {
        let (actual, row) = self.get_version(rid)?.ok_or_else(stale_version)?;
        if actual != expected || actual.visibility.deleter.is_some() {
            return Err(stale_version());
        }
        Ok(row)
    }

    pub fn get_version(
        &mut self,
        rid: RecordId,
    ) -> Result<Option<(TupleVersion, Row)>, PhobosError> {
        self.require_versioned()?;
        let page = if self.pool.file.file.is_statement_reader() {
            // Index batches can observe later committed entries on new pages or
            // new slots of cached pages. Refresh physical bytes without extending
            // sequential traversal; visibility remains tied to the original pin.
            let Some(bytes) = self.pool.file.file.read_statement_reference(rid.page_id)? else {
                return Ok(None);
            };
            let page = SlottedPage::from_bytes(bytes)?;
            if page.get_u16(4) != 3 {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "heap tuple capability mismatch",
                ));
            }
            if page.page_id() != rid.page_id {
                return Err(PhobosError::new(
                    ErrorCode::InvalidPage,
                    "heap page identity does not match its position",
                ));
            }
            page
        } else {
            if rid.page_id >= self.pool.page_count()? {
                return Ok(None);
            }
            self.pool.read_page(rid.page_id)?
        };
        if page.is_overflow() {
            return Err(overflow_invalid("RecordId references an overflow page"));
        }
        page.get(rid.slot_id)?
            .map(|bytes| self.decode_record(bytes))
            .transpose()
    }

    pub fn get_visible(
        &mut self,
        rid: RecordId,
        snapshot: Snapshot,
        statuses: &mut impl StatusLookup,
    ) -> Result<Option<Row>, PhobosError> {
        let Some((tuple, row)) = self.get_version(rid)? else {
            return Ok(None);
        };
        if !hint_bits_enabled() {
            return Ok(snapshot.visible(tuple.visibility, statuses)?.then_some(row));
        }
        let known = self.hints.get(rid.page_id, rid.slot_id);
        let (visible, retained) = snapshot.visible_hinted(tuple.visibility, known, statuses)?;
        if retained != known {
            let mut bits = Vec::new();
            set_slot_hints(&mut bits, rid.slot_id, retained);
            self.hints.merge(rid.page_id, &bits);
        }
        Ok(visible.then_some(row))
    }

    /// Bounded physical traversal for migration/integrity. SQL must use the
    /// snapshot-filtered wrapper; this method deliberately exposes metadata.
    pub fn scan_versions(
        &mut self,
        mut visitor: impl FnMut(RecordId, TupleVersion, Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        self.require_versioned()?;
        for id in 0..self.pool.page_count()? {
            cancellation_poll.checkpoint_at("versioned_heap.scan_versions")?;
            let page = self.pool.read_page_ref(id, true)?;
            if page.is_overflow() {
                continue;
            }
            for slot in 0..page.slot_count() {
                cancellation_poll.checkpoint_at("versioned_heap.scan_versions")?;
                if let Some(bytes) = page.get(slot)? {
                    phobos_observability::event("scan_rows_examined", 1);
                    let (tuple, row) = self.decode_record(bytes)?;
                    if !visitor(
                        RecordId {
                            page_id: id,
                            slot_id: slot,
                        },
                        tuple,
                        row,
                    )? {
                        return Ok(());
                    }
                }
            }
        }
        Ok(())
    }

    pub fn scan_visible(
        &mut self,
        snapshot: Snapshot,
        statuses: &mut impl StatusLookup,
        mut visitor: impl FnMut(RecordId, Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        if !hint_bits_enabled() {
            return self.scan_versions(|rid, tuple, row| {
                if snapshot.visible(tuple.visibility, statuses)? {
                    visitor(rid, row)
                } else {
                    Ok(true)
                }
            });
        }
        // B1: one hint-cache read and at most one merge per page.
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        self.require_versioned()?;
        for id in 0..self.pool.page_count()? {
            cancellation_poll.checkpoint_at("versioned_heap.scan_versions")?;
            let page = self.pool.read_page_ref(id, true)?;
            if page.is_overflow() {
                continue;
            }
            let mut bits = self.hints.page(id);
            let mut learned = Vec::new();
            let mut stop = false;
            for slot in 0..page.slot_count() {
                cancellation_poll.checkpoint_at("versioned_heap.scan_versions")?;
                let Some(bytes) = page.get(slot)? else {
                    continue;
                };
                phobos_observability::event("scan_rows_examined", 1);
                let (tuple, row) = self.decode_record(bytes)?;
                let known = slot_hints(&bits, slot).union(TupleVersion::hints_in(bytes));
                let (visible, retained) =
                    snapshot.visible_hinted(tuple.visibility, known, statuses)?;
                if retained != known {
                    set_slot_hints(&mut learned, slot, retained);
                    set_slot_hints(&mut bits, slot, retained);
                }
                if visible
                    && !visitor(
                        RecordId {
                            page_id: id,
                            slot_id: slot,
                        },
                        row,
                    )?
                {
                    stop = true;
                    break;
                }
            }
            self.hints.merge(id, &learned);
            if stop {
                return Ok(());
            }
        }
        Ok(())
    }

    /// 0.2-B Execution Engine v2 scan kernel. Visits snapshot-visible tuples
    /// in physical order with only the `required` columns decoded, as borrowed
    /// values pointing into the immutable page image (the shared committed
    /// frame itself, not a copy). Page validation, visibility and hint
    /// learning are those of `scan_visible`; the payload of an invisible
    /// tuple is never decoded, and no `Row` is built for inline tuples.
    pub fn scan_visible_projected(
        &mut self,
        snapshot: Snapshot,
        statuses: &mut impl StatusLookup,
        required: &[bool],
        mut visitor: impl FnMut(RecordId, &[ValueRef<'_>]) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        self.require_versioned()?;
        let use_hints = hint_bits_enabled();
        for id in 0..self.pool.page_count()? {
            cancellation_poll.checkpoint_at("versioned_heap.scan_versions")?;
            let page = self.pool.read_page_ref(id, true)?;
            if page.is_overflow() {
                continue;
            }
            let mut bits = if use_hints {
                self.hints.page(id)
            } else {
                Vec::new()
            };
            let mut learned = Vec::new();
            let mut values = Vec::with_capacity(required.len());
            let mut stop = false;
            for slot in 0..page.slot_count() {
                cancellation_poll.checkpoint_at("versioned_heap.scan_versions")?;
                let Some(bytes) = page.get(slot)? else {
                    continue;
                };
                phobos_observability::event("scan_rows_examined", 1);
                let rid = RecordId {
                    page_id: id,
                    slot_id: slot,
                };
                let envelope = TupleVersion::decode_envelope(bytes)?;
                let tuple = match &envelope {
                    Envelope::Inline(tuple, _) | Envelope::Overflow(tuple, _) => *tuple,
                };
                let visible = if use_hints {
                    let known = slot_hints(&bits, slot).union(TupleVersion::hints_in(bytes));
                    let (visible, retained) =
                        snapshot.visible_hinted(tuple.visibility, known, statuses)?;
                    if retained != known {
                        set_slot_hints(&mut learned, slot, retained);
                        set_slot_hints(&mut bits, slot, retained);
                    }
                    visible
                } else {
                    snapshot.visible(tuple.visibility, statuses)?
                };
                if !visible {
                    continue;
                }
                let more = match envelope {
                    Envelope::Inline(_, payload) => {
                        RowCodec::decode_projected(&self.schema, payload, required, &mut values)?;
                        visitor(rid, &values)?
                    }
                    Envelope::Overflow(_, reference) => {
                        let payload = self.read_overflow(reference)?;
                        let row = RowCodec::decode(&self.schema, &payload)?;
                        visitor(rid, &project_owned(&row, required))?
                    }
                };
                if !more {
                    stop = true;
                    break;
                }
            }
            if use_hints {
                self.hints.merge(id, &learned);
            }
            if stop {
                return Ok(());
            }
        }
        Ok(())
    }

    /// 0.2-B projected statement fetch for index access: the committed page is
    /// borrowed from the shared cache (no 8 KiB copy), the tuple's visibility
    /// is resolved with hints exactly as `get_visible`, and only `required`
    /// columns of a visible inline tuple are decoded. Returns whether a
    /// visible version was delivered. Non-statement heaps use `get_visible`.
    pub fn get_visible_projected(
        &mut self,
        rid: RecordId,
        snapshot: Snapshot,
        statuses: &mut impl StatusLookup,
        required: &[bool],
        visitor: &mut dyn FnMut(&[ValueRef<'_>]) -> Result<(), PhobosError>,
    ) -> Result<bool, PhobosError> {
        self.require_versioned()?;
        if !self.pool.file.file.is_statement_reader() {
            let Some(row) = self.get_visible(rid, snapshot, statuses)? else {
                return Ok(false);
            };
            visitor(&project_owned(&row, required))?;
            return Ok(true);
        }
        let Some((image, validated)) = self
            .pool
            .file
            .file
            .read_statement_reference_shared(rid.page_id)?
        else {
            return Ok(false);
        };
        let page = PageRef::Shared(image, validated);
        page.check(rid.page_id, Some(true))?;
        if page.is_overflow() {
            return Err(overflow_invalid("RecordId references an overflow page"));
        }
        let Some(bytes) = page.get(rid.slot_id)? else {
            return Ok(false);
        };
        let envelope = TupleVersion::decode_envelope(bytes)?;
        let tuple = match &envelope {
            Envelope::Inline(tuple, _) | Envelope::Overflow(tuple, _) => *tuple,
        };
        let visible = if hint_bits_enabled() {
            let known = self
                .hints
                .get(rid.page_id, rid.slot_id)
                .union(TupleVersion::hints_in(bytes));
            let (visible, retained) = snapshot.visible_hinted(tuple.visibility, known, statuses)?;
            if retained != known {
                let mut bits = Vec::new();
                set_slot_hints(&mut bits, rid.slot_id, retained);
                self.hints.merge(rid.page_id, &bits);
            }
            visible
        } else {
            snapshot.visible(tuple.visibility, statuses)?
        };
        if !visible {
            return Ok(false);
        }
        match envelope {
            Envelope::Inline(_, payload) => {
                let mut values = Vec::with_capacity(required.len());
                RowCodec::decode_projected(&self.schema, payload, required, &mut values)?;
                visitor(&values)?;
            }
            Envelope::Overflow(_, reference) => {
                let payload = self.read_overflow(reference)?;
                let row = RowCodec::decode(&self.schema, &payload)?;
                visitor(&project_owned(&row, required))?;
            }
        }
        Ok(true)
    }

    /// Count snapshot-visible tuple envelopes without decoding user rows.
    pub fn count_visible_versions(
        &mut self,
        snapshot: Snapshot,
        statuses: &mut impl StatusLookup,
    ) -> Result<u64, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        self.require_versioned()?;
        let mut count = 0u64;
        let use_hints = hint_bits_enabled();
        for id in 0..self.pool.page_count()? {
            cancellation_poll.checkpoint_at("versioned_heap.count_visible")?;
            let page = self.pool.read_page_ref(id, true)?;
            if page.is_overflow() {
                continue;
            }
            let mut bits = if use_hints {
                self.hints.page(id)
            } else {
                Vec::new()
            };
            let mut learned = Vec::new();
            for slot in 0..page.slot_count() {
                cancellation_poll.checkpoint_at("versioned_heap.count_visible")?;
                let Some(bytes) = page.get(slot)? else {
                    continue;
                };
                phobos_observability::event("scan_rows_examined", 1);
                let tuple = TupleVersion::decode_header(bytes)?;
                let visible = if use_hints {
                    let known = slot_hints(&bits, slot).union(TupleVersion::hints_in(bytes));
                    let (visible, retained) =
                        snapshot.visible_hinted(tuple.visibility, known, statuses)?;
                    if retained != known {
                        set_slot_hints(&mut learned, slot, retained);
                        set_slot_hints(&mut bits, slot, retained);
                    }
                    visible
                } else {
                    snapshot.visible(tuple.visibility, statuses)?
                };
                if visible {
                    count = count.checked_add(1).ok_or_else(|| {
                        PhobosError::new(ErrorCode::ResourceLimit, "row count overflow")
                    })?;
                    phobos_observability::event("count_fast_rows", 1);
                }
            }
            if use_hints {
                self.hints.merge(id, &learned);
            }
        }
        Ok(count)
    }
}

/// Borrowed view of an owned row restricted to `required` (others `Absent`).
pub(crate) fn project_owned<'a>(row: &'a Row, required: &[bool]) -> Vec<ValueRef<'a>> {
    row.values
        .iter()
        .zip(required)
        .map(|(value, wanted)| {
            if *wanted {
                value.as_value_ref()
            } else {
                ValueRef::Absent
            }
        })
        .collect()
}

fn stale_version() -> PhobosError {
    PhobosError::new(
        ErrorCode::TransactionState,
        "tuple version changed; transaction must retry",
    )
}

fn overflow_invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_txn::mvcc::{SnapshotRegistry, Status, Version};
    use phobos_types::ColumnSchema;

    #[test]
    fn f4_overflow_rows_round_trip_reclaim_reuse_and_reject_cycles() {
        let root = std::env::temp_dir().join(format!(
            "phobos-f4-overflow-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&root).unwrap();
        let schema = TableSchema {
            id: 1,
            name: "wide".into(),
            columns: vec![ColumnSchema {
                name: "payload".into(),
                data_type: DataType::Binary,
                nullable: false,
            }],
        };
        let mut heap = HeapTable::open_versioned(root.join("table.heap"), schema, 8).unwrap();
        heap.begin_private(&root.join("wide.private"), 1, &root)
            .unwrap();
        let tuple = TupleVersion {
            logical_row: 1,
            visibility: Version {
                creator: 1,
                deleter: None,
            },
            previous: None,
        };
        let inline = TupleVersion {
            logical_row: 2,
            ..tuple
        };
        let inline_rid = heap
            .insert_version(
                inline,
                &Row {
                    values: vec![Value::Binary(vec![1; 32])],
                },
            )
            .unwrap();
        let inline_page = heap.pool.read_page(inline_rid.page_id).unwrap();
        assert!(
            TupleVersion::decode_overflow(inline_page.get(inline_rid.slot_id).unwrap().unwrap())
                .unwrap()
                .is_none()
        );
        let row = Row {
            values: vec![Value::Binary(vec![0x5a; 24_000])],
        };
        let rid = heap.insert_version(tuple, &row).unwrap();
        let pages = heap.private_page_count().unwrap();
        assert!(pages >= 4);
        assert_eq!(heap.get_version(rid).unwrap().unwrap().1, row);
        heap.reclaim_versions(&[(rid.page_id, vec![(rid.slot_id, tuple)], false)])
            .unwrap();
        let reused = heap.insert_version(tuple, &row).unwrap();
        assert_eq!(heap.private_page_count().unwrap(), pages);
        assert_eq!(heap.get_version(reused).unwrap().unwrap().1, row);

        let main = heap.pool.read_page(reused.page_id).unwrap();
        let (_, reference) =
            TupleVersion::decode_overflow(main.get(reused.slot_id).unwrap().unwrap())
                .unwrap()
                .unwrap();
        println!(
            "F4_COUNTERS inline_bytes={} overflow_pages={} reclaimed_reused_pages={}",
            inline_page.get(inline_rid.slot_id).unwrap().unwrap().len(),
            reference.page_count,
            reference.page_count
        );
        let mut first = heap.pool.read_page(reference.first_page).unwrap();
        let slot = HEADER_SIZE;
        let start = usize::from(first.get_u16(slot));
        first.bytes[start + 8..start + 16].copy_from_slice(&reference.first_page.to_le_bytes());
        first.refresh_checksum();
        heap.pool.put_dirty(first).unwrap();
        assert_eq!(
            heap.get_version(reused).unwrap_err().code,
            ErrorCode::InvalidPage
        );
        heap.rollback_private().unwrap();
        drop(heap);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn statement_heap_readers_overlap_private_versions_and_recover_unflushed_commit() {
        use phobos_txn::mvcc::{StatusFile, sessions::SessionManager};
        use phobos_wal::v2::{FileId, PageAction, Wal};
        use std::{
            sync::{Arc, mpsc},
            time::Duration,
        };
        let root = std::env::temp_dir().join(format!(
            "phobos-statement-heap-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut wal = Wal::create_with_versioned_heap(&root).unwrap();
        let root = std::fs::canonicalize(root).unwrap();
        let manager =
            SessionManager::new(StatusFile::create(&root, 128).unwrap(), 4, 4, 8).unwrap();
        let writer = manager.connect(1).unwrap();
        let reader = manager.connect(2).unwrap();
        let schema = TableSchema {
            id: 1,
            name: "t".into(),
            columns: vec![ColumnSchema {
                name: "v".into(),
                data_type: DataType::Int64,
                nullable: false,
            }],
        };
        let identity = FileId::Heap(1);
        let path = root.join(identity.name());
        let store = committed_pages::CommittedStore::new(
            &root,
            committed_pages::FlushConfig {
                wake_interval: Duration::from_secs(3600),
                ..Default::default()
            },
        )
        .unwrap();
        let mut heap = HeapTable::open_versioned(&path, schema.clone(), 2).unwrap();
        heap.attach_committed(&store, identity).unwrap();
        let first = writer.begin().unwrap();
        heap.begin_private(&root.join("first.private"), first, &root)
            .unwrap();
        let initial = TupleVersion {
            logical_row: 1,
            visibility: Version {
                creator: first,
                deleter: None,
            },
            previous: None,
        };
        let original = heap
            .insert_version(
                initial,
                &Row {
                    values: vec![Value::Int64(1)],
                },
            )
            .unwrap();
        wal.begin_mvcc(first).unwrap();
        heap.prepare_private_redo(identity, |page, bytes, _| {
            wal.append_page(PageAction::HeapUpdate, identity, page, bytes)?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        writer
            .submit_commit()
            .unwrap()
            .publish(&receipt, || heap.install_private(&receipt))
            .unwrap();
        assert_eq!(std::fs::metadata(&path).unwrap().len(), 0);

        let second = writer.begin().unwrap();
        heap.begin_private(&root.join("second.private"), second, &root)
            .unwrap();
        let successor = heap
            .update_version(
                original,
                initial,
                &Row {
                    values: vec![Value::Int64(2)],
                },
            )
            .unwrap();
        assert_eq!(
            heap.get_version(successor).unwrap().unwrap().0.previous,
            Some(original)
        );
        let mut own = writer.statement().unwrap();
        let own_snapshot = own.snapshot();
        assert!(
            heap.get_visible(original, own_snapshot, &mut own)
                .unwrap()
                .is_none()
        );
        assert_eq!(
            heap.get_visible(successor, own_snapshot, &mut own)
                .unwrap()
                .unwrap()
                .values,
            vec![Value::Int64(2)]
        );
        drop(own);
        let statement = Arc::new(reader.statement().unwrap());
        let mut view = heap.statement_reader(statement.clone()).unwrap();
        drop(statement);
        assert!(
            view.insert_version(
                initial,
                &Row {
                    values: vec![Value::Int64(99)]
                }
            )
            .is_err()
        );
        let (sent, received) = mpsc::channel();
        let reading = std::thread::spawn(move || {
            sent.send(view.scan().unwrap()).unwrap();
            view
        });
        let rows = received
            .recv_timeout(Duration::from_secs(5))
            .expect("reader blocked behind paused private writer");
        assert_eq!(
            rows,
            vec![(
                original,
                Row {
                    values: vec![Value::Int64(1)]
                }
            )]
        );
        let mut old_view = reading.join().unwrap();
        assert!(reader.statement().is_err()); // heap lease, not the caller's Arc, retains the pin
        wal.begin_mvcc(second).unwrap();
        heap.prepare_private_redo(identity, |page, bytes, _| {
            wal.append_page(PageAction::HeapUpdate, identity, page, bytes)?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        writer
            .submit_commit()
            .unwrap()
            .publish(&receipt, || heap.install_private(&receipt))
            .unwrap();
        assert_eq!(old_view.scan().unwrap(), rows);
        drop(old_view);
        let mut fresh = heap
            .statement_reader(Arc::new(reader.statement().unwrap()))
            .unwrap();
        assert_eq!(
            fresh.scan().unwrap(),
            vec![(
                successor,
                Row {
                    values: vec![Value::Int64(2)]
                }
            )]
        );
        assert!(fresh.get(original).unwrap().is_none());
        drop(fresh);

        let third = writer.begin().unwrap();
        heap.begin_private(&root.join("third.private"), third, &root)
            .unwrap();
        let current = heap.get_version(successor).unwrap().unwrap().0;
        heap.delete_version(successor, current).unwrap();
        assert!(heap.delete_version(successor, current).is_err());
        let mut own = writer.statement().unwrap();
        assert!(
            heap.get_visible(successor, own.snapshot(), &mut own)
                .unwrap()
                .is_none()
        );
        drop(own);
        heap.rollback_private().unwrap();
        writer.rollback().unwrap();
        assert_eq!(heap.get_version(successor).unwrap().unwrap().0, current);
        assert_eq!(std::fs::metadata(&path).unwrap().len(), 0);
        drop(heap);
        drop(store);
        drop(writer);
        drop(reader);
        drop(manager);
        drop(wal);
        for _ in 0..2 {
            let (mut statuses, recovered) = StatusFile::recover_database(&root).unwrap();
            let mut recovered_heap = HeapTable::open_versioned(&path, schema.clone(), 2).unwrap();
            let mut snapshots = SnapshotRegistry::new(statuses.durable_frontier(), 1).unwrap();
            let pin = snapshots.pin(None).unwrap();
            let mut restored = Vec::new();
            recovered_heap
                .scan_visible(pin.snapshot(), &mut statuses, |rid, row| {
                    restored.push((rid, row));
                    Ok(true)
                })
                .unwrap();
            assert_eq!(
                restored,
                vec![(
                    successor,
                    Row {
                        values: vec![Value::Int64(2)]
                    }
                )]
            );
            drop(recovered_heap);
            drop(statuses);
            drop(recovered);
        }
        std::fs::remove_dir_all(root).unwrap();
    }

    struct Statuses;
    impl StatusLookup for Statuses {
        fn status(&mut self, id: u64) -> Result<Status, PhobosError> {
            Ok(match id {
                1 => Status::Committed { sequence: 10 },
                2 => Status::InProgress,
                _ => Status::Aborted,
            })
        }
    }

    /// Bulk batches seal each page exactly once: every private image (full
    /// pages and the partially filled last page) validates, rollover across
    /// batches continues the open page, rollback restores the heap, and a
    /// corrupted image is still rejected.
    #[test]
    fn bulk_batches_seal_every_page_across_rollover_and_rollback() {
        let dir = std::env::temp_dir().join(format!(
            "phobos-bulk-seal-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&dir).unwrap();
        let root = std::fs::canonicalize(&dir).unwrap();
        let schema = TableSchema {
            id: 1,
            name: "t".into(),
            columns: vec![
                ColumnSchema {
                    name: "v".into(),
                    data_type: DataType::Int64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "p".into(),
                    data_type: DataType::Text,
                    nullable: false,
                },
            ],
        };
        let path = root.join("table-0000000000000001.heap");
        let mut heap = HeapTable::open_versioned(&path, schema.clone(), 2).unwrap();
        let owner = 5;
        let image = |n: u64| {
            TupleVersion {
                logical_row: n,
                visibility: Version {
                    creator: owner,
                    deleter: None,
                },
                previous: None,
            }
            .encode(
                &schema,
                &Row {
                    values: vec![Value::Int64(n as i64), Value::Text("x".repeat(60))],
                },
            )
            .unwrap()
        };
        heap.begin_private(&root.join("bulk.private"), owner, &root)
            .unwrap();
        // Two batches: the second continues the page the first left open.
        let first = heap
            .insert_version_batch(&(1..=200).map(image).collect::<Vec<_>>())
            .unwrap();
        let second = heap
            .insert_version_batch(&(201..=300).map(image).collect::<Vec<_>>())
            .unwrap();
        let rids = [first.clone(), second.clone()].concat();
        assert_eq!(rids.len(), 300);
        assert!(rids.windows(2).all(|w| w[0] < w[1]), "RIDs ascend");
        let pages = heap.pool.page_count().unwrap();
        assert!(pages >= 3, "{pages} pages: rollover happened");
        assert_eq!(rids.last().unwrap().page_id, pages - 1);
        assert_eq!(
            first.last().unwrap().page_id,
            second.first().unwrap().page_id,
            "second batch continued the open page"
        );
        assert!(second.first().unwrap().slot_id > 0);
        // Every private image, including the partially filled last page,
        // carries a valid checksum before anything is logged or published.
        let mut validated = 0;
        let mut last_slots = 0;
        heap.prepare_private(|id, bytes, _| {
            let page = SlottedPage::from_bytes(*bytes)?;
            assert_eq!(page.page_id(), id);
            validated += 1;
            if id == pages - 1 {
                last_slots = page.slot_count();
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(validated, pages);
        assert!(last_slots > 0 && u64::from(last_slots) < 300 / pages + 1);
        // Reads through the checksum-validating page path, not the frame cache.
        heap.pool.frames.clear();
        for (n, rid) in (1..=300u64).zip(&rids) {
            let (tuple, row) = heap.get_version(*rid).unwrap().unwrap();
            assert_eq!(tuple.logical_row, n);
            assert_eq!(row.values[0], Value::Int64(n as i64));
        }
        // A corrupted sealed image is still rejected.
        let mut bytes = heap.pool.read_page(0).unwrap().to_bytes();
        bytes[PAGE_SIZE - 1] ^= 0x40;
        assert_eq!(
            SlottedPage::from_bytes(bytes).unwrap_err().code,
            ErrorCode::ChecksumMismatch
        );
        // Rollback discards every bulk page; the heap is usable again.
        heap.rollback_private().unwrap();
        assert_eq!(heap.pool.page_count().unwrap(), 0);
        assert!(heap.get_version(rids[0]).ok().flatten().is_none());
        heap.begin_private(&root.join("again.private"), owner, &root)
            .unwrap();
        let again = heap
            .insert_version_batch(&(1..=3).map(image).collect::<Vec<_>>())
            .unwrap();
        assert_eq!(again[0].page_id, 0);
        heap.rollback_private().unwrap();
        drop(heap);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn explicit_heap_format_and_visibility_are_required() {
        let dir = std::env::temp_dir().join(format!(
            "phobos-versioned-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&dir).unwrap();
        let schema = TableSchema {
            id: 1,
            name: "t".into(),
            columns: vec![ColumnSchema {
                name: "v".into(),
                data_type: DataType::Int64,
                nullable: true,
            }],
        };
        let path = dir.join("table-0000000000000001.heap");
        let mut heap = HeapTable::open_versioned(&path, schema.clone(), 2).unwrap();
        let mut ids = Vec::new();
        for creator in 1..=3 {
            ids.push(
                heap.insert_version(
                    TupleVersion {
                        logical_row: creator,
                        visibility: Version {
                            creator,
                            deleter: None,
                        },
                        previous: None,
                    },
                    &Row {
                        values: vec![Value::Int64(creator as i64)],
                    },
                )
                .unwrap(),
            );
        }
        assert!(heap.get(ids[0]).is_err());
        assert!(heap.scan().is_err());
        assert!(heap.delete(ids[0]).is_err());
        let mut snapshots = SnapshotRegistry::new(10, 2).unwrap();
        let reader = snapshots.pin(None).unwrap();
        let own = snapshots.pin(Some(2)).unwrap();
        assert_eq!(
            heap.count_visible_versions(reader.snapshot(), &mut Statuses)
                .unwrap(),
            1
        );
        assert_eq!(
            heap.count_visible_versions(own.snapshot(), &mut Statuses)
                .unwrap(),
            2
        );
        let mut rows = Vec::new();
        heap.scan_visible(reader.snapshot(), &mut Statuses, |_, row| {
            rows.push(row);
            Ok(true)
        })
        .unwrap();
        assert_eq!(rows.len(), 1);
        assert!(
            heap.get_visible(ids[1], reader.snapshot(), &mut Statuses)
                .unwrap()
                .is_none()
        );
        assert!(
            heap.get_visible(ids[1], own.snapshot(), &mut Statuses)
                .unwrap()
                .is_some()
        );
        assert!(
            heap.get_visible(ids[2], own.snapshot(), &mut Statuses)
                .unwrap()
                .is_none()
        );
        drop(heap);
        assert!(HeapTable::open(&path, schema.clone(), 2).is_err());
        let mut heap = HeapTable::open_versioned(&path, schema, 2).unwrap();
        assert_eq!(heap.get_version(ids[0]).unwrap().unwrap().0.logical_row, 1);
        drop(heap);
        std::fs::remove_dir_all(dir).unwrap();
    }
}
