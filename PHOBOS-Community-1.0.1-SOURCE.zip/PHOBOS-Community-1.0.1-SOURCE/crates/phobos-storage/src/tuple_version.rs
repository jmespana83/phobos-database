//! Explicit tuple envelope codec for C5 heap page version 3 / WAL capability 4.
//! Legacy heaps require explicit backup-first offline migration.
//! SQL RowCodec and client/protocol encoding remain unchanged.
use crate::RowCodec;
use phobos_error::{ErrorCode, PhobosError};
use phobos_txn::mvcc::Version;
use phobos_types::{RecordId, Row, TableSchema};

const HEADER: usize = 48;
const OVERFLOW_REFERENCE: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct OverflowReference {
    pub first_page: u64,
    pub page_count: u32,
    pub total_length: u32,
    pub checksum: u32,
}
/// 0.1.9-B1: envelope byte 7 is the hint-flag byte (`Hints::MASK` bits are
/// settled-visibility hints, other bits stay reserved and must be zero).
/// The on-disk size is unchanged; this round never writes the bits to pages
/// (hints are cache-resident), but the codec accepts them so a page carrying
/// them decodes to the same version.
pub const HINT_FLAGS_OFFSET: usize = 7;

/// 0.2-B: a validated tuple envelope.
pub(crate) enum Envelope<'a> {
    Inline(TupleVersion, &'a [u8]),
    Overflow(TupleVersion, OverflowReference),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TupleVersion {
    /// Table-local identity, unchanged by UPDATE; never a reusable physical slot.
    pub logical_row: u64,
    pub visibility: Version,
    pub previous: Option<RecordId>,
}

impl TupleVersion {
    /// Decode and validate the tuple envelope without materializing its user
    /// row. COUNT(*) uses this because visibility lives entirely in the fixed
    /// envelope, including for overflow rows.
    pub fn decode_header(bytes: &[u8]) -> Result<Self, PhobosError> {
        if let Some((tuple, _)) = Self::decode_overflow(bytes)? {
            return Ok(tuple);
        }
        Self::decode_inline_header(bytes)
    }

    /// 0.2-B: one validation pass over a tuple envelope, returning the inline
    /// payload or the overflow reference (P1-E kernels validated the header
    /// two or three times per tuple).
    pub(crate) fn decode_envelope(bytes: &[u8]) -> Result<Envelope<'_>, PhobosError> {
        if let Some((tuple, reference)) = Self::decode_overflow(bytes)? {
            return Ok(Envelope::Overflow(tuple, reference));
        }
        let tuple = Self::decode_inline_header(bytes)?;
        Ok(Envelope::Inline(tuple, &bytes[HEADER..]))
    }

    fn decode_inline_header(bytes: &[u8]) -> Result<Self, PhobosError> {
        if bytes.len() < HEADER
            || &bytes[..4] != b"PHMV"
            || bytes[4..6] != [1, 0]
            || bytes[6] > 1
            || bytes[HINT_FLAGS_OFFSET] & !phobos_txn::mvcc::Hints::MASK != 0
            || bytes[42..44] != [0, 0]
        {
            return Err(invalid());
        }
        let payload_length =
            u32::from_le_bytes(bytes[44..48].try_into().expect("four bytes")) as usize;
        if payload_length != bytes.len() - HEADER {
            return Err(invalid());
        }
        let previous = if bytes[6] == 1 {
            Some(RecordId {
                page_id: number(&bytes[32..40]),
                slot_id: u16::from_le_bytes(bytes[40..42].try_into().expect("two bytes")),
            })
        } else {
            if bytes[32..42] != [0; 10] {
                return Err(invalid());
            }
            None
        };
        let deleter = number(&bytes[16..24]);
        let tuple = Self {
            logical_row: number(&bytes[24..32]),
            visibility: Version {
                creator: number(&bytes[8..16]),
                deleter: (deleter != 0).then_some(deleter),
            },
            previous,
        };
        tuple.validate()?;
        Ok(tuple)
    }

    pub fn encode(self, schema: &TableSchema, row: &Row) -> Result<Vec<u8>, PhobosError> {
        self.validate()?;
        let payload = RowCodec::encode(schema, row)?;
        HEADER.checked_add(payload.len()).ok_or_else(invalid)?;
        let mut bytes = vec![0; HEADER];
        bytes[..4].copy_from_slice(b"PHMV");
        bytes[4..6].copy_from_slice(&1u16.to_le_bytes());
        bytes[6] = u8::from(self.previous.is_some());
        bytes[8..16].copy_from_slice(&self.visibility.creator.to_le_bytes());
        bytes[16..24].copy_from_slice(&self.visibility.deleter.unwrap_or(0).to_le_bytes());
        bytes[24..32].copy_from_slice(&self.logical_row.to_le_bytes());
        if let Some(previous) = self.previous {
            bytes[32..40].copy_from_slice(&previous.page_id.to_le_bytes());
            bytes[40..42].copy_from_slice(&previous.slot_id.to_le_bytes());
        }
        bytes[44..48].copy_from_slice(&(payload.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&payload);
        Ok(bytes)
    }

    pub(crate) fn encode_overflow(
        self,
        reference: OverflowReference,
    ) -> Result<Vec<u8>, PhobosError> {
        self.validate()?;
        if reference.page_count == 0 || reference.total_length == 0 {
            return Err(invalid());
        }
        let mut bytes = vec![0; OVERFLOW_REFERENCE];
        bytes[..4].copy_from_slice(b"PHMV");
        bytes[4..6].copy_from_slice(&2u16.to_le_bytes());
        bytes[6] = u8::from(self.previous.is_some());
        bytes[8..16].copy_from_slice(&self.visibility.creator.to_le_bytes());
        bytes[16..24].copy_from_slice(&self.visibility.deleter.unwrap_or(0).to_le_bytes());
        bytes[24..32].copy_from_slice(&self.logical_row.to_le_bytes());
        if let Some(previous) = self.previous {
            bytes[32..40].copy_from_slice(&previous.page_id.to_le_bytes());
            bytes[40..42].copy_from_slice(&previous.slot_id.to_le_bytes());
        }
        bytes[44..48].copy_from_slice(&reference.total_length.to_le_bytes());
        bytes[48..56].copy_from_slice(&reference.first_page.to_le_bytes());
        bytes[56..60].copy_from_slice(&reference.page_count.to_le_bytes());
        bytes[60..64].copy_from_slice(&reference.checksum.to_le_bytes());
        Ok(bytes)
    }

    pub fn decode(schema: &TableSchema, bytes: &[u8]) -> Result<(Self, Row), PhobosError> {
        if bytes.len() < HEADER
            || &bytes[..4] != b"PHMV"
            || bytes[4..6] != [1, 0]
            || bytes[6] > 1
            || bytes[HINT_FLAGS_OFFSET] & !phobos_txn::mvcc::Hints::MASK != 0
            || bytes[42..44] != [0, 0]
        {
            return Err(invalid());
        }
        let payload_length =
            u32::from_le_bytes(bytes[44..48].try_into().expect("four bytes")) as usize;
        if payload_length != bytes.len() - HEADER {
            return Err(invalid());
        }
        let tuple = Self::decode_header(bytes)?;
        Ok((tuple, RowCodec::decode(schema, &bytes[HEADER..])?))
    }

    pub(crate) fn decode_overflow(
        bytes: &[u8],
    ) -> Result<Option<(Self, OverflowReference)>, PhobosError> {
        if bytes.get(..4) != Some(b"PHMV") || bytes.get(4..6) != Some(&[2, 0]) {
            return Ok(None);
        }
        if bytes.len() != OVERFLOW_REFERENCE
            || bytes[6] > 1
            || bytes[HINT_FLAGS_OFFSET] & !phobos_txn::mvcc::Hints::MASK != 0
            || bytes[42..44] != [0, 0]
        {
            return Err(invalid());
        }
        let previous = if bytes[6] == 1 {
            Some(RecordId {
                page_id: number(&bytes[32..40]),
                slot_id: u16::from_le_bytes(bytes[40..42].try_into().expect("two bytes")),
            })
        } else {
            if bytes[32..42] != [0; 10] {
                return Err(invalid());
            }
            None
        };
        let deleter = number(&bytes[16..24]);
        let tuple = Self {
            logical_row: number(&bytes[24..32]),
            visibility: Version {
                creator: number(&bytes[8..16]),
                deleter: (deleter != 0).then_some(deleter),
            },
            previous,
        };
        tuple.validate()?;
        let reference = OverflowReference {
            total_length: u32::from_le_bytes(bytes[44..48].try_into().expect("four bytes")),
            first_page: number(&bytes[48..56]),
            page_count: u32::from_le_bytes(bytes[56..60].try_into().expect("four bytes")),
            checksum: u32::from_le_bytes(bytes[60..64].try_into().expect("four bytes")),
        };
        if reference.page_count == 0 || reference.total_length == 0 {
            return Err(invalid());
        }
        Ok(Some((tuple, reference)))
    }

    /// Settled-visibility hint flags carried by an encoded envelope.
    #[must_use]
    pub fn hints_in(bytes: &[u8]) -> phobos_txn::mvcc::Hints {
        bytes
            .get(HINT_FLAGS_OFFSET)
            .map_or_else(Default::default, |flags| {
                phobos_txn::mvcc::Hints::from_bits(*flags)
            })
    }

    fn validate(self) -> Result<(), PhobosError> {
        if self.logical_row == 0
            || self.visibility.creator == 0
            || self.visibility.deleter == Some(0)
        {
            return Err(invalid());
        }
        Ok(())
    }
}

fn number(bytes: &[u8]) -> u64 {
    u64::from_le_bytes(bytes.try_into().expect("eight bytes"))
}
fn invalid() -> PhobosError {
    PhobosError::new(
        ErrorCode::InvalidPage,
        "invalid or unsupported MVCC tuple envelope",
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_types::{ColumnSchema, DataType, Value};

    #[test]
    fn explicit_envelope_preserves_public_row_codec_and_version_links() {
        let schema = TableSchema {
            id: 1,
            name: "t".into(),
            columns: vec![ColumnSchema {
                name: "v".into(),
                data_type: DataType::Int64,
                nullable: true,
            }],
        };
        let tuple = TupleVersion {
            logical_row: 7,
            visibility: Version {
                creator: 2,
                deleter: Some(3),
            },
            previous: Some(RecordId {
                page_id: 0,
                slot_id: 0,
            }),
        };
        for row in [
            Row {
                values: vec![Value::Int64(42)],
            },
            Row {
                values: vec![Value::Null],
            },
        ] {
            let bytes = tuple.encode(&schema, &row).unwrap();
            assert_eq!(&bytes[HEADER..], RowCodec::encode(&schema, &row).unwrap());
            assert_eq!(TupleVersion::decode(&schema, &bytes).unwrap(), (tuple, row));
            for offset in [4, 6, 7, 42, 44] {
                let mut invalid = bytes.clone();
                invalid[offset] = 0xff;
                assert!(TupleVersion::decode(&schema, &invalid).is_err());
            }
            assert!(TupleVersion::decode(&schema, &bytes[..bytes.len() - 1]).is_err());
        }
        let row = Row {
            values: vec![Value::Int64(1)],
        };
        assert!(TupleVersion::decode(&schema, &RowCodec::encode(&schema, &row).unwrap()).is_err());
    }
}
