use super::*;
use phobos_types::ColumnSchema;
use std::fs;

fn schema() -> TableSchema {
    TableSchema {
        id: 1,
        name: "b5".into(),
        columns: vec![ColumnSchema {
            name: "v".into(),
            data_type: DataType::Text,
            nullable: false,
        }],
    }
}

#[test]
fn lazy_open_reads_only_endpoints_and_defers_interior_corruption() {
    let path = std::env::temp_dir().join(format!("phobos-b5-{}.heap", std::process::id()));
    let row = Row::new(vec![Value::Text("x".repeat(5000))]);
    let encoded = RowCodec::encode(&schema(), &row).unwrap();
    let mut bytes = Vec::new();
    for id in 0..32 {
        let mut page = SlottedPage::new(id);
        page.insert(&encoded).unwrap();
        bytes.extend_from_slice(&page.to_bytes());
    }
    fs::write(&path, &bytes).unwrap();
    {
        let mut heap = HeapTable::open(&path, schema(), 64).unwrap();
        assert_eq!(heap.cached_pages(), 2);
        assert_eq!(
            heap.free_space.iter().filter(|v| **v == usize::MAX).count(),
            30
        );
        assert_eq!(heap.scan().unwrap().len(), 32);
        // Unknown hints must not cause an insert into a full page.
        let rid = heap.insert(&row).unwrap();
        assert_eq!(rid.page_id, 32);
    }
    // Recreate file, corrupt a page outside the two startup endpoints.
    bytes[16 * PAGE_SIZE + 4000] ^= 1;
    fs::write(&path, &bytes).unwrap();
    {
        let mut heap = HeapTable::open(&path, schema(), 64).unwrap();
        assert_eq!(heap.cached_pages(), 2);
        assert!(
            heap.get(RecordId {
                page_id: 0,
                slot_id: 0
            })
            .unwrap()
            .is_some()
        );
        assert_eq!(
            heap.get(RecordId {
                page_id: 16,
                slot_id: 0
            })
            .unwrap_err()
            .code,
            ErrorCode::ChecksumMismatch
        );
        assert_eq!(heap.scan().unwrap_err().code, ErrorCode::ChecksumMismatch);
    }
    fs::remove_file(path).unwrap();
}

#[test]
fn old_fnv_heap_reads_and_rewrite_preserves_rows_with_crc32c() {
    let mut page = SlottedPage::new(7);
    page.insert(b"old row").unwrap();
    let mut bytes = page.to_bytes();
    bytes[7] = 0;
    bytes[32..36].fill(0);
    let fnv = bytes.iter().fold(0x811c_9dc5u32, |h, b| {
        (h ^ u32::from(*b)).wrapping_mul(0x0100_0193)
    });
    bytes[32..36].copy_from_slice(&fnv.to_le_bytes());
    let mut old = SlottedPage::from_bytes(bytes).unwrap();
    assert_eq!(old.get(0).unwrap(), Some(b"old row".as_slice()));
    old.insert(b"new row").unwrap();
    assert_eq!(old.to_bytes()[7], 1);
    let reopened = SlottedPage::from_bytes(old.to_bytes()).unwrap();
    assert_eq!(reopened.get(0).unwrap(), Some(b"old row".as_slice()));
    assert_eq!(reopened.get(1).unwrap(), Some(b"new row".as_slice()));
    let mut corrupt = reopened.to_bytes();
    corrupt[4000] ^= 1;
    assert_eq!(
        SlottedPage::from_bytes(corrupt).unwrap_err().code,
        ErrorCode::ChecksumMismatch
    );
}
