//! Bounded private page images. These scratch records are never a durability
//! source: a transaction must log and sync its WAL before installing any image.
use super::PAGE_SIZE;
use phobos_error::{ErrorCode, PhobosError};
use std::{
    collections::{BTreeMap, HashMap},
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
};

const BUCKETS: usize = 4096;
const CACHE_PAGES: usize = 64;
/// 0.2-B: a prepared generation of at most this many changed pages stays
/// memory-resident and never creates its scratch file (small OLTP commits
/// previously paid create/write/close/remove for every touched file).
/// 0.2-G: raised from 8 to just below the cache size, so a medium transaction (e.g. 500
/// rows: ~30 changed pages) no longer creates, writes, renames and deletes a
/// scratch directory per commit. Residency stays bounded: a batch publishes
/// inline once its staged redo exceeds 1 MiB, and a generation that outgrows
/// the cache spills exactly as before.
const RESIDENT_PREPARED_PAGES: u64 = CACHE_PAGES as u64 - 1;
const HEADER: usize = 24;
const RECORD_BYTES: u64 = (HEADER + PAGE_SIZE) as u64;

type Result<T> = std::result::Result<T, PhobosError>;

struct Cleanup {
    path: PathBuf,
    armed: bool,
}
impl Cleanup {
    fn remove(mut self) -> Result<()> {
        if !self.armed {
            // The scratch file was never created.
            return Ok(());
        }
        self.armed = false;
        fs::remove_file(&self.path)?;
        Ok(())
    }
    fn release(mut self) {
        self.armed = false;
    }
}
impl Drop for Cleanup {
    fn drop(&mut self) {
        if self.armed {
            let _ = fs::remove_file(&self.path);
        }
    }
}

#[derive(Clone, Copy)]
struct Record {
    offset: u64,
    page: u64,
    next: u64,
    data_checksum: u32,
    persisted: bool,
}
struct Cached {
    record: Record,
    bytes: Box<[u8; PAGE_SIZE]>,
    modified: bool,
    last_use: u64,
}

/// Bounded maintenance patches borrow immutable predecessor images; unlike
/// ordinary private pages these never spill a whole image to scratch.
struct LifecyclePatch {
    base: std::sync::Arc<[u8; PAGE_SIZE]>,
    edits: Vec<(usize, Vec<u8>)>,
}
impl LifecyclePatch {
    fn image(&self) -> [u8; PAGE_SIZE] {
        let mut image = *self.base;
        for (at, bytes) in &self.edits {
            image[*at..*at + bytes.len()].copy_from_slice(bytes);
        }
        image
    }
}

/// Private images with fixed hash-head metadata and a bounded dirty-page cache.
/// Large page IDs do not create file holes: records append by changed-page count.
/// The caller owns the surrounding transaction directory.
///
/// 0.2-B: the scratch file (and, if needed, its transaction directory) is
/// created on the first spill. While no file exists every record is resident
/// in `cache` (records are only ever dropped from the cache by spilling them).
///
/// The on-disk bucket chains remain the authoritative, self-checking record
/// index. `offsets` is a transaction-local accelerator: every record this
/// instance has ever appended is mapped page → record offset, so a lookup is
/// one header read (still checksum-verified) and a miss needs no I/O at all,
/// instead of walking a bucket chain that grows with the dirty-page count.
/// Records are never removed, so the map can never be stale; it lives and
/// dies with this instance (staged generations keep it, rollback drops it).
pub struct PrivatePages {
    // Declaration order is deliberate: File closes before Cleanup removes it.
    file: Option<File>,
    /// Bucket chain heads (0 = empty). 0.2-G: sparse, so a transaction that
    /// dirties a few pages does not zero a 32 KiB table per file.
    heads: HashMap<usize, u64>,
    offsets: HashMap<u64, u64>,
    order: Vec<u64>,
    cache: BTreeMap<u64, Cached>,
    lifecycle: BTreeMap<u64, LifecyclePatch>,
    original_pages: u64,
    pages: u64,
    records: u64,
    clock: u64,
    initial_writes: u64,
    #[cfg_attr(not(test), allow(dead_code))]
    lsn_rewrite_writes: u64,
    #[cfg_attr(not(test), allow(dead_code))]
    lsn_patch_writes: u64,
    cleanup: Cleanup,
}

/// 0.2-F: transaction scratch directories this process may have created
/// (inserted before `create_dir_all`). Database open removes every scratch
/// directory, so a root absent from this set (and no overflow) cannot exist
/// and its retirement needs no filesystem probe. Bounded: past the limit the
/// set is abandoned and every retirement probes the filesystem again.
static SCRATCH_ROOTS: std::sync::Mutex<Option<std::collections::HashSet<PathBuf>>> =
    std::sync::Mutex::new(None);
static SCRATCH_ROOTS_OVERFLOW: std::sync::atomic::AtomicBool =
    std::sync::atomic::AtomicBool::new(false);
const SCRATCH_ROOTS_LIMIT: usize = 4096;

fn note_scratch_root(root: &Path) {
    let Ok(mut roots) = SCRATCH_ROOTS.lock() else {
        SCRATCH_ROOTS_OVERFLOW.store(true, std::sync::atomic::Ordering::SeqCst);
        return;
    };
    let roots = roots.get_or_insert_with(Default::default);
    if roots.len() >= SCRATCH_ROOTS_LIMIT {
        SCRATCH_ROOTS_OVERFLOW.store(true, std::sync::atomic::Ordering::SeqCst);
    }
    roots.insert(root.to_path_buf());
}

/// 0.2-F: `false` only when `root` was certainly never created by this
/// process (so it does not exist); `true` means "probe the filesystem".
/// Forgets `root`.
#[must_use]
pub fn take_scratch_root(root: &Path) -> bool {
    if SCRATCH_ROOTS_OVERFLOW.load(std::sync::atomic::Ordering::SeqCst) {
        return true;
    }
    match SCRATCH_ROOTS.lock() {
        Ok(mut roots) => roots.as_mut().is_some_and(|roots| roots.remove(root)),
        Err(_) => true,
    }
}

/// 0.2-G: evidence that every dirty image of a `PrivatePages` was produced
/// in this process and never left memory (no scratch file was ever created,
/// so no image was spilled to disk and read back). Only `PrivatePages`
/// can issue it.
pub struct ProducedInProcess(());

impl PrivatePages {
    /// 0.2-G: `Some` only while this transaction never spilled to scratch.
    #[must_use]
    pub fn produced_in_process(&self) -> Option<ProducedInProcess> {
        self.file.is_none().then_some(ProducedInProcess(()))
    }
    pub fn new(path: impl AsRef<Path>, original_pages: u64) -> Result<Self> {
        let path = path.as_ref().to_path_buf();
        Ok(Self {
            file: None,
            heads: HashMap::new(),
            offsets: HashMap::new(),
            order: Vec::new(),
            cache: BTreeMap::new(),
            lifecycle: BTreeMap::new(),
            original_pages,
            pages: original_pages,
            records: 0,
            clock: 0,
            initial_writes: 0,
            lsn_rewrite_writes: 0,
            lsn_patch_writes: 0,
            cleanup: Cleanup { path, armed: false },
        })
    }

    /// Scratch file, created (with its transaction directory) on first spill.
    fn spill_file(&mut self) -> Result<&mut File> {
        if self.file.is_none() {
            if let Some(parent) = self.cleanup.path.parent() {
                note_scratch_root(parent);
                fs::create_dir_all(parent)?;
            }
            let file = OpenOptions::new()
                .read(true)
                .write(true)
                .create_new(true)
                .open(&self.cleanup.path)?;
            self.cleanup.armed = true;
            self.file = Some(file);
            phobos_observability::event("private.scratch_files_created", 1);
        }
        Ok(self.file.as_mut().expect("scratch file"))
    }

    /// Scratch file for reading a spilled record; never creates one.
    fn spilled_file(&mut self) -> Result<&mut File> {
        self.file
            .as_mut()
            .ok_or_else(|| invalid("private record is neither resident nor spilled"))
    }

    /// True while the whole generation is resident and small enough to stay so.
    fn resident_only(&self) -> bool {
        self.file.is_none() && self.records <= RESIDENT_PREPARED_PAGES
    }

    #[must_use]
    pub fn page_count(&self) -> u64 {
        self.pages
    }
    #[cfg(feature = "db1-diagnostics")]
    pub(crate) fn original_page_count(&self) -> u64 {
        self.original_pages
    }
    #[must_use]
    pub fn dirty_page_count(&self) -> u64 {
        self.records + self.lifecycle.len() as u64
    }
    #[must_use]
    pub fn cached_pages(&self) -> usize {
        self.cache.len()
    }
    #[cfg(test)]
    fn file_len(&self) -> u64 {
        self.file
            .as_ref()
            .map_or(0, |file| file.metadata().unwrap().len())
    }
    #[cfg(test)]
    fn write_counters(&self) -> (u64, u64) {
        (self.initial_writes, self.lsn_rewrite_writes)
    }
    #[cfg(test)]
    fn patch_writes(&self) -> u64 {
        self.lsn_patch_writes
    }

    /// None means this transaction has not changed the page; read the base file.
    pub fn read(&mut self, page: u64) -> Result<Option<[u8; PAGE_SIZE]>> {
        if let Some(patch) = self.lifecycle.get(&page) {
            return Ok(Some(patch.image()));
        }
        self.clock = self.clock.wrapping_add(1);
        if let Some(cached) = self.cache.get_mut(&page) {
            cached.last_use = self.clock;
            return Ok(Some(*cached.bytes));
        }
        let Some(record) = self.find(page)? else {
            return Ok(None);
        };
        let bytes = self.read_data(record)?;
        self.make_room()?;
        self.cache.insert(
            page,
            Cached {
                record,
                bytes: Box::new(bytes),
                modified: false,
                last_use: self.clock,
            },
        );
        Ok(Some(bytes))
    }

    pub fn write(&mut self, page: u64, bytes: &[u8; PAGE_SIZE]) -> Result<()> {
        if self.lifecycle.remove(&page).is_some() {
            self.order.retain(|id| *id != page);
        }
        if page > self.pages {
            return Err(invalid("private page allocation is not contiguous"));
        }
        let next_pages = if page == self.pages {
            self.pages
                .checked_add(1)
                .ok_or_else(|| invalid("private page count overflow"))?
        } else {
            self.pages
        };
        self.clock = self.clock.wrapping_add(1);
        if let Some(cached) = self.cache.get_mut(&page) {
            cached.bytes.copy_from_slice(bytes);
            cached.modified = true;
            cached.last_use = self.clock;
            phobos_observability::event("private.page_writes", 1);
            return Ok(());
        }
        let existing = self.find(page)?;
        self.make_room()?;
        let (record, modified) = if let Some(record) = existing {
            (record, true)
        } else {
            let offset = self
                .records
                .checked_mul(RECORD_BYTES)
                .ok_or_else(|| invalid("private record offset overflow"))?;
            let bucket = bucket(page);
            let record = Record {
                offset,
                page,
                next: self.heads.get(&bucket).copied().unwrap_or(0),
                data_checksum: 0,
                persisted: false,
            };
            let head = offset
                .checked_add(1)
                .ok_or_else(|| invalid("private pointer overflow"))?;
            self.heads.insert(bucket, head);
            self.records += 1;
            if self.offsets.insert(page, offset).is_some() {
                return Err(invalid("private page record appended twice"));
            }
            self.order.push(page);
            phobos_observability::event("private.dirty_pages", 1);
            (record, true)
        };
        if next_pages != self.pages {
            phobos_observability::event("private.page_allocations", 1);
            self.pages = next_pages;
        }
        self.cache.insert(
            page,
            Cached {
                record,
                bytes: Box::new(*bytes),
                modified,
                last_use: self.clock,
            },
        );
        phobos_observability::event("private.page_writes", 1);
        Ok(())
    }

    /// Visit each distinct changed page exactly once. `allocated` identifies a
    /// page beyond the original file length. No data-file writes or fsync occur.
    /// Page numbers of every dirty image, from record headers only (no page
    /// data is read). Used to drop cache-resident hints before installation.
    pub fn dirty_pages(&mut self) -> Result<Vec<u64>> {
        Ok(self.order.clone())
    }

    pub(crate) fn write_lifecycle_patch(
        &mut self,
        page: u64,
        base: std::sync::Arc<[u8; PAGE_SIZE]>,
        edits: Vec<(usize, Vec<u8>)>,
    ) -> Result<bool> {
        if page >= self.original_pages
            || self.offsets.contains_key(&page)
            || self.lifecycle.contains_key(&page)
            || self.lifecycle.len() >= 1024
            || edits.iter().map(|(_, bytes)| bytes.len()).sum::<usize>() > 1024
        {
            return Ok(false);
        }
        if edits
            .iter()
            .any(|(at, bytes)| *at > PAGE_SIZE || bytes.len() > PAGE_SIZE - *at)
        {
            return Err(invalid("lifecycle patch exceeds page"));
        }
        self.lifecycle.insert(page, LifecyclePatch { base, edits });
        self.order.push(page);
        phobos_observability::event("private.lifecycle_patches", 1);
        Ok(true)
    }

    pub fn visit_dirty(
        &mut self,
        mut visitor: impl FnMut(u64, &[u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        for page in self.order.clone() {
            let allocated = page >= self.original_pages;
            if let Some(patch) = self.lifecycle.get(&page) {
                visitor(page, &patch.image(), false)?;
                continue;
            }
            // 0.2-G: a resident image is visited in place (no 8 KiB copy).
            if let Some(cached) = self.cache.get(&page) {
                visitor(page, &cached.bytes, allocated)?;
                continue;
            }
            let record = self.find(page)?.expect("dirty page record");
            let bytes = self.read_data(record)?;
            visitor(page, &bytes, allocated)?;
        }
        Ok(())
    }

    /// Rewrite bounded images during WAL preparation (for version/LSN stamping).
    /// A failed visitor leaves private state disposable; the owner must abort.
    pub fn rewrite_dirty(
        &mut self,
        mut visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        self.prepare_dirty(|page, bytes, allocated, append| {
            if !append {
                visitor(page, bytes, allocated)?;
            }
            Ok(())
        })
    }

    /// Stamp each current image, persist it, then append that exact image.
    /// Cache-resident pages therefore reach scratch only once; pages evicted
    /// before WAL assignment retain the bounded fallback rewrite.
    pub fn prepare_dirty(
        &mut self,
        mut visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool, bool) -> Result<()>,
    ) -> Result<()> {
        // Stamp and append each exact image, then keep just the changed bytes.
        // The receipt still authorizes installation; no data-file write occurs.
        for (&page, patch) in &mut self.lifecycle {
            let mut image = patch.image();
            visitor(page, &mut image, false, false)?;
            visitor(page, &mut image, false, true)?;
            patch.edits.clear();
            let mut at = 0;
            while at < PAGE_SIZE {
                if patch.base[at] == image[at] {
                    at += 1;
                    continue;
                }
                let start = at;
                while at < PAGE_SIZE && patch.base[at] != image[at] {
                    at += 1;
                }
                patch.edits.push((start, image[start..at].to_vec()));
            }
        }
        if self.resident_only() {
            // Every record is cached: stamp in place, no scratch I/O.
            phobos_observability::event("private.resident_prepared", 1);
            for page in self.order.clone() {
                if self.lifecycle.contains_key(&page) {
                    continue;
                }
                let allocated = page >= self.original_pages;
                let cached = self
                    .cache
                    .get_mut(&page)
                    .ok_or_else(|| invalid("resident private page missing"))?;
                visitor(page, &mut cached.bytes, allocated, false)?;
                cached.modified = true;
                visitor(page, &mut cached.bytes, allocated, true)?;
            }
            return Ok(());
        }
        for page in self.order.clone() {
            if self.lifecycle.contains_key(&page) {
                continue;
            }
            let (mut record, mut bytes, modified) = if let Some(cached) = self.cache.remove(&page) {
                (cached.record, *cached.bytes, cached.modified)
            } else {
                let record = self.find(page)?.expect("dirty page record");
                (record, self.read_data(record)?, false)
            };
            let allocated = page >= self.original_pages;
            let before = record.persisted.then_some(bytes);
            visitor(page, &mut bytes, allocated, false)?;
            if let Some(before) = before.filter(|_| !modified) {
                patch_record(self.spilled_file()?, &mut record, &before, &bytes)?;
                self.lsn_patch_writes += 1;
                phobos_observability::event("private.lsn_patch_writes", 1);
            } else {
                let rewrite = record.persisted;
                write_record(self.spill_file()?, &mut record, &bytes)?;
                phobos_observability::event(
                    if rewrite {
                        // A cache-resident data mutation still requires one
                        // full spill update. Final-LSN-only changes use the
                        // bounded header patch path above.
                        "private.overlay_rewrite_writes"
                    } else {
                        self.initial_writes += 1;
                        "private.overlay_initial_writes"
                    },
                    1,
                );
            }
            visitor(page, &mut bytes, allocated, true)?;
        }
        Ok(())
    }
    pub(crate) fn flush_for_visit(&mut self) -> Result<()> {
        // Legacy full freeze: always persists (creating the scratch file).
        self.spill_file()?;
        let file = self
            .file
            .as_mut()
            .ok_or_else(|| invalid("private record is neither resident nor spilled"))?;
        for cached in self.cache.values_mut() {
            if cached.modified {
                let initial = !cached.record.persisted;
                write_record(file, &mut cached.record, &cached.bytes)?;
                if initial {
                    self.initial_writes += 1;
                    phobos_observability::event("private.overlay_initial_writes", 1);
                }
                cached.modified = false;
            }
        }
        let expected_len = self
            .records
            .checked_mul(RECORD_BYTES)
            .ok_or_else(|| invalid("private spill length overflow"))?;
        if file.metadata()?.len() != expected_len {
            return Err(invalid(
                "private spill has a truncated or unexpected record",
            ));
        }
        self.cache.clear();
        Ok(())
    }

    /// Close the Windows handle before removing the owned scratch file.
    pub fn close(self) -> Result<()> {
        let _span = phobos_observability::span("scratch.retirement");
        let Self { file, cleanup, .. } = self;
        drop(file);
        cleanup.remove()
    }

    /// Close the Windows handle while leaving the disposable file for the
    /// database housekeeping worker to retire after commit acknowledgement.
    pub(crate) fn close_deferred(self) {
        let Self { file, cleanup, .. } = self;
        drop(file);
        cleanup.release();
    }

    fn make_room(&mut self) -> Result<()> {
        if self.cache.len() < CACHE_PAGES {
            return Ok(());
        }
        let key = *self
            .cache
            .iter()
            .min_by_key(|(_, value)| value.last_use)
            .expect("full cache")
            .0;
        let mut cached = self.cache.remove(&key).expect("chosen cache page");
        if cached.modified {
            let initial = !cached.record.persisted;
            if let Err(error) = self
                .spill_file()
                .and_then(|file| write_record(file, &mut cached.record, &cached.bytes))
            {
                // Keep the image resident: a failed spill loses nothing.
                self.cache.insert(key, cached);
                return Err(error);
            }
            if initial {
                self.initial_writes += 1;
                phobos_observability::event("private.overlay_initial_writes", 1);
            }
        }
        Ok(())
    }

    fn find(&mut self, page: u64) -> Result<Option<Record>> {
        if let Some(cached) = self.cache.get(&page) {
            return Ok(Some(cached.record));
        }
        // Every appended record is in `offsets`; a page absent from it has no
        // record, and a present one is read (and checksum-verified) directly.
        let Some(offset) = self.offsets.get(&page).copied() else {
            return Ok(None);
        };
        let record = self.read_header(
            offset
                .checked_add(1)
                .ok_or_else(|| invalid("private pointer overflow"))?,
        )?;
        if record.page != page {
            return Err(invalid("private record index does not match its header"));
        }
        Ok(Some(record))
    }

    /// Authoritative on-disk lookup through the bucket chain. Kept as the
    /// reference for tests; live lookups go through `offsets`.
    #[cfg(test)]
    fn find_via_chain(&mut self, page: u64) -> Result<Option<Record>> {
        let mut pointer = self.heads.get(&bucket(page)).copied().unwrap_or(0);
        while pointer != 0 {
            let record = self.read_header(pointer)?;
            if bucket(record.page) != bucket(page) {
                return Err(invalid("private spill hash chain crosses buckets"));
            }
            if record.page == page {
                return Ok(Some(record));
            }
            pointer = record.next;
        }
        Ok(None)
    }

    fn read_header(&mut self, pointer: u64) -> Result<Record> {
        let offset = pointer
            .checked_sub(1)
            .ok_or_else(|| invalid("null private record pointer"))?;
        if offset % RECORD_BYTES != 0 || offset / RECORD_BYTES >= self.records {
            return Err(invalid("private record pointer out of bounds"));
        }
        let file = self.spilled_file()?;
        file.seek(SeekFrom::Start(offset))?;
        let mut header = [0; HEADER];
        file.read_exact(&mut header)?;
        let expected = u32::from_le_bytes(header[20..24].try_into().expect("header checksum"));
        if checksum(&header[..20]) != expected {
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "private spill header checksum mismatch",
            ));
        }
        let page = u64::from_le_bytes(header[..8].try_into().expect("page"));
        let next = u64::from_le_bytes(header[8..16].try_into().expect("next"));
        // Chains point strictly backward, so corrupt cycles cannot hang a read.
        if next >= pointer || (next != 0 && (next - 1) % RECORD_BYTES != 0) || page >= self.pages {
            return Err(invalid("invalid private spill chain or page identity"));
        }
        Ok(Record {
            offset,
            page,
            next,
            data_checksum: u32::from_le_bytes(header[16..20].try_into().expect("data checksum")),
            persisted: true,
        })
    }

    fn read_data(&mut self, record: Record) -> Result<[u8; PAGE_SIZE]> {
        let file = self.spilled_file()?;
        file.seek(SeekFrom::Start(record.offset + HEADER as u64))?;
        let mut bytes = [0; PAGE_SIZE];
        file.read_exact(&mut bytes)?;
        if checksum(&bytes) != record.data_checksum {
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "private spill page checksum mismatch",
            ));
        }
        Ok(bytes)
    }
}

// Unlike a heap-page checksum, the scratch checksum covers every byte,
// including the embedded heap/index checksum and future page-LSN fields.
fn checksum(bytes: &[u8]) -> u32 {
    phobos_wal::page_checksum::scratch_checksum(bytes)
}

fn bucket(page: u64) -> usize {
    (page % BUCKETS as u64) as usize
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}
fn write_record(file: &mut File, record: &mut Record, bytes: &[u8; PAGE_SIZE]) -> Result<()> {
    record.data_checksum = checksum(bytes);
    let mut header = [0; HEADER];
    header[..8].copy_from_slice(&record.page.to_le_bytes());
    header[8..16].copy_from_slice(&record.next.to_le_bytes());
    header[16..20].copy_from_slice(&record.data_checksum.to_le_bytes());
    let crc = checksum(&header[..20]);
    header[20..24].copy_from_slice(&crc.to_le_bytes());
    file.seek(SeekFrom::Start(record.offset))?;
    file.write_all(&header)?;
    file.write_all(bytes)?;
    record.persisted = true;
    phobos_observability::event("private.spill_bytes", RECORD_BYTES);
    Ok(())
}

/// Persist a final-LSN/checksum change without rewriting an already spilled
/// 8 KiB image. Page stamping changes a small header range; the scratch record
/// checksum and the changed byte span are updated in place.
fn patch_record(
    file: &mut File,
    record: &mut Record,
    before: &[u8; PAGE_SIZE],
    after: &[u8; PAGE_SIZE],
) -> Result<()> {
    let first = before.iter().zip(after).position(|(a, b)| a != b);
    let last = before.iter().zip(after).rposition(|(a, b)| a != b);
    if let (Some(first), Some(last)) = (first, last) {
        file.seek(SeekFrom::Start(
            record.offset + HEADER as u64 + first as u64,
        ))?;
        file.write_all(&after[first..=last])?;
        phobos_observability::event("private.spill_bytes", (last - first + 1) as u64);
    }
    record.data_checksum = checksum(after);
    let mut header = [0; HEADER];
    header[..8].copy_from_slice(&record.page.to_le_bytes());
    header[8..16].copy_from_slice(&record.next.to_le_bytes());
    header[16..20].copy_from_slice(&record.data_checksum.to_le_bytes());
    let crc = checksum(&header[..20]);
    header[20..24].copy_from_slice(&crc.to_le_bytes());
    file.seek(SeekFrom::Start(record.offset))?;
    file.write_all(&header)?;
    phobos_observability::event("private.spill_bytes", HEADER as u64);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn k5_lifecycle_patches_stamp_reconstruct_and_convert_without_spill() {
        let scratch = path();
        let mut pages = PrivatePages::new(&scratch, 128).unwrap();
        let base = std::sync::Arc::new([0u8; PAGE_SIZE]);
        for id in 0..128 {
            assert!(
                pages
                    .write_lifecycle_patch(id, base.clone(), vec![(100, vec![id as u8])])
                    .unwrap()
            );
        }
        assert_eq!(pages.dirty_page_count(), 128);
        let mut appended = 0;
        pages
            .prepare_dirty(|id, bytes, allocated, append| {
                assert!(!allocated);
                if append {
                    assert_eq!(bytes[16], id as u8 + 1);
                    appended += 1;
                } else {
                    bytes[16] = id as u8 + 1;
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(appended, 128);
        assert!(!scratch.exists(), "patch-only publication must not spill");
        for _ in 0..2 {
            pages
                .visit_dirty(|id, bytes, _| {
                    assert_eq!(bytes[16], id as u8 + 1);
                    assert_eq!(bytes[100], id as u8);
                    Ok(())
                })
                .unwrap();
        }
        let mut converted = pages.read(3).unwrap().unwrap();
        converted[101] = 99;
        pages.write(3, &converted).unwrap();
        assert_eq!(pages.dirty_page_count(), 128);
        assert_eq!(pages.dirty_pages().unwrap().len(), 128);
        assert_eq!(pages.read(3).unwrap().unwrap()[101], 99);
        assert_eq!(base[16], 0, "immutable predecessor unchanged");
        pages.close().unwrap();
    }
    fn path() -> PathBuf {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "phobos-private-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed),
        ))
    }

    #[test]
    fn bounded_private_pages_spill_replace_visit_and_close() {
        let path = path();
        let mut pages = PrivatePages::new(&path, 0).unwrap();
        for id in 0..200 {
            pages.write(id, &[id as u8; PAGE_SIZE]).unwrap();
            assert!(pages.cached_pages() <= CACHE_PAGES);
        }
        for id in (0..200).rev() {
            assert_eq!(pages.read(id).unwrap().unwrap(), [id as u8; PAGE_SIZE]);
            pages.write(id, &[(id + 1) as u8; PAGE_SIZE]).unwrap();
        }
        assert_eq!(pages.page_count(), 200);
        assert_eq!(pages.dirty_page_count(), 200);
        let mut seen = std::collections::BTreeSet::new();
        pages
            .visit_dirty(|id, bytes, allocated| {
                assert!(allocated);
                assert_eq!(*bytes, [(id + 1) as u8; PAGE_SIZE]);
                assert!(seen.insert(id));
                Ok(())
            })
            .unwrap();
        assert_eq!(seen.len(), 200);
        assert_eq!(pages.file_len(), 200 * RECORD_BYTES);
        pages.close().unwrap();
        assert!(!path.exists());
    }

    #[test]
    fn d4_cached_page_is_stamped_before_its_first_overlay_write() {
        let path = path();
        let mut pages = PrivatePages::new(&path, 1).unwrap();
        pages.write(0, &[3; PAGE_SIZE]).unwrap();
        assert_eq!(pages.write_counters(), (0, 0));
        pages
            .prepare_dirty(|page, bytes, allocated, append| {
                assert_eq!(page, 0);
                assert!(!allocated);
                if append {
                    assert_eq!(bytes[16], 91);
                } else {
                    bytes[16] = 91;
                }
                Ok(())
            })
            .unwrap();
        // 0.2-B: a single-page generation stays resident (no overlay write).
        assert_eq!(pages.write_counters(), (0, 0));
        assert_eq!(pages.read(0).unwrap().unwrap()[16], 91);
        pages.close().unwrap();

        // Spilled generations keep the D4 property: each cached page is
        // stamped before its one and only overlay write.
        let path = super::tests::path();
        let count = RESIDENT_PREPARED_PAGES + 1;
        let mut pages = PrivatePages::new(&path, count).unwrap();
        for page in 0..count {
            pages.write(page, &[3; PAGE_SIZE]).unwrap();
        }
        assert_eq!(pages.write_counters(), (0, 0));
        pages
            .prepare_dirty(|_, bytes, allocated, append| {
                assert!(!allocated);
                if append {
                    assert_eq!(bytes[16], 91);
                } else {
                    bytes[16] = 91;
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(pages.write_counters(), (count, 0));
        eprintln!("D4_COUNTERS initial_overlay_writes={count} lsn_rewrite_writes=0");
        pages.cache.clear();
        assert_eq!(pages.read(0).unwrap().unwrap()[16], 91);
        pages.close().unwrap();
    }

    #[test]
    fn perf1_spilled_pages_patch_final_lsn_without_full_rewrite() {
        let path = path();
        let mut pages = PrivatePages::new(&path, 0).unwrap();
        let count = CACHE_PAGES as u64 * 3;
        for page in 0..count {
            pages.write(page, &[page as u8; PAGE_SIZE]).unwrap();
        }
        pages
            .prepare_dirty(|page, bytes, _, append| {
                if !append {
                    bytes[16..24].copy_from_slice(&(page + 1000).to_le_bytes());
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(pages.write_counters(), (count, 0));
        assert_eq!(pages.patch_writes(), count - CACHE_PAGES as u64);
        for page in 0..count {
            assert_eq!(
                u64::from_le_bytes(
                    pages.read(page).unwrap().unwrap()[16..24]
                        .try_into()
                        .unwrap()
                ),
                page + 1000
            );
        }
        pages.close().unwrap();
    }

    /// The in-memory page → offset index must agree with the authoritative
    /// on-disk bucket chains: first writes, lookups, rewrites of existing
    /// records (same offset, no new record), pages that collide into one
    /// bucket, misses, visiting, and cleanup.
    #[test]
    fn offset_index_matches_bucket_chains_for_colliding_pages_and_rewrites() {
        let path = path();
        // A large original length lets sparse page ids be written directly.
        let mut pages = PrivatePages::new(&path, 1 << 40).unwrap();
        // 300 pages that all hash to bucket 0: page ids 0, BUCKETS, 2*BUCKETS, ...
        let colliding: Vec<u64> = (0..300).map(|i| i * BUCKETS as u64).collect();
        let last = *colliding.last().unwrap();
        for id in &colliding {
            pages.write(*id, &[(id % 251) as u8; PAGE_SIZE]).unwrap();
            assert!(
                pages.find(*id).unwrap().is_some(),
                "lookup right after first write"
            );
        }
        assert_eq!(pages.dirty_page_count(), colliding.len() as u64);
        assert_eq!(pages.offsets.len(), colliding.len());
        pages.flush_for_visit().unwrap();
        pages.cache.clear();
        for id in &colliding {
            let fast = pages.find(*id).unwrap().expect("indexed record");
            let slow = pages.find_via_chain(*id).unwrap().expect("chained record");
            assert_eq!(fast.offset, slow.offset);
            assert_eq!(fast.page, slow.page);
            assert_eq!(fast.next, slow.next);
            assert_eq!(fast.data_checksum, slow.data_checksum);
            assert_eq!(fast.page, *id);
            assert_eq!(
                pages.read(*id).unwrap().unwrap(),
                [(id % 251) as u8; PAGE_SIZE]
            );
        }
        // A page never written: no record by either lookup, no I/O needed.
        assert!(pages.find(last + 1).unwrap().is_none());
        assert!(pages.find_via_chain(last + 1).unwrap().is_none());
        assert!(
            pages.read(last + 1).unwrap().is_none(),
            "not a private page"
        );
        // Rewrite existing records once evicted from the cache: the record is
        // updated in place (same offset, no new record) and both lookups agree.
        pages.cache.clear();
        let before_records = pages.dirty_page_count();
        let before_len = pages.file_len();
        for id in colliding.iter().step_by(7) {
            let old = pages.find(*id).unwrap().unwrap();
            pages.write(*id, &[0xAB; PAGE_SIZE]).unwrap();
            pages.flush_for_visit().unwrap();
            pages.cache.clear();
            let fast = pages.find(*id).unwrap().unwrap();
            let slow = pages.find_via_chain(*id).unwrap().unwrap();
            assert_eq!(fast.offset, old.offset);
            assert_eq!(fast.data_checksum, slow.data_checksum);
            assert_ne!(fast.data_checksum, old.data_checksum);
            assert_eq!(pages.read(*id).unwrap().unwrap(), [0xAB; PAGE_SIZE]);
        }
        assert_eq!(pages.dirty_page_count(), before_records);
        assert_eq!(pages.file_len(), before_len);
        assert_eq!(pages.offsets.len() as u64, before_records);
        // Every distinct page is visited exactly once with its latest image.
        let mut seen = std::collections::BTreeSet::new();
        pages
            .visit_dirty(|id, bytes, _| {
                assert!(seen.insert(id));
                let expected = if id % BUCKETS as u64 == 0 && (id / BUCKETS as u64) % 7 == 0 {
                    [0xAB; PAGE_SIZE]
                } else {
                    [(id % 251) as u8; PAGE_SIZE]
                };
                assert_eq!(*bytes, expected);
                Ok(())
            })
            .unwrap();
        assert_eq!(seen.len() as u64, before_records);
        // Rollback/cleanup drops the index with the scratch file.
        pages.close().unwrap();
        assert!(!path.exists());
    }

    #[test]
    fn large_page_ids_use_no_holes_and_callback_failure_cleans_up() {
        let path = path();
        {
            let mut pages = PrivatePages::new(&path, 1 << 40).unwrap();
            assert!(pages.read(42).unwrap().is_none());
            pages.write((1 << 40) - 1, &[7; PAGE_SIZE]).unwrap();
            pages
                .write((1 << 40) - 1 - BUCKETS as u64, &[8; PAGE_SIZE])
                .unwrap();
            // Allocation is logical until eviction/freeze; avoid one costly
            // set_len syscall per newly dirtied page.
            assert!(pages.file_len() <= 2 * RECORD_BYTES);
            pages.flush_for_visit().unwrap();
            assert_eq!(pages.file_len(), 2 * RECORD_BYTES);
            pages.cache.clear(); // Force collision-chain reads from the scratch file.
            assert!(
                pages
                    .read((1 << 40) - 1 - 2 * BUCKETS as u64)
                    .unwrap()
                    .is_none()
            );
            assert_eq!(pages.read((1 << 40) - 1).unwrap(), Some([7; PAGE_SIZE]));
            assert_eq!(
                pages.read((1 << 40) - 1 - BUCKETS as u64).unwrap(),
                Some([8; PAGE_SIZE])
            );
            assert!(pages.write((1 << 40) + 1, &[0; PAGE_SIZE]).is_err());
            assert!(
                pages
                    .visit_dirty(|_, _, allocated| {
                        assert!(!allocated);
                        Err(invalid("test cancellation"))
                    })
                    .is_err()
            );
        }
        assert!(!path.exists());
    }

    #[test]
    fn private_spill_rejects_corruption_truncation_and_cycles() {
        for corruption in ["header", "data", "embedded_checksum", "tail", "cycle"] {
            let path = path();
            let mut pages = PrivatePages::new(&path, 0).unwrap();
            pages.write(0, &[5; PAGE_SIZE]).unwrap();
            pages.flush_for_visit().unwrap();
            pages.cache.clear();
            let file = pages.file.as_mut().expect("flushed scratch file");
            match corruption {
                "header" => {
                    file.seek(SeekFrom::Start(0)).unwrap();
                    file.write_all(&[99]).unwrap();
                }
                "data" => {
                    file.seek(SeekFrom::Start(HEADER as u64)).unwrap();
                    file.write_all(&[99]).unwrap();
                }
                "embedded_checksum" => {
                    file.seek(SeekFrom::Start((HEADER + 32) as u64)).unwrap();
                    file.write_all(&[99]).unwrap();
                }
                "tail" => file.set_len(RECORD_BYTES - 1).unwrap(),
                _ => {
                    let mut record = Record {
                        offset: 0,
                        page: 0,
                        next: 1,
                        data_checksum: 0,
                        persisted: true,
                    };
                    write_record(file, &mut record, &[5; PAGE_SIZE]).unwrap();
                }
            }
            assert!(pages.visit_dirty(|_, _, _| Ok(())).is_err(), "{corruption}");
            pages.close().unwrap();
            assert!(!path.exists());
        }
    }

    #[test]
    fn small_prepared_generation_stays_resident_and_large_one_spills() {
        // 0.2-B: <= RESIDENT_PREPARED_PAGES changed pages never create the
        // scratch file (or its directory); stamping still reaches every page.
        let dir = path();
        let scratch = dir.join("table-1.heap");
        let mut pages = PrivatePages::new(&scratch, 4).unwrap();
        for page in 0..6 {
            pages.write(page, &[page as u8; PAGE_SIZE]).unwrap();
        }
        let mut stamped = Vec::new();
        pages
            .prepare_dirty(|page, bytes, _, append| {
                if !append {
                    bytes[0] = 0xEE;
                    stamped.push(page);
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(stamped, (0..6).collect::<Vec<_>>());
        assert!(!dir.exists(), "resident generation created scratch");
        for page in 0..6 {
            let image = pages.read(page).unwrap().unwrap();
            assert_eq!(image[0], 0xEE);
            assert_eq!(image[1], page as u8);
        }
        pages.close().unwrap();
        assert!(!dir.exists());

        let mut pages = PrivatePages::new(&scratch, 0).unwrap();
        for page in 0..(RESIDENT_PREPARED_PAGES + 1) {
            pages.write(page, &[3; PAGE_SIZE]).unwrap();
        }
        pages.prepare_dirty(|_, _, _, _| Ok(())).unwrap();
        assert!(scratch.exists());
        assert_eq!(
            pages.file_len(),
            (RESIDENT_PREPARED_PAGES + 1) * RECORD_BYTES
        );
        pages.cache.clear();
        assert_eq!(pages.read(0).unwrap(), Some([3; PAGE_SIZE]));
        pages.close().unwrap();
        assert!(!scratch.exists());
        fs::remove_dir_all(&dir).unwrap();
    }
}
