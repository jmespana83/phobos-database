//! Shared heap/index page I/O. Active private writes never reach the base file.
use crate::{PAGE_SIZE, private_pages::PrivatePages};
use phobos_error::{ErrorCode, PhobosError};
use std::{
    collections::VecDeque,
    fs::File,
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
};
type Result<T> = std::result::Result<T, PhobosError>;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RedoPhase {
    Stamp,
    Append,
}

/// In-memory provenance for the db1 isolation campaign. This is compiled only
/// when the diagnostic feature is selected and is never persisted.
#[cfg(feature = "db1-diagnostics")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PageProvenance {
    pub source: &'static str,
    pub owner: Option<u64>,
    pub pending_generations: Vec<u64>,
    pub page_lsn: u64,
}

struct PreparedPages {
    pages: PrivatePages,
    transaction: (u64, PathBuf),
    file: Option<phobos_wal::v2::FileId>,
}

pub struct PageIo {
    /// 0.2-G: shared so that statement readers (which never position or read
    /// it) clone an `Arc` instead of duplicating the descriptor.
    base: std::sync::Arc<File>,
    reader: Option<(crate::committed_pages::CommittedReader, u64)>,
    committed: Option<crate::committed_pages::CommittedFile>,
    private: Option<PrivatePages>,
    pending: VecDeque<PreparedPages>,
    transaction: Option<(u64, PathBuf)>,
    prepared: bool,
    prepared_file: Option<phobos_wal::v2::FileId>,
    defer_scratch_cleanup: bool,
    fenced: bool,
    unprotected_writes: bool,
    unforced_lsn: u64,
    durable_lsn: u64,
    /// 0.2-C: (database path as given, its canonical form). The database
    /// directory of a file never changes; resolving it once avoids a
    /// realpath (several syscalls) per private transaction.
    canonical_database: Option<(PathBuf, PathBuf)>,
}
impl std::fmt::Debug for PageIo {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("PageIo")
            .field("base", &self.base)
            .field("private", &self.private.is_some())
            .finish()
    }
}
impl PageIo {
    #[cfg(feature = "db1-diagnostics")]
    pub fn page_provenance(&mut self, page: u64) -> Result<PageProvenance> {
        self.available()?;
        let pending_generations = self
            .pending
            .iter()
            .map(|pending| pending.transaction.0)
            .collect::<Vec<_>>();
        if let Some(private) = &mut self.private {
            if let Some(bytes) = private.read(page)? {
                return Ok(PageProvenance {
                    source: if page >= private.original_page_count() {
                        "new-private-page"
                    } else {
                        "private-overlay"
                    },
                    owner: self.transaction.as_ref().map(|value| value.0),
                    pending_generations,
                    page_lsn: u64::from_le_bytes(bytes[40..48].try_into().expect("page lsn")),
                });
            }
        }
        for pending in self.pending.iter_mut().rev() {
            if let Some(bytes) = pending.pages.read(page)? {
                return Ok(PageProvenance {
                    source: "pending-generation",
                    owner: Some(pending.transaction.0),
                    pending_generations,
                    page_lsn: u64::from_le_bytes(bytes[40..48].try_into().expect("page lsn")),
                });
            }
        }
        let bytes = if let Some(committed) = &self.committed {
            committed.read(page)?
        } else {
            let mut bytes = [0; PAGE_SIZE];
            (&*self.base).seek(SeekFrom::Start(offset(page)?))?;
            (&*self.base).read_exact(&mut bytes)?;
            bytes
        };
        Ok(PageProvenance {
            source: if self.committed.is_some() {
                "committed-page-store"
            } else {
                "base-file"
            },
            owner: None,
            pending_generations,
            page_lsn: u64::from_le_bytes(bytes[40..48].try_into().expect("page lsn")),
        })
    }
    pub fn new_reader(base: File, reader: crate::committed_pages::CommittedReader) -> Result<Self> {
        Self::new_reader_shared(std::sync::Arc::new(base), reader)
    }
    /// 0.2-G: a statement reader over a shared base handle. A reader never
    /// positions, reads or writes its base handle (every page comes from the
    /// committed store and `len` uses the captured length), so sharing one
    /// open file description between concurrent readers is safe.
    pub fn new_reader_shared(
        base: std::sync::Arc<File>,
        reader: crate::committed_pages::CommittedReader,
    ) -> Result<Self> {
        let length = reader.len()?;
        let mut io = Self::new_shared(base);
        io.reader = Some((reader, length));
        Ok(io)
    }
    /// A committed reader bypasses both the active overlay and the pending WAL
    /// generation chain. Its lease keeps acknowledged dirty pages reachable.
    pub fn committed_reader(&self) -> Result<crate::committed_pages::CommittedReader> {
        self.available()?;
        self.committed
            .as_ref()
            .map(|file| file.reader())
            .ok_or_else(|| invalid("committed reader requires an attached store"))
    }
    /// Direct tuple references from a refreshed index may exceed the original
    /// scan bound. Read the latest committed image, never private/pending pages.
    /// The caller must still evaluate the tuple against its statement snapshot.
    pub(crate) fn read_statement_reference(&self, page: u64) -> Result<Option<[u8; PAGE_SIZE]>> {
        self.available()?;
        let (reader, _) = self
            .reader
            .as_ref()
            .ok_or_else(|| invalid("missing statement reader"))?;
        if page >= reader.len()? / PAGE_SIZE as u64 {
            return Ok(None);
        }
        reader.read(page).map(Some)
    }
    pub(crate) fn is_statement_reader(&self) -> bool {
        self.reader.is_some()
    }
    pub fn new(base: File) -> Self {
        Self::new_shared(std::sync::Arc::new(base))
    }
    fn new_shared(base: std::sync::Arc<File>) -> Self {
        Self {
            base,
            reader: None,
            committed: None,
            private: None,
            pending: VecDeque::new(),
            transaction: None,
            prepared: false,
            prepared_file: None,
            defer_scratch_cleanup: false,
            fenced: false,
            // An externally restored/copied file may still need its first force.
            unprotected_writes: true,
            unforced_lsn: 0,
            durable_lsn: 0,
            canonical_database: None,
        }
    }

    pub fn attach_committed(
        &mut self,
        store: &std::sync::Arc<crate::committed_pages::CommittedStore>,
        path: &Path,
        identity: phobos_wal::v2::FileId,
    ) -> Result<()> {
        self.ensure_writable()?;
        if self.committed.is_none() {
            self.sync_before_private()?;
            self.committed = Some(store.register(path, identity)?);
        }
        Ok(())
    }

    pub fn len(&self) -> Result<u64> {
        if let Some((reader, length)) = &self.reader {
            reader.check()?;
            return Ok(*length);
        }
        match &self.private {
            Some(private) => private
                .page_count()
                .checked_mul(PAGE_SIZE as u64)
                .ok_or_else(|| invalid("private file length overflow")),
            None if !self.pending.is_empty() => self
                .pending
                .back()
                .expect("pending pages")
                .pages
                .page_count()
                .checked_mul(PAGE_SIZE as u64)
                .ok_or_else(|| invalid("pending file length overflow")),
            None if self.committed.is_some() => {
                self.committed.as_ref().expect("committed file").len()
            }
            None => Ok(
                phobos_observability::measure("fs.file_metadata", || self.base.metadata())?.len(),
            ),
        }
    }
    pub fn is_empty(&self) -> Result<bool> {
        Ok(self.len()? == 0)
    }
    #[must_use]
    pub fn is_private(&self) -> bool {
        self.private.is_some()
    }
    #[must_use]
    pub fn uses_shared_cache(&self) -> bool {
        self.reader.is_some()
            || (self.committed.is_some() && self.private.is_none() && self.pending.is_empty())
    }
    pub fn private_owner(&self) -> Result<u64> {
        self.ensure_writable()?;
        self.transaction
            .as_ref()
            .map(|(id, _)| *id)
            .ok_or_else(|| invalid("version mutation requires a private transaction"))
    }

    /// The owner must flush existing committed buffers before entering private
    /// mode. This retains the same base handle and does not scan or copy it.
    pub fn begin_private(
        &mut self,
        scratch: impl AsRef<Path>,
        txn_id: u64,
        database: &Path,
    ) -> Result<()> {
        self.ensure_writable()?;
        if self.private.is_some() {
            return Err(invalid("private page I/O already active"));
        }
        self.sync_before_private()?;
        let len = self.len()?;
        if len % PAGE_SIZE as u64 != 0 {
            return Err(invalid("base file is not page aligned"));
        }
        if txn_id == 0 {
            return Err(invalid("private transaction ID is zero"));
        }
        let database = match &self.canonical_database {
            Some((given, canonical)) if given == database => canonical.clone(),
            _ => {
                let canonical = std::fs::canonicalize(database)?;
                self.canonical_database = Some((database.to_path_buf(), canonical.clone()));
                canonical
            }
        };
        self.private = Some(PrivatePages::new(scratch, len / PAGE_SIZE as u64)?);
        self.transaction = Some((txn_id, database));
        self.prepared = false;
        self.prepared_file = None;
        Ok(())
    }
    pub fn read(&mut self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        self.available()?;
        if let Some(private) = &mut self.private {
            if page >= private.page_count() {
                return Err(invalid("private page does not exist"));
            }
            if let Some(bytes) = private.read(page)? {
                return Ok(bytes);
            }
        }
        self.read_base(page)
    }

    pub(crate) fn write_lifecycle_patch(
        &mut self,
        page: u64,
        base: std::sync::Arc<[u8; PAGE_SIZE]>,
        edits: Vec<(usize, Vec<u8>)>,
    ) -> Result<bool> {
        self.ensure_writable()?;
        self.private
            .as_mut()
            .ok_or_else(|| invalid("lifecycle patch requires private owner"))?
            .write_lifecycle_patch(page, base, edits)
    }
    pub fn read_scan(&mut self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        self.available()?;
        if self.private.is_some() || !self.pending.is_empty() {
            return self.read(page);
        }
        if let Some((reader, length)) = &self.reader {
            if page >= length / PAGE_SIZE as u64 {
                return Err(invalid("page exceeds statement traversal bound"));
            }
            return reader.read_scan(page);
        }
        if let Some(committed) = &self.committed {
            return committed.reader().read_scan(page);
        }
        self.read_base(page)
    }
    /// 0.2-B zero-copy read of a committed image for statement readers and
    /// committed-only handles. `None` means private/pending state exists and
    /// the caller must use the copying `read`/`read_scan` path instead.
    pub fn read_shared(
        &mut self,
        page: u64,
        scan: bool,
    ) -> Result<Option<(std::sync::Arc<[u8; PAGE_SIZE]>, bool)>> {
        self.available()?;
        if self.private.is_some() || !self.pending.is_empty() {
            return Ok(None);
        }
        if let Some((reader, length)) = &self.reader {
            if page >= length / PAGE_SIZE as u64 {
                return Err(invalid("page exceeds statement traversal bound"));
            }
            return reader.read_shared(page, scan).map(Some);
        }
        if let Some(committed) = &self.committed {
            return committed.reader().read_shared(page, scan).map(Some);
        }
        Ok(None)
    }
    /// 0.2-B zero-copy variant of `read_statement_reference`: refreshes the
    /// committed image of `page` beyond the sequential traversal bound.
    pub(crate) fn read_statement_reference_shared(
        &self,
        page: u64,
    ) -> Result<Option<(std::sync::Arc<[u8; PAGE_SIZE]>, bool)>> {
        self.available()?;
        let (reader, _) = self
            .reader
            .as_ref()
            .ok_or_else(|| invalid("missing statement reader"))?;
        if page >= reader.len()? / PAGE_SIZE as u64 {
            return Ok(None);
        }
        reader.read_shared(page, false).map(Some)
    }
    /// 0.2-F: the image `read` would return, shared when it is a committed
    /// frame. The flag is true only for a committed-store image that passed
    /// the file's validator on entry (immutable since); private, pending and
    /// uncached base pages are copies reported as not validated.
    pub fn read_trusted(&mut self, page: u64) -> Result<(std::sync::Arc<[u8; PAGE_SIZE]>, bool)> {
        self.available()?;
        if let Some(private) = &mut self.private {
            if page >= private.page_count() {
                return Err(invalid("private page does not exist"));
            }
            if let Some(bytes) = private.read(page)? {
                return Ok((std::sync::Arc::new(bytes), false));
            }
        }
        if let Some((reader, length)) = &self.reader {
            if page >= length / PAGE_SIZE as u64 {
                return Err(invalid("page exceeds statement traversal bound"));
            }
            return reader.read_shared(page, false);
        }
        for pending in self.pending.iter_mut().rev() {
            if let Some(bytes) = pending.pages.read(page)? {
                return Ok((std::sync::Arc::new(bytes), false));
            }
        }
        if let Some(committed) = &self.committed {
            return committed.read_shared(page);
        }
        Ok((std::sync::Arc::new(self.read_base(page)?), false))
    }
    /// Bypass private state for rollback of derived heap free-space metadata.
    pub fn read_base(&mut self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        self.available()?;
        if let Some((reader, length)) = &self.reader {
            if page >= length / PAGE_SIZE as u64 {
                return Err(invalid("page exceeds statement traversal bound"));
            }
            return reader.read(page);
        }
        for pending in self.pending.iter_mut().rev() {
            if let Some(bytes) = pending.pages.read(page)? {
                return Ok(bytes);
            }
        }
        if let Some(committed) = &self.committed {
            return committed.read(page);
        }
        let mut bytes = [0; PAGE_SIZE];
        (&*self.base).seek(SeekFrom::Start(offset(page)?))?;
        (&*self.base).read_exact(&mut bytes)?;
        Ok(bytes)
    }
    pub fn write(&mut self, page: u64, bytes: &[u8; PAGE_SIZE]) -> Result<()> {
        self.ensure_writable()?;
        if let Some(private) = &mut self.private {
            return private.write(page, bytes);
        }
        if !self.pending.is_empty() {
            return Err(invalid(
                "pending pages require a successor private transaction",
            ));
        }
        if self.committed.is_some() {
            return Err(invalid(
                "committed store writes require private WAL publication",
            ));
        }
        self.unprotected_writes = true;
        (&*self.base).seek(SeekFrom::Start(offset(page)?))?;
        (&*self.base).write_all(bytes)?;
        Ok(())
    }
    pub fn sync_data(&mut self) -> Result<()> {
        self.available()?;
        if self.reader.is_some() {
            return Ok(());
        }
        // Private scratch is disposable. COMMIT must obtain WAL durability
        // before installing its images; synchronizing this base cannot commit it.
        if self.private.is_none() {
            self.check_flush_barrier()?;
            if let Some(committed) = &self.committed {
                committed.force()?;
            }
            phobos_observability::measure("fs.sync_data", || self.base.sync_data())?;
            self.unprotected_writes = false;
            self.unforced_lsn = 0;
        }
        Ok(())
    }

    /// BEGIN drains buffer frames first, but does not force already WAL-protected
    /// committed pages. Previously unprotected writes still require a force.
    pub fn sync_before_private(&mut self) -> Result<()> {
        self.available()?;
        self.check_flush_barrier()?;
        if self.unprotected_writes {
            self.sync_data()?;
        }
        Ok(())
    }
    fn check_flush_barrier(&self) -> Result<()> {
        if self.unforced_lsn > self.durable_lsn {
            return Err(invalid("page flush would outrun durable WAL"));
        }
        Ok(())
    }
    /// Force covered committed pages before the engine can discard their WAL.
    pub fn force_committed(&mut self) -> Result<()> {
        self.ensure_writable()?;
        if self.private.is_some() || !self.pending.is_empty() {
            return Err(invalid("cannot force an active private transaction"));
        }
        self.check_flush_barrier()?;
        if let Some(committed) = &self.committed {
            committed.force()?;
            self.unprotected_writes = false;
            self.unforced_lsn = 0;
            return Ok(());
        }
        if !self.unprotected_writes && self.unforced_lsn == 0 {
            return Ok(());
        }
        self.fenced = true;
        phobos_observability::certification_crash("v2_before_dirty_page_force");
        phobos_observability::measure("storage.wal_page_fsync", || self.base.sync_all())?;
        phobos_observability::certification_crash("v2_after_dirty_page_force");
        self.unprotected_writes = false;
        self.unforced_lsn = 0;
        self.fenced = false;
        Ok(())
    }
    #[must_use]
    pub fn unforced_lsn(&self) -> u64 {
        self.unforced_lsn
    }
    pub fn visit_private(
        &mut self,
        visitor: impl FnMut(u64, &[u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        self.available()?;
        self.private
            .as_mut()
            .ok_or_else(|| invalid("private page I/O is inactive"))?
            .visit_dirty(visitor)
    }

    pub fn private_page_count(&self) -> Result<u64> {
        self.available()?;
        self.private
            .as_ref()
            .map(PrivatePages::dirty_page_count)
            .ok_or_else(|| invalid("private page I/O is inactive"))
    }
    /// The owner must discard private buffer frames and restore its derived
    /// metadata before allowing further queries. Base bytes remain unchanged.
    pub fn rollback_private(&mut self) -> Result<()> {
        self.available()?;
        self.transaction = None;
        self.prepared = false;
        self.prepared_file = None;
        self.private
            .take()
            .ok_or_else(|| invalid("private page I/O is inactive"))?
            .close()
    }

    /// Freeze images after the caller has appended every image to its WAL. A
    /// failed visitor leaves the transaction unprepared and must abort its WAL.
    pub fn prepare_private(
        &mut self,
        visitor: impl FnMut(u64, &[u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        if self.prepared {
            return Err(invalid("private pages already prepared"));
        }
        self.visit_private(visitor)?;
        self.private
            .as_mut()
            .expect("visited private pages")
            .flush_for_visit()?;
        self.prepared = true;
        Ok(())
    }

    /// Freeze an independent-preparation generation without serializing its
    /// cache-resident pages. The exclusive WAL owner stamps and persists them
    /// later through `prepare_pending_redo_phased`.
    pub fn prepare_private_deferred(
        &mut self,
        visitor: impl FnMut(u64, &[u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        if self.prepared {
            return Err(invalid("private pages already prepared"));
        }
        self.visit_private(visitor)?;
        self.prepared = true;
        Ok(())
    }

    pub fn prepare_private_redo(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        self.ensure_writable()?;
        if !file.is_paged() {
            return Err(invalid("private redo requires a paged file"));
        }
        self.private
            .as_mut()
            .ok_or_else(|| invalid("private page I/O is inactive"))?
            .rewrite_dirty(visitor)?;
        self.prepared_file = Some(file);
        self.prepared = true;
        Ok(())
    }

    pub fn prepare_private_redo_phased(
        &mut self,
        file: phobos_wal::v2::FileId,
        mut visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool, RedoPhase) -> Result<()>,
    ) -> Result<()> {
        self.ensure_writable()?;
        if !file.is_paged() {
            return Err(invalid("private redo requires a paged file"));
        }
        self.private
            .as_mut()
            .ok_or_else(|| invalid("private page I/O is inactive"))?
            .prepare_dirty(|page, bytes, allocated, append| {
                visitor(
                    page,
                    bytes,
                    allocated,
                    if append {
                        RedoPhase::Append
                    } else {
                        RedoPhase::Stamp
                    },
                )
            })?;
        self.prepared_file = Some(file);
        self.prepared = true;
        Ok(())
    }

    /// 0.2-D: like `prepare_private_redo_phased`, but the Append phase of a
    /// page that existed before this transaction also receives its base: the
    /// image this change was made to (newest pending generation, else the
    /// committed image, else the base file). The WAL writer decides whether a
    /// compact delta against it is safe.
    pub fn prepare_private_redo_based(
        &mut self,
        file: phobos_wal::v2::FileId,
        mut visitor: impl FnMut(
            u64,
            &mut [u8; PAGE_SIZE],
            Option<&[u8; PAGE_SIZE]>,
            bool,
            RedoPhase,
        ) -> Result<()>,
    ) -> Result<()> {
        self.ensure_writable()?;
        if !file.is_paged() {
            return Err(invalid("private redo requires a paged file"));
        }
        let Self {
            private,
            pending,
            committed,
            base,
            ..
        } = self;
        private
            .as_mut()
            .ok_or_else(|| invalid("private page I/O is inactive"))?
            .prepare_dirty(|page, bytes, allocated, append| {
                if append && !allocated {
                    let prior = predecessor(pending.iter_mut().rev(), committed, base, page)?;
                    visitor(page, bytes, Some(&prior), allocated, RedoPhase::Append)
                } else {
                    visitor(
                        page,
                        bytes,
                        None,
                        allocated,
                        if append {
                            RedoPhase::Append
                        } else {
                            RedoPhase::Stamp
                        },
                    )
                }
            })?;
        self.prepared_file = Some(file);
        self.prepared = true;
        Ok(())
    }

    /// 0.2-D: `prepare_pending_redo_phased` with bases from older generations.
    pub fn prepare_pending_redo_based(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        mut visitor: impl FnMut(
            u64,
            &mut [u8; PAGE_SIZE],
            Option<&[u8; PAGE_SIZE]>,
            bool,
            RedoPhase,
        ) -> Result<()>,
    ) -> Result<()> {
        self.available()?;
        if !file.is_paged() {
            return Err(invalid("pending redo requires a paged file"));
        }
        let Self {
            pending,
            committed,
            base,
            ..
        } = self;
        let generations = pending.make_contiguous();
        let index = generations
            .iter()
            .position(|pending| pending.transaction.0 == transaction)
            .ok_or_else(|| invalid("pending redo generation missing"))?;
        let (older, rest) = generations.split_at_mut(index);
        let target = &mut rest[0];
        if target.file.is_some() {
            return Err(invalid("pending redo generation already logged"));
        }
        target
            .pages
            .prepare_dirty(|page, bytes, allocated, append| {
                if append && !allocated {
                    let prior = predecessor(older.iter_mut().rev(), committed, base, page)?;
                    visitor(page, bytes, Some(&prior), allocated, RedoPhase::Append)
                } else {
                    visitor(
                        page,
                        bytes,
                        None,
                        allocated,
                        if append {
                            RedoPhase::Append
                        } else {
                            RedoPhase::Stamp
                        },
                    )
                }
            })?;
        target.file = Some(file);
        Ok(())
    }

    /// Read only changed original pages for restoring derived in-memory state.
    /// Appended private pages have no base image and are excluded.
    pub fn visit_original_private(
        &mut self,
        mut visitor: impl FnMut(u64, &[u8; PAGE_SIZE]) -> Result<()>,
    ) -> Result<()> {
        self.available()?;
        let mut base: &File = &self.base;
        let pending = &mut self.pending;
        let committed = &self.committed;
        self.private
            .as_mut()
            .ok_or_else(|| invalid("private page I/O is inactive"))?
            .visit_dirty(|page, _, allocated| {
                if !allocated {
                    for predecessor in pending.iter_mut().rev() {
                        if let Some(bytes) = predecessor.pages.read(page)? {
                            return visitor(page, &bytes);
                        }
                    }
                    if let Some(committed) = committed {
                        return visitor(page, &committed.read(page)?);
                    }
                    let mut bytes = [0; PAGE_SIZE];
                    base.seek(SeekFrom::Start(offset(page)?))?;
                    base.read_exact(&mut bytes)?;
                    visitor(page, &bytes)?;
                }
                Ok(())
            })
    }

    /// Transfer frozen images to the ordered predecessor chain. Only an engine
    /// batch owner may expose this state to successor writers; public readers
    /// must remain excluded until the complete batch is durable and installed.
    pub fn stage_private(&mut self) -> Result<()> {
        self.available()?;
        if !self.prepared {
            return Err(invalid("only prepared pages can enter the pending chain"));
        }
        self.pending.push_back(PreparedPages {
            pages: self.private.take().expect("prepared private pages"),
            transaction: self.transaction.take().expect("prepared transaction"),
            file: self.prepared_file.take(),
        });
        self.prepared = false;
        Ok(())
    }

    /// Bind an unlogged frozen generation to its exact WAL images under the
    /// exclusive writer owner. Successors cannot mutate this generation.
    pub fn prepare_pending_redo(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool) -> Result<()>,
    ) -> Result<()> {
        self.available()?;
        if !file.is_paged() {
            return Err(invalid("pending redo requires a paged file"));
        }
        let pending = self
            .pending
            .iter_mut()
            .find(|pending| pending.transaction.0 == transaction)
            .ok_or_else(|| invalid("pending redo generation missing"))?;
        if pending.file.is_some() {
            return Err(invalid("pending redo generation already logged"));
        }
        pending.pages.rewrite_dirty(visitor)?;
        pending.file = Some(file);
        Ok(())
    }

    pub fn prepare_pending_redo_phased(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        mut visitor: impl FnMut(u64, &mut [u8; PAGE_SIZE], bool, RedoPhase) -> Result<()>,
    ) -> Result<()> {
        self.available()?;
        if !file.is_paged() {
            return Err(invalid("pending redo requires a paged file"));
        }
        let pending = self
            .pending
            .iter_mut()
            .find(|pending| pending.transaction.0 == transaction)
            .ok_or_else(|| invalid("pending redo generation missing"))?;
        if pending.file.is_some() {
            return Err(invalid("pending redo generation already logged"));
        }
        pending
            .pages
            .prepare_dirty(|page, bytes, allocated, append| {
                visitor(
                    page,
                    bytes,
                    allocated,
                    if append {
                        RedoPhase::Append
                    } else {
                        RedoPhase::Stamp
                    },
                )
            })?;
        pending.file = Some(file);
        Ok(())
    }

    /// Publish one predecessor in order, leaving successors' images owned and
    /// readable. Installation never replaces a newer generation with old data.
    pub fn install_pending(&mut self, receipt: &phobos_wal::v2::DurableCommit) -> Result<()> {
        self.available()?;
        if self.pending.front().is_none_or(|pending| {
            pending.transaction.0 != receipt.mvcc_id().unwrap_or(receipt.txn_id())
                || pending.transaction.1 != receipt.directory()
        }) {
            return Err(invalid("pending installation is out of order"));
        }
        // A successor may have executed but not yet appended its redo. Its
        // owner must first drain private buffer frames; preserve its scratch and
        // rollback identity while installing earlier, now-durable generations.
        let successor = (
            self.private.take(),
            self.transaction.take(),
            self.prepared,
            self.prepared_file.take(),
        );
        let pending = self.pending.pop_front().expect("matched pending pages");
        self.private = Some(pending.pages);
        self.transaction = Some(pending.transaction);
        self.prepared_file = pending.file;
        self.prepared = true;
        self.install_private(receipt)?;
        (
            self.private,
            self.transaction,
            self.prepared,
            self.prepared_file,
        ) = successor;
        Ok(())
    }

    /// The MVCC publication owner coordinates retirement of the shared
    /// transaction directory after every heap/index handle has closed.
    pub fn defer_private_cleanup(&mut self) -> Result<()> {
        self.available()?;
        if self.pending.is_empty() {
            return Err(invalid("no pending private generation to retire"));
        }
        self.defer_scratch_cleanup = true;
        Ok(())
    }

    /// Pages the active private transaction would install (empty when none).
    pub fn private_dirty_pages(&mut self) -> Result<Vec<u64>> {
        match self.private.as_mut() {
            Some(private) => private.dirty_pages(),
            None => Ok(Vec::new()),
        }
    }

    /// Install only frozen images authorized by the same database/transaction's
    /// synchronized WAL receipt. Any installation error fences this handle;
    /// recovery is required and rollback must not undo a durable transaction.
    pub fn install_private(&mut self, receipt: &phobos_wal::v2::DurableCommit) -> Result<()> {
        self.available()?;
        let (id, directory) = self
            .transaction
            .as_ref()
            .ok_or_else(|| invalid("private page I/O is inactive"))?;
        if !self.prepared
            || *id != receipt.mvcc_id().unwrap_or(receipt.txn_id())
            || directory != receipt.directory()
        {
            return Err(invalid(
                "private installation lacks matching durable WAL receipt",
            ));
        }
        if receipt.page_format() >= 2 && self.prepared_file.is_none() {
            return Err(invalid(
                "page-LSN installation lacks a prepared file identity",
            ));
        }
        // Fence before the first base write. Clear only after all writes, sync,
        // and scratch-handle cleanup succeed.
        self.fenced = true;
        self.durable_lsn = self.durable_lsn.max(receipt.lsn());
        let file = self.prepared_file;
        let produced = self
            .private
            .as_ref()
            .and_then(PrivatePages::produced_in_process);
        let unforced = &mut self.unforced_lsn;
        let mut base: &File = &self.base;
        let committed = &self.committed;
        self.private
            .as_mut()
            .expect("active private pages")
            .visit_dirty(|page, bytes, _| {
                let mut verified = None;
                if receipt.page_format() >= 2 {
                    phobos_wal::v2::page_format::validate_capability(
                        receipt.page_format(),
                        file.expect("prepared file"),
                        bytes,
                    )?;
                    // 0.2-G: one complete checksum/identity/LSN verification,
                    // carried to the store as a proof on the same borrow.
                    let proof = match &produced {
                        Some(evidence) => crate::committed_pages::VerifiedImage::verify_produced(
                            file.expect("prepared file"),
                            page,
                            bytes,
                            evidence,
                        )?,
                        None => crate::committed_pages::VerifiedImage::verify(
                            file.expect("prepared file"),
                            page,
                            bytes,
                        )?,
                    };
                    let lsn = proof.lsn();
                    if lsn == 0 || lsn > receipt.lsn() {
                        return Err(invalid("base-page write would outrun durable WAL"));
                    }
                    *unforced = (*unforced).max(lsn);
                    verified = Some(proof);
                }
                if let Some(committed) = committed {
                    match verified {
                        Some(proof) => committed.publish_verified(proof, receipt)?,
                        None => committed.publish(page, bytes, receipt)?,
                    }
                    if receipt.page_format() == 4
                        && matches!(file, Some(phobos_wal::v2::FileId::Index(_)))
                    {
                        phobos_observability::synchronization_boundary(
                            "c6_index_page_published",
                            receipt.directory(),
                        );
                    }
                    phobos_observability::event("private.installed_pages", 1);
                    if matches!(file, Some(phobos_wal::v2::FileId::Heap(_))) {
                        phobos_observability::event("heap.pages_installed", 1);
                        phobos_observability::synchronization_boundary(
                            "k5_heap_installed",
                            receipt.directory(),
                        );
                    }
                    phobos_observability::event("private.installed_bytes", PAGE_SIZE as u64);
                    phobos_observability::certification_crash("during_installation");
                    return Ok(());
                }
                let offset = offset(page)?;
                if offset > base.metadata()?.len() {
                    return Err(invalid("private install would create a page gap"));
                }
                base.seek(SeekFrom::Start(offset))?;
                phobos_observability::certification_crash("v2_before_dirty_page_write");
                base.write_all(bytes)?;
                phobos_observability::certification_crash("v2_after_dirty_page_write");
                phobos_observability::event("private.installed_pages", 1);
                phobos_observability::event("private.installed_bytes", PAGE_SIZE as u64);
                phobos_observability::certification_crash("during_installation");
                Ok(())
            })?;
        if receipt.page_format() == 1 {
            phobos_observability::measure("private.install_fsync", || base.sync_all())?;
            self.unforced_lsn = 0;
        }
        self.unprotected_writes = false;
        let private = self.private.take().expect("installed private pages");
        if self.defer_scratch_cleanup {
            private.close_deferred();
        } else {
            private.close()?;
        }
        self.transaction = None;
        self.prepared = false;
        self.prepared_file = None;
        self.defer_scratch_cleanup = false;
        self.fenced = false;
        Ok(())
    }

    fn available(&self) -> Result<()> {
        if let Some((reader, _)) = &self.reader {
            reader.check()?;
        }
        if let Some(committed) = &self.committed {
            committed.check()?;
        }
        if self.fenced {
            Err(invalid("page I/O fenced; close and recover database"))
        } else {
            Ok(())
        }
    }
    pub fn ensure_writable(&self) -> Result<()> {
        self.available()?;
        if self.reader.is_some() {
            Err(invalid(
                "statement page reader cannot mutate committed state",
            ))
        } else if self.prepared {
            Err(invalid("prepared private pages cannot be changed"))
        } else {
            Ok(())
        }
    }
    pub fn ensure_readable(&self) -> Result<()> {
        self.available()
    }
}
/// The image a page change was made to: newest older pending generation,
/// else the committed store, else the base file.
fn predecessor<'a>(
    generations: impl Iterator<Item = &'a mut PreparedPages>,
    committed: &Option<crate::committed_pages::CommittedFile>,
    base: &File,
    page: u64,
) -> Result<[u8; PAGE_SIZE]> {
    for generation in generations {
        if let Some(bytes) = generation.pages.read(page)? {
            return Ok(bytes);
        }
    }
    if let Some(committed) = committed {
        return committed.read(page);
    }
    let mut bytes = [0; PAGE_SIZE];
    let mut base = base;
    base.seek(SeekFrom::Start(offset(page)?))?;
    base.read_exact(&mut bytes)?;
    Ok(bytes)
}

fn offset(page: u64) -> Result<u64> {
    page.checked_mul(PAGE_SIZE as u64)
        .ok_or_else(|| invalid("page offset overflow"))
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}

#[cfg(test)]
mod tests {
    #[test]
    fn stable_owner_and_page_lsn_authorize_versioned_publication() {
        use crate::{
            SlottedPage,
            committed_pages::{CommittedStore, FlushConfig},
        };
        use phobos_wal::v2::{FileId, PageAction, Wal};
        let dir = std::env::temp_dir().join(format!(
            "phobos-mapped-pages-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut wal = Wal::create_with_versioned_heap(&dir).unwrap();
        let dir = fs::canonicalize(dir).unwrap();
        let identity = FileId::Heap(1);
        let path = dir.join(identity.name());
        fs::write(&path, []).unwrap();
        let store = CommittedStore::new(&dir, FlushConfig::default()).unwrap();
        let mut io = PageIo::new(
            OpenOptions::new()
                .read(true)
                .write(true)
                .open(&path)
                .unwrap(),
        );
        io.attach_committed(&store, &path, identity).unwrap();
        let reader = io.committed_reader().unwrap();
        // WAL chains 1,2 publish stable transactions 20,10. Chain identity must
        // never authorize a different private owner, even with matching bytes.
        for (page, stable) in [20, 10].into_iter().enumerate() {
            let chain = wal.begin_mvcc(stable).unwrap();
            assert_ne!(chain, stable);
            let scratch = dir.join(format!("private-{stable}"));
            io.begin_private(&scratch, stable, &dir).unwrap();
            io.write(
                page as u64,
                &SlottedPage::new_versioned(page as u64).to_bytes(),
            )
            .unwrap();
            io.prepare_private_redo(identity, |page, bytes, _| {
                wal.append_page(PageAction::HeapUpdate, identity, page, bytes)?;
                Ok(())
            })
            .unwrap();
            io.stage_private().unwrap();
            assert_eq!(reader.len().unwrap(), page as u64 * PAGE_SIZE as u64);
            let receipt = wal.commit().unwrap();
            let wrong_path = dir.join(format!("wrong-{stable}"));
            fs::write(&wrong_path, []).unwrap();
            let mut wrong = PageIo::new(
                OpenOptions::new()
                    .read(true)
                    .write(true)
                    .open(&wrong_path)
                    .unwrap(),
            );
            wrong
                .begin_private(dir.join(format!("wrong-private-{stable}")), chain, &dir)
                .unwrap();
            wrong
                .prepare_private_redo(identity, |_, _, _| Ok(()))
                .unwrap();
            assert!(wrong.install_private(&receipt).is_err());
            wrong.rollback_private().unwrap();
            io.install_pending(&receipt).unwrap();
            assert_eq!(
                reader.read(page as u64).unwrap(),
                io.read(page as u64).unwrap()
            );
            assert!(!scratch.exists());
            let image = io.read(page as u64).unwrap();
            let lsn = phobos_wal::v2::page_format::lsn(identity, page as u64, &image).unwrap();
            assert!(lsn > 0 && lsn <= receipt.lsn());
            assert_eq!(&image[4..6], &3u16.to_le_bytes());
        }
        io.force_committed().unwrap();
        assert_eq!(fs::metadata(&path).unwrap().len(), 2 * PAGE_SIZE as u64);
        assert_eq!(store.stats().unwrap().pages_flushed, 2);
        drop(io);
        assert_eq!(reader.len().unwrap(), 2 * PAGE_SIZE as u64);
        assert_eq!(reader.read(0).unwrap()[4..6], 3u16.to_le_bytes());
        drop(reader);
        drop(store);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
    use super::*;
    use std::fs::{self, OpenOptions};

    fn lsn_database() -> (PathBuf, phobos_wal::v2::Wal, PageIo) {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let dir = std::env::temp_dir().join(format!(
            "phobos-page-lsn-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        ));
        let wal = phobos_wal::v2::Wal::create_with_page_lsn(&dir).unwrap();
        let path = dir.join(phobos_wal::v2::FileId::Heap(1).name());
        fs::write(&path, crate::SlottedPage::new(0).to_bytes()).unwrap();
        let io = PageIo::new(
            OpenOptions::new()
                .read(true)
                .write(true)
                .open(path)
                .unwrap(),
        );
        (dir, wal, io)
    }
    fn prepare_lsn(
        io: &mut PageIo,
        wal: &mut phobos_wal::v2::Wal,
        dir: &Path,
        value: &[u8],
    ) -> phobos_wal::v2::DurableCommit {
        use phobos_wal::v2::{FileId, PageAction};
        let id = wal.begin().unwrap();
        io.begin_private(dir.join(format!("private-{id}")), id, dir)
            .unwrap();
        let mut page = crate::SlottedPage::from_bytes(io.read(0).unwrap()).unwrap();
        page.insert(value).unwrap();
        io.write(0, &page.to_bytes()).unwrap();
        io.prepare_private_redo(FileId::Heap(1), |page, bytes, _| {
            wal.append_page(PageAction::HeapUpdate, FileId::Heap(1), page, bytes)?;
            Ok(())
        })
        .unwrap();
        wal.commit().unwrap()
    }

    #[test]
    fn page_lsn_barrier_defers_force_across_begin_and_survives_checkpoint() {
        use phobos_wal::v2::{FileId, Wal, inspect};
        let (dir, mut wal, mut io) = lsn_database();
        let receipt = prepare_lsn(&mut io, &mut wal, &dir, b"first");
        io.install_private(&receipt).unwrap();
        let pending = io.unforced_lsn();
        assert!(pending > 0 && pending < receipt.lsn());
        assert_eq!(
            crate::SlottedPage::from_bytes(io.read(0).unwrap())
                .unwrap()
                .page_lsn(),
            pending
        );
        let id = wal.begin().unwrap();
        io.begin_private(dir.join("rollback"), id, &dir).unwrap();
        assert_eq!(io.unforced_lsn(), pending, "BEGIN forced protected pages");
        wal.abort().unwrap();
        io.rollback_private().unwrap();
        io.durable_lsn = pending - 1;
        assert!(
            io.force_committed().is_err(),
            "flush crossed the WAL barrier"
        );
        assert_eq!(io.unforced_lsn(), pending);
        io.durable_lsn = receipt.lsn();
        io.force_committed().unwrap();
        assert_eq!(io.unforced_lsn(), 0);
        let second = prepare_lsn(&mut io, &mut wal, &dir, b"second");
        io.install_private(&second).unwrap();
        let expected = io.read(0).unwrap();
        drop(io);
        drop(wal);
        // Multiple retained commits encounter a valid newer page. Recovery must
        // force even skipped images before retaining only the capability anchor.
        for _ in 0..2 {
            drop(Wal::recover(&dir).unwrap());
            assert_eq!(
                fs::read(dir.join(FileId::Heap(1).name())).unwrap(),
                expected
            );
            assert_eq!(inspect(dir.join("phobos.wal")).unwrap().page_format, 2);
            // Anchor flags: page format 2, plus the 0.2-D compact-redo bit,
            // plus the 0.2-E preallocated-segment bit in Mode E.
            let prealloc = if phobos_wal::v2::DurabilityMode::configured()
                == phobos_wal::v2::DurabilityMode::WriteThrough
            {
                0x20
            } else {
                0
            };
            assert_eq!(
                fs::read(dir.join("phobos.wal")).unwrap()[7],
                1 | 0x10 | prealloc
            );
        }
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn future_page_lsn_never_reaches_base_and_durable_redo_repairs_it() {
        use phobos_wal::v2::{FileId, Wal, page_format};
        let (dir, mut wal, mut io) = lsn_database();
        let before = io.read(0).unwrap();
        let receipt = prepare_lsn(&mut io, &mut wal, &dir, b"committed");
        // Deliberate checksum-valid scratch damage after prepare: the WAL image
        // remains correct, but the attempted base image has an ineligible LSN.
        io.private
            .as_mut()
            .unwrap()
            .rewrite_dirty(|page, bytes, _| {
                page_format::stamp(FileId::Heap(1), page, bytes, receipt.lsn() + 1)
            })
            .unwrap();
        assert!(io.install_private(&receipt).is_err());
        assert!(io.read(0).is_err());
        assert_eq!(fs::read(dir.join(FileId::Heap(1).name())).unwrap(), before);
        drop(io);
        drop(wal);
        for _ in 0..2 {
            drop(Wal::recover(&dir).unwrap());
            let bytes = fs::read(dir.join(FileId::Heap(1).name()))
                .unwrap()
                .try_into()
                .unwrap();
            let page = crate::SlottedPage::from_bytes(bytes).unwrap();
            assert_eq!(page.get(0).unwrap(), Some(b"committed".as_slice()));
            assert!(page.page_lsn() < receipt.lsn());
        }
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn installation_requires_frozen_matching_receipt_and_fences_on_corruption() {
        use phobos_wal::v2::{Body, FileId, PageAction, Wal};
        let dir = std::env::temp_dir().join(format!(
            "phobos-private-install-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut wal = Wal::create(&dir).unwrap();
        let id = wal.begin().unwrap();
        let path = dir.join(FileId::Heap(1).name());
        fs::write(&path, [7; PAGE_SIZE]).unwrap();
        let mut io = PageIo::new(
            OpenOptions::new()
                .read(true)
                .write(true)
                .open(&path)
                .unwrap(),
        );
        let scratch = dir.join("private");
        io.begin_private(&scratch, id, &dir).unwrap();
        io.write(0, &[17; PAGE_SIZE]).unwrap();
        let mut other = Wal::create(dir.join("other")).unwrap();
        other.begin().unwrap();
        let wrong = other.commit().unwrap();
        assert!(io.install_private(&wrong).is_err());
        io.prepare_private(|page, bytes, _| {
            wal.append(Body::Page {
                action: PageAction::HeapUpdate,
                file: FileId::Heap(1),
                page,
                image: Box::new(*bytes),
            })?;
            Ok(())
        })
        .unwrap();
        assert!(io.write(0, &[99; PAGE_SIZE]).is_err());
        assert!(io.install_private(&wrong).is_err());
        assert_eq!(fs::read(&path).unwrap(), [7; PAGE_SIZE]);
        let receipt = wal.commit().unwrap();
        io.install_private(&receipt).unwrap();
        assert_eq!(io.read(0).unwrap(), [17; PAGE_SIZE]);
        assert!(!scratch.exists());

        let id = wal.begin().unwrap();
        io.begin_private(&scratch, id, &dir).unwrap();
        io.write(0, &[23; PAGE_SIZE]).unwrap();
        io.prepare_private(|page, bytes, _| {
            wal.append(Body::Page {
                action: PageAction::HeapUpdate,
                file: FileId::Heap(1),
                page,
                image: Box::new(*bytes),
            })?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        fs::write(&scratch, [0]).unwrap();
        assert!(io.install_private(&receipt).is_err());
        assert!(io.rollback_private().is_err());
        assert!(io.read(0).is_err());
        drop(io);
        drop(wal);
        drop(other);
        drop(Wal::recover(&dir).unwrap());
        assert_eq!(fs::read(&path).unwrap(), [23; PAGE_SIZE]);
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn private_eviction_and_sync_leave_base_unchanged_and_release_scratch() {
        let dir = std::env::temp_dir().join(format!(
            "phobos-page-io-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir(&dir).unwrap();
        let path = dir.join("base");
        fs::write(&path, [7; PAGE_SIZE]).unwrap();
        let mut io = PageIo::new(
            OpenOptions::new()
                .read(true)
                .write(true)
                .open(&path)
                .unwrap(),
        );
        let scratch = dir.join("private");
        io.begin_private(&scratch, 1, &dir).unwrap();
        for page in 0..200 {
            io.write(page, &[page as u8; PAGE_SIZE]).unwrap();
        }
        io.sync_data().unwrap();
        assert_eq!(io.len().unwrap(), 200 * PAGE_SIZE as u64);
        assert_eq!(fs::read(&path).unwrap(), [7; PAGE_SIZE]);
        assert_eq!(io.read(0).unwrap(), [0; PAGE_SIZE]);
        assert_eq!(io.read_base(0).unwrap(), [7; PAGE_SIZE]);
        let mut count = 0;
        io.visit_private(|page, bytes, allocated| {
            assert_eq!(bytes, &[page as u8; PAGE_SIZE]);
            assert_eq!(allocated, page != 0);
            count += 1;
            Ok(())
        })
        .unwrap();
        assert_eq!(count, 200);
        io.rollback_private().unwrap();
        assert!(!scratch.exists());
        assert_eq!(io.read(0).unwrap(), [7; PAGE_SIZE]);
        assert_eq!(io.len().unwrap(), PAGE_SIZE as u64);
        drop(io);
        fs::remove_dir_all(dir).unwrap();
    }
}
