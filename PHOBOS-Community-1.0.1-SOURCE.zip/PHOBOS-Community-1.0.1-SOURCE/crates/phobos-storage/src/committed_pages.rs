//! Bounded, WAL-authorized committed images. Private overlays never enter here.
use crate::PAGE_SIZE;
use phobos_error::{ErrorCode, PhobosError};
use phobos_wal::v2::{DurableCommit, FileId};
use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    fs::{self, File, OpenOptions},
    path::{Path, PathBuf},
    sync::{
        Arc, Condvar, Mutex, MutexGuard,
        atomic::{AtomicUsize, Ordering},
    },
    thread::JoinHandle,
    time::{Duration, Instant},
};

mod checkpoint;
type Result<T> = std::result::Result<T, PhobosError>;
pub type PageValidator = fn(&[u8; PAGE_SIZE]) -> Result<()>;

/// 0.2-F: full validator for index page images (CRC, node structure and every
/// encoded key), supplied by the index crate. An image admitted to the store
/// through it (disk read or publication) is immutable afterwards, so readers
/// may build trusted views over the shared frame without re-validating it.
static INDEX_VALIDATOR: std::sync::OnceLock<PageValidator> = std::sync::OnceLock::new();

/// Install the index page validator (first call wins; files registered
/// earlier keep validating at use, as before).
pub fn set_index_page_validator(validator: PageValidator) {
    let _ = INDEX_VALIDATOR.set(validator);
}

/// 0.2-G: structural validator for an index image whose complete checksum
/// was verified on the same borrow (`VerifiedImage`); every structural and
/// key check still runs.
static INDEX_STRUCTURE_VALIDATOR: std::sync::OnceLock<PageValidator> = std::sync::OnceLock::new();

/// 0.2-G: layout validator (header, kind, count, bounds, entry layout; no
/// per-key decoding) for an index image produced in this process.
static INDEX_PRODUCED_VALIDATOR: std::sync::OnceLock<PageValidator> = std::sync::OnceLock::new();

/// Install the full, the checksum-verified and the produced-in-process index
/// validators.
pub fn set_index_page_validators(
    full: PageValidator,
    structure: PageValidator,
    produced: PageValidator,
) {
    let _ = INDEX_VALIDATOR.set(full);
    let _ = INDEX_STRUCTURE_VALIDATOR.set(structure);
    let _ = INDEX_PRODUCED_VALIDATOR.set(produced);
}

/// 0.2-G: proof that `image` carries a valid complete page checksum, page
/// identity and LSN for `page` of `identity` (checked by
/// `page_format::lsn`). It borrows the exact bytes it verified, so they
/// cannot change before `CommittedFile::publish_verified` consumes it; the
/// store then does not recompute the same CRC a second and third time.
pub struct VerifiedImage<'a> {
    identity: FileId,
    page: u64,
    image: &'a [u8; PAGE_SIZE],
    lsn: u64,
    /// Produced in this process and never spilled (see `ProducedInProcess`).
    produced: bool,
}
impl<'a> VerifiedImage<'a> {
    pub fn verify(identity: FileId, page: u64, image: &'a [u8; PAGE_SIZE]) -> Result<Self> {
        let lsn = phobos_wal::v2::page_format::lsn(identity, page, image)?;
        Ok(Self {
            identity,
            page,
            image,
            lsn,
            produced: false,
        })
    }
    /// 0.2-G: `verify` of an image of a private generation that never left
    /// memory. The store then checks the page layout but does not decode
    /// every key again (debug builds still run the full validator).
    pub fn verify_produced(
        identity: FileId,
        page: u64,
        image: &'a [u8; PAGE_SIZE],
        _evidence: &crate::private_pages::ProducedInProcess,
    ) -> Result<Self> {
        let mut proof = Self::verify(identity, page, image)?;
        proof.produced = true;
        Ok(proof)
    }
    #[must_use]
    pub fn lsn(&self) -> u64 {
        self.lsn
    }
}

#[derive(Clone, Debug)]
pub struct FlushConfig {
    pub page_cache_bytes: usize,
    pub batch_pages: usize,
    pub wake_interval: Duration,
    /// Explicit shutdown drains and forces when true; otherwise it retains WAL.
    pub drain_on_shutdown: bool,
}
impl Default for FlushConfig {
    fn default() -> Self {
        Self {
            page_cache_bytes: 256 * 1024 * 1024,
            batch_pages: 128,
            wake_interval: Duration::from_millis(10),
            drain_on_shutdown: true,
        }
    }
}
impl FlushConfig {
    pub fn from_env() -> Result<Self> {
        fn number(name: &str, default: usize) -> Result<usize> {
            match std::env::var(name) {
                Ok(value) => value.parse().map_err(|_| invalid("invalid flush setting")),
                Err(std::env::VarError::NotPresent) => Ok(default),
                Err(_) => Err(invalid("invalid flush environment encoding")),
            }
        }
        let defaults = Self::default();
        let drain = number("PHOBOS_FLUSH_SHUTDOWN_DRAIN", 1)?;
        if drain > 1 {
            return Err(invalid("shutdown drain must be 0 or 1"));
        }
        let page_cache_bytes = match std::env::var("PHOBOS_PAGE_CACHE_BYTES") {
            Ok(value) => value
                .parse()
                .map_err(|_| invalid("invalid cache byte setting"))?,
            Err(std::env::VarError::NotPresent) => number(
                "PHOBOS_DIRTY_HIGH_WATER_PAGES",
                defaults.page_cache_bytes / PAGE_SIZE,
            )?
            .checked_mul(PAGE_SIZE)
            .ok_or_else(|| invalid("cache size overflow"))?,
            Err(_) => return Err(invalid("invalid cache environment encoding")),
        };
        let config = Self {
            page_cache_bytes,
            batch_pages: number("PHOBOS_FLUSH_BATCH_PAGES", defaults.batch_pages)?,
            wake_interval: Duration::from_millis(number("PHOBOS_FLUSH_WAKE_MS", 10)? as u64),
            drain_on_shutdown: drain == 1,
        };
        config.validate()?;
        Ok(config)
    }
    fn validate(&self) -> Result<()> {
        if self.page_cache_bytes < PAGE_SIZE
            || self.batch_pages == 0
            || self.wake_interval.is_zero()
        {
            return Err(invalid("flush limits and interval must be nonzero"));
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct FlushStats {
    pub resident_pages: usize,
    pub clean_pages: usize,
    pub resident_bytes: usize,
    pub dirty_pages: usize,
    pub peak_dirty_pages: usize,
    pub pages_flushed: u64,
    pub bytes_flushed: u64,
    pub background_ns: u64,
    pub eviction_pages: u64,
    pub durable_wal_lsn: u64,
    pub maximum_page_lsn: u64,
}

struct Frame {
    image: Arc<[u8; PAGE_SIZE]>,
    page_lsn: u64,
    rec_lsn: u64,
    generation: u64,
}
struct CleanFrame {
    image: Arc<[u8; PAGE_SIZE]>,
    /// 0.2-B CLOCK reference bit: set on every hit, cleared by the sweep.
    referenced: bool,
    scan: bool,
}

/// 0.2-B: one clean-cache shard with O(1) lookup and amortized O(1) CLOCK
/// eviction. The P1-E shard was a `BTreeMap` whose eviction scanned every
/// resident frame of every shard (O(resident pages), taking each shard lock in
/// turn) on each miss once the cache was full. Workloads whose working set
/// exceeds the cache (any 1M-row table under the 64 MiB default) paid that
/// full scan per page read.
///
/// Policy, preserving P1-E's intent: frames admitted by sequential scans start
/// unreferenced and are the first victims; point/index frames start referenced
/// and survive one sweep; any hit re-arms the reference bit.
#[derive(Default)]
struct ClockShard {
    map: std::collections::HashMap<(u64, u64), usize>,
    slots: Vec<Option<((u64, u64), CleanFrame)>>,
    free: Vec<usize>,
    hand: usize,
}
impl ClockShard {
    #[cfg(test)]
    fn contains_key(&self, key: &(u64, u64)) -> bool {
        self.map.contains_key(key)
    }
    fn get(&mut self, key: &(u64, u64)) -> Option<Arc<[u8; PAGE_SIZE]>> {
        let index = *self.map.get(key)?;
        let (_, frame) = self.slots[index].as_mut().expect("mapped clean slot");
        frame.referenced = true;
        Some(Arc::clone(&frame.image))
    }
    fn remove(&mut self, key: &(u64, u64)) -> bool {
        let Some(index) = self.map.remove(key) else {
            return false;
        };
        self.slots[index] = None;
        self.free.push(index);
        true
    }
    /// Inserts only when absent; returns whether a frame was added.
    fn insert_vacant(&mut self, key: (u64, u64), frame: CleanFrame) -> bool {
        if self.map.contains_key(&key) {
            return false;
        }
        let index = if let Some(index) = self.free.pop() {
            self.slots[index] = Some((key, frame));
            index
        } else {
            self.slots.push(Some((key, frame)));
            self.slots.len() - 1
        };
        self.map.insert(key, index);
        true
    }
    /// Evict one frame; false only when the shard is empty. At most two full
    /// rotations: the first clears every reference bit it passes.
    fn evict_one(&mut self) -> bool {
        if self.map.is_empty() {
            return false;
        }
        let len = self.slots.len();
        for _ in 0..len.saturating_mul(2).saturating_add(1) {
            if self.hand >= len {
                self.hand = 0;
            }
            let index = self.hand;
            self.hand += 1;
            let Some((key, frame)) = self.slots[index].as_mut() else {
                continue;
            };
            if frame.referenced && !frame.scan {
                frame.referenced = false;
                continue;
            }
            if frame.referenced {
                // A reused scan frame is promoted to an ordinary frame.
                frame.referenced = false;
                frame.scan = false;
                continue;
            }
            let key = *key;
            self.map.remove(&key);
            self.slots[index] = None;
            self.free.push(index);
            return true;
        }
        false
    }
    fn retain_file(&mut self, id: u64) -> usize {
        let keys = self
            .map
            .keys()
            .filter(|(file, _)| *file == id)
            .copied()
            .collect::<Vec<_>>();
        for key in &keys {
            self.remove(key);
        }
        keys.len()
    }
}
struct RegisteredFile {
    // This independently opened handle has its own cursor. File::try_clone
    // would share a cursor with PageIo on some platforms.
    // 0.2-B: shared rather than duplicated per read. Positioned reads/writes
    // never use the cursor, and a reader holding the Arc keeps the handle open
    // exactly as the former `try_clone` duplicate did.
    io: Mutex<Option<Arc<File>>>,
    identity: FileId,
    /// 0.2-B: page-image validation applied to every image before it enters
    /// the cache (disk reads before admission, published images before
    /// installation). Images served from this file are then already
    /// validated, so readers need not re-checksum resident pages.
    validator: Option<PageValidator>,
    /// 0.2-G: the same validation minus the page CRC, for `VerifiedImage`s.
    structure: Option<PageValidator>,
    /// 0.2-G: layout-only validation for produced-in-process images.
    produced: Option<PageValidator>,
}
impl RegisteredFile {
    fn snapshot(&self) -> Result<Arc<File>> {
        let (wait, hold) = match self.identity {
            FileId::Heap(_) => ("writeback.heap_lock_wait", "writeback.heap_lock_hold"),
            _ => ("writeback.index_lock_wait", "writeback.index_lock_hold"),
        };
        let io = measured_lock(&self.io, wait, hold)?;
        io.as_ref()
            .ok_or_else(|| invalid("committed file closed"))
            .map(Arc::clone)
    }
}
struct MeasuredGuard<'a, T> {
    guard: MutexGuard<'a, T>,
    _hold: phobos_observability::Span,
}
impl<T> std::ops::Deref for MeasuredGuard<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        &self.guard
    }
}
impl<T> std::ops::DerefMut for MeasuredGuard<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        &mut self.guard
    }
}
fn measured_lock<'a, T>(
    mutex: &'a Mutex<T>,
    wait: &'static str,
    hold: &'static str,
) -> Result<MeasuredGuard<'a, T>> {
    let guard = {
        let _waiting = phobos_observability::span(wait);
        lock(mutex)?
    };
    Ok(MeasuredGuard {
        guard,
        _hold: phobos_observability::span(hold),
    })
}
struct FileState {
    handle: Arc<RegisteredFile>,
    pages: u64,
    unforced_rec_lsn: Option<u64>,
}
#[derive(Default)]
struct State {
    files: BTreeMap<u64, FileState>,
    frames: BTreeMap<(u64, u64), Frame>,
    dirty_pages: BTreeMap<u64, BTreeSet<u64>>,
    next_file: u64,
    generation: u64,
    stopped: bool,
    wake_requested: bool,
    failure: Option<PhobosError>,
    stats: FlushStats,
    checkpoint: Option<checkpoint::Checkpoint>,
    checkpoint_ready: Option<(u64, u64)>,
    retired_scratch: VecDeque<PathBuf>,
    /// A page has at most one physical write in flight. Newer generations may
    /// publish concurrently and remain dirty after the stale completion.
    inflight: BTreeSet<(u64, u64)>,
    /// Foreground force blocks new physical writes for the file without
    /// retaining its handle mutex across sync_all.
    forcing: BTreeSet<u64>,
}
struct Inner {
    directory: PathBuf,
    config: FlushConfig,
    state: Mutex<State>,
    clean: Vec<Mutex<ClockShard>>,
    resident_pages: AtomicUsize,
    /// Round-robin shard cursor for eviction (0.2-B).
    evict_hand: AtomicUsize,
    changed: Condvar,
}
/// One worker per database, shared by C2 preparation domains. The worker owns
/// only Inner; the final Store owner stops and joins it before releasing WAL.
pub struct CommittedStore {
    inner: Arc<Inner>,
    worker: Mutex<Option<JoinHandle<()>>>,
}
pub struct CommittedFile {
    lease: Arc<FileLease>,
}
/// Read-only registration owner. The background worker does not own this lease;
/// the final reader/writer closes the file even if a worker selected its handle.
#[derive(Clone)]
pub struct CommittedReader {
    lease: Arc<FileLease>,
}
#[cfg(feature = "db1-diagnostics")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DiagnosticCommittedPageState {
    pub store_generation: u64,
    pub publication_generation: Option<u64>,
    pub clean_cached: bool,
}
struct FileLease {
    store: Arc<CommittedStore>,
    id: u64,
    handle: Arc<RegisteredFile>,
}
impl CommittedStore {
    pub fn new(directory: &Path, config: FlushConfig) -> Result<Arc<Self>> {
        config.validate()?;
        let inner = Arc::new(Inner {
            directory: std::fs::canonicalize(directory)?,
            config,
            state: Mutex::new(State::default()),
            clean: (0..16).map(|_| Mutex::new(ClockShard::default())).collect(),
            resident_pages: AtomicUsize::new(0),
            evict_hand: AtomicUsize::new(0),
            changed: Condvar::new(),
        });
        let worker_inner = Arc::clone(&inner);
        let worker = std::thread::Builder::new()
            .name("phobos-page-flusher".into())
            .spawn(move || {
                if std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    worker_loop(&worker_inner)
                }))
                .is_err()
                {
                    worker_inner.fail(invalid("background flusher panicked; recovery required"));
                }
            })?;
        Ok(Arc::new(Self {
            inner,
            worker: Mutex::new(Some(worker)),
        }))
    }
    pub fn check(&self) -> Result<()> {
        self.inner.lock()?.check()
    }
    pub fn config(&self) -> &FlushConfig {
        &self.inner.config
    }
    pub fn request_flush(&self) -> Result<()> {
        let mut state = self.inner.lock()?;
        state.check()?;
        state.wake_requested = true;
        self.inner.changed.notify_one();
        Ok(())
    }
    /// Atomically remove committed scratch from the live namespace, then let
    /// the existing housekeeping worker perform recursive deletion outside
    /// the commit acknowledgement path. Recovery/open also recognizes the
    /// retired name, so a crash can only leave disposable scratch behind.
    /// 0.2-F: retirement of the transaction scratch root `path` that skips
    /// the filesystem probe when this process never created it (resident-only
    /// commits). Any doubt takes the unchanged probing path.
    pub fn retire_scratch_if_created(&self, path: &Path) -> Result<()> {
        if crate::private_pages::take_scratch_root(path) {
            return self.retire_scratch(path);
        }
        phobos_observability::event("scratch.retire_absent_known", 1);
        Ok(())
    }
    pub fn retire_scratch(&self, path: &Path) -> Result<()> {
        let name = path
            .file_name()
            .and_then(|name| name.to_str())
            .and_then(|name| name.strip_prefix(".phobos-mvcc-private-"))
            .filter(|id| id.parse::<u64>().is_ok_and(|id| id > 0))
            .ok_or_else(|| invalid("invalid private scratch retirement path"))?;
        // 0.2-B: a resident-only commit never created its scratch directory;
        // there is nothing to move (0.2-C: checked before resolving paths).
        match fs::symlink_metadata(path) {
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                phobos_observability::event("scratch.retire_absent", 1);
                return Ok(());
            }
            Err(error) => return Err(error.into()),
            Ok(_) => {}
        }
        if path.parent().map(fs::canonicalize).transpose()?.as_deref()
            != Some(self.inner.directory.as_path())
        {
            return Err(invalid("private scratch is outside the database"));
        }
        let retired = self
            .inner
            .directory
            .join(format!(".phobos-retired-private-{name}"));
        fs::rename(path, &retired)?;
        let mut state = self.inner.lock()?;
        state.check()?;
        state.retired_scratch.push_back(retired);
        state.wake_requested = true;
        self.inner.changed.notify_one();
        Ok(())
    }
    pub fn stats(&self) -> Result<FlushStats> {
        let state = self.inner.lock()?;
        state.check()?;
        let resident_pages = self.inner.resident_pages.load(Ordering::Relaxed);
        Ok(FlushStats {
            resident_pages,
            clean_pages: resident_pages.saturating_sub(state.frames.len()),
            resident_bytes: resident_pages.saturating_mul(PAGE_SIZE),
            dirty_pages: state.frames.len(),
            ..state.stats
        })
    }
    pub fn register(self: &Arc<Self>, path: &Path, identity: FileId) -> Result<CommittedFile> {
        if path.parent() != Some(self.inner.directory.as_path())
            || !identity.is_paged()
            || path.file_name() != Some(std::ffi::OsStr::new(&identity.name()))
        {
            return Err(invalid("committed file must belong to the database"));
        }
        let file = OpenOptions::new().read(true).write(true).open(path)?;
        let length = file.metadata()?.len();
        if length % PAGE_SIZE as u64 != 0 {
            return Err(invalid("unaligned committed file"));
        }
        let handle = Arc::new(RegisteredFile {
            io: Mutex::new(Some(Arc::new(file))),
            identity,
            validator: match identity {
                FileId::Heap(_) => Some(crate::validate_page_image),
                FileId::Index(_) => INDEX_VALIDATOR.get().copied(),
                _ => None,
            },
            structure: match identity {
                FileId::Heap(_) => Some(crate::validate_page_structure),
                FileId::Index(_) => INDEX_STRUCTURE_VALIDATOR.get().copied(),
                _ => None,
            },
            produced: match identity {
                FileId::Heap(_) => Some(crate::validate_page_structure),
                FileId::Index(_) => INDEX_PRODUCED_VALIDATOR.get().copied(),
                _ => None,
            },
        });
        let mut state = self.inner.lock()?;
        state.check()?;
        if state
            .files
            .values()
            .any(|file| file.handle.identity == identity)
        {
            return Err(invalid("duplicate committed file identity"));
        }
        state.next_file = state
            .next_file
            .checked_add(1)
            .ok_or_else(|| invalid("file generation exhausted"))?;
        let id = state.next_file;
        state.files.insert(
            id,
            FileState {
                handle: Arc::clone(&handle),
                pages: length / PAGE_SIZE as u64,
                unforced_rec_lsn: None,
            },
        );
        Ok(CommittedFile {
            lease: Arc::new(FileLease {
                store: Arc::clone(self),
                id,
                handle,
            }),
        })
    }
    /// Stop is fallible and joins all outstanding I/O. It never retires WAL.
    /// The database's existing checkpoint barrier supplies drain-and-force.
    pub fn stop(&self) -> Result<()> {
        {
            let mut state = self.inner.lock()?;
            state.stopped = true;
            self.inner.changed.notify_all();
        }
        if let Some(worker) = lock(&self.worker)?.take() {
            worker
                .join()
                .map_err(|_| invalid("background flusher panicked"))?;
        }
        self.inner.lock()?.check_failure()
    }
}
impl Drop for CommittedStore {
    fn drop(&mut self) {
        // Drop makes no clean-shutdown claim; retained WAL remains authoritative.
        let _ = self.stop();
    }
}
impl State {
    fn check_failure(&self) -> Result<()> {
        self.failure.clone().map_or(Ok(()), Err)
    }
    fn check(&self) -> Result<()> {
        self.check_failure()?;
        if self.stopped {
            Err(invalid("committed store stopped"))
        } else {
            Ok(())
        }
    }
}
impl Inner {
    fn lock(&self) -> Result<MeasuredGuard<'_, State>> {
        measured_lock(
            &self.state,
            "writeback.store_lock_wait",
            "writeback.store_lock_hold",
        )
    }
    fn maximum_pages(&self) -> usize {
        (self.config.page_cache_bytes / PAGE_SIZE).max(1)
    }
    fn shard(&self, key: (u64, u64)) -> usize {
        ((key.0 ^ key.1) as usize) % self.clean.len()
    }
    fn clean_get(&self, key: (u64, u64)) -> Result<Option<Arc<[u8; PAGE_SIZE]>>> {
        Ok(lock(&self.clean[self.shard(key)])?.get(&key))
    }
    fn clean_remove(&self, key: (u64, u64)) -> Result<bool> {
        let removed = lock(&self.clean[self.shard(key)])?.remove(&key);
        if removed {
            self.resident_pages.fetch_sub(1, Ordering::Relaxed);
        }
        Ok(removed)
    }
    /// 0.2-B: amortized O(1). Shards are visited round-robin; one lock is
    /// held at a time and only for that shard's CLOCK step.
    fn evict_clean(&self) -> Result<bool> {
        let shards = self.clean.len();
        let start = self.evict_hand.fetch_add(1, Ordering::Relaxed);
        for offset in 0..shards {
            let index = (start + offset) % shards;
            if lock(&self.clean[index])?.evict_one() {
                self.resident_pages.fetch_sub(1, Ordering::Relaxed);
                phobos_observability::event("page_cache.clean_evictions", 1);
                return Ok(true);
            }
        }
        Ok(false)
    }
    fn clean_insert(&self, key: (u64, u64), image: Arc<[u8; PAGE_SIZE]>, scan: bool) -> Result<()> {
        while self.resident_pages.load(Ordering::Relaxed) >= self.maximum_pages() {
            if !self.evict_clean()? {
                // Dirty pages remain authoritative and cannot be discarded.
                return Ok(());
            }
        }
        let mut shard = lock(&self.clean[self.shard(key)])?;
        if shard.insert_vacant(
            key,
            CleanFrame {
                image,
                referenced: !scan,
                scan,
            },
        ) {
            self.resident_pages.fetch_add(1, Ordering::Relaxed);
        }
        Ok(())
    }
    fn fail(&self, error: PhobosError) -> PhobosError {
        if let Ok(mut state) = self.state.lock() {
            state.failure.get_or_insert(error.clone());
        }
        self.changed.notify_all();
        error
    }
    fn flush_one(&self, only_file: Option<u64>, reason: &'static str) -> Result<bool> {
        self.flush_target(only_file, reason, None)
    }
    fn flush_target(
        &self,
        only_file: Option<u64>,
        reason: &'static str,
        target: Option<u64>,
    ) -> Result<bool> {
        let selected = {
            let mut state = self.lock()?;
            state.check_failure()?;
            let key = state.dirty_pages.iter().find_map(|(file, pages)| {
                if only_file.is_some_and(|id| id != *file) {
                    return None;
                }
                if state.forcing.contains(file) {
                    return None;
                }
                pages.iter().find_map(|page| {
                    let key = (*file, *page);
                    if state.inflight.contains(&key) {
                        return None;
                    }
                    state.frames.get(&key).and_then(|frame| {
                        target
                            .is_none_or(|lsn| frame.page_lsn <= lsn)
                            .then_some(key)
                    })
                })
            });
            key.map(|key| {
                let frame = &state.frames[&key];
                if frame.page_lsn == 0 || frame.page_lsn > state.stats.durable_wal_lsn {
                    return Err(invalid("background write would outrun durable WAL"));
                }
                let captured = (
                    Arc::clone(&frame.image),
                    frame.page_lsn,
                    frame.rec_lsn,
                    frame.generation,
                );
                let handle = Arc::clone(&state.files[&key.0].handle);
                state.inflight.insert(key);
                Ok((key, handle, captured))
            })
            .transpose()?
        };
        let Some((key, handle, captured)) = selected else {
            return Ok(false);
        };
        // Selection/generation ownership is fixed under the directory mutex.
        // The handle mutex is retained only long enough to clone the handle;
        // positioned I/O itself holds neither synchronization lock.
        let io = handle.snapshot()?;
        phobos_observability::synchronization_boundary(reason, &self.directory);
        phobos_observability::certification_crash(reason);
        phobos_observability::certification_crash("v2_before_dirty_page_write");
        write_all_at(&io, captured.0.as_ref(), page_offset(key.1)?)?;
        let written = match reason {
            "background_flush" => "background_flush_after_write",
            "eviction_flush" => "eviction_flush_after_write",
            _ => "checkpoint_drain_after_write",
        };
        phobos_observability::synchronization_boundary(written, &self.directory);
        phobos_observability::certification_crash(written);
        phobos_observability::certification_crash("v2_after_dirty_page_write");
        phobos_observability::synchronization_boundary("flush_after_write", &self.directory);
        let mut state = self.lock()?;
        state.inflight.remove(&key);
        if state
            .frames
            .get(&key)
            .is_some_and(|frame| frame.generation == captured.3)
        {
            state.frames.remove(&key);
            if let Some(pages) = state.dirty_pages.get_mut(&key.0) {
                pages.remove(&key.1);
                if pages.is_empty() {
                    state.dirty_pages.remove(&key.0);
                }
            }
            self.resident_pages.fetch_sub(1, Ordering::Relaxed);
        }
        let Some(file) = state.files.get_mut(&key.0) else {
            return Ok(true);
        };
        file.unforced_rec_lsn = Some(
            file.unforced_rec_lsn
                .map_or(captured.2, |lsn| lsn.min(captured.2)),
        );
        state.stats.pages_flushed += 1;
        state.stats.bytes_flushed += PAGE_SIZE as u64;
        if reason == "eviction_flush" {
            state.stats.eviction_pages += 1;
        }
        phobos_observability::event("flush.pages", 1);
        phobos_observability::event(
            match reason {
                "background_flush" => "flush.background_pages",
                "eviction_flush" => "flush.eviction_pages",
                _ => "flush.checkpoint_pages",
            },
            1,
        );
        phobos_observability::event("flush.bytes", PAGE_SIZE as u64);
        Ok(true)
    }
}
impl CommittedFile {
    pub fn reader(&self) -> CommittedReader {
        CommittedReader {
            lease: Arc::clone(&self.lease),
        }
    }
    pub fn check(&self) -> Result<()> {
        self.lease.check()
    }
    pub fn len(&self) -> Result<u64> {
        self.lease.len()
    }
    pub fn is_empty(&self) -> Result<bool> {
        self.lease.is_empty()
    }
    pub fn read(&self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        self.lease.read(page)
    }
    /// 0.2-F zero-copy read (see `CommittedReader::read_shared`).
    pub fn read_shared(&self, page: u64) -> Result<(Arc<[u8; PAGE_SIZE]>, bool)> {
        let image = self.lease.read_with_admission(page, false)?;
        Ok((image, self.lease.handle.validator.is_some()))
    }
    pub fn publish(
        &self,
        page: u64,
        image: &[u8; PAGE_SIZE],
        receipt: &DurableCommit,
    ) -> Result<()> {
        self.lease.publish(page, image, receipt)
    }
    /// 0.2-G: see `FileLease::publish_verified`.
    pub fn publish_verified(
        &self,
        proof: VerifiedImage<'_>,
        receipt: &DurableCommit,
    ) -> Result<()> {
        self.lease.publish_verified(proof, receipt)
    }
    pub fn force(&self) -> Result<()> {
        self.lease.force()
    }
}
impl CommittedReader {
    #[cfg(feature = "db1-diagnostics")]
    pub fn diagnostic_state(&self, page: u64) -> Result<DiagnosticCommittedPageState> {
        let key = (self.lease.id, page);
        let state = self.lease.store.inner.lock()?;
        state.check()?;
        let mut result = DiagnosticCommittedPageState {
            store_generation: state.generation,
            publication_generation: state.frames.get(&key).map(|frame| frame.generation),
            clean_cached: false,
        };
        drop(state);
        result.clean_cached =
            lock(&self.lease.store.inner.clean[self.lease.store.inner.shard(key)])?
                .map
                .contains_key(&key);
        Ok(result)
    }
    #[cfg(feature = "db1-diagnostics")]
    pub fn diagnostic_evict_clean(&self, page: u64) -> Result<bool> {
        let key = (self.lease.id, page);
        let state = self.lease.store.inner.lock()?;
        state.check()?;
        if state.frames.contains_key(&key) {
            return Err(invalid("diagnostic eviction requires a clean page"));
        }
        drop(state);
        self.lease.store.inner.clean_remove(key)
    }
    pub fn check(&self) -> Result<()> {
        self.lease.check()
    }
    pub fn len(&self) -> Result<u64> {
        self.lease.len()
    }
    pub fn is_empty(&self) -> Result<bool> {
        self.lease.is_empty()
    }
    pub fn read(&self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        self.lease.read(page)
    }
    /// Sequential scans use low-priority admission so they do not evict hot
    /// point-lookup pages from the shared cache.
    pub fn read_scan(&self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        Ok(*self.lease.read_with_admission(page, true)?)
    }
    /// 0.2-B zero-copy read: the returned image is the immutable committed
    /// frame (or the one-off disk image) shared by reference, never a copy.
    /// The flag reports whether the image was validated on entry to the
    /// store (heap files): the caller may then skip re-validating it.
    pub fn read_shared(&self, page: u64, scan: bool) -> Result<(Arc<[u8; PAGE_SIZE]>, bool)> {
        let image = self.lease.read_with_admission(page, scan)?;
        Ok((image, self.lease.handle.validator.is_some()))
    }
}
impl FileLease {
    pub fn check(&self) -> Result<()> {
        self.store.check()
    }
    pub fn len(&self) -> Result<u64> {
        let state = self.store.inner.lock()?;
        state.check()?;
        page_offset(state.files[&self.id].pages)
    }
    pub fn is_empty(&self) -> Result<bool> {
        Ok(self.len()? == 0)
    }
    pub fn read(&self, page: u64) -> Result<[u8; PAGE_SIZE]> {
        Ok(*self.read_with_admission(page, false)?)
    }
    fn read_with_admission(&self, page: u64, scan: bool) -> Result<Arc<[u8; PAGE_SIZE]>> {
        let key = (self.id, page);
        loop {
            // Fast resident lookup does not wait for unrelated physical I/O.
            {
                let state = self.store.inner.lock()?;
                state.check()?;
                if let Some(frame) = state.frames.get(&key) {
                    phobos_observability::event("page_cache.dirty_hits", 1);
                    if scan {
                        phobos_observability::event("scan_cached_dirty_pages", 1);
                    }
                    return Ok(Arc::clone(&frame.image));
                }
            }
            if let Some(image) = self.store.inner.clean_get(key)? {
                phobos_observability::event("page_cache.clean_hits", 1);
                return Ok(image);
            }
            let io = self.handle.snapshot()?;
            let (generation, admit_scan) = {
                let state = self.store.inner.lock()?;
                state.check()?;
                if let Some(frame) = state.frames.get(&key) {
                    return Ok(Arc::clone(&frame.image));
                }
                // 0.2-B: like PostgreSQL's bulk-read ring threshold, a file no
                // larger than a quarter of the cache is admitted by scans (as
                // first-victim frames) so small hot tables become resident;
                // larger scans still bypass admission and cannot flush the
                // point-read working set.
                let small = state.files.get(&self.id).is_some_and(|file| {
                    file.pages <= (self.store.inner.maximum_pages() / 4) as u64
                });
                (state.generation, scan && small)
            };
            if let Some(image) = self.store.inner.clean_get(key)? {
                return Ok(image);
            }
            let mut image = Arc::new([0; PAGE_SIZE]);
            read_exact_at(
                &io,
                Arc::get_mut(&mut image).expect("fresh image"),
                page_offset(page)?,
            )?;
            if let Some(validate) = self.handle.validator {
                // Never admit (or return) an image that fails validation.
                validate(&image)?;
            }
            phobos_observability::synchronization_boundary(
                "committed_read_after_disk",
                &self.store.inner.directory,
            );
            {
                let state = self.store.inner.lock()?;
                state.check()?;
                if let Some(frame) = state.frames.get(&key) {
                    return Ok(Arc::clone(&frame.image));
                }
                if state.generation != generation {
                    continue;
                }
            }
            if scan && !admit_scan {
                // A cold sequential page is not reusable enough to displace the
                // point-read working set. Dirty committed images and existing hot
                // clean frames were checked above; only the cold disk image bypasses
                // shared-cache admission.
                phobos_observability::event("scan_direct_pages", 1);
                phobos_observability::event("scan_read_calls", 1);
            } else {
                self.store
                    .inner
                    .clean_insert(key, Arc::clone(&image), scan)?;
                let state = self.store.inner.lock()?;
                state.check()?;
                if let Some(frame) = state.frames.get(&key) {
                    let current = Arc::clone(&frame.image);
                    drop(state);
                    self.store.inner.clean_remove(key)?;
                    return Ok(current);
                }
                if state.generation != generation {
                    drop(state);
                    self.store.inner.clean_remove(key)?;
                    continue;
                }
            }
            phobos_observability::event("page_cache.misses", 1);
            return Ok(image);
        }
    }
    pub fn publish(
        &self,
        page: u64,
        image: &[u8; PAGE_SIZE],
        receipt: &DurableCommit,
    ) -> Result<()> {
        self.publish_checked(page, image, receipt, None)
    }
    /// 0.2-G: `publish` of an image whose checksum, identity and LSN were
    /// verified on this exact borrow: the full structural validation still
    /// runs, the CRC is not recomputed. A validator that is not registered
    /// for the structural path falls back to the full one.
    pub fn publish_verified(
        &self,
        proof: VerifiedImage<'_>,
        receipt: &DurableCommit,
    ) -> Result<()> {
        if proof.identity != self.handle.identity {
            return Err(invalid("verified image belongs to another file"));
        }
        if proof.produced {
            phobos_observability::event("writeback.publish_produced_in_process", 1);
            #[cfg(debug_assertions)]
            if let Some(validate) = self.handle.validator {
                validate(proof.image).expect("produced image passes full validation");
            }
            let layout = self
                .handle
                .produced
                .or(self.handle.structure)
                .or(self.handle.validator);
            return self.publish_checked(
                proof.page,
                proof.image,
                receipt,
                Some((proof.lsn, layout)),
            );
        }
        let structure = self.handle.structure.or(self.handle.validator);
        self.publish_checked(
            proof.page,
            proof.image,
            receipt,
            Some((proof.lsn, structure)),
        )
    }
    fn publish_checked(
        &self,
        page: u64,
        image: &[u8; PAGE_SIZE],
        receipt: &DurableCommit,
        verified: Option<(u64, Option<PageValidator>)>,
    ) -> Result<()> {
        let inner = &self.store.inner;
        if receipt.directory() != inner.directory || receipt.page_format() < 2 {
            return Err(invalid(
                "committed buffer requires matching page-LSN WAL receipt",
            ));
        }
        phobos_wal::v2::page_format::validate_capability(
            receipt.page_format(),
            self.handle.identity,
            image,
        )?;
        let lsn = match verified {
            Some((lsn, validator)) => {
                phobos_observability::event("writeback.publish_checksum_verified", 1);
                if let Some(validate) = validator {
                    validate(image)?;
                }
                lsn
            }
            None => {
                if let Some(validate) = self.handle.validator {
                    validate(image)?;
                }
                phobos_observability::measure("writeback.page_lsn_validation", || {
                    phobos_wal::v2::page_format::lsn(self.handle.identity, page, image)
                })?
            }
        };
        if lsn == 0 || lsn > receipt.lsn() {
            return Err(invalid("publication would outrun durable WAL"));
        }
        let key = (self.id, page);
        loop {
            let mut state = inner.lock()?;
            state.check()?;
            let existed = state.frames.contains_key(&key);
            if existed || inner.resident_pages.load(Ordering::Relaxed) < inner.maximum_pages() {
                let file = state.files.get_mut(&self.id).expect("owned registration");
                if page > file.pages {
                    return Err(invalid("buffered publication creates page gap"));
                }
                file.pages = file.pages.max(
                    page.checked_add(1)
                        .ok_or_else(|| invalid("page count overflow"))?,
                );
                state.generation = state
                    .generation
                    .checked_add(1)
                    .ok_or_else(|| invalid("dirty generation exhausted"))?;
                let generation = state.generation;
                if state.checkpoint.is_some() && state.frames.contains_key(&key) {
                    phobos_observability::event("checkpoint.redirties", 1);
                }
                let rec_lsn = state.frames.get(&key).map_or(lsn, |frame| frame.rec_lsn);
                state.frames.insert(
                    key,
                    Frame {
                        image: Arc::new(*image),
                        page_lsn: lsn,
                        rec_lsn,
                        generation,
                    },
                );
                state.dirty_pages.entry(self.id).or_default().insert(page);
                if !existed {
                    inner.resident_pages.fetch_add(1, Ordering::Relaxed);
                }
                state.stats.durable_wal_lsn = state.stats.durable_wal_lsn.max(receipt.lsn());
                state.stats.maximum_page_lsn = state.stats.maximum_page_lsn.max(lsn);
                state.stats.peak_dirty_pages = state.stats.peak_dirty_pages.max(state.frames.len());
                if state.frames.len() >= inner.maximum_pages() {
                    inner.changed.notify_one();
                }
                drop(state);
                // 0.2-B: drop any clean image only AFTER the dirty frame is
                // visible. Removing it first (as before) left a window in
                // which a concurrent miss could admit the pre-publication disk
                // image after the removal; the reader's generation re-check
                // then passed, and once the dirty frame was flushed and
                // retired that stale clean image was served (a committed
                // index entry could be lost by the next writer). A reader
                // admitting after this removal re-checks frames/generation
                // under the state lock and discards its image.
                inner.clean_remove(key)?;
                return Ok(());
            }
            drop(state);
            if inner.evict_clean()? {
                continue;
            }
            let _stall = phobos_observability::span("flush.eviction_wait");
            inner
                .flush_one(None, "eviction_flush")
                .map_err(|error| inner.fail(error))?;
        }
    }
    pub fn force(&self) -> Result<()> {
        let _span = phobos_observability::span("checkpoint.foreground_drain");
        let inner = &self.store.inner;
        let result = (|| {
            loop {
                while inner.flush_one(Some(self.id), "checkpoint_drain")? {}
                let mut state = inner.lock()?;
                if state.inflight.iter().any(|(file, _)| *file == self.id) {
                    drop(state);
                    std::thread::yield_now();
                    continue;
                }
                state.forcing.insert(self.id);
                break;
            }
            let io = self.handle.snapshot()?;
            if inner.lock()?.files[&self.id].unforced_rec_lsn.is_none() {
                inner.lock()?.forcing.remove(&self.id);
                return Ok(());
            }
            phobos_observability::certification_crash("v2_before_dirty_page_force");
            phobos_observability::measure("storage.wal_page_fsync", || io.sync_all())?;
            phobos_observability::certification_crash("v2_after_dirty_page_force");
            let mut state = inner.lock()?;
            state.forcing.remove(&self.id);
            state
                .files
                .get_mut(&self.id)
                .expect("owned registration")
                .unforced_rec_lsn = None;
            Ok(())
        })();
        result.map_err(|error| inner.fail(error))
    }
}
impl Drop for FileLease {
    fn drop(&mut self) {
        // Wait for this file's pinned write before releasing handles for Windows
        // rename/removal. Dirty images may be discarded only with retained WAL.
        if let Ok(mut io) = self.handle.io.lock() {
            if let Ok(mut state) = self.store.inner.state.lock() {
                let before = state.frames.len();
                state.frames.retain(|(id, _), _| *id != self.id);
                state.dirty_pages.remove(&self.id);
                state.inflight.retain(|(id, _)| *id != self.id);
                state.forcing.remove(&self.id);
                self.store
                    .inner
                    .resident_pages
                    .fetch_sub(before - state.frames.len(), Ordering::Relaxed);
                state.files.remove(&self.id);
            }
            for shard in &self.store.inner.clean {
                if let Ok(mut shard) = shard.lock() {
                    let removed = shard.retain_file(self.id);
                    self.store
                        .inner
                        .resident_pages
                        .fetch_sub(removed, Ordering::Relaxed);
                }
            }
            // Selected worker Arc references do not keep the OS handle open.
            io.take();
        }
    }
}
fn worker_loop(inner: &Inner) {
    loop {
        let Ok(state) = inner.state.lock() else {
            return;
        };
        if state.stopped || state.failure.is_some() {
            return;
        }
        let (mut state, due) =
            if state.wake_requested || state.frames.len() >= inner.maximum_pages() {
                (state, true)
            } else {
                let Ok((state, timeout)) = inner
                    .changed
                    .wait_timeout(state, inner.config.wake_interval)
                else {
                    return;
                };
                (state, timeout.timed_out())
            };
        if state.stopped || state.failure.is_some() {
            return;
        }
        if !due && !state.wake_requested && state.frames.len() < inner.maximum_pages() {
            continue;
        }
        state.wake_requested = false;
        let retired = state.retired_scratch.pop_front();
        if !state.retired_scratch.is_empty() {
            state.wake_requested = true;
            inner.changed.notify_one();
        }
        phobos_observability::event("writeback.wakeups", 1);
        drop(state);
        let retired_work = retired.is_some();
        if let Some(path) = retired {
            let _retirement = phobos_observability::span("scratch.retirement");
            match fs::remove_dir_all(path) {
                Ok(()) => phobos_observability::event("scratch.retired_directories", 1),
                Err(_) => phobos_observability::event("scratch.retirement_failures", 1),
            }
        }
        if retired_work {
            // A retirement wake is housekeeping only. Preserve the established
            // dirty-page timing and let the ordinary high-water/timer policy
            // decide when committed pages are written back.
            continue;
        }
        phobos_observability::synchronization_boundary("background_batch_start", &inner.directory);
        let start = Instant::now();
        let _profile = phobos_observability::span("flush.background");
        let checkpoint = match inner.checkpoint_batch() {
            Ok(active) => active,
            Err(error) => {
                inner.fail(error);
                return;
            }
        };
        for _ in 0..if checkpoint {
            0
        } else {
            inner.config.batch_pages
        } {
            match inner.flush_one(None, "background_flush") {
                Ok(true) => {}
                Ok(false) => break,
                Err(error) => {
                    inner.fail(error);
                    return;
                }
            }
        }
        if let Ok(mut state) = inner.state.lock() {
            state.stats.background_ns = state
                .stats
                .background_ns
                .saturating_add(start.elapsed().as_nanos().min(u64::MAX as u128) as u64);
        }
    }
}
fn lock<T>(mutex: &Mutex<T>) -> Result<MutexGuard<'_, T>> {
    mutex
        .lock()
        .map_err(|_| invalid("committed page synchronization poisoned"))
}
fn page_offset(page: u64) -> Result<u64> {
    page.checked_mul(PAGE_SIZE as u64)
        .ok_or_else(|| invalid("committed page offset overflow"))
}

#[cfg(windows)]
fn write_all_at(file: &File, mut bytes: &[u8], mut offset: u64) -> std::io::Result<()> {
    use std::os::windows::fs::FileExt;
    while !bytes.is_empty() {
        let written = file.seek_write(bytes, offset)?;
        if written == 0 {
            return Err(std::io::ErrorKind::WriteZero.into());
        }
        bytes = &bytes[written..];
        offset += written as u64;
    }
    Ok(())
}
#[cfg(unix)]
fn write_all_at(file: &File, mut bytes: &[u8], mut offset: u64) -> std::io::Result<()> {
    use std::os::unix::fs::FileExt;
    while !bytes.is_empty() {
        let written = file.write_at(bytes, offset)?;
        if written == 0 {
            return Err(std::io::ErrorKind::WriteZero.into());
        }
        bytes = &bytes[written..];
        offset += written as u64;
    }
    Ok(())
}
#[cfg(windows)]
fn read_exact_at(file: &File, mut bytes: &mut [u8], mut offset: u64) -> std::io::Result<()> {
    use std::os::windows::fs::FileExt;
    while !bytes.is_empty() {
        let read = file.seek_read(bytes, offset)?;
        if read == 0 {
            return Err(std::io::ErrorKind::UnexpectedEof.into());
        }
        bytes = &mut bytes[read..];
        offset += read as u64;
    }
    Ok(())
}
#[cfg(unix)]
fn read_exact_at(file: &File, mut bytes: &mut [u8], mut offset: u64) -> std::io::Result<()> {
    use std::os::unix::fs::FileExt;
    while !bytes.is_empty() {
        let read = file.read_at(bytes, offset)?;
        if read == 0 {
            return Err(std::io::ErrorKind::UnexpectedEof.into());
        }
        bytes = &mut bytes[read..];
        offset += read as u64;
    }
    Ok(())
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{SlottedPage, page_io::PageIo};
    use phobos_wal::v2::{PageAction, Wal};
    use std::sync::mpsc;

    fn setup() -> (PathBuf, Wal, Arc<CommittedStore>, PageIo) {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let dir = std::env::temp_dir().join(format!(
            "phobos-c3-pages-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        ));
        let wal = Wal::create_with_page_lsn(&dir).unwrap();
        let path = dir.join(FileId::Heap(1).name());
        std::fs::write(&path, SlottedPage::new(0).to_bytes()).unwrap();
        let store = CommittedStore::new(
            &dir,
            FlushConfig {
                wake_interval: Duration::from_secs(3600),
                ..Default::default()
            },
        )
        .unwrap();
        let mut io = PageIo::new(
            OpenOptions::new()
                .read(true)
                .write(true)
                .open(&path)
                .unwrap(),
        );
        io.attach_committed(
            &store,
            &std::fs::canonicalize(path).unwrap(),
            FileId::Heap(1),
        )
        .unwrap();
        (dir, wal, store, io)
    }
    #[test]
    fn perf1_retired_scratch_leaves_commit_path_before_recursive_delete() {
        let (dir, wal, store, io) = setup();
        let live = dir.join(".phobos-mvcc-private-77");
        fs::create_dir(&live).unwrap();
        fs::write(live.join("page-spill"), [7; 8192]).unwrap();
        store.retire_scratch(&live).unwrap();
        assert!(!live.exists(), "live scratch name survived retirement");
        let retired = dir.join(".phobos-retired-private-77");
        let deadline = Instant::now() + Duration::from_secs(10);
        while retired.exists() && Instant::now() < deadline {
            std::thread::yield_now();
        }
        assert!(
            !retired.exists(),
            "housekeeping worker did not delete scratch"
        );
        drop(io);
        drop(store);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn checkpoint_target_skips_redirty_retains_dependency_then_advances() {
        let (dir, mut wal, store, mut io) = setup();
        let first = commit(&mut io, &mut wal, &dir, b"first");
        let (entered, waiting) = mpsc::channel();
        let (release, released) = mpsc::channel();
        let released = Mutex::new(released);
        let once = std::sync::atomic::AtomicBool::new(false);
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |at| {
                if at == "checkpoint.target_captured"
                    && !once.swap(true, std::sync::atomic::Ordering::SeqCst)
                {
                    entered.send(()).unwrap();
                    released
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
            }),
        );
        store.request_checkpoint(first.lsn()).unwrap();
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        // The checkpoint worker is paused while ordinary private preparation,
        // WAL durability, and committed publication all finish independently.
        let second = commit(&mut io, &mut wal, &dir, b"second");
        let expected = io.read(0).unwrap();
        release.send(()).unwrap();
        drop(hook);
        // Wake explicitly instead of waiting for the deliberately long timer.
        let deadline = Instant::now() + Duration::from_secs(10);
        let completion = loop {
            store.request_flush().unwrap();
            if let Some(done) = store.take_checkpoint().unwrap() {
                break done;
            }
            assert!(Instant::now() < deadline);
            std::thread::yield_now();
        };
        assert_eq!(completion.0, first.lsn());
        assert!(
            completion.1 < first.lsn(),
            "redirty still requires earlier WAL"
        );
        assert_eq!(io.read(0).unwrap(), expected);
        io.force_committed().unwrap();
        store.request_checkpoint(second.lsn()).unwrap();
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            store.request_flush().unwrap();
            if let Some((target, safe)) = store.take_checkpoint().unwrap() {
                assert_eq!((target, safe), (second.lsn(), second.lsn()));
                break;
            }
            assert!(Instant::now() < deadline);
            std::thread::yield_now();
        }
        wal.checkpoint_all(second.lsn()).unwrap();
        drop(io);
        drop(store);
        drop(wal);
        std::fs::remove_dir_all(dir).unwrap();
    }
    /// 0.2-G: the verified-image proof checks the complete checksum, page
    /// identity and LSN, and is accepted only by the file it was made for.
    #[test]
    fn verified_image_proof_is_complete_and_file_bound() {
        let (dir, mut wal, store, mut io) = setup();
        let receipt = commit(&mut io, &mut wal, &dir, b"proof");
        let image = io.read(0).unwrap();
        let proof = VerifiedImage::verify(FileId::Heap(1), 0, &image).unwrap();
        assert!(proof.lsn() > 0 && proof.lsn() < receipt.lsn());
        // Any flipped byte fails the complete checksum.
        for at in [0usize, 40, 4000, PAGE_SIZE - 1] {
            let mut bad = image;
            bad[at] ^= 0x10;
            assert!(
                VerifiedImage::verify(FileId::Heap(1), 0, &bad).is_err(),
                "byte {at}"
            );
        }
        // Wrong page identity.
        assert!(VerifiedImage::verify(FileId::Heap(1), 1, &image).is_err());
        // A proof for another file identity is refused by this file.
        let second = dir.join(FileId::Heap(2).name());
        std::fs::write(&second, SlottedPage::new(0).to_bytes()).unwrap();
        // Registration compares canonical database paths (including Windows
        // extended-length prefixes), just as PageIo does in production.
        let file = store
            .register(&std::fs::canonicalize(&second).unwrap(), FileId::Heap(2))
            .unwrap();
        assert!(file.publish_verified(proof, &receipt).is_err());
        drop(file);
        drop(io);
        drop(store);
        drop(wal);
        std::fs::remove_dir_all(dir).unwrap();
    }
    fn commit(io: &mut PageIo, wal: &mut Wal, dir: &Path, value: &[u8]) -> DurableCommit {
        let id = wal.begin().unwrap();
        io.begin_private(dir.join(format!("private-{id}")), id, dir)
            .unwrap();
        let mut page = SlottedPage::from_bytes(io.read(0).unwrap()).unwrap();
        page.insert(value).unwrap();
        io.write(0, &page.to_bytes()).unwrap();
        io.prepare_private_redo(FileId::Heap(1), |page, image, _| {
            wal.append_page(PageAction::HeapUpdate, FileId::Heap(1), page, image)?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        io.install_private(&receipt).unwrap();
        receipt
    }
    #[test]
    fn sequential_scan_prefers_newer_dirty_committed_image_to_stale_disk() {
        let (dir, mut wal, store, mut io) = setup();
        let path = dir.join(FileId::Heap(1).name());
        let disk = std::fs::read(&path).unwrap();
        commit(&mut io, &mut wal, &dir, b"visible-before-flush");
        assert_eq!(std::fs::read(&path).unwrap(), disk);
        let scanned = io.committed_reader().unwrap().read_scan(0).unwrap();
        assert_eq!(scanned, io.read(0).unwrap());
        assert_ne!(scanned.as_slice(), disk.as_slice());
        drop(io);
        drop(store);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn disk_miss_racing_publication_returns_the_published_page() {
        let (dir, mut wal, store, mut io) = setup();
        let id = wal.begin().unwrap();
        io.begin_private(dir.join(format!("private-{id}")), id, &dir)
            .unwrap();
        let bytes: [u8; PAGE_SIZE] = fs::read(dir.join(FileId::Heap(1).name()))
            .unwrap()
            .try_into()
            .unwrap();
        let mut page = SlottedPage::from_bytes(bytes).unwrap();
        page.insert(b"published").unwrap();
        io.write(0, &page.to_bytes()).unwrap();
        io.prepare_private_redo(FileId::Heap(1), |page, image, _| {
            wal.append_page(PageAction::HeapUpdate, FileId::Heap(1), page, image)?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();

        let reader = io.committed_reader().unwrap();
        let (entered_tx, entered_rx) = mpsc::channel();
        let (release_tx, release_rx) = mpsc::channel();
        let release_rx = Mutex::new(release_rx);
        let once = std::sync::atomic::AtomicBool::new(false);
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "committed_read_after_disk"
                    && !once.swap(true, std::sync::atomic::Ordering::SeqCst)
                {
                    entered_tx.send(()).unwrap();
                    release_rx
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
            }),
        );
        let reading = std::thread::spawn(move || reader.read(0).unwrap());
        entered_rx.recv_timeout(Duration::from_secs(10)).unwrap();
        io.install_private(&receipt).unwrap();
        let expected = io.read(0).unwrap();
        release_tx.send(()).unwrap();
        let observed = reading.join().unwrap();
        drop(hook);
        assert_eq!(observed, expected, "cold disk read returned a stale image");
        drop(io);
        drop(store);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn redirty_during_pinned_write_retains_new_generation_and_forces_latest_image() {
        let (dir, mut wal, store, mut io) = setup();
        let before = std::fs::read(dir.join(FileId::Heap(1).name())).unwrap();
        commit(&mut io, &mut wal, &dir, b"first");
        assert_eq!(
            std::fs::read(dir.join(FileId::Heap(1).name())).unwrap(),
            before
        );
        let (entered, waiting) = mpsc::channel();
        let (release, released) = mpsc::channel();
        let released = Mutex::new(released);
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "flush_after_write" {
                    entered.send(()).unwrap();
                    released
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
            }),
        );
        let worker_store = Arc::clone(&store);
        let worker =
            std::thread::spawn(move || worker_store.inner.flush_one(None, "background_flush"));
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        let receipt = commit(&mut io, &mut wal, &dir, b"second");
        let expected = io.read(0).unwrap();
        release.send(()).unwrap();
        assert!(worker.join().unwrap().unwrap());
        drop(hook);
        assert_eq!(
            store.stats().unwrap().dirty_pages,
            1,
            "stale completion lost redirty"
        );
        io.force_committed().unwrap();
        let stats = store.stats().unwrap();
        assert_eq!(stats.dirty_pages, 0);
        assert_eq!(stats.pages_flushed, 2);
        assert!(stats.maximum_page_lsn < receipt.lsn());
        assert_eq!(stats.durable_wal_lsn, receipt.lsn());
        assert_eq!(
            std::fs::read(dir.join(FileId::Heap(1).name())).unwrap(),
            expected
        );
        wal.checkpoint_all(receipt.lsn()).unwrap();
        drop(io);
        drop(store);
        drop(wal);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn failed_write_retains_dirty_state_fences_all_handles_and_recovers() {
        let (dir, mut wal, store, mut io) = setup();
        commit(&mut io, &mut wal, &dir, b"durable");
        let expected = io.read(0).unwrap();
        let handle = Arc::clone(
            &store
                .inner
                .lock()
                .unwrap()
                .files
                .values()
                .next()
                .unwrap()
                .handle,
        );
        *handle.io.lock().unwrap() = Some(Arc::new(
            File::open(dir.join(FileId::Heap(1).name())).unwrap(),
        ));
        assert!(io.force_committed().is_err());
        assert!(io.read(0).is_err());
        assert!(store.check().is_err());
        assert_eq!(store.inner.lock().unwrap().frames.len(), 1);
        assert!(store.stop().is_err(), "shutdown hid write failure");
        drop(handle);
        drop(io);
        drop(store);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        assert_eq!(
            std::fs::read(dir.join(FileId::Heap(1).name())).unwrap(),
            expected
        );
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn selected_registration_cannot_keep_windows_handle_alive_after_owner_drop() {
        let (dir, mut wal, store, mut io) = setup();
        commit(&mut io, &mut wal, &dir, b"retained in WAL");
        let selected = Arc::clone(
            &store
                .inner
                .lock()
                .unwrap()
                .files
                .values()
                .next()
                .unwrap()
                .handle,
        );
        drop(io);
        assert!(selected.io.lock().unwrap().is_none());
        assert!(store.inner.lock().unwrap().frames.is_empty());
        let path = dir.join(FileId::Heap(1).name());
        std::fs::rename(&path, dir.join("retired.heap")).unwrap();
        drop(selected);
        drop(store);
        drop(wal);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn flush_rechecks_wal_frontier_and_leaves_ineligible_image_dirty() {
        let (dir, mut wal, store, mut io) = setup();
        let before = std::fs::read(dir.join(FileId::Heap(1).name())).unwrap();
        commit(&mut io, &mut wal, &dir, b"durable");
        store.inner.lock().unwrap().stats.durable_wal_lsn = 0;
        assert!(io.force_committed().is_err());
        assert_eq!(
            std::fs::read(dir.join(FileId::Heap(1).name())).unwrap(),
            before
        );
        assert_eq!(store.inner.lock().unwrap().frames.len(), 1);
        drop(io);
        drop(store);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn shared_cache_has_one_resident_copy_across_clean_and_dirty_states() {
        let (dir, mut wal, store, mut io) = setup();
        let before = io.read(0).unwrap();
        assert_eq!(io.read(0).unwrap(), before);
        let clean = store.stats().unwrap();
        assert_eq!(
            (clean.resident_pages, clean.clean_pages, clean.dirty_pages),
            (1, 1, 0)
        );
        commit(&mut io, &mut wal, &dir, b"new");
        let dirty = store.stats().unwrap();
        assert_eq!(
            (dirty.resident_pages, dirty.clean_pages, dirty.dirty_pages),
            (1, 0, 1)
        );
        drop(io);
        drop(store);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn sequential_scan_bypasses_clean_admission_and_preserves_hot_pages() {
        let dir = std::env::temp_dir().join(format!(
            "phobos-f3-cache-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        let dir = std::fs::canonicalize(dir).unwrap();
        let identity = FileId::Heap(1);
        let path = dir.join(identity.name());
        let mut bytes = Vec::new();
        for page in 0..3 {
            bytes.extend_from_slice(&SlottedPage::new(page).to_bytes());
        }
        std::fs::write(&path, bytes).unwrap();
        let store = CommittedStore::new(
            &dir,
            FlushConfig {
                page_cache_bytes: 2 * PAGE_SIZE,
                wake_interval: Duration::from_secs(3600),
                ..Default::default()
            },
        )
        .unwrap();
        let file = store.register(&path, identity).unwrap();
        let reader = file.reader();
        reader.read(0).unwrap();
        reader.read_scan(1).unwrap();
        reader.read_scan(2).unwrap();
        assert_eq!(store.stats().unwrap().clean_pages, 1);
        let id = file.lease.id;
        let hot = (id, 0);
        assert!(
            store.inner.clean[store.inner.shard(hot)]
                .lock()
                .unwrap()
                .contains_key(&hot)
        );
        drop(file);
        drop(store);
        std::fs::remove_dir_all(dir).unwrap();
    }
}
