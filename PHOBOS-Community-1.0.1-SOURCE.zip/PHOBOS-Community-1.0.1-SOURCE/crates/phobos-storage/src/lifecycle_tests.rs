//! 0.2-K Storage Lifecycle V1: page-level slot states (Part B), FREE-slot
//! allocation (Part E), trailing trim (Part F) and whole-page reset (Part G).
use super::*;
use phobos_types::ColumnSchema;

fn record(byte: u8, len: usize) -> Vec<u8> {
    vec![byte; len]
}

/// A versioned page with `n` occupied slots of `len` bytes each.
fn page_with(n: u16, len: usize) -> SlottedPage {
    let mut page = SlottedPage::new_versioned(7);
    for slot in 0..n {
        assert_eq!(page.insert(&record(slot as u8 + 1, len)).unwrap(), slot);
    }
    page
}

fn retire(page: &mut SlottedPage, slot: SlotId) {
    page.retire_slot(slot).unwrap();
    page.refresh_checksum();
}

fn free(page: &mut SlottedPage, slot: SlotId) {
    page.free_retired_slot(slot).unwrap();
    page.refresh_checksum();
}

fn states(page: &SlottedPage) -> Vec<SlotState> {
    (0..page.slot_count())
        .map(|slot| page.slot_state(slot))
        .collect()
}

#[test]
fn k_slot_states_are_distinct_and_retired_is_the_legacy_tombstone() {
    let mut page = page_with(3, 20);
    // The pre-0.2-K tombstone (`delete`) is exactly RETIRED.
    assert!(page.delete(0).unwrap());
    assert_eq!(page.slot_state(0), SlotState::Retired);
    retire(&mut page, 1);
    assert_eq!(page.slot_state(1), SlotState::Retired);
    free(&mut page, 1);
    assert_eq!(page.slot_state(1), SlotState::Free);
    assert_eq!(page.slot_state(2), SlotState::Occupied);
    assert_eq!(page.slot_state(3), SlotState::Vacant);
    assert_eq!(
        page.slot_census(),
        SlotCensus {
            slots: 3,
            occupied: 1,
            retired: 1,
            free: 1
        }
    );
    // Neither RETIRED nor FREE returns a tuple; both are "empty".
    assert!(page.get(0).unwrap().is_none() && page.get(1).unwrap().is_none());
    assert!(page.slot_is_empty(0) && page.slot_is_empty(1) && !page.slot_is_empty(2));
    // Byte-level encoding: RETIRED keeps its (non-zero) offset, FREE is 0/0.
    let entry = |slot: usize| {
        let at = HEADER_SIZE + slot * SLOT_SIZE;
        (page.get_u16(at), page.get_u16(at + 2))
    };
    assert!(entry(0).0 >= HEADER_SIZE as u16 && entry(0).1 == 0);
    assert_eq!(entry(1), (0, 0));
    assert_ne!(page.flags() & PAGE_FLAG_FREE_SLOTS, 0);
    // Round trip through validation.
    let reread = SlottedPage::from_bytes(page.to_bytes()).unwrap();
    assert_eq!(states(&reread), states(&page));
}

#[test]
fn k_invalid_slot_state_combinations_are_rejected() {
    // len 0 with an offset inside the header: neither RETIRED nor FREE.
    let mut page = page_with(2, 16);
    let at = HEADER_SIZE;
    page.put_u16(at, 12);
    page.put_u16(at + 2, 0);
    page.refresh_checksum();
    assert!(SlottedPage::from_bytes(page.to_bytes()).is_err());
    // FREE on an overflow page.
    let mut overflow = SlottedPage::new_overflow(3);
    overflow.insert(&record(9, 64)).unwrap();
    overflow.put_u16(HEADER_SIZE, 0);
    overflow.put_u16(HEADER_SIZE + 2, 0);
    overflow.refresh_checksum();
    assert!(SlottedPage::from_bytes(overflow.to_bytes()).is_err());
    // FREE on a legacy (non-versioned) page.
    let mut legacy = SlottedPage::new(4);
    legacy.insert(&record(9, 64)).unwrap();
    legacy.put_u16(HEADER_SIZE, 0);
    legacy.put_u16(HEADER_SIZE + 2, 0);
    legacy.refresh_checksum();
    assert!(SlottedPage::from_bytes(legacy.to_bytes()).is_err());
    // The transition guards: only OCCUPIED retires, only RETIRED frees, never
    // on overflow pages.
    let mut page = page_with(2, 16);
    assert!(
        page.free_retired_slot(0).is_err(),
        "occupied cannot become FREE"
    );
    retire(&mut page, 0);
    assert!(page.retire_slot(0).is_err(), "RETIRED cannot retire again");
    free(&mut page, 0);
    assert!(page.free_retired_slot(0).is_err(), "FREE cannot free again");
    let mut overflow = SlottedPage::new_overflow(5);
    overflow.insert(&record(1, 64)).unwrap();
    overflow.delete(0).unwrap();
    assert!(
        overflow.free_retired_slot(0).is_err(),
        "overflow slots are never FREE"
    );
}

/// Part O 1/2: FREE is reused before the directory grows; RETIRED never is.
#[test]
fn k_allocator_reuses_free_slots_and_never_retired_ones() {
    let mut page = page_with(4, 32);
    retire(&mut page, 1);
    retire(&mut page, 2);
    page.compact().unwrap();
    // Only RETIRED entries: the directory grows.
    let slot = page.insert_ordinary(&record(0xaa, 32)).unwrap();
    assert_eq!(slot, 4, "RETIRED must never be reused");
    free(&mut page, 2);
    let slot = page.insert_ordinary(&record(0xbb, 32)).unwrap();
    assert_eq!(
        slot, 2,
        "the FREE slot is reused before the directory grows"
    );
    assert_eq!(page.get(2).unwrap().unwrap(), &record(0xbb, 32)[..]);
    assert_eq!(page.slot_state(1), SlotState::Retired);
    assert_eq!(page.slot_count(), 5);
    // No FREE slot left: the next insert appends and clears the hint.
    let slot = page.insert_ordinary(&record(0xcc, 32)).unwrap();
    assert_eq!(slot, 5);
    assert_eq!(page.flags() & PAGE_FLAG_FREE_SLOTS, 0);
    SlottedPage::from_bytes(page.to_bytes()).unwrap();
}

/// A FREE slot needs only the tuple bytes; an insufficient page is left
/// untouched by a failed allocation.
#[test]
fn k_free_slot_allocation_space_rules_and_failure_atomicity() {
    let mut page = SlottedPage::new_versioned(9);
    // Fill to the byte.
    let tuple = 100;
    while page.free_space() >= tuple + SLOT_SIZE {
        page.insert(&record(1, tuple)).unwrap();
    }
    retire(&mut page, 0);
    free(&mut page, 0);
    page.compact().unwrap();
    let before = page.to_bytes();
    // Larger than the reclaimed space: refused, page unchanged.
    let too_big = page.free_space() + 1;
    assert!(page.insert_ordinary(&record(2, too_big)).is_err());
    assert_eq!(page.to_bytes(), before);
    // Exactly the reclaimed space fits into the FREE slot (no new entry).
    let exact = page.free_space();
    assert_eq!(page.insert_ordinary(&record(3, exact)).unwrap(), 0);
    assert_eq!(page.free_space(), 0);
}

/// Part F: trailing FREE entries are trimmed; RETIRED/OCCUPIED never.
#[test]
fn k_trailing_free_entries_are_trimmed_only_at_the_end() {
    // FREE FREE FREE at the end -> all trimmed.
    let mut page = page_with(5, 24);
    for slot in 2..5 {
        retire(&mut page, slot);
        free(&mut page, slot);
    }
    assert_eq!(page.trim_trailing_free(), 3);
    assert_eq!(page.slot_count(), 2);
    assert_eq!(page.get_u16(24) as usize, HEADER_SIZE + 2 * SLOT_SIZE);
    page.refresh_checksum();
    SlottedPage::from_bytes(page.to_bytes()).unwrap();
    // FREE OCCUPIED FREE -> only the final FREE.
    let mut page = page_with(3, 24);
    for slot in [0, 2] {
        retire(&mut page, slot);
        free(&mut page, slot);
    }
    assert_eq!(page.trim_trailing_free(), 1);
    assert_eq!(
        states(&page),
        vec![SlotState::Free, SlotState::Occupied],
        "slot ids of the survivors are unchanged"
    );
    assert_ne!(page.flags() & PAGE_FLAG_FREE_SLOTS, 0);
    // RETIRED at the end -> nothing trimmed.
    let mut page = page_with(3, 24);
    retire(&mut page, 2);
    assert_eq!(page.trim_trailing_free(), 0);
    assert_eq!(page.slot_count(), 3);
    // FREE before a trailing RETIRED -> nothing trimmed.
    let mut page = page_with(3, 24);
    retire(&mut page, 1);
    free(&mut page, 1);
    retire(&mut page, 2);
    assert_eq!(page.trim_trailing_free(), 0);
    assert_eq!(
        states(&page),
        vec![SlotState::Occupied, SlotState::Free, SlotState::Retired]
    );
}

/// Part G: a page whose every slot is FREE becomes a fresh page; pages with
/// RETIRED or OCCUPIED slots, overflow pages and legacy pages never qualify.
#[test]
fn k_all_free_page_resets_to_a_fresh_page() {
    let mut page = page_with(4, 40);
    for slot in 0..4 {
        retire(&mut page, slot);
    }
    page.compact().unwrap();
    assert!(!page.all_slots_free(), "RETIRED blocks reset");
    for slot in 0..3 {
        free(&mut page, slot);
    }
    assert!(!page.all_slots_free());
    free(&mut page, 3);
    assert!(page.all_slots_free());
    let fresh = SlottedPage::new_versioned(page.page_id());
    // Trim alone already produces the fresh layout (empty directory).
    page.compact().unwrap();
    assert_eq!(page.trim_trailing_free(), 4);
    page.set_flag(PAGE_FLAG_RECLAIM_CANDIDATE, false);
    page.refresh_checksum();
    assert_eq!(page.slot_count(), 0);
    assert_eq!(page.free_space(), fresh.free_space());
    assert_eq!(page.to_bytes(), fresh.to_bytes());
    let mut occupied = page_with(1, 10);
    assert!(!occupied.all_slots_free());
    retire(&mut occupied, 0);
    assert!(!occupied.all_slots_free());
    let overflow = SlottedPage::new_overflow(2);
    assert!(!overflow.all_slots_free(), "overflow pages are never reset");
    let legacy = SlottedPage::new(2);
    assert!(!legacy.all_slots_free(), "legacy pages are never reset");
}

/// Part O 8: one slot reused thousands of times stays one slot.
#[test]
fn k_one_slot_reused_thousands_of_times_keeps_the_directory_bounded() {
    let mut page = page_with(10, 50);
    for round in 0..5000u32 {
        let slot = (round % 10) as u16;
        retire(&mut page, slot);
        page.compact().unwrap();
        free(&mut page, slot);
        let reused = page
            .insert_ordinary(&record((round % 251) as u8, 50))
            .unwrap();
        page.refresh_checksum();
        assert_eq!(reused, slot);
        assert_eq!(page.slot_count(), 10);
    }
    let page = SlottedPage::from_bytes(page.to_bytes()).unwrap();
    assert_eq!(page.slot_census().occupied, 10);
}

fn heap_schema() -> TableSchema {
    TableSchema {
        id: 1,
        name: "k".into(),
        columns: vec![ColumnSchema {
            name: "id".into(),
            data_type: DataType::Int64,
            nullable: false,
        }],
    }
}

/// `HeapTable::reclaim_lifecycle`: retire + free + trim + reset in one
/// private rewrite, with stale expectations refused and hints forgotten.
#[test]
fn k_heap_lifecycle_rewrite_retires_frees_trims_resets_and_refuses_guesses() {
    use crate::tuple_version::TupleVersion;
    use phobos_txn::mvcc::Version;
    let path = std::env::temp_dir().join(format!(
        "phobos-k-heap-{}-{}.heap",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    let scratch = path.with_extension("scratch");
    let mut heap = HeapTable::open_versioned(&path, heap_schema(), 8).unwrap();
    heap.begin_private(&scratch, 5, path.parent().unwrap())
        .unwrap();
    let tuple = |id: u64| TupleVersion {
        logical_row: id + 1,
        visibility: Version {
            creator: 5,
            deleter: None,
        },
        previous: None,
    };
    let mut rids = Vec::new();
    for id in 0..6u64 {
        rids.push(
            heap.insert_version(tuple(id), &Row::new(vec![Value::Int64(id as i64)]))
                .unwrap(),
        );
    }
    assert!(rids.iter().all(|rid| rid.page_id == 0));
    // A stale expectation aborts without changing anything.
    let wrong = LifecyclePage {
        page: 0,
        dead: vec![(0, tuple(99))],
        free: Vec::new(),
        keep_candidate: false,
    };
    assert!(heap.reclaim_lifecycle(&[wrong]).is_err());
    // Freeing an OCCUPIED slot is refused.
    let guess = LifecyclePage {
        page: 0,
        dead: Vec::new(),
        free: vec![1],
        keep_candidate: false,
    };
    assert!(heap.reclaim_lifecycle(&[guess]).is_err());
    // Retire 3..6, then free them: trailing trim back to 3 slots.
    let retire_tail = LifecyclePage {
        page: 0,
        dead: (3..6u64).map(|id| (id as u16, tuple(id))).collect(),
        free: Vec::new(),
        keep_candidate: false,
    };
    let delta = heap.prepare_lifecycle_delta(&retire_tail).unwrap().unwrap();
    let outcome = heap
        .reclaim_lifecycle_prepared(&[retire_tail], &BTreeMap::from([(0, delta)]))
        .unwrap();
    assert_eq!(outcome.retired, 3);
    // A slot retired by a pass can never be freed by the same pass.
    let same_pass = LifecyclePage {
        page: 0,
        dead: vec![(0, tuple(0))],
        free: vec![0],
        keep_candidate: false,
    };
    assert!(heap.reclaim_lifecycle(&[same_pass]).is_err());
    let free_tail = LifecyclePage {
        page: 0,
        dead: Vec::new(),
        free: vec![3, 4, 5],
        keep_candidate: false,
    };
    let delta = heap.prepare_lifecycle_delta(&free_tail).unwrap().unwrap();
    let outcome = heap
        .reclaim_lifecycle_prepared(&[free_tail], &BTreeMap::from([(0, delta)]))
        .unwrap();
    assert_eq!((outcome.freed, outcome.trimmed, outcome.reset), (3, 3, 0));
    let census = heap.page_census(0).unwrap().unwrap().2;
    assert_eq!((census.slots, census.occupied), (3, 3));
    // Hints of a slot are forgotten when it gets a new occupant.
    heap.hint_cache().merge(0, &[0xff]);
    let reused = heap
        .insert_version(tuple(7), &Row::new(vec![Value::Int64(7)]))
        .unwrap();
    assert_eq!(
        reused.slot_id, 3,
        "re-extension after trim reuses the number"
    );
    assert_eq!(heap.hint_cache().get(0, 3).bits(), 0);
    // Retire and free everything: the page resets to a fresh page.
    let all = LifecyclePage {
        page: 0,
        dead: vec![(0, tuple(0)), (1, tuple(1)), (2, tuple(2)), (3, tuple(7))],
        free: Vec::new(),
        keep_candidate: false,
    };
    heap.reclaim_lifecycle(&[all]).unwrap();
    let view = heap.page_lifecycle(0).unwrap().unwrap();
    assert_eq!(view.retired, vec![0, 1, 2, 3]);
    assert_ne!(
        view.flags & PAGE_FLAG_RECLAIM_CANDIDATE,
        0,
        "RETIRED keeps the page a candidate"
    );
    let reset = LifecyclePage {
        page: 0,
        dead: Vec::new(),
        free: vec![0, 1, 2, 3],
        keep_candidate: false,
    };
    let outcome = heap.reclaim_lifecycle(&[reset]).unwrap();
    assert_eq!(outcome.reset, 1);
    let (flags, overflow, census, free) = heap.page_census(0).unwrap().unwrap();
    assert_eq!((flags, overflow, census.slots), (0, false, 0));
    assert_eq!(free, PAGE_SIZE - HEADER_SIZE);
    heap.rollback_private().unwrap();
    drop(heap);
    let _ = std::fs::remove_file(&path);
    let _ = std::fs::remove_dir_all(&scratch);
}

#[test]
fn k5_prepared_lifecycle_rebases_after_foreground_insert() {
    use crate::tuple_version::TupleVersion;
    use phobos_txn::mvcc::Version;
    let path = std::env::temp_dir().join(format!(
        "phobos-k5-rebase-{}-{}.heap",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    let scratch = path.with_extension("scratch");
    let mut heap = HeapTable::open_versioned(&path, heap_schema(), 8).unwrap();
    heap.begin_private(&scratch, 5, path.parent().unwrap())
        .unwrap();
    let tuple = |id| TupleVersion {
        logical_row: id,
        visibility: Version {
            creator: 5,
            deleter: None,
        },
        previous: None,
    };
    let first = heap
        .insert_version(tuple(1), &Row::new(vec![Value::Int64(1)]))
        .unwrap();
    heap.insert_version(tuple(2), &Row::new(vec![Value::Int64(2)]))
        .unwrap();
    let plan = LifecyclePage {
        page: first.page_id,
        dead: vec![(first.slot_id, tuple(1))],
        free: vec![],
        keep_candidate: false,
    };
    let delta = heap.prepare_lifecycle_delta(&plan).unwrap().unwrap();
    let fresh = heap
        .insert_version(tuple(3), &Row::new(vec![Value::Int64(3)]))
        .unwrap();
    let prepared = BTreeMap::from([(first.page_id, delta)]);
    assert_eq!(
        heap.reclaim_lifecycle_prepared(std::slice::from_ref(&plan), &prepared)
            .unwrap()
            .retired,
        1
    );
    assert_eq!(
        heap.get_version(fresh).unwrap().unwrap().1.values,
        vec![Value::Int64(3)]
    );
    assert!(
        heap.reclaim_lifecycle_prepared(&[plan], &prepared).is_err(),
        "a stale patch cannot regress lifecycle state"
    );
    heap.rollback_private().unwrap();
    drop(heap);
    let _ = std::fs::remove_file(path);
}

/// Part E7 / O13: a FREE slot reused inside a private (uncommitted) image is
/// invisible to the committed file and comes back FREE after rollback; the
/// next transaction reuses it again.
#[test]
fn k_rollback_of_a_private_reuse_leaves_the_committed_free_slot_intact() {
    use crate::tuple_version::TupleVersion;
    use phobos_txn::mvcc::Version;
    let dir = std::env::temp_dir().join(format!(
        "phobos-k-rollback-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("table.heap");
    let schema = heap_schema();
    let tuple = |id: u64, creator: u64| TupleVersion {
        logical_row: id + 1,
        visibility: Version {
            creator,
            deleter: None,
        },
        previous: None,
    };
    // Committed base: 4 tuples, slot 1 FREE.
    let mut page = SlottedPage::new_versioned(0);
    for id in 0..4u64 {
        page.insert(
            &tuple(id, 2)
                .encode(&schema, &Row::new(vec![Value::Int64(id as i64)]))
                .unwrap(),
        )
        .unwrap();
    }
    retire(&mut page, 1);
    page.compact().unwrap();
    free(&mut page, 1);
    {
        let mut file = PageFile::open(&path).unwrap();
        file.append(&page).unwrap();
        file.sync().unwrap();
    }
    let committed = std::fs::read(&path).unwrap();
    let mut heap = HeapTable::open_versioned(&path, schema.clone(), 4).unwrap();
    heap.begin_private(&dir.join("private-1"), 9, &dir).unwrap();
    let rid = heap
        .insert_version(tuple(10, 9), &Row::new(vec![Value::Int64(10)]))
        .unwrap();
    assert_eq!(
        rid,
        RecordId {
            page_id: 0,
            slot_id: 1
        },
        "FREE slot reused"
    );
    heap.flush().unwrap();
    assert_eq!(
        std::fs::read(&path).unwrap(),
        committed,
        "base file untouched"
    );
    heap.rollback_private().unwrap();
    assert_eq!(std::fs::read(&path).unwrap(), committed);
    assert_eq!(
        heap.page_census(0).unwrap().unwrap().2,
        SlotCensus {
            slots: 4,
            occupied: 3,
            retired: 0,
            free: 1
        }
    );
    // The next transaction finds the same FREE slot.
    heap.begin_private(&dir.join("private-2"), 11, &dir)
        .unwrap();
    let again = heap
        .insert_version(tuple(11, 11), &Row::new(vec![Value::Int64(11)]))
        .unwrap();
    assert_eq!(again, rid);
    heap.rollback_private().unwrap();
    drop(heap);
    let _ = std::fs::remove_dir_all(&dir);
}
