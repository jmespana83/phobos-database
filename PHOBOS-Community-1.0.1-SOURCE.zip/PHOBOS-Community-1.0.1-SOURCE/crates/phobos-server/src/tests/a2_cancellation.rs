use super::*;
use phobos_client::Client;
use phobos_error::cancellation::{StatementContext, test_hooks};
use std::sync::mpsc;

type Worker = thread::JoinHandle<Result<(), PhobosError>>;
fn connection(
    coordinator: Arc<Coordinator>,
    auth: Option<Arc<AuthStore>>,
    hook: Option<test_hooks::Callback>,
) -> (Client, Worker) {
    let (address, worker) = listener(coordinator, auth, hook);
    let client = Client::connect(address).unwrap();
    client.set_io_timeout(Duration::from_secs(20)).unwrap();
    (client, worker)
}
fn listener(
    coordinator: Arc<Coordinator>,
    auth: Option<Arc<AuthStore>>,
    hook: Option<test_hooks::Callback>,
) -> (std::net::SocketAddr, Worker) {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let worker = thread::spawn(move || {
        let _hook = hook.map(test_hooks::register);
        let (socket, _) = listener.accept().unwrap();
        socket
            .set_write_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        let id = coordinator.new_session();
        // 0.2-H: the production plain-TCP transport (PHOBOS_TEST_PUMPED=1
        // runs these tests over the reader-thread transport instead).
        if std::env::var("PHOBOS_TEST_PUMPED").is_ok() {
            let mut stream = request_transport::Pumped::new(socket, coordinator.clone(), id)?;
            return session_requests(
                &mut stream,
                coordinator,
                id,
                auth,
                phobos_protocol::MAX_PAYLOAD,
            );
        }
        let mut stream = request_transport::Direct::new(socket, coordinator.clone(), id)?;
        session_requests(
            &mut stream,
            coordinator,
            id,
            auth,
            phobos_protocol::MAX_PAYLOAD,
        )
    });
    (address, worker)
}
fn gate(point: &'static str) -> (test_hooks::Callback, mpsc::Receiver<()>, mpsc::Sender<()>) {
    let (reached, receive) = mpsc::channel();
    let (resume, resumed) = mpsc::channel();
    let resumed = Mutex::new(resumed);
    let once = AtomicBool::new(false);
    (
        Arc::new(move |actual| {
            if actual == point && !once.swap(true, Ordering::SeqCst) {
                reached.send(()).unwrap();
                resumed
                    .lock()
                    .unwrap()
                    .recv_timeout(Duration::from_secs(20))
                    .unwrap();
            }
        }),
        receive,
        resume,
    )
}
fn clean(coordinator: Arc<Coordinator>, root: PathBuf) {
    assert_eq!(coordinator.cancellation.len(), 0);
    assert_eq!(coordinator.metrics.snapshot().active_sessions, 0);
    coordinator.shutdown().unwrap(); // Requires all statement pins and transactions to drain.
    drop(coordinator);
    phobos_admin::check_integrity(&root.join("mvcc")).unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a2_full_stack_cancel_authorization_isolation_write_atomicity_and_stream() {
    let (root, dir) = migrated_rows(512);
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    let mut auth = AuthStore::open(root.join("auth")).unwrap();
    for user in ["alice", "bob"] {
        auth.upsert_user(user, "a2-test-password", Role::Admin)
            .unwrap();
    }
    let auth = Arc::new(auth);
    let (mut control, control_worker) = connection(coordinator.clone(), Some(auth.clone()), None);
    let (mut other, other_worker) = connection(coordinator.clone(), Some(auth.clone()), None);
    let (mut anonymous, anonymous_worker) =
        connection(coordinator.clone(), Some(auth.clone()), None);
    control.authenticate("alice", "a2-test-password").unwrap();
    other.authenticate("bob", "a2-test-password").unwrap();
    assert_eq!(
        control.cancel(&"0".repeat(64)).unwrap_err().code,
        ErrorCode::CancellationTarget
    );
    for (sql, point, stream, explicit) in [
        (
            "SELECT id FROM t",
            "versioned_heap.scan_versions",
            false,
            false,
        ),
        ("UPDATE t SET v=v+10000", "writes.stage_sql", false, false),
        ("DELETE FROM t", "writes.stage_sql", false, true),
        (
            "SELECT id FROM t",
            "versioned_heap.scan_versions",
            true,
            false,
        ),
    ] {
        let (hook, reached, resume) = gate(point);
        let (mut query, worker) = connection(coordinator.clone(), Some(auth.clone()), Some(hook));
        query.authenticate("alice", "a2-test-password").unwrap();
        if explicit {
            query.query("BEGIN").unwrap();
            query.query("UPDATE t SET v=10001 WHERE id=1").unwrap();
        }
        if stream {
            query.negotiate_streaming().unwrap();
        }
        let handle = query.cancellation_handle().unwrap();
        let executing = thread::spawn(move || {
            let result = if stream {
                query.query_stream(sql, |_| Ok(())).map(|()| String::new())
            } else {
                query.query(sql)
            };
            (query, result)
        });
        reached.recv_timeout(Duration::from_secs(20)).unwrap();
        assert_eq!(
            anonymous.cancel(&handle).unwrap_err().code,
            ErrorCode::Authentication
        );
        assert_eq!(
            other.cancel(&handle).unwrap_err().code,
            ErrorCode::Authorization
        );
        assert_eq!(other.query("SELECT v FROM t WHERE id=1").unwrap(), "v\n1\n");
        control.cancel(&handle).unwrap();
        control.cancel(&handle).unwrap(); // Idempotent while target is active.
        resume.send(()).unwrap();
        let (mut query, result) = executing.join().unwrap();
        assert_eq!(
            result.unwrap_err().code,
            ErrorCode::StatementCancelled,
            "{sql}"
        );
        if explicit {
            assert!(query.query("COMMIT").is_err());
            query.query("ROLLBACK").unwrap();
        }
        if !stream {
            assert_eq!(
                query.query("SELECT COUNT(*) AS n FROM t").unwrap(),
                "n\n512\n"
            );
        }
        assert_eq!(
            control.cancel(&handle).unwrap_err().code,
            ErrorCode::CancellationTarget
        );
        assert_eq!(
            control.query("SELECT v FROM t WHERE id=1").unwrap(),
            "v\n1\n"
        );
        // Reacquiring a row changed before the cancelled write proves lease cleanup.
        control.query("UPDATE t SET v=1 WHERE id=1").unwrap();
        drop(query);
        worker.join().unwrap().unwrap();
        assert_eq!(coordinator.cancellation.len(), 0);
    }
    drop(control);
    drop(other);
    drop(anonymous);
    control_worker.join().unwrap().unwrap();
    other_worker.join().unwrap().unwrap();
    anonymous_worker.join().unwrap().unwrap();
    clean(coordinator, root);
}

#[test]
fn a2_operator_deadlines_atomicity_and_read_transaction_preservation() {
    let (root, dir) = migrated_rows(512);
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    let id = coordinator.new_session();
    coordinator
        .execute(id, "CREATE TABLE s (id BIGINT, v BIGINT)")
        .unwrap();
    coordinator
        .execute(id, "CREATE TABLE big (id BIGINT, v BIGINT)")
        .unwrap();
    for (name, count) in [("s", 512), ("big", 1536)] {
        coordinator
            .bulk_load(
                id,
                name,
                (0..count).map(|n| {
                    Ok(phobos_types::Row::new(vec![
                        phobos_types::Value::Int64(n),
                        phobos_types::Value::Int64(n),
                    ]))
                }),
            )
            .unwrap();
    }
    for (sql, point) in [
        ("SELECT id FROM t", "versioned_heap.scan_versions"),
        ("SELECT id FROM t WHERE id>=1", "lib.range_entry_visit"),
        (
            "SELECT t.id FROM t JOIN s ON t.id=s.id",
            "lib.hash_join_rows",
        ),
        (
            "SELECT t.id FROM t JOIN big ON t.id=big.id",
            "lib.hash_join_rows",
        ),
        ("SELECT id FROM big ORDER BY v DESC", "lib.compare_rows"),
        (
            "SELECT v,COUNT(*) AS n FROM t GROUP BY v",
            "lib.aggregate_relation",
        ),
        ("UPDATE t SET v=v+10000", "writes.stage_sql"),
        ("DELETE FROM t", "writes.stage_sql"),
        ("CREATE INDEX a2idx ON t(g)", "versioned_heap.scan_versions"),
        ("ANALYZE t", "lib.analyze_table"),
    ] {
        let observed = Arc::new(AtomicBool::new(false));
        let hit = observed.clone();
        let context = StatementContext::new(sql.into(), Some(Duration::from_secs(60)));
        let result = {
            let _context = context.enter();
            let _hook = test_hooks::register(Arc::new(move |actual| {
                if actual == point {
                    hit.store(true, Ordering::SeqCst);
                    test_hooks::expire_current();
                }
            }));
            coordinator.execute(id, sql)
        };
        assert!(
            observed.load(Ordering::SeqCst),
            "operator was not reached: {sql} {result:?}"
        );
        assert_eq!(
            result.unwrap_err().code,
            ErrorCode::StatementTimeout,
            "{sql}"
        );
        assert_eq!(
            coordinator
                .execute(id, "SELECT COUNT(*) AS n FROM t")
                .unwrap(),
            "n\n512\n"
        );
        assert_eq!(
            coordinator
                .execute(id, "SELECT v FROM t WHERE id=1")
                .unwrap(),
            "v\n1\n"
        );
    }
    coordinator.execute(id, "BEGIN").unwrap();
    coordinator
        .execute(id, "UPDATE t SET v=10001 WHERE id=1")
        .unwrap();
    let context = StatementContext::new("read".into(), None);
    {
        let _context = context.enter();
        let token = context.token.clone();
        let _hook = test_hooks::register(Arc::new(move |_| token.cancel()));
        assert_eq!(
            coordinator
                .execute(id, "SELECT id FROM t")
                .unwrap_err()
                .code,
            ErrorCode::StatementCancelled
        );
    }
    assert_eq!(
        coordinator
            .execute(id, "SELECT v FROM t WHERE id=1")
            .unwrap(),
        "v\n10001\n"
    );
    coordinator.execute(id, "ROLLBACK").unwrap();
    coordinator.disconnect(id);
    clean(coordinator, root);
}

#[test]
fn a2_disconnect_idle_transaction_rollback_and_commit_boundary() {
    let (root, dir) = migrated_rows(512);
    let coordinator = Arc::new(
        Coordinator::open(&dir)
            .unwrap()
            .with_timeouts(Duration::from_secs(60), Duration::from_millis(100)),
    );
    for transaction in [false, true] {
        let (mut client, worker) = connection(coordinator.clone(), None, None);
        if transaction {
            client.query("BEGIN").unwrap();
            client.query("UPDATE t SET v=10001 WHERE id=1").unwrap();
        }
        let result = worker.join().unwrap(); // Actual finite idle expiry, no timing assertion.
        assert_eq!(result.unwrap_err().code, ErrorCode::IdleTimeout);
        assert!(client.query("SELECT id FROM t").is_err());
        assert_eq!(coordinator.cancellation.len(), 0);
    }
    let (hook, reached, resume) = gate("versioned_heap.scan_versions");
    let (address, worker) = listener(coordinator.clone(), None, Some(hook));
    let mut socket = TcpStream::connect(address).unwrap();
    Frame::new(MessageType::Query, 1, b"SELECT id FROM t".to_vec())
        .write_to(&mut socket)
        .unwrap();
    reached.recv_timeout(Duration::from_secs(20)).unwrap();
    socket.shutdown(std::net::Shutdown::Both).unwrap();
    // EOF cancellation becomes visible while the operator is paused.
    let end = Instant::now() + Duration::from_secs(10);
    loop {
        let cancelled = coordinator.cancellation.any_cancelled();
        if cancelled {
            break;
        }
        assert!(Instant::now() < end);
        thread::yield_now();
    }
    resume.send(()).unwrap();
    let _closed = worker.join().unwrap();
    let id = coordinator.new_session();
    assert_eq!(
        coordinator
            .execute(id, "SELECT v FROM t WHERE id=1")
            .unwrap(),
        "v\n1\n"
    );
    coordinator
        .execute(id, "UPDATE t SET v=1 WHERE id=1")
        .unwrap();
    coordinator.disconnect(id);
    clean(coordinator, root);
}
#[test]
fn a2_cancel_before_and_after_irrevocable_commit_reports_true_outcome() {
    for before in [true, false] {
        let (root, dir) = migrated();
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let (mut writer, writer_worker) = connection(coordinator.clone(), None, None);
        let (mut control, control_worker) = connection(coordinator.clone(), None, None);
        writer.query("BEGIN").unwrap();
        writer.query("UPDATE t SET v=100 WHERE id=1").unwrap();
        let handle = writer.cancellation_handle().unwrap();
        let (signal, reached) = mpsc::channel();
        let (resume, resumed) = mpsc::channel();
        let resumed = Mutex::new(resumed);
        let boundary = if before {
            "a2_before_commit_admission"
        } else {
            "c6_private_preparation_begin"
        };
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == boundary {
                    signal.send(()).unwrap();
                    resumed
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(20))
                        .unwrap();
                }
            }),
        );
        let executing = thread::spawn(move || {
            let result = writer.query("COMMIT");
            (writer, result)
        });
        reached.recv_timeout(Duration::from_secs(20)).unwrap();
        control.cancel(&handle).unwrap();
        resume.send(()).unwrap();
        let (mut writer, result) = executing.join().unwrap();
        drop(hook);
        if before {
            assert_eq!(result.unwrap_err().code, ErrorCode::StatementCancelled);
            writer.query("ROLLBACK").unwrap();
        } else {
            assert!(result.unwrap().contains("COMMIT"));
        }
        assert_eq!(
            control.query("SELECT v FROM t WHERE id=1").unwrap(),
            if before { "v\n1\n" } else { "v\n100\n" }
        );
        assert_eq!(
            control.cancel(&handle).unwrap_err().code,
            ErrorCode::CancellationTarget
        );
        drop(writer);
        drop(control);
        writer_worker.join().unwrap().unwrap();
        control_worker.join().unwrap().unwrap();
        clean(coordinator, root);
    }
}

#[test]
fn a2_sixteen_clients_repeated_cancel_timeout_normal_idle_stress() {
    let (root, dir) = migrated_rows(512);
    let coordinator = Arc::new(
        Coordinator::open(&dir)
            .unwrap()
            .with_timeouts(Duration::from_secs(60), Duration::from_secs(2)),
    );
    for cycle in 0..3 {
        let (mut controller, controller_worker) = connection(coordinator.clone(), None, None);
        let barrier = Arc::new(Barrier::new(17));
        let mut clients = Vec::new();
        let mut cancelled = Vec::new();
        for n in 0..16 {
            let mode = n % 4;
            let hook = if mode == 0 {
                let (hook, reached, resume) = gate("versioned_heap.scan_versions");
                cancelled.push((reached, resume, String::new()));
                Some(hook)
            } else if mode == 1 {
                Some(Arc::new(|point: &str| {
                    if point == "versioned_heap.scan_versions" {
                        test_hooks::expire_current();
                    }
                }) as test_hooks::Callback)
            } else {
                None
            };
            let (mut client, worker) = connection(coordinator.clone(), None, hook);
            if mode == 0 {
                cancelled.last_mut().unwrap().2 = client.cancellation_handle().unwrap();
            }
            let barrier = barrier.clone();
            clients.push(thread::spawn(move || {
                barrier.wait();
                if mode == 3 {
                    assert_eq!(
                        worker.join().unwrap().unwrap_err().code,
                        ErrorCode::IdleTimeout
                    );
                    drop(client);
                } else {
                    let result = client.query(if mode == 2 {
                        "SELECT id FROM t WHERE id=1"
                    } else {
                        "SELECT id FROM t"
                    });
                    match mode {
                        0 => assert_eq!(result.unwrap_err().code, ErrorCode::StatementCancelled),
                        1 => assert_eq!(result.unwrap_err().code, ErrorCode::StatementTimeout),
                        _ => assert_eq!(result.unwrap(), "id\n1\n"),
                    }
                    assert_eq!(
                        client.query("SELECT id FROM t WHERE id=1").unwrap(),
                        "id\n1\n"
                    );
                    drop(client);
                    worker.join().unwrap().unwrap();
                }
            }));
        }
        barrier.wait();
        for (reached, resume, handle) in cancelled {
            reached.recv_timeout(Duration::from_secs(20)).unwrap();
            controller.cancel(&handle).unwrap();
            resume.send(()).unwrap();
        }
        drop(controller);
        controller_worker.join().unwrap().unwrap();
        for client in clients {
            client.join().unwrap();
        }
        assert_eq!(coordinator.cancellation.len(), 0, "cycle {cycle}");
        assert_eq!(coordinator.metrics.snapshot().active_sessions, 0);
        assert!(fs::read_dir(&dir).unwrap().all(|entry| {
            !entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill")
        }));
        let (mut later, worker) = connection(coordinator.clone(), None, None);
        assert_eq!(
            later.query("SELECT COUNT(*) AS n FROM t").unwrap(),
            "n\n512\n"
        );
        drop(later);
        worker.join().unwrap().unwrap();
    }
    clean(coordinator, root);
}

#[test]
fn a2_streamed_sort_join_aggregate_and_bulk_finalize_are_interruptible() {
    let (root, dir) = migrated_rows(1536);
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    // Bounded streams exercise spill creation/reading and cleanup, not just input scan.
    for (sql, point) in [
        ("SELECT id FROM t ORDER BY v DESC", "bounded_sort.finish"),
        (
            "SELECT v,COUNT(*) AS n FROM t GROUP BY v",
            "streaming_aggregate.push",
        ),
    ] {
        let observed = Arc::new(AtomicBool::new(false));
        let hit = observed.clone();
        let hook = Arc::new(move |actual: &str| {
            if actual == point {
                hit.store(true, Ordering::SeqCst);
                test_hooks::expire_current();
            }
        });
        let (mut client, worker) = connection(coordinator.clone(), None, Some(hook));
        client.negotiate_streaming().unwrap();
        assert_eq!(
            client.query_stream(sql, |_| Ok(())).unwrap_err().code,
            ErrorCode::StatementTimeout,
            "{sql}"
        );
        assert!(observed.load(Ordering::SeqCst));
        drop(client);
        worker.join().unwrap().unwrap();
        assert_eq!(coordinator.cancellation.len(), 0);
        assert!(fs::read_dir(&dir).unwrap().all(|entry| {
            !entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill")
        }));
    }
    let (mut client, worker) = connection(
        coordinator.clone(),
        None,
        Some(Arc::new(|point| {
            if point == "bulk.write_record" {
                test_hooks::expire_current();
            }
        })),
    );
    client.bulk_begin("t").unwrap();
    for first in (2000..2512).step_by(64) {
        client
            .bulk_batch(
                &(first..first + 64)
                    .map(|n| {
                        phobos_types::Row::new(vec![
                            phobos_types::Value::Int64(n),
                            phobos_types::Value::Int64(n),
                            phobos_types::Value::Int64(7),
                        ])
                    })
                    .collect::<Vec<_>>(),
            )
            .unwrap();
    }
    assert_eq!(
        client.query("COMMIT").unwrap_err().code,
        ErrorCode::StatementTimeout
    );
    client.query("ROLLBACK").unwrap();
    assert_eq!(
        client.query("SELECT COUNT(*) AS n FROM t").unwrap(),
        "n\n1536\n"
    );
    drop(client);
    worker.join().unwrap().unwrap();
    clean(coordinator, root);
}
#[test]
fn a2_real_statement_deadline_does_not_use_idle_deadline() {
    let (root, dir) = migrated_rows(512);
    let coordinator = Arc::new(
        Coordinator::open(&dir)
            .unwrap()
            .with_timeouts(Duration::from_millis(500), Duration::from_millis(100)),
    );
    let once = AtomicBool::new(false);
    let hook = Arc::new(move |point: &str| {
        if point == "versioned_heap.scan_versions" && !once.swap(true, Ordering::SeqCst) {
            let deadline = phobos_error::cancellation::current()
                .unwrap()
                .deadline
                .unwrap();
            thread::sleep(
                deadline.saturating_duration_since(Instant::now()) + Duration::from_millis(1),
            );
        }
    });
    let (mut client, worker) = connection(coordinator.clone(), None, Some(hook));
    assert_eq!(
        client.query("SELECT id FROM t").unwrap_err().code,
        ErrorCode::StatementTimeout
    );
    assert_eq!(
        client.query("SELECT id FROM t WHERE id=1").unwrap(),
        "id\n1\n"
    );
    drop(client);
    worker.join().unwrap().unwrap();
    clean(coordinator, root);
}
#[test]
fn a2_partial_frame_offsets_survive_reader_polling_and_tls_idle_closes() {
    let (root, dir) = migrated();
    let coordinator = Arc::new(
        Coordinator::open(&dir)
            .unwrap()
            .with_timeouts(Duration::from_secs(60), Duration::from_millis(600)),
    );
    let (address, worker) = listener(coordinator.clone(), None, None);
    let mut socket = TcpStream::connect(address).unwrap();
    socket
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let mut bytes = Vec::new();
    Frame::new(MessageType::Ping, 123, Vec::new())
        .write_to(&mut bytes)
        .unwrap();
    socket.write_all(&bytes[..8]).unwrap();
    // Cross an OS read polling interval while retaining a partial header.
    thread::sleep(Duration::from_millis(150));
    socket.write_all(&bytes[8..]).unwrap();
    let response = Frame::read_from(&mut socket).unwrap();
    assert_eq!(response.message_type, MessageType::Pong);
    assert_eq!(response.request_id, 123);
    socket.write_all(&bytes[..8]).unwrap();
    assert_eq!(
        worker.join().unwrap().unwrap_err().code,
        ErrorCode::IdleTimeout
    );
    drop(socket);
    let fixtures = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures");
    let config = load_tls_config(
        Some(&fixtures.join("server.pem")),
        Some(&fixtures.join("server-key.pem")),
        None,
        false,
    )
    .unwrap()
    .unwrap();
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let server = coordinator.clone();
    let worker = thread::spawn(move || {
        let (socket, _) = listener.accept().unwrap();
        socket
            .set_write_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        let id = server.new_session();
        let mut stream = request_transport::Pumped::tls(
            socket,
            ServerConnection::new(config).unwrap(),
            server.clone(),
            id,
        )
        .unwrap();
        session_requests(&mut stream, server, id, None, phobos_protocol::MAX_PAYLOAD)
    });
    let mut client = Client::connect_tls(address, "localhost", fixtures.join("ca.pem")).unwrap();
    assert_eq!(
        client.query("SELECT id FROM t WHERE id=1").unwrap(),
        "id\n1\n"
    );
    assert_eq!(
        worker.join().unwrap().unwrap_err().code,
        ErrorCode::IdleTimeout
    );
    drop(client);
    clean(coordinator, root);
}

#[test]
fn a2_legacy_group_tokens_are_isolated_and_cancelled_writes_roll_back() {
    let root = temp_dir("a2-legacy");
    let mut database = Database::open(&root).unwrap();
    database
        .execute("CREATE TABLE a (id BIGINT, v BIGINT)")
        .unwrap();
    database
        .execute("CREATE TABLE b (id BIGINT, v BIGINT)")
        .unwrap();
    let values = (0..512)
        .map(|n| format!("({n},{n})"))
        .collect::<Vec<_>>()
        .join(",");
    database
        .execute(&format!("INSERT INTO a VALUES {values}"))
        .unwrap();
    database
        .execute(&format!("INSERT INTO b VALUES {values}"))
        .unwrap();
    let cancelled = StatementContext::new("A".into(), None);
    let normal = StatementContext::new("B".into(), None);
    cancelled.token.cancel();
    let results = database.execute_independent_group_with_contexts(
        &["UPDATE a SET v=999", "UPDATE b SET v=999"],
        &[Some(cancelled), Some(normal)],
    );
    assert_eq!(
        results[0].as_ref().unwrap_err().code,
        ErrorCode::StatementCancelled
    );
    assert!(results[1].is_ok());
    assert_eq!(
        database
            .execute("SELECT v FROM a WHERE id=1")
            .unwrap()
            .to_text(),
        "v\n1\n"
    );
    assert_eq!(
        database
            .execute("SELECT v FROM b WHERE id=1")
            .unwrap()
            .to_text(),
        "v\n999\n"
    );
    drop(database);
    let coordinator = Arc::new(Coordinator::open(&root).unwrap());
    let (hook, reached, resume) = gate("lib.update");
    let armed = Arc::new(AtomicBool::new(false));
    let active = armed.clone();
    let hook = Arc::new(move |point: &str| {
        if active.load(Ordering::Acquire) {
            hook(point);
        }
    });
    let (mut writer, writer_worker) = connection(coordinator.clone(), None, Some(hook));
    let (mut controller, control_worker) = connection(coordinator.clone(), None, None);
    writer.query("BEGIN").unwrap();
    writer.query("UPDATE a SET v=77 WHERE id=1").unwrap();
    let handle = writer.cancellation_handle().unwrap();
    armed.store(true, Ordering::Release);
    let executing = thread::spawn(move || {
        let result = writer.query("UPDATE a SET v=v+1");
        (writer, result)
    });
    reached.recv_timeout(Duration::from_secs(20)).unwrap();
    controller.cancel(&handle).unwrap();
    resume.send(()).unwrap();
    let (writer, result) = executing.join().unwrap();
    assert_eq!(result.unwrap_err().code, ErrorCode::StatementCancelled);
    assert_eq!(
        controller.query("SELECT v FROM a WHERE id=1").unwrap(),
        "v\n1\n"
    );
    controller.query("UPDATE a SET v=1 WHERE id=1").unwrap();
    drop(writer);
    drop(controller);
    writer_worker.join().unwrap().unwrap();
    control_worker.join().unwrap().unwrap();
    assert_eq!(coordinator.cancellation.len(), 0);
    coordinator.shutdown().unwrap();
    drop(coordinator);
    phobos_admin::check_integrity(&root).unwrap();
    fs::remove_dir_all(root).unwrap();
}
