use super::*;
use std::{io::BufReader, time::Duration};

fn free_address() -> std::net::SocketAddr {
    let probe = TcpListener::bind("127.0.0.1:0").unwrap();
    probe.local_addr().unwrap()
}

fn connect(address: std::net::SocketAddr) -> phobos_client::Client {
    for _ in 0..100 {
        if let Ok(client) = phobos_client::Client::connect(address) {
            return client;
        }
        thread::sleep(Duration::from_millis(10));
    }
    panic!("server did not start")
}

#[test]
fn roles_password_auth_and_secret_safe_audit_are_enforced() {
    let root = temp_dir("g34-roles-audit");
    let auth_path = root.join("auth.phc");
    let audit_path = root.join("audit.jsonl");
    let mut auth = AuthStore::open(&auth_path).unwrap();
    auth.upsert_user("reader_one", "reader-password", Role::Reader)
        .unwrap();
    auth.upsert_user("writer_one", "writer-password", Role::Writer)
        .unwrap();
    auth.upsert_user("admin_one", "admin-password", Role::Admin)
        .unwrap();
    drop(auth);

    let address = free_address();
    let shutdown = root.join("shutdown.request");
    let mut settings = ServerSettings::alpha_default(address.to_string(), root.join("data"));
    settings.auth_file = Some(auth_path);
    settings.apply_config(RuntimeConfig {
        audit_enabled: true,
        audit_log_path: Some(audit_path.clone()),
        idle_timeout_ms: 10_000,
        ..Default::default()
    });
    let stop = shutdown.clone();
    let server = thread::spawn(move || serve_with_shutdown_file(settings, Some(stop)).unwrap());

    let mut admin = connect(address);
    admin.authenticate("admin_one", "admin-password").unwrap();
    admin
        .query("CREATE TABLE secured (id BIGINT NOT NULL)")
        .unwrap();

    let mut reader = connect(address);
    reader
        .authenticate("reader_one", "reader-password")
        .unwrap();
    reader.query("SELECT id FROM secured").unwrap();
    assert_eq!(
        reader
            .query("INSERT INTO secured VALUES (1)")
            .unwrap_err()
            .code,
        ErrorCode::Authorization
    );

    let mut writer = connect(address);
    writer
        .authenticate("writer_one", "writer-password")
        .unwrap();
    writer.query("INSERT INTO secured VALUES (2)").unwrap();
    assert_eq!(
        writer
            .query("CREATE TABLE forbidden (id BIGINT NOT NULL)")
            .unwrap_err()
            .code,
        ErrorCode::Authorization
    );
    drop((admin, reader, writer));
    fs::write(&shutdown, b"stop").unwrap();
    server.join().unwrap();

    let audit = fs::read_to_string(&audit_path).unwrap();
    let events = audit
        .lines()
        .map(|line| serde_json::from_str::<serde_json::Value>(line).unwrap())
        .collect::<Vec<_>>();
    assert!(audit.contains("\"principal\":\"admin_one\""));
    assert!(audit.contains("\"action\":\"CREATE\""));
    assert!(audit.contains("\"success\":false"));
    for secret in [
        "reader-password",
        "writer-password",
        "admin-password",
        "$argon2",
    ] {
        assert!(!audit.contains(secret));
    }
    let denials = events
        .iter()
        .filter(|event| event["success"] == false)
        .count();
    eprintln!(
        "G34_SECURITY audit_events={} authorization_denials={denials}",
        events.len()
    );
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn mandatory_mtls_maps_a_trusted_certificate_and_rejects_others() {
    let root = temp_dir("g34-mtls");
    let fixtures = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures");
    let mut certificate_file = BufReader::new(File::open(fixtures.join("g4-client.pem")).unwrap());
    let mut certificates = rustls_pemfile::certs(&mut certificate_file);
    let fingerprint = certificate_fingerprint(certificates.next().unwrap().unwrap().as_ref());
    let auth_path = root.join("auth.phc");
    let mut auth = AuthStore::open(&auth_path).unwrap();
    auth.upsert_user("cert_reader", "unused-password", Role::Reader)
        .unwrap();
    drop(auth);

    let address = free_address();
    let shutdown = root.join("shutdown.request");
    let mut settings = ServerSettings::alpha_default(address.to_string(), root.join("data"));
    settings.auth_file = Some(auth_path);
    settings.tls_cert = Some(fixtures.join("g4-server.pem"));
    settings.tls_key = Some(fixtures.join("g4-server-key.pem"));
    settings.apply_config(RuntimeConfig {
        mtls_required: true,
        client_ca_path: Some(fixtures.join("g4-ca.pem")),
        mtls_identities: BTreeMap::from([(fingerprint, "cert_reader".into())]),
        idle_timeout_ms: 10_000,
        ..Default::default()
    });
    let stop = shutdown.clone();
    let server = thread::spawn(move || serve_with_shutdown_file(settings, Some(stop)).unwrap());

    // Establish that the listener is ready before the TLS assertions.
    let mut plain = connect(address);
    plain.set_io_timeout(Duration::from_secs(2)).unwrap();
    assert!(plain.handshake().is_err());

    let mut trusted = phobos_client::Client::connect_mtls(
        address,
        "localhost",
        fixtures.join("g4-ca.pem"),
        fixtures.join("g4-client.pem"),
        fixtures.join("g4-client-key.pem"),
    )
    .unwrap();
    trusted.handshake().unwrap();
    trusted.query("SELECT * FROM phobos_metrics").unwrap();
    assert_eq!(
        trusted
            .query("CREATE TABLE forbidden (id BIGINT NOT NULL)")
            .unwrap_err()
            .code,
        ErrorCode::Authorization
    );

    let mut untrusted = phobos_client::Client::connect_mtls(
        address,
        "localhost",
        fixtures.join("g4-ca.pem"),
        fixtures.join("g4-untrusted-client.pem"),
        fixtures.join("g4-untrusted-client-key.pem"),
    )
    .unwrap();
    untrusted.set_io_timeout(Duration::from_secs(2)).unwrap();
    assert!(untrusted.handshake().is_err());
    drop(trusted);
    fs::write(&shutdown, b"stop").unwrap();
    server.join().unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn standby_marker_allows_reads_and_rejects_mutation() {
    let root = temp_dir("g34-read-only-standby");
    let coordinator = Coordinator::open(&root).unwrap();
    let session = coordinator.new_session();
    coordinator
        .execute(session, "CREATE TABLE stable (id BIGINT NOT NULL)")
        .unwrap();
    coordinator
        .execute(session, "INSERT INTO stable VALUES (1)")
        .unwrap();
    coordinator.shutdown().unwrap();
    drop(coordinator);
    fs::write(root.join("PHOBOS_STANDBY_1"), b"physical-read-only\n").unwrap();
    let coordinator = Coordinator::open(&root).unwrap();
    let session = coordinator.new_session();
    assert_eq!(
        coordinator
            .execute(session, "SELECT id FROM stable")
            .unwrap(),
        "id\n1\n"
    );
    assert_eq!(
        coordinator
            .execute(session, "INSERT INTO stable VALUES (2)")
            .unwrap_err()
            .code,
        ErrorCode::Authorization
    );
    coordinator.shutdown().unwrap();
    drop(coordinator);
    fs::remove_dir_all(root).unwrap();
}
