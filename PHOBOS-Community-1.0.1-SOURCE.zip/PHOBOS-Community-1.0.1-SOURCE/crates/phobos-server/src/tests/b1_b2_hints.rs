//! 0.1.9-B1/B2 through the full stack: hint activity, a committed delete,
//! restart (hints are cache-resident and vanish), offline integrity clean,
//! results identical before and after, and counters showing the second
//! stable scan resolves no transaction statuses.
use super::*;

#[test]
fn b1_b2_hint_activity_survives_reopen_with_integrity_and_identical_results() {
    let (root, dir) = migrated_rows(1000);
    let count = |db: &Coordinator, session: u64, sql: &str| -> i64 {
        db.execute(session, sql)
            .unwrap()
            .lines()
            .nth(1)
            .unwrap()
            .trim()
            .parse()
            .unwrap()
    };
    let expected_sum = (1..=1000i64).sum::<i64>();
    let mut before_restart = Vec::new();
    {
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        // 0.2-K: this test asserts exact database-wide status-resolution
        // counters; background reclamation resolves statuses too.
        db.stop_automatic_reclamation();
        let session = db.new_session();
        let m0 = db.status_metrics().unwrap();
        assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 1000);
        let m1 = db.status_metrics().unwrap();
        assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 1000);
        let m2 = db.status_metrics().unwrap();
        assert!(m1.status_lookups - m0.status_lookups >= 1000);
        assert!(
            (m2.status_lookups - m1.status_lookups) * 20 <= m1.status_lookups - m0.status_lookups
        );
        assert!(m2.hint_hits - m1.hint_hits >= 1000);
        // Committed delete: the deleter is resolved once, then hinted.
        db.execute(session, "DELETE FROM t WHERE id<=100").unwrap();
        assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 900);
        let m3 = db.status_metrics().unwrap();
        assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 900);
        let m4 = db.status_metrics().unwrap();
        assert_eq!(m4.status_lookups, m3.status_lookups, "{m3:?} {m4:?}");
        for sql in [
            "SELECT COUNT(*) AS n FROM t",
            "SELECT SUM(id) AS s FROM t",
            "SELECT v FROM t WHERE id=500",
            "SELECT COUNT(*) AS n FROM t WHERE id<=100",
        ] {
            before_restart.push(count(&db, session, sql));
        }
        assert_eq!(before_restart[1], expected_sum - (1..=100i64).sum::<i64>());
        db.disconnect(session);
        db.shutdown().unwrap();
        drop(db);
    }
    phobos_admin::check_integrity(&dir).unwrap();
    // After restart the cache-resident hints are gone: the first scan
    // resolves statuses again, the second is hinted again; results equal.
    let db = Arc::new(Coordinator::open(&dir).unwrap());
    db.stop_automatic_reclamation();
    let session = db.new_session();
    let m0 = db.status_metrics().unwrap();
    let mut after_restart = Vec::new();
    for sql in [
        "SELECT COUNT(*) AS n FROM t",
        "SELECT SUM(id) AS s FROM t",
        "SELECT v FROM t WHERE id=500",
        "SELECT COUNT(*) AS n FROM t WHERE id<=100",
    ] {
        after_restart.push(count(&db, session, sql));
    }
    assert_eq!(before_restart, after_restart);
    let m1 = db.status_metrics().unwrap();
    assert!(
        m1.status_lookups - m0.status_lookups >= 1000,
        "{m0:?} {m1:?}"
    );
    assert!(
        m1.status_page_reads - m0.status_page_reads >= 1,
        "{m0:?} {m1:?}"
    );
    assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 900);
    let m2 = db.status_metrics().unwrap();
    assert_eq!(m2.status_lookups, m1.status_lookups, "{m1:?} {m2:?}");
    assert!(m2.hint_hits - m1.hint_hits >= 1000);
    db.disconnect(session);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}
