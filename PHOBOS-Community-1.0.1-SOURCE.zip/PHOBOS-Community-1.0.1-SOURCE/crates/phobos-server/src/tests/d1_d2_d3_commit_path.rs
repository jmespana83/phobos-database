//! 0.1.9-D1/D2/D3 through the coordinator: read-only transactions cost no
//! identity and no force, writers commit through one WAL force, concurrent
//! COMMITs keep independent results, and the store stays integral across
//! restarts.
use super::*;

fn count(db: &Coordinator, session: u64, sql: &str) -> i64 {
    db.execute(session, sql)
        .unwrap()
        .lines()
        .nth(1)
        .unwrap()
        .trim()
        .parse()
        .unwrap()
}

#[test]
fn d1_d2_d3_coordinator_commit_path_counters_and_integrity() {
    let (root, dir) = migrated_rows(500);
    let db = Arc::new(Coordinator::open(&dir).unwrap());
    let reader = db.new_session();
    let before = db.commit_metrics().unwrap();
    // Read-only transactions: no identity, no status write, no force.
    for _ in 0..50 {
        db.execute(reader, "BEGIN").unwrap();
        assert_eq!(count(&db, reader, "SELECT COUNT(*) AS n FROM t"), 500);
        db.execute(reader, "COMMIT").unwrap();
        db.execute(reader, "BEGIN").unwrap();
        assert_eq!(count(&db, reader, "SELECT v FROM t WHERE id=5"), 5);
        db.execute(reader, "ROLLBACK").unwrap();
    }
    let after_reads = db.commit_metrics().unwrap();
    assert_eq!(after_reads.ids_allocated, before.ids_allocated);
    assert_eq!(after_reads.status_writes, before.status_writes);
    assert_eq!(after_reads.status_forces, before.status_forces);
    // One autocommit write: one identity, reserve + commit records, no
    // status-file force (the WAL force is the durability boundary).
    db.execute(reader, "INSERT INTO t VALUES (9000,9000,7)")
        .unwrap();
    let after_write = db.commit_metrics().unwrap();
    assert_eq!(after_write.ids_allocated, before.ids_allocated + 1);
    assert_eq!(after_write.status_writes, before.status_writes + 2);
    assert_eq!(after_write.status_forces, before.status_forces);
    // Eight clients commit concurrently; two of them fail a UNIQUE check at
    // statement time and are rolled back, the others commit. Every client
    // gets its own answer and nothing fences.
    let admission_before = db.admission_metrics().unwrap();
    let mut workers = Vec::new();
    for n in 0..8i64 {
        let db = db.clone();
        workers.push(thread::spawn(move || {
            let session = db.new_session();
            db.execute(session, "BEGIN").unwrap();
            let id = if n % 4 == 1 { 1 } else { 9100 + n };
            let staged = db.execute(
                session,
                &format!("INSERT INTO t VALUES ({id},{},7)", 9100 + n),
            );
            let outcome = match staged {
                Ok(_) => db.execute(session, "COMMIT").map(|_| true),
                Err(error) => {
                    assert!(matches!(
                        error.code,
                        ErrorCode::ConstraintViolation | ErrorCode::TransactionState
                    ));
                    assert!(db.execute(session, "COMMIT").is_err());
                    db.execute(session, "ROLLBACK").map(|_| false)
                }
            };
            db.disconnect(session);
            outcome.unwrap()
        }));
    }
    let committed = workers
        .into_iter()
        .map(|worker| worker.join().unwrap())
        .filter(|committed| *committed)
        .count();
    assert_eq!(committed, 6);
    assert_eq!(
        count(&db, reader, "SELECT COUNT(*) AS n FROM t WHERE id>=9100"),
        6
    );
    let admission_after = db.admission_metrics().unwrap();
    // D3: one committed view per write statement (the failed ones included).
    assert_eq!(admission_after.passes, admission_before.passes + 8);
    assert_eq!(
        admission_after.views_built,
        admission_before.views_built + 8
    );
    let after_group = db.commit_metrics().unwrap();
    assert_eq!(after_group.ids_allocated, after_write.ids_allocated + 8);
    assert_eq!(after_group.status_forces, before.status_forces);
    db.disconnect(reader);
    drop(db);
    // Restart without a checkpoint: every acknowledged commit is there, the
    // aborted ones are not, and the store is integral.
    let report = phobos_admin::check_integrity(&dir).unwrap();
    assert_eq!(report.tables, 1, "{report:?}");
    let db = Coordinator::open(&dir).unwrap();
    let session = db.new_session();
    assert_eq!(
        count(&db, session, "SELECT COUNT(*) AS n FROM t WHERE id>=9000"),
        7
    );
    assert_eq!(
        count(&db, session, "SELECT COUNT(*) AS n FROM t WHERE id=1"),
        1
    );
    db.execute(session, "CHECKPOINT").unwrap();
    db.disconnect(session);
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}
