//! 0.1.9-A1 through the full MVCC stack: the same logical join and grouping
//! must return identical rows on both sides of the join-strategy threshold
//! (1,024 right rows), through the text executor and the streaming executor.
use super::*;

#[derive(Default)]
struct Rows(Vec<phobos_types::Row>);
impl ResultSink for Rows {
    fn start(&mut self, _: Vec<String>) -> Result<(), PhobosError> {
        Ok(())
    }
    fn row(&mut self, row: phobos_types::Row) -> Result<(), PhobosError> {
        self.0.push(row);
        Ok(())
    }
    fn finish(&mut self) -> Result<(), PhobosError> {
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
        panic!("expected rows")
    }
}

fn sorted_stream(db: &Coordinator, session: u64, sql: &str) -> Vec<String> {
    let mut sink = Rows::default();
    db.execute_stream_result(session, sql, &mut sink).unwrap();
    let mut rows: Vec<String> = sink
        .0
        .iter()
        .map(|row| format!("{:?}", row.values))
        .collect();
    rows.sort();
    rows
}

#[test]
fn a1_mvcc_join_and_grouping_results_are_identical_across_the_strategy_threshold() {
    let (root, dir) = migrated();
    let db = Arc::new(Coordinator::open(&dir).unwrap());
    let session = db.new_session();
    db.execute(
        session,
        "CREATE TABLE l (k BIGINT NOT NULL, name TEXT NOT NULL)",
    )
    .unwrap();
    db.execute(session, "CREATE TABLE r (k DOUBLE, name TEXT NOT NULL)")
        .unwrap();
    db.execute(
        session,
        "INSERT INTO l VALUES (1,'one'),(0,'zero'),(9007199254740993,'big+1'),(9007199254740992,'big'),(-7,'neg'),(5,'five')",
    )
    .unwrap();
    let mut values: Vec<String> = (0..1_017)
        .map(|i| format!("({}.5,'filler{i}')", 1_000 + i))
        .collect();
    values.extend([
        "(1.0,'r-one')".to_string(),
        "(-0.0,'r-negzero')".to_string(),
        "(9007199254740992.0,'r-big')".to_string(),
        "(-7.0,'r-neg')".to_string(),
        "(1.0,'r-one-dup')".to_string(),
        "(NULL,'r-null')".to_string(),
        "(0.5,'r-half')".to_string(),
    ]);
    db.execute(
        session,
        &format!("INSERT INTO r VALUES {}", values.join(",")),
    )
    .unwrap();
    db.execute(session, "ANALYZE l").unwrap();
    db.execute(session, "ANALYZE r").unwrap();
    let queries = [
        "SELECT l.name, r.name FROM l JOIN r ON l.k = r.k ORDER BY l.name, r.name",
        "SELECT l.name, r.name FROM l LEFT JOIN r ON l.k = r.k ORDER BY l.name, r.name",
        "SELECT l.k, COUNT(*) AS n FROM l JOIN r ON l.k = r.k GROUP BY l.k ORDER BY l.k",
        "SELECT r.k, COUNT(*) AS n FROM r GROUP BY r.k ORDER BY n DESC, r.k LIMIT 4",
    ];
    let before: Vec<(String, Vec<String>)> = queries
        .iter()
        .map(|sql| {
            let text = db.execute(session, sql).unwrap();
            let streamed = sorted_stream(&db, session, sql);
            (text, streamed)
        })
        .collect();
    assert!(
        before[0].0.contains("one") && before[0].0.contains("r-one-dup"),
        "{}",
        before[0].0
    );
    assert!(
        before[0].0.contains("zero") && before[0].0.contains("r-negzero"),
        "{}",
        before[0].0
    );
    assert!(
        before[0].0.contains("big") && !before[0].0.contains("big+1"),
        "{}",
        before[0].0
    );
    assert!(
        before[0].0.contains("neg") && before[0].0.contains("r-neg"),
        "{}",
        before[0].0
    );
    // Cross the threshold: 1,025 right rows switch hash join to nested loop.
    db.execute(session, "INSERT INTO r VALUES (2999.5,'filler-1025')")
        .unwrap();
    db.execute(session, "ANALYZE r").unwrap();
    for (sql, (text, streamed)) in queries.iter().zip(&before) {
        assert_eq!(&db.execute(session, sql).unwrap(), text, "{sql}");
        assert_eq!(&sorted_stream(&db, session, sql), streamed, "{sql}");
    }
    db.disconnect(session);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}
