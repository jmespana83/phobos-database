//! 0.1.9-A4 through the full stack: a transaction far larger than its
//! spill threshold commits through the server, survives restart with the
//! offline integrity check clean, and an uncommitted spilled transaction
//! leaves nothing behind after shutdown.
use super::*;

#[test]
fn a4_spilled_transaction_commits_survives_reopen_and_integrity_check() {
    let (root, dir) = migrated_rows(1000);
    let spill_dirs = |dir: &Path| {
        fs::read_dir(dir)
            .unwrap()
            .map(|entry| entry.unwrap().path())
            .filter(|path| {
                path.file_name()
                    .unwrap()
                    .to_string_lossy()
                    .starts_with(".phobos-mvcc-writes-")
            })
            .count()
    };
    let count = |db: &Coordinator, session: u64, sql: &str| -> i64 {
        db.execute(session, sql)
            .unwrap()
            .lines()
            .nth(1)
            .unwrap()
            .trim()
            .parse()
            .unwrap()
    };
    {
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        // 4 KiB memtable: every statement below spills several sorted runs.
        db.set_write_spill(4096, 64 * 1024 * 1024).unwrap();
        let session = db.new_session();
        db.execute(session, "BEGIN").unwrap();
        for start in (2000..3000).step_by(200) {
            let values = (start..start + 200)
                .map(|id| format!("({id},{id},NULL)"))
                .collect::<Vec<_>>()
                .join(",");
            db.execute(session, &format!("INSERT INTO t VALUES {values}"))
                .unwrap();
        }
        // The composite UNIQUE c(v,g) makes a blanket v=v+1 collide within
        // the statement (pre-existing semantics); the new rows carry g=NULL.
        db.execute(session, "UPDATE t SET v=v+1 WHERE id>=2000")
            .unwrap();
        db.execute(session, "DELETE FROM t WHERE id>=2900").unwrap();
        assert_eq!(spill_dirs(&dir), 1);
        // Read-your-own-writes over the spilled image, other sessions unaffected.
        assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 1900);
        assert_eq!(count(&db, session, "SELECT v FROM t WHERE id=2500"), 2501);
        let other = db.new_session();
        assert_eq!(count(&db, other, "SELECT COUNT(*) AS n FROM t"), 1000);
        assert_eq!(count(&db, other, "SELECT v FROM t WHERE id=2"), 2);
        db.execute(session, "COMMIT").unwrap();
        assert_eq!(spill_dirs(&dir), 0);
        assert_eq!(count(&db, other, "SELECT COUNT(*) AS n FROM t"), 1900);
        assert_eq!(count(&db, other, "SELECT v FROM t WHERE id=2"), 2);
        assert_eq!(count(&db, other, "SELECT v FROM t WHERE id=2500"), 2501);
        assert_eq!(
            db.execute(other, "INSERT INTO t VALUES (2500,1,NULL)")
                .unwrap_err()
                .code,
            ErrorCode::ConstraintViolation
        );
        // A second spilled transaction is left uncommitted at shutdown.
        db.execute(session, "BEGIN").unwrap();
        db.execute(session, "UPDATE t SET v=v+100 WHERE id>=2000")
            .unwrap();
        assert_eq!(spill_dirs(&dir), 1);
        db.disconnect(other);
        db.disconnect(session);
        db.shutdown().unwrap();
        drop(db);
    }
    assert_eq!(spill_dirs(&dir), 0);
    phobos_admin::check_integrity(&dir).unwrap();
    for _ in 0..2 {
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        let session = db.new_session();
        assert_eq!(count(&db, session, "SELECT COUNT(*) AS n FROM t"), 1900);
        assert_eq!(
            count(&db, session, "SELECT SUM(v) AS s FROM t WHERE id>=2000"),
            (2000..2900).map(|id| id + 1).sum::<i64>()
        );
        assert_eq!(count(&db, session, "SELECT v FROM t WHERE id=2"), 2);
        assert_eq!(
            count(&db, session, "SELECT COUNT(*) AS n FROM t WHERE id>=2900"),
            0
        );
        db.disconnect(session);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}
