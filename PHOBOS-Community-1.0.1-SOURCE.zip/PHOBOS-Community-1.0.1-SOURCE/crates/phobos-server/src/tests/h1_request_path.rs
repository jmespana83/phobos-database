//! 0.2-H request path: the direct transport (the connection's worker reads,
//! executes and responds) and the forced reader-thread fallback, end to end
//! over TCP. Cancellation, disconnect, idle, partial-frame and shutdown cases
//! are covered by the a2/c6/g12 tests, which now run on the direct transport.
use super::*;
use phobos_client::Client;
use std::net::SocketAddr;

type Worker = thread::JoinHandle<Result<(), PhobosError>>;
fn serve_one(coordinator: Arc<Coordinator>, direct: bool) -> (SocketAddr, Worker) {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let worker = thread::spawn(move || {
        let (socket, _) = listener.accept().unwrap();
        socket
            .set_write_timeout(Some(Duration::from_secs(20)))
            .unwrap();
        let id = coordinator.new_session();
        let result = if direct {
            let mut stream = request_transport::Direct::new(socket, coordinator.clone(), id)?;
            session_requests(
                &mut stream,
                coordinator.clone(),
                id,
                None,
                phobos_protocol::MAX_PAYLOAD,
            )
        } else {
            let mut stream = request_transport::Pumped::new(socket, coordinator.clone(), id)?;
            session_requests(
                &mut stream,
                coordinator.clone(),
                id,
                None,
                phobos_protocol::MAX_PAYLOAD,
            )
        };
        coordinator.disconnect(id);
        result
    });
    (address, worker)
}
fn client(address: SocketAddr) -> Client {
    let client = Client::connect(address).unwrap();
    client.set_io_timeout(Duration::from_secs(20)).unwrap();
    client
}
fn finish(coordinator: Arc<Coordinator>, root: PathBuf) {
    coordinator.shutdown().unwrap();
    drop(coordinator);
    phobos_admin::check_integrity(&root.join("mvcc")).unwrap();
    fs::remove_dir_all(root).unwrap();
}

/// R1, R2, R17: the same request sequence over the direct and the forced
/// fallback transport; transaction state survives across requests.
#[test]
fn h_r1_direct_and_fallback_transports_serve_identical_sessions() {
    for direct in [true, false] {
        let (root, dir) = migrated();
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let (address, worker) = serve_one(coordinator.clone(), direct);
        let (other_address, other_worker) = serve_one(coordinator.clone(), direct);
        let mut session = client(address);
        let mut other = client(other_address);
        assert_eq!(
            session.query("SELECT v FROM t WHERE id=2").unwrap(),
            "v\n2\n"
        );
        session.query("BEGIN").unwrap();
        session.query("INSERT INTO t VALUES (10,10,1)").unwrap();
        assert_eq!(
            session.query("SELECT COUNT(*) AS n FROM t").unwrap(),
            "n\n4\n"
        );
        assert_eq!(
            other.query("SELECT COUNT(*) AS n FROM t").unwrap(),
            "n\n3\n"
        );
        session.query("COMMIT").unwrap();
        assert_eq!(
            other.query("SELECT COUNT(*) AS n FROM t").unwrap(),
            "n\n4\n"
        );
        drop(session);
        drop(other);
        worker.join().unwrap().unwrap();
        other_worker.join().unwrap().unwrap();
        finish(coordinator, root);
    }
}

/// R12, R13, R14: one response per request (nothing more arrives), a bad
/// header and an oversized length end the connection with the protocol error.
#[test]
fn h_r12_response_once_parse_error_and_oversized_frame() {
    let (root, dir) = migrated();
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    for (case, header) in [("magic", b"XXXX".to_vec()), ("size", Vec::new())] {
        let (address, worker) = serve_one(coordinator.clone(), true);
        let mut socket = TcpStream::connect(address).unwrap();
        socket
            .set_read_timeout(Some(Duration::from_millis(300)))
            .unwrap();
        Frame::new(
            MessageType::Query,
            7,
            b"SELECT v FROM t WHERE id=1".to_vec(),
        )
        .write_to(&mut socket)
        .unwrap();
        let response = Frame::read_from(&mut socket).unwrap();
        assert_eq!(
            (response.message_type, response.request_id),
            (MessageType::QueryResult, 7)
        );
        let mut probe = [0u8; 1];
        assert!(
            socket.read(&mut probe).is_err(),
            "a second response arrived"
        );
        let mut bad = [0u8; 16];
        let mut good = Vec::new();
        Frame::new(MessageType::Ping, 1, Vec::new())
            .write_to(&mut good)
            .unwrap();
        bad.copy_from_slice(&good[..16]);
        if case == "magic" {
            bad[..4].copy_from_slice(&header);
        } else {
            bad[12..16].copy_from_slice(&((phobos_protocol::MAX_PAYLOAD + 1) as u32).to_be_bytes());
        }
        socket.write_all(&bad).unwrap();
        let error = worker.join().unwrap().unwrap_err();
        assert_eq!(
            error.code,
            if case == "magic" {
                ErrorCode::InvalidProtocol
            } else {
                ErrorCode::FrameTooLarge
            },
            "{case}: {error}"
        );
        socket
            .set_read_timeout(Some(Duration::from_secs(5)))
            .unwrap();
        assert!(
            matches!(socket.read(&mut probe), Ok(0) | Err(_)),
            "connection must close"
        );
    }
    finish(coordinator, root);
}

/// R15: a request delivered one byte at a time, each byte after more than
/// one receive-timeout interval, is assembled intact.
#[test]
fn h_r15_frame_delivered_byte_by_byte_across_receive_timeouts() {
    let (root, dir) = migrated();
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    let (address, worker) = serve_one(coordinator.clone(), true);
    let mut socket = TcpStream::connect(address).unwrap();
    socket.set_nodelay(true).unwrap();
    socket
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let mut bytes = Vec::new();
    Frame::new(
        MessageType::Query,
        9,
        b"SELECT v FROM t WHERE id=3".to_vec(),
    )
    .write_to(&mut bytes)
    .unwrap();
    for (i, byte) in bytes.iter().enumerate() {
        socket.write_all(&[*byte]).unwrap();
        if i % 9 == 0 {
            thread::sleep(Duration::from_millis(120));
        }
    }
    let response = Frame::read_from(&mut socket).unwrap();
    assert_eq!(response.request_id, 9);
    assert_eq!(response.payload, b"v\n3\n");
    drop(socket);
    worker.join().unwrap().unwrap();
    finish(coordinator, root);
}

/// R8, R9, R16: a slow consumer of a large streamed result (backpressure on
/// the server's socket writes) does not delay 15 other sessions, and 16
/// concurrent sessions all complete with bounded spread.
#[test]
fn h_r8_slow_client_does_not_starve_fifteen_others() {
    let (root, dir) = migrated();
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    {
        // ~1.4 MB of rows: the streamed result needs many socket writes.
        let id = coordinator.new_session();
        coordinator
            .execute(
                id,
                "CREATE TABLE big (id BIGINT NOT NULL, payload TEXT NOT NULL)",
            )
            .unwrap();
        let values = (0..1500)
            .map(|i| format!("({i},'{}')", "x".repeat(900)))
            .collect::<Vec<_>>()
            .join(",");
        coordinator
            .execute(id, &format!("INSERT INTO big VALUES {values}"))
            .unwrap();
        coordinator.disconnect(id);
    }
    let (slow_address, slow_worker) = serve_one(coordinator.clone(), true);
    let mut slow = client(slow_address);
    slow.negotiate_streaming().unwrap();
    let (started, streaming) = std::sync::mpsc::channel();
    let slow_reader = thread::spawn(move || {
        let mut rows = 0u64;
        slow.query_stream("SELECT id, payload FROM big ORDER BY id", |event| {
            if let phobos_client::StreamEvent::Rows { rows: batch, .. } = event {
                if rows == 0 {
                    let _ = started.send(());
                }
                rows += batch.len() as u64;
                thread::sleep(Duration::from_millis(150));
            }
            Ok(())
        })
        .unwrap();
        drop(slow);
        rows
    });
    streaming.recv_timeout(Duration::from_secs(20)).unwrap();
    let barrier = Arc::new(std::sync::Barrier::new(15));
    let others = (0..15)
        .map(|k| {
            let (address, worker) = serve_one(coordinator.clone(), true);
            let barrier = barrier.clone();
            let handle = thread::spawn(move || {
                let mut session = client(address);
                barrier.wait();
                let started = Instant::now();
                for i in 0..40 {
                    session
                        .query(&format!(
                            "INSERT INTO t VALUES ({},{},1)",
                            100_000 + k * 1000 + i,
                            100_000 + k * 1000 + i
                        ))
                        .unwrap();
                }
                drop(session);
                started.elapsed()
            });
            (handle, worker)
        })
        .collect::<Vec<_>>();
    let mut times = Vec::new();
    for (handle, worker) in others {
        times.push(handle.join().unwrap());
        worker.join().unwrap().unwrap();
    }
    assert!(
        !slow_reader.is_finished(),
        "the slow stream must still be in progress"
    );
    let fastest = times.iter().min().unwrap().as_secs_f64();
    let slowest = times.iter().max().unwrap().as_secs_f64();
    assert!(
        slowest < 30.0 && slowest <= fastest * 20.0 + 2.0,
        "unfair: {times:?}"
    );
    assert_eq!(slow_reader.join().unwrap(), 1500);
    slow_worker.join().unwrap().unwrap();
    let id = coordinator.new_session();
    assert_eq!(
        coordinator
            .execute(id, "SELECT COUNT(*) AS n FROM t WHERE id>=100000")
            .unwrap(),
        "n\n600\n"
    );
    coordinator.disconnect(id);
    finish(coordinator, root);
}
