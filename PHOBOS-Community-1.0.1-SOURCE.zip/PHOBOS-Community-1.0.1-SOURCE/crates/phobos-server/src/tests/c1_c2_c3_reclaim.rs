//! 0.1.9-C1/C2/C3 through the full stack: UPDATE/DELETE churn with
//! CHECKPOINT-driven reclamation keeps heap and index files bounded, the
//! offline integrity check stays clean across restarts, and results are
//! identical before and after reopening.
use super::*;

fn pages(path: &Path) -> u64 {
    fs::metadata(path).unwrap().len() / 8192
}
fn count(db: &Coordinator, session: u64, sql: &str) -> i64 {
    db.execute(session, sql)
        .unwrap()
        .lines()
        .nth(1)
        .unwrap()
        .trim()
        .parse()
        .unwrap()
}
fn churn(db: &Coordinator, session: u64, rounds: i64, reclaim: bool) {
    for round in 1..=rounds {
        // c(v,g) is UNIQUE, so shift v by a stride that never collides.
        db.execute(
            session,
            &format!("UPDATE t SET v=id+{} WHERE id>3", round * 100_000),
        )
        .unwrap();
        db.execute(
            session,
            &format!("DELETE FROM t WHERE id>{}", 1000 - round * 50),
        )
        .unwrap();
        let values = (0..50)
            .map(|k| {
                let id = 1000 - round * 50 + k + 1;
                format!("({id},{},7)", id + round * 100_000)
            })
            .collect::<Vec<_>>()
            .join(",");
        db.execute(session, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
        if reclaim {
            db.execute(session, "CHECKPOINT").unwrap();
        }
    }
}

#[test]
fn c1_c2_c3_churn_reclaims_space_and_survives_reopen_with_integrity() {
    let mut sizes = Vec::new();
    let mut results = Vec::new();
    for reclaim in [false, true] {
        let (root, dir) = migrated_rows(1000);
        let heap = fs::read_dir(&dir)
            .unwrap()
            .map(|e| e.unwrap().path())
            .find(|p| {
                p.file_name()
                    .unwrap()
                    .to_string_lossy()
                    .starts_with("table-")
            })
            .unwrap();
        let indexes = fs::read_dir(&dir)
            .unwrap()
            .map(|e| e.unwrap().path())
            .filter(|p| p.extension().is_some_and(|e| e == "idx"))
            .collect::<Vec<_>>();
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        // Compare explicit CHECKPOINT reclamation with genuinely no reclaim;
        // otherwise the automatic worker races both sides of this A/B test.
        db.stop_automatic_reclamation();
        let session = db.new_session();
        let before = (pages(&heap), indexes.iter().map(|p| pages(p)).sum::<u64>());
        churn(&db, session, 6, reclaim);
        let report = if reclaim {
            // Drain whatever the bounded CHECKPOINT passes left behind.
            let mut last = db.reclaim_once(64).unwrap();
            for _ in 0..16 {
                if last.versions_reclaimed == 0 && last.candidates_remaining == 0 {
                    break;
                }
                last = db.reclaim_once(64).unwrap();
            }
            Some(last)
        } else {
            None
        };
        let snapshot = [
            count(&db, session, "SELECT COUNT(*) AS n FROM t"),
            count(&db, session, "SELECT SUM(v) AS s FROM t"),
            count(&db, session, "SELECT v FROM t WHERE id=500"),
            count(&db, session, "SELECT COUNT(*) AS n FROM t WHERE v>=600000"),
        ];
        db.disconnect(session);
        db.shutdown().unwrap();
        drop(db);
        let after = (pages(&heap), indexes.iter().map(|p| pages(p)).sum::<u64>());
        phobos_admin::check_integrity(&dir).unwrap();
        sizes.push((reclaim, before, after, report));
        // Reopen: identical results, integrity clean, reclamation still works.
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        let session = db.new_session();
        let again = [
            count(&db, session, "SELECT COUNT(*) AS n FROM t"),
            count(&db, session, "SELECT SUM(v) AS s FROM t"),
            count(&db, session, "SELECT v FROM t WHERE id=500"),
            count(&db, session, "SELECT COUNT(*) AS n FROM t WHERE v>=600000"),
        ];
        assert_eq!(snapshot, again);
        assert_eq!(
            db.execute(session, "INSERT INTO t VALUES (500,1,NULL)")
                .unwrap_err()
                .code,
            ErrorCode::ConstraintViolation
        );
        db.execute(session, "CHECKPOINT").unwrap();
        db.disconnect(session);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
        results.push(snapshot);
        fs::remove_dir_all(root).unwrap();
    }
    assert_eq!(results[0], results[1], "reclamation never changes results");
    let (_, plain_before, plain_after, _) = sizes[0];
    let (_, reclaimed_before, reclaimed_after, report) = sizes[1];
    eprintln!(
        "C2/C3 space: 6 churn rounds without reclaim heap {} -> {} pages, indexes {} -> {} pages; with CHECKPOINT reclaim heap {} -> {} pages, indexes {} -> {} pages; last pass {:?}",
        plain_before.0,
        plain_after.0,
        plain_before.1,
        plain_after.1,
        reclaimed_before.0,
        reclaimed_after.0,
        reclaimed_before.1,
        reclaimed_after.1,
        report
    );
    assert!(
        reclaimed_after.0 < plain_after.0,
        "heap pages: {reclaimed_after:?} vs {plain_after:?}"
    );
    assert!(
        reclaimed_after.1 <= plain_after.1,
        "index pages: {reclaimed_after:?} vs {plain_after:?}"
    );
}
