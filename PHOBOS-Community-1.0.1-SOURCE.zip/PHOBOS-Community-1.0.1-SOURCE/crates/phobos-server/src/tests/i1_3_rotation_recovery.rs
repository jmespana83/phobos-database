//! 0.2-I.3: an interrupted WAL segment rotation must recover through the
//! normal open path. A crash between `rename(phobos.wal -> sealed segment)`
//! and `rename(new active -> phobos.wal)` leaves sealed V2 history and no
//! active WAL. 0.2-I.2 routed such an MVCC database to the legacy engine
//! ("heap tuple capability mismatch"), and a page-LSN (non-MVCC V2) database
//! to the V1 WAL path, which created a V1 `phobos.wal` beside the V2 history.
//!
//! The crash state is produced exactly as `Wal::rotate_segment` produces it:
//! the active file of a database that was not shut down is renamed to
//! `phobos.wal.<its first LSN, 16 hex>.seg`. (The certification-build crash
//! point `v2_rotation_sealed` is exercised by the external harness.)
use super::*;
use phobos_execution::mvcc_runtime::MvccDatabase;
use std::time::Duration;

fn count_mvcc(db: &Coordinator, session: u64) -> String {
    db.execute(session, "SELECT COUNT(*) AS n FROM t")
        .unwrap()
        .lines()
        .nth(1)
        .unwrap_or("")
        .trim()
        .to_string()
}

/// Seal the active WAL the way an interrupted rotation leaves it.
fn interrupt_rotation(dir: &Path) {
    let active = dir.join("phobos.wal");
    let first = {
        let mut file = fs::File::open(&active).unwrap();
        phobos_wal::v2::read_record(&mut file).unwrap().unwrap().lsn
    };
    fs::rename(&active, dir.join(format!("phobos.wal.{first:016x}.seg"))).unwrap();
    assert!(!active.exists());
    assert!(phobos_wal::v2::interrupted_rotation(dir).unwrap());
}

/// MVCC database with 3 committed rows that exist only in the WAL (the
/// process ended without shutdown, as after a crash).
fn mvcc_crashed(label: &str) -> PathBuf {
    let root = temp_dir(label);
    fs::create_dir_all(&root).unwrap();
    let source = root.join("source");
    Database::open(&source)
        .unwrap()
        .execute("CREATE TABLE t (id BIGINT NOT NULL)")
        .unwrap();
    let dir = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    let db = MvccDatabase::open(&dir).unwrap();
    db.execute(1, "CREATE UNIQUE INDEX t_id ON t(id)").unwrap();
    db.execute(1, "CHECKPOINT").unwrap();
    for id in 1..=3 {
        db.execute(1, &format!("INSERT INTO t VALUES ({id})"))
            .unwrap();
    }
    db.disconnect(1);
    drop(db); // no shutdown: the commits are in the WAL only
    let report = phobos_wal::v2::inspect(dir.join("phobos.wal")).unwrap();
    assert!(report.committed_transactions >= 3);
    dir
}

/// I1/I2/I5: the normal server path routes to MVCC recovery, which performs
/// the existing `repair_interrupted_rotation`; every committed row survives.
#[test]
fn i1_3_interrupted_mvcc_rotation_recovers_through_coordinator_open() {
    let dir = mvcc_crashed("i1-3-mvcc");
    interrupt_rotation(&dir);
    assert!(MvccDatabase::is_capable(&dir).unwrap());
    let db = Coordinator::open(&dir).unwrap();
    let s = db.new_session();
    assert_eq!(count_mvcc(&db, s), "3");
    assert!(
        db.execute(s, "INSERT INTO t VALUES (2)")
            .unwrap_err()
            .message
            .contains("duplicate")
    );
    db.execute(s, "INSERT INTO t VALUES (4)").unwrap();
    db.disconnect(s);
    db.shutdown().unwrap();
    drop(db);
    // Repaired: an active WAL again, no sealed leftovers needed for recovery.
    assert!(dir.join("phobos.wal").exists());
    assert!(!phobos_wal::v2::interrupted_rotation(&dir).unwrap());
    phobos_admin::check_integrity(&dir).unwrap();
    let db = Coordinator::open(&dir).unwrap();
    let s = db.new_session();
    assert_eq!(count_mvcc(&db, s), "4");
    db.disconnect(s);
    db.shutdown().unwrap();
}

/// `phobos-admin check` routes the interrupted state to the MVCC check and
/// stays read-only: it recovers a scratch copy, never the source.
#[test]
fn i1_3_check_on_interrupted_rotation_is_mvcc_and_read_only() {
    let dir = mvcc_crashed("i1-3-check");
    interrupt_rotation(&dir);
    let before: Vec<_> = {
        let mut files: Vec<_> = fs::read_dir(&dir)
            .unwrap()
            .map(|entry| entry.unwrap().path())
            .filter(|path| path.is_file())
            .map(|path| (path.clone(), fs::read(path).unwrap()))
            .collect();
        files.sort();
        files
    };
    let report = phobos_admin::check_integrity(&dir).unwrap();
    assert_eq!((report.tables, report.indexes), (1, 1));
    for (path, bytes) in &before {
        assert_eq!(&fs::read(path).unwrap(), bytes, "check mutated {path:?}");
    }
    assert!(!dir.join("phobos.wal").exists());
}

/// I4: damaged sealed history is never guessed into either engine. The open
/// fails, and nothing is created or changed in the directory.
#[test]
fn i1_3_damaged_interrupted_rotation_fails_closed_without_side_effects() {
    let dir = mvcc_crashed("i1-3-damaged");
    interrupt_rotation(&dir);
    let sealed = fs::read_dir(&dir)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .find(|path| path.extension().is_some_and(|ext| ext == "seg"))
        .unwrap();
    let mut bytes = fs::read(&sealed).unwrap();
    let middle = bytes.iter().rposition(|byte| *byte != 0).unwrap() / 2;
    bytes[middle] ^= 0x5a;
    fs::write(&sealed, &bytes).unwrap();
    let listing = || {
        let mut names: Vec<_> = fs::read_dir(&dir)
            .unwrap()
            .map(|entry| entry.unwrap().file_name())
            .collect();
        names.sort();
        names
    };
    let before = listing();
    assert!(MvccDatabase::is_capable(&dir).is_err());
    assert!(Coordinator::open(&dir).is_err());
    assert!(Database::open(&dir).is_err());
    assert_eq!(listing(), before, "a failed open must not create files");
    assert!(!dir.join("phobos.wal").exists());
    assert!(!dir.join("phobos.wal.gen").exists());
    assert_eq!(fs::read(&sealed).unwrap(), bytes);
}

/// The same crash in a page-LSN (non-MVCC V2) database: it stays on the
/// legacy *engine* but recovers through V2 WAL recovery. 0.2-I.2 took the V1
/// path, which created a V1 `phobos.wal` and `phobos.wal.gen` beside the V2
/// history and then refused to serve it.
#[test]
fn i1_3_interrupted_page_lsn_rotation_stays_legacy_engine_and_recovers() {
    let dir = temp_dir("i1-3-page-lsn");
    {
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        for id in 1..=3 {
            db.execute(&format!("INSERT INTO t VALUES ({id})")).unwrap();
        }
    }
    assert_eq!(
        phobos_wal::v2::inspect(dir.join("phobos.wal"))
            .unwrap()
            .page_format,
        2
    );
    interrupt_rotation(&dir);
    assert!(!MvccDatabase::is_capable(&dir).unwrap());
    let db = Coordinator::open(&dir).unwrap();
    let s = db.new_session();
    assert_eq!(count_mvcc(&db, s), "3");
    db.disconnect(s);
    db.shutdown().unwrap();
    drop(db);
    assert!(!dir.join("phobos.wal.gen").exists());
    let mut prefix = [0; 6];
    std::io::Read::read_exact(
        &mut fs::File::open(dir.join("phobos.wal")).unwrap(),
        &mut prefix,
    )
    .unwrap();
    assert_eq!(&prefix, b"PHWL\x02\x00");
    phobos_admin::check_integrity(&dir).unwrap();
}

/// I3: true legacy (V1 WAL) databases keep selecting the legacy V1 path,
/// with or without a WAL file; segment-like junk with a non-segment name is
/// ignored, and a well-formed segment name holding junk fails closed.
#[test]
fn i1_3_legacy_v1_detection_is_unchanged_and_junk_fails_closed() {
    // V1 WAL present.
    let dir = temp_dir("i1-3-v1");
    fs::create_dir_all(&dir).unwrap();
    drop(phobos_wal::Wal::open(&dir).unwrap());
    {
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT)").unwrap();
        db.execute("INSERT INTO t VALUES (7)").unwrap();
        assert!(db.uses_legacy_v1_copy_engine());
    }
    assert!(!phobos_wal::v2::interrupted_rotation(&dir).unwrap());
    assert!(!MvccDatabase::is_capable(&dir).unwrap());
    fs::write(dir.join("phobos.wal.junk.seg"), b"not a segment").unwrap();
    // The V1 WAL is empty after its checkpoint, so it cannot vouch for its
    // format. A well-formed V2 segment name next to an empty WAL and
    // phobos.wal.gen is ambiguous (V1 data, or a V2 rotation an older binary
    // polluted through the V1 path): refused before any guess; nothing is
    // created.
    assert_eq!(fs::metadata(dir.join("phobos.wal")).unwrap().len(), 0);
    fs::write(dir.join("phobos.wal.0000000000000009.seg"), b"junk").unwrap();
    // (Empty WAL + phobos.wal.gen beside a sealed name: refused as ambiguous.)
    assert!(phobos_wal::v2::interrupted_rotation(&dir).is_err());
    assert!(Database::open(&dir).is_err());
    assert!(Coordinator::open(&dir).is_err());
    fs::remove_file(dir.join("phobos.wal.0000000000000009.seg")).unwrap();
    fs::write(dir.join("phobos.wal.0000000000000001.seg.bak"), b"junk").unwrap();
    assert!(!phobos_wal::v2::interrupted_rotation(&dir).unwrap());
    assert!(Database::open(&dir).unwrap().uses_legacy_v1_copy_engine());
    // V1 data without a WAL file (accepted by the legacy path) plus a file
    // that *looks* like a V2 segment but is junk: ambiguous, so it fails closed.
    fs::remove_file(dir.join("phobos.wal")).unwrap();
    assert!(Database::open(&dir).unwrap().uses_legacy_v1_copy_engine());
    fs::remove_file(dir.join("phobos.wal")).unwrap();
    let _ = fs::remove_file(dir.join("phobos.wal.gen"));
    fs::write(dir.join("phobos.wal.0000000000000001.seg"), b"junk").unwrap();
    assert!(phobos_wal::v2::interrupted_rotation(&dir).unwrap());
    assert!(MvccDatabase::is_capable(&dir).is_err());
    assert!(Coordinator::open(&dir).is_err());
    assert!(Database::open(&dir).is_err());
    assert!(!dir.join("phobos.wal").exists());
}

/// I6: a normal MVCC database (active WAL present) is not affected: the
/// detection helper is false and capability is unchanged.
#[test]
fn i1_3_normal_mvcc_database_detection_is_unchanged() {
    let dir = mvcc_crashed("i1-3-normal");
    assert!(!phobos_wal::v2::interrupted_rotation(&dir).unwrap());
    assert!(MvccDatabase::is_capable(&dir).unwrap());
    let db = MvccDatabase::open(&dir).unwrap();
    db.shutdown(Duration::from_secs(10)).unwrap();
}

/// Page-LSN database whose interrupted rotation an older binary opened
/// through the V1 WAL path (creating an empty `phobos.wal` and
/// `phobos.wal.gen`): refused as ambiguous with no change; after the
/// documented operator step it recovers with every committed row.
#[test]
fn i1_3_polluted_page_lsn_rotation_is_refused_then_recovers_after_operator_step() {
    let dir = temp_dir("i1-3-polluted");
    {
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        for id in 1..=3 {
            db.execute(&format!("INSERT INTO t VALUES ({id})")).unwrap();
        }
    }
    interrupt_rotation(&dir);
    // What the 0.2-I.2 V1 fallback left behind (phobos_wal::Wal::open).
    drop(phobos_wal::Wal::open(&dir).unwrap());
    assert_eq!(fs::metadata(dir.join("phobos.wal")).unwrap().len(), 0);
    assert!(dir.join("phobos.wal.gen").exists());
    let listing = || {
        let mut names: Vec<_> = fs::read_dir(&dir)
            .unwrap()
            .map(|entry| entry.unwrap().file_name())
            .collect();
        names.sort();
        names
    };
    let before = listing();
    let error = match Coordinator::open(&dir) {
        Ok(_) => panic!("ambiguous layout must be refused"),
        Err(error) => error,
    };
    assert!(error.message.contains("ambiguous WAL layout"), "{error:?}");
    assert!(Database::open(&dir).is_err());
    assert_eq!(listing(), before);
    // Operator step from the message.
    fs::remove_file(dir.join("phobos.wal")).unwrap();
    fs::remove_file(dir.join("phobos.wal.gen")).unwrap();
    let db = Coordinator::open(&dir).unwrap();
    let s = db.new_session();
    assert_eq!(count_mvcc(&db, s), "3");
    db.disconnect(s);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
}

/// A V1->V2 migrated database keeps `phobos.wal.gen` forever; an ordinary
/// interrupted rotation there (no active file) still recovers automatically.
#[test]
fn i1_3_interrupted_rotation_with_leftover_generation_file_recovers() {
    let dir = temp_dir("i1-3-gen");
    {
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        db.execute("INSERT INTO t VALUES (1)").unwrap();
        db.execute("INSERT INTO t VALUES (2)").unwrap();
    }
    fs::write(dir.join("phobos.wal.gen"), b"PHWG\x01\x00").unwrap();
    interrupt_rotation(&dir);
    let db = Coordinator::open(&dir).unwrap();
    let s = db.new_session();
    assert_eq!(count_mvcc(&db, s), "2");
    db.disconnect(s);
    db.shutdown().unwrap();
}
