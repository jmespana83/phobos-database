use super::*;
use std::time::{Duration, Instant};

#[test]
fn metrics_virtual_relation_is_stable_and_side_effect_free() {
    let root = temp_dir("g12-metrics");
    let coordinator = Coordinator::open(&root).unwrap();
    let before = coordinator.metrics().snapshot();
    let mut prepared = BTreeMap::new();
    let text = execute_session_query(
        &coordinator,
        coordinator.new_session(),
        Role::Admin,
        "SELECT * FROM phobos_metrics",
        &mut prepared,
        &coordinator.metrics(),
    )
    .unwrap();
    assert!(text.starts_with("name\tvalue\tkind\n"));
    assert!(text.contains("active_connections\t0\tgauge\n"));
    assert_eq!(coordinator.metrics().snapshot(), before);
    coordinator.shutdown().unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn prepared_reads_reuse_ast_deallocate_and_replan_after_ddl() {
    let root = temp_dir("g12-prepared");
    let coordinator = Coordinator::open(&root).unwrap();
    let session = coordinator.new_session();
    coordinator
        .execute(session, "CREATE TABLE t (id BIGINT NOT NULL, value TEXT)")
        .unwrap();
    coordinator
        .execute(session, "INSERT INTO t VALUES (1,'one'),(2,'two')")
        .unwrap();
    let mut prepared = BTreeMap::new();
    let metrics = coordinator.metrics();
    assert_eq!(
        execute_session_query(
            &coordinator,
            session,
            Role::Admin,
            "PREPARE point AS SELECT value FROM t WHERE id = 2",
            &mut prepared,
            &metrics,
        )
        .unwrap(),
        "PREPARE 0"
    );
    for _ in 0..2 {
        assert_eq!(
            execute_session_query(
                &coordinator,
                session,
                Role::Admin,
                "EXECUTE point",
                &mut prepared,
                &metrics,
            )
            .unwrap(),
            "value\ntwo\n"
        );
    }
    assert_eq!(metrics.snapshot().prepared_executions, 2);
    let cancelled =
        phobos_error::cancellation::StatementContext::new("prepared-cancel".into(), None);
    cancelled.token.cancel();
    {
        let _scope = cancelled.enter();
        assert_eq!(
            execute_session_query(
                &coordinator,
                session,
                Role::Admin,
                "EXECUTE point",
                &mut prepared,
                &metrics,
            )
            .unwrap_err()
            .code,
            ErrorCode::StatementCancelled
        );
    }
    let timed_out = phobos_error::cancellation::StatementContext::new(
        "prepared-timeout".into(),
        Some(Duration::ZERO),
    );
    {
        let _scope = timed_out.enter();
        assert_eq!(
            execute_session_query(
                &coordinator,
                session,
                Role::Admin,
                "EXECUTE point",
                &mut prepared,
                &metrics,
            )
            .unwrap_err()
            .code,
            ErrorCode::StatementTimeout
        );
    }
    coordinator
        .execute(session, "CREATE INDEX idx_t_id ON t (id)")
        .unwrap();
    execute_session_query(
        &coordinator,
        session,
        Role::Admin,
        "EXECUTE point",
        &mut prepared,
        &metrics,
    )
    .unwrap();
    assert_eq!(metrics.snapshot().prepared_replans, 1);
    execute_session_query(
        &coordinator,
        session,
        Role::Admin,
        "DEALLOCATE point",
        &mut prepared,
        &metrics,
    )
    .unwrap();
    assert!(
        execute_session_query(
            &coordinator,
            session,
            Role::Admin,
            "EXECUTE point",
            &mut prepared,
            &metrics,
        )
        .is_err()
    );
    coordinator.disconnect(session);
    coordinator.shutdown().unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn four_workers_service_twelve_connections_and_shutdown_cleanly() {
    let root = temp_dir("g12-worker-acceptance");
    let probe = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = probe.local_addr().unwrap();
    drop(probe);
    let shutdown = root.join("shutdown.request");
    let mut settings = ServerSettings::alpha_default(address.to_string(), root.join("data"));
    settings.apply_config(RuntimeConfig {
        worker_threads: 4,
        max_connections: 16,
        slow_query_ms: 1,
        log_format: phobos_config::LogFormat::Json,
        idle_timeout_ms: 10_000,
        ..Default::default()
    });
    let shutdown_for_server = shutdown.clone();
    let server = thread::spawn(move || {
        serve_with_shutdown_file(settings, Some(shutdown_for_server)).unwrap()
    });
    let connect = || {
        for _ in 0..100 {
            if let Ok(client) = phobos_client::Client::connect(address) {
                return client;
            }
            thread::sleep(Duration::from_millis(10));
        }
        panic!("server did not start")
    };

    let mut setup = connect();
    setup
        .query("CREATE TABLE points (id BIGINT NOT NULL, value TEXT)")
        .unwrap();
    setup
        .query("CREATE TABLE cancelled_queue (id BIGINT NOT NULL)")
        .unwrap();
    let values = (0..2_000)
        .map(|id| format!("({id},'value-{id}')"))
        .collect::<Vec<_>>()
        .join(",");
    setup
        .query(&format!("INSERT INTO points VALUES {values}"))
        .unwrap();
    setup
        .query("CREATE INDEX idx_points_id ON points (id)")
        .unwrap();
    let plain_started = Instant::now();
    for _ in 0..20 {
        setup
            .query("SELECT value FROM points WHERE id=1999")
            .unwrap();
    }
    let plain = plain_started.elapsed();
    setup
        .query("PREPARE point AS SELECT value FROM points WHERE id=1999")
        .unwrap();
    let prepared_started = Instant::now();
    for _ in 0..20 {
        setup.query("EXECUTE point").unwrap();
    }
    let prepared_time = prepared_started.elapsed();
    setup.query("DEALLOCATE point").unwrap();
    let setup_metrics = setup.query("SELECT * FROM phobos_metrics").unwrap();
    assert!(setup_metrics.contains("prepared_executions\t20\tcounter"));
    let slow_count = setup_metrics
        .lines()
        .find(|line| line.starts_with("slow_query_count\t"))
        .and_then(|line| line.split('\t').nth(1))
        .and_then(|value| value.parse::<u64>().ok())
        .unwrap();
    assert!(slow_count >= 1);
    eprintln!(
        "G12_ACCEPTANCE plain_20_us={} prepared_20_us={} slow_events={slow_count}",
        plain.as_micros(),
        prepared_time.as_micros()
    );
    drop(setup);

    // Four persistent idle clients occupy the bounded connection workers.
    let mut blockers = Vec::new();
    for _ in 0..4 {
        let mut client = connect();
        assert!(client.query("SELECT * FROM phobos_metrics").is_ok());
        blockers.push(client);
    }
    // A complete request abandoned while queued must never execute later.
    let mut abandoned = TcpStream::connect(address).unwrap();
    Frame::new(
        MessageType::Query,
        1,
        b"INSERT INTO cancelled_queue VALUES (1)".to_vec(),
    )
    .write_to(&mut abandoned)
    .unwrap();
    abandoned.shutdown(std::net::Shutdown::Both).unwrap();
    drop(abandoned);
    // Eight additional accepted connections wait in the bounded queue and
    // make progress after the first four release their slots.
    let mut queued = Vec::new();
    for _ in 0..8 {
        queued.push(thread::spawn(move || {
            let mut client = phobos_client::Client::connect(address).unwrap();
            client.query("SELECT * FROM phobos_metrics").unwrap()
        }));
    }
    thread::sleep(Duration::from_millis(100));
    drop(blockers);
    let results = queued
        .into_iter()
        .map(|worker| worker.join().unwrap())
        .collect::<Vec<_>>();
    assert!(
        results
            .iter()
            .all(|text| text.contains("peak_active_workers\t4\tcounter")
                || text.contains("peak_active_workers\t4\tgauge"))
    );
    let mut verifier = connect();
    assert_eq!(
        verifier
            .query("SELECT COUNT(*) AS n FROM cancelled_queue")
            .unwrap(),
        "n\n0\n"
    );
    drop(verifier);
    std::fs::write(&shutdown, b"stop").unwrap();
    server.join().unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn network_role_limits_reject_release_and_isolate_roles() {
    let root = temp_dir("g12-role-acceptance");
    let auth_path = root.join("auth.phc");
    let mut auth = AuthStore::open(&auth_path).unwrap();
    auth.upsert_user("reader_one", "reader-password", Role::Reader)
        .unwrap();
    auth.upsert_user("writer_one", "writer-password", Role::Writer)
        .unwrap();
    drop(auth);
    let probe = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = probe.local_addr().unwrap();
    drop(probe);
    let shutdown = root.join("shutdown.request");
    let mut settings = ServerSettings::alpha_default(address.to_string(), root.join("data"));
    settings.auth_file = Some(auth_path);
    settings.apply_config(RuntimeConfig {
        worker_threads: 4,
        max_connections: 8,
        role_connection_limits: BTreeMap::from([("reader".into(), 1), ("writer".into(), 2)]),
        idle_timeout_ms: 10_000,
        ..Default::default()
    });
    let shutdown_for_server = shutdown.clone();
    let server = thread::spawn(move || {
        serve_with_shutdown_file(settings, Some(shutdown_for_server)).unwrap()
    });
    let connect = || {
        for _ in 0..100 {
            if let Ok(client) = phobos_client::Client::connect(address) {
                return client;
            }
            thread::sleep(Duration::from_millis(10));
        }
        panic!("server did not start")
    };
    let mut reader = connect();
    reader
        .authenticate("reader_one", "reader-password")
        .unwrap();
    let mut rejected = connect();
    assert!(
        rejected
            .authenticate("reader_one", "reader-password")
            .is_err()
    );
    let mut writer = connect();
    writer
        .authenticate("writer_one", "writer-password")
        .unwrap();
    drop(rejected);
    drop(reader);
    thread::sleep(Duration::from_millis(200));
    let mut replacement = connect();
    replacement
        .authenticate("reader_one", "reader-password")
        .unwrap();
    drop(replacement);
    drop(writer);
    std::fs::write(&shutdown, b"stop").unwrap();
    server.join().unwrap();
    fs::remove_dir_all(root).unwrap();
}
