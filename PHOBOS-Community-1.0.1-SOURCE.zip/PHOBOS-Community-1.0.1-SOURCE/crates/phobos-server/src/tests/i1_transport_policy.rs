//! 0.2-I: request transport policy (auto / direct / pumped, resolved once per
//! server), Direct/Pumped parity of the 0.2-H engine paths over a real TCP
//! server, and shutdown-marker robustness.
use super::*;
use std::time::Duration;

#[test]
fn i_policy_parse_accepts_three_values_and_rejects_everything_else() {
    assert_eq!(RequestPath::parse(None).unwrap(), RequestPath::Auto);
    for (raw, expected) in [
        ("auto", RequestPath::Auto),
        ("AUTO", RequestPath::Auto),
        ("direct", RequestPath::Direct),
        ("Direct", RequestPath::Direct),
        ("pumped", RequestPath::Pumped),
        (" pumped ", RequestPath::Pumped), // cmd.exe `set X=pumped ` keeps the space
    ] {
        assert_eq!(RequestPath::parse(Some(raw)).unwrap(), expected, "{raw:?}");
    }
    for raw in [
        "",
        " ",
        "fast",
        "pump",
        "direct,pumped",
        "0",
        "1",
        "threaded",
    ] {
        let error = RequestPath::parse(Some(raw)).unwrap_err();
        assert_eq!(error.code, ErrorCode::ResourceLimit, "{raw:?}");
        assert!(
            error.message.contains(REQUEST_PATH_ENV)
                && error.message.contains("expected auto, direct or pumped"),
            "{error}"
        );
    }
}

#[test]
fn i_policy_resolution_matrix() {
    use Platform::*;
    use RequestPath::*;
    // Auto: Windows -> Pumped, Linux / other Unix -> Direct.
    assert_eq!(Auto.resolve(Windows, false), ResolvedPath::Pumped);
    assert_eq!(Auto.resolve(Linux, false), ResolvedPath::Direct);
    assert_eq!(Auto.resolve(OtherUnix, false), ResolvedPath::Direct);
    // Explicit overrides win on every platform.
    for platform in [Windows, Linux, OtherUnix] {
        assert_eq!(Direct.resolve(platform, false), ResolvedPath::Direct);
        assert_eq!(Pumped.resolve(platform, false), ResolvedPath::Pumped);
        // TLS is always Pumped (Direct cannot read rustls' plaintext).
        for policy in [Auto, Direct, Pumped] {
            assert_eq!(policy.resolve(platform, true), ResolvedPath::Pumped);
        }
    }
    // This build's own platform.
    let expected = if cfg!(windows) {
        ResolvedPath::Pumped
    } else {
        ResolvedPath::Direct
    };
    assert_eq!(Auto.resolve(Platform::current(), false), expected);
}

#[test]
fn i_shutdown_marker_transient_errors_are_windows_sharing_violations_only() {
    let raw = io::Error::from_raw_os_error;
    for code in [5, 32, 33] {
        assert!(transient_marker_error(&raw(code), true), "{code}");
        // On Unix the same numbers mean other things (e.g. 32 = EPIPE).
        assert!(!transient_marker_error(&raw(code), false), "{code}");
    }
    for code in [2, 3, 6, 87, 112] {
        assert!(!transient_marker_error(&raw(code), true), "{code}");
    }
    assert!(!transient_marker_error(
        &io::Error::new(io::ErrorKind::PermissionDenied, "no os code"),
        true
    ));

    let root = temp_dir("i1-marker");
    fs::create_dir_all(&root).unwrap();
    let log = g1g2::OperatorLog::new(phobos_config::LogFormat::Json, 1_000);
    let marker = root.join("shutdown.request");
    // Missing marker: nothing to do.
    remove_shutdown_marker(&marker, &log).unwrap();
    fs::write(&marker, "stop").unwrap();
    remove_shutdown_marker(&marker, &log).unwrap();
    assert!(!marker.exists());
    // Windows reports AccessDenied (5) for removing a directory as a file,
    // which the production policy explicitly leaves in place. Unix reports
    // a non-transient directory error instead.
    fs::create_dir_all(&marker).unwrap();
    let result = remove_shutdown_marker(&marker, &log);
    assert_eq!(result.is_ok(), cfg!(windows));
    assert!(marker.is_dir());
    fs::remove_dir_all(root).unwrap();
}

struct Server {
    address: std::net::SocketAddr,
    marker: PathBuf,
    handle: thread::JoinHandle<Result<(), PhobosError>>,
}
fn start(root: &Path, policy: RequestPath) -> Server {
    let probe = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = probe.local_addr().unwrap();
    drop(probe);
    let marker = root.join("shutdown.request");
    let mut settings = ServerSettings::alpha_default(address.to_string(), root.join("data"));
    settings.apply_config(RuntimeConfig {
        worker_threads: 32,
        max_connections: 64,
        ..Default::default()
    });
    let for_server = marker.clone();
    let handle = thread::spawn(move || serve_with_request_path(settings, Some(for_server), policy));
    Server {
        address,
        marker,
        handle,
    }
}
fn connect(address: std::net::SocketAddr) -> phobos_client::Client {
    for _ in 0..500 {
        if let Ok(client) = phobos_client::Client::connect(address) {
            client.set_io_timeout(Duration::from_secs(60)).unwrap();
            return client;
        }
        thread::sleep(Duration::from_millis(10));
    }
    panic!("server did not start")
}
/// The helper-side protocol: write a temporary file, close it, rename.
fn stop(server: Server) {
    let temporary = server.marker.with_extension("request.tmp");
    fs::write(&temporary, "stop").unwrap();
    fs::rename(&temporary, &server.marker).unwrap();
    server.handle.join().unwrap().unwrap();
    assert!(!server.marker.exists());
}
fn rows(first: i64, count: i64) -> String {
    (first..first + count)
        .map(|id| format!("({id},{},'g{}')", id % 97, id % 13))
        .collect::<Vec<_>>()
        .join(",")
}
/// Deterministic single-client workload over the 0.2-H engine paths:
/// 500-row transactions (Batch DML V2, encoded leaf merges, heap in place),
/// statement-level and committed UNIQUE conflicts, rollback, indexed and
/// row-growing UPDATEs, DELETE, CHECKPOINT. Returns every statement's
/// outcome (result text or error code).
fn workload(client: &mut phobos_client::Client) -> Vec<String> {
    let mut statements = vec![
        "CREATE TABLE t (id BIGINT NOT NULL, v BIGINT NOT NULL, g TEXT)".to_string(),
        "CREATE UNIQUE INDEX t_id ON t(id)".into(),
        "CREATE INDEX t_v ON t(v,id)".into(),
        "CREATE INDEX t_g ON t(g)".into(),
        format!("INSERT INTO t VALUES {}", rows(0, 1_000)),
    ];
    for batch in 0..4 {
        let first = 10_000 + batch * 5_000;
        statements.push("BEGIN".into());
        statements.push(format!("INSERT INTO t VALUES {}", rows(first, 250)));
        statements.push(format!("INSERT INTO t VALUES {}", rows(first + 250, 250)));
        statements.push("COMMIT".into());
    }
    // Duplicate inside one statement, duplicate of a committed key: both fail.
    statements.push(format!(
        "INSERT INTO t VALUES {},(40100,1,'x')",
        rows(40_000, 200)
    ));
    statements.push(format!("INSERT INTO t VALUES {}", rows(999, 3)));
    // A 500-row transaction rolled back.
    statements.push("BEGIN".into());
    statements.push(format!("INSERT INTO t VALUES {}", rows(50_000, 500)));
    statements.push("ROLLBACK".into());
    // Indexed UPDATE, UPDATE that grows rows, an UPDATE creating a duplicate.
    statements.push("UPDATE t SET v = v + 1000 WHERE id >= 100 AND id < 300".into());
    statements.push(format!(
        "UPDATE t SET g = '{}' WHERE id >= 10000 AND id < 10100",
        "w".repeat(300)
    ));
    statements.push("UPDATE t SET id = 5 WHERE id = 6".into());
    statements.push("DELETE FROM t WHERE id >= 15000 AND id < 15250".into());
    statements.push("CHECKPOINT".into());
    let mut outcomes = statements
        .iter()
        .map(|sql| match client.query(sql) {
            Ok(text) => format!("ok {text}"),
            Err(error) => format!("err {:?}", error.code),
        })
        .collect::<Vec<_>>();
    outcomes.extend(snapshot(client));
    outcomes
}
fn snapshot(client: &mut phobos_client::Client) -> Vec<String> {
    [
        "SELECT id, v, g FROM t ORDER BY id",
        "SELECT COUNT(*) AS n FROM t",
        "SELECT COUNT(*) AS n FROM t WHERE v >= 1000",
        "SELECT id FROM t WHERE id = 20250",
        "SELECT COUNT(*) AS n FROM t WHERE g = 'g7'",
        "SELECT COUNT(*) AS n FROM t WHERE id >= 50000",
    ]
    .iter()
    .map(|sql| client.query(sql).unwrap())
    .collect()
}
fn data_files(root: &Path) -> BTreeMap<String, Vec<u8>> {
    let mut files = BTreeMap::new();
    for entry in fs::read_dir(root.join("data")).unwrap() {
        let path = entry.unwrap().path();
        let name = path.file_name().unwrap().to_string_lossy().into_owned();
        if path.is_file() && (name.ends_with(".heap") || name.ends_with(".idx")) {
            files.insert(name, fs::read(&path).unwrap());
        }
    }
    files
}

/// Part F + parity: the same deterministic workload over a real TCP server
/// with Direct and with Pumped gives identical statement outcomes, identical
/// query results, identical heap and index files, and identical results
/// after a restart (recovery).
#[test]
fn i_direct_and_pumped_servers_are_logically_and_physically_identical() {
    let mut results = Vec::new();
    for policy in [RequestPath::Direct, RequestPath::Pumped] {
        let root = temp_dir(&format!("i1-parity-{}", policy.name()));
        let server = start(&root, policy);
        let mut client = connect(server.address);
        let outcomes = workload(&mut client);
        drop(client);
        stop(server);
        // Restart on the same data: recovery yields the same state.
        let server = start(&root, policy);
        let mut client = connect(server.address);
        let reopened = snapshot(&mut client);
        drop(client);
        stop(server);
        assert_eq!(
            reopened,
            outcomes[outcomes.len() - reopened.len()..].to_vec(),
            "{policy:?}: state changed across restart"
        );
        results.push((outcomes, data_files(&root)));
        fs::remove_dir_all(root).unwrap();
    }
    let (direct, pumped) = (&results[0], &results[1]);
    // The expected outcomes, so a silent change on both sides cannot pass.
    let outcomes = &direct.0;
    let failures = outcomes.iter().filter(|o| o.starts_with("err")).count();
    assert_eq!(failures, 3, "{outcomes:#?}"); // two UNIQUE inserts + UPDATE to id 5
    assert!(outcomes.iter().all(|o| !o.contains("TransactionState")));
    let count = &outcomes[outcomes.len() - 5];
    assert!(
        count.ends_with(&format!("\n{}\n", 1_000 + 2_000 - 250)),
        "{count}"
    );
    assert_eq!(
        direct.0, pumped.0,
        "logical results differ between transports"
    );
    assert!(!direct.1.is_empty());
    assert_eq!(
        direct.1.keys().collect::<Vec<_>>(),
        pumped.1.keys().collect::<Vec<_>>()
    );
    for (name, bytes) in &direct.1 {
        assert!(
            pumped.1[name] == *bytes,
            "{name} differs between transports"
        );
    }
}

/// Auto on this platform serves the full protocol (transactions, a 500-row
/// style multi-statement transaction, streaming), and the start-up contract
/// of the marker is unchanged: a marker already present when the server
/// starts requests an immediate clean shutdown (helpers delete stale markers
/// before they start a server).
#[test]
fn i_auto_policy_serves_and_marker_present_at_start_still_stops_cleanly() {
    let root = temp_dir("i1-auto");
    fs::create_dir_all(&root).unwrap();
    let server = start(&root, RequestPath::Auto);
    let mut client = connect(server.address);
    client
        .query("CREATE TABLE a (id BIGINT NOT NULL, p TEXT NOT NULL)")
        .unwrap();
    client.query("BEGIN").unwrap();
    client
        .query(&format!(
            "INSERT INTO a VALUES {}",
            (0..300)
                .map(|i| format!("({i},'{}')", "p".repeat(200)))
                .collect::<Vec<_>>()
                .join(",")
        ))
        .unwrap();
    client.query("COMMIT").unwrap();
    let mut streamed = 0usize;
    client.negotiate_streaming().unwrap();
    client
        .query_stream("SELECT id, p FROM a ORDER BY id", |_| {
            streamed += 1;
            Ok(())
        })
        .unwrap();
    assert!(streamed > 0);
    assert_eq!(
        client.query("SELECT COUNT(*) AS n FROM a").unwrap(),
        "n\n300\n"
    );
    drop(client);
    stop(server);
    // Marker present before start: start, observe it, shut down cleanly.
    fs::write(root.join("shutdown.request"), "stop").unwrap();
    let server = start(&root, RequestPath::Auto);
    server.handle.join().unwrap().unwrap();
    assert!(!root.join("shutdown.request").exists());
    fs::remove_dir_all(root).unwrap();
}
