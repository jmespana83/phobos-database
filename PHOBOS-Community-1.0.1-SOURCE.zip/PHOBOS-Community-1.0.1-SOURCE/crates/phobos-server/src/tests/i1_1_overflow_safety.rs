//! 0.2-I.1 overflow safety: permanent end-to-end regression for the 0.2-I
//! defect where, after a restart, ordinary INSERTs probed "unknown" interior
//! heap pages, accepted an overflow page by its raw free space and stored
//! ordinary tuples on it. On pristine 0.2-I these tests fail:
//! * live chain: insert #15 lands on the wide row's last overflow page
//!   (slot_count 1 -> 3); the wide row, scans and CHECKPOINT then fail with
//!   "overflow page kind is invalid" and `phobos-admin check` fails;
//! * released chain: inserts land on released overflow pages and COUNT(*)
//!   and scans silently omit 12 committed rows.
//!
//! Everything goes through supported paths: legacy create + offline MVCC
//! migration, Coordinator SQL, clean shutdown/restart, `check_integrity`.
use super::*;

const WIDE_ID: i64 = 1000;
const WIDE_LEN: usize = 20_000;

fn text(len: usize, seed: u64) -> String {
    let mut x = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    (0..len)
        .map(|_| {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            char::from(b'a' + (x % 26) as u8)
        })
        .collect()
}

fn row(id: i64, len: usize) -> String {
    format!("({id},{},{id},{id},'{}')", id % 97, text(len, id as u64))
}

fn scalar(db: &Coordinator, session: u64, sql: &str) -> String {
    db.execute(session, sql)
        .unwrap_or_else(|error| panic!("{sql}: {error:?}"))
        .lines()
        .nth(1)
        .unwrap_or("")
        .trim()
        .to_string()
}

/// Overflow pages of the single table heap as `(page, slot_count)`, read raw.
fn overflow_pages(dir: &Path) -> Vec<(usize, u16)> {
    let heap = fs::read_dir(dir)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .find(|path| path.extension().is_some_and(|ext| ext == "heap"))
        .unwrap();
    fs::read(heap)
        .unwrap()
        .chunks_exact(8192)
        .enumerate()
        .filter(|(_, page)| page[30] & 0b10 != 0)
        .map(|(id, page)| (id, u16::from_le_bytes([page[28], page[29]])))
        .collect()
}

fn open(dir: &Path) -> (Arc<Coordinator>, u64) {
    let db = Arc::new(Coordinator::open(dir).unwrap());
    let session = db.new_session();
    (db, session)
}

fn close(db: Arc<Coordinator>, session: u64) {
    db.disconnect(session);
    db.shutdown().unwrap();
}

fn scenario(release_chain: bool) {
    let root = temp_dir(if release_chain {
        "i1-1-overflow-released"
    } else {
        "i1-1-overflow-live"
    });
    fs::create_dir_all(&root).unwrap();
    let source = root.join("source");
    Database::open(&source)
        .unwrap()
        .execute("CREATE TABLE t (id BIGINT NOT NULL, k BIGINT, u BIGINT, v BIGINT, pad TEXT)")
        .unwrap();
    let dir = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    let (db, s) = open(&dir);
    db.execute(s, "CREATE UNIQUE INDEX t_id ON t(id)").unwrap();
    db.execute(s, "CREATE INDEX t_k ON t(k)").unwrap();
    let insert = |from: i64, to: i64| {
        for start in (from..=to).step_by(50) {
            let values = (start..=(start + 49).min(to))
                .map(|id| row(id, 40))
                .collect::<Vec<_>>()
                .join(",");
            db.execute(s, &format!("INSERT INTO t VALUES {values}"))
                .unwrap();
        }
    };
    insert(1, 100);
    let wide = text(WIDE_LEN, 7);
    db.execute(
        s,
        &format!("INSERT INTO t VALUES ({WIDE_ID},1,{WIDE_ID},1,'{wide}')"),
    )
    .unwrap();
    insert(2000, 2299);
    db.execute(s, "CHECKPOINT").unwrap();
    assert_eq!(
        scalar(&db, s, &format!("SELECT pad FROM t WHERE id={WIDE_ID}")),
        wide
    );
    let mut expected = 401;
    if release_chain {
        db.execute(s, &format!("DELETE FROM t WHERE id={WIDE_ID}"))
            .unwrap();
        expected -= 1;
        for _ in 0..16 {
            let pass = db.reclaim_once(64).unwrap();
            if pass.versions_reclaimed == 0 && pass.candidates_remaining == 0 {
                break;
            }
        }
        db.execute(s, "CHECKPOINT").unwrap();
    }
    close(db, s);
    let before = overflow_pages(&dir);
    assert!(
        before.len() >= 3,
        "wide row must use an overflow chain: {before:?}"
    );
    assert!(before.iter().all(|(_, slots)| *slots == 1));

    // Restart: interior free space is now "unknown" and gets probed.
    let (db, s) = open(&dir);
    for i in 0..40 {
        db.execute(s, &format!("INSERT INTO t VALUES {}", row(5000 + i, 1600)))
            .unwrap();
        expected += 1;
        if !release_chain {
            assert_eq!(
                scalar(
                    &db,
                    s,
                    &format!("SELECT LENGTH(pad) AS n FROM t WHERE id={WIDE_ID}")
                ),
                WIDE_LEN.to_string(),
                "wide row unreadable after post-restart insert {}",
                i + 1
            );
        }
    }
    let check_rows = |db: &Coordinator, s: u64| {
        assert_eq!(
            scalar(db, s, "SELECT COUNT(*) AS n FROM t"),
            expected.to_string()
        );
        assert_eq!(
            scalar(db, s, "SELECT COUNT(*) AS n FROM t WHERE pad<>'q'"),
            expected.to_string()
        );
        assert_eq!(
            scalar(
                db,
                s,
                "SELECT COUNT(*) AS n FROM t WHERE id>=5000 AND pad<>'q'"
            ),
            "40"
        );
        for id in [5000, 5014, 5015, 5039] {
            assert_eq!(
                scalar(db, s, &format!("SELECT v FROM t WHERE id={id}")),
                id.to_string()
            );
        }
        if !release_chain {
            assert_eq!(
                scalar(db, s, &format!("SELECT pad FROM t WHERE id={WIDE_ID}")),
                wide
            );
        }
    };
    check_rows(&db, s);
    db.execute(s, "CHECKPOINT").unwrap();
    close(db, s);
    let after = overflow_pages(&dir);
    assert!(
        after.iter().all(|(_, slots)| *slots == 1),
        "ordinary tuples reached an overflow page: {after:?}"
    );
    assert_eq!(before, after);
    phobos_admin::check_integrity(&dir).unwrap();
    for _ in 0..2 {
        let (db, s) = open(&dir);
        check_rows(&db, s);
        db.execute(s, "UPDATE t SET v=v+1 WHERE id=5014").unwrap();
        db.execute(s, "UPDATE t SET v=v-1 WHERE id=5014").unwrap();
        db.execute(s, &format!("INSERT INTO t VALUES {}", row(9000, 1600)))
            .unwrap();
        db.execute(s, "DELETE FROM t WHERE id=9000").unwrap();
        close(db, s);
        phobos_admin::check_integrity(&dir).unwrap();
    }
    assert!(overflow_pages(&dir).iter().all(|(_, slots)| *slots == 1));
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn i1_1_post_restart_inserts_never_land_on_live_overflow_chain() {
    scenario(false);
}

#[test]
fn i1_1_post_restart_inserts_never_land_on_released_overflow_pages() {
    scenario(true);
}
