use super::*;
#[path = "a1_key_semantics.rs"]
mod a1_key_semantics;
#[path = "a3_status_growth.rs"]
mod a3_status_growth;
#[path = "a4_write_spill.rs"]
mod a4_write_spill;
#[path = "b1_b2_hints.rs"]
mod b1_b2_hints;
#[path = "c1_c2_c3_reclaim.rs"]
mod c1_c2_c3_reclaim;
#[path = "c7_bulk.rs"]
mod c7_bulk;
#[path = "c9_bulk.rs"]
mod c9_bulk;
#[path = "h1_request_path.rs"]
mod h1_request_path;

#[test]
fn c6_tcp_disconnect_cancels_waiter_and_releases_its_other_row() {
    disconnect_waiter(false, 0);
    disconnect_waiter(false, 1);
}
#[test]
fn c6_tls_disconnect_cancels_waiter_and_releases_its_other_row() {
    disconnect_waiter(true, 0);
    disconnect_waiter(true, 1);
}
#[test]
fn c6_tcp_tls_disconnect_aborts_held_but_completes_admitted_transactions() {
    for tls in [false, true] {
        disconnect_waiter(tls, 2);
        disconnect_waiter(tls, 3);
    }
}
/// 0.2-H: the same disconnect scenarios through the direct request transport
/// (worker reads its own frames; the monitor thread observes EOF).
#[test]
fn h_direct_disconnect_cancels_waiter_and_releases_its_other_row() {
    disconnect_waiter_with(false, true, 0);
    disconnect_waiter_with(false, true, 1);
}
#[test]
fn h_direct_disconnect_aborts_held_but_completes_admitted_transactions() {
    disconnect_waiter_with(false, true, 2);
    disconnect_waiter_with(false, true, 3);
}
fn disconnect_waiter(tls: bool, mode: u8) {
    disconnect_waiter_with(tls, false, mode)
}
fn disconnect_waiter_with(tls: bool, direct: bool, mode: u8) {
    let unique = mode == 1;
    let (root, dir) = migrated();
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let server = coordinator.clone();
    let fixtures = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures");
    let config = load_tls_config(
        Some(&fixtures.join("server.pem")),
        Some(&fixtures.join("server-key.pem")),
        None,
        false,
    )
    .unwrap()
    .unwrap();
    let (done, completion) = std::sync::mpsc::channel();
    let worker = thread::spawn(move || {
        let (socket, _) = listener.accept().unwrap();
        let id = server.new_session();
        let mut socket = if tls {
            request_transport::Pumped::tls(
                socket,
                ServerConnection::new(config).unwrap(),
                server.clone(),
                id,
            )
            .unwrap()
        } else if direct {
            let mut socket = request_transport::Direct::new(socket, server.clone(), id).unwrap();
            let _ = session_requests(
                &mut socket,
                server.clone(),
                id,
                None,
                phobos_protocol::MAX_PAYLOAD,
            );
            server.disconnect(id);
            drop(socket);
            done.send(()).unwrap();
            return;
        } else {
            request_transport::Pumped::new(socket, server.clone(), id).unwrap()
        };
        let _ = session_requests(
            &mut socket,
            server.clone(),
            id,
            None,
            phobos_protocol::MAX_PAYLOAD,
        );
        server.disconnect(id);
        drop(socket);
        done.send(()).unwrap();
    });
    let socket = TcpStream::connect(address).unwrap();
    socket
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let shutdown = socket.try_clone().unwrap();
    trait Duplex: Read + Write {}
    impl<T: Read + Write> Duplex for T {}
    let mut socket: Box<dyn Duplex> = if tls {
        let mut roots = rustls::RootCertStore::empty();
        for certificate in rustls_pemfile::certs(&mut BufReader::new(
            File::open(fixtures.join("ca.pem")).unwrap(),
        )) {
            roots.add(certificate.unwrap()).unwrap();
        }
        let config = rustls::ClientConfig::builder()
            .with_root_certificates(roots)
            .with_no_client_auth();
        let connection = rustls::ClientConnection::new(
            Arc::new(config),
            rustls::pki_types::ServerName::try_from("localhost").unwrap(),
        )
        .unwrap();
        Box::new(StreamOwned::new(connection, socket))
    } else {
        Box::new(socket)
    };
    for (request, sql) in [(1, "BEGIN"), (2, "UPDATE t SET v=10 WHERE id=1")] {
        Frame::new(MessageType::Query, request, sql.as_bytes().to_vec())
            .write_to(&mut socket)
            .unwrap();
        assert_eq!(
            Frame::read_from(&mut socket).unwrap().message_type,
            MessageType::QueryResult
        );
    }
    if mode >= 2 {
        let (signal, preparing) = std::sync::mpsc::channel();
        let (resume, resumed) = std::sync::mpsc::channel();
        let resumed = Mutex::new(resumed);
        let (cancel, cancelled) = std::sync::mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "c6_private_preparation_begin" {
                    signal.send(()).unwrap();
                    resumed
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
                if point == "c6_cancel_observed" {
                    let _ = cancel.send(());
                }
            }),
        );
        if mode == 3 {
            Frame::new(MessageType::Query, 3, b"COMMIT".to_vec())
                .write_to(&mut socket)
                .unwrap();
            preparing.recv_timeout(Duration::from_secs(10)).unwrap();
        }
        shutdown.shutdown(std::net::Shutdown::Both).unwrap();
        drop(socket);
        cancelled.recv_timeout(Duration::from_secs(10)).unwrap();
        if mode == 3 {
            resume.send(()).unwrap();
        }
        completion.recv_timeout(Duration::from_secs(10)).unwrap();
        worker.join().unwrap();
        drop(hook);
        let observer = coordinator.new_session();
        assert_eq!(
            coordinator
                .execute(observer, "SELECT v FROM t WHERE id=1")
                .unwrap(),
            if mode == 3 { "v\n10\n" } else { "v\n1\n" }
        );
        coordinator
            .execute(observer, "UPDATE t SET v=11 WHERE id=1")
            .unwrap();
        assert!(
            coordinator
                .conflict_diagnostics()
                .unwrap()
                .unwrap()
                .active
                .is_empty()
        );
        coordinator.disconnect(observer);
        coordinator.shutdown().unwrap();
        drop(coordinator);
        phobos_admin::check_integrity(&dir).unwrap();
        let reopened = Coordinator::open(&dir).unwrap();
        let observer = reopened.new_session();
        assert_eq!(
            reopened
                .execute(observer, "SELECT v FROM t WHERE id=1")
                .unwrap(),
            "v\n11\n"
        );
        reopened.disconnect(observer);
        reopened.shutdown().unwrap();
        drop(reopened);
        fs::remove_dir_all(root).unwrap();
        return;
    }
    let owner = coordinator.new_session();
    coordinator.execute(owner, "BEGIN").unwrap();
    coordinator
        .execute(
            owner,
            if unique {
                "INSERT INTO t VALUES (20,20,20)"
            } else {
                "UPDATE t SET v=20 WHERE id=2"
            },
        )
        .unwrap();
    let (signal, waiting) = std::sync::mpsc::channel();
    let hook = phobos_observability::test_hooks::register(
        &dir,
        Arc::new(move |point| {
            if point
                == if unique {
                    "c5_unique_wait"
                } else {
                    "c5_row_wait"
                }
            {
                let _ = signal.send(());
            }
        }),
    );
    Frame::new(
        MessageType::Query,
        3,
        if unique {
            b"INSERT INTO t VALUES (21,20,20)".to_vec()
        } else {
            b"UPDATE t SET v=21 WHERE id=2".to_vec()
        },
    )
    .write_to(&mut socket)
    .unwrap();
    waiting.recv_timeout(Duration::from_secs(10)).unwrap();
    shutdown.shutdown(std::net::Shutdown::Both).unwrap();
    drop(socket);
    completion.recv_timeout(Duration::from_secs(10)).unwrap();
    worker.join().unwrap();
    coordinator
        .execute(owner, "UPDATE t SET v=11 WHERE id=1")
        .unwrap();
    coordinator.execute(owner, "COMMIT").unwrap();
    assert_eq!(
        coordinator
            .execute(owner, "SELECT v FROM t WHERE id=1")
            .unwrap(),
        "v\n11\n"
    );
    let diagnostics = coordinator.conflict_diagnostics().unwrap().unwrap();
    assert_eq!(
        if unique {
            diagnostics.unique.cancellations
        } else {
            diagnostics.row.cancellations
        },
        1
    );
    assert!(diagnostics.active.is_empty());
    drop(hook);
    coordinator.disconnect(owner);
    coordinator.shutdown().unwrap();
    drop(coordinator);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}

fn migrated() -> (PathBuf, PathBuf) {
    migrated_rows(3)
}
fn migrated_rows(rows: usize) -> (PathBuf, PathBuf) {
    let root = temp_dir("mvcc-sql");
    fs::create_dir_all(&root).unwrap();
    let source = root.join("source");
    let mut db = Database::open(&source).unwrap();
    db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT, g BIGINT)")
        .unwrap();
    db.execute("CREATE UNIQUE INDEX u ON t(id)").unwrap();
    db.execute("CREATE UNIQUE INDEX c ON t(v,g)").unwrap();
    db.execute("INSERT INTO t VALUES (1,1,NULL),(2,2,NULL),(3,3,NULL)")
        .unwrap();
    if rows > 3 {
        db.execute("CREATE INDEX duplicates ON t(g)").unwrap();
        db.execute("UPDATE t SET g=7").unwrap();
        for start in (4..=rows).step_by(100) {
            let values = (start..=(start + 99).min(rows))
                .map(|id| format!("({id},{id},7)"))
                .collect::<Vec<_>>()
                .join(",");
            db.execute(&format!("INSERT INTO t VALUES {values}"))
                .unwrap();
        }
    }
    drop(db);
    let destination = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &destination).unwrap();
    (root, destination)
}

#[test]
fn tcp_mvcc_paused_writer_own_writes_read_committed_conflicts_and_rollback() {
    let (root, dir) = migrated();
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    let (mut writer, writer_worker) = stream_test_connection(coordinator.clone());
    let (mut reader, reader_worker) = stream_test_connection(coordinator.clone());
    let (mut other, other_worker) = stream_test_connection(coordinator.clone());
    writer.query("BEGIN").unwrap();
    writer.query("UPDATE t SET v=11 WHERE id=1").unwrap();
    reader.query("BEGIN").unwrap();
    assert_eq!(
        reader.query("SELECT v FROM t WHERE id=1").unwrap(),
        "v\n1\n"
    );
    assert_eq!(
        writer.query("SELECT v FROM t WHERE id=1").unwrap(),
        "v\n11\n"
    );
    other.query("BEGIN").unwrap();
    assert!(other.query("UPDATE t SET v=99 WHERE id=1").is_err());
    assert!(other.query("COMMIT").is_err());
    other.query("ROLLBACK").unwrap();
    other.query("BEGIN").unwrap();
    other.query("UPDATE t SET v=22 WHERE id=2").unwrap();
    other.query("COMMIT").unwrap();
    writer.query("COMMIT").unwrap();
    assert_eq!(
        reader.query("SELECT v FROM t WHERE id=1").unwrap(),
        "v\n11\n"
    );
    assert_eq!(
        reader.query("SELECT v FROM t WHERE id=2").unwrap(),
        "v\n22\n"
    );
    reader.query("COMMIT").unwrap();
    writer.query("BEGIN").unwrap();
    writer
        .query("INSERT INTO t VALUES (10,10,NULL),(11,10,NULL)")
        .unwrap();
    writer.query("UPDATE t SET v=v+1 WHERE id=10").unwrap();
    assert_eq!(
        writer.query("SELECT v FROM t WHERE id=10").unwrap(),
        "v\n11\n"
    );
    writer.query("DELETE FROM t WHERE id=11").unwrap();
    assert_eq!(
        writer.query("SELECT id FROM t WHERE id>=10").unwrap(),
        "id\n10\n"
    );
    writer.query("ROLLBACK").unwrap();
    assert_eq!(
        reader.query("SELECT id FROM t WHERE id>=10").unwrap(),
        "id\n"
    );
    writer.query("INSERT INTO t VALUES (20,20,0)").unwrap();
    assert!(other.query("INSERT INTO t VALUES (21,20,0)").is_err());
    drop(writer);
    drop(reader);
    drop(other);
    writer_worker.join().unwrap();
    reader_worker.join().unwrap();
    other_worker.join().unwrap();
    coordinator.shutdown().unwrap();
    drop(coordinator);
    let coordinator = Coordinator::open(&dir).unwrap();
    let id = coordinator.new_session();
    assert_eq!(
        coordinator
            .execute(id, "SELECT v FROM t WHERE id<=2 ORDER BY id")
            .unwrap(),
        "v\n11\n22\n"
    );
    coordinator.disconnect(id);
    coordinator.shutdown().unwrap();
    drop(coordinator);
    fs::remove_dir_all(root).unwrap();
}

struct PausedSink {
    started: std::sync::mpsc::Sender<()>,
    resume: std::sync::mpsc::Receiver<()>,
    rows: Vec<phobos_types::Row>,
    fail: bool,
}
impl ResultSink for PausedSink {
    fn start(&mut self, _: Vec<String>) -> Result<(), PhobosError> {
        Ok(())
    }
    fn row(&mut self, row: phobos_types::Row) -> Result<(), PhobosError> {
        if self.rows.is_empty() {
            self.started.send(()).unwrap();
            self.resume.recv_timeout(Duration::from_secs(10)).unwrap();
        }
        if self.fail {
            return Err(PhobosError::new(ErrorCode::Io, "test disconnected stream"));
        }
        self.rows.push(row);
        Ok(())
    }
    fn finish(&mut self) -> Result<(), PhobosError> {
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
        panic!("expected rows")
    }
}

#[test]
fn mvcc_stream_retains_snapshot_during_publication_and_releases_on_error() {
    for (fail, query) in [
        (false, "SELECT id,v FROM t WHERE id>=1"),
        (false, "SELECT id,v FROM t WHERE g=7"),
        (true, "SELECT id,v FROM t WHERE id>=1"),
    ] {
        let (root, dir) = migrated_rows(512);
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let reader = coordinator.new_session();
        let writer = coordinator.new_session();
        let (started, ready) = std::sync::mpsc::channel();
        let (resume, receive) = std::sync::mpsc::channel();
        let worker_db = coordinator.clone();
        let worker = thread::spawn(move || {
            let mut sink = PausedSink {
                started,
                resume: receive,
                rows: Vec::new(),
                fail,
            };
            let result = worker_db.execute_stream_result(reader, query, &mut sink);
            (result, sink.rows)
        });
        ready.recv_timeout(Duration::from_secs(10)).unwrap();
        // Publication must finish while the statement is suspended in delivery.
        coordinator
            .execute(writer, "UPDATE t SET v=v+1000 WHERE id>=1")
            .unwrap();
        coordinator
            .execute(writer, "INSERT INTO t VALUES (513,513,7)")
            .unwrap();
        resume.send(()).unwrap();
        let (result, mut rows) = worker.join().unwrap();
        assert_eq!(result.is_err(), fail);
        if !fail {
            use phobos_types::{Row, Value};
            rows.sort_by_key(|row| match row.values[0] {
                Value::Int64(id) => id,
                _ => panic!("integer id"),
            });
            assert_eq!(
                rows,
                (1..=512)
                    .map(|n| Row::new(vec![Value::Int64(n), Value::Int64(n)]))
                    .collect::<Vec<_>>()
            );
        }
        assert_eq!(
            coordinator
                .execute(reader, "SELECT v FROM t WHERE id=2")
                .unwrap(),
            "v\n1002\n"
        );
        coordinator.disconnect(reader);
        coordinator.disconnect(writer);
        // Shutdown checks all live pins, including disconnected statement pins.
        coordinator.shutdown().unwrap();
        drop(coordinator);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn mvcc_unique_wait_rechecks_commit_and_abort_and_row_head() {
    for (row_conflict, commit) in [(false, true), (false, false), (true, true)] {
        let (root, dir) = migrated();
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let older = coordinator.new_session();
        let younger = coordinator.new_session();
        coordinator.execute(older, "BEGIN").unwrap();
        coordinator.execute(younger, "BEGIN").unwrap();
        // Equal composite keys containing NULL remain legal while both
        // sessions hold uncommitted inserts; neither waits for key ownership.
        // D1: identities (and so conflict age) are taken by the first write,
        // not by BEGIN, so the older session writes first.
        coordinator
            .execute(older, "INSERT INTO t VALUES (51,88,NULL)")
            .unwrap();
        coordinator
            .execute(younger, "INSERT INTO t VALUES (50,88,NULL)")
            .unwrap();
        coordinator
            .execute(
                younger,
                if row_conflict {
                    "UPDATE t SET v=40 WHERE id=1"
                } else {
                    "INSERT INTO t VALUES (40,40,0)"
                },
            )
            .unwrap();
        let (signal, waiting) = std::sync::mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point
                    == if row_conflict {
                        "c5_row_wait"
                    } else {
                        "c5_unique_wait"
                    }
                {
                    signal.send(()).unwrap();
                }
            }),
        );
        let worker_db = coordinator.clone();
        let worker = thread::spawn(move || {
            worker_db.execute(
                older,
                if row_conflict {
                    "UPDATE t SET v=41 WHERE id=1"
                } else {
                    "INSERT INTO t VALUES (41,40,0)"
                },
            )
        });
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        coordinator
            .execute(younger, if commit { "COMMIT" } else { "ROLLBACK" })
            .unwrap();
        let result = worker.join().unwrap();
        drop(hook);
        assert_eq!(result.is_err(), commit, "{result:?}");
        if commit {
            assert!(coordinator.execute(older, "COMMIT").is_err());
            coordinator.execute(older, "ROLLBACK").unwrap();
        } else {
            coordinator.execute(older, "COMMIT").unwrap();
            assert_eq!(
                coordinator
                    .execute(older, "SELECT id FROM t WHERE v=40 AND g=0")
                    .unwrap(),
                "id\n41\n"
            );
        }
        coordinator.disconnect(older);
        coordinator.disconnect(younger);
        coordinator.shutdown().unwrap();
        drop(coordinator);
        fs::remove_dir_all(root).unwrap();
    }
}

fn file_image(
    directory: &std::path::Path,
) -> std::collections::BTreeMap<std::ffi::OsString, Vec<u8>> {
    fs::read_dir(directory)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| path.is_file())
        .map(|path| {
            (
                path.file_name().unwrap().to_owned(),
                fs::read(path).unwrap(),
            )
        })
        .collect()
}

#[test]
fn mvcc_runtime_twenty_four_crash_boundaries_and_offline_integrity() {
    runtime_crash_campaign(
        "tests::mvcc::mvcc_runtime_twenty_four_crash_boundaries_and_offline_integrity",
        &[
            "c5_before_visibility_publication",
            "c5_ack_before_flush",
            "background_flush_after_write",
            "eviction_flush_after_write",
            "checkpoint_drain_after_write",
            "c5_visibility_before_retirement",
        ],
    );
}
#[test]
fn c6_index_publication_and_status_frontier_crashes_recover_twice() {
    runtime_crash_campaign(
        "tests::mvcc::c6_index_publication_and_status_frontier_crashes_recover_twice",
        &[
            "c6_index_page_published",
            "c6_status_persisted_before_frontier",
        ],
    );
}
fn runtime_crash_campaign(test: &str, points: &[&str]) {
    use std::{
        io::Write,
        process::{Command, exit},
    };
    const ENV: &str = "PHOBOS_C5_RUNTIME_CRASH";
    if let Ok(point) = std::env::var(ENV) {
        let root = PathBuf::from(std::env::var_os("PHOBOS_C5_RUNTIME_ROOT").unwrap());
        let dir = root.join("mvcc");
        let coordinator = Coordinator::open(&dir).unwrap();
        let marker = root.join("crash.marker");
        let target = point.clone();
        let (_hold_background, background_wait) = std::sync::mpsc::channel::<()>();
        let background_wait = std::sync::Mutex::new(background_wait);
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |observed| {
                if target == "eviction_flush_after_write" && observed == "background_batch_start" {
                    let _ = background_wait
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10));
                }
                if observed == target {
                    let mut file = File::create(&marker).unwrap();
                    file.write_all(observed.as_bytes()).unwrap();
                    file.sync_all().unwrap();
                    exit(86); // No Rust destructors or graceful shutdown.
                }
            }),
        );
        let writer = coordinator.new_session();
        let abandoned = coordinator.new_session();
        coordinator.execute(abandoned, "BEGIN").unwrap();
        coordinator
            .execute(abandoned, "INSERT INTO t VALUES (99,99,NULL)")
            .unwrap();
        coordinator.execute(writer, "BEGIN").unwrap();
        coordinator
            .execute(writer, "UPDATE t SET v=11 WHERE id=1")
            .unwrap();
        coordinator
            .execute(writer, "DELETE FROM t WHERE id=2")
            .unwrap();
        coordinator
            .execute(writer, "INSERT INTO t VALUES (4,4,NULL)")
            .unwrap();
        coordinator.execute(writer, "COMMIT").unwrap();
        let mut acknowledgment = File::create(root.join("commit.ack")).unwrap();
        acknowledgment
            .write_all(b"update 1; delete 2; insert 4\n")
            .unwrap();
        acknowledgment.sync_all().unwrap();
        if point == "c5_ack_before_flush" {
            let stats = coordinator.flush_stats().unwrap();
            assert!(stats.dirty_pages > 0);
            assert!(stats.maximum_page_lsn <= stats.durable_wal_lsn);
            phobos_observability::synchronization_boundary(
                &point,
                &fs::canonicalize(&dir).unwrap(),
            );
        } else if point == "background_flush_after_write" {
            // The worker, not this timeout, terminates the process at its write.
            let (_keep, wait) = std::sync::mpsc::channel::<()>();
            let _ = wait.recv_timeout(Duration::from_secs(10));
        } else {
            coordinator.execute(writer, "CHECKPOINT").unwrap();
        }
        panic!("runtime crash boundary not reached: {point}");
    }
    for &point in points {
        for round in 0..4 {
            let (root, dir) = migrated();
            let child = Command::new(std::env::current_exe().unwrap())
                .args(["--exact", test, "--nocapture"])
                .env(ENV, point)
                .env("PHOBOS_C5_RUNTIME_ROOT", &root)
                .env(
                    "PHOBOS_FLUSH_WAKE_MS",
                    if point == "background_flush_after_write" {
                        "10"
                    } else {
                        "3600000"
                    },
                )
                .env(
                    "PHOBOS_DIRTY_HIGH_WATER_PAGES",
                    if point == "eviction_flush_after_write" {
                        "1"
                    } else {
                        "8192"
                    },
                )
                .output()
                .unwrap();
            assert_eq!(
                child.status.code(),
                Some(86),
                "{point}/{round}: {} {}",
                String::from_utf8_lossy(&child.stdout),
                String::from_utf8_lossy(&child.stderr)
            );
            assert_eq!(
                fs::read_to_string(root.join("crash.marker")).unwrap(),
                point
            );
            if matches!(
                point,
                "c5_ack_before_flush"
                    | "checkpoint_drain_after_write"
                    | "c5_visibility_before_retirement"
            ) {
                assert!(root.join("commit.ack").is_file());
            }
            let original = file_image(&dir);
            let report = phobos_admin::check_integrity(&dir).unwrap();
            assert_eq!((report.tables, report.indexes), (1, 2));
            assert_eq!(file_image(&dir), original, "integrity modified source");
            if round == 0 {
                phobos_admin::backup_offline(&dir, &root.join("runtime-backup")).unwrap();
                phobos_admin::restore_offline(&root.join("runtime-backup"), &root.join("restored"))
                    .unwrap();
                assert_eq!(
                    phobos_admin::check_integrity(&root.join("restored")).unwrap(),
                    report
                );
                assert_eq!(file_image(&dir), original);
            }
            for _ in 0..2 {
                let coordinator = Coordinator::open(&dir).unwrap();
                let reader = coordinator.new_session();
                assert_eq!(
                    coordinator
                        .execute(reader, "SELECT id,v FROM t ORDER BY id")
                        .unwrap(),
                    "id\tv\n1\t11\n3\t3\n4\t4\n"
                );
                assert_eq!(
                    coordinator
                        .execute(reader, "SELECT v FROM t WHERE id=1")
                        .unwrap(),
                    "v\n11\n"
                );
                assert_eq!(
                    coordinator
                        .execute(reader, "SELECT id FROM t WHERE id=99")
                        .unwrap(),
                    "id\n"
                );
                coordinator.disconnect(reader);
                coordinator.shutdown().unwrap();
                drop(coordinator);
            }
            phobos_admin::check_integrity(&dir).unwrap();
            fs::remove_dir_all(root).unwrap();
            let checkpoint = if point.starts_with("c6_") { "C6" } else { "C5" };
            eprintln!("{checkpoint} runtime crash passed: {point}/{round}");
        }
    }
}

#[test]
fn mvcc_sql_joins_grouping_and_streams_keep_one_statement_snapshot() {
    for grouped in [false, true] {
        let (root, dir) = migrated();
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        let writer = db.new_session();
        let reader = db.new_session();
        db.execute(writer, "CREATE TABLE tags (id BIGINT, label TEXT)")
            .unwrap();
        db.execute(writer, "INSERT INTO tags VALUES (1,'a'),(2,'a'),(3,'b')")
            .unwrap();
        db.execute(writer, "CREATE UNIQUE INDEX tags_id ON tags(id)")
            .unwrap();
        db.execute(writer, "BEGIN").unwrap();
        db.execute(writer, "UPDATE t SET v=v+10").unwrap();
        let query = if grouped {
            "SELECT tags.label, SUM(t.v) AS total FROM t JOIN tags ON t.id=tags.id GROUP BY tags.label ORDER BY tags.label"
        } else {
            "SELECT t.id, t.v FROM t JOIN tags ON t.id=tags.id ORDER BY t.id"
        };
        let old = db.execute(reader, query).unwrap();
        let own = db.execute(writer, query).unwrap();
        assert_ne!(old, own);
        let (started, waiting) = std::sync::mpsc::channel();
        let (resume, receive) = std::sync::mpsc::channel();
        let streaming = db.clone();
        let worker = thread::spawn(move || {
            let mut sink = PausedSink {
                started,
                resume: receive,
                rows: Vec::new(),
                fail: false,
            };
            streaming
                .execute_stream_result(reader, query, &mut sink)
                .unwrap();
            sink.rows
        });
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        db.execute(writer, "COMMIT").unwrap();
        resume.send(()).unwrap();
        let rows = worker.join().unwrap();
        use phobos_types::{Row, Value};
        let expected = if grouped {
            vec![
                Row::new(vec![Value::Text("a".into()), Value::Int64(3)]),
                Row::new(vec![Value::Text("b".into()), Value::Int64(3)]),
            ]
        } else {
            (1..=3)
                .map(|id| Row::new(vec![Value::Int64(id), Value::Int64(id)]))
                .collect()
        };
        assert_eq!(rows, expected);
        assert_eq!(db.execute(reader, query).unwrap(), own);
        db.disconnect(writer);
        db.disconnect(reader);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn mvcc_schema_three_crash_boundaries_restore_catalog_rows_and_indexes() {
    use std::{
        io::Write,
        process::{Command, exit},
    };
    const TEST: &str =
        "tests::mvcc::mvcc_schema_three_crash_boundaries_restore_catalog_rows_and_indexes";
    if let Ok(point) = std::env::var("PHOBOS_C5_SCHEMA_CRASH") {
        let root = PathBuf::from(std::env::var_os("PHOBOS_C5_SCHEMA_ROOT").unwrap());
        let dir = root.join("mvcc");
        let db = Coordinator::open(&dir).unwrap();
        let marker = root.join("schema.marker");
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |at| {
                if at == point {
                    let mut file = File::create(&marker).unwrap();
                    file.write_all(at.as_bytes()).unwrap();
                    file.sync_all().unwrap();
                    exit(86);
                }
            }),
        );
        let session = db.new_session();
        db.execute(session, "BEGIN").unwrap();
        db.execute(session, "CREATE TABLE schema_crash (id BIGINT)")
            .unwrap();
        db.execute(session, "INSERT INTO schema_crash VALUES (8),(9)")
            .unwrap();
        db.execute(session, "CREATE UNIQUE INDEX schema_id ON schema_crash(id)")
            .unwrap();
        db.execute(session, "ANALYZE schema_crash").unwrap();
        db.execute(session, "DROP INDEX c").unwrap();
        db.execute(session, "COMMIT").unwrap();
        panic!("schema crash was not reached");
    }
    for point in [
        "c5_before_visibility_publication",
        "c5_schema_metadata_installed",
        "c5_after_visibility_publication",
    ] {
        let (root, dir) = migrated();
        let child = Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env("PHOBOS_C5_SCHEMA_CRASH", point)
            .env("PHOBOS_C5_SCHEMA_ROOT", &root)
            .output()
            .unwrap();
        assert_eq!(
            child.status.code(),
            Some(86),
            "{} {}",
            String::from_utf8_lossy(&child.stdout),
            String::from_utf8_lossy(&child.stderr)
        );
        assert_eq!(
            fs::read_to_string(root.join("schema.marker")).unwrap(),
            point
        );
        phobos_admin::check_integrity(&dir).unwrap();
        for _ in 0..2 {
            let db = Coordinator::open(&dir).unwrap();
            let session = db.new_session();
            assert_eq!(
                db.execute(session, "SELECT id FROM schema_crash WHERE id=9")
                    .unwrap(),
                "id\n9\n"
            );
            assert!(
                db.execute(session, "INSERT INTO schema_crash VALUES (9)")
                    .is_err()
            );
            db.execute(session, "INSERT INTO t VALUES (30,3,NULL)")
                .unwrap();
            db.execute(session, "DELETE FROM t WHERE id=30").unwrap();
            db.disconnect(session);
            db.shutdown().unwrap();
            drop(db);
        }
        phobos_admin::check_integrity(&dir).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
}
#[path = "a2_cancellation.rs"]
mod a2_cancellation;

#[test]
fn a5_server_settings_and_status_extent_reach_runtime() {
    let root = temp_dir("a5-settings");
    let source = root.join("source");
    let mut old = Database::open(&source).unwrap();
    old.execute("CREATE TABLE t (id BIGINT)").unwrap();
    drop(old);
    let destination = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy_with_capacity(&source, &root.join("backup"), &destination, 4)
        .unwrap();
    let config = RuntimeConfig::from_json(r#"{"status_growth_extent_records":7,"statement_timeout_ms":1234,"idle_timeout_ms":2345,"lock_timeout_ms":3456,"max_connections":17}"#).unwrap();
    let mut settings = ServerSettings::alpha_default("127.0.0.1:0", &destination);
    settings.apply_config(config.clone());
    assert_eq!(settings.effective_config().unwrap(), config);
    let db = Coordinator::open_configured(&destination, &config).unwrap();
    assert_eq!(db.statement_timeout, Duration::from_millis(1234));
    assert_eq!(db.idle_timeout, Duration::from_millis(2345));
    assert_eq!(db.lock_wait, Duration::from_millis(3456));
    let id = db.new_session();
    // D1: BEGIN/ROLLBACK allocates nothing; a write allocates the identity.
    for _ in 0..6 {
        db.execute(id, "BEGIN").unwrap();
        db.execute(id, "INSERT INTO t VALUES (1)").unwrap();
        db.execute(id, "ROLLBACK").unwrap();
    }
    let bytes = fs::read(destination.join("phobos.mvcc-status")).unwrap();
    assert_eq!(u64::from_le_bytes(bytes[8..16].try_into().unwrap()), 11);
    db.disconnect(id);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&destination).unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[path = "c4_c5_freeze.rs"]
mod c4_c5_freeze;
#[path = "d1_d2_d3_commit_path.rs"]
mod d1_d2_d3_commit_path;
