//! 0.2-K Storage Lifecycle V1 through the server: crash before/after the
//! FREE publication and after slot reuse (real process termination at
//! commit boundaries), restart, automatic reclamation without CHECKPOINT,
//! interrupted rotation after reuse, and a standby never running the
//! maintenance worker.
use super::*;
use std::{
    io::Write,
    process::{Command, exit},
};

fn scalar(db: &Coordinator, session: u64, sql: &str) -> i64 {
    db.execute(session, sql)
        .unwrap_or_else(|error| panic!("{sql}: {error:?}"))
        .lines()
        .nth(1)
        .unwrap_or("0")
        .trim()
        .parse()
        .unwrap_or(0)
}

fn table(rows: i64) -> (PathBuf, PathBuf) {
    let root = temp_dir("k-lifecycle");
    fs::create_dir_all(&root).unwrap();
    let source = root.join("source");
    let mut db = Database::open(&source).unwrap();
    db.execute("CREATE TABLE t (id BIGINT NOT NULL, k BIGINT, v BIGINT, pad TEXT)")
        .unwrap();
    db.execute("CREATE UNIQUE INDEX t_id ON t(id)").unwrap();
    db.execute("CREATE INDEX t_k ON t(k)").unwrap();
    let mut id = 1;
    while id <= rows {
        let end = (id + 199).min(rows);
        let values = (id..=end)
            .map(|id| format!("({id},{},{id},'{}')", id % 5, "p".repeat(30)))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(&format!("INSERT INTO t VALUES {values}"))
            .unwrap();
        id = end + 1;
    }
    drop(db);
    let dir = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    (root, dir)
}

fn census(db: &Coordinator) -> phobos_execution::mvcc_runtime::TableLifecycle {
    db.storage_lifecycle(None)
        .unwrap()
        .tables
        .into_iter()
        .find(|table| table.table == "t")
        .unwrap()
}

const CRASH_ENV: &str = "PHOBOS_K_LIFECYCLE_CRASH";

/// Child: build the lifecycle state, then terminate the process (no
/// destructors, no shutdown) at `point` of the armed commit.
fn crash_child(mode: &str, root: &Path) -> ! {
    let dir = root.join("mvcc");
    let db = Coordinator::open(&dir).unwrap();
    db.stop_automatic_reclamation();
    let s = db.new_session();
    db.execute(s, "DELETE FROM t WHERE id<=60").unwrap();
    let retired = db.reclaim_once(256).unwrap();
    assert_eq!(retired.versions_reclaimed, 60, "{retired:?}");
    db.execute(s, "INSERT INTO t VALUES (100001,1,1,'marker')")
        .unwrap();
    let arm = |point: &'static str| {
        let marker = root.join("crash.marker");
        phobos_observability::test_hooks::register(
            &fs::canonicalize(&dir).unwrap(),
            Arc::new(move |observed| {
                if observed == point {
                    let mut file = File::create(&marker).unwrap();
                    file.write_all(observed.as_bytes()).unwrap();
                    file.sync_all().unwrap();
                    exit(86);
                }
            }),
        )
    };
    match mode {
        "before_free" => {
            // Before anything of the FREE pass reaches the WAL.
            let _hook = arm("c6_private_preparation_begin");
            db.reclaim_once(256).unwrap();
        }
        "after_free" => {
            let _hook = arm("c5_after_visibility_publication");
            db.reclaim_once(256).unwrap();
        }
        "after_reuse" => {
            let freed = db.reclaim_once(256).unwrap();
            assert_eq!(freed.slots_freed, 60, "{freed:?}");
            let _hook = arm("c5_after_visibility_publication");
            let values = (0..40)
                .map(|n| format!("({},{},{},'reused')", 200_000 + n, n % 5, n))
                .collect::<Vec<_>>()
                .join(",");
            db.execute(s, &format!("INSERT INTO t VALUES {values}"))
                .unwrap();
        }
        _ => unreachable!(),
    }
    panic!("lifecycle crash boundary not reached: {mode}");
}

/// Part O 15, 16, 17, 18: crash before the FREE publication, after it, and
/// after a reused slot was published; then restart. Every committed row is
/// exact, the lifecycle state is what was durable, reuse resumes after
/// recovery, and offline integrity passes.
#[test]
fn k_crash_before_free_after_free_and_after_reuse_recover_exactly() {
    const TEST: &str =
        "tests::k_lifecycle::k_crash_before_free_after_free_and_after_reuse_recover_exactly";
    if let Ok(mode) = std::env::var(CRASH_ENV) {
        let root = PathBuf::from(std::env::var_os("PHOBOS_K_LIFECYCLE_ROOT").unwrap());
        crash_child(&mode, &root);
    }
    for mode in ["before_free", "after_free", "after_reuse"] {
        let (root, dir) = table(400);
        let child = Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env(CRASH_ENV, mode)
            .env("PHOBOS_K_LIFECYCLE_ROOT", &root)
            .output()
            .unwrap();
        assert_eq!(
            child.status.code(),
            Some(86),
            "{mode}: {}",
            String::from_utf8_lossy(&child.stderr)
        );
        assert!(root.join("crash.marker").exists(), "{mode}");
        let db = Coordinator::open(&dir).unwrap();
        db.stop_automatic_reclamation();
        let s = db.new_session();
        let reused_rows = i64::from(mode == "after_reuse") * 40;
        assert_eq!(
            scalar(&db, s, "SELECT COUNT(*) AS n FROM t"),
            340 + 1 + reused_rows,
            "{mode}"
        );
        assert_eq!(
            scalar(&db, s, "SELECT COUNT(*) AS n FROM t WHERE id<=60"),
            0
        );
        assert_eq!(
            scalar(&db, s, "SELECT SUM(v) AS s FROM t WHERE id<=400"),
            (61..=400).sum::<i64>()
        );
        assert_eq!(
            scalar(&db, s, "SELECT COUNT(*) AS n FROM t WHERE id>=200000"),
            reused_rows
        );
        let state = census(&db);
        match mode {
            // The FREE pass never became durable: still RETIRED.
            "before_free" => assert_eq!(state.slots_retired, 60, "{state:?}"),
            // FREE (or trimmed) is durable; nothing RETIRED remains.
            "after_free" => assert_eq!(state.slots_retired, 0, "{state:?}"),
            // The reused slots hold the 40 new rows.
            _ => assert_eq!(state.slots_retired, 0, "{state:?}"),
        }
        // After restart every RETIRED slot is freeable (no statement
        // survives a restart); reuse continues.
        db.reclaim_once(256).unwrap();
        assert_eq!(census(&db).slots_retired, 0, "{mode}");
        let values = (0..60)
            .map(|n| format!("({},{},{},'after')", 300_000 + n, n % 5, n))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(s, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
        let after = census(&db);
        assert!(
            after.heap_pages <= state.heap_pages + 1,
            "{mode} {state:?} {after:?}"
        );
        // UNIQUE stays exact: a live id conflicts, a deleted one is free.
        assert!(
            db.execute(s, "INSERT INTO t VALUES (100,1,1,'dup')")
                .is_err()
        );
        db.disconnect(s);
        let s = db.new_session();
        db.execute(s, "INSERT INTO t VALUES (5,1,1,'again')")
            .unwrap();
        db.disconnect(s);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
}

/// Part K: with the automatic worker (default), constant-cardinality UPDATE
/// churn reaches a bounded state without any CHECKPOINT or reclaim call.
#[test]
fn k_automatic_reclamation_bounds_churn_without_checkpoint() {
    let (root, dir) = table(200);
    let db = Arc::new(Coordinator::open(&dir).unwrap());
    assert!(db.automatic_reclamation());
    let s = db.new_session();
    let mut pages = Vec::new();
    for round in 0..300 {
        db.execute(s, "UPDATE t SET v=v+1 WHERE id<=200").unwrap();
        if round % 30 == 29 {
            // Give the bounded worker time to catch up (its duty cycle).
            thread::sleep(Duration::from_millis(300));
            let state = census(&db);
            eprintln!(
                "round {round}: pages={} tuples={} dead={} reclaimable={} slots={}/{}/{}/{} free_bytes={} accepting={} candidates={} metrics={:?}",
                state.heap_pages,
                state.tuples_present,
                state.dead_versions,
                state.reclaimable_versions,
                state.slots_total,
                state.slots_occupied,
                state.slots_retired,
                state.slots_free,
                state.free_bytes,
                state.pages_accepting_rows,
                state.reclaim_candidate_pages,
                db.reclaim_metrics().unwrap()
            );
            pages.push(state.heap_pages);
        }
    }
    let metrics = db.reclaim_metrics().unwrap();
    assert!(metrics.automatic_passes > 0, "{metrics:?}");
    assert!(metrics.versions_reclaimed > 40_000, "{metrics:?}");
    assert!(metrics.slots_freed > 30_000, "{metrics:?}");
    // 60,000 updates: before 0.2-K ~4 B/update of permanent slot growth.
    let late = &pages[pages.len() / 2..];
    assert!(late.iter().max().unwrap() <= &(late[0] + 2), "{pages:?}");
    assert!(*pages.last().unwrap() <= 40, "{pages:?}");
    assert_eq!(
        scalar(&db, s, "SELECT SUM(v) AS s FROM t"),
        (1..=200).sum::<i64>() + 300 * 200
    );
    db.disconnect(s);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}

/// Part O 29: an interrupted WAL rotation after slot reuse recovers through
/// the normal open path (0.2-I.3) with every row exact.
#[test]
fn k_interrupted_rotation_after_reuse_recovers() {
    let (root, dir) = table(300);
    {
        let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&dir).unwrap();
        db.execute(1, "DELETE FROM t WHERE id<=100").unwrap();
        db.reclaim_once(256).unwrap();
        db.execute(1, "INSERT INTO t VALUES (100001,1,1,'m')")
            .unwrap();
        let freed = db.reclaim_once(256).unwrap();
        assert_eq!(freed.slots_freed, 100, "{freed:?}");
        let values = (0..100)
            .map(|n| format!("({},{},{},'reused')", 200_000 + n, n % 5, n))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(1, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
        db.disconnect(1);
        drop(db); // no shutdown: the reuse exists only in the WAL
    }
    let active = dir.join("phobos.wal");
    let first = {
        let mut file = fs::File::open(&active).unwrap();
        phobos_wal::v2::read_record(&mut file).unwrap().unwrap().lsn
    };
    fs::rename(&active, dir.join(format!("phobos.wal.{first:016x}.seg"))).unwrap();
    assert!(phobos_wal::v2::interrupted_rotation(&dir).unwrap());
    let db = Coordinator::open(&dir).unwrap();
    let s = db.new_session();
    assert_eq!(scalar(&db, s, "SELECT COUNT(*) AS n FROM t"), 301);
    assert_eq!(
        scalar(&db, s, "SELECT COUNT(*) AS n FROM t WHERE id>=200000"),
        100
    );
    db.disconnect(s);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}

/// Part J: the server never runs automatic reclamation on a physical
/// standby (read-only data directory).
#[test]
fn k_standby_runs_no_maintenance_worker() {
    let (root, dir) = table(50);
    fs::write(dir.join("PHOBOS_STANDBY_1"), b"physical-read-only\n").unwrap();
    let db = Coordinator::open(&dir).unwrap();
    assert!(!db.automatic_reclamation());
    let s = db.new_session();
    assert_eq!(scalar(&db, s, "SELECT COUNT(*) AS n FROM t"), 50);
    db.disconnect(s);
    db.shutdown().unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
