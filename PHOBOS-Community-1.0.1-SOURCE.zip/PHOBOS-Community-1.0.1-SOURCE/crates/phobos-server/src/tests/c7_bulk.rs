use super::*;
use phobos_types::{Row, Value};

fn row(id: i64) -> Row {
    Row::new(vec![Value::Int64(id), Value::Int64(id), Value::Null])
}

#[test]
fn tcp_tls_bulk_auth_chunks_abort_disconnect_and_integrity() {
    for tls in [false, true] {
        let (root, dir) = migrated();
        let db = Arc::new(Coordinator::open(&dir).unwrap());
        let mut auth = AuthStore::open(root.join("auth")).unwrap();
        auth.upsert_user("writer", "test-bulk-password", Role::Writer)
            .unwrap();
        auth.upsert_user("reader", "test-reader-password", Role::Reader)
            .unwrap();
        let auth = Arc::new(auth);
        let connect = || {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let address = listener.local_addr().unwrap();
            let server = db.clone();
            let auth = auth.clone();
            let fixtures = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures");
            let config = load_tls_config(
                Some(&fixtures.join("server.pem")),
                Some(&fixtures.join("server-key.pem")),
                None,
                false,
            )
            .unwrap()
            .unwrap();
            let worker = thread::spawn(move || {
                let (socket, _) = listener.accept().unwrap();
                socket
                    .set_write_timeout(Some(Duration::from_secs(10)))
                    .unwrap();
                let id = server.new_session();
                let mut transport = if tls {
                    request_transport::Pumped::tls(
                        socket,
                        ServerConnection::new(config).unwrap(),
                        server.clone(),
                        id,
                    )
                    .unwrap()
                } else {
                    request_transport::Pumped::new(socket, server.clone(), id).unwrap()
                };
                let _ = session_requests(
                    &mut transport,
                    server.clone(),
                    id,
                    Some(auth),
                    phobos_protocol::MAX_PAYLOAD,
                );
                server.disconnect(id);
            });
            let client = if tls {
                phobos_client::Client::connect_tls(address, "localhost", fixtures.join("ca.pem"))
                    .unwrap()
            } else {
                phobos_client::Client::connect(address).unwrap()
            };
            (client, worker)
        };
        let (mut client, worker) = connect();
        assert!(client.bulk_begin("t").is_err());
        client
            .authenticate("reader", "test-reader-password")
            .unwrap();
        assert!(client.bulk_begin("t").is_err());
        client.authenticate("writer", "test-bulk-password").unwrap();
        assert_eq!(
            client
                .bulk_load("t", (1000..1512).map(|id| Ok(row(id))))
                .unwrap(),
            512
        );
        assert!(
            client
                .bulk_load(
                    "t",
                    (2000..2100).map(|id| if id == 2080 {
                        Err(PhobosError::new(ErrorCode::Semantic, "bad input"))
                    } else {
                        Ok(row(id))
                    })
                )
                .is_err()
        );
        assert_eq!(
            client
                .query("SELECT COUNT(*) AS n FROM t WHERE id>=2000")
                .unwrap(),
            "n\n0\n"
        );
        client.bulk_begin("t").unwrap();
        client.bulk_batch(&[row(2000)]).unwrap();
        // C9: the committed-key conflict is detected by COMMIT's sorted
        // validation, before admission; the chunk itself is accepted.
        client.bulk_batch(&[row(1000)]).unwrap();
        let error = client.query("COMMIT").unwrap_err();
        assert!(error.message.contains("unique"), "{error:?}");
        client.query("ROLLBACK").unwrap();
        assert_eq!(
            client
                .query("SELECT COUNT(*) AS n FROM t WHERE id>=2000")
                .unwrap(),
            "n\n0\n"
        );
        client.bulk_begin("t").unwrap();
        client.bulk_batch(&[row(2000)]).unwrap();
        drop(client);
        worker.join().unwrap();
        let (mut client, worker) = connect();
        client.authenticate("writer", "test-bulk-password").unwrap();
        assert_eq!(
            client
                .query("SELECT COUNT(*) AS n FROM t WHERE id>=2000")
                .unwrap(),
            "n\n0\n"
        );
        client.bulk_begin("t").unwrap();
        client.bulk_batch(&[row(2000)]).unwrap();
        let oversized = Row::new(vec![
            Value::Int64(2001),
            Value::Binary(vec![0; 2 * 1024 * 1024]),
            Value::Null,
        ]);
        assert_eq!(
            client.bulk_batch(&[oversized]).unwrap_err().code,
            ErrorCode::ResourceLimit
        );
        assert_eq!(
            client
                .query("SELECT COUNT(*) AS n FROM t WHERE id>=2000")
                .unwrap(),
            "n\n0\n"
        );
        let nulls = [
            Row::new(vec![Value::Int64(2000), Value::Int64(88), Value::Null]),
            Row::new(vec![Value::Int64(2001), Value::Int64(88), Value::Null]),
        ];
        client.bulk_load("t", nulls.into_iter().map(Ok)).unwrap();
        let duplicates = [
            Row::new(vec![Value::Int64(3000), Value::Int64(42), Value::Int64(0)]),
            Row::new(vec![Value::Int64(3001), Value::Int64(42), Value::Int64(0)]),
        ];
        assert!(
            client
                .bulk_load("t", duplicates.into_iter().map(Ok))
                .is_err()
        );
        assert_eq!(
            client
                .query("SELECT COUNT(*) AS n FROM t WHERE id>=3000")
                .unwrap(),
            "n\n0\n"
        );
        drop(client);
        worker.join().unwrap();
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn bulk_sixteen_crashes_recover_all_or_nothing_twice_with_integrity() {
    const ENV: &str = "PHOBOS_C7_CRASH";
    if let Ok(point) = std::env::var(ENV) {
        let root = PathBuf::from(std::env::var_os("PHOBOS_C7_ROOT").unwrap());
        let dir = root.join("mvcc");
        let db = Coordinator::open(&dir).unwrap();
        let target = point.clone();
        let hook_root = root.clone();
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |observed| {
                if observed == target {
                    let mut marker = File::create(hook_root.join("marker")).unwrap();
                    marker.write_all(observed.as_bytes()).unwrap();
                    marker.sync_all().unwrap();
                    std::process::exit(86);
                }
            }),
        );
        let id = db.new_session();
        db.bulk_load(id, "t", (1000..1128).map(|id| Ok(row(id))))
            .unwrap();
        phobos_observability::synchronization_boundary("c7_ack", &fs::canonicalize(&dir).unwrap());
        panic!("crash hook not reached: {point}");
    }
    for point in [
        "c7_batch_staged",
        "c7_private_batch_prepared",
        "wal.before_force",
        "wal.after_force",
        "c5_before_visibility_publication",
        "c6_index_page_published",
        "c6_status_persisted_before_frontier",
        "c7_ack",
    ] {
        for round in 0..2 {
            let (root, dir) = migrated();
            let child = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--exact","tests::mvcc::c7_bulk::bulk_sixteen_crashes_recover_all_or_nothing_twice_with_integrity","--nocapture"])
                .env(ENV,point).env("PHOBOS_C7_ROOT",&root).env("PHOBOS_FLUSH_WAKE_MS","3600000").output().unwrap();
            assert_eq!(
                child.status.code(),
                Some(86),
                "{point}: {} {}",
                String::from_utf8_lossy(&child.stdout),
                String::from_utf8_lossy(&child.stderr)
            );
            assert_eq!(fs::read_to_string(root.join("marker")).unwrap(), point);
            phobos_admin::check_integrity(&dir).unwrap();
            // 0.2-E Mode E: before the force the batch exists only in the
            // writer's memory (never acknowledged), so it is absent as a whole.
            let unforced_lost = point == "wal.before_force"
                && phobos_wal::v2::DurabilityMode::configured()
                    == phobos_wal::v2::DurabilityMode::WriteThrough;
            let expected = if unforced_lost
                || matches!(point, "c7_batch_staged" | "c7_private_batch_prepared")
            {
                0
            } else {
                128
            };
            for _ in 0..2 {
                let db = Coordinator::open(&dir).unwrap();
                let reader = db.new_session();
                assert_eq!(
                    db.execute(reader, "SELECT COUNT(*) AS n FROM t WHERE id>=1000")
                        .unwrap(),
                    format!("n\n{expected}\n")
                );
                db.disconnect(reader);
                db.shutdown().unwrap();
                drop(db);
                phobos_admin::check_integrity(&dir).unwrap();
            }
            assert!(!fs::read_dir(&dir).unwrap().any(|p| {
                p.unwrap()
                    .file_name()
                    .to_string_lossy()
                    .starts_with(".phobos-mvcc-bulk-")
            }));
            eprintln!("C7 crash passed {point}/{round}");
            fs::remove_dir_all(root).unwrap();
        }
    }
}

#[test]
fn malformed_wire_chunk_aborts_prior_chunks() {
    let (root, dir) = migrated();
    let db = Arc::new(Coordinator::open(&dir).unwrap());
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let server = db.clone();
    let worker = thread::spawn(move || {
        let (socket, _) = listener.accept().unwrap();
        let id = server.new_session();
        let mut stream = request_transport::Pumped::new(socket, server.clone(), id).unwrap();
        let _ = session_requests(
            &mut stream,
            server.clone(),
            id,
            None,
            phobos_protocol::MAX_PAYLOAD,
        );
        server.disconnect(id);
    });
    let mut socket = TcpStream::connect(address).unwrap();
    socket
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let mut exchange = |kind, payload| {
        phobos_protocol::Frame {
            message_type: kind,
            flags: 0,
            request_id: 1,
            payload,
        }
        .write_to(&mut socket)
        .unwrap();
        phobos_protocol::Frame::read_from(&mut socket).unwrap()
    };
    assert_eq!(
        exchange(MessageType::BulkBegin, b"t".to_vec()).message_type,
        MessageType::QueryResult
    );
    let payload = phobos_protocol::streaming::Event::Rows {
        sequence: 0,
        rows: vec![row(1000)],
    }
    .frame(1)
    .unwrap()
    .payload;
    assert_eq!(
        exchange(MessageType::BulkRows, payload).message_type,
        MessageType::QueryResult
    );
    assert_eq!(
        exchange(MessageType::BulkRows, vec![0]).message_type,
        MessageType::Error
    );
    assert_eq!(
        exchange(MessageType::Query, b"COMMIT".to_vec()).message_type,
        MessageType::Error
    );
    drop(socket);
    worker.join().unwrap();
    let id = db.new_session();
    assert_eq!(
        db.execute(id, "SELECT COUNT(*) AS n FROM t WHERE id=1000")
            .unwrap(),
        "n\n0\n"
    );
    db.disconnect(id);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c8_runtime_batch_constraints_rollback_and_crash() {
    const CHILD: &str = "PHOBOS_C8_CRASH_ROOT";
    if let Some(root) = std::env::var_os(CHILD) {
        let root = PathBuf::from(root);
        let dir = root.join("mvcc");
        let db = Coordinator::open(&dir).unwrap();
        let marker = root.join("c8-marker");
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "c6_index_page_published" {
                    let mut file = File::create(&marker).unwrap();
                    file.write_all(b"batched index publication after WAL force")
                        .unwrap();
                    file.sync_all().unwrap();
                    std::process::exit(86);
                }
            }),
        );
        db.bulk_load(db.new_session(), "t", (7000..7256).map(|n| Ok(row(n))))
            .unwrap();
        panic!("crash boundary not reached");
    }
    let (root, dir) = migrated();
    let db = Coordinator::open(&dir).unwrap();
    let id = db.new_session();
    db.bulk_load(id, "t", (1000..3048).rev().map(|n| Ok(row(n))))
        .unwrap();
    assert_eq!(
        db.execute(id, "SELECT id FROM t WHERE id=2048").unwrap(),
        "id\n2048\n"
    );
    db.bulk_begin(id, "t").unwrap();
    db.bulk_batch(id, &[row(4000)]).unwrap();
    db.bulk_batch(id, &[row(1000)]).unwrap();
    assert_eq!(
        db.execute(id, "COMMIT").unwrap_err().code,
        ErrorCode::ConstraintViolation
    );
    db.execute(id, "ROLLBACK").unwrap();
    db.bulk_begin(id, "t").unwrap();
    db.bulk_batch(id, &[row(4000)]).unwrap();
    db.execute(id, "ROLLBACK").unwrap();
    assert_eq!(
        db.execute(id, "SELECT COUNT(*) AS n FROM t WHERE id=4000")
            .unwrap(),
        "n\n0\n"
    );
    db.bulk_load(
        id,
        "t",
        [5000, 5001].map(|n| {
            Ok(Row::new(vec![
                Value::Int64(n),
                Value::Int64(44),
                Value::Null,
            ]))
        }),
    )
    .unwrap();
    assert!(
        db.bulk_load(
            id,
            "t",
            [6000, 6001].map(|n| Ok(Row::new(vec![
                Value::Int64(n),
                Value::Int64(44),
                Value::Int64(0)
            ])))
        )
        .is_err()
    );
    db.disconnect(id);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "--exact",
            "tests::mvcc::c7_bulk::c8_runtime_batch_constraints_rollback_and_crash",
            "--nocapture",
        ])
        .env(CHILD, &root)
        .status()
        .unwrap();
    assert_eq!(status.code(), Some(86));
    assert!(root.join("c8-marker").exists());
    for _ in 0..2 {
        let db = Coordinator::open(&dir).unwrap();
        let id = db.new_session();
        assert_eq!(
            db.execute(id, "SELECT COUNT(*) AS n FROM t WHERE id>=7000")
                .unwrap(),
            "n\n256\n"
        );
        assert_eq!(
            db.execute(id, "SELECT id FROM t WHERE id=7123").unwrap(),
            "id\n7123\n"
        );
        db.disconnect(id);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}
