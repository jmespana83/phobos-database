use super::*;

#[test]
fn production_coordinator_rejects_v1_directory_copy_engine() {
    let root = temp_dir("e45-v1-retired");
    fs::create_dir_all(&root).unwrap();
    // A non-empty pre-WAL directory selects the historical V1 compatibility
    // reader in phobos-execution. The production coordinator must not route it.
    fs::write(root.join("legacy.marker"), b"v1").unwrap();
    let error = Coordinator::open(&root).err().expect("V1 must be rejected");
    assert_eq!(error.code, ErrorCode::Unsupported);
    assert!(error.message.contains("offline MVCC migration"));
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn empty_server_database_uses_non_copy_v2_path() {
    let root = temp_dir("e45-v2");
    let coordinator = Coordinator::open(&root).unwrap();
    let guard = coordinator.database.lock().unwrap();
    assert!(!guard.as_ref().unwrap().uses_legacy_v1_copy_engine());
    drop(guard);
    coordinator.shutdown().unwrap();
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn e4_surface_executes_through_supported_mvcc_server_path() {
    let root = temp_dir("e45-mvcc-sql");
    let source = root.join("source");
    let mut legacy = Database::open(&source).unwrap();
    legacy
        .execute("CREATE TABLE t (id BIGINT, name TEXT)")
        .unwrap();
    legacy
        .execute("INSERT INTO t VALUES (1,'alice'),(2,'bob'),(3,'al')")
        .unwrap();
    drop(legacy);
    let data = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &data).unwrap();
    let coordinator = Coordinator::open(&data).unwrap();
    let session = coordinator.new_session();
    let result = coordinator.execute(session, "SELECT DISTINCT CASE WHEN UPPER(name) LIKE 'AL%' THEN UPPER(name) ELSE 'OTHER' END AS label FROM t WHERE id IN (1,2,3,NULL) ORDER BY 1").unwrap();
    assert_eq!(result, "label\nAL\nALICE\nOTHER\n");
    coordinator.disconnect(session);
    coordinator.shutdown().unwrap();
    drop(coordinator);
    phobos_admin::check_integrity(&data).unwrap();
    fs::remove_dir_all(root).unwrap();
}
