//! 0.1.9-A3 through the full stack: a store migrated with a tiny initial
//! status grant keeps accepting transactions far past it, across restarts,
//! with the offline integrity check clean.
use super::*;

#[test]
fn a3_migrated_store_grows_past_its_initial_status_capacity() {
    let root = temp_dir("a3-growth");
    fs::create_dir_all(&root).unwrap();
    let source = root.join("source");
    let mut db = Database::open(&source).unwrap();
    db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
        .unwrap();
    db.execute("CREATE UNIQUE INDEX u ON t(id)").unwrap();
    db.execute("INSERT INTO t VALUES (1,1),(2,2),(3,3)")
        .unwrap();
    drop(db);
    let destination = root.join("mvcc");
    // Initial grant of 4 identities: the migration itself uses identity 1.
    phobos_admin::migrate_mvcc_copy_with_capacity(&source, &root.join("backup"), &destination, 4)
        .unwrap();
    let status = destination.join("phobos.mvcc-status");
    let capacity = |path: &PathBuf| {
        let bytes = fs::read(path).unwrap();
        u64::from_le_bytes(bytes[8..16].try_into().unwrap())
    };
    assert_eq!(capacity(&status), 4);
    let mut expected_rows = 3i64;
    for restart in 0..3 {
        let db = Arc::new(Coordinator::open(&destination).unwrap());
        let session = db.new_session();
        for step in 0..30i64 {
            let id = 100 + restart * 100 + step;
            db.execute(session, "BEGIN").unwrap();
            db.execute(session, &format!("INSERT INTO t VALUES ({id},{step})"))
                .unwrap();
            if step % 3 == 0 {
                db.execute(session, "ROLLBACK").unwrap();
            } else {
                db.execute(session, "COMMIT").unwrap();
                expected_rows += 1;
            }
        }
        let count = db.execute(session, "SELECT COUNT(*) AS n FROM t").unwrap();
        assert!(count.contains(&expected_rows.to_string()), "{count}");
        db.disconnect(session);
        db.shutdown().unwrap();
        drop(db);
        assert!(capacity(&status) > 4, "grant grew past the initial 4");
        phobos_admin::check_integrity(&destination).unwrap();
    }
    // Every statement above needed at least one identity: well past 4, and
    // the grant (default extent) covers all of them.
    let bytes = fs::read(&status).unwrap();
    let boundary = u64::from_le_bytes(bytes[16..24].try_into().unwrap());
    assert!(boundary > 90, "{boundary}");
    assert!(capacity(&status) >= boundary - 1);
    fs::remove_dir_all(root).unwrap();
}
