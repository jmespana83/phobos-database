//! C9 focused tests: bulk index build/merge through the dedicated import.
use super::*;
use phobos_types::{Row, Value};

fn row(id: i64) -> Row {
    Row::new(vec![Value::Int64(id), Value::Int64(id), Value::Int64(7)])
}
fn count(db: &Coordinator, id: u64, predicate: &str) -> i64 {
    db.execute(
        id,
        &format!("SELECT COUNT(*) AS n FROM t WHERE {predicate}"),
    )
    .unwrap()
    .trim_start_matches("n\n")
    .trim()
    .parse()
    .unwrap()
}
fn reopen_verify(dir: &Path, predicate: &str, expected: i64, probe: i64) {
    for _ in 0..2 {
        let db = Coordinator::open(dir).unwrap();
        let id = db.new_session();
        assert_eq!(count(&db, id, predicate), expected);
        if expected > 0 {
            assert_eq!(
                db.execute(id, &format!("SELECT id FROM t WHERE id={probe}"))
                    .unwrap(),
                format!("id\n{probe}\n")
            );
        }
        db.disconnect(id);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(dir).unwrap();
    }
}

/// Empty index build, merge into a populated index, unique/non-unique/
/// composite/NULL semantics, in-batch and committed conflicts, rollback.
#[test]
fn c9_bulk_build_merge_constraints_and_rollback() {
    // 500 rows: unique u(id), composite unique c(v,g), non-unique duplicates(g).
    let (root, dir) = migrated_rows(500);
    let db = Coordinator::open(&dir).unwrap();
    let id = db.new_session();
    // Empty index build: a fresh table with a unique and a non-unique index.
    db.execute(
        id,
        "CREATE TABLE e (k BIGINT NOT NULL, name TEXT, grp BIGINT)",
    )
    .unwrap();
    db.execute(id, "CREATE UNIQUE INDEX e_k ON e(k)").unwrap();
    db.execute(id, "CREATE INDEX e_grp ON e(grp, k)").unwrap();
    db.bulk_load(
        id,
        "e",
        (0..5000).rev().map(|k| {
            Ok(Row::new(vec![
                Value::Int64(k),
                Value::Text(format!("name-{k}")),
                Value::Int64(k % 10),
            ]))
        }),
    )
    .unwrap();
    assert_eq!(
        db.execute(id, "SELECT k FROM e WHERE k=4321").unwrap(),
        "k\n4321\n"
    );
    assert_eq!(
        db.execute(id, "SELECT COUNT(*) AS n FROM e WHERE grp=3 AND k>=0")
            .unwrap(),
        "n\n500\n"
    );
    // Merge into the populated table: interleaved and appended keys, in
    // descending input order, with duplicate non-unique g values.
    let before = count(&db, id, "id>=1");
    db.bulk_load(
        id,
        "t",
        (0..3000)
            .rev()
            .map(|n| Ok(row(if n < 1000 { 10_000 + n } else { 100_000 + n }))),
    )
    .unwrap();
    assert_eq!(count(&db, id, "id>=1"), before + 3000);
    assert_eq!(count(&db, id, "g=7"), before + 3000);
    assert_eq!(count(&db, id, "id>=10000 AND id<11000"), 1000);
    assert_eq!(
        db.execute(id, "SELECT id FROM t WHERE id=102999").unwrap(),
        "id\n102999\n"
    );
    // Duplicate inside the incoming batch (unique u): COMMIT rejects it.
    let error = db
        .bulk_load(id, "t", [row(50_000), row(50_001), row(50_000)].map(Ok))
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ConstraintViolation);
    assert_eq!(count(&db, id, "id>=50000 AND id<60000"), 0);
    // Incoming key conflicting with an existing committed key.
    let error = db
        .bulk_load(id, "t", [row(60_000), row(3)].map(Ok))
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ConstraintViolation);
    assert_eq!(count(&db, id, "id>=60000 AND id<70000"), 0);
    // Composite unique (v,g): NULL-containing keys never conflict; equal
    // non-NULL composite keys do, both inside the batch and against t.
    db.bulk_load(
        id,
        "t",
        [
            Row::new(vec![Value::Int64(70_000), Value::Int64(44), Value::Null]),
            Row::new(vec![Value::Int64(70_001), Value::Int64(44), Value::Null]),
            Row::new(vec![Value::Int64(70_002), Value::Null, Value::Null]),
            Row::new(vec![Value::Int64(70_003), Value::Null, Value::Int64(7)]),
        ]
        .map(Ok),
    )
    .unwrap();
    assert_eq!(count(&db, id, "id>=70000 AND id<71000"), 4);
    assert!(
        db.bulk_load(
            id,
            "t",
            [
                Row::new(vec![
                    Value::Int64(71_000),
                    Value::Int64(45),
                    Value::Int64(1)
                ]),
                Row::new(vec![
                    Value::Int64(71_001),
                    Value::Int64(45),
                    Value::Int64(1)
                ]),
            ]
            .map(Ok)
        )
        .is_err()
    );
    assert!(
        db.bulk_load(
            id,
            "t",
            [Row::new(vec![
                Value::Int64(71_002),
                Value::Int64(5),
                Value::Int64(7)
            ])]
            .map(Ok)
        )
        .is_err()
    );
    assert_eq!(count(&db, id, "id>=71000 AND id<80000"), 0);
    // Rollback before publication leaves nothing behind and the table usable.
    db.bulk_begin(id, "t").unwrap();
    db.bulk_batch(id, &(80_000..80_100).map(row).collect::<Vec<_>>())
        .unwrap();
    db.execute(id, "ROLLBACK").unwrap();
    assert_eq!(count(&db, id, "id>=80000 AND id<90000"), 0);
    db.bulk_load(id, "t", (80_000..80_010).map(|n| Ok(row(n))))
        .unwrap();
    assert_eq!(count(&db, id, "id>=80000 AND id<90000"), 10);
    // Ordinary SQL still works against the bulk-built indexes.
    db.execute(id, "INSERT INTO t VALUES (90000,90000,7)")
        .unwrap();
    assert!(db.execute(id, "INSERT INTO t VALUES (102999,1,1)").is_err());
    assert_eq!(count(&db, id, "id>=90000 AND id<100000"), 1);
    db.disconnect(id);
    db.shutdown().unwrap();
    drop(db);
    reopen_verify(&dir, "id>=1", before + 3000 + 4 + 10 + 1, 102_999);
    fs::remove_dir_all(root).unwrap();
}

/// Text keys make every index need several leaf pages and two upper levels.
#[test]
fn c9_bulk_multilevel_tree_reopen_and_integrity() {
    let (root, dir) = migrated();
    let db = Coordinator::open(&dir).unwrap();
    let id = db.new_session();
    db.execute(
        id,
        "CREATE TABLE w (id BIGINT NOT NULL, name TEXT NOT NULL)",
    )
    .unwrap();
    db.execute(id, "CREATE UNIQUE INDEX w_name ON w(name)")
        .unwrap();
    db.execute(id, "CREATE INDEX w_id ON w(id)").unwrap();
    let name = |n: i64| format!("{:06}-{}", (n * 7919) % 20_000, "x".repeat(220));
    db.bulk_load(
        id,
        "w",
        (0..20_000).map(|n| Ok(Row::new(vec![Value::Int64(n), Value::Text(name(n))]))),
    )
    .unwrap();
    assert_eq!(
        db.execute(
            id,
            &format!("SELECT id FROM w WHERE name='{}'", name(12_345))
        )
        .unwrap(),
        "id\n12345\n"
    );
    db.disconnect(id);
    db.shutdown().unwrap();
    drop(db);
    let report = phobos_admin::check_integrity(&dir).unwrap();
    // Rough shape check: two text indexes of 20K wide keys need hundreds of
    // pages; the trees are validated page by page above.
    assert!(report.index_pages > 500, "{report:?}");
    let catalog = phobos_catalog::Catalog::open(&dir).unwrap();
    let unique = catalog
        .indexes()
        .find(|index| index.name == "w_name")
        .unwrap();
    let mut tree = phobos_index::BPlusTree::open(
        dir.join(phobos_wal::v2::FileId::Index(unique.id).name()),
        true,
        1,
    )
    .unwrap();
    let validation = tree.validate().unwrap();
    assert!(
        validation.height >= 3 && validation.entries == 20_000,
        "{validation:?}"
    );
    drop(tree);
    let db = Coordinator::open(&dir).unwrap();
    let id = db.new_session();
    assert_eq!(
        db.execute(id, "SELECT COUNT(*) AS n FROM w WHERE id>=0")
            .unwrap(),
        "n\n20000\n"
    );
    db.disconnect(id);
    db.shutdown().unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Failure during private index construction (corrupted sorted key scratch)
/// happens after admission but before anything durable exists. D2: the
/// import alone is aborted (private images undone, status Aborted), no
/// success is returned, the database stays available, and reopen leaves the
/// committed table and indexes intact. (Before D2 this fenced the database.)
#[test]
fn c9_bulk_index_construction_failure_fences_and_recovers() {
    let (root, dir) = migrated_rows(200);
    let db = Coordinator::open(&dir).unwrap();
    let id = db.new_session();
    let data_dir = fs::canonicalize(&dir).unwrap();
    let scratch_root = data_dir.clone();
    let _hook = phobos_observability::test_hooks::register(
        &dir,
        Arc::new(move |point| {
            if point == "c9_bulk_finalized" {
                for entry in fs::read_dir(&scratch_root).unwrap() {
                    let path = entry.unwrap().path();
                    if !path.file_name().is_some_and(|name| {
                        name.to_string_lossy().starts_with(".phobos-mvcc-bulk-")
                    }) {
                        continue;
                    }
                    for file in fs::read_dir(&path).unwrap() {
                        let file = file.unwrap().path();
                        if file
                            .file_name()
                            .unwrap()
                            .to_string_lossy()
                            .starts_with("sorted-")
                        {
                            let mut bytes = fs::read(&file).unwrap();
                            bytes[3] ^= 0x5a;
                            fs::write(&file, bytes).unwrap();
                        }
                    }
                }
            }
        }),
    );
    let error = db
        .bulk_load(id, "t", (5000..6000).map(|n| Ok(row(n))))
        .unwrap_err();
    assert_ne!(error.code, ErrorCode::ConstraintViolation);
    assert_eq!(
        db.execute(id, "SELECT id FROM t WHERE id=1").unwrap(),
        "id\n1\n"
    );
    assert_eq!(
        db.execute(id, "SELECT COUNT(*) AS n FROM t WHERE id>=5000")
            .unwrap(),
        "n\n0\n"
    );
    // The connection and the database continue; the same key range loads.
    db.execute(id, "INSERT INTO t VALUES (5000,5000,7)")
        .unwrap();
    db.execute(id, "DELETE FROM t WHERE id=5000").unwrap();
    db.disconnect(id);
    drop(db);
    reopen_verify(&dir, "id>=5000", 0, 0);
    reopen_verify(&dir, "id>=1", 200, 150);
    fs::remove_dir_all(root).unwrap();
}

/// Crashes around publication: after the private build (before any WAL) the
/// import must be absent; during index page installation (after the durable
/// force) it must be complete. Offline integrity holds in both cases.
#[test]
fn c9_bulk_crash_before_wal_and_during_index_publication() {
    const CHILD: &str = "PHOBOS_C9_CRASH_POINT";
    if let Ok(point) = std::env::var(CHILD) {
        let root = PathBuf::from(std::env::var_os("PHOBOS_C9_ROOT").unwrap());
        let dir = root.join("mvcc");
        let db = Coordinator::open(&dir).unwrap();
        let target = point.clone();
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |observed| {
                if observed == target {
                    std::process::exit(86);
                }
            }),
        );
        db.bulk_load(db.new_session(), "t", (7000..9000).map(|n| Ok(row(n))))
            .unwrap();
        panic!("crash boundary not reached");
    }
    for (point, expected) in [
        ("c9_bulk_index_built", 0),
        ("c6_index_page_published", 2000),
    ] {
        let (root, dir) = migrated_rows(300);
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "tests::mvcc::c9_bulk::c9_bulk_crash_before_wal_and_during_index_publication",
                "--nocapture",
            ])
            .env(CHILD, point)
            .env("PHOBOS_C9_ROOT", &root)
            .status()
            .unwrap();
        assert_eq!(status.code(), Some(86), "{point}");
        reopen_verify(&dir, "id>=7000", expected, 8123);
        reopen_verify(&dir, "id>=1", 300 + expected, 250);
        fs::remove_dir_all(root).unwrap();
    }
}
