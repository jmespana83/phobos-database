use super::*;
fn sizes(dir: &Path) -> (u64, u64) {
    let mut result = (0, 0);
    for entry in fs::read_dir(dir).unwrap() {
        let path = entry.unwrap().path();
        let pages = fs::metadata(&path).unwrap().len() / 8192;
        match path.extension().and_then(|e| e.to_str()) {
            Some("heap") => result.0 += pages,
            Some("idx") => result.1 += pages,
            _ => {}
        }
    }
    result
}
#[test]
fn c5_ten_churn_rounds_reuse_heap_index_pages_freeze_and_check_integrity() {
    let (root, dir) = migrated_rows(1000);
    let db = Coordinator::open(&dir).unwrap();
    let session = db.new_session();
    let before = sizes(&dir);
    let mut rounds = Vec::new();
    let mut boundaries = Vec::new();
    for round in 1..=10 {
        db.execute(session, &format!("UPDATE t SET v=id+{}", round * 100000))
            .unwrap();
        db.execute(session, "DELETE FROM t WHERE id>950").unwrap();
        let values = (951..=1000)
            .map(|id| format!("({id},{},7)", id + round * 100000))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(session, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
        db.execute(session, "CHECKPOINT").unwrap();
        for _ in 0..4 {
            let r = db.reclaim_once(64).unwrap();
            if r.candidates_remaining == 0 && r.versions_reclaimed == 0 {
                break;
            }
        }
        let runtime = db.mvcc.as_ref().unwrap();
        runtime.freeze_once(64).unwrap();
        runtime.checkpoint().unwrap();
        assert_eq!(
            db.execute(session, "SELECT COUNT(*) AS n FROM t").unwrap(),
            "n\n1000\n"
        );
        rounds.push(sizes(&dir));
        boundaries.push(runtime.freeze_metrics().unwrap().0);
    }
    let end = *rounds.last().unwrap();
    assert!(
        end.0 <= before.0 * 3,
        "heap growth: {before:?} -> {rounds:?}"
    );
    assert!(
        end.1 <= before.1 * 3,
        "index growth: {before:?} -> {rounds:?}"
    );
    assert!(
        end.0 <= rounds[4].0 + 4,
        "heap must plateau/reuse over later rounds: {rounds:?}"
    );
    assert!(
        end.1 <= rounds[4].1 + 8,
        "indexes must plateau/reuse over later rounds: {rounds:?}"
    );
    assert!(boundaries[0] > 1);
    assert!(boundaries[9] > boundaries[0]);
    let expected = db
        .execute(session, "SELECT id,v FROM t ORDER BY id")
        .unwrap();
    eprintln!(
        "C5 10x churn pages initial {before:?}; rounds {rounds:?}; watermarks {boundaries:?}"
    );
    db.disconnect(session);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    let db = Coordinator::open(&dir).unwrap();
    let session = db.new_session();
    assert_eq!(
        db.execute(session, "SELECT id,v FROM t ORDER BY id")
            .unwrap(),
        expected
    );
    assert_eq!(
        db.mvcc.as_ref().unwrap().freeze_metrics().unwrap().0,
        *boundaries.last().unwrap()
    );
    db.disconnect(session);
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    fs::remove_dir_all(root).unwrap();
}
