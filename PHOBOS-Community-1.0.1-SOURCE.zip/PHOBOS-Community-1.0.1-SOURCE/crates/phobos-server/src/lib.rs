#![forbid(unsafe_code)]
//! Hardened TCP server with explicit database-capability routing.
//!
//! Legacy databases retain the C1-C4 ownership/publication coordinator.
//! Explicitly migrated capability-4 databases use per-session MVCC reads and
//! logical write overlays, with ordered WAL-durable publication.

use fs2::FileExt;
use phobos_auth::{AuthStore, Role, classify_sql};
use phobos_error::{ErrorCode, PhobosError};
use phobos_execution::{Database, ResultSink};
use phobos_observability::Metrics;
use phobos_protocol::streaming::{BATCH_ROWS, CAPABILITY, Event, TARGET_BATCH_BYTES, encode_row};
use phobos_protocol::{Frame, MessageType};
#[cfg(test)]
use rustls::StreamOwned;
use rustls::{
    RootCertStore, ServerConfig as TlsServerConfig, ServerConnection,
    pki_types::{CertificateDer, PrivateKeyDer},
    server::WebPkiClientVerifier,
};
use std::{
    collections::BTreeMap,
    fs::{File, OpenOptions},
    io::{self, BufReader, Read, Write},
    net::{TcpListener, TcpStream},
    path::{Path, PathBuf},
    sync::{
        Arc, Condvar, Mutex,
        atomic::{AtomicBool, AtomicU64, Ordering},
    },
    thread,
    time::{Duration, Instant},
};

mod cancellation;
mod g1g2;
pub use cancellation::{DEFAULT_IDLE_TIMEOUT, DEFAULT_STATEMENT_TIMEOUT};
pub use phobos_config::RuntimeConfig;

const DEFAULT_LOCK_WAIT: Duration = Duration::from_secs(2);

/// Shared server-side database coordinator.
///
/// Explicit session ownership and bounded group admission preserve strict isolation.
/// The database-slot mutex is released before execution, WAL force and network I/O.
pub struct Coordinator {
    cancellation: cancellation::Registry,
    statement_timeout: Duration,
    idle_timeout: Duration,
    mvcc: Option<Arc<phobos_execution::mvcc_runtime::MvccDatabase>>,
    /// 0.2-K Part K: bounded automatic reclamation (MVCC primaries only;
    /// never on a physical standby).
    maintenance: Mutex<Option<phobos_execution::mvcc_runtime::maintenance::MaintenanceWorker>>,
    groups: Mutex<CommitQueue>,
    group_changed: Condvar,
    group_window: Duration,
    database: Mutex<Option<Database>>,
    database_changed: Condvar,
    closing: AtomicBool,
    #[cfg(test)]
    test_directory: PathBuf,
    owner: Mutex<Option<u64>>,
    owner_changed: Condvar,
    next_session: AtomicU64,
    lock_wait: Duration,
    metrics: Arc<Metrics>,
    schema_generation: AtomicU64,
    read_only: bool,
}

impl Coordinator {
    pub fn backup_online(
        &self,
        destination: &std::path::Path,
    ) -> Result<phobos_execution::mvcc_runtime::OnlineBackupReport, PhobosError> {
        self.mvcc
            .as_ref()
            .ok_or_else(|| PhobosError::new(ErrorCode::Unsupported, "online backup requires MVCC"))?
            .backup_online(destination)
    }

    pub fn check_online(
        &self,
    ) -> Result<phobos_execution::mvcc_runtime::OnlineCheckReport, PhobosError> {
        self.mvcc
            .as_ref()
            .ok_or_else(|| PhobosError::new(ErrorCode::Unsupported, "online check requires MVCC"))?
            .check_online()
    }

    pub fn bulk_begin(&self, session: u64, table: &str) -> Result<(), PhobosError> {
        self.require_writable()?;
        self.mvcc
            .as_ref()
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "bulk import requires explicit MVCC capability",
                )
            })?
            .bulk_begin(session, table)
    }
    pub fn bulk_batch(&self, session: u64, rows: &[phobos_types::Row]) -> Result<u64, PhobosError> {
        self.require_writable()?;
        self.mvcc
            .as_ref()
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "bulk import requires explicit MVCC capability",
                )
            })?
            .bulk_batch(session, rows)
    }
    pub fn bulk_load(
        &self,
        session: u64,
        table: &str,
        rows: impl IntoIterator<Item = Result<phobos_types::Row, PhobosError>>,
    ) -> Result<u64, PhobosError> {
        self.require_writable()?;
        self.mvcc
            .as_ref()
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "bulk import requires explicit MVCC capability",
                )
            })?
            .bulk_load(session, table, rows)
    }
    /// 0.1.9-A4: pending-write memtable threshold and per-transaction scratch
    /// quota for transactions that begin afterwards (MVCC stores only).
    pub fn set_write_spill(&self, threshold: usize, scratch_quota: u64) -> Result<(), PhobosError> {
        self.mvcc
            .as_ref()
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "write spilling requires explicit MVCC capability",
                )
            })?
            .set_write_spill(threshold, scratch_quota)
    }
    /// 0.1.9-B1/B2 status-resolution counters (MVCC stores only).
    pub fn status_metrics(
        &self,
    ) -> Result<phobos_execution::mvcc_runtime::StatusMetrics, PhobosError> {
        self.mvcc
            .as_ref()
            .map(|mvcc| mvcc.status_metrics())
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "status metrics require explicit MVCC capability",
                )
            })
    }
    /// 0.1.9-D1 commit-path counters: identities allocated, status records
    /// written and status-file forces (MVCC stores only).
    pub fn commit_metrics(
        &self,
    ) -> Result<phobos_execution::mvcc_runtime::CommitMetrics, PhobosError> {
        self.mvcc
            .as_ref()
            .map(|mvcc| mvcc.commit_metrics())
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "commit metrics require explicit MVCC capability",
                )
            })
    }
    /// 0.1.9-D3 admission counters: write statements and committed views
    /// built for their admission (MVCC stores only).
    pub fn admission_metrics(
        &self,
    ) -> Result<phobos_execution::mvcc_runtime::AdmissionMetrics, PhobosError> {
        self.mvcc
            .as_ref()
            .map(|mvcc| mvcc.admission_metrics())
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "admission metrics require explicit MVCC capability",
                )
            })
    }
    /// 0.1.9-C2: one bounded dead-version reclaim pass (MVCC stores only).
    pub fn reclaim_once(
        &self,
        limit: usize,
    ) -> Result<phobos_execution::mvcc_runtime::ReclaimReport, PhobosError> {
        self.mvcc
            .as_ref()
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "reclamation requires explicit MVCC capability",
                )
            })?
            .reclaim_once(limit)
    }
    /// 0.2-K Part N: per-table and global storage-lifecycle diagnostics
    /// (MVCC stores only; read-only, no checkpoint).
    pub fn storage_lifecycle(
        &self,
        row_need: Option<usize>,
    ) -> Result<phobos_execution::mvcc_runtime::StorageLifecycleReport, PhobosError> {
        self.mvcc
            .as_ref()
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "storage lifecycle diagnostics require explicit MVCC capability",
                )
            })?
            .storage_lifecycle_report(row_need)
    }
    /// 0.2-K Part N: cumulative reclamation counters (MVCC stores only).
    pub fn reclaim_metrics(
        &self,
    ) -> Result<phobos_execution::mvcc_runtime::ReclaimMetrics, PhobosError> {
        self.mvcc
            .as_ref()
            .map(|mvcc| mvcc.reclaim_metrics())
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Unsupported,
                    "reclaim metrics require explicit MVCC capability",
                )
            })
    }
    /// Stops the automatic reclamation worker (after its current pass), e.g.
    /// for measurements that need a quiescent database. Idempotent.
    pub fn stop_automatic_reclamation(&self) {
        let worker = self
            .maintenance
            .lock()
            .ok()
            .and_then(|mut worker| worker.take());
        if let Some(mut worker) = worker {
            worker.stop();
        }
    }
    /// Whether the automatic reclamation worker runs for this database.
    #[must_use]
    pub fn automatic_reclamation(&self) -> bool {
        self.maintenance.lock().is_ok_and(|worker| worker.is_some())
    }
    pub fn flush_stats(&self) -> Result<phobos_execution::FlushStats, PhobosError> {
        if let Some(mvcc) = &self.mvcc {
            return mvcc.flush_stats();
        }
        self.lease_database(Some(Instant::now() + self.lock_wait))?
            .flush_stats()
    }
    pub fn open(data_dir: &Path) -> Result<Self, PhobosError> {
        Self::open_with_timeout(data_dir, DEFAULT_LOCK_WAIT)
    }

    fn open_with_timeout(data_dir: &Path, lock_wait: Duration) -> Result<Self, PhobosError> {
        let mut config = RuntimeConfig::load(None)?;
        config.lock_timeout_ms = u64::try_from(lock_wait.as_millis())
            .map_err(|_| PhobosError::new(ErrorCode::ResourceLimit, "lock wait overflow"))?;
        Self::open_configured(data_dir, &config)
    }
    fn open_configured(data_dir: &Path, config: &RuntimeConfig) -> Result<Self, PhobosError> {
        config.validate()?;
        let lock_wait = Duration::from_millis(config.lock_timeout_ms);
        let group_window = match std::env::var("PHOBOS_GROUP_WINDOW_US") {
            Ok(value) => value
                .parse::<u64>()
                .ok()
                .filter(|value| *value <= 200)
                .map(Duration::from_micros)
                .ok_or_else(|| {
                    PhobosError::new(
                        ErrorCode::ResourceLimit,
                        "PHOBOS_GROUP_WINDOW_US must be between 0 and 200",
                    )
                })?,
            // Windows timed waits rounded sub-millisecond windows to ~15 ms in
            // C1 controls. Queue arrivals still batch during execution at zero.
            Err(std::env::VarError::NotPresent) => Duration::ZERO,
            Err(_) => {
                return Err(PhobosError::new(
                    ErrorCode::ResourceLimit,
                    "invalid group window encoding",
                ));
            }
        };
        let mvcc = if phobos_execution::mvcc_runtime::MvccDatabase::is_capable(data_dir)? {
            Some(Arc::new(
                phobos_execution::mvcc_runtime::MvccDatabase::open_with_config(data_dir, config)?,
            ))
        } else {
            None
        };
        let read_only = data_dir.join("PHOBOS_STANDBY_1").exists();
        // 0.2-K.4: a writable primary enables LAZY_INDEX_PRUNING_V1 at open
        // when it has a non-unique index (nothing can conflict yet). The
        // capability is a WAL-logged catalog change: standbys and PITR
        // receive it through replay, never by enabling it themselves.
        if let Some(mvcc) = &mvcc {
            if !read_only {
                mvcc.try_enable_lazy_index_pruning()?;
            }
        }
        let maintenance = match &mvcc {
            Some(mvcc)
                if !read_only
                    && phobos_execution::mvcc_runtime::maintenance::MaintenanceConfig::enabled_from_env() =>
            {
                Some(
                    phobos_execution::mvcc_runtime::maintenance::MaintenanceWorker::start(
                        mvcc.clone(),
                        phobos_execution::mvcc_runtime::maintenance::MaintenanceConfig::from_env()?,
                    )?,
                )
            }
            _ => None,
        };
        let database = if mvcc.is_some() {
            None
        } else {
            let database = Database::open_with_config(data_dir, config)?;
            if database.uses_legacy_v1_copy_engine() {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "legacy V1 databases require offline MVCC migration; the production server will not run directory-copy autocommit",
                ));
            }
            Some(database)
        };
        Ok(Self {
            cancellation: Default::default(),
            statement_timeout: Duration::from_millis(config.statement_timeout_ms),
            idle_timeout: Duration::from_millis(config.idle_timeout_ms),
            mvcc,
            maintenance: Mutex::new(maintenance),
            group_window,
            groups: Mutex::new(CommitQueue::default()),
            group_changed: Condvar::new(),
            database: Mutex::new(database),
            database_changed: Condvar::new(),
            closing: AtomicBool::new(false),
            #[cfg(test)]
            test_directory: std::fs::canonicalize(data_dir)?,
            owner: Mutex::new(None),
            owner_changed: Condvar::new(),
            next_session: AtomicU64::new(1),
            lock_wait,
            metrics: Arc::new(Metrics::default()),
            schema_generation: AtomicU64::new(0),
            read_only,
        })
    }

    pub fn with_timeouts(mut self, statement: Duration, idle: Duration) -> Self {
        self.statement_timeout = statement;
        self.idle_timeout = idle;
        self
    }
    #[must_use]
    pub fn new_session(&self) -> u64 {
        self.next_session.fetch_add(1, Ordering::Relaxed)
    }

    pub fn execute(&self, session_id: u64, sql: &str) -> Result<String, PhobosError> {
        if self.read_only && classify_sql(sql) != phobos_auth::Action::Read {
            return Err(PhobosError::new(
                ErrorCode::Authorization,
                "physical standby is read-only",
            ));
        }
        let result = self.execute_inner(session_id, sql);
        self.observe_statement(sql, &result);
        if self.mvcc.is_none()
            && result
                .as_ref()
                .is_err_and(phobos_error::cancellation::is_interrupted)
            && classify_sql(sql) != phobos_auth::Action::Read
        {
            self.disconnect(session_id);
        }
        result
    }
    fn require_writable(&self) -> Result<(), PhobosError> {
        if self.read_only {
            Err(PhobosError::new(
                ErrorCode::Authorization,
                "physical standby is read-only",
            ))
        } else {
            Ok(())
        }
    }
    fn observe_statement<T>(&self, sql: &str, result: &Result<T, PhobosError>) {
        if result.is_ok() {
            let keyword = sql.split_whitespace().next().unwrap_or("");
            if matches!(
                keyword.to_ascii_uppercase().as_str(),
                "CREATE" | "DROP" | "ALTER"
            ) {
                self.schema_generation.fetch_add(1, Ordering::AcqRel);
            }
            match keyword.to_ascii_uppercase().as_str() {
                "COMMIT" => self.metrics.transaction_committed(),
                "ROLLBACK" => self.metrics.transaction_aborted(),
                _ => {}
            }
        } else if result
            .as_ref()
            .is_err_and(phobos_error::cancellation::is_interrupted)
        {
            self.metrics.statement_cancelled();
        }
    }
    #[must_use]
    pub fn schema_generation(&self) -> u64 {
        self.schema_generation.load(Ordering::Acquire)
    }
    pub fn execute_prepared(
        &self,
        session_id: u64,
        statement: phobos_sql::Statement,
    ) -> Result<String, PhobosError> {
        self.metrics.query_started();
        let result = if let Some(mvcc) = &self.mvcc {
            mvcc.execute_prepared_read(session_id, statement)
        } else {
            self.admitted_database(session_id, None)?
                .execute_prepared_read(statement)
        };
        let result = result.and_then(|value| value.to_text_cancellable());
        if result
            .as_ref()
            .is_err_and(phobos_error::cancellation::is_interrupted)
        {
            self.metrics.statement_cancelled();
        }
        result
    }
    fn metrics_text(&self) -> String {
        let mut output = String::from("name\tvalue\tkind\n");
        for (name, value, kind) in self.operator_metrics_rows() {
            use std::fmt::Write as _;
            writeln!(&mut output, "{name}\t{value}\t{kind}").expect("write to string");
        }
        output
    }
    fn operator_metrics_rows(&self) -> Vec<(String, u64, String)> {
        let mut rows = self
            .metrics
            .snapshot()
            .rows()
            .into_iter()
            .map(|(name, value, kind)| (name.into(), value, kind.into()))
            .collect::<Vec<_>>();
        if let Ok(status) = self.status_metrics() {
            rows.extend([
                (
                    "status_lookups".into(),
                    status.status_lookups,
                    "counter".into(),
                ),
                (
                    "status_cache_hits".into(),
                    status.shared_cache_hits,
                    "counter".into(),
                ),
                (
                    "status_cache_misses".into(),
                    status.status_page_reads,
                    "counter".into(),
                ),
                (
                    "visibility_hint_hits".into(),
                    status.hint_hits,
                    "counter".into(),
                ),
            ]);
        }
        if let Some(mvcc) = &self.mvcc {
            // 0.2-K Part N: reclamation counters and backlog (cheap, in
            // memory; the full per-table census is `storage_lifecycle`).
            let reclaim = mvcc.reclaim_metrics();
            for (name, value, kind) in [
                ("reclaim_passes", reclaim.passes, "counter"),
                (
                    "reclaim_automatic_passes",
                    reclaim.automatic_passes,
                    "counter",
                ),
                ("reclaim_pages_examined", reclaim.pages_examined, "counter"),
                (
                    "reclaim_versions_reclaimed",
                    reclaim.versions_reclaimed,
                    "counter",
                ),
                ("reclaim_slots_freed", reclaim.slots_freed, "counter"),
                ("reclaim_slots_trimmed", reclaim.slots_trimmed, "counter"),
                ("reclaim_pages_reset", reclaim.pages_reset, "counter"),
                (
                    "reclaim_versions_deferred",
                    reclaim.versions_deferred,
                    "counter",
                ),
                (
                    "reclaim_deferred_by_horizon",
                    reclaim.retired_deferred + reclaim.pages_deferred,
                    "counter",
                ),
                ("reclaim_elapsed_us", reclaim.elapsed_us, "counter"),
                ("reclaim_candidate_pages", reclaim.candidate_pages, "gauge"),
                ("reclaim_retired_pages", reclaim.retired_pages, "gauge"),
                (
                    "reclaim_rate_per_second",
                    reclaim.last_rate_per_second,
                    "gauge",
                ),
            ] {
                rows.push((name.into(), value, kind.into()));
            }
        }
        if let Ok(flush) = self.flush_stats() {
            rows.extend([
                (
                    "page_cache_resident_pages".into(),
                    u64::try_from(flush.resident_pages).unwrap_or(u64::MAX),
                    "gauge".into(),
                ),
                (
                    "page_cache_resident_bytes".into(),
                    u64::try_from(flush.resident_bytes).unwrap_or(u64::MAX),
                    "gauge".into(),
                ),
                (
                    "dirty_pages".into(),
                    u64::try_from(flush.dirty_pages).unwrap_or(u64::MAX),
                    "gauge".into(),
                ),
                (
                    "pages_flushed".into(),
                    flush.pages_flushed,
                    "counter".into(),
                ),
                (
                    "bytes_flushed".into(),
                    flush.bytes_flushed,
                    "counter".into(),
                ),
            ]);
        }
        rows
    }
    fn execute_inner(&self, session_id: u64, sql: &str) -> Result<String, PhobosError> {
        self.metrics.query_started();
        if let Some(mvcc) = &self.mvcc {
            return mvcc
                .execute(session_id, sql)
                .and_then(|result| result.to_text_cancellable());
        }
        let command = transaction_command(sql);
        match command {
            TxCommand::Begin => self.begin(session_id),
            TxCommand::Commit => self.end_transaction(session_id, true),
            TxCommand::Rollback => self.end_transaction(session_id, false),
            TxCommand::Other => {
                if is_group_dml(sql) {
                    return self
                        .execute_dml(session_id, sql)
                        .and_then(|result| result.to_text_cancellable());
                }
                let mut database = self.admitted_database(session_id, None)?;
                database
                    .execute(sql)
                    .and_then(|result| result.to_text_cancellable())
            }
        }
    }

    pub fn execute_stream_result(
        &self,
        session_id: u64,
        sql: &str,
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        if self.read_only && classify_sql(sql) != phobos_auth::Action::Read {
            return Err(PhobosError::new(
                ErrorCode::Authorization,
                "physical standby is read-only",
            ));
        }
        let result = self.execute_stream_inner(session_id, sql, sink);
        if result
            .as_ref()
            .is_err_and(phobos_error::cancellation::is_interrupted)
        {
            self.metrics.statement_cancelled();
        }
        if self.mvcc.is_none()
            && result
                .as_ref()
                .is_err_and(phobos_error::cancellation::is_interrupted)
            && classify_sql(sql) != phobos_auth::Action::Read
        {
            self.disconnect(session_id);
        }
        result
    }
    fn execute_stream_inner(
        &self,
        session_id: u64,
        sql: &str,
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        if let Some(mvcc) = &self.mvcc {
            self.metrics.query_started();
            return mvcc.execute_stream(session_id, sql, sink);
        }
        let command = transaction_command(sql);
        if command == TxCommand::Other {
            self.metrics.query_started();
            if is_group_dml(sql) {
                return match self.execute_dml(session_id, sql)? {
                    phobos_execution::QueryResult::Command { tag, rows_affected } => {
                        sink.command(tag, rows_affected)
                    }
                    _ => Err(PhobosError::new(
                        ErrorCode::TransactionState,
                        "DML returned a row result",
                    )),
                };
            }
            let mut database = self.admitted_database(session_id, None)?;
            database.execute_stream(sql, &[], sink)
        } else {
            self.execute(session_id, sql)?;
            let tag = match command {
                TxCommand::Begin => "BEGIN",
                TxCommand::Commit => "COMMIT",
                TxCommand::Rollback => "ROLLBACK",
                TxCommand::Other => unreachable!(),
            };
            sink.command(tag.into(), 0)
        }
    }

    #[must_use]
    pub fn metrics(&self) -> Arc<Metrics> {
        Arc::clone(&self.metrics)
    }

    pub fn cancel(&self, session_id: u64) {
        self.cancellation.disconnect(session_id);
        if let Some(mvcc) = &self.mvcc {
            mvcc.cancel(session_id);
        }
    }
    pub fn conflict_diagnostics(
        &self,
    ) -> Result<Option<phobos_execution::mvcc_runtime::ConflictDiagnostics>, PhobosError> {
        self.mvcc
            .as_ref()
            .map(|mvcc| mvcc.conflict_diagnostics())
            .transpose()
    }
    pub fn disconnect(&self, session_id: u64) {
        let _cleanup = phobos_error::cancellation::suspend();
        self.cancellation.disconnect(session_id);
        if let Some(mvcc) = &self.mvcc {
            mvcc.disconnect(session_id);
            return;
        }
        let owns_transaction = self
            .owner
            .lock()
            .map(|owner| *owner == Some(session_id))
            .unwrap_or(false);
        if !owns_transaction {
            return;
        }

        if let Ok(mut database) = self.lock_database() {
            if database.in_transaction() {
                let _ = database.execute("ROLLBACK");
            }
        }
        self.release_owner(session_id);
    }

    /// Close admission and wait for accepted work before checkpointing. A
    /// timeout leaves admission closed; accepted commits are never revoked and
    /// callers may repeat shutdown after they finish. The wait is bounded by
    /// lock_wait; OS durability I/O itself cannot be cancelled safely.
    pub fn shutdown(&self) -> Result<(), PhobosError> {
        if let Some(mvcc) = &self.mvcc {
            // 0.2-K: stop automatic reclamation (after its current pass)
            // before admission closes and the final checkpoint runs.
            if let Some(mut worker) = self
                .maintenance
                .lock()
                .map_err(|_| poisoned_lock_error())?
                .take()
            {
                worker.stop();
            }
            return mvcc.shutdown(self.lock_wait);
        }
        let deadline = Instant::now() + self.lock_wait;
        let mut owner = self.lock_owner()?;
        self.closing.store(true, Ordering::Release);
        self.owner_changed.notify_all();
        while owner.is_some()
            || self
                .groups
                .lock()
                .map_err(|_| poisoned_lock_error())?
                .running
        {
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err(lock_timeout_error());
            }
            let (next, timeout) = self
                .owner_changed
                .wait_timeout(owner, remaining.min(Duration::from_millis(10)))
                .map_err(|_| poisoned_lock_error())?;
            owner = next;
            if timeout.timed_out() && Instant::now() >= deadline {
                return Err(lock_timeout_error());
            }
        }
        drop(owner);
        let mut database = self.lease_database(Some(deadline))?;
        database.shutdown()?;
        Ok(())
    }

    fn begin(&self, session_id: u64) -> Result<String, PhobosError> {
        self.claim_owner(session_id)?;
        let result = self
            .lock_database()?
            .execute("BEGIN")
            .and_then(|result| result.to_text_cancellable());
        if result.is_err() {
            self.release_owner(session_id);
        }
        result
    }

    fn end_transaction(&self, session_id: u64, commit: bool) -> Result<String, PhobosError> {
        {
            let owner = self.lock_owner()?;
            if *owner != Some(session_id) {
                return Err(PhobosError::new(
                    ErrorCode::TransactionState,
                    if commit {
                        "COMMIT attempted by a session that does not own the transaction"
                    } else {
                        "ROLLBACK attempted by a session that does not own the transaction"
                    },
                ));
            }
        }

        let sql = if commit { "COMMIT" } else { "ROLLBACK" };
        let result = self
            .lock_database()?
            .execute(sql)
            .and_then(|result| result.to_text_cancellable());
        if result.is_ok() || !commit {
            self.release_owner(session_id);
        }
        result
    }

    fn claim_owner(&self, session_id: u64) -> Result<(), PhobosError> {
        let deadline = Instant::now() + self.lock_wait;
        let mut owner = self.lock_owner()?;
        loop {
            self.check_admission()?;
            match *owner {
                None if !self
                    .groups
                    .lock()
                    .map_err(|_| poisoned_lock_error())?
                    .running =>
                {
                    *owner = Some(session_id);
                    return Ok(());
                }
                Some(id) if id == session_id => {
                    return Err(PhobosError::new(
                        ErrorCode::TransactionState,
                        "a transaction is already active for this session",
                    ));
                }
                _ => {
                    let now = Instant::now();
                    if now >= deadline {
                        return Err(lock_timeout_error());
                    }
                    let remaining = deadline.saturating_duration_since(now);
                    let (guard, timeout) = self
                        .owner_changed
                        .wait_timeout(owner, remaining.min(Duration::from_millis(10)))
                        .map_err(|_| poisoned_lock_error())?;
                    owner = guard;
                    if timeout.timed_out() && Instant::now() >= deadline {
                        return Err(lock_timeout_error());
                    }
                }
            }
        }
    }

    fn wait_for_turn(
        &self,
        session_id: u64,
    ) -> Result<std::sync::MutexGuard<'_, Option<u64>>, PhobosError> {
        self.wait_for_turn_inner(session_id, false)
    }

    fn wait_for_turn_inner(
        &self,
        session_id: u64,
        drain_groups: bool,
    ) -> Result<std::sync::MutexGuard<'_, Option<u64>>, PhobosError> {
        let _profile = phobos_observability::span("server.wait_for_turn");
        let deadline = Instant::now() + self.lock_wait;
        let mut owner = self.lock_owner()?;
        loop {
            self.check_admission()?;
            match *owner {
                None if !drain_groups
                    || !self
                        .groups
                        .lock()
                        .map_err(|_| poisoned_lock_error())?
                        .running =>
                {
                    return Ok(owner);
                }
                Some(id) if id == session_id => return Ok(owner),
                _ => {
                    let now = Instant::now();
                    if now >= deadline {
                        return Err(lock_timeout_error());
                    }
                    let remaining = deadline.saturating_duration_since(now);
                    let (guard, timeout) = self
                        .owner_changed
                        .wait_timeout(owner, remaining.min(Duration::from_millis(10)))
                        .map_err(|_| poisoned_lock_error())?;
                    owner = guard;
                    if timeout.timed_out() && Instant::now() >= deadline {
                        return Err(lock_timeout_error());
                    }
                }
            }
        }
    }

    fn release_owner(&self, session_id: u64) {
        if let Ok(mut owner) = self.owner.lock() {
            if *owner == Some(session_id) {
                *owner = None;
                self.owner_changed.notify_all();
            }
        }
    }

    // Check admission and take an available database atomically in owner ->
    // slot order. When busy, release admission before waiting, then recheck it:
    // BEGIN may have acquired ownership while this statement was asleep.
    fn admitted_database(
        &self,
        session: u64,
        expected_owner: Option<u64>,
    ) -> Result<DatabaseLease<'_>, PhobosError> {
        let deadline = Instant::now() + self.lock_wait;
        loop {
            let admission = self.wait_for_turn_inner(session, true)?;
            if expected_owner.is_some() && *admission != expected_owner {
                return Err(PhobosError::new(
                    ErrorCode::TransactionState,
                    "explicit ownership changed before statement execution",
                ));
            }
            let mut slot = self.database.lock().map_err(|_| poisoned_lock_error())?;
            if slot.is_some() {
                let hold = phobos_observability::span("server.database_guard_hold");
                let database = slot.take();
                drop(slot);
                drop(hold);
                drop(admission);
                return Ok(DatabaseLease {
                    coordinator: self,
                    database,
                    _ownership: phobos_observability::span("server.database_ownership_hold"),
                });
            }
            drop(admission);
            #[cfg(test)]
            phobos_observability::synchronization_boundary(
                "server.database_wait",
                &self.test_directory,
            );
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err(lock_timeout_error());
            }
            let (next, timeout) = self
                .database_changed
                .wait_timeout(slot, remaining.min(Duration::from_millis(10)))
                .map_err(|_| poisoned_lock_error())?;
            drop(next);
            if timeout.timed_out() && Instant::now() >= deadline {
                return Err(lock_timeout_error());
            }
        }
    }

    fn lock_database(&self) -> Result<DatabaseLease<'_>, PhobosError> {
        self.lease_database(None)
    }
    fn check_admission(&self) -> Result<(), PhobosError> {
        phobos_error::cancellation::check_now()?;
        if self.closing.load(Ordering::Acquire) {
            Err(PhobosError::new(
                ErrorCode::TransactionState,
                "database admission is closed",
            ))
        } else {
            Ok(())
        }
    }
    fn lease_database(&self, deadline: Option<Instant>) -> Result<DatabaseLease<'_>, PhobosError> {
        let _profile = phobos_observability::span("server.lock_database");
        let mut slot = self.database.lock().map_err(|_| poisoned_lock_error())?;
        while slot.is_none() {
            #[cfg(test)]
            phobos_observability::synchronization_boundary(
                "server.lease_wait",
                &self.test_directory,
            );
            slot = if let Some(deadline) = deadline {
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    return Err(lock_timeout_error());
                }
                let (next, timeout) = self
                    .database_changed
                    .wait_timeout(slot, remaining.min(Duration::from_millis(10)))
                    .map_err(|_| poisoned_lock_error())?;
                if timeout.timed_out() {
                    return Err(lock_timeout_error());
                }
                next
            } else {
                self.database_changed
                    .wait(slot)
                    .map_err(|_| poisoned_lock_error())?
            };
        }
        let hold = phobos_observability::span("server.database_guard_hold");
        let database = slot.take();
        drop(slot);
        drop(hold);
        Ok(DatabaseLease {
            coordinator: self,
            database,
            _ownership: phobos_observability::span("server.database_ownership_hold"),
        })
    }

    fn lock_owner(&self) -> Result<std::sync::MutexGuard<'_, Option<u64>>, PhobosError> {
        self.owner.lock().map_err(|_| poisoned_lock_error())
    }
}

// Ownership, rather than a structural mutex guard, excludes readers from the
// pending-generation chain. This does not claim MVCC: readers/DDL still drain
// accepted groups. Disjoint preparation workers own separate table handles.
struct DatabaseLease<'a> {
    coordinator: &'a Coordinator,
    database: Option<Database>,
    _ownership: phobos_observability::Span,
}
impl std::ops::Deref for DatabaseLease<'_> {
    type Target = Database;
    fn deref(&self) -> &Database {
        self.database.as_ref().expect("database lease")
    }
}
impl std::ops::DerefMut for DatabaseLease<'_> {
    fn deref_mut(&mut self) -> &mut Database {
        self.database.as_mut().expect("database lease")
    }
}
impl Drop for DatabaseLease<'_> {
    fn drop(&mut self) {
        if std::thread::panicking() {
            self.database
                .as_mut()
                .expect("database lease")
                .fence_for_recovery();
        }
        let mut slot = self
            .coordinator
            .database
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let hold = phobos_observability::span("server.database_guard_hold");
        *slot = self.database.take();
        // Readers may wake only to discover a newly admitted writer group.
        // Wake every class of waiter so an eligible group leader cannot remain
        // asleep behind a reader that must return to the admission condition.
        self.coordinator.database_changed.notify_all();
        drop(slot);
        drop(hold);
    }
}

#[derive(Default)]
struct CommitQueue {
    running: bool,
    requests: Vec<CommitRequest>,
}
struct CommitRequest {
    context: Option<phobos_error::cancellation::StatementContext>,
    sql: String,
    enqueued: Instant,
    completion: std::sync::mpsc::Sender<CommitCompletion>,
}
enum CommitCompletion {
    Lead,
    Done(Result<phobos_execution::QueryResult, PhobosError>),
}
fn is_group_dml(sql: &str) -> bool {
    matches!(
        phobos_sql::parse(sql),
        Ok(phobos_sql::Statement::Insert { .. }
            | phobos_sql::Statement::Update { .. }
            | phobos_sql::Statement::Delete { .. })
    )
}

impl Coordinator {
    fn execute_dml(
        &self,
        session: u64,
        sql: &str,
    ) -> Result<phobos_execution::QueryResult, PhobosError> {
        let _latency = phobos_observability::span("server.group_request_latency");
        let admission = self.wait_for_turn(session)?;
        if admission.is_some() {
            drop(admission);
            let mut database = self.admitted_database(session, Some(session))?;
            return database.execute(sql);
        }
        let (completion, receiver) = std::sync::mpsc::channel();
        let mut group = self.groups.lock().map_err(|_| poisoned_lock_error())?;
        if group.requests.len() == 64 {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "commit admission queue is full",
            ));
        }
        group.requests.push(CommitRequest {
            context: phobos_error::cancellation::current(),
            sql: sql.into(),
            enqueued: Instant::now(),
            completion,
        });
        let leader = !group.running;
        group.running = true;
        self.group_changed.notify_one();
        drop(group);
        drop(admission);
        if leader {
            self.run_commit_groups()?;
        }
        // Once submitted, disconnect/cancellation cannot revoke a possible
        // durable commit. Completion is sent only after installation finishes.
        loop {
            match receiver.recv().map_err(|_| poisoned_lock_error())? {
                CommitCompletion::Lead => self.run_commit_groups()?,
                CommitCompletion::Done(result) => return result,
            }
        }
    }

    fn run_commit_groups(&self) -> Result<(), PhobosError> {
        let _leader = phobos_error::cancellation::suspend();
        loop {
            let collection = phobos_observability::span("server.group_collection");
            let deadline = Instant::now() + self.group_window;
            let mut group = self.groups.lock().map_err(|_| poisoned_lock_error())?;
            while group.requests.len() < 64 {
                let remaining = deadline.saturating_duration_since(Instant::now());
                if remaining.is_zero() {
                    break;
                }
                let (next, _) = self
                    .group_changed
                    .wait_timeout(group, remaining)
                    .map_err(|_| poisoned_lock_error())?;
                group = next;
            }
            let requests = std::mem::take(&mut group.requests);
            drop(group);
            self.group_changed.notify_all();
            drop(collection);
            phobos_observability::event("server.group_requests", requests.len() as u64);
            phobos_observability::event("server.groups", 1);
            let results = match self.lock_database() {
                Ok(mut database) => {
                    for request in &requests {
                        phobos_observability::event(
                            "server.group_queue_wait_ns",
                            request
                                .enqueued
                                .elapsed()
                                .as_nanos()
                                .min(u128::from(u64::MAX)) as u64,
                        );
                    }
                    let statements: Vec<_> = requests
                        .iter()
                        .map(|request| request.sql.as_str())
                        .collect();
                    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        database.execute_independent_group_with_contexts(
                            &statements,
                            &requests
                                .iter()
                                .map(|request| request.context.clone())
                                .collect::<Vec<_>>(),
                        )
                    })) {
                        Ok(results) => results,
                        Err(_) => {
                            database.fence_for_recovery();
                            vec![
                                Err(PhobosError::new(
                                    ErrorCode::TransactionState,
                                    "execution worker panicked; database fenced for recovery"
                                ));
                                requests.len()
                            ]
                        }
                    }
                }
                Err(error) => vec![Err(error); requests.len()],
            };
            for (request, result) in requests.into_iter().zip(results) {
                let _ = request.completion.send(CommitCompletion::Done(result));
            }
            // Same owner -> queue lock order as admission and BEGIN; clearing
            // running while holding owner prevents a lost BEGIN wakeup.
            let owner = self.lock_owner()?;
            let mut group = self.groups.lock().map_err(|_| poisoned_lock_error())?;
            if group.requests.is_empty() {
                group.running = false;
                self.owner_changed.notify_all();
                return Ok(());
            }
            // A completed leader must return its own result promptly instead
            // of waiting for other clients to exhaust their next transactions.
            // The elected waiter is still queued and cannot execute twice.
            for request in &group.requests {
                if request.completion.send(CommitCompletion::Lead).is_ok() {
                    return Ok(());
                }
            }
            // If every receiver disappeared, retain responsibility for these
            // submitted transactions: cancellation cannot revoke a COMMIT.
            drop(group);
            drop(owner);
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum TxCommand {
    Begin,
    Commit,
    Rollback,
    Other,
}

fn transaction_command(sql: &str) -> TxCommand {
    match phobos_sql::parse(sql) {
        Ok(phobos_sql::Statement::Begin) => TxCommand::Begin,
        Ok(phobos_sql::Statement::Commit) => TxCommand::Commit,
        Ok(phobos_sql::Statement::Rollback) => TxCommand::Rollback,
        _ => TxCommand::Other,
    }
}

fn lock_timeout_error() -> PhobosError {
    PhobosError::new(
        ErrorCode::LockTimeout,
        "timed out waiting for another session's transaction",
    )
}

fn poisoned_lock_error() -> PhobosError {
    PhobosError::new(
        ErrorCode::TransactionState,
        "server coordination lock was poisoned",
    )
}

/// Phase-0 compatibility handler used by the handshake unit test.
pub fn handle_connection(mut stream: TcpStream) -> Result<(), PhobosError> {
    let frame = Frame::read_from(&mut stream)?;
    match frame.message_type {
        MessageType::Hello => Frame::new(
            MessageType::HelloAck,
            frame.request_id,
            concat!("phobos-server/", env!("CARGO_PKG_VERSION"))
                .as_bytes()
                .to_vec(),
        )
        .write_to(&mut stream),
        MessageType::Ping => {
            Frame::new(MessageType::Pong, frame.request_id, Vec::new()).write_to(&mut stream)
        }
        _ => Err(PhobosError::new(
            ErrorCode::InvalidProtocol,
            "this connection handler accepts only Hello or Ping",
        )),
    }
}

mod request_transport;
pub use request_transport::{Platform, REQUEST_PATH_ENV, RequestPath, ResolvedPath};

#[cfg(test)]
fn session_loop<S: Read + Write>(
    stream: &mut S,
    coordinator: Arc<Coordinator>,
    session_id: u64,
    auth: Option<Arc<AuthStore>>,
    max_result_bytes: usize,
) -> Result<(), PhobosError> {
    session_requests(
        &mut request_transport::Borrowed(stream),
        coordinator,
        session_id,
        auth,
        max_result_bytes,
    )
}

#[cfg(test)]
fn session_requests<S: request_transport::RequestStream>(
    stream: &mut S,
    coordinator: Arc<Coordinator>,
    session_id: u64,
    auth: Option<Arc<AuthStore>>,
    max_result_bytes: usize,
) -> Result<(), PhobosError> {
    session_requests_configured(
        stream,
        coordinator,
        session_id,
        auth,
        max_result_bytes,
        g1g2::RoleConnections::new(BTreeMap::new()),
        g1g2::OperatorLog::new(phobos_config::LogFormat::Text, 0),
        Arc::new(BTreeMap::new()),
        g1g2::AuditLog::default(),
    )
}

#[allow(clippy::too_many_arguments)]
fn session_requests_configured<S: request_transport::RequestStream>(
    stream: &mut S,
    coordinator: Arc<Coordinator>,
    session_id: u64,
    auth: Option<Arc<AuthStore>>,
    max_result_bytes: usize,
    role_connections: Arc<g1g2::RoleConnections>,
    log: g1g2::OperatorLog,
    mtls_identities: Arc<BTreeMap<String, String>>,
    audit: g1g2::AuditLog,
) -> Result<(), PhobosError> {
    let metrics = coordinator.metrics();
    metrics.session_opened();
    log.event("connection_open", &[("session", session_id.to_string())]);
    struct SessionLog(g1g2::OperatorLog, u64);
    impl Drop for SessionLog {
        fn drop(&mut self) {
            self.0
                .event("connection_close", &[("session", self.1.to_string())]);
        }
    }
    let _session_log = SessionLog(log.clone(), session_id);
    struct SessionMetrics<'a>(&'a Metrics);
    impl Drop for SessionMetrics<'_> {
        fn drop(&mut self) {
            self.0.session_closed();
        }
    }
    let _session_metrics = SessionMetrics(&metrics);
    struct SessionCleanup<'a>(&'a Coordinator, u64);
    impl Drop for SessionCleanup<'_> {
        fn drop(&mut self) {
            self.0.disconnect(self.1);
        }
    }
    let _cleanup = SessionCleanup(&coordinator, session_id);
    let mut owner = auth.is_none().then(String::new);
    let mut next_handle = None;
    let mut streaming = false;
    let mut role = if auth.is_none() {
        Some(Role::Admin)
    } else {
        None
    };
    let mut role_slot = if auth.is_none() {
        log.event(
            "auth_success",
            &[("user", "local-admin".into()), ("role", "admin".into())],
        );
        audit.event(
            "login",
            "local-admin",
            session_id,
            "local_auth",
            "server",
            true,
            "admin",
        );
        Some(role_connections.acquire(Role::Admin)?)
    } else {
        None
    };
    let mut prepared = BTreeMap::<String, g1g2::Prepared>::new();
    let mut mtls_checked = false;
    let mut internal_handles = cancellation::InternalHandles::new()?;
    loop {
        let frame = match stream.request_timeout(coordinator.idle_timeout) {
            Ok(frame) => frame,
            Err(error) if error.code == ErrorCode::Io => break,
            Err(error) => return Err(error),
        };
        if !mtls_checked {
            mtls_checked = true;
            if let Some(certificate) = stream.peer_certificate() {
                let fingerprint = certificate_fingerprint(&certificate);
                let username = mtls_identities.get(&fingerprint).ok_or_else(|| {
                    PhobosError::new(ErrorCode::Authentication, "mTLS certificate is not mapped")
                })?;
                let store = auth.as_ref().ok_or_else(|| {
                    PhobosError::new(ErrorCode::Authentication, "mTLS requires an auth store")
                })?;
                let authenticated_role = store.role_for_user(username)?;
                role_slot = Some(role_connections.acquire(authenticated_role)?);
                role = Some(authenticated_role);
                owner = Some(username.clone());
                audit.event(
                    "login",
                    username,
                    session_id,
                    "mtls_authenticate",
                    &fingerprint,
                    true,
                    authenticated_role.as_str(),
                );
                log.event(
                    "auth_success",
                    &[
                        ("user", username.clone()),
                        ("role", authenticated_role.as_str().into()),
                        ("method", "mtls".into()),
                    ],
                );
            }
        }
        // 0.2-B: released before the statement's final response is written,
        // so a cancel that races the reply never finds a finished statement.
        let mut statement_guard = if owner.is_some()
            && matches!(
                frame.message_type,
                MessageType::Query
                    | MessageType::QueryStream
                    | MessageType::BulkBegin
                    | MessageType::BulkRows
            ) {
            let handle = match next_handle.take() {
                Some(handle) => handle,
                None => internal_handles.next_handle(),
            };
            let guard = coordinator.cancellation.start(
                handle,
                session_id,
                owner.clone().unwrap(),
                coordinator.statement_timeout,
            )?;
            // EOF can race registry insertion; the reader cancels registered work,
            // and this closes the gap if it observed EOF just before insertion.
            if stream.closed() {
                coordinator.cancel(session_id);
            }
            Some(guard)
        } else {
            None
        };
        let response = match frame.message_type {
            MessageType::Hello => {
                streaming = std::str::from_utf8(&frame.payload)
                    .is_ok_and(|hello| hello.split(';').any(|part| part == CAPABILITY));
                let hello = if streaming {
                    concat!(
                        "phobos-server/",
                        env!("CARGO_PKG_VERSION"),
                        " phase7;stream=1;bulk=1"
                    )
                } else {
                    concat!(
                        "phobos-server/",
                        env!("CARGO_PKG_VERSION"),
                        " phase7;bulk=1"
                    )
                };
                Frame::new(
                    MessageType::HelloAck,
                    frame.request_id,
                    hello.as_bytes().to_vec(),
                )
            }
            MessageType::Ping => Frame::new(MessageType::Pong, frame.request_id, Vec::new()),
            MessageType::Auth => {
                if let Some(store) = &auth {
                    let decoded = decode_credentials(&frame.payload);
                    let audit_user = decoded.as_ref().map_or("unknown", |value| value.0);
                    match decoded
                        .and_then(|(username, password)| store.authenticate(username, password))
                    {
                        Ok(authenticated_role) => {
                            match role_connections.acquire(authenticated_role) {
                                Ok(slot) => {
                                    let username =
                                        decode_credentials(&frame.payload)?.0.to_string();
                                    role = Some(authenticated_role);
                                    owner = Some(username.clone());
                                    role_slot = Some(slot);
                                    next_handle = None;
                                    log.event(
                                        "auth_success",
                                        &[
                                            ("user", username.clone()),
                                            ("role", authenticated_role.as_str().into()),
                                        ],
                                    );
                                    audit.event(
                                        "login",
                                        &username,
                                        session_id,
                                        "password_authenticate",
                                        "server",
                                        true,
                                        authenticated_role.as_str(),
                                    );
                                    Frame::new(
                                        MessageType::AuthOk,
                                        frame.request_id,
                                        authenticated_role.as_str().as_bytes().to_vec(),
                                    )
                                }
                                Err(error) => {
                                    metrics.role_connection_rejected();
                                    log.event("auth_failure", &[("reason", "role_limit".into())]);
                                    audit.event(
                                        "login",
                                        audit_user,
                                        session_id,
                                        "password_authenticate",
                                        "server",
                                        false,
                                        "role limit",
                                    );
                                    Frame::new(
                                        MessageType::Error,
                                        frame.request_id,
                                        error.to_string().into_bytes(),
                                    )
                                }
                            }
                        }
                        Err(_) => {
                            metrics.auth_failure();
                            log.event("auth_failure", &[("reason", "credentials".into())]);
                            audit.event(
                                "login",
                                audit_user,
                                session_id,
                                "password_authenticate",
                                "server",
                                false,
                                "credentials",
                            );
                            Frame::new(
                                MessageType::Error,
                                frame.request_id,
                                b"authentication failed".to_vec(),
                            )
                        }
                    }
                } else {
                    role = Some(Role::Admin);
                    Frame::new(MessageType::AuthOk, frame.request_id, b"admin".to_vec())
                }
            }
            MessageType::CancelHandle | MessageType::Cancel => {
                let result = (|| {
                    let user = owner.as_deref().ok_or_else(|| {
                        PhobosError::new(ErrorCode::Authentication, "authentication required")
                    })?;
                    if frame.flags != 0 {
                        return Err(PhobosError::new(
                            ErrorCode::InvalidProtocol,
                            "cancel flags must be zero",
                        ));
                    }
                    if frame.message_type == MessageType::CancelHandle {
                        if !frame.payload.is_empty() {
                            return Err(PhobosError::new(
                                ErrorCode::InvalidProtocol,
                                "cancel handle payload must be empty",
                            ));
                        }
                        let handle = cancellation::handle()?;
                        next_handle = Some(handle.clone());
                        Ok(Frame::new(
                            MessageType::CancelHandleResult,
                            frame.request_id,
                            handle.into_bytes(),
                        ))
                    } else {
                        let handle = std::str::from_utf8(&frame.payload).map_err(|_| {
                            PhobosError::new(
                                ErrorCode::InvalidProtocol,
                                "invalid cancellation handle",
                            )
                        })?;
                        if handle.len() != 64 || !handle.bytes().all(|b| b.is_ascii_hexdigit()) {
                            return Err(PhobosError::new(
                                ErrorCode::CancellationTarget,
                                "unknown or completed cancellation target",
                            ));
                        }
                        coordinator.cancellation.cancel(handle, user)?;
                        Ok(Frame::new(
                            MessageType::CancelResult,
                            frame.request_id,
                            b"cancel requested; admitted commits complete".to_vec(),
                        ))
                    }
                })();
                result.unwrap_or_else(|error: PhobosError| {
                    Frame::new(
                        MessageType::Error,
                        frame.request_id,
                        error.to_string().into_bytes(),
                    )
                })
            }
            MessageType::Metrics => {
                if role != Some(Role::Admin) {
                    Frame::new(
                        MessageType::Error,
                        frame.request_id,
                        b"authorization failed".to_vec(),
                    )
                } else {
                    Frame::new(
                        MessageType::MetricsResult,
                        frame.request_id,
                        metrics.snapshot().to_text().into_bytes(),
                    )
                }
            }
            MessageType::BulkBegin | MessageType::BulkRows => {
                let result = (|| {
                    if !role.is_some_and(|role| role.allows(phobos_auth::Action::Write)) {
                        return Err(PhobosError::new(
                            ErrorCode::Authorization,
                            "bulk import requires writer authorization",
                        ));
                    }
                    if frame.flags != 0 {
                        return Err(PhobosError::new(
                            ErrorCode::InvalidProtocol,
                            "bulk flags must be zero",
                        ));
                    }
                    if frame.message_type == MessageType::BulkBegin {
                        let table = std::str::from_utf8(&frame.payload).map_err(|_| {
                            PhobosError::new(ErrorCode::InvalidProtocol, "bulk table must be UTF-8")
                        })?;
                        if table.is_empty() || table.len() > 256 {
                            return Err(PhobosError::new(
                                ErrorCode::InvalidProtocol,
                                "bulk table length",
                            ));
                        }
                        coordinator.bulk_begin(session_id, table)?;
                        Ok("BULK BEGIN".to_string())
                    } else {
                        let mut rows_frame = frame.clone();
                        rows_frame.message_type = MessageType::QueryRows;
                        let Event::Rows { sequence, rows } = Event::decode(&rows_frame)? else {
                            unreachable!()
                        };
                        if sequence != 0 {
                            return Err(PhobosError::new(
                                ErrorCode::InvalidProtocol,
                                "bulk chunk sequence must be zero",
                            ));
                        }
                        Ok(coordinator.bulk_batch(session_id, &rows)?.to_string())
                    }
                })();
                if result
                    .as_ref()
                    .is_err_and(|error| error.code == ErrorCode::Authorization)
                {
                    audit.event(
                        "authorization",
                        owner.as_deref().unwrap_or("anonymous"),
                        session_id,
                        "bulk_ingest",
                        "table",
                        false,
                        "permission denied",
                    );
                }
                match result {
                    Ok(output) => Frame::new(
                        MessageType::QueryResult,
                        frame.request_id,
                        output.into_bytes(),
                    ),
                    Err(error) => {
                        // Includes decode/framing errors after earlier chunks. Never
                        // let a subsequent COMMIT import only an accepted prefix.
                        coordinator.disconnect(session_id);
                        Frame::new(
                            MessageType::Error,
                            frame.request_id,
                            error.to_string().into_bytes(),
                        )
                    }
                }
            }
            MessageType::QueryStream => {
                let started = Instant::now();
                let mut slow_sql = String::new();
                let result = (|| {
                    if !streaming || frame.flags != 0 {
                        return Err(PhobosError::new(
                            ErrorCode::InvalidProtocol,
                            "stream capability not negotiated or invalid flags",
                        ));
                    }
                    let current_role = role.ok_or_else(|| {
                        PhobosError::new(ErrorCode::Authentication, "authentication required")
                    })?;
                    let sql = std::str::from_utf8(&frame.payload).map_err(|_| {
                        PhobosError::new(ErrorCode::InvalidProtocol, "query was not UTF-8")
                    })?;
                    slow_sql = sql.to_string();
                    if !current_role.allows(classify_sql(sql)) {
                        return Err(PhobosError::new(
                            ErrorCode::Authorization,
                            "authorization failed",
                        ));
                    }
                    let mut sink = StreamWriter {
                        stream,
                        request_id: frame.request_id,
                        limit: max_result_bytes.min(phobos_protocol::MAX_PAYLOAD),
                        metrics: &metrics,
                        batch: Vec::new(),
                        batch_bytes: 13,
                        count: 0,
                        sequence: 0,
                        out: Vec::new(),
                    };
                    let executed = if sql
                        .trim()
                        .trim_end_matches(';')
                        .trim()
                        .eq_ignore_ascii_case("SELECT * FROM phobos_metrics")
                    {
                        stream_metrics(&coordinator, &mut sink)
                    } else {
                        coordinator.execute_stream_result(session_id, sql, &mut sink)
                    };
                    // The statement is complete: unregister it, then deliver
                    // every frame produced (before any error frame).
                    drop(statement_guard.take());
                    let flushed = sink.flush_out();
                    executed.and(flushed)
                })();
                let status = match &result {
                    Ok(()) => "success",
                    Err(error) if phobos_error::cancellation::is_interrupted(error) => "cancelled",
                    Err(_) => "error",
                };
                if result
                    .as_ref()
                    .is_err_and(|error| error.code == ErrorCode::Authorization)
                {
                    audit.event(
                        "authorization",
                        owner.as_deref().unwrap_or("anonymous"),
                        session_id,
                        classify_action_name(&slow_sql),
                        statement_target(&slow_sql),
                        false,
                        "permission denied",
                    );
                }
                if !slow_sql.is_empty()
                    && log.slow(
                        started,
                        owner
                            .as_deref()
                            .filter(|user| !user.is_empty())
                            .unwrap_or("local-admin"),
                        session_id,
                        &slow_sql,
                        status,
                    )
                {
                    metrics.slow_query();
                }
                drop(statement_guard.take());
                if phobos_observability::trace::enabled() {
                    phobos_observability::trace_request_end(request_kind(&slow_sql));
                }
                if let Err(error) = result {
                    if error.code == ErrorCode::Io {
                        return Err(error);
                    }
                    metrics.query_error();
                    let mut message = error.to_string();
                    if message.len() > 8192 {
                        message = "stream failed: error message exceeds diagnostic limit".into();
                    }
                    Event::Error {
                        code: format!("{:?}", error.code),
                        message,
                    }
                    .frame(frame.request_id)?
                    .write_to(&mut *stream)?;
                }
                continue;
            }
            MessageType::Query => {
                let Some(current_role) = role else {
                    let response = Frame::new(
                        MessageType::Error,
                        frame.request_id,
                        b"authentication required".to_vec(),
                    );
                    response.write_to(&mut *stream)?;
                    continue;
                };
                match String::from_utf8(frame.payload) {
                    Ok(sql) => {
                        let started = Instant::now();
                        let result = execute_session_query(
                            &coordinator,
                            session_id,
                            current_role,
                            &sql,
                            &mut prepared,
                            &metrics,
                        );
                        let action = classify_sql(&sql);
                        if result
                            .as_ref()
                            .is_err_and(|error| error.code == ErrorCode::Authorization)
                        {
                            audit.event(
                                "authorization",
                                owner.as_deref().unwrap_or("anonymous"),
                                session_id,
                                classify_action_name(&sql),
                                statement_target(&sql),
                                false,
                                "permission denied",
                            );
                        } else if action == phobos_auth::Action::Ddl {
                            audit.event(
                                "ddl",
                                owner.as_deref().unwrap_or("local-admin"),
                                session_id,
                                classify_action_name(&sql),
                                statement_target(&sql),
                                result.is_ok(),
                                if result.is_ok() { "complete" } else { "failed" },
                            );
                        }
                        let status = match &result {
                            Ok(_) => "success",
                            Err(error) if phobos_error::cancellation::is_interrupted(error) => {
                                "cancelled"
                            }
                            Err(_) => "error",
                        };
                        if log.slow(
                            started,
                            owner
                                .as_deref()
                                .filter(|user| !user.is_empty())
                                .unwrap_or("local-admin"),
                            session_id,
                            &sql,
                            status,
                        ) {
                            metrics.slow_query();
                        }
                        if result.is_ok()
                            && sql
                                .split_whitespace()
                                .next()
                                .is_some_and(|word| word.eq_ignore_ascii_case("CHECKPOINT"))
                        {
                            log.event("checkpoint", &[("status", "complete".into())]);
                        }
                        if let Err(error) = &result {
                            if matches!(
                                error.code,
                                ErrorCode::Recovery
                                    | ErrorCode::ChecksumMismatch
                                    | ErrorCode::InvalidWal
                            ) {
                                log.event(
                                    "storage_error",
                                    &[("status", "fenced".into()), ("error", error.to_string())],
                                );
                            }
                        }
                        match result {
                            Ok(output) if output.len() <= max_result_bytes => {
                                metrics.add_bytes_out(output.len());
                                Frame::new(
                                    MessageType::QueryResult,
                                    frame.request_id,
                                    output.into_bytes(),
                                )
                            }
                            Ok(_) => {
                                metrics.query_error();
                                Frame::new(
                                    MessageType::Error,
                                    frame.request_id,
                                    b"result exceeds configured maximum".to_vec(),
                                )
                            }
                            Err(error) => {
                                metrics.query_error();
                                if error.code == ErrorCode::LockTimeout {
                                    metrics.lock_timeout();
                                }
                                Frame::new(
                                    MessageType::Error,
                                    frame.request_id,
                                    error.to_string().into_bytes(),
                                )
                            }
                        }
                    }
                    Err(_) => Frame::new(
                        MessageType::Error,
                        frame.request_id,
                        b"query text must be UTF-8".to_vec(),
                    ),
                }
            }
            _ => Frame::new(
                MessageType::Error,
                frame.request_id,
                b"unsupported request type".to_vec(),
            ),
        };
        drop(statement_guard.take());
        {
            let _write = phobos_observability::span("request.socket_write");
            response.write_to(&mut *stream)?;
        }
        if phobos_observability::trace::enabled() {
            phobos_observability::trace_request_end(request_kind(""));
        }
    }
    drop(role_slot);
    Ok(())
}

/// 0.2-H slow-request trace label: the statement's first keyword.
fn request_kind(sql: &str) -> &'static str {
    let word = sql.split_whitespace().next().unwrap_or("");
    for kind in [
        "select",
        "insert",
        "update",
        "delete",
        "begin",
        "commit",
        "rollback",
        "checkpoint",
    ] {
        if word.eq_ignore_ascii_case(kind) {
            return kind;
        }
    }
    if word.is_empty() { "frame" } else { "other" }
}

fn stream_metrics(coordinator: &Coordinator, sink: &mut dyn ResultSink) -> Result<(), PhobosError> {
    sink.start(vec!["name".into(), "value".into(), "kind".into()])?;
    for (name, value, kind) in coordinator.operator_metrics_rows() {
        sink.row(phobos_types::Row::new(vec![
            phobos_types::Value::Text(name),
            phobos_types::Value::Int64(i64::try_from(value).unwrap_or(i64::MAX)),
            phobos_types::Value::Text(kind),
        ]))?;
    }
    sink.finish()
}

fn execute_session_query(
    coordinator: &Coordinator,
    session_id: u64,
    role: Role,
    sql: &str,
    prepared: &mut BTreeMap<String, g1g2::Prepared>,
    metrics: &Metrics,
) -> Result<String, PhobosError> {
    if sql
        .trim()
        .trim_end_matches(';')
        .trim()
        .eq_ignore_ascii_case("SELECT * FROM phobos_metrics")
    {
        if !role.allows(phobos_auth::Action::Read) {
            return Err(PhobosError::new(
                ErrorCode::Authorization,
                "authorization failed",
            ));
        }
        return Ok(coordinator.metrics_text());
    }
    match g1g2::session_command(sql)? {
        Some(g1g2::SessionCommand::Prepare {
            name,
            sql,
            statement,
        }) => {
            if !role.allows(classify_sql(&sql)) {
                return Err(PhobosError::new(
                    ErrorCode::Authorization,
                    "authorization failed",
                ));
            }
            if prepared.contains_key(&name) {
                return Err(PhobosError::new(
                    ErrorCode::ConstraintViolation,
                    "prepared statement already exists",
                ));
            }
            prepared.insert(
                name,
                g1g2::Prepared {
                    sql,
                    statement,
                    schema_generation: coordinator.schema_generation(),
                },
            );
            metrics.prepared();
            Ok("PREPARE 0".into())
        }
        Some(g1g2::SessionCommand::Execute(name)) => {
            let entry = prepared.get_mut(&name).ok_or_else(|| {
                PhobosError::new(ErrorCode::NotFound, "prepared statement does not exist")
            })?;
            if entry.schema_generation != coordinator.schema_generation() {
                entry.statement = phobos_sql::parse(&entry.sql)?;
                entry.schema_generation = coordinator.schema_generation();
                metrics.prepared_replanned();
            }
            metrics.prepared_executed();
            coordinator.execute_prepared(session_id, entry.statement.clone())
        }
        Some(g1g2::SessionCommand::Deallocate(name)) => {
            if prepared.remove(&name).is_none() {
                return Err(PhobosError::new(
                    ErrorCode::NotFound,
                    "prepared statement does not exist",
                ));
            }
            Ok("DEALLOCATE 0".into())
        }
        None => {
            if !role.allows(classify_sql(sql)) {
                return Err(PhobosError::new(
                    ErrorCode::Authorization,
                    "authorization failed",
                ));
            }
            coordinator.execute(session_id, sql)
        }
    }
}

struct StreamWriter<'a, S> {
    stream: &'a mut S,
    request_id: u32,
    limit: usize,
    metrics: &'a Metrics,
    batch: Vec<phobos_types::Row>,
    batch_bytes: usize,
    count: u64,
    sequence: u64,
    /// 0.2-B: encoded frames not yet written. A small result (start, one row
    /// batch, end) leaves in one socket write instead of three; large results
    /// still stream in bounded 64 KiB writes. Bytes and frame order are
    /// unchanged; the owner must call `flush_out` before any error frame.
    out: Vec<u8>,
}

const STREAM_WRITE_BYTES: usize = 64 * 1024;

impl<S: Write> StreamWriter<'_, S> {
    fn flush_out(&mut self) -> Result<(), PhobosError> {
        if !self.out.is_empty() {
            let _write = phobos_observability::span("request.socket_write");
            self.stream.write_all(&self.out)?;
            self.out.clear();
        }
        Ok(())
    }

    fn send(&mut self, event: Event) -> Result<(), PhobosError> {
        phobos_error::cancellation::check_now()?;
        let frame = event.frame(self.request_id)?;
        if frame.payload.len() > self.limit {
            return Err(PhobosError::new(
                ErrorCode::FrameTooLarge,
                "stream frame exceeds configured maximum",
            ));
        }
        frame.write_to(&mut self.out)?;
        if self.out.len() >= STREAM_WRITE_BYTES {
            self.flush_out()?;
        }
        self.metrics.add_bytes_out(frame.payload.len());
        phobos_observability::event(
            "stream.protocol_bytes",
            (phobos_protocol::HEADER_LEN + frame.payload.len()) as u64,
        );
        Ok(())
    }

    fn flush_batch(&mut self) -> Result<(), PhobosError> {
        if self.batch.is_empty() {
            return Ok(());
        }
        let rows = std::mem::take(&mut self.batch);
        let count = rows.len();
        self.send(Event::Rows {
            sequence: self.sequence,
            rows,
        })?;
        phobos_observability::event("stream.rows", count as u64);
        phobos_observability::event("stream.batches", 1);
        self.sequence += 1;
        self.batch_bytes = 13;
        Ok(())
    }
}

impl<S: Write> ResultSink for StreamWriter<'_, S> {
    fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError> {
        self.send(Event::Start(columns))
    }

    fn row(&mut self, row: phobos_types::Row) -> Result<(), PhobosError> {
        let size = encode_row(&row)?.len();
        if size.saturating_add(13) > self.limit {
            return Err(PhobosError::new(
                ErrorCode::FrameTooLarge,
                "individual row exceeds configured frame maximum",
            ));
        }
        if !self.batch.is_empty()
            && (self.batch.len() == BATCH_ROWS
                || self.batch_bytes + size > TARGET_BATCH_BYTES.min(self.limit))
        {
            self.flush_batch()?;
        }
        self.batch_bytes += size;
        self.batch.push(row);
        self.count += 1;
        Ok(())
    }

    fn finish(&mut self) -> Result<(), PhobosError> {
        self.flush_batch()?;
        self.send(Event::End {
            rows: self.count,
            batches: self.sequence,
        })?;
        self.flush_out()
    }

    fn command(&mut self, tag: String, rows_affected: u64) -> Result<(), PhobosError> {
        self.send(Event::Command { tag, rows_affected })?;
        self.flush_out()
    }
}

fn decode_credentials(payload: &[u8]) -> Result<(&str, &str), PhobosError> {
    let Some(separator) = payload.iter().position(|b| *b == 0) else {
        return Err(PhobosError::new(
            ErrorCode::InvalidProtocol,
            "invalid auth payload",
        ));
    };
    let username = std::str::from_utf8(&payload[..separator])
        .map_err(|_| PhobosError::new(ErrorCode::InvalidProtocol, "username is not UTF-8"))?;
    let password = std::str::from_utf8(&payload[separator + 1..])
        .map_err(|_| PhobosError::new(ErrorCode::InvalidProtocol, "password is not UTF-8"))?;
    Ok((username, password))
}

fn classify_action_name(sql: &str) -> &str {
    sql.split_whitespace().next().unwrap_or("UNKNOWN")
}

fn statement_target(sql: &str) -> &str {
    let mut words = sql.split_whitespace();
    let first = words.next().unwrap_or("");
    if matches!(
        first.to_ascii_uppercase().as_str(),
        "CREATE" | "DROP" | "ALTER"
    ) {
        let _kind = words.next();
    }
    words.next().unwrap_or("database")
}

#[derive(Debug, Clone)]
pub struct ServerSettings {
    pub runtime: Option<RuntimeConfig>,
    pub bind: String,
    pub data_dir: PathBuf,
    pub auth_file: Option<PathBuf>,
    pub tls_cert: Option<PathBuf>,
    pub tls_key: Option<PathBuf>,
    pub max_connections: u64,
    pub max_result_bytes: usize,
    pub lock_wait: Duration,
    pub statement_timeout: Duration,
    pub idle_timeout: Duration,
}

impl ServerSettings {
    pub fn apply_config(&mut self, config: RuntimeConfig) {
        self.max_connections = config.max_connections;
        self.max_result_bytes = config.max_result_bytes;
        self.lock_wait = Duration::from_millis(config.lock_timeout_ms);
        self.statement_timeout = Duration::from_millis(config.statement_timeout_ms);
        self.idle_timeout = Duration::from_millis(config.idle_timeout_ms);
        self.runtime = Some(config);
    }
    pub fn effective_config(&self) -> Result<RuntimeConfig, PhobosError> {
        let mut config = match &self.runtime {
            Some(config) => config.clone(),
            None => RuntimeConfig::load(None)?,
        };
        config.max_connections = self.max_connections;
        config.max_result_bytes = self.max_result_bytes;
        for (destination, value) in [
            (&mut config.lock_timeout_ms, self.lock_wait),
            (&mut config.statement_timeout_ms, self.statement_timeout),
            (&mut config.idle_timeout_ms, self.idle_timeout),
        ] {
            *destination = u64::try_from(value.as_millis())
                .map_err(|_| PhobosError::new(ErrorCode::ResourceLimit, "timeout overflow"))?;
        }
        config.validate()?;
        Ok(config)
    }

    #[must_use]
    pub fn alpha_default(bind: impl Into<String>, data_dir: impl Into<PathBuf>) -> Self {
        Self {
            runtime: None,
            bind: bind.into(),
            data_dir: data_dir.into(),
            auth_file: None,
            tls_cert: None,
            tls_key: None,
            max_connections: 64,
            max_result_bytes: 1024 * 1024,
            lock_wait: DEFAULT_LOCK_WAIT,
            statement_timeout: DEFAULT_STATEMENT_TIMEOUT,
            idle_timeout: DEFAULT_IDLE_TIMEOUT,
        }
    }
}

/// 0.2-I: Windows reports a sharing violation (os error 32), a lock
/// violation (33) or access denied (5, delete pending) while another process
/// (e.g. the PowerShell helper that just wrote the marker) still holds the
/// file. Only those, and only on Windows, are treated as transient.
fn transient_marker_error(error: &io::Error, windows: bool) -> bool {
    windows && matches!(error.raw_os_error(), Some(5 | 32 | 33))
}

/// Removes the shutdown marker. Shutdown never depends on this succeeding:
/// a transient Windows sharing violation is retried for up to ~1 s and then
/// left in place with a warning. The server's start-up contract is unchanged
/// (a marker present at start requests an immediate clean shutdown, relied on
/// by `a5_startup`), so a marker left behind is removed by the start helpers,
/// which already delete stale lifecycle files before launching a server.
fn remove_shutdown_marker(path: &Path, log: &g1g2::OperatorLog) -> Result<(), PhobosError> {
    const ATTEMPTS: u32 = 40;
    for attempt in 1..=ATTEMPTS {
        match std::fs::remove_file(path) {
            Ok(()) => return Ok(()),
            Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(()),
            Err(error) if transient_marker_error(&error, cfg!(windows)) => {
                if attempt == ATTEMPTS {
                    log.event(
                        "shutdown_marker",
                        &[
                            ("status", "left_in_place".into()),
                            ("warning", error.to_string()),
                        ],
                    );
                    return Ok(());
                }
                thread::sleep(Duration::from_millis(25));
            }
            Err(error) => return Err(error.into()),
        }
    }
    Ok(())
}

pub fn serve_with_settings(settings: ServerSettings) -> Result<(), PhobosError> {
    serve_with_shutdown_file(settings, None)
}

/// Optional local control file exposes the existing admission/drain shutdown.
/// Its directory must be writable only by the instance owner.
pub fn serve_with_shutdown_file(
    settings: ServerSettings,
    shutdown_file: Option<PathBuf>,
) -> Result<(), PhobosError> {
    // 0.2-I: the transport policy is read and validated once, before anything
    // is opened; an invalid PHOBOS_REQUEST_PATH is a start-up error.
    let request_policy = request_transport::RequestPath::from_env()?;
    serve_with_request_path(settings, shutdown_file, request_policy)
}

/// [`serve_with_shutdown_file`] with an explicit request transport policy
/// (instead of `PHOBOS_REQUEST_PATH`); resolved once for the whole server.
pub fn serve_with_request_path(
    settings: ServerSettings,
    shutdown_file: Option<PathBuf>,
    request_policy: request_transport::RequestPath,
) -> Result<(), PhobosError> {
    let config = settings.effective_config()?;
    std::fs::create_dir_all(&settings.data_dir)?;
    validate_network_security(&settings)?;
    let _data_lock = lock_data_directory(&settings.data_dir)?;
    let coordinator = Arc::new(Coordinator::open_configured(&settings.data_dir, &config)?);
    let auth = match &settings.auth_file {
        Some(path) => Some(Arc::new(AuthStore::open(path)?)),
        None => None,
    };
    let tls = load_tls_config(
        settings.tls_cert.as_deref(),
        settings.tls_key.as_deref(),
        config.client_ca_path.as_deref(),
        config.mtls_required,
    )?;
    let platform = request_transport::Platform::current();
    let request_path = request_policy.resolve(platform, tls.is_some());
    let listener = TcpListener::bind(&settings.bind)?;
    let active = Arc::new(AtomicU64::new(0));
    let log = g1g2::OperatorLog::new(config.log_format, config.slow_query_ms);
    let audit = g1g2::AuditLog::new(config.audit_enabled, config.audit_log_path.as_deref())?;
    let mtls_identities = Arc::new(config.mtls_identities.clone());
    let role_connections = g1g2::RoleConnections::new(config.role_connection_limits.clone());
    let pool = g1g2::WorkerPool::new(config.worker_threads, config.max_connections as usize)?;
    let sockets = Arc::new(Mutex::new(BTreeMap::<u64, TcpStream>::new()));
    log.event(
        "recovery",
        &[
            ("status", "complete".into()),
            ("data_dir", settings.data_dir.display().to_string()),
        ],
    );
    audit.event(
        "server",
        "system",
        0,
        "startup",
        &settings.bind,
        true,
        "started",
    );
    log.event(
        "startup",
        &[
            ("bind", settings.bind.clone()),
            ("data_dir", settings.data_dir.display().to_string()),
            ("auth", auth.is_some().to_string()),
            ("tls", tls.is_some().to_string()),
            ("worker_threads", config.worker_threads.to_string()),
        ],
    );
    // One line per server start: policy, concrete transport, platform.
    log.event(
        "request_path",
        &[
            ("policy", request_policy.name().into()),
            ("resolved", request_path.name().into()),
            ("platform", platform.name().into()),
            ("tls", tls.is_some().to_string()),
        ],
    );
    let auto_policy = request_policy == request_transport::RequestPath::Auto;
    if shutdown_file.is_some() {
        listener.set_nonblocking(true)?;
    }
    loop {
        if let Some(path) = &shutdown_file {
            if path.exists() {
                // 0.2-I: the request is observed; removing the marker is
                // cleanup and never turns into a server failure on a
                // transient Windows sharing violation (os error 32).
                remove_shutdown_marker(path, &log)?;
                if let Ok(open) = sockets.lock() {
                    for stream in open.values() {
                        let _ = stream.shutdown(std::net::Shutdown::Both);
                    }
                }
                drop(pool);
                match coordinator.shutdown() {
                    Ok(()) => {
                        log.event("shutdown", &[("status", "clean".into())]);
                        audit.event(
                            "server",
                            "system",
                            0,
                            "shutdown",
                            &settings.bind,
                            true,
                            "clean",
                        );
                        return Ok(());
                    }
                    Err(error) => {
                        log.event(
                            "shutdown",
                            &[
                                ("status", "incomplete".into()),
                                ("error", error.to_string()),
                            ],
                        );
                        std::fs::write(path.with_extension("failed"), error.to_string())?;
                        return Err(error);
                    }
                }
            }
        }
        match listener.accept().map(|(stream, _)| stream) {
            Ok(stream) => {
                // Windows accepted sockets can inherit a nonblocking listener's mode.
                stream.set_nonblocking(false)?;
                stream.set_write_timeout(Some(Duration::from_secs(5)))?;
                // PERF3: this is a strict request/response protocol whose
                // reply is written as a header followed by its payload. With
                // Nagle enabled the second write waits for the client's
                // delayed acknowledgement, which measured ~43 ms per
                // statement on Linux loopback. Errors are ignored: the
                // option is an optimization, never a correctness condition.
                let _ = stream.set_nodelay(true);
                if active.fetch_add(1, Ordering::AcqRel) >= settings.max_connections {
                    active.fetch_sub(1, Ordering::AcqRel);
                    coordinator.metrics().global_connection_rejected();
                    drop(stream);
                    continue;
                }
                coordinator.metrics().connection_accepted();
                let connection_coordinator = Arc::clone(&coordinator);
                let connection_metrics = coordinator.metrics();
                let auth = auth.clone();
                let tls = tls.clone();
                let connection_active = Arc::clone(&active);
                let sockets_for_job = Arc::clone(&sockets);
                let role_connections = role_connections.clone();
                let connection_log = log.clone();
                let connection_audit = audit.clone();
                let connection_mtls = mtls_identities.clone();
                let max_result_bytes = settings.max_result_bytes;
                let session_id = connection_coordinator.new_session();
                sockets
                    .lock()
                    .map_err(|_| poisoned_lock_error())?
                    .insert(session_id, stream.try_clone()?);
                let submitted = pool.submit(move || {
                    struct ActiveConnection {
                        active: Arc<AtomicU64>,
                        metrics: Arc<Metrics>,
                        sockets: Arc<Mutex<BTreeMap<u64, TcpStream>>>,
                        session: u64,
                    }
                    impl Drop for ActiveConnection {
                        fn drop(&mut self) {
                            self.active.fetch_sub(1, Ordering::AcqRel);
                            self.metrics.connection_closed();
                            self.metrics.worker_stopped();
                            if let Ok(mut sockets) = self.sockets.lock() {
                                sockets.remove(&self.session);
                            }
                        }
                    }
                    let metrics = connection_coordinator.metrics();
                    metrics.worker_started();
                    let _active_connection = ActiveConnection {
                        active: connection_active,
                        metrics,
                        sockets: sockets_for_job,
                        session: session_id,
                    };
                    let result = if let Some(config) = tls {
                        match ServerConnection::new(config) {
                            Ok(connection) => request_transport::Pumped::tls(
                                stream,
                                connection,
                                connection_coordinator.clone(),
                                session_id,
                            )
                            .and_then(|mut stream| {
                                session_requests_configured(
                                    &mut stream,
                                    connection_coordinator.clone(),
                                    session_id,
                                    auth,
                                    max_result_bytes,
                                    role_connections,
                                    connection_log.clone(),
                                    connection_mtls,
                                    connection_audit,
                                )
                            }),
                            Err(error) => Err(PhobosError::new(ErrorCode::Tls, error.to_string())),
                        }
                    } else if request_path == request_transport::ResolvedPath::Direct {
                        // 0.2-H: the connection's worker reads, executes and
                        // responds itself (no reader thread hand-off).
                        if auto_policy {
                            phobos_observability::event(
                                "request.transport.auto_resolved_direct",
                                1,
                            );
                        }
                        request_transport::Direct::new(
                            stream,
                            Arc::clone(&connection_coordinator),
                            session_id,
                        )
                        .and_then(|mut stream| {
                            session_requests_configured(
                                &mut stream,
                                Arc::clone(&connection_coordinator),
                                session_id,
                                auth,
                                max_result_bytes,
                                role_connections,
                                connection_log.clone(),
                                connection_mtls,
                                connection_audit,
                            )
                        })
                    } else {
                        // 0.2-G reader-thread transport (Windows default).
                        if auto_policy {
                            phobos_observability::event(
                                "request.transport.auto_resolved_pumped",
                                1,
                            );
                        }
                        request_transport::Pumped::new(
                            stream,
                            Arc::clone(&connection_coordinator),
                            session_id,
                        )
                        .and_then(|mut stream| {
                            session_requests_configured(
                                &mut stream,
                                Arc::clone(&connection_coordinator),
                                session_id,
                                auth,
                                max_result_bytes,
                                role_connections,
                                connection_log.clone(),
                                connection_mtls,
                                connection_audit,
                            )
                        })
                    };
                    connection_coordinator.disconnect(session_id);
                    if let Err(error) = result {
                        connection_log.event(
                            "connection_error",
                            &[
                                ("session", session_id.to_string()),
                                ("error", error.to_string()),
                            ],
                        );
                    }
                });
                if submitted.is_err() {
                    active.fetch_sub(1, Ordering::AcqRel);
                    connection_metrics.connection_closed();
                    connection_metrics.global_connection_rejected();
                    if let Ok(mut open) = sockets.lock() {
                        open.remove(&session_id);
                    }
                }
            }
            Err(error) if error.kind() == io::ErrorKind::WouldBlock => {
                thread::sleep(Duration::from_millis(100));
            }
            Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
            Err(error) => return Err(error.into()),
        }
    }
}

fn validate_network_security(settings: &ServerSettings) -> Result<(), PhobosError> {
    let addr: std::net::SocketAddr = settings.bind.parse().map_err(|_| {
        PhobosError::new(
            ErrorCode::Semantic,
            "bind address must be a numeric socket address",
        )
    })?;
    let tls_configured = settings.tls_cert.is_some() && settings.tls_key.is_some();
    if !addr.ip().is_loopback() && !tls_configured {
        return Err(PhobosError::new(
            ErrorCode::Tls,
            "non-loopback bind requires TLS during alpha",
        ));
    }
    if settings.tls_cert.is_some() != settings.tls_key.is_some() {
        return Err(PhobosError::new(
            ErrorCode::Tls,
            "both TLS certificate and key are required",
        ));
    }
    if !addr.ip().is_loopback() && settings.auth_file.is_none() {
        return Err(PhobosError::new(
            ErrorCode::Authentication,
            "non-loopback bind requires authentication during alpha",
        ));
    }
    Ok(())
}

fn lock_data_directory(data_dir: &Path) -> Result<File, PhobosError> {
    let path = data_dir.join("phobos.lock");
    let file = OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false)
        .open(path)?;
    file.try_lock_exclusive().map_err(|_| {
        PhobosError::new(
            ErrorCode::DataDirectoryLocked,
            "data directory is already locked by another server or admin operation",
        )
    })?;
    Ok(file)
}

fn load_tls_config(
    cert: Option<&Path>,
    key: Option<&Path>,
    client_ca: Option<&Path>,
    mtls_required: bool,
) -> Result<Option<Arc<TlsServerConfig>>, PhobosError> {
    let (Some(cert), Some(key)) = (cert, key) else {
        return Ok(None);
    };
    let mut cert_reader = BufReader::new(File::open(cert)?);
    let certs: Vec<CertificateDer<'static>> = rustls_pemfile::certs(&mut cert_reader)
        .collect::<Result<Vec<_>, _>>()
        .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
    if certs.is_empty() {
        return Err(PhobosError::new(
            ErrorCode::Tls,
            "TLS certificate file contained no certificates",
        ));
    }
    let mut key_reader = BufReader::new(File::open(key)?);
    let key: PrivateKeyDer<'static> = rustls_pemfile::private_key(&mut key_reader)
        .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?
        .ok_or_else(|| PhobosError::new(ErrorCode::Tls, "TLS key file contained no private key"))?;
    let builder = TlsServerConfig::builder();
    let builder = if let Some(client_ca) = client_ca {
        let mut roots = RootCertStore::empty();
        let mut reader = BufReader::new(File::open(client_ca)?);
        let roots_certs: Vec<CertificateDer<'static>> = rustls_pemfile::certs(&mut reader)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
        if roots_certs.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::Tls,
                "client CA file contained no certificates",
            ));
        }
        for certificate in roots_certs {
            roots
                .add(certificate)
                .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
        }
        let verifier = WebPkiClientVerifier::builder(Arc::new(roots));
        let verifier = if mtls_required {
            verifier.build()
        } else {
            verifier.allow_unauthenticated().build()
        }
        .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
        builder.with_client_cert_verifier(verifier)
    } else {
        if mtls_required {
            return Err(PhobosError::new(
                ErrorCode::Tls,
                "mTLS requires a client CA",
            ));
        }
        builder.with_no_client_auth()
    };
    let config = builder
        .with_single_cert(certs, key)
        .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
    Ok(Some(Arc::new(config)))
}

fn certificate_fingerprint(certificate: &[u8]) -> String {
    let mut hash = 0xcbf29ce484222325u64;
    for byte in certificate {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(0x100000001b3);
    }
    format!("{hash:016x}")
}

pub fn serve(bind: &str, data_dir: &Path) -> Result<(), PhobosError> {
    serve_with_settings(ServerSettings::alpha_default(bind, data_dir))
}

#[cfg(test)]
mod tests {
    mod e45;
    mod g12;
    mod g34;
    mod i1_1_overflow_safety;
    mod i1_3_rotation_recovery;
    mod i1_transport_policy;
    mod k_lifecycle;
    mod mvcc;
    use super::*;
    use std::fs;
    use std::{
        net::TcpListener,
        path::PathBuf,
        sync::{Arc, Barrier},
        time::{SystemTime, UNIX_EPOCH},
    };

    fn stream_test_connection(
        coordinator: Arc<Coordinator>,
    ) -> (phobos_client::Client, thread::JoinHandle<()>) {
        stream_test_connection_auth(coordinator, None)
    }

    fn stream_test_connection_auth(
        coordinator: Arc<Coordinator>,
        auth: Option<Arc<AuthStore>>,
    ) -> (phobos_client::Client, thread::JoinHandle<()>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        let worker = thread::spawn(move || {
            let (mut socket, _) = listener.accept().unwrap();
            socket
                .set_write_timeout(Some(Duration::from_secs(5)))
                .unwrap();
            let id = coordinator.new_session();
            if coordinator.mvcc.is_some() {
                // 0.2-H: the production transport for plain TCP is Direct.
                let mut socket =
                    request_transport::Direct::new(socket, coordinator.clone(), id).unwrap();
                let _ = session_requests(
                    &mut socket,
                    coordinator.clone(),
                    id,
                    auth,
                    phobos_protocol::MAX_PAYLOAD,
                );
            } else {
                let _ = session_loop(
                    &mut socket,
                    Arc::clone(&coordinator),
                    id,
                    auth,
                    phobos_protocol::MAX_PAYLOAD,
                );
            }
            coordinator.disconnect(id);
        });
        (phobos_client::Client::connect(address).unwrap(), worker)
    }

    fn stream_test_data(coordinator: &Coordinator) {
        let id = coordinator.new_session();
        coordinator
            .execute(
                id,
                "CREATE TABLE streamed (id BIGINT NOT NULL, payload TEXT NOT NULL)",
            )
            .unwrap();
        let values = (0..1500)
            .map(|i| format!("({i},'{}')", "x".repeat(900)))
            .collect::<Vec<_>>()
            .join(",");
        coordinator
            .execute(id, &format!("INSERT INTO streamed VALUES {values}"))
            .unwrap();
    }

    #[test]
    fn streaming_preserves_authentication_and_reader_permissions() {
        let dir = temp_dir("stream-auth");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        coordinator
            .execute(
                coordinator.new_session(),
                "CREATE TABLE secured (id BIGINT)",
            )
            .unwrap();
        let mut store = AuthStore::open(dir.join("auth.txt")).unwrap();
        store
            .upsert_user("reader", "test-only-password", Role::Reader)
            .unwrap();
        let store = Arc::new(store);
        let (mut client, worker) =
            stream_test_connection_auth(Arc::clone(&coordinator), Some(Arc::clone(&store)));
        client.negotiate_streaming().unwrap();
        let mut code = String::new();
        assert!(
            client
                .query_stream("SELECT * FROM secured", |event| {
                    if let Event::Error { code: c, .. } = event {
                        code = c;
                    }
                    Ok(())
                })
                .is_err()
        );
        assert_eq!(code, "Authentication");
        drop(client);
        worker.join().unwrap();
        let (mut client, worker) =
            stream_test_connection_auth(Arc::clone(&coordinator), Some(Arc::clone(&store)));
        client.authenticate("reader", "test-only-password").unwrap();
        client.negotiate_streaming().unwrap();
        client
            .query_stream("SELECT * FROM secured", |_| Ok(()))
            .unwrap();
        client
            .query_stream("SHOW CATALOG COLUMNS FROM secured", |_| Ok(()))
            .unwrap();
        client
            .query_stream(
                "WITH visible AS (SELECT id FROM secured) SELECT id FROM visible",
                |_| Ok(()),
            )
            .unwrap();
        assert!(
            client
                .query("WITH x AS (DELETE FROM secured) SELECT * FROM x")
                .is_err()
        );

        assert!(
            client
                .query_stream("INSERT INTO secured VALUES (1)", |event| {
                    if let Event::Error { code: c, .. } = event {
                        code = c;
                    }
                    Ok(())
                })
                .is_err()
        );
        assert_eq!(code, "Authorization");
        drop(client);
        worker.join().unwrap();
        assert_eq!(
            coordinator
                .execute(
                    coordinator.new_session(),
                    "SELECT COUNT(*) AS n FROM secured"
                )
                .unwrap(),
            "n\n0\n"
        );
        drop(store);
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn streaming_large_ordered_result_legacy_empty_and_commands() {
        use phobos_client::StreamEvent;
        let dir = temp_dir("stream-large");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        stream_test_data(&coordinator);
        let (mut client, worker) = stream_test_connection(Arc::clone(&coordinator));
        assert!(!client.handshake().unwrap().contains(CAPABILITY));
        assert!(
            client
                .query("SELECT * FROM streamed")
                .unwrap_err()
                .message
                .contains("maximum")
        );
        client.negotiate_streaming().unwrap();
        let mut count = 0;
        let mut bytes = 0;
        let mut batches = 0;
        client
            .query_stream("SELECT * FROM streamed ORDER BY id", |event| {
                match event {
                    StreamEvent::Start(columns) => assert_eq!(columns, ["id", "payload"]),
                    StreamEvent::Rows { rows, .. } => {
                        batches += 1;
                        for row in rows {
                            assert_eq!(row.values[0].to_string(), count.to_string());
                            assert_eq!(row.values[1].to_string(), "x".repeat(900));
                            bytes += row.values[1].to_string().len();
                            count += 1;
                        }
                    }
                    StreamEvent::End {
                        rows,
                        batches: actual,
                    } => {
                        assert_eq!(rows, 1500);
                        assert_eq!(actual, batches);
                    }
                    _ => panic!("unexpected event"),
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(count, 1500);
        assert!(bytes > phobos_protocol::MAX_PAYLOAD);
        assert!(batches > 1);
        let mut empty = Vec::new();
        client
            .query_stream("SELECT id FROM streamed WHERE id<0", |event| {
                empty.push(event);
                Ok(())
            })
            .unwrap();
        assert_eq!(
            empty,
            [
                StreamEvent::Start(vec!["id".into()]),
                StreamEvent::End {
                    rows: 0,
                    batches: 0
                }
            ]
        );
        for command in ["BEGIN", "ROLLBACK"] {
            client
                .query_stream(command, |event| {
                    assert_eq!(
                        event,
                        StreamEvent::Command {
                            tag: command.into(),
                            rows_affected: 0
                        }
                    );
                    Ok(())
                })
                .unwrap();
        }
        assert!(
            client
                .query("SELECT COUNT(*) AS n FROM streamed")
                .unwrap()
                .contains("1500")
        );
        drop(client);
        worker.join().unwrap();
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn streaming_tls_verifies_hostname_auth_and_disconnect_rollback() {
        let dir = temp_dir("stream-tls");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        stream_test_data(&coordinator);
        let fixtures = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures");
        let config = load_tls_config(
            Some(&fixtures.join("server.pem")),
            Some(&fixtures.join("server-key.pem")),
            None,
            false,
        )
        .unwrap()
        .unwrap();
        let mut auth = AuthStore::open(dir.join("auth.txt")).unwrap();
        auth.upsert_user("reader", "test-only-password", Role::Reader)
            .unwrap();
        auth.upsert_user("admin", "test-only-password", Role::Admin)
            .unwrap();
        let auth = Arc::new(auth);
        let connect = |name: &str| {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let address = listener.local_addr().unwrap();
            let config = Arc::clone(&config);
            let coordinator = Arc::clone(&coordinator);
            let auth = Arc::clone(&auth);
            let worker = thread::spawn(move || {
                let (socket, _) = listener.accept().unwrap();
                socket
                    .set_write_timeout(Some(Duration::from_secs(5)))
                    .unwrap();
                let mut stream = StreamOwned::new(ServerConnection::new(config).unwrap(), socket);
                let id = coordinator.new_session();
                let _ = session_loop(
                    &mut stream,
                    Arc::clone(&coordinator),
                    id,
                    Some(auth),
                    phobos_protocol::MAX_PAYLOAD,
                );
                coordinator.disconnect(id);
            });
            (
                phobos_client::Client::connect_tls(address, name, fixtures.join("ca.pem")).unwrap(),
                worker,
            )
        };
        let (mut bad, worker) = connect("wrong-host.invalid");
        assert!(bad.negotiate_streaming().is_err());
        drop(bad);
        worker.join().unwrap();
        let (mut client, worker) = connect("localhost");
        client.negotiate_streaming().unwrap();
        client.authenticate("reader", "test-only-password").unwrap();
        let mut count = 0;
        client
            .query_stream("SELECT * FROM streamed ORDER BY id", |event| {
                if let Event::Rows { rows, .. } = event {
                    for row in rows {
                        assert_eq!(row.values[0], phobos_types::Value::Int64(count));
                        assert_eq!(row.values[1], phobos_types::Value::Text("x".repeat(900)));
                        count += 1;
                    }
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(count, 1500);
        let mut denied = false;
        assert!(
            client
                .query_stream("INSERT INTO streamed VALUES (9999,'forbidden')", |event| {
                    if let Event::Error { code, .. } = event {
                        denied = code == "Authorization";
                    }
                    Ok(())
                })
                .is_err()
        );
        assert!(denied);
        drop(client);
        worker.join().unwrap();
        let (mut client, worker) = connect("localhost");
        client.negotiate_streaming().unwrap();
        client.authenticate("admin", "test-only-password").unwrap();
        client.query_stream("BEGIN", |_| Ok(())).unwrap();
        client
            .query_stream("INSERT INTO streamed VALUES (9999,'uncommitted')", |_| {
                Ok(())
            })
            .unwrap();
        assert!(
            client
                .query_stream("SELECT * FROM streamed ORDER BY id", |event| {
                    if matches!(event, Event::Rows { .. }) {
                        return Err(PhobosError::new(ErrorCode::Io, "TLS consumer cancelled"));
                    }
                    Ok(())
                })
                .is_err()
        );
        drop(client);
        worker.join().unwrap();
        assert_eq!(
            coordinator
                .execute(
                    coordinator.new_session(),
                    "SELECT COUNT(*) AS n FROM streamed"
                )
                .unwrap(),
            "n\n1500\n"
        );
        drop(auth);
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn streaming_large_join_and_sort_deliver_all_rows() {
        let dir = temp_dir("stream-join");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        stream_test_data(&coordinator);
        let id = coordinator.new_session();
        coordinator
            .execute(id, "CREATE TABLE labels (id BIGINT, label TEXT)")
            .unwrap();
        coordinator
            .execute(id, "INSERT INTO labels VALUES (0,'zero'),(1000,'thousand')")
            .unwrap();
        for ordered in [false, true] {
            let (mut client, worker) = stream_test_connection(Arc::clone(&coordinator));
            client.negotiate_streaming().unwrap();
            let sql = format!(
                "SELECT streamed.id, streamed.payload, labels.label FROM streamed LEFT JOIN labels ON streamed.id=labels.id{}",
                if ordered { " ORDER BY streamed.id" } else { "" }
            );
            let mut count = 0;
            let mut batches = 0;
            client
                .query_stream(&sql, |event| {
                    match event {
                        Event::Rows { rows, .. } => {
                            batches += 1;
                            for row in rows {
                                assert_eq!(row.values[0], phobos_types::Value::Int64(count));
                                assert_eq!(
                                    row.values[1],
                                    phobos_types::Value::Text("x".repeat(900))
                                );
                                assert_eq!(
                                    row.values[2],
                                    match count {
                                        0 => phobos_types::Value::Text("zero".into()),
                                        1000 => phobos_types::Value::Text("thousand".into()),
                                        _ => phobos_types::Value::Null,
                                    }
                                );
                                count += 1;
                            }
                        }
                        Event::End { rows, .. } => assert_eq!(rows, 1500),
                        Event::Start(_) => {}
                        _ => panic!("unexpected join event"),
                    }
                    Ok(())
                })
                .unwrap();
            assert_eq!(count, 1500);
            assert!(batches > 1);
            drop(client);
            worker.join().unwrap();
        }
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn enterprise_management_and_queries_over_stream_protocol() {
        use phobos_client::StreamEvent;
        let dir = temp_dir("enterprise-protocol");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let (mut client, worker) = stream_test_connection(Arc::clone(&coordinator));
        client
            .query("CREATE TABLE enterprise (id BIGINT NOT NULL, label TEXT)")
            .unwrap();
        client
            .query("INSERT INTO enterprise (label,id) VALUES ('  hello  ',1)")
            .unwrap();
        client.negotiate_streaming().unwrap();
        for sql in [
            "SHOW CATALOG COLUMNS FROM enterprise",
            "SELECT id FROM enterprise LIMIT (SELECT COUNT(*) FROM enterprise)",
            "SELECT id FROM enterprise OFFSET (SELECT id-1 FROM enterprise)",
            "WITH clean AS (SELECT id, TRIM(label) AS label FROM enterprise) SELECT c.label FROM clean c",
            "SELECT a.id FROM enterprise a JOIN enterprise b ON a.id=b.id AND b.id>0",
        ] {
            let mut count = 0;
            let mut ended = false;
            client
                .query_stream(sql, |event| {
                    match event {
                        StreamEvent::Rows { rows, .. } => count += rows.len(),
                        StreamEvent::End { .. } => ended = true,
                        _ => (),
                    }
                    Ok(())
                })
                .unwrap();
            assert!(ended && count > 0, "{sql}");
        }
        client.query("PREPARE meta AS SHOW CATALOG TABLES").unwrap();
        assert!(client.query("EXECUTE meta").unwrap().contains("enterprise"));
        drop(client);
        worker.join().unwrap();
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn streaming_disconnect_rolls_back_and_releases_handles() {
        use phobos_client::StreamEvent;
        let dir = temp_dir("stream-disconnect");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        stream_test_data(&coordinator);
        let (mut client, worker) = stream_test_connection(Arc::clone(&coordinator));
        client.negotiate_streaming().unwrap();
        client.query_stream("BEGIN", |_| Ok(())).unwrap();
        client
            .query_stream("INSERT INTO streamed VALUES (9999, 'uncommitted')", |_| {
                Ok(())
            })
            .unwrap();
        let mut received = false;
        assert!(
            client
                .query_stream("SELECT * FROM streamed", |event| {
                    if matches!(event, StreamEvent::Rows { .. }) {
                        received = true;
                        return Err(PhobosError::new(ErrorCode::Semantic, "consumer cancelled"));
                    }
                    Ok(())
                })
                .is_err()
        );
        assert!(received);
        assert!(client.query("SELECT * FROM streamed").is_err());
        drop(client);
        worker.join().unwrap();
        let next = coordinator.new_session();
        assert!(
            coordinator
                .execute(next, "SELECT COUNT(*) AS n FROM streamed")
                .unwrap()
                .contains("1500")
        );
        coordinator.execute(next, "BEGIN").unwrap();
        coordinator.execute(next, "ROLLBACK").unwrap();
        drop(coordinator);
        assert!(!fs::read_dir(&dir).unwrap().any(|entry| {
            entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-")
        }));
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn beta_begin_transaction_preserves_session_ownership() {
        let dir = temp_dir("beta-begin");
        let coordinator = Coordinator::open_with_timeout(&dir, Duration::from_millis(20)).unwrap();
        let owner = coordinator.new_session();
        let other = coordinator.new_session();
        coordinator
            .execute(owner, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        coordinator.execute(owner, "BEGIN TRANSACTION").unwrap();
        coordinator
            .execute(owner, "INSERT INTO t VALUES (7)")
            .unwrap();
        assert_eq!(
            coordinator
                .execute(other, "SELECT * FROM t")
                .unwrap_err()
                .code,
            ErrorCode::LockTimeout
        );
        coordinator.disconnect(owner);
        assert_eq!(
            coordinator.execute(other, "SELECT * FROM t").unwrap(),
            "id\n"
        );
        drop(coordinator);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn beta_statement_admission_keeps_owner_stable() {
        let dir = temp_dir("beta-admission");
        let coordinator = Coordinator::open(&dir).unwrap();
        let admission = coordinator
            .wait_for_turn(coordinator.new_session())
            .unwrap();
        assert!(coordinator.owner.try_lock().is_err());
        let database = coordinator.lock_database().unwrap();
        drop(admission);
        assert!(coordinator.owner.try_lock().is_ok());
        drop(database);
        drop(coordinator);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn beta_protocol_error_releases_session_metric() {
        let dir = temp_dir("beta-metrics");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let mut stream = std::io::Cursor::new(vec![0; 16]);
        let result = session_loop(
            &mut stream,
            Arc::clone(&coordinator),
            coordinator.new_session(),
            None,
            1024,
        );
        assert!(result.is_err());
        assert_eq!(coordinator.metrics().snapshot().active_sessions, 0);
        drop(coordinator);
        std::fs::remove_dir_all(dir).unwrap();
    }

    fn temp_dir(label: &str) -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-phase5-{label}-{n}"))
    }

    #[test]
    fn hello_handshake_over_tcp() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let server = thread::spawn(move || {
            let (stream, _) = listener.accept().unwrap();
            handle_connection(stream).unwrap();
        });
        let mut stream = TcpStream::connect(addr).unwrap();
        Frame::new(MessageType::Hello, 99, b"phobos-client".to_vec())
            .write_to(&mut stream)
            .unwrap();
        let response = Frame::read_from(&mut stream).unwrap();
        assert_eq!(response.message_type, MessageType::HelloAck);
        assert_eq!(response.request_id, 99);
        server.join().unwrap();
    }

    #[test]
    fn other_session_times_out_while_transaction_is_open() {
        let dir = temp_dir("timeout");
        let coordinator = Coordinator::open_with_timeout(&dir, Duration::from_millis(80)).unwrap();
        let first = coordinator.new_session();
        let second = coordinator.new_session();
        coordinator
            .execute(first, "CREATE TABLE t (id BIGINT NOT NULL)")
            .unwrap();
        coordinator.execute(first, "BEGIN").unwrap();
        coordinator
            .execute(first, "INSERT INTO t VALUES (1)")
            .unwrap();
        let error = coordinator.execute(second, "SELECT * FROM t").unwrap_err();
        assert_eq!(error.code, ErrorCode::LockTimeout);
        coordinator.execute(first, "ROLLBACK").unwrap();
        let rows = coordinator.execute(second, "SELECT * FROM t").unwrap();
        assert!(!rows.contains("\n1\n"));
        drop(coordinator);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn disconnect_rolls_back_and_releases_waiters() {
        let dir = temp_dir("disconnect");
        let coordinator =
            Arc::new(Coordinator::open_with_timeout(&dir, Duration::from_secs(1)).unwrap());
        let first = coordinator.new_session();
        let second = coordinator.new_session();
        coordinator
            .execute(first, "CREATE TABLE t (id BIGINT NOT NULL)")
            .unwrap();
        coordinator.execute(first, "BEGIN").unwrap();
        coordinator
            .execute(first, "INSERT INTO t VALUES (7)")
            .unwrap();

        let barrier = Arc::new(Barrier::new(2));
        let worker_coordinator = Arc::clone(&coordinator);
        let worker_barrier = Arc::clone(&barrier);
        let worker = thread::spawn(move || {
            worker_barrier.wait();
            worker_coordinator
                .execute(second, "SELECT * FROM t")
                .unwrap()
        });
        barrier.wait();
        thread::sleep(Duration::from_millis(20));
        coordinator.disconnect(first);
        let rows = worker.join().unwrap();
        assert!(!rows.contains("\n7\n"));
        drop(coordinator);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn simultaneous_autocommit_writers_are_serialized_without_lost_rows() {
        let dir = temp_dir("writers");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let setup = coordinator.new_session();
        coordinator
            .execute(setup, "CREATE TABLE t (id BIGINT NOT NULL)")
            .unwrap();
        let barrier = Arc::new(Barrier::new(3));
        let mut handles = Vec::new();
        for id in [1, 2] {
            let coordinator = Arc::clone(&coordinator);
            let barrier = Arc::clone(&barrier);
            handles.push(thread::spawn(move || {
                let session = coordinator.new_session();
                barrier.wait();
                coordinator
                    .execute(session, &format!("INSERT INTO t VALUES ({id})"))
                    .unwrap();
            }));
        }
        barrier.wait();
        for handle in handles {
            handle.join().unwrap();
        }
        let rows = coordinator
            .execute(setup, "SELECT * FROM t ORDER BY id")
            .unwrap();
        assert!(rows.contains("\n1\n"));
        assert!(rows.contains("\n2\n"));
        drop(coordinator);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn queued_groups_are_read_ddl_and_begin_barriers() {
        let dir = temp_dir("group-barrier");
        let coordinator = Coordinator::open_with_timeout(&dir, Duration::from_millis(20)).unwrap();
        let session = coordinator.new_session();
        coordinator
            .execute(session, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        coordinator.groups.lock().unwrap().running = true;
        for sql in [
            "SELECT * FROM t",
            "CREATE TABLE hidden (id BIGINT)",
            "BEGIN",
        ] {
            assert_eq!(
                coordinator.execute(session, sql).unwrap_err().code,
                ErrorCode::LockTimeout
            );
        }
        assert!(coordinator.owner.lock().unwrap().is_none());
        coordinator.groups.lock().unwrap().running = false;
        assert!(
            coordinator
                .execute(session, "SELECT * FROM hidden")
                .is_err()
        );
        coordinator.execute(session, "SELECT * FROM t").unwrap();
        drop(coordinator);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn paused_force_releases_structural_guards_and_bounds_shutdown_and_queue() {
        let dir = temp_dir("c2-paused-force");
        let coordinator =
            Arc::new(Coordinator::open_with_timeout(&dir, Duration::from_millis(100)).unwrap());
        let session = coordinator.new_session();
        for table in ["a", "b"] {
            coordinator
                .execute(
                    session,
                    &format!("CREATE TABLE {table} (id BIGINT NOT NULL)"),
                )
                .unwrap();
        }
        let (reached, paused) = std::sync::mpsc::channel();
        let (release, resume) = std::sync::mpsc::channel();
        let resume = Mutex::new(resume);
        let first = AtomicBool::new(true);
        let weak = Arc::downgrade(&coordinator);
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "wal.before_force" && first.swap(false, Ordering::SeqCst) {
                    let coordinator = weak.upgrade().unwrap();
                    assert!(coordinator.database.try_lock().unwrap().is_none());
                    assert!(coordinator.owner.try_lock().unwrap().is_none());
                    assert!(coordinator.groups.try_lock().unwrap().running);
                    reached.send(()).unwrap();
                    resume
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(5))
                        .unwrap();
                }
            }),
        );
        let mut completions = Vec::new();
        {
            let mut queue = coordinator.groups.lock().unwrap();
            queue.running = true;
            for table in ["a", "b"] {
                let (completion, receiver) = std::sync::mpsc::channel();
                queue.requests.push(CommitRequest {
                    context: None,
                    sql: format!("INSERT INTO {table} VALUES (1)"),
                    enqueued: Instant::now(),
                    completion,
                });
                completions.push(receiver);
            }
        }
        let worker = Arc::clone(&coordinator);
        let leader = thread::spawn(move || worker.run_commit_groups().unwrap());
        paused.recv_timeout(Duration::from_secs(5)).unwrap();
        for receiver in &completions {
            assert!(receiver.try_recv().is_err());
        }
        // Accepted arrivals remain in a later prefix. A disconnected waiter is
        // not a cancellation of a possibly durable transaction.
        {
            let mut queue = coordinator.groups.lock().unwrap();
            for id in 2..66 {
                let (completion, receiver) = std::sync::mpsc::channel();
                drop(receiver);
                queue.requests.push(CommitRequest {
                    context: None,
                    sql: format!("INSERT INTO a VALUES ({id})"),
                    enqueued: Instant::now(),
                    completion,
                });
            }
        }
        assert_eq!(
            coordinator
                .execute(session, "INSERT INTO a VALUES (99)")
                .unwrap_err()
                .code,
            ErrorCode::ResourceLimit
        );
        for sql in [
            "SELECT * FROM a",
            "CREATE TABLE blocked (id BIGINT)",
            "BEGIN",
        ] {
            assert_eq!(
                coordinator.execute(session, sql).unwrap_err().code,
                ErrorCode::LockTimeout
            );
        }
        assert_eq!(
            coordinator.shutdown().unwrap_err().code,
            ErrorCode::LockTimeout
        );
        assert!(
            coordinator
                .execute(session, "INSERT INTO a VALUES (100)")
                .is_err()
        );
        release.send(()).unwrap();
        leader.join().unwrap();
        for receiver in completions {
            assert!(matches!(
                receiver.try_recv().unwrap(),
                CommitCompletion::Done(Ok(_))
            ));
            assert!(receiver.try_recv().is_err());
        }
        coordinator.shutdown().unwrap();
        drop(hook);
        drop(coordinator);
        let mut db = Database::open(&dir).unwrap();
        assert_eq!(
            db.execute("SELECT COUNT(*) FROM a").unwrap().to_text(),
            "count(*)\n65\n"
        );
        assert_eq!(
            db.execute("SELECT COUNT(*) FROM b").unwrap().to_text(),
            "count(*)\n1\n"
        );
        assert!(db.execute("SELECT * FROM blocked").is_err());
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn database_return_wakes_writer_when_earlier_reader_must_readmit() {
        let dir = temp_dir("c2-mixed-wakeup");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let session = coordinator.new_session();
        coordinator
            .execute(session, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        let lease = coordinator.lock_database().unwrap();
        let (reached, waiting) = std::sync::mpsc::channel();
        let reader_announced = AtomicBool::new(false);
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                // Condvars may wake repeatedly before the database is returned.
                // Announce reader arrival once; still require the real writer hook.
                if point == "server.lease_wait"
                    || (point == "server.database_wait"
                        && !reader_announced.swap(true, Ordering::SeqCst))
                {
                    let _ = reached.send(point.to_owned());
                }
            }),
        );
        let worker = Arc::clone(&coordinator);
        let reader = thread::spawn(move || worker.execute(session, "SELECT * FROM t"));
        assert_eq!(
            waiting.recv_timeout(Duration::from_secs(2)).unwrap(),
            "server.database_wait"
        );
        let worker = Arc::clone(&coordinator);
        let (done, completed) = std::sync::mpsc::channel();
        let writer = thread::spawn(move || {
            let result = worker.execute(worker.new_session(), "INSERT INTO t VALUES (1)");
            done.send(result).unwrap();
        });
        assert_eq!(
            waiting.recv_timeout(Duration::from_secs(2)).unwrap(),
            "server.lease_wait"
        );
        drop(lease);
        let result = completed.recv_timeout(Duration::from_secs(1));
        // Drain even an incorrect implementation before reporting the failure,
        // so a regression never leaves a parked test thread holding files.
        coordinator.database_changed.notify_all();
        writer.join().unwrap();
        let rows = reader.join().unwrap();
        assert_eq!(result.unwrap().unwrap(), "INSERT 1");
        assert!(rows.unwrap().contains("\n1\n"));
        drop(hook);
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn waking_read_rechecks_a_new_explicit_owner_before_execution() {
        let dir = temp_dir("c2-admission-recheck");
        let coordinator =
            Arc::new(Coordinator::open_with_timeout(&dir, Duration::from_millis(100)).unwrap());
        let session = coordinator.new_session();
        let owner = coordinator.new_session();
        coordinator
            .execute(session, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        let mut lease = coordinator.lock_database().unwrap();
        let (reached, waiting) = std::sync::mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "server.database_wait" {
                    let _ = reached.send(());
                }
            }),
        );
        let worker = Arc::clone(&coordinator);
        let reader = thread::spawn(move || worker.execute(session, "SELECT * FROM t"));
        waiting.recv_timeout(Duration::from_secs(2)).unwrap();
        coordinator.claim_owner(owner).unwrap();
        lease.execute("BEGIN").unwrap();
        lease.execute("INSERT INTO t VALUES (9)").unwrap();
        drop(lease);
        assert_eq!(
            reader.join().unwrap().unwrap_err().code,
            ErrorCode::LockTimeout
        );
        coordinator.execute(owner, "ROLLBACK").unwrap();
        assert!(
            !coordinator
                .execute(session, "SELECT * FROM t")
                .unwrap()
                .contains("\n9\n")
        );
        drop(hook);
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn waiting_read_releases_admission_and_shutdown_wait_is_bounded() {
        let dir = temp_dir("c2-read-admission");
        let coordinator =
            Arc::new(Coordinator::open_with_timeout(&dir, Duration::from_millis(100)).unwrap());
        let session = coordinator.new_session();
        coordinator
            .execute(session, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        let lease = coordinator.lock_database().unwrap();
        let (reached, waiting) = std::sync::mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "server.database_wait" {
                    let _ = reached.send(());
                }
            }),
        );
        let worker = Arc::clone(&coordinator);
        let reader = thread::spawn(move || worker.execute(session, "SELECT * FROM t"));
        waiting.recv_timeout(Duration::from_secs(2)).unwrap();
        assert!(coordinator.owner.try_lock().unwrap().is_none());
        assert_eq!(
            coordinator.shutdown().unwrap_err().code,
            ErrorCode::LockTimeout
        );
        drop(lease);
        assert!(reader.join().unwrap().is_err());
        coordinator.shutdown().unwrap();
        drop(hook);
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn durable_execution_panic_completes_every_waiter_and_fences_successors() {
        let dir = temp_dir("c2-panic-completions");
        let coordinator = Coordinator::open(&dir).unwrap();
        let session = coordinator.new_session();
        for table in ["a", "b"] {
            coordinator
                .execute(session, &format!("CREATE TABLE {table} (id BIGINT)"))
                .unwrap();
        }
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(|point| {
                if point == "wal.after_force" {
                    panic!("injected durable execution panic");
                }
            }),
        );
        let mut receivers = Vec::new();
        {
            let mut queue = coordinator.groups.lock().unwrap();
            queue.running = true;
            for table in ["a", "b"] {
                let (completion, receiver) = std::sync::mpsc::channel();
                queue.requests.push(CommitRequest {
                    context: None,
                    sql: format!("INSERT INTO {table} VALUES (1)"),
                    enqueued: Instant::now(),
                    completion,
                });
                receivers.push(receiver);
            }
        }
        coordinator.run_commit_groups().unwrap();
        for receiver in receivers {
            assert!(matches!(
                receiver.try_recv().unwrap(),
                CommitCompletion::Done(Err(_))
            ));
            assert!(receiver.try_recv().is_err());
        }
        assert!(!coordinator.groups.lock().unwrap().running);
        assert!(
            coordinator
                .execute(session, "INSERT INTO a VALUES (2)")
                .is_err()
        );
        assert!(coordinator.execute(session, "SELECT * FROM a").is_err());
        drop(hook);
        drop(coordinator);
        let mut db = Database::open(&dir).unwrap();
        for table in ["a", "b"] {
            assert_eq!(
                db.execute(&format!("SELECT id FROM {table}"))
                    .unwrap()
                    .to_text(),
                "id\n1\n"
            );
        }
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn unwinding_detached_owner_fences_instead_of_reusing_partial_state() {
        let dir = temp_dir("c2-panic-lease");
        let coordinator = Coordinator::open(&dir).unwrap();
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let _lease = coordinator.lock_database().unwrap();
            panic!("injected execution unwind");
        }));
        assert!(result.is_err());
        assert!(
            coordinator
                .execute(coordinator.new_session(), "CREATE TABLE t (id BIGINT)")
                .is_err()
        );
        drop(coordinator);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn completed_leader_hands_off_without_executing_later_waiters() {
        let dir = temp_dir("group-handoff");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let session = coordinator.new_session();
        coordinator
            .execute(session, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        let database = coordinator.database.lock().unwrap();
        let (first_sender, first) = std::sync::mpsc::channel();
        {
            let mut queue = coordinator.groups.lock().unwrap();
            queue.running = true;
            queue.requests.push(CommitRequest {
                context: None,
                sql: "INSERT INTO t VALUES (1)".into(),
                enqueued: Instant::now(),
                completion: first_sender,
            });
        }
        let worker = Arc::clone(&coordinator);
        let leader = thread::spawn(move || worker.run_commit_groups().unwrap());
        let (second_sender, second) = std::sync::mpsc::channel();
        {
            let mut queue = coordinator.groups.lock().unwrap();
            while !queue.requests.is_empty() {
                let (next, timeout) = coordinator
                    .group_changed
                    .wait_timeout(queue, Duration::from_secs(2))
                    .unwrap();
                queue = next;
                assert!(!timeout.timed_out(), "leader never acquired its batch");
            }
            queue.requests.push(CommitRequest {
                context: None,
                sql: "INSERT INTO t VALUES (2)".into(),
                enqueued: Instant::now(),
                completion: second_sender,
            });
        }
        drop(database);
        assert!(matches!(
            first.recv_timeout(Duration::from_secs(2)).unwrap(),
            CommitCompletion::Done(Ok(_))
        ));
        assert!(matches!(
            second.recv_timeout(Duration::from_secs(2)).unwrap(),
            CommitCompletion::Lead
        ));
        leader.join().unwrap();
        coordinator.run_commit_groups().unwrap();
        assert!(matches!(
            second.try_recv().unwrap(),
            CommitCompletion::Done(Ok(_))
        ));
        let rows = coordinator
            .execute(session, "SELECT id FROM t ORDER BY id")
            .unwrap();
        assert!(rows.contains("\n1\n") && rows.contains("\n2\n"));
        drop(coordinator);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn append_failure_completes_every_queued_waiter_and_fences_successors() {
        let dir = temp_dir("group-failure");
        let coordinator = Coordinator::open(&dir).unwrap();
        let session = coordinator.new_session();
        coordinator
            .execute(session, "CREATE TABLE t (id BIGINT)")
            .unwrap();
        OpenOptions::new()
            .append(true)
            .open(dir.join("phobos.wal"))
            .unwrap()
            .write_all(b"damage")
            .unwrap();
        let mut receivers = Vec::new();
        {
            let mut queue = coordinator.groups.lock().unwrap();
            queue.running = true;
            for id in 0..8 {
                let (completion, receiver) = std::sync::mpsc::channel();
                queue.requests.push(CommitRequest {
                    context: None,
                    enqueued: Instant::now(),
                    sql: format!("INSERT INTO t VALUES ({id})"),
                    completion,
                });
                receivers.push(receiver);
            }
        }
        coordinator.run_commit_groups().unwrap();
        for receiver in receivers {
            assert!(matches!(
                receiver.try_recv().unwrap(),
                CommitCompletion::Done(Err(_))
            ));
        }
        assert!(!coordinator.groups.lock().unwrap().running);
        assert!(coordinator.execute(session, "SELECT * FROM t").is_err());
        drop(coordinator);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn phase7_data_directory_lock_rejects_second_owner() {
        let dir = temp_dir("dir-lock");
        std::fs::create_dir_all(&dir).unwrap();
        let first = lock_data_directory(&dir).unwrap();
        let error = lock_data_directory(&dir).unwrap_err();
        assert_eq!(error.code, ErrorCode::DataDirectoryLocked);
        drop(first);
        lock_data_directory(&dir).unwrap();
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn phase7_non_loopback_requires_tls_and_auth() {
        let dir = temp_dir("network-security");
        let settings = ServerSettings::alpha_default("0.0.0.0:54321", dir);
        let error = validate_network_security(&settings).unwrap_err();
        assert_eq!(error.code, ErrorCode::Tls);
    }
}
