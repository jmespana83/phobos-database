//! Active-only cancellation registry. Handles are random, single-use and owned
//! by the authenticated username. The no-auth loopback mode is a trusted domain.
use super::*;
use phobos_error::cancellation::{Scope, StatementContext};
use rand_core::{OsRng, RngCore};
use std::collections::BTreeMap;
pub const DEFAULT_STATEMENT_TIMEOUT: Duration = Duration::from_secs(30 * 60);
pub const DEFAULT_IDLE_TIMEOUT: Duration = Duration::from_secs(15 * 60);
#[derive(Default)]
pub(super) struct Registry(Mutex<BTreeMap<String, Active>>);
struct Active {
    session: u64,
    owner: String,
    context: StatementContext,
}
pub(super) struct Guard<'a> {
    registry: &'a Registry,
    handle: String,
    _scope: Scope,
}
pub(super) fn handle() -> Result<String, PhobosError> {
    let mut bytes = [0u8; 32];
    OsRng
        .try_fill_bytes(&mut bytes)
        .map_err(|error| PhobosError::new(ErrorCode::ResourceLimit, error.to_string()))?;
    Ok(hex(&bytes))
}
fn hex(bytes: &[u8; 32]) -> String {
    const DIGITS: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(64);
    for byte in bytes {
        out.push(DIGITS[usize::from(byte >> 4)] as char);
        out.push(DIGITS[usize::from(byte & 15)] as char);
    }
    out
}
/// 0.2-H: registry handles for statements whose client never asked for one
/// (`CancelHandle`). Such a handle is never disclosed to anybody; it only has
/// to be unique and unguessable. One OS random base per connection, then a
/// per-statement counter folded into it — instead of one `getrandom` call
/// and 32 string allocations per statement. Disclosed handles still come
/// from [`handle`].
pub(super) struct InternalHandles {
    base: [u8; 32],
    next: u64,
}
impl InternalHandles {
    pub fn new() -> Result<Self, PhobosError> {
        let mut base = [0u8; 32];
        OsRng
            .try_fill_bytes(&mut base)
            .map_err(|error| PhobosError::new(ErrorCode::ResourceLimit, error.to_string()))?;
        Ok(Self { base, next: 0 })
    }
    pub fn next_handle(&mut self) -> String {
        self.next = self.next.wrapping_add(1);
        let mut bytes = self.base;
        for (byte, counter) in bytes[24..].iter_mut().zip(self.next.to_le_bytes()) {
            *byte ^= counter;
        }
        hex(&bytes)
    }
}
impl Registry {
    pub fn start(
        &self,
        handle: String,
        session: u64,
        owner: String,
        timeout: Duration,
    ) -> Result<Guard<'_>, PhobosError> {
        let context = StatementContext::new(handle.clone(), Some(timeout));
        let mut entries = self.0.lock().map_err(|_| poisoned_lock_error())?;
        if entries.contains_key(&handle) {
            return Err(PhobosError::new(
                ErrorCode::CancellationTarget,
                "cancellation handle already active",
            ));
        }
        let scope = context.enter();
        entries.insert(
            handle.clone(),
            Active {
                session,
                owner,
                context,
            },
        );
        Ok(Guard {
            registry: self,
            handle,
            _scope: scope,
        })
    }
    pub fn cancel(&self, handle: &str, owner: &str) -> Result<(), PhobosError> {
        let entries = self.0.lock().map_err(|_| poisoned_lock_error())?;
        let active = entries.get(handle).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::CancellationTarget,
                "unknown or completed cancellation target",
            )
        })?;
        if active.owner != owner {
            return Err(PhobosError::new(
                ErrorCode::Authorization,
                "cancellation target belongs to another user",
            ));
        }
        active.context.token.cancel();
        Ok(())
    }
    pub fn disconnect(&self, session: u64) {
        if let Ok(entries) = self.0.lock() {
            for active in entries.values().filter(|active| active.session == session) {
                active.context.token.cancel();
            }
        }
    }
    #[cfg(test)]
    pub fn any_cancelled(&self) -> bool {
        self.0
            .lock()
            .unwrap()
            .values()
            .any(|active| active.context.token.is_cancelled())
    }
    #[cfg(test)]
    pub fn len(&self) -> usize {
        self.0.lock().unwrap().len()
    }
}
impl Drop for Guard<'_> {
    fn drop(&mut self) {
        self.registry
            .0
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .remove(&self.handle);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn a2_registry_scope_cleans_success_error_and_unwind() {
        let registry = Registry::default();
        let old = handle().unwrap();
        {
            let _guard = registry
                .start(old.clone(), 1, "alice".into(), DEFAULT_STATEMENT_TIMEOUT)
                .unwrap();
            assert_eq!(registry.len(), 1);
            assert_eq!(
                registry.cancel(&old, "bob").unwrap_err().code,
                ErrorCode::Authorization
            );
        }
        assert_eq!(registry.len(), 0);
        assert_eq!(
            registry.cancel(&old, "alice").unwrap_err().code,
            ErrorCode::CancellationTarget
        );
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let _guard = registry
                .start(
                    handle().unwrap(),
                    2,
                    "alice".into(),
                    DEFAULT_STATEMENT_TIMEOUT,
                )
                .unwrap();
            panic!("test panic before durability admission");
        }));
        assert!(result.is_err());
        assert_eq!(registry.len(), 0);
        phobos_error::cancellation::check_now().unwrap();
    }
    #[test]
    fn h1_internal_handles_are_unique_hex_and_differ_per_connection() {
        let mut first = InternalHandles::new().unwrap();
        let mut second = InternalHandles::new().unwrap();
        let mut seen = std::collections::BTreeSet::new();
        for _ in 0..1000 {
            let handle = first.next_handle();
            assert_eq!(handle.len(), 64);
            assert!(handle.bytes().all(|b| b.is_ascii_hexdigit()));
            assert!(seen.insert(handle));
        }
        assert!(!seen.contains(&second.next_handle()));
        assert_eq!(handle().unwrap().len(), 64);
    }
}
