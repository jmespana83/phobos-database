use phobos_auth::Role;
use phobos_config::LogFormat;
use phobos_error::{ErrorCode, PhobosError};
use phobos_sql::Statement;
use std::{
    collections::BTreeMap,
    fs::{File, OpenOptions},
    io::Write,
    path::Path,
    sync::{Arc, Mutex, mpsc},
    thread,
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};

#[derive(Clone, Default)]
pub(super) struct AuditLog(Option<Arc<Mutex<File>>>);

impl AuditLog {
    pub(super) fn new(enabled: bool, path: Option<&Path>) -> Result<Self, PhobosError> {
        if !enabled {
            return Ok(Self::default());
        }
        let path = path.ok_or_else(|| {
            PhobosError::new(ErrorCode::ResourceLimit, "audit log path is required")
        })?;
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let file = OpenOptions::new().create(true).append(true).open(path)?;
        Ok(Self(Some(Arc::new(Mutex::new(file)))))
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn event(
        &self,
        event: &str,
        principal: &str,
        session: u64,
        action: &str,
        target: &str,
        success: bool,
        detail: &str,
    ) {
        let Some(file) = &self.0 else { return };
        let timestamp_ms = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        let bounded = |value: &str| value.chars().take(256).collect::<String>();
        let value = serde_json::json!({
            "timestamp_ms": timestamp_ms,
            "event": bounded(event),
            "principal": bounded(principal),
            "session": session,
            "action": bounded(action),
            "target": bounded(target),
            "success": success,
            "detail": bounded(detail),
        });
        if let Ok(mut file) = file.lock() {
            let _ = writeln!(file, "{value}");
            let _ = file.flush();
        }
    }
}

#[derive(Clone)]
pub(super) struct OperatorLog {
    format: LogFormat,
    slow_query: Option<Duration>,
}

impl OperatorLog {
    pub(super) fn new(format: LogFormat, slow_query_ms: u64) -> Self {
        Self {
            format,
            slow_query: (slow_query_ms != 0).then(|| Duration::from_millis(slow_query_ms)),
        }
    }

    pub(super) fn event(&self, name: &str, fields: &[(&str, String)]) {
        eprintln!("{}", self.render(name, fields));
    }

    fn render(&self, name: &str, fields: &[(&str, String)]) -> String {
        let timestamp_ms = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        match self.format {
            LogFormat::Text => {
                let fields = fields
                    .iter()
                    .map(|(key, value)| format!("{key}={value}"))
                    .collect::<Vec<_>>()
                    .join(" ");
                format!("timestamp_ms={timestamp_ms} event={name} {fields}")
            }
            LogFormat::Json => {
                let mut object = serde_json::Map::new();
                object.insert(
                    "timestamp_ms".into(),
                    u64::try_from(timestamp_ms).unwrap_or(u64::MAX).into(),
                );
                object.insert("event".into(), name.into());
                for (key, value) in fields {
                    object.insert((*key).into(), value.clone().into());
                }
                serde_json::Value::Object(object).to_string()
            }
        }
    }

    pub(super) fn slow(
        &self,
        started: Instant,
        user: &str,
        session: u64,
        sql: &str,
        status: &str,
    ) -> bool {
        let elapsed = started.elapsed();
        if self.slow_query.is_none_or(|threshold| elapsed < threshold) {
            return false;
        }
        self.event(
            "slow_query",
            &[
                ("duration_ms", elapsed.as_millis().to_string()),
                ("user", user.to_string()),
                ("session", session.to_string()),
                ("statement_type", statement_type(sql).to_string()),
                ("sql", safe_sql(sql)),
                ("status", status.to_string()),
            ],
        );
        true
    }
}

fn statement_type(sql: &str) -> &str {
    sql.split_whitespace().next().unwrap_or("UNKNOWN")
}

/// Bounded, single-line SQL with literal contents removed. This keeps useful
/// statement shape without placing passwords or application values in logs.
fn safe_sql(sql: &str) -> String {
    let mut output = String::with_capacity(sql.len().min(512));
    let mut quoted = false;
    let mut previous_space = false;
    for ch in sql.chars() {
        if output.len() >= 512 {
            output.push('…');
            break;
        }
        if ch == '\'' {
            if !quoted {
                output.push('?');
            }
            quoted = !quoted;
            continue;
        }
        if quoted {
            continue;
        }
        if ch.is_whitespace() {
            if !previous_space {
                output.push(' ');
            }
            previous_space = true;
        } else {
            output.push(ch);
            previous_space = false;
        }
    }
    output.trim().to_string()
}

type Job = Box<dyn FnOnce() + Send + 'static>;

pub(super) struct WorkerPool {
    sender: Option<mpsc::SyncSender<Job>>,
    workers: Vec<thread::JoinHandle<()>>,
}

impl WorkerPool {
    pub(super) fn new(size: usize, queue: usize) -> Result<Self, PhobosError> {
        let (sender, receiver) = mpsc::sync_channel::<Job>(queue);
        let receiver = Arc::new(Mutex::new(receiver));
        let mut workers = Vec::with_capacity(size);
        for index in 0..size {
            let receiver = receiver.clone();
            workers.push(
                thread::Builder::new()
                    .name(format!("phobos-worker-{index}"))
                    .spawn(move || {
                        loop {
                            let job = receiver.lock().ok().and_then(|queue| queue.recv().ok());
                            match job {
                                Some(job) => job(),
                                None => break,
                            }
                        }
                    })?,
            );
        }
        Ok(Self {
            sender: Some(sender),
            workers,
        })
    }

    pub(super) fn submit(&self, job: impl FnOnce() + Send + 'static) -> Result<(), ()> {
        self.sender
            .as_ref()
            .ok_or(())?
            .try_send(Box::new(job))
            .map_err(|_| ())
    }
}

impl Drop for WorkerPool {
    fn drop(&mut self) {
        drop(self.sender.take());
        for worker in self.workers.drain(..) {
            let _ = worker.join();
        }
    }
}

#[derive(Default)]
pub(super) struct RoleConnections {
    limits: BTreeMap<String, u64>,
    active: Mutex<BTreeMap<String, u64>>,
}

impl RoleConnections {
    pub(super) fn new(limits: BTreeMap<String, u64>) -> Arc<Self> {
        Arc::new(Self {
            limits,
            active: Mutex::default(),
        })
    }

    pub(super) fn acquire(self: &Arc<Self>, role: Role) -> Result<RoleSlot, PhobosError> {
        let name = role.as_str().to_string();
        let mut active = self.active.lock().map_err(|_| {
            PhobosError::new(ErrorCode::ResourceLimit, "role connection counts poisoned")
        })?;
        let current = active.entry(name.clone()).or_default();
        if self
            .limits
            .get(&name)
            .is_some_and(|limit| *current >= *limit)
        {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                format!("connection limit reached for role {name}"),
            ));
        }
        *current += 1;
        Ok(RoleSlot {
            tracker: self.clone(),
            role: name,
        })
    }

    #[cfg(test)]
    fn count(&self, role: &str) -> u64 {
        self.active
            .lock()
            .ok()
            .and_then(|counts| counts.get(role).copied())
            .unwrap_or(0)
    }
}

pub(super) struct RoleSlot {
    tracker: Arc<RoleConnections>,
    role: String,
}
impl Drop for RoleSlot {
    fn drop(&mut self) {
        if let Ok(mut active) = self.tracker.active.lock() {
            if let Some(count) = active.get_mut(&self.role) {
                *count = count.saturating_sub(1);
            }
        }
    }
}

// Pre-existing layout; flagged only by newer Clippy (1.95). One command per
// request, moved once through the session channel.
#[allow(clippy::large_enum_variant)]
pub(super) enum SessionCommand {
    Prepare {
        name: String,
        sql: String,
        statement: Statement,
    },
    Execute(String),
    Deallocate(String),
}

pub(super) fn session_command(sql: &str) -> Result<Option<SessionCommand>, PhobosError> {
    let trimmed = sql.trim().trim_end_matches(';').trim();
    let Some((keyword, rest)) = split_word(trimmed) else {
        return Ok(None);
    };
    if keyword.eq_ignore_ascii_case("PREPARE") {
        let (name, rest) = split_word(rest).ok_or_else(|| syntax("PREPARE requires a name"))?;
        validate_name(name)?;
        let (as_keyword, inner) = split_word(rest).ok_or_else(|| syntax("PREPARE requires AS"))?;
        if !as_keyword.eq_ignore_ascii_case("AS") || inner.trim().is_empty() {
            return Err(syntax("PREPARE requires AS and a statement"));
        }
        let statement = phobos_sql::parse(inner.trim())?;
        if !read_only(&statement) {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "prepared statements currently support parameterless read-only SQL",
            ));
        }
        if contains_parameter(&statement) {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "prepared statement parameters are not supported yet",
            ));
        }
        Ok(Some(SessionCommand::Prepare {
            name: name.to_ascii_lowercase(),
            sql: inner.trim().to_string(),
            statement,
        }))
    } else if keyword.eq_ignore_ascii_case("EXECUTE") {
        let name = single_name(rest, "EXECUTE")?;
        Ok(Some(SessionCommand::Execute(name)))
    } else if keyword.eq_ignore_ascii_case("DEALLOCATE") {
        let name = single_name(rest, "DEALLOCATE")?;
        Ok(Some(SessionCommand::Deallocate(name)))
    } else {
        Ok(None)
    }
}

fn split_word(input: &str) -> Option<(&str, &str)> {
    let end = input.find(char::is_whitespace).unwrap_or(input.len());
    (end != 0).then(|| (&input[..end], input[end..].trim_start()))
}
fn single_name(rest: &str, command: &str) -> Result<String, PhobosError> {
    let (name, tail) =
        split_word(rest).ok_or_else(|| syntax(format!("{command} requires a name")))?;
    validate_name(name)?;
    if !tail.is_empty() {
        return Err(syntax(format!("unexpected input after {command} name")));
    }
    Ok(name.to_ascii_lowercase())
}
fn validate_name(name: &str) -> Result<(), PhobosError> {
    if name.is_empty()
        || name.len() > 63
        || !name.starts_with(|c: char| c.is_ascii_alphabetic() || c == '_')
        || !name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_')
    {
        return Err(syntax("invalid prepared statement name"));
    }
    Ok(())
}
fn syntax(message: impl Into<String>) -> PhobosError {
    PhobosError::new(ErrorCode::SqlSyntax, message)
}
fn read_only(statement: &Statement) -> bool {
    match statement {
        Statement::ShowCatalog { .. }
        | Statement::Select { .. }
        | Statement::RelationalSelect(_) => true,
        Statement::Explain { statement, .. } => read_only(statement),
        _ => false,
    }
}
fn contains_parameter(statement: &Statement) -> bool {
    format!("{statement:?}").contains("Parameter(")
}

#[derive(Clone)]
pub(super) struct Prepared {
    pub(super) sql: String,
    pub(super) statement: Statement,
    pub(super) schema_generation: u64,
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    #[test]
    fn json_log_is_valid_bounded_and_redacts_literals() {
        let log = OperatorLog::new(LogFormat::Json, 1);
        let line = log.render(
            "slow_query",
            &[("sql", safe_sql("SELECT * FROM t WHERE secret='do-not-log'"))],
        );
        let value: serde_json::Value = serde_json::from_str(&line).unwrap();
        assert_eq!(value["event"], "slow_query");
        assert!(!line.contains("do-not-log"));
        assert!(safe_sql(&"x".repeat(700)).len() <= 515);
    }

    #[test]
    fn slow_threshold_and_fast_path() {
        let disabled = OperatorLog::new(LogFormat::Text, 0);
        assert!(!disabled.slow(
            Instant::now() - Duration::from_secs(2),
            "u",
            1,
            "SELECT 1",
            "success"
        ));
        let enabled = OperatorLog::new(LogFormat::Text, 1);
        assert!(enabled.slow(
            Instant::now() - Duration::from_millis(2),
            "u",
            1,
            "SELECT 1",
            "success"
        ));
        assert!(!enabled.slow(Instant::now(), "u", 1, "SELECT 1", "success"));
    }

    #[test]
    fn worker_pool_is_bounded_and_progresses() {
        let pool = WorkerPool::new(2, 8).unwrap();
        let active = Arc::new(AtomicU64::new(0));
        let peak = Arc::new(AtomicU64::new(0));
        let done = Arc::new(AtomicU64::new(0));
        for _ in 0..8 {
            let (active, peak, done) = (active.clone(), peak.clone(), done.clone());
            pool.submit(move || {
                let current = active.fetch_add(1, Ordering::SeqCst) + 1;
                peak.fetch_max(current, Ordering::SeqCst);
                thread::sleep(Duration::from_millis(2));
                active.fetch_sub(1, Ordering::SeqCst);
                done.fetch_add(1, Ordering::SeqCst);
            })
            .unwrap();
        }
        drop(pool);
        assert_eq!(done.load(Ordering::SeqCst), 8);
        assert!(peak.load(Ordering::SeqCst) <= 2);
    }

    #[test]
    fn role_limit_releases_and_other_role_is_independent() {
        let limits = RoleConnections::new(BTreeMap::from([("reader".into(), 1)]));
        let first = limits.acquire(Role::Reader).unwrap();
        assert!(limits.acquire(Role::Reader).is_err());
        let admin = limits.acquire(Role::Admin).unwrap();
        assert_eq!(limits.count("admin"), 1);
        drop(first);
        assert!(limits.acquire(Role::Reader).is_ok());
        drop(admin);
    }

    #[test]
    fn prepared_command_shapes_and_read_only_limit() {
        assert!(matches!(
            session_command("PREPARE p AS SELECT * FROM t").unwrap(),
            Some(SessionCommand::Prepare { .. })
        ));
        assert!(
            matches!(session_command("EXECUTE p;").unwrap(), Some(SessionCommand::Execute(name)) if name == "p")
        );
        assert!(
            matches!(session_command("DEALLOCATE p").unwrap(), Some(SessionCommand::Deallocate(name)) if name == "p")
        );
        assert!(session_command("PREPARE p AS INSERT INTO t VALUES (1)").is_err());
    }
}
