#![forbid(unsafe_code)]

use phobos_server::{RuntimeConfig, ServerSettings, serve_with_shutdown_file};
use std::{env, path::PathBuf, process, time::Duration};

fn main() {
    if env::args().nth(1).as_deref() == Some("--version") {
        println!(
            "PHOBOS Server {} Community Edition",
            env!("CARGO_PKG_VERSION")
        );
        return;
    }

    let mut settings = ServerSettings::alpha_default("127.0.0.1:54321", PathBuf::from("./data"));
    let mut shutdown_file = None;
    let mut config_path = None;
    let mut max_connections = None;
    let mut max_result_bytes = None;
    let mut lock_wait = None;
    let mut args = env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--config" => {
                if config_path.is_some() {
                    usage();
                }
                config_path = Some(PathBuf::from(args.next().unwrap_or_else(|| usage())));
            }
            "--shutdown-file" => {
                shutdown_file = Some(PathBuf::from(args.next().unwrap_or_else(|| usage())))
            }
            "--bind" => settings.bind = args.next().unwrap_or_else(|| usage()),
            "--wal-mode" => {
                let value = args.next().unwrap_or_else(|| usage());
                let Some(mode) = phobos_wal::v2::DurabilityMode::parse(&value) else {
                    eprintln!("invalid WAL mode: {value} (expected flush or write-through)");
                    process::exit(2);
                };
                phobos_wal::v2::DurabilityMode::set_process_default(mode);
            }
            "--data-dir" => {
                settings.data_dir = PathBuf::from(args.next().unwrap_or_else(|| usage()))
            }
            "--auth-file" => {
                settings.auth_file = Some(PathBuf::from(args.next().unwrap_or_else(|| usage())))
            }
            "--tls-cert" => {
                settings.tls_cert = Some(PathBuf::from(args.next().unwrap_or_else(|| usage())))
            }
            "--tls-key" => {
                settings.tls_key = Some(PathBuf::from(args.next().unwrap_or_else(|| usage())))
            }
            "--max-connections" => {
                max_connections = Some(parse_u64(
                    args.next().unwrap_or_else(|| usage()),
                    "max connections",
                ))
            }
            "--max-result-bytes" => {
                max_result_bytes = Some(parse_usize(
                    args.next().unwrap_or_else(|| usage()),
                    "max result bytes",
                ))
            }
            "--lock-wait-ms" => {
                lock_wait = Some(Duration::from_millis(parse_u64(
                    args.next().unwrap_or_else(|| usage()),
                    "lock wait",
                )))
            }
            "--help" | "-h" => {
                print_help();
                return;
            }
            _ => usage(),
        }
    }
    let config = RuntimeConfig::load(config_path.as_deref()).unwrap_or_else(|error| {
        eprintln!("server failed: {error}");
        process::exit(1);
    });
    settings.apply_config(config);
    // Retain the existing flags; explicit command-line values win regardless of order.
    if let Some(value) = max_connections {
        settings.max_connections = value;
    }
    if let Some(value) = max_result_bytes {
        settings.max_result_bytes = value;
    }
    if let Some(value) = lock_wait {
        settings.lock_wait = value;
    }
    let effective = settings.effective_config().unwrap_or_else(|error| {
        eprintln!("server failed: {error}");
        process::exit(1);
    });
    eprintln!("{}", effective.banner());
    if let Ok(value) = env::var("PHOBOS_WAL_MODE") {
        if phobos_wal::v2::DurabilityMode::parse(&value).is_none() {
            eprintln!(
                "server failed: invalid PHOBOS_WAL_MODE={value} (expected flush or write-through)"
            );
            process::exit(2);
        }
    }
    eprintln!(
        "PHOBOS WAL durability: {}",
        phobos_wal::v2::DurabilityMode::configured().name()
    );
    // Public startup never silently upgrades an older catalog. The admin copy command
    // performs integrity, backup, transactional migration and post-migration checks.
    let catalog_path = settings.data_dir.join("catalog.phc");
    let catalog = std::fs::read(&catalog_path).unwrap_or_else(|error| {
        eprintln!(
            "Cannot read catalog {}: {error}. Initialize with phobos-admin init first.",
            catalog_path.display()
        );
        process::exit(1)
    });
    if catalog.len() < 6 || u16::from_le_bytes([catalog[4], catalog[5]]) != 5 {
        eprintln!(
            "PHOBOS 1.0 requires catalog format 5. Preserve the original and run phobos-admin upgrade-community-copy SOURCE_DATA BACKUP NEW_DATA [--accept-v4] before starting this version."
        );
        process::exit(1);
    }
    if let Err(error) = serve_with_shutdown_file(settings, shutdown_file) {
        eprintln!("server failed: {error}");
        process::exit(1);
    }
    eprintln!("PHOBOS clean shutdown completed");
    #[cfg(feature = "profiling")]
    if let Ok(path) = env::var("PHOBOS_PROFILE_OUT") {
        match phobos_observability::write_profile(std::path::Path::new(&path)) {
            Ok(()) => eprintln!("PHOBOS profile written to {path}"),
            Err(error) => eprintln!("PHOBOS profile not written: {error}"),
        }
    }
}

fn parse_u64(value: String, label: &str) -> u64 {
    value.parse().unwrap_or_else(|_| {
        eprintln!("invalid {label}: {value}");
        usage()
    })
}

fn parse_usize(value: String, label: &str) -> usize {
    value.parse().unwrap_or_else(|_| {
        eprintln!("invalid {label}: {value}");
        usage()
    })
}

fn usage() -> ! {
    print_help();
    process::exit(2)
}

fn print_help() {
    println!(
        "phobos-server [--config PATH] [--shutdown-file PATH] [--bind HOST:PORT] [--data-dir PATH] [--auth-file PATH] [--tls-cert PEM --tls-key PEM] [--max-connections N] [--max-result-bytes N] [--lock-wait-ms N] [--wal-mode flush|write-through]"
    );
}
