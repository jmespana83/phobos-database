//! A bounded request reader observes EOF during execution waits. TLS has one
//! shared protocol state; neither socket reads nor writes retain its state guard.
//! A full pipelined request queue is rejected explicitly.
//!
//! 0.2-H: [`Direct`]: the connection's worker reads the next frame itself (no
//! reader thread, channel or second wake-up per request). A low-frequency
//! monitor thread keeps the old guarantee that a client disconnect cancels a
//! long-running statement. [`Pumped`] is the 0.2-G reader-thread transport.
//!
//! 0.2-I: which one a plain-TCP connection uses is decided once per server by
//! [`RequestPath::resolve`] (`PHOBOS_REQUEST_PATH=auto|direct|pumped`, unset =
//! auto: Pumped on Windows, Direct on Linux/other Unix). TLS is always Pumped.
use super::*;
use std::sync::mpsc::{self, Receiver};
use std::time::Instant;

pub(super) trait RequestStream: Write {
    fn request(&mut self) -> Result<Frame, PhobosError>;
    fn request_timeout(&mut self, _timeout: Duration) -> Result<Frame, PhobosError> {
        self.request()
    }
    fn closed(&self) -> bool {
        false
    }
    fn peer_certificate(&self) -> Option<Vec<u8>> {
        None
    }
}
#[cfg(test)]
pub(super) struct Borrowed<'a, S>(pub &'a mut S);
#[cfg(test)]
impl<S: Read + Write> RequestStream for Borrowed<'_, S> {
    fn request(&mut self) -> Result<Frame, PhobosError> {
        Frame::read_from(&mut *self.0)
    }
}
#[cfg(test)]
impl<S: Write> Write for Borrowed<'_, S> {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.0.write(bytes)
    }
    fn flush(&mut self) -> io::Result<()> {
        self.0.flush()
    }
}

pub(super) struct Pumped {
    writer: Box<dyn Write + Send>,
    shutdown: TcpStream,
    requests: Receiver<(Result<Frame, PhobosError>, Instant)>,
    reader: Option<thread::JoinHandle<()>>,
    closed: Arc<AtomicBool>,
    tls: Option<Arc<TlsState>>,
}
impl Pumped {
    pub fn new(
        writer: TcpStream,
        coordinator: Arc<Coordinator>,
        session: u64,
    ) -> Result<Self, PhobosError> {
        let reader = writer.try_clone()?;
        reader.set_read_timeout(Some(Duration::from_millis(100)))?;
        let shutdown = writer.try_clone()?;
        Self::start(
            reader,
            Box::new(writer),
            shutdown,
            coordinator,
            session,
            None,
        )
    }
    pub fn tls(
        socket: TcpStream,
        mut connection: ServerConnection,
        coordinator: Arc<Coordinator>,
        session: u64,
    ) -> Result<Self, PhobosError> {
        connection.set_buffer_limit(Some(64 * 1024));
        let shared = Arc::new(TlsState {
            connection: Mutex::new(connection),
            output: Mutex::new(socket.try_clone()?),
        });
        let reader = TlsReader {
            socket: socket.try_clone()?,
            shared: shared.clone(),
        };
        reader
            .socket
            .set_read_timeout(Some(Duration::from_millis(100)))?;
        Self::start(
            reader,
            Box::new(TlsWriter(shared.clone())),
            socket,
            coordinator,
            session,
            Some(shared),
        )
    }
    fn start(
        input: impl Read + Send + 'static,
        writer: Box<dyn Write + Send>,
        shutdown: TcpStream,
        coordinator: Arc<Coordinator>,
        session: u64,
        tls: Option<Arc<TlsState>>,
    ) -> Result<Self, PhobosError> {
        // On Windows, shutdown on a cloned socket need not wake a pending
        // recv in another thread. Bound recv waits, preserving partial frames.

        let socket = shutdown.try_clone()?;
        let (send, requests) = mpsc::sync_channel(1);
        let closed = Arc::new(AtomicBool::new(false));
        let reader_closed = closed.clone();
        let mut input = InterruptibleReader {
            input,
            closed: closed.clone(),
        };
        let reader = thread::Builder::new()
            .name("phobos-request-reader".into())
            .spawn(move || {
                loop {
                    let request = Frame::read_from(&mut input);
                    let terminal = request.is_err();
                    // Never block this control reader behind a paused execution.
                    // At most one complete pending frame is retained per connection.
                    if terminal || send.try_send((request, Instant::now())).is_err() {
                        reader_closed.store(true, Ordering::Release);
                        coordinator.cancel(session);
                        let _ = socket.shutdown(std::net::Shutdown::Both);
                        break;
                    }
                }
            })?;
        Ok(Self {
            writer,
            shutdown,
            requests,
            reader: Some(reader),
            closed,
            tls,
        })
    }
}
impl RequestStream for Pumped {
    fn request(&mut self) -> Result<Frame, PhobosError> {
        self.request_timeout(DEFAULT_IDLE_TIMEOUT)
    }
    fn closed(&self) -> bool {
        self.closed.load(Ordering::Acquire)
    }
    fn peer_certificate(&self) -> Option<Vec<u8>> {
        let state = self.tls.as_ref()?;
        let connection = state.connection.lock().ok()?;
        connection
            .peer_certificates()?
            .first()
            .map(|certificate| certificate.as_ref().to_vec())
    }
    fn request_timeout(&mut self, timeout: Duration) -> Result<Frame, PhobosError> {
        let (request, complete) =
            self.requests
                .recv_timeout(timeout)
                .map_err(|error| match error {
                    mpsc::RecvTimeoutError::Timeout => PhobosError::new(
                        ErrorCode::IdleTimeout,
                        "idle connection deadline exceeded",
                    ),
                    mpsc::RecvTimeoutError::Disconnected => {
                        PhobosError::new(ErrorCode::Io, "request transport closed")
                    }
                })?;
        if self.closed() {
            return Err(PhobosError::new(ErrorCode::Io, "request transport closed"));
        }
        // 0.2-H: frame complete on the reader thread -> dequeued by the worker.
        let handoff = complete.elapsed().as_nanos() as u64;
        phobos_observability::event("request.pumped", 1);
        phobos_observability::event("request.handoff_ns", handoff);
        phobos_observability::trace_request_start(handoff);
        request
    }
}
impl Write for Pumped {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.writer.write(bytes)
    }
    fn flush(&mut self) -> io::Result<()> {
        self.writer.flush()
    }
}
impl Drop for Pumped {
    fn drop(&mut self) {
        self.closed.store(true, Ordering::Release);
        let _ = self.shutdown.shutdown(std::net::Shutdown::Both);

        if let Some(reader) = self.reader.take() {
            let _ = reader.join();
        }
    }
}

struct TlsState {
    connection: Mutex<ServerConnection>,
    output: Mutex<TcpStream>,
}
impl TlsState {
    // Ciphertext order is reserved before touching rustls, and retained until
    // those owned bytes are written. The rustls guard is dropped before I/O.
    fn update<T>(
        &self,
        operation: impl FnOnce(&mut ServerConnection) -> io::Result<T>,
    ) -> io::Result<T> {
        let mut output = self
            .output
            .lock()
            .map_err(|_| io::Error::other("TLS output poisoned"))?;
        let (value, ciphertext) = {
            let mut connection = self
                .connection
                .lock()
                .map_err(|_| io::Error::other("TLS state poisoned"))?;
            let value = operation(&mut connection)?;
            let mut ciphertext = Vec::new();
            while connection.wants_write() {
                connection.write_tls(&mut ciphertext)?;
            }
            (value, ciphertext)
        };
        output.write_all(&ciphertext)?;
        Ok(value)
    }
}
struct TlsWriter(Arc<TlsState>);
impl Write for TlsWriter {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.0.update(|connection| connection.writer().write(bytes))
    }
    fn flush(&mut self) -> io::Result<()> {
        self.0.update(|_| Ok(()))
    }
}
struct TlsReader {
    socket: TcpStream,
    shared: Arc<TlsState>,
}
impl Read for TlsReader {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        loop {
            let plaintext = self
                .shared
                .connection
                .lock()
                .map_err(|_| io::Error::other("TLS state poisoned"))?
                .reader()
                .read(bytes);
            match plaintext {
                Err(error) if error.kind() == io::ErrorKind::WouldBlock => {}
                result => return result,
            }
            // Only this reader consumes socket bytes. Feed rustls from an owned
            // bounded buffer; processing packets never blocks on socket input.
            let mut ciphertext = [0; 16 * 1024];
            let count = self.socket.read(&mut ciphertext)?;
            self.shared.update(|connection| {
                let mut input = &ciphertext[..count];
                if count == 0 {
                    connection.read_tls(&mut input)?;
                }
                while !input.is_empty() {
                    if connection.read_tls(&mut input)? == 0 {
                        return Err(io::Error::other("TLS input made no progress"));
                    }
                    connection.process_new_packets().map_err(io::Error::other)?;
                }
                Ok(())
            })?;
        }
    }
}

// Retrying here, below Frame::read_from/read_exact, keeps the framing offset
// intact across OS timeouts, including TLS records and partial headers/payloads.
struct InterruptibleReader<R> {
    input: R,
    closed: Arc<AtomicBool>,
}
impl<R: Read> Read for InterruptibleReader<R> {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        loop {
            if self.closed.load(Ordering::Acquire) {
                return Err(io::Error::new(
                    io::ErrorKind::ConnectionAborted,
                    "request reader closed",
                ));
            }
            match self.input.read(bytes) {
                Err(error)
                    if matches!(
                        error.kind(),
                        io::ErrorKind::TimedOut | io::ErrorKind::WouldBlock
                    ) =>
                {
                    continue;
                }
                result => return result,
            }
        }
    }
}

/// 0.2-H direct request transport for plain TCP connections.
///
/// The worker that owns the connection reads frames itself through a 16 KiB
/// buffer (one `recv` normally carries the header and the payload). Reads use
/// the socket's 100 ms receive timeout so a closed flag, server shutdown and
/// the idle deadline are observed exactly as with [`Pumped`]; a partial frame
/// survives timeouts. Responses are written by the same thread, as before.
///
/// Disconnect while executing: the monitor thread wakes every 100 ms and, only
/// when a statement has been executing for at least 100 ms, peeks the socket
/// (never consuming bytes). EOF or a socket error cancels the session exactly
/// like the pump reader did. Short statements complete and the failed response
/// write ends the connection (the client never saw an acknowledgement).
pub(super) struct Direct {
    input: TcpStream,
    writer: TcpStream,
    shutdown: TcpStream,
    buffer: Box<[u8]>,
    start: usize,
    end: usize,
    shared: Arc<DirectShared>,
    monitor: Option<thread::JoinHandle<()>>,
    coordinator: Arc<Coordinator>,
    session: u64,
    first: bool,
}
struct DirectShared {
    closed: AtomicBool,
    stop: AtomicBool,
    /// Milliseconds since [`epoch`] when the current request started
    /// executing; 0 while the worker waits for the next request.
    executing_since: AtomicU64,
}
const DIRECT_BUFFER: usize = 16 * 1024;
const MONITOR_TICK: Duration = Duration::from_millis(100);
fn epoch() -> Instant {
    static EPOCH: std::sync::OnceLock<Instant> = std::sync::OnceLock::new();
    *EPOCH.get_or_init(Instant::now)
}
fn now_ms() -> u64 {
    epoch().elapsed().as_millis() as u64 + 1
}
/// 0.2-I: request transport policy (`PHOBOS_REQUEST_PATH`), resolved once at
/// server start-up into one concrete [`ResolvedPath`] that every connection
/// of that server uses. Absent variable = [`RequestPath::Auto`].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RequestPath {
    /// Platform default: Pumped on Windows, Direct on Linux and other Unix.
    Auto,
    /// The 0.2-H worker-reads transport ([`Direct`]) where supported.
    Direct,
    /// The 0.2-G reader-thread transport ([`Pumped`]).
    Pumped,
}
/// The concrete transport a plain-TCP connection uses.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ResolvedPath {
    Direct,
    Pumped,
}
/// Platform class for [`RequestPath::resolve`] (a parameter so the policy is
/// unit-testable for every platform on any build host).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Platform {
    Windows,
    Linux,
    OtherUnix,
}
impl Platform {
    pub fn current() -> Self {
        if cfg!(windows) {
            Platform::Windows
        } else if cfg!(target_os = "linux") {
            Platform::Linux
        } else {
            Platform::OtherUnix
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            Platform::Windows => "windows",
            Platform::Linux => "linux",
            Platform::OtherUnix => "unix",
        }
    }
}
pub const REQUEST_PATH_ENV: &str = "PHOBOS_REQUEST_PATH";
impl RequestPath {
    /// `None` (variable absent) is `Auto`. Accepted values, ignoring ASCII
    /// case and surrounding whitespace: `auto`, `direct`, `pumped`. Anything
    /// else (including an empty value) is a configuration error.
    pub fn parse(value: Option<&str>) -> Result<Self, PhobosError> {
        let Some(raw) = value else {
            return Ok(RequestPath::Auto);
        };
        match raw.trim().to_ascii_lowercase().as_str() {
            "auto" => Ok(RequestPath::Auto),
            "direct" => Ok(RequestPath::Direct),
            "pumped" => Ok(RequestPath::Pumped),
            // Same code and prefix as phobos-config's configuration errors
            // (no new error code: the error code set is part of the protocol).
            _ => Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                format!(
                    "configuration: invalid {REQUEST_PATH_ENV}={raw:?}: expected auto, \
                     direct or pumped (unset = auto)"
                ),
            )),
        }
    }
    /// Reads `PHOBOS_REQUEST_PATH` (once, at server start-up).
    pub fn from_env() -> Result<Self, PhobosError> {
        match std::env::var(REQUEST_PATH_ENV) {
            Ok(value) => Self::parse(Some(&value)),
            Err(std::env::VarError::NotPresent) => Self::parse(None),
            Err(std::env::VarError::NotUnicode(value)) => Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                format!("configuration: invalid {REQUEST_PATH_ENV}={value:?}: not valid Unicode"),
            )),
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            RequestPath::Auto => "auto",
            RequestPath::Direct => "direct",
            RequestPath::Pumped => "pumped",
        }
    }
    /// The single place where the transport is chosen. TLS always uses
    /// Pumped (one rustls state shared by reader and writer; Direct reads the
    /// raw socket and cannot see rustls' buffered plaintext).
    pub fn resolve(self, platform: Platform, tls: bool) -> ResolvedPath {
        if tls {
            return ResolvedPath::Pumped;
        }
        match self {
            RequestPath::Direct => ResolvedPath::Direct,
            RequestPath::Pumped => ResolvedPath::Pumped,
            // Windows: the long-proven reader-thread transport (0.2-G OLTP8/16
            // behaviour); Linux and other Unix: Direct (0.2-H measurements).
            RequestPath::Auto => match platform {
                Platform::Windows => ResolvedPath::Pumped,
                Platform::Linux | Platform::OtherUnix => ResolvedPath::Direct,
            },
        }
    }
}
impl ResolvedPath {
    pub fn name(self) -> &'static str {
        match self {
            ResolvedPath::Direct => "direct",
            ResolvedPath::Pumped => "pumped",
        }
    }
}
impl Direct {
    pub fn new(
        writer: TcpStream,
        coordinator: Arc<Coordinator>,
        session: u64,
    ) -> Result<Self, PhobosError> {
        let input = writer.try_clone()?;
        input.set_read_timeout(Some(MONITOR_TICK))?;
        let shutdown = writer.try_clone()?;
        let probe = writer.try_clone()?;
        let shared = Arc::new(DirectShared {
            closed: AtomicBool::new(false),
            stop: AtomicBool::new(false),
            executing_since: AtomicU64::new(0),
        });
        let monitor_shared = shared.clone();
        let monitor_coordinator = coordinator.clone();
        let monitor = thread::Builder::new()
            .name("phobos-request-monitor".into())
            .spawn(move || {
                let mut byte = [0u8; 1];
                while !monitor_shared.stop.load(Ordering::Acquire) {
                    thread::park_timeout(MONITOR_TICK);
                    if monitor_shared.stop.load(Ordering::Acquire) {
                        break;
                    }
                    let since = monitor_shared.executing_since.load(Ordering::Acquire);
                    if since == 0
                        || now_ms().saturating_sub(since) < MONITOR_TICK.as_millis() as u64
                    {
                        continue;
                    }
                    // A long-running statement: watch for EOF without consuming
                    // pipelined bytes (blocks at most one receive timeout).
                    match probe.peek(&mut byte) {
                        Ok(0) => {}
                        Ok(_) => continue,
                        Err(error)
                            if matches!(
                                error.kind(),
                                io::ErrorKind::TimedOut | io::ErrorKind::WouldBlock
                            ) =>
                        {
                            continue;
                        }
                        Err(_) => {}
                    }
                    monitor_shared.closed.store(true, Ordering::Release);
                    phobos_observability::event("request.monitor_disconnects", 1);
                    monitor_coordinator.cancel(session);
                    let _ = probe.shutdown(std::net::Shutdown::Both);
                    break;
                }
            })?;
        Ok(Self {
            input,
            writer,
            shutdown,
            buffer: vec![0; DIRECT_BUFFER].into_boxed_slice(),
            start: 0,
            end: 0,
            shared,
            monitor: Some(monitor),
            coordinator,
            session,
            first: true,
        })
    }
    /// A connection accepted while every worker was busy may have been
    /// abandoned (request sent, then closed) before its worker started. As
    /// with the reader thread, which saw that EOF first, such a request is not
    /// executed. Checked once per connection, for its first request, with a
    /// non-blocking peek (no cost on later requests).
    fn abandoned_before_start(&mut self) -> bool {
        if self.end > self.start || self.input.set_nonblocking(true).is_err() {
            return false;
        }
        let mut byte = [0u8; 1];
        let eof = matches!(self.input.peek(&mut byte), Ok(0));
        let _ = self.input.set_nonblocking(false);
        eof
    }
    /// Ensures `need` buffered bytes (`need <= DIRECT_BUFFER`). `idle` is the
    /// deadline for the complete frame (as with the reader thread, where the
    /// worker's wait for a complete frame timed out even if part of it had
    /// arrived); bytes already buffered are kept across receive timeouts.
    fn fill(&mut self, need: usize, idle: Option<Instant>) -> Result<(), PhobosError> {
        while self.end - self.start < need {
            if self.start > 0 {
                self.buffer.copy_within(self.start..self.end, 0);
                self.end -= self.start;
                self.start = 0;
            }
            if self.shared.closed.load(Ordering::Acquire) {
                return Err(PhobosError::new(ErrorCode::Io, "request transport closed"));
            }
            match self.input.read(&mut self.buffer[self.end..]) {
                Ok(0) => return Err(PhobosError::new(ErrorCode::Io, "request transport closed")),
                Ok(count) => self.end += count,
                Err(error)
                    if matches!(
                        error.kind(),
                        io::ErrorKind::TimedOut
                            | io::ErrorKind::WouldBlock
                            | io::ErrorKind::Interrupted
                    ) =>
                {
                    if idle.is_some_and(|deadline| Instant::now() >= deadline) {
                        return Err(PhobosError::new(
                            ErrorCode::IdleTimeout,
                            "idle connection deadline exceeded",
                        ));
                    }
                }
                Err(error) => return Err(error.into()),
            }
        }
        Ok(())
    }
    fn read_frame(&mut self, timeout: Duration) -> Result<Frame, PhobosError> {
        let idle = Instant::now().checked_add(timeout);
        self.fill(phobos_protocol::HEADER_LEN, idle)?;
        let header = &self.buffer[self.start..self.start + phobos_protocol::HEADER_LEN];
        let len = u32::from_be_bytes([header[12], header[13], header[14], header[15]]) as usize;
        // Frame::read_from validates magic, version, type and the payload
        // limit before allocating; it reads from the buffered bytes and,
        // for payloads larger than the buffer, from the socket directly.
        let header_valid = header[0..4] == phobos_protocol::MAGIC
            && header[4] == phobos_protocol::VERSION
            && MessageType::try_from(header[5]).is_ok();
        if !header_valid {
            // Same error as the reader thread produced, without waiting for
            // a payload that a malformed header may never be followed by.
            let mut bytes = &self.buffer[self.start..self.start + phobos_protocol::HEADER_LEN];
            return Frame::read_from(&mut bytes);
        }
        if len + phobos_protocol::HEADER_LEN <= DIRECT_BUFFER {
            self.fill(phobos_protocol::HEADER_LEN + len, idle)?;
            let mut bytes = &self.buffer[self.start..self.end];
            let before = bytes.len();
            let frame = Frame::read_from(&mut bytes);
            self.start += before - bytes.len();
            return frame;
        }
        let mut reader = DirectFrameReader {
            direct: self,
            idle,
            expired: false,
        };
        let frame = Frame::read_from(&mut reader);
        if reader.expired {
            return Err(PhobosError::new(
                ErrorCode::IdleTimeout,
                "idle connection deadline exceeded",
            ));
        }
        frame
    }
}
/// Buffered-then-socket reader for a frame larger than the buffer; timeouts
/// retry (preserving the partial frame) until the connection closes.
struct DirectFrameReader<'a> {
    direct: &'a mut Direct,
    idle: Option<Instant>,
    expired: bool,
}
impl Read for DirectFrameReader<'_> {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        let direct = &mut *self.direct;
        if direct.end > direct.start {
            let count = bytes.len().min(direct.end - direct.start);
            bytes[..count].copy_from_slice(&direct.buffer[direct.start..direct.start + count]);
            direct.start += count;
            return Ok(count);
        }
        loop {
            if direct.shared.closed.load(Ordering::Acquire) {
                return Err(io::Error::new(
                    io::ErrorKind::ConnectionAborted,
                    "request reader closed",
                ));
            }
            match direct.input.read(bytes) {
                Err(error)
                    if matches!(
                        error.kind(),
                        io::ErrorKind::TimedOut
                            | io::ErrorKind::WouldBlock
                            | io::ErrorKind::Interrupted
                    ) =>
                {
                    if self.idle.is_some_and(|deadline| Instant::now() >= deadline) {
                        self.expired = true;
                        return Err(io::Error::new(io::ErrorKind::TimedOut, "idle deadline"));
                    }
                }
                result => return result,
            }
        }
    }
}
impl RequestStream for Direct {
    fn request(&mut self) -> Result<Frame, PhobosError> {
        self.request_timeout(DEFAULT_IDLE_TIMEOUT)
    }
    fn closed(&self) -> bool {
        self.shared.closed.load(Ordering::Acquire)
    }
    fn request_timeout(&mut self, timeout: Duration) -> Result<Frame, PhobosError> {
        self.shared.executing_since.store(0, Ordering::Release);
        let mut frame = self.read_frame(timeout);
        if frame.is_ok() && std::mem::take(&mut self.first) && self.abandoned_before_start() {
            frame = Err(PhobosError::new(ErrorCode::Io, "request transport closed"));
        }
        if let Err(error) = &frame {
            if error.code != ErrorCode::IdleTimeout {
                // As the reader thread did on EOF, a parse error or a socket
                // failure: cancel the session's open work and close.
                self.shared.closed.store(true, Ordering::Release);
                self.coordinator.cancel(self.session);
                let _ = self.shutdown.shutdown(std::net::Shutdown::Both);
            }
        }
        let frame = frame?;
        self.shared
            .executing_since
            .store(now_ms(), Ordering::Release);
        phobos_observability::event("request.direct", 1);
        phobos_observability::trace_request_start(0);
        Ok(frame)
    }
}
impl Write for Direct {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.writer.write(bytes)
    }
    fn flush(&mut self) -> io::Result<()> {
        self.writer.flush()
    }
}
impl Drop for Direct {
    fn drop(&mut self) {
        self.shared.closed.store(true, Ordering::Release);
        self.shared.stop.store(true, Ordering::Release);
        let _ = self.shutdown.shutdown(std::net::Shutdown::Both);
        if let Some(monitor) = self.monitor.take() {
            monitor.thread().unpark();
            let _ = monitor.join();
        }
    }
}
