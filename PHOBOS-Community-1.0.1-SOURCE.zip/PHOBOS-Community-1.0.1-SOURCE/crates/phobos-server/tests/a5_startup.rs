use std::{
    fs,
    process::Command,
    time::{SystemTime, UNIX_EPOCH},
};

#[test]
fn a5_cli_config_failure_and_effective_banner() {
    let root = std::env::temp_dir().join(format!(
        "phobos-a5-cli-{}-{}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    fs::create_dir_all(&root).unwrap();
    let config = root.join("config.json");
    let data = root.join("data");
    let stop = root.join("stop");
    for text in ["{", r#"{"query_memory_bytes":0}"#, r#"{"unknown":1}"#] {
        fs::write(&config, text).unwrap();
        let output = Command::new(env!("CARGO_BIN_EXE_phobos-server"))
            .arg("--config")
            .arg(&config)
            .arg("--data-dir")
            .arg(&data)
            .output()
            .unwrap();
        assert!(!output.status.success());
        assert!(String::from_utf8_lossy(&output.stderr).contains("configuration:"));
        assert!(
            !data.exists(),
            "invalid configuration must precede database startup"
        );
    }
    let legacy = root.join("legacy");
    drop(phobos_execution::Database::open(&legacy).unwrap());
    phobos_admin::migrate_mvcc_copy(&legacy, &root.join("backup"), &data).unwrap();
    let before = fs::read(data.join("catalog.phc")).unwrap();
    let rejected = Command::new(env!("CARGO_BIN_EXE_phobos-server"))
        .arg("--data-dir")
        .arg(&data)
        .output()
        .unwrap();
    assert!(!rejected.status.success());
    assert!(String::from_utf8_lossy(&rejected.stderr).contains("requires catalog format 5"));
    assert_eq!(before, fs::read(data.join("catalog.phc")).unwrap());
    {
        let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&data).unwrap();
        let session = db.connect(1).unwrap();
        db.upgrade_catalog_format(&session).unwrap();
    }
    fs::write(
        &config,
        r#"{"max_connections":9,"query_memory_bytes":31,"idle_timeout_ms":4567}"#,
    )
    .unwrap();
    fs::write(&stop, "stop").unwrap();
    let output = Command::new(env!("CARGO_BIN_EXE_phobos-server"))
        .args([
            "--max-connections",
            "7",
            "--bind",
            "127.0.0.1:0",
            "--config",
        ])
        .arg(&config)
        .arg("--data-dir")
        .arg(&data)
        .arg("--shutdown-file")
        .arg(&stop)
        .output()
        .unwrap();
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{stderr}");
    assert!(stderr.contains("PHOBOS effective settings"));
    assert!(stderr.contains("\"max_connections\": 7"));
    assert!(stderr.contains("\"query_memory_bytes\": 31"));
    assert!(stderr.contains("\"idle_timeout_ms\": 4567"));
    assert!(stderr.contains("PHOBOS clean shutdown completed"));
    fs::remove_dir_all(root).unwrap();
}
