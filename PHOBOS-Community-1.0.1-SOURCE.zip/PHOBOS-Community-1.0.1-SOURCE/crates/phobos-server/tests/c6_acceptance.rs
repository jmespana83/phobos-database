//! Additional C6 acceptance through the public ordinary SQL coordinator.
use phobos_server::Coordinator;
use std::{
    fs,
    path::PathBuf,
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicU64, Ordering},
        mpsc,
    },
    thread,
    time::Duration,
};

fn database() -> (PathBuf, PathBuf, Arc<Coordinator>) {
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let root = std::env::temp_dir().join(format!(
        "phobos-c6-final-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    let legacy = root.join("legacy");
    let mut db = phobos_execution::Database::open(&legacy).unwrap();
    db.execute("CREATE TABLE t (id BIGINT, v BIGINT, g BIGINT)")
        .unwrap();
    db.execute("CREATE UNIQUE INDEX pk ON t(id)").unwrap();
    db.execute("CREATE UNIQUE INDEX uk ON t(v,g)").unwrap();
    db.execute("INSERT INTO t VALUES (1,1,NULL),(2,2,NULL),(3,3,NULL)")
        .unwrap();
    drop(db);
    let dir = root.join("mvcc");
    phobos_admin::migrate_mvcc_copy(&legacy, &root.join("backup"), &dir).unwrap();
    let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
    (root, dir, coordinator)
}

#[test]
fn unique_update_wait_rechecks_owner_commit_and_abort_while_independent_key_progresses() {
    for commit in [false, true] {
        let (root, dir, db) = database();
        let older = db.new_session();
        let younger = db.new_session();
        let independent = db.new_session();
        db.execute(older, "BEGIN").unwrap();
        db.execute(younger, "BEGIN").unwrap();
        // D1: identities (conflict age) are taken by the first write, not by
        // BEGIN, so the older session writes first.
        db.execute(older, "INSERT INTO t VALUES (100,100,NULL)")
            .unwrap();
        db.execute(younger, "UPDATE t SET v=42,g=0 WHERE id=2")
            .unwrap();
        let (signal, waiting) = mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |point| {
                if point == "c5_unique_wait" {
                    let _ = signal.send(());
                }
            }),
        );
        let writer = db.clone();
        let worker =
            thread::spawn(move || writer.execute(older, "UPDATE t SET v=42,g=0 WHERE id=1"));
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        db.execute(independent, "UPDATE t SET v=43,g=0 WHERE id=3")
            .unwrap();
        assert_eq!(
            db.execute(independent, "SELECT id FROM t WHERE v=43 AND g=0")
                .unwrap(),
            "id\n3\n"
        );
        db.execute(younger, if commit { "COMMIT" } else { "ROLLBACK" })
            .unwrap();
        let result = worker.join().unwrap();
        assert_eq!(result.is_err(), commit, "{result:?}");
        db.execute(older, if commit { "ROLLBACK" } else { "COMMIT" })
            .unwrap();
        assert_eq!(
            db.execute(independent, "SELECT id FROM t WHERE v=42 AND g=0")
                .unwrap(),
            if commit { "id\n2\n" } else { "id\n1\n" }
        );
        assert!(
            db.conflict_diagnostics()
                .unwrap()
                .unwrap()
                .active
                .is_empty()
        );
        drop(hook);
        for id in [older, younger, independent] {
            db.disconnect(id);
        }
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn indexed_update_and_insert_splits_preserve_paused_range_snapshot_and_point_visibility() {
    let (root, dir, db) = database();
    let setup = db.new_session();
    db.execute(setup, "CREATE TABLE s (k TEXT, n BIGINT)")
        .unwrap();
    db.execute(setup, "CREATE UNIQUE INDEX sk ON s(k)").unwrap();
    let key = |prefix: &str, n: usize| format!("{prefix}-{n:04}-{}", "x".repeat(1600));
    for n in 0..2 {
        db.execute(
            setup,
            &format!("INSERT INTO s VALUES ('{}',{n})", key("old", n)),
        )
        .unwrap();
    }
    let (started, waiting) = mpsc::channel();
    let (resume, resumed) = mpsc::channel();
    let resumed = Mutex::new(resumed);
    let first = AtomicBool::new(true);
    let hook = phobos_observability::test_hooks::register(
        &dir,
        Arc::new(move |point| {
            if point == "c6_index_batch_read" && first.swap(false, Ordering::AcqRel) {
                started.send(()).unwrap();
                resumed
                    .lock()
                    .unwrap()
                    .recv_timeout(Duration::from_secs(30))
                    .unwrap();
            }
        }),
    );
    let reader = db.new_session();
    let reading = db.clone();
    let worker = thread::spawn(move || {
        reading.execute(reader, "SELECT n FROM s WHERE k>='old-' ORDER BY n")
    });
    waiting.recv_timeout(Duration::from_secs(10)).unwrap();
    db.execute(setup, "BEGIN").unwrap();
    for n in 0..2 {
        db.execute(
            setup,
            &format!(
                "UPDATE s SET k='{}' WHERE k='{}'",
                key("new", n),
                key("old", n)
            ),
        )
        .unwrap();
    }
    let values = (2..90)
        .map(|n| format!("('{}',{n})", key("new", n)))
        .collect::<Vec<_>>()
        .join(",");
    db.execute(setup, &format!("INSERT INTO s VALUES {values}"))
        .unwrap();
    db.execute(setup, "COMMIT").unwrap();
    resume.send(()).unwrap();
    assert_eq!(worker.join().unwrap().unwrap(), "n\n0\n1\n");
    drop(hook);
    for n in 0..90 {
        assert_eq!(
            db.execute(
                setup,
                &format!("SELECT n FROM s WHERE k='{}'", key("new", n))
            )
            .unwrap(),
            format!("n\n{n}\n")
        );
    }
    assert_eq!(
        db.execute(setup, "SELECT COUNT(*) AS n FROM s WHERE k>='old-'")
            .unwrap(),
        "n\n0\n"
    );
    // Historic unique entries survive, but their now-invisible old versions
    // cannot reject reuse of a key after the pinned reader releases its snapshot.
    db.execute(
        setup,
        &format!("INSERT INTO s VALUES ('{}',90)", key("old", 0)),
    )
    .unwrap();
    for id in [setup, reader] {
        db.disconnect(id);
    }
    db.shutdown().unwrap();
    drop(db);
    phobos_admin::check_integrity(&dir).unwrap();
    for _ in 0..2 {
        let db = Coordinator::open(&dir).unwrap();
        let reader = db.new_session();
        assert_eq!(
            db.execute(reader, "SELECT COUNT(*) AS n FROM s").unwrap(),
            "n\n91\n"
        );
        assert_eq!(
            db.execute(
                reader,
                &format!("SELECT n FROM s WHERE k='{}'", key("old", 0))
            )
            .unwrap(),
            "n\n90\n"
        );
        db.disconnect(reader);
        db.shutdown().unwrap();
        drop(db);
        phobos_admin::check_integrity(&dir).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}
