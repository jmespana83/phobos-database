//! C7 measurements: identical rows/indexes, explicitly different commit granularity.
use super::*;

pub(super) fn run(o: &Options) -> Result<()> {
    if ![100_000, 1_000_000].contains(&o.rows) {
        return Err("C7 permits 100K/1M only".into());
    }
    fs::create_dir(&o.dir)?;
    let source = o.dir.join("source");
    let dir = o.dir.join("database");
    let mut legacy = Database::open(&source)?;
    legacy.execute(SCHEMA)?;
    legacy.execute("CREATE UNIQUE INDEX bench_id ON bench(id)")?;
    legacy.execute("CREATE INDEX bench_bucket ON bench(bucket,id)")?;
    drop(legacy);
    phobos_admin::migrate_mvcc_copy(&source, &o.dir.join("backup"), &dir)?;
    let db = Coordinator::open(&dir)?;
    let session = db.new_session();
    phobos_observability::write_profile(&o.output.with_extension("before.csv"))?;
    let before_wal = phobos_wal::total_written_bytes();
    let started = Instant::now();
    let commits = if matches!(o.mode.as_str(), "c7-bulk" | "c8-bulk") {
        let inserted = db.bulk_load(
            session,
            "bench",
            (0..o.rows).map(|id| {
                Ok(Row::new(vec![
                    Value::Int64(id as i64),
                    Value::Int64((id % 100) as i64),
                    Value::Text(payload(id)),
                ]))
            }),
        )?;
        if inserted != o.rows as u64 {
            return Err("bulk count mismatch".into());
        }
        1
    } else {
        // Ordinary SQL's 64 MiB transaction overlay cannot hold this entire import.
        // Use its existing bounded multi-row autocommit path; never relax its bound.
        for start in (0..o.rows).step_by(256) {
            db.execute(session, &insert("bench", start, (o.rows - start).min(256)))?;
        }
        o.rows.div_ceil(256)
    };
    let elapsed = started.elapsed();
    let wal_bytes = phobos_wal::total_written_bytes() - before_wal;
    phobos_observability::write_profile(&o.output.with_extension("after.csv"))?;
    let mut csv = BufWriter::new(File::create_new(&o.output)?);
    writeln!(
        csv,
        "path,rows,commits,elapsed_ns,rows_per_second,wal_bytes,profiled"
    )?;
    writeln!(
        csv,
        "{},{},{},{},{:.3},{},{}",
        o.mode,
        o.rows,
        commits,
        elapsed.as_nanos(),
        o.rows as f64 / elapsed.as_secs_f64(),
        wal_bytes,
        cfg!(feature = "profiling")
    )?;
    csv.flush()?;
    eprintln!(
        "{}: {} rows in {:.3}s",
        o.mode,
        o.rows,
        elapsed.as_secs_f64()
    );
    if db.execute(session, "SELECT COUNT(*) AS n FROM bench")? != format!("n\n{}\n", o.rows) {
        return Err("committed count mismatch".into());
    }
    db.disconnect(session);
    db.shutdown()?;
    drop(db);
    for _ in 0..if o.mode == "c8-bulk" { 1 } else { 2 } {
        if o.mode != "c8-bulk" {
            phobos_admin::check_integrity(&dir)?;
        }
        let db = Coordinator::open(&dir)?;
        let session = db.new_session();
        if db.execute(session, "SELECT COUNT(*) AS n FROM bench")? != format!("n\n{}\n", o.rows) {
            return Err("reopened count mismatch".into());
        }
        if db.execute(session, "SELECT id FROM bench WHERE id=42")? != "id\n42\n" {
            return Err("reopened index mismatch".into());
        }
        db.disconnect(session);
        db.shutdown()?;
    }
    phobos_admin::check_integrity(&dir)?;
    fs::write(
        o.output.with_extension("verified.txt"),
        if o.mode == "c8-bulk" {
            "reopen heap count/index lookup and offline index integrity passed\n"
        } else {
            "two reopens; heap count and indexed point verified; three offline integrity checks passed\n"
        },
    )?;
    Ok(())
}
