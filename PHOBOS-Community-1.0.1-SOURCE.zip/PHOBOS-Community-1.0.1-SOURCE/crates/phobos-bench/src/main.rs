#![forbid(unsafe_code)]
//! Deterministic synchronous-durability benchmarks. See benchmarks/workloads/README.md.
use phobos_error::PhobosError;
use phobos_execution::{Database, QueryResult, ResultSink};
use phobos_server::Coordinator;
use phobos_storage::RowCodec;
use phobos_types::{ColumnSchema, DataType, Row, TableSchema, Value};
use std::{
    error::Error,
    fs::{self, File},
    hint::black_box,
    io::{BufWriter, Write},
    path::{Path, PathBuf},
    process::{Command, ExitCode},
    sync::{Arc, Barrier},
    thread,
    time::{Duration, Instant},
};

mod c5_acceptance;
mod c7_bulk;

type Result<T> = std::result::Result<T, Box<dyn Error + Send + Sync>>;
const SEED: u64 = 8067;
const SCHEMA: &str =
    "CREATE TABLE bench (id BIGINT NOT NULL, bucket BIGINT NOT NULL, payload TEXT NOT NULL)";

#[derive(Debug)]
struct Options {
    mode: String,
    dir: PathBuf,
    output: PathBuf,
    rows: usize,
    samples: usize,
    operations: usize,
    connections: usize,
}

impl Options {
    fn parse() -> Result<Self> {
        let mut o = Self {
            mode: "suite".into(),
            dir: "benchmark-data".into(),
            output: "benchmark.csv".into(),
            rows: 2000,
            samples: 3,
            operations: 10,
            connections: 4,
        };
        let mut args = std::env::args().skip(1);
        while let Some(arg) = args.next() {
            let value = args.next().ok_or("every option requires a value")?;
            match arg.as_str() {
                "--mode" => o.mode = value,
                "--dir" => o.dir = value.into(),
                "--output" => o.output = value.into(),
                "--rows" => o.rows = value.parse()?,
                "--samples" => o.samples = value.parse()?,
                "--operations" => o.operations = value.parse()?,
                "--connections" => o.connections = value.parse()?,
                _ => return Err(format!("unknown option: {arg}").into()),
            }
        }
        if o.rows < 100
            || o.rows > 100_000_000
            || o.samples == 0
            || o.operations == 0
            || o.connections == 0
            || o.connections > 64
        {
            return Err(
                "rows must be 100..100M; samples/operations positive; connections 1..64".into(),
            );
        }
        Ok(o)
    }
}

struct Results(BufWriter<File>, usize);
impl Results {
    fn new(path: &Path, rows: usize) -> Result<Self> {
        let file = File::create_new(path)?;
        let mut out = Self(BufWriter::new(file), rows);
        writeln!(
            out.0,
            "engine,workload,cache,rows,seed,sample,operations,elapsed_ns,units,bytes,parent_wal_bytes_cumulative"
        )?;
        out.0.flush()?;
        Ok(out)
    }
    fn record(
        &mut self,
        workload: &str,
        cache: &str,
        sample: usize,
        operations: usize,
        elapsed: Duration,
        volume: (usize, u64),
    ) -> Result<()> {
        let (units, bytes) = volume;
        let ns = elapsed.as_nanos();
        let engine = if cfg!(feature = "profiling") {
            "phobos-embedded-profiled"
        } else {
            "phobos-embedded"
        };
        writeln!(
            self.0,
            "{engine},{workload},{cache},{},{SEED},{sample},{operations},{ns},{units},{bytes},{}",
            self.1,
            phobos_wal::total_written_bytes()
        )?;
        self.0.flush()?;
        eprintln!(
            "{workload} sample={sample}: {:.3} ms",
            ns as f64 / 1_000_000.0
        );
        Ok(())
    }
}

fn payload(id: usize) -> String {
    let v = (id as u64)
        .wrapping_mul(6364136223846793005)
        .wrapping_add(SEED);
    format!("p{v:016x}")
}
fn insert(table: &str, start: usize, count: usize) -> String {
    let mut sql = format!("INSERT INTO {table} VALUES ");
    for id in start..start + count {
        if id != start {
            sql.push(',');
        }
        write!(
            StringWriter(&mut sql),
            "({id},{},'{}')",
            id % 100,
            payload(id)
        )
        .expect("string write");
    }
    sql
}
// io::Write adapter avoids mixing the fmt::Write trait with file writers.
struct StringWriter<'a>(&'a mut String);
impl Write for StringWriter<'_> {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        self.0
            .push_str(std::str::from_utf8(bytes).expect("formatted UTF-8"));
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

fn count(result: &QueryResult) -> usize {
    match result {
        QueryResult::Rows { rows, .. } => rows.len(),
        QueryResult::Command { rows_affected, .. } => *rows_affected as usize,
    }
}
fn scalar(result: QueryResult) -> Result<i64> {
    if let QueryResult::Rows { rows, .. } = result {
        if rows.len() == 1 && rows[0].values.len() == 1 {
            if let Value::Int64(n) = rows[0].values[0] {
                return Ok(n);
            }
        }
    }
    Err("expected one integer result".into())
}

fn c3_fixture(o: &Options) -> Result<()> {
    let mut db = Database::open(&o.dir)?;
    db.execute(
        "CREATE TABLE c3_group (id BIGINT NOT NULL, g1 BIGINT NOT NULL, g10 BIGINT NOT NULL, g1000 BIGINT NOT NULL, g10000 BIGINT NOT NULL, g100000 BIGINT NOT NULL, gcomp BIGINT NOT NULL, gtext TEXT NOT NULL)",
    )?;
    db.execute("BEGIN")?;
    for start in (0..o.rows).step_by(1000) {
        let end = (start + 1000).min(o.rows);
        let values = (start..end)
            .map(|id| {
                format!(
                    "({id},0,{},{},{},{},{},'t{}')",
                    id % 10,
                    id % 1000,
                    id % 10000,
                    id % 100000,
                    (id / 1000) % 10,
                    id % 1000,
                )
            })
            .collect::<Vec<_>>()
            .join(",");
        db.execute(&format!("INSERT INTO c3_group VALUES {values}"))?;
    }
    db.execute("COMMIT")?;
    if scalar(db.execute("SELECT COUNT(*) FROM c3_group")?)? != o.rows as i64 {
        return Err("C3 fixture count mismatch".into());
    }
    Ok(())
}

fn c3_group(o: &Options) -> Result<()> {
    let column = match o.operations {
        1 => "g1",
        10 => "g10",
        1000 => "g1000",
        10000 => "g10000",
        100000 => "g100000",
        groups if groups == o.rows => "id",
        _ => return Err("unsupported C3 group cardinality".into()),
    };
    let sql = match o.connections {
        2 => "SELECT gtext AS g, COUNT(*) AS n FROM c3_group GROUP BY gtext HAVING n<0".into(),
        3 => "SELECT g1000 AS a, gcomp AS b, COUNT(*) AS n FROM c3_group GROUP BY g1000,gcomp HAVING n<0".into(),
        4 => "SELECT g1000 AS g, COUNT(*) AS n, SUM(id) AS s, AVG(id) AS a, MIN(id) AS lo, MAX(id) AS hi FROM c3_group GROUP BY g1000 HAVING n<0".into(),
        _ => format!(
            "SELECT {column} AS g, COUNT(*) AS n FROM c3_group GROUP BY {column} HAVING n<0"
        ),
    };
    let mut db = if o.connections == 5 {
        let config = phobos_config::RuntimeConfig {
            query_memory_bytes: 2 * 1024 * 1024,
            ..phobos_config::RuntimeConfig::default()
        };
        Database::open_with_config(&o.dir, &config)?
    } else {
        Database::open(&o.dir)?
    };
    if count(&db.execute(&sql)?) != 0 {
        return Err("C3 warm-up result mismatch".into());
    }
    let mut out = Results::new(&o.output, o.rows)?;
    for sample in 0..o.samples {
        let start = Instant::now();
        if count(&db.execute(&sql)?) != 0 {
            return Err("C3 result mismatch".into());
        }
        out.record(
            &format!("group_{}", o.operations),
            "warm",
            sample,
            1,
            start.elapsed(),
            (o.operations, 0),
        )?;
    }
    phobos_observability::write_profile(&o.output.with_extension("profile.csv"))?;
    Ok(())
}
fn check_count(db: &mut Database, expected: usize) -> Result<()> {
    if scalar(db.execute("SELECT COUNT(*) AS n FROM bench")?)? != expected as i64 {
        return Err("row-count correctness check failed".into());
    }
    Ok(())
}
fn copy_database(source: &Path, destination: &Path) -> Result<()> {
    fs::create_dir(destination)?;
    for e in fs::read_dir(source)? {
        let e = e?;
        if e.file_type()?.is_file() {
            let target = destination.join(e.file_name());
            fs::copy(e.path(), &target)?;
            // Fixture creation is outside workload timing. Do not make the
            // first admitted writer persist the entire copied database while
            // other clients consume their ordinary admission deadline.
            fs::OpenOptions::new()
                .write(true)
                .open(target)?
                .sync_all()?;
        }
    }
    #[cfg(unix)]
    File::open(destination)?.sync_all()?;
    Ok(())
}
fn bytes(dir: &Path) -> Result<u64> {
    let mut total = 0;
    for e in fs::read_dir(dir)? {
        let e = e?;
        if e.file_type()?.is_file() {
            total += e.metadata()?.len();
        }
    }
    Ok(total)
}

fn load(o: &Options, out: &mut Results) -> Result<PathBuf> {
    let base = o.dir.join("base");
    fs::create_dir(&base)?;
    let mut db = Database::open(&base)?;
    db.execute(SCHEMA)?;
    db.execute("CREATE UNIQUE INDEX bench_id ON bench (id)")?;
    // Generation excluded; one durable transaction containing 1000-row SQL statements.
    let statements: Vec<_> = (0..o.rows)
        .step_by(1000)
        .map(|start| insert("bench", start, (o.rows - start).min(1000)))
        .collect();
    let start = Instant::now();
    if o.mode == "bulk" {
        phobos_observability::write_profile(&o.output.with_extension("setup.csv"))?;
    }
    db.execute("BEGIN")?;
    if o.mode == "bulk" {
        phobos_observability::write_profile(&o.output.with_extension("begun.csv"))?;
    }
    for (batch, sql) in statements.iter().enumerate() {
        db.execute(sql)?;
        if (batch + 1) % 100 == 0 {
            eprintln!(
                "bulk_load staged_rows={} elapsed_seconds={:.3}; transaction not yet committed",
                ((batch + 1) * 1000).min(o.rows),
                start.elapsed().as_secs_f64()
            );
        }
    }
    if o.mode == "bulk" {
        phobos_observability::write_profile(&o.output.with_extension("staged.csv"))?;
    }
    db.execute("COMMIT")?;
    out.record(
        "bulk_load",
        "uncontrolled",
        0,
        statements.len(),
        start.elapsed(),
        (o.rows, bytes(&base)?),
    )?;
    if o.mode == "bulk" {
        phobos_observability::write_profile(&o.output.with_extension("committed.csv"))?;
    }
    check_count(&mut db, o.rows)?;
    db.execute("CREATE TABLE dimension (id BIGINT NOT NULL, bucket BIGINT NOT NULL, payload TEXT NOT NULL)")?;
    db.execute(&insert("dimension", 0, 100))?;
    drop(db);
    Ok(base)
}

fn reads(o: &Options, out: &mut Results, base: &Path) -> Result<()> {
    let mut db = Database::open(base)?;
    let queries = [
        (
            "indexed_point",
            format!("SELECT * FROM bench WHERE id={}", o.rows / 2),
            1,
        ),
        (
            "indexed_range",
            "SELECT * FROM bench WHERE id>=10 AND id<30".into(),
            20,
        ),
        ("full_scan", "SELECT * FROM bench".into(), o.rows),
        (
            "scan_aggregate",
            "SELECT COUNT(*) AS n FROM bench".into(),
            1,
        ),
        (
            "join",
            "SELECT bench.id AS id FROM bench INNER JOIN dimension ON bench.bucket=dimension.id"
                .into(),
            o.rows,
        ),
        (
            "group_aggregate",
            "SELECT bucket AS bucket, COUNT(*) AS n FROM bench GROUP BY bucket".into(),
            100,
        ),
        (
            "sort_spill",
            "SELECT id AS id, payload AS payload FROM bench ORDER BY payload DESC".into(),
            o.rows,
        ),
    ];
    for (name, sql, expected) in queries {
        let warmup = db.execute(&sql)?;
        if count(&warmup) != expected {
            return Err(format!("{name}: wrong row count").into());
        }
        if name.starts_with("indexed_")
            && !db
                .last_access_path()
                .is_some_and(|p| p.starts_with("INDEX"))
        {
            return Err(format!("{name}: index was not used").into());
        }
        drop(warmup);
        for sample in 0..o.samples {
            let start = Instant::now();
            let result = db.execute(&sql)?;

            // Record prior to validation/serialization; retain result through timing.
            out.record(name, "warm", sample, 1, start.elapsed(), (expected, 0))?;

            if count(&result) != expected {
                return Err(format!("{name}: wrong row count").into());
            }
            if name == "scan_aggregate" && scalar(result)? != o.rows as i64 {
                return Err("aggregate mismatch".into());
            }
        }
    }
    Ok(())
}

fn mutations(o: &Options, out: &mut Results, base: &Path) -> Result<()> {
    for name in [
        "autocommit_insert",
        "transaction_insert",
        "update",
        "delete",
    ] {
        for sample in 0..o.samples {
            let dir = o.dir.join(format!("{name}-{sample}"));
            copy_database(base, &dir)?;
            let mut db = Database::open(&dir)?;
            let statements: Vec<_> = (0..o.operations)
                .map(|i| match name {
                    "update" => format!("UPDATE bench SET payload='updated' WHERE id={i}"),
                    "delete" => format!("DELETE FROM bench WHERE id={i}"),
                    _ => insert("bench", o.rows + i, 1),
                })
                .collect();
            if o.operations > o.rows {
                return Err("operations must not exceed rows".into());
            }
            let start = Instant::now();
            if name == "transaction_insert" {
                db.execute("BEGIN")?;
            }
            for sql in &statements {
                if count(&db.execute(sql)?) != 1 {
                    return Err("mutation did not affect exactly one row".into());
                }
            }
            if name == "transaction_insert" {
                db.execute("COMMIT")?;
            }
            out.record(
                name,
                "warm_setup",
                sample,
                o.operations,
                start.elapsed(),
                (o.operations, 0),
            )?;
            let expected = match name {
                "delete" => o.rows - o.operations,
                "update" => o.rows,
                _ => o.rows + o.operations,
            };
            check_count(&mut db, expected)?;
            drop(db);
            let mut db = Database::open(&dir)?;
            check_count(&mut db, expected)?;
            drop(db);
            fs::remove_dir_all(dir)?;
        }
    }
    Ok(())
}

fn concurrency(o: &Options, out: &mut Results, base: &Path) -> Result<()> {
    for name in ["concurrent_readers", "concurrent_writers", "mixed"] {
        for sample in 0..o.samples {
            let dir = o.dir.join(format!("{name}-{sample}"));
            copy_database(base, &dir)?;
            let coordinator = Arc::new(Coordinator::open(&dir)?);
            let barrier = Arc::new(Barrier::new(o.connections + 1));
            let mut workers = Vec::new();
            for worker in 0..o.connections {
                let coordinator = Arc::clone(&coordinator);
                let barrier = Arc::clone(&barrier);
                let statements: Vec<_> = (0..o.operations)
                    .map(|i| {
                        if name == "concurrent_readers" || (name == "mixed" && worker % 2 == 0) {
                            format!(
                                "SELECT id FROM bench WHERE id={}",
                                (i * 7919 + worker) % o.rows
                            )
                        } else {
                            insert("bench", o.rows + worker * o.operations + i, 1)
                        }
                    })
                    .collect();
                workers.push(thread::spawn(move || -> Result<()> {
                    let session = coordinator.new_session();
                    barrier.wait();
                    for sql in statements {
                        black_box(coordinator.execute(session, &sql)?);
                    }
                    coordinator.disconnect(session);
                    Ok(())
                }));
            }
            let start = Instant::now();
            barrier.wait();
            for worker in workers {
                worker.join().map_err(|_| "benchmark worker panicked")??;
            }
            out.record(
                name,
                "warm_setup",
                sample,
                o.connections * o.operations,
                start.elapsed(),
                (o.connections, 0),
            )?;
            drop(coordinator);
            let mut db = Database::open(&dir)?;
            let writers = match name {
                "concurrent_readers" => 0,
                "mixed" => o.connections / 2,
                _ => o.connections,
            };
            check_count(&mut db, o.rows + writers * o.operations)?;
            drop(db);
            fs::remove_dir_all(dir)?;
        }
    }
    Ok(())
}

fn restart(o: &Options, out: &mut Results, base: &Path) -> Result<()> {
    for sample in 0..o.samples {
        let start = Instant::now();
        let mut db = Database::open(base)?;
        out.record(
            "startup",
            "os_cache_uncontrolled",
            sample,
            1,
            start.elapsed(),
            (o.rows, 0),
        )?;
        check_count(&mut db, o.rows)?;
        drop(db);
        let dir = o.dir.join(format!("recovery-{sample}"));
        copy_database(base, &dir)?;
        let status = Command::new(std::env::current_exe()?)
            .args(["--mode", "crash-child", "--dir"])
            .arg(&dir)
            .arg("--rows")
            .arg(o.rows.to_string())
            .env("PHOBOS_CRASH_POINT", "after_wal_commit")
            .status()?;
        if status.success() {
            return Err("crash injection did not abort".into());
        }
        let wal_bytes = fs::metadata(dir.join("phobos.wal"))?.len();
        if wal_bytes == 0 {
            return Err("crash left no WAL; child may have failed before commit".into());
        }
        let start = Instant::now();
        let mut db = Database::open(&dir)?;
        out.record(
            "crash_recovery",
            "os_cache_uncontrolled",
            sample,
            1,
            start.elapsed(),
            (o.rows, wal_bytes),
        )?;
        check_count(&mut db, o.rows + 1)?;
        let mut db2;
        drop(db);
        db2 = Database::open(&dir)?;
        check_count(&mut db2, o.rows + 1)?;
        drop(db2);
        fs::remove_dir_all(dir)?;
    }
    Ok(())
}

fn micro(o: &Options, out: &mut Results) -> Result<()> {
    let rows: Vec<_> = (0..o.rows)
        .map(|id| {
            Row::new(vec![
                Value::Int64(id as i64),
                Value::Int64((id % 100) as i64),
                Value::Text(payload(id)),
            ])
        })
        .collect();
    let schema = TableSchema {
        id: 1,
        name: "bench".into(),
        columns: vec![
            ColumnSchema {
                name: "id".into(),
                data_type: DataType::Int64,
                nullable: false,
            },
            ColumnSchema {
                name: "bucket".into(),
                data_type: DataType::Int64,
                nullable: false,
            },
            ColumnSchema {
                name: "payload".into(),
                data_type: DataType::Text,
                nullable: false,
            },
        ],
    };
    let result = QueryResult::Rows {
        columns: vec!["id".into(), "bucket".into(), "payload".into()],
        rows: rows.clone(),
    };
    let encoded: Vec<_> = rows
        .iter()
        .map(|row| RowCodec::encode(&schema, row))
        .collect::<std::result::Result<_, _>>()?;
    for sample in 0..o.samples {
        let start = Instant::now();
        for _ in 0..o.operations {
            black_box(result.to_text());
        }
        out.record(
            "micro_text_serialization",
            "warm",
            sample,
            o.operations,
            start.elapsed(),
            (o.rows * o.operations, 0),
        )?;
        let start = Instant::now();
        for row in &rows {
            black_box(RowCodec::encode(&schema, row)?);
        }
        out.record(
            "micro_row_encode",
            "warm",
            sample,
            o.rows,
            start.elapsed(),
            (o.rows, 0),
        )?;
        let start = Instant::now();
        for row in &encoded {
            black_box(RowCodec::decode(&schema, row)?);
        }
        out.record(
            "micro_row_decode",
            "warm",
            sample,
            o.rows,
            start.elapsed(),
            (o.rows, 0),
        )?;
        let sql = "SELECT id FROM bench WHERE id=123";
        let start = Instant::now();
        for _ in 0..o.rows {
            black_box(phobos_sql::parse(sql)?);
        }
        out.record(
            "micro_sql_parse",
            "warm",
            sample,
            o.rows,
            start.elapsed(),
            (o.rows, 0),
        )?;
    }
    Ok(())
}

// Each probe owns a fresh, forced clone. Snapshot exports bracket only the named
// phase; copying AND forcing the fixture, opening, and checks are excluded.
fn write_profile(o: &Options) -> Result<()> {
    if !cfg!(feature = "profiling") {
        return Err("write-profile requires --features profiling".into());
    }
    let root = o.output.with_extension("fixtures");
    fs::create_dir(&root)?;
    let mut out = Results::new(&o.output, o.rows)?;
    for sample in 0..o.samples {
        for kind in ["insert", "update", "delete", "autocommit_insert"] {
            let dir = root.join(format!("{kind}-{sample}"));
            copy_database(&o.dir, &dir)?;
            // Otherwise the first BEGIN sync would measure OS writeback from
            // copying the entire fixture, falsely making BEGIN scale with size.
            for entry in fs::read_dir(&dir)? {
                let entry = entry?;
                if entry.file_type()?.is_file() {
                    fs::OpenOptions::new()
                        .write(true)
                        .open(entry.path())?
                        .sync_all()?;
                }
            }
            let mut db = Database::open(&dir)?;
            check_count(&mut db, o.rows)?;
            let statements: Vec<_> = (0..o.operations)
                .map(|i| match kind {
                    "insert" | "autocommit_insert" => insert("bench", o.rows + i, 1),
                    "update" => {
                        format!("UPDATE bench SET payload='changed' WHERE id={}", i % o.rows)
                    }
                    _ => format!("DELETE FROM bench WHERE id={}", i % o.rows),
                })
                .collect();
            let phases: &[&str] = if kind == "autocommit_insert" {
                &["autocommit"]
            } else {
                &["begin", "stage", "commit"]
            };
            for &phase in phases {
                let prefix = format!("{kind}-{sample}-{phase}");
                phobos_observability::write_profile(
                    &o.output.with_extension(format!("{prefix}-before.csv")),
                )?;
                let start = Instant::now();
                match phase {
                    "begin" => {
                        db.execute("BEGIN")?;
                    }
                    "commit" => {
                        db.execute("COMMIT")?;
                    }
                    _ => {
                        for sql in &statements {
                            if count(&db.execute(sql)?) != 1 {
                                return Err("write-profile affected-row mismatch".into());
                            }
                        }
                    }
                }
                let elapsed = start.elapsed();
                phobos_observability::write_profile(
                    &o.output.with_extension(format!("{prefix}-after.csv")),
                )?;
                out.record(
                    &prefix,
                    "warm_setup",
                    sample,
                    if phase == "stage" || phase == "autocommit" {
                        o.operations
                    } else {
                        1
                    },
                    elapsed,
                    (0, 0),
                )?;
            }
            let expected = match kind {
                "insert" | "autocommit_insert" => o.rows + o.operations,
                "delete" => o.rows - o.operations,
                _ => o.rows,
            };
            check_count(&mut db, expected)?;
            drop(db);
            let mut reopened = Database::open(&dir)?;
            check_count(&mut reopened, expected)?;
            for i in 0..o.operations {
                let id = if kind.ends_with("insert") {
                    o.rows + i
                } else {
                    i
                };
                let result =
                    reopened.execute(&format!("SELECT payload FROM bench WHERE id={id}"))?;
                let QueryResult::Rows { rows, .. } = result else {
                    return Err("write-profile expected indexed rows".into());
                };
                if kind == "delete" {
                    if !rows.is_empty() {
                        return Err("deleted row survived reopen".into());
                    }
                } else {
                    let expected_value = if kind == "update" {
                        "changed".into()
                    } else {
                        payload(id)
                    };
                    if rows
                        != vec![Row {
                            values: vec![Value::Text(expected_value)],
                        }]
                    {
                        return Err("write-profile reopened value mismatch".into());
                    }
                }
            }
        }
    }
    Ok(())
}

fn commit_table(domains: bool, worker: usize) -> String {
    if domains {
        format!("bench_{worker}")
    } else {
        "bench".into()
    }
}
fn domain_rows(o: &Options, worker: usize) -> usize {
    o.rows / o.connections + usize::from(worker < o.rows % o.connections)
}
// Total cardinality stays at the requested 100K/1M, partitioned into independent
// tables. Setup is separate from timings; every engine copies the same fixture.
fn domain_fixture(o: &Options) -> Result<()> {
    if ![100_000, 1_000_000].contains(&o.rows) || ![1, 4, 8].contains(&o.connections) {
        return Err("domain fixture requires 100K/1M and 1/4/8 clients".into());
    }
    fs::create_dir(&o.dir)?;
    let mut db = Database::open(&o.dir)?;
    for worker in 0..o.connections {
        let table = commit_table(true, worker);
        db.execute(&SCHEMA.replacen("bench", &table, 1))?;
        db.execute(&format!("CREATE UNIQUE INDEX {table}_id ON {table} (id)"))?;
    }
    db.execute("BEGIN")?;
    for worker in 0..o.connections {
        let table = commit_table(true, worker);
        let rows = domain_rows(o, worker);
        for start in (0..rows).step_by(1000) {
            db.execute(&insert(&table, start, (rows - start).min(1000)))?;
        }
    }
    db.execute("COMMIT")?;
    db.execute("CHECKPOINT")?;
    for worker in 0..o.connections {
        if scalar(db.execute(&format!(
            "SELECT COUNT(*) FROM {}",
            commit_table(true, worker)
        ))?)?
            != domain_rows(o, worker) as i64
        {
            return Err("domain fixture count mismatch".into());
        }
    }
    let mut out = File::create_new(&o.output)?;
    writeln!(out, "rows,domains,seed,durability")?;
    writeln!(
        out,
        "{},{},{SEED},unchanged synchronous WAL",
        o.rows, o.connections
    )?;
    Ok(())
}

// Steady coordinator commits, separate from the fixed SQL comparison campaign.
// Setup, the first force of copied files, and post-run recovery are not timed.
fn commit_profile(o: &Options) -> Result<()> {
    let domains = o.mode == "commit-domains";
    let transactions = o
        .connections
        .checked_mul(o.operations)
        .filter(|count| *count <= 1_000_000)
        .ok_or("commit-profile requires at most one million measured transactions")?;
    let root = o.output.with_extension("fixtures");
    fs::create_dir(&root)?;
    let mut out = Results::new(&o.output, o.rows)?;
    let mut latencies = BufWriter::new(File::create_new(o.output.with_extension("latencies.csv"))?);
    writeln!(latencies, "sample,worker,operation,elapsed_ns")?;
    let mut flushes = BufWriter::new(File::create_new(o.output.with_extension("flush.csv"))?);
    writeln!(
        flushes,
        "sample,boundary,dirty_pages,peak_dirty_pages,pages_flushed,bytes_flushed,background_ns,eviction_pages,durable_wal_lsn,maximum_page_lsn,wal_retained_bytes"
    )?;
    for sample in 0..o.samples {
        let dir = root.join(format!("sample-{sample}"));
        copy_database(&o.dir, &dir)?;
        let coordinator = Arc::new(Coordinator::open(&dir)?);
        let session = coordinator.new_session();
        // This untimed commit establishes the steady WAL-protected page state.
        for worker in 0..if domains { o.connections } else { 1 } {
            let table = commit_table(domains, worker);
            if coordinator.execute(session, &insert(&table, o.rows + transactions, 1))?
                != "INSERT 1"
            {
                return Err("commit-profile warmup response mismatch".into());
            }
        }
        coordinator.disconnect(session);
        let barrier = Arc::new(Barrier::new(o.connections + 1));
        let mut workers = Vec::new();
        for worker in 0..o.connections {
            let coordinator = Arc::clone(&coordinator);
            let barrier = Arc::clone(&barrier);
            let table = commit_table(domains, worker);
            let statements: Vec<_> = (0..o.operations)
                .map(|i| insert(&table, o.rows + worker * o.operations + i, 1))
                .collect();
            workers.push(thread::spawn(move || -> Result<Vec<u128>> {
                let session = coordinator.new_session();
                let mut elapsed = Vec::with_capacity(statements.len());
                barrier.wait();
                for sql in statements {
                    let start = Instant::now();
                    let response = coordinator.execute(session, &sql)?;
                    elapsed.push(start.elapsed().as_nanos());
                    if response != "INSERT 1" {
                        return Err("commit-profile response mismatch".into());
                    }
                }
                coordinator.disconnect(session);
                Ok(elapsed)
            }));
        }
        write_flush_stats(
            &mut flushes,
            sample,
            "before",
            coordinator.flush_stats()?,
            fs::metadata(dir.join("phobos.wal"))?.len(),
        )?;
        phobos_observability::write_profile(
            &o.output
                .with_extension(format!("sample-{sample}-before.csv")),
        )?;
        let start = Instant::now();
        barrier.wait();
        let mut samples = Vec::new();
        for worker in workers {
            samples.push(
                worker
                    .join()
                    .map_err(|_| "commit-profile worker panicked")??,
            );
        }
        let elapsed = start.elapsed();
        phobos_observability::write_profile(
            &o.output
                .with_extension(format!("sample-{sample}-after.csv")),
        )?;
        write_flush_stats(
            &mut flushes,
            sample,
            "after",
            coordinator.flush_stats()?,
            fs::metadata(dir.join("phobos.wal"))?.len(),
        )?;
        out.record(
            "steady_commits",
            "warm_setup",
            sample,
            transactions,
            elapsed,
            (transactions, 0),
        )?;
        for (worker, values) in samples.into_iter().enumerate() {
            for (operation, elapsed) in values.into_iter().enumerate() {
                writeln!(latencies, "{sample},{worker},{operation},{elapsed}")?;
            }
        }
        latencies.flush()?;
        flushes.flush()?;
        coordinator.shutdown()?;
        drop(coordinator);
        for _ in 0..2 {
            let mut db = Database::open(&dir)?;
            for worker in 0..if domains { o.connections } else { 1 } {
                let table = commit_table(domains, worker);
                let expected = if domains {
                    domain_rows(o, worker) + o.operations + 1
                } else {
                    o.rows + transactions + 1
                };
                if scalar(db.execute(&format!("SELECT COUNT(*) FROM {table}"))?)? != expected as i64
                {
                    return Err("commit-profile row count mismatch".into());
                }
                let start = if domains {
                    o.rows + worker * o.operations
                } else {
                    o.rows
                };
                let end = if domains {
                    start + o.operations
                } else {
                    o.rows + transactions
                };
                for id in (start..end).chain(std::iter::once(o.rows + transactions)) {
                    let QueryResult::Rows { rows, .. } =
                        db.execute(&format!("SELECT payload FROM {table} WHERE id={id}"))?
                    else {
                        return Err("commit-profile expected indexed rows".into());
                    };
                    if rows != vec![Row::new(vec![Value::Text(payload(id))])] {
                        return Err("commit-profile lost or changed an acknowledged row".into());
                    }
                }
            }
        }
    }
    Ok(())
}

fn write_flush_stats(
    output: &mut impl Write,
    sample: usize,
    boundary: &str,
    stats: phobos_execution::FlushStats,
    wal_bytes: u64,
) -> Result<()> {
    if stats.maximum_page_lsn > stats.durable_wal_lsn {
        return Err("dirty page outran durable WAL".into());
    }
    writeln!(
        output,
        "{sample},{boundary},{},{},{},{},{},{},{},{},{wal_bytes}",
        stats.dirty_pages,
        stats.peak_dirty_pages,
        stats.pages_flushed,
        stats.bytes_flushed,
        stats.background_ns,
        stats.eviction_pages,
        stats.durable_wal_lsn,
        stats.maximum_page_lsn
    )?;
    Ok(())
}

fn indexed_loop_profile(o: &Options) -> Result<()> {
    let mut out = Results::new(&o.output, o.rows)?;
    let mut db = Database::open(&o.dir)?;
    check_count(&mut db, o.rows)?;
    for (name, sql, expected) in [
        (
            "indexed_point_loop",
            format!("SELECT * FROM bench WHERE id={}", o.rows / 2),
            1,
        ),
        (
            "indexed_range_loop",
            "SELECT * FROM bench WHERE id>=10 AND id<30".into(),
            20,
        ),
    ] {
        if count(&db.execute(&sql)?) != expected
            || !db
                .last_access_path()
                .is_some_and(|p| p.starts_with("INDEX"))
        {
            return Err("indexed loop warmup did not use the expected index/result".into());
        }
        for sample in 0..o.samples {
            let start = Instant::now();
            for _ in 0..o.operations {
                if count(&db.execute(&sql)?) != expected {
                    return Err("indexed loop result mismatch".into());
                }
            }
            // Repeated-query diagnostic includes validation and result disposal.
            // It is labelled separately from the original single-query suite.
            out.record(
                name,
                "warm_loop",
                sample,
                o.operations,
                start.elapsed(),
                (o.operations * expected, 0),
            )?;
        }
    }
    phobos_observability::write_profile(&o.output.with_extension("profile.csv"))?;
    Ok(())
}

#[derive(Default)]
struct P0Capture {
    rows: Vec<Row>,
}

impl ResultSink for P0Capture {
    fn start(&mut self, _columns: Vec<String>) -> std::result::Result<(), PhobosError> {
        Ok(())
    }

    fn row(&mut self, row: Row) -> std::result::Result<(), PhobosError> {
        self.rows.push(row);
        Ok(())
    }

    fn finish(&mut self) -> std::result::Result<(), PhobosError> {
        Ok(())
    }

    fn command(
        &mut self,
        _tag: String,
        _rows_affected: u64,
    ) -> std::result::Result<(), PhobosError> {
        Ok(())
    }
}

fn p0_prepare(o: &Options) -> Result<()> {
    let db = Coordinator::open(&o.dir)?;
    let session = db.new_session();
    db.execute(
        session,
        "CREATE TABLE qdim (bucket BIGINT NOT NULL, label TEXT NOT NULL)",
    )?;
    db.execute(session, "CREATE UNIQUE INDEX qdim_bucket ON qdim(bucket)")?;
    let mut sql = String::from("INSERT INTO qdim VALUES ");
    for bucket in 0..100 {
        if bucket != 0 {
            sql.push(',');
        }
        write!(StringWriter(&mut sql), "({bucket},'bucket-{bucket:02}')")?;
    }
    db.execute(session, &sql)?;
    db.execute(session, "CHECKPOINT")?;
    db.disconnect(session);
    db.shutdown()?;
    Ok(())
}

fn p0_profile(o: &Options) -> Result<()> {
    if o.rows != 1_000_000 {
        return Err("P0 profile requires the exact one-million-row fixture".into());
    }
    let db = Coordinator::open(&o.dir)?;
    let session = db.new_session();
    let mut out = BufWriter::new(File::create_new(&o.output)?);
    writeln!(out, "workload,sample,elapsed_ns,rows")?;
    let workloads = [
        (
            "full_scan_zero_match",
            "SELECT id FROM bench WHERE payload='__PHOBOS_BENCH_NEVER_MATCH__'",
        ),
        (
            "secondary_range_1pct",
            "SELECT id,payload FROM bench WHERE bucket=10 ORDER BY id",
        ),
        (
            "group_by_bucket",
            "SELECT bucket,COUNT(*) FROM bench GROUP BY bucket",
        ),
        (
            "equality_join_aggregate",
            "SELECT COUNT(*) FROM bench INNER JOIN qdim ON bench.bucket=qdim.bucket",
        ),
    ];
    for (name, sql) in workloads {
        let mut warm = P0Capture::default();
        db.execute_stream_result(session, sql, &mut warm)?;
        validate_p0_result(name, &warm.rows, o.rows)?;
        for sample in 0..o.samples {
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.before.csv")),
            )?;
            let mut capture = P0Capture::default();
            let started = Instant::now();
            db.execute_stream_result(session, sql, &mut capture)?;
            let elapsed = started.elapsed();
            validate_p0_result(name, &capture.rows, o.rows)?;
            writeln!(
                out,
                "{name},{sample},{},{}",
                elapsed.as_nanos(),
                capture.rows.len()
            )?;
            out.flush()?;
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.after.csv")),
            )?;
            eprintln!("P0 {name} sample={sample}: {:.3}s", elapsed.as_secs_f64());
        }
    }
    db.disconnect(session);
    db.shutdown()?;
    Ok(())
}

fn validate_p0_result(name: &str, rows: &[Row], total: usize) -> Result<()> {
    match name {
        "full_scan_zero_match" if rows.is_empty() => Ok(()),
        "secondary_range_1pct" if rows.len() == total / 100 => Ok(()),
        "group_by_bucket"
            if rows.len() == 100
                && rows.iter().all(|row| {
                    matches!(row.values.as_slice(), [Value::Int64(_), Value::Int64(n)] if *n == (total / 100) as i64)
                }) =>
        {
            Ok(())
        }
        "equality_join_aggregate"
            if rows == [Row::new(vec![Value::Int64(total as i64)])] =>
        {
            Ok(())
        }
        "projected_join_10k"
            if rows.len() == 10_000
                && rows.iter().all(|row| {
                    matches!(row.values.as_slice(), [Value::Int64(id), Value::Text(label)] if label == &format!("bucket-{:02}", id.rem_euclid(100)))
                }) =>
        {
            Ok(())
        }
        _ => Err(format!("P0 {name} result mismatch: {} rows", rows.len()).into()),
    }
}

const P1B_RANGE: &str = "SELECT id,payload FROM bench WHERE bucket=10 ORDER BY id";

fn p1b_profile(o: &Options) -> Result<()> {
    if o.rows != 1_000_000 {
        return Err("P1-B profile requires the exact one-million-row fixture".into());
    }
    let db = Coordinator::open(&o.dir)?;
    let session = db.new_session();
    let plan = db.execute(session, &format!("EXPLAIN {P1B_RANGE}"))?;
    fs::write(o.output.with_extension("plan.txt"), &plan)?;
    if !plan.contains("Index Scan using bench_bucket") {
        return Err(format!("P1-B profile requires bench_bucket index plan: {plan:?}").into());
    }
    let mut out = BufWriter::new(File::create_new(&o.output)?);
    writeln!(out, "workload,sample,elapsed_ns,rows")?;
    for (name, sql) in [
        ("secondary_range_1pct", P1B_RANGE),
        (
            "indexed_point",
            "SELECT id,payload FROM bench WHERE id=500000",
        ),
        (
            "full_scan_zero_match",
            "SELECT id FROM bench WHERE payload='__PHOBOS_BENCH_NEVER_MATCH__'",
        ),
    ] {
        let mut warm = P0Capture::default();
        db.execute_stream_result(session, sql, &mut warm)?;
        validate_p1b_result(name, &warm.rows, o.rows)?;
        for sample in 0..o.samples {
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.before.csv")),
            )?;
            let mut capture = P0Capture::default();
            let started = Instant::now();
            db.execute_stream_result(session, sql, &mut capture)?;
            let elapsed = started.elapsed();
            validate_p1b_result(name, &capture.rows, o.rows)?;
            writeln!(
                out,
                "{name},{sample},{},{}",
                elapsed.as_nanos(),
                capture.rows.len()
            )?;
            out.flush()?;
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.after.csv")),
            )?;
            eprintln!("P1-B {name} sample={sample}: {:.3}s", elapsed.as_secs_f64());
        }
    }
    db.disconnect(session);
    db.shutdown()?;
    Ok(())
}

fn validate_p1b_result(name: &str, rows: &[Row], total: usize) -> Result<()> {
    match name {
        "secondary_range_1pct"
            if rows.len() == total / 100
                && rows.iter().enumerate().all(|(offset, row)| {
                    let id = 10 + offset * 100;
                    row.values == [Value::Int64(id as i64), Value::Text(payload(id))]
                }) =>
        {
            Ok(())
        }
        "indexed_point"
            if rows
                == [Row::new(vec![
                    Value::Int64(500_000),
                    Value::Text(payload(500_000)),
                ])] =>
        {
            Ok(())
        }
        "full_scan_zero_match" if rows.is_empty() => Ok(()),
        _ => Err(format!("P1-B {name} result mismatch: {} rows", rows.len()).into()),
    }
}

fn p1c_profile(o: &Options) -> Result<()> {
    if o.rows != 1_000_000 {
        return Err("P1-C profile requires the exact one-million-row fixture".into());
    }
    let db = Coordinator::open(&o.dir)?;
    let session = db.new_session();
    let mut out = BufWriter::new(File::create_new(&o.output)?);
    writeln!(out, "workload,sample,elapsed_ns,rows")?;
    for (name, sql) in [
        (
            "full_scan_zero_match",
            "SELECT id FROM bench WHERE payload='__PHOBOS_BENCH_NEVER_MATCH__'",
        ),
        (
            "equality_join_aggregate",
            "SELECT COUNT(*) FROM bench INNER JOIN qdim ON bench.bucket=qdim.bucket",
        ),
        (
            "projected_join_10k",
            "SELECT bench.id,qdim.label FROM bench INNER JOIN qdim ON bench.bucket=qdim.bucket LIMIT 10000",
        ),
        (
            "group_by_bucket",
            "SELECT bucket,COUNT(*) FROM bench GROUP BY bucket",
        ),
        (
            "indexed_point",
            "SELECT id,payload FROM bench WHERE id=500000",
        ),
    ] {
        let mut warm = P0Capture::default();
        db.execute_stream_result(session, sql, &mut warm)?;
        if name == "indexed_point" {
            validate_p1b_result(name, &warm.rows, o.rows)?;
        } else {
            validate_p0_result(name, &warm.rows, o.rows)?;
        }
        for sample in 0..o.samples {
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.before.csv")),
            )?;
            let mut capture = P0Capture::default();
            let started = Instant::now();
            db.execute_stream_result(session, sql, &mut capture)?;
            let elapsed = started.elapsed();
            if name == "indexed_point" {
                validate_p1b_result(name, &capture.rows, o.rows)?;
            } else {
                validate_p0_result(name, &capture.rows, o.rows)?;
            }
            writeln!(
                out,
                "{name},{sample},{},{}",
                elapsed.as_nanos(),
                capture.rows.len()
            )?;
            out.flush()?;
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.after.csv")),
            )?;
            eprintln!("P1-C {name} sample={sample}: {:.3}s", elapsed.as_secs_f64());
        }
    }
    db.disconnect(session);
    db.shutdown()?;
    Ok(())
}

fn run() -> Result<()> {
    let o = Options::parse()?;
    if matches!(o.mode.as_str(), "c7-bulk" | "c7-ordinary" | "c8-bulk") {
        return c7_bulk::run(&o);
    }
    if o.mode == "mvcc-acceptance" {
        return c5_acceptance::run(&o);
    }
    if o.mode == "concurrency-profile" {
        // Reuse a forced fixture to diagnose a failed concurrency gate without
        // changing its SQL, admission timeout, or durability configuration.
        let mut out = Results::new(&o.output, o.rows)?;
        let diagnostic = Options {
            dir: o.output.with_extension("fixtures"),
            ..o
        };
        fs::create_dir(&diagnostic.dir)?;
        let result = concurrency(&diagnostic, &mut out, &o.dir);
        phobos_observability::write_profile(&diagnostic.output.with_extension("profile.csv"))?;
        return result;
    }
    if o.mode == "commit-profile" || o.mode == "commit-domains" {
        return commit_profile(&o);
    }
    if o.mode == "domain-fixture" {
        return domain_fixture(&o);
    }
    if o.mode == "c3-fixture" {
        return c3_fixture(&o);
    }
    if o.mode == "c3-group" {
        return c3_group(&o);
    }
    if o.mode == "indexed-profile" {
        return indexed_loop_profile(&o);
    }
    if o.mode == "p0-prepare" {
        return p0_prepare(&o);
    }
    if o.mode == "p0-profile" {
        return p0_profile(&o);
    }
    if o.mode == "p1b-profile" {
        return p1b_profile(&o);
    }
    if o.mode == "p1c-profile" {
        return p1c_profile(&o);
    }
    if o.mode == "write-profile" {
        if o.operations > o.rows {
            return Err("write-profile operations must not exceed rows".into());
        }
        return write_profile(&o);
    }
    if o.mode == "crash-child" {
        let mut db = Database::open(&o.dir)?;
        db.execute(&insert("bench", o.rows, 1))?;
        return Err("crash injection missing".into());
    }
    if o.mode == "lookup" {
        let mut out = Results::new(&o.output, o.rows)?;
        let mut db = Database::open(&o.dir)?;
        check_count(&mut db, o.rows)?;
        for sample in 0..o.samples {
            let queries: Vec<_> = (0..o.operations)
                .map(|i| format!("SELECT * FROM bench WHERE id={}", (i * 7919) % o.rows))
                .collect();
            let start = Instant::now();
            for sql in queries {
                if count(&db.execute(&sql)?) != 1 {
                    return Err("lookup mismatch".into());
                }
            }
            out.record(
                "lookup_loop",
                "warm",
                sample,
                o.operations,
                start.elapsed(),
                (o.operations, 0),
            )?;
        }
        phobos_observability::write_profile(&o.output.with_extension("profile.csv"))?;
        return Ok(());
    }
    if o.mode == "generate" {
        let mut file = BufWriter::new(File::create_new(&o.output)?);
        writeln!(
            file,
            "{SCHEMA};\nCREATE UNIQUE INDEX bench_id ON bench (id);\nBEGIN;"
        )?;
        for start in (0..o.rows).step_by(1000) {
            writeln!(
                file,
                "{};",
                insert("bench", start, (o.rows - start).min(1000))
            )?;
        }
        writeln!(file, "COMMIT;")?;
        return Ok(());
    }
    if o.mode != "suite" && o.mode != "micro" && o.mode != "bulk" {
        return Err("mode must be suite, micro, bulk, generate, or crash-child".into());
    }
    fs::create_dir(&o.dir)?;
    let mut out = Results::new(&o.output, o.rows)?;
    if o.mode == "micro" {
        micro(&o, &mut out)?;
        return Ok(phobos_observability::write_profile(
            &o.output.with_extension("profile.csv"),
        )?);
    }
    let base = load(&o, &mut out)?;
    if o.mode == "bulk" {
        phobos_observability::write_profile(&o.output.with_extension("profile.csv"))?;
        return Ok(());
    }
    reads(&o, &mut out, &base)?;
    mutations(&o, &mut out, &base)?;
    concurrency(&o, &mut out, &base)?;
    restart(&o, &mut out, &base)?;
    phobos_observability::write_profile(&o.output.with_extension("profile.csv"))?;
    Ok(())
}
fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("benchmark failed: {error}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn deterministic_generator_matches_known_values() {
        assert_eq!(payload(0), "p0000000000001f83");
        let sql = insert("bench", 0, 2);
        assert!(sql.starts_with("INSERT INTO bench VALUES (0,0,'p0000000000001f83'),(1,1,'"));
        assert_eq!(sql, insert("bench", 0, 2));
        assert!(phobos_sql::parse(&sql).is_ok());
    }
}
