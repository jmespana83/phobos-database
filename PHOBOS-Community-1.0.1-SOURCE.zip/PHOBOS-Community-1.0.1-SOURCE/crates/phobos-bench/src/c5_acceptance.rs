//! Finite C5 acceptance measurements through the ordinary SQL coordinator.
use super::*;
use std::sync::atomic::{AtomicUsize, Ordering};

pub(super) fn run(o: &Options) -> Result<()> {
    if ![100_000, 1_000_000].contains(&o.rows) {
        return Err("C5 acceptance permits 100K/1M only".into());
    }
    let capable = phobos_wal::v2::inspect(o.dir.join("phobos.wal"))?.page_format == 4;
    let startup = Instant::now();
    let db = Arc::new(Coordinator::open(&o.dir)?);
    let startup_ns = startup.elapsed().as_nanos();
    let setup = db.new_session();
    let count = db.execute(setup, "SELECT COUNT(*) AS n FROM bench")?;
    if count != format!("n\n{}\n", o.rows) {
        return Err(format!("fixture cardinality differs: {count:?}").into());
    }
    db.execute(setup, "UPDATE bench SET bucket=bucket WHERE id=0")?;
    db.execute(setup, "CREATE TABLE c5_probe (id BIGINT)")?;
    db.execute(
        setup,
        "INSERT INTO c5_probe VALUES (0),(1),(2),(3),(4),(5),(6),(7)",
    )?;
    db.execute(setup, "CHECKPOINT")?;
    let mut csv = BufWriter::new(File::create_new(&o.output)?);
    writeln!(
        csv,
        "workload,sample,clients,operations,successes,conflicts,elapsed_ns,p50_ns,p95_ns,p99_ns,reader_successes,writer_successes"
    )?;
    let mut detail = BufWriter::new(File::create_new(o.output.with_extension("latencies.csv"))?);
    writeln!(
        detail,
        "workload,sample,client,operation,elapsed_ns,success"
    )?;
    writeln!(
        csv,
        "startup,0,1,1,1,0,{startup_ns},{startup_ns},{startup_ns},{startup_ns},1,0"
    )?;
    for sample in 0..o.samples {
        for (name, sql, expected, operations) in [
            (
                "indexed_point_loop",
                "SELECT id FROM bench WHERE id=0",
                1,
                32,
            ),
            (
                "indexed_range_loop",
                "SELECT id FROM bench WHERE id<8",
                8,
                32,
            ),
            ("full_scan", "SELECT id FROM bench", o.rows, 3),
            ("scan_aggregate", "SELECT COUNT(*) FROM bench", 1, 3),
            (
                "group_aggregate",
                "SELECT bucket, COUNT(*) FROM bench GROUP BY bucket",
                100,
                3,
            ),
            (
                "join",
                "SELECT bench.id FROM bench JOIN c5_probe ON bench.id=c5_probe.id",
                8,
                3,
            ),
            (
                "sort_spill",
                "SELECT id FROM bench ORDER BY payload LIMIT 100",
                100,
                3,
            ),
        ] {
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.before.csv")),
            )?;
            let start = Instant::now();
            let mut times = Vec::new();
            for operation in 0..operations {
                let mut sink = Counter(0);
                let query_start = Instant::now();
                db.execute_stream_result(setup, sql, &mut sink)?;
                let ns = query_start.elapsed().as_nanos();
                if sink.0 != expected {
                    return Err(format!("{name} rows {} != {expected}", sink.0).into());
                }
                times.push(ns);
                writeln!(detail, "{name},{sample},0,{operation},{ns},true")?;
            }
            let elapsed = start.elapsed().as_nanos();
            times.sort_unstable();
            let n = times.len();
            writeln!(
                csv,
                "{name},{sample},1,{n},{n},0,{elapsed},{},{},{},{n},0",
                times[(n - 1) * 50 / 100],
                times[(n - 1) * 95 / 100],
                times[(n - 1) * 99 / 100]
            )?;
            csv.flush()?;
            phobos_observability::write_profile(
                &o.output
                    .with_extension(format!("{name}-{sample}.after.csv")),
            )?;
            eprintln!("C5 {name}: {elapsed} ns");
        }
        for (workload, clients, operations) in [
            ("concurrent_readers", 4, 32),
            ("disjoint_writers", 4, 32),
            ("disjoint_writers", 8, 32),
            ("shared_row_writers", 4, 32),
            ("mixed", 8, 32),
            ("autocommit_insert", 1, 3),
            ("explicit_insert", 1, 3),
            ("concurrent_insert", 4, 3),
        ] {
            let previous = db.execute(setup, "SELECT SUM(bucket) AS n FROM bench WHERE id<8")?;
            let previous: i64 = previous
                .lines()
                .nth(1)
                .ok_or("sum result missing")?
                .parse()?;
            let label = format!("{workload}-{clients}-{sample}");
            conflict_snapshot(o, &db, &format!("{label}.before"))?;
            phobos_observability::write_profile(
                &o.output.with_extension(format!("{label}.before.csv")),
            )?;
            let barrier = Arc::new(Barrier::new(clients + 1));
            let mut workers = Vec::new();
            let successes = Arc::new(AtomicUsize::new(0));
            let writers_active =
                Arc::new(AtomicUsize::new(if workload == "mixed" { 4 } else { 0 }));
            let reader_progress = Arc::new(AtomicUsize::new(0));
            for client in 0..clients {
                let db = db.clone();
                let barrier = barrier.clone();
                let successes = successes.clone();
                let writers_active = writers_active.clone();
                let reader_progress = reader_progress.clone();
                let base = o.rows
                    + sample * 100_000
                    + client * 1000
                    + if workload == "explicit_insert" {
                        50000
                    } else if workload == "concurrent_insert" {
                        60000
                    } else {
                        0
                    };
                workers.push(thread::spawn(move || -> Result<Vec<(u128, bool)>> {
                    let session = db.new_session();
                    let mut results = Vec::new();
                    barrier.wait();
                    if workload == "explicit_insert" {
                        let start = Instant::now();
                        db.execute(session, "BEGIN")?;
                        for operation in 0..operations {
                            db.execute(session, &insert("bench", base + operation, 1))?;
                        }
                        db.execute(session, "COMMIT")?;
                        results.push((start.elapsed().as_nanos(), true));
                        successes.fetch_add(1, Ordering::Relaxed);
                    } else {
                        for operation in 0..operations {
                            let sql = match workload {
                                "concurrent_readers" => format!(
                                    "SELECT bucket FROM bench WHERE id={}",
                                    (operation * 7919) % 100000
                                ),
                                "mixed" if client >= 4 => {
                                    format!("SELECT bucket FROM bench WHERE id={}", client - 4)
                                }
                                "autocommit_insert" | "concurrent_insert" => {
                                    insert("bench", base + operation, 1)
                                }
                                "shared_row_writers" => {
                                    "UPDATE bench SET bucket=bucket+1 WHERE id=0".into()
                                }
                                _ => format!("UPDATE bench SET bucket=bucket+1 WHERE id={client}"),
                            };
                            let start = Instant::now();
                            let result = db.execute(session, &sql);
                            let elapsed = start.elapsed().as_nanos();
                            let ok = result.is_ok();
                            if let Err(error) = result {
                                if error.code != phobos_error::ErrorCode::TransactionState {
                                    return Err(error.into());
                                }
                                if workload != "shared_row_writers" {
                                    return Err(
                                        format!("unexpected {workload} conflict: {error}").into()
                                    );
                                }
                            }
                            if ok
                                && workload == "mixed"
                                && client >= 4
                                && writers_active.load(Ordering::SeqCst) > 0
                            {
                                reader_progress.fetch_add(1, Ordering::SeqCst);
                            }
                            successes.fetch_add(usize::from(ok), Ordering::Relaxed);
                            results.push((elapsed, ok));
                        }
                    }
                    if workload == "mixed" && client < 4 {
                        writers_active.fetch_sub(1, Ordering::SeqCst);
                    }
                    db.disconnect(session);
                    Ok(results)
                }));
            }
            let start = Instant::now();
            barrier.wait();
            let mut latency = Vec::new();
            let mut readers = 0;
            let mut writers = 0;
            for (client, worker) in workers.into_iter().enumerate() {
                for (operation, (ns, ok)) in worker
                    .join()
                    .map_err(|_| "measurement worker panic")??
                    .into_iter()
                    .enumerate()
                {
                    writeln!(detail, "{workload},{sample},{client},{operation},{ns},{ok}")?;
                    latency.push(ns);
                    if ok {
                        if workload == "concurrent_readers" || (workload == "mixed" && client >= 4)
                        {
                            readers += 1;
                        } else {
                            writers += 1;
                        }
                    }
                }
            }
            let elapsed = start.elapsed().as_nanos();
            latency.sort_unstable();
            let after = db.execute(setup, "SELECT SUM(bucket) AS n FROM bench WHERE id<8")?;
            let after: i64 = after.lines().nth(1).ok_or("sum result missing")?.parse()?;
            let expected = if matches!(
                workload,
                "disjoint_writers" | "shared_row_writers" | "mixed"
            ) {
                writers as i64
            } else {
                0
            };
            if after - previous != expected {
                return Err(format!(
                    "lost update in {workload}: {} expected {expected}",
                    after - previous
                )
                .into());
            }
            if workload == "mixed" {
                let progress = reader_progress.load(Ordering::SeqCst);
                if progress == 0 && capable {
                    return Err("no reader progressed during writer activity".into());
                }
                fs::write(
                    o.output
                        .with_extension(format!("mixed-progress-{sample}.txt")),
                    format!("reader queries completed while writer loops active: {progress}\n"),
                )?;
            }
            let n = latency.len();
            let succeeded = successes.load(Ordering::Relaxed);
            writeln!(
                csv,
                "{workload},{sample},{clients},{n},{succeeded},{},{elapsed},{},{},{},{readers},{writers}",
                n - succeeded,
                latency[(n - 1) * 50 / 100],
                latency[(n - 1) * 95 / 100],
                latency[(n - 1) * 99 / 100]
            )?;
            csv.flush()?;
            detail.flush()?;
            conflict_snapshot(o, &db, &format!("{label}.after"))?;
            phobos_observability::write_profile(
                &o.output.with_extension(format!("{label}.after.csv")),
            )?;
            eprintln!("C5 {workload} {clients} sample {sample}: {succeeded}/{n}, {elapsed} ns");
        }
        if capable {
            db.execute(setup, "BEGIN")?;
            let before = db.execute(setup, "SELECT bucket FROM bench WHERE id=0")?;
            db.execute(setup, "UPDATE bench SET bucket=bucket+1 WHERE id=0")?;
            let reader = db.new_session();
            let start = Instant::now();
            let mut times = Vec::new();
            for operation in 0..32 {
                let query_start = Instant::now();
                if db.execute(reader, "SELECT bucket FROM bench WHERE id=0")? != before {
                    return Err("paused writer exposed uncommitted data".into());
                }
                let ns = query_start.elapsed().as_nanos();
                times.push(ns);
                writeln!(
                    detail,
                    "paused_writer_readers,{sample},0,{operation},{ns},true"
                )?;
            }
            let elapsed = start.elapsed().as_nanos();
            times.sort_unstable();
            writeln!(
                csv,
                "paused_writer_readers,{sample},1,32,32,0,{elapsed},{},{},{},32,0",
                times[15], times[29], times[30]
            )?;
            db.disconnect(reader);
            db.execute(setup, "ROLLBACK")?;
        }
    }
    #[cfg(feature = "diagnostics")]
    if capable {
        unique_wait(o, &db, setup)?;
    }
    db.disconnect(setup);
    db.shutdown()?;
    drop(db);
    csv.flush()?;
    Ok(())
}

#[cfg(feature = "diagnostics")]
fn unique_wait(o: &Options, db: &Arc<Coordinator>, setup: u64) -> Result<()> {
    db.execute(setup, "CREATE TABLE c5_wait (id BIGINT, k BIGINT)")?;
    db.execute(setup, "CREATE UNIQUE INDEX c5_wait_key ON c5_wait(k)")?;
    let mut output = BufWriter::new(File::create_new(
        o.output.with_extension("unique-wait.csv"),
    )?);
    writeln!(output, "sample,wait_and_recheck_ns,owner_commit_ns,outcome")?;
    for sample in 0..o.samples {
        conflict_snapshot(o, db, &format!("unique-{sample}.before"))?;
        let older = db.new_session();
        let younger = db.new_session();
        db.execute(older, "BEGIN")?;
        db.execute(younger, "BEGIN")?;
        db.execute(younger, &format!("INSERT INTO c5_wait VALUES (1,{sample})"))?;
        let (send, receive) = std::sync::mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &o.dir,
            Arc::new(move |point| {
                if point == "c5_unique_wait" {
                    let _ = send.send(());
                }
            }),
        );
        phobos_observability::write_profile(
            &o.output
                .with_extension(format!("unique-{sample}.before.csv")),
        )?;
        let worker_db = db.clone();
        let worker = thread::spawn(move || {
            let start = Instant::now();
            let result =
                worker_db.execute(older, &format!("INSERT INTO c5_wait VALUES (2,{sample})"));
            (start.elapsed().as_nanos(), result)
        });
        receive.recv_timeout(Duration::from_secs(10))?;
        let start = Instant::now();
        db.execute(younger, "COMMIT")?;
        let commit = start.elapsed().as_nanos();
        let (elapsed, result) = worker.join().map_err(|_| "unique worker panic")?;
        if result.is_ok() {
            return Err("unique stale recheck accepted duplicate".into());
        }
        phobos_observability::write_profile(
            &o.output
                .with_extension(format!("unique-{sample}.after.csv")),
        )?;
        drop(hook);
        conflict_snapshot(o, db, &format!("unique-{sample}.after"))?;
        db.execute(older, "ROLLBACK")?;
        writeln!(output, "{sample},{elapsed},{commit},duplicate_rejected")?;
        db.disconnect(older);
        db.disconnect(younger);
    }
    Ok(())
}

// Outside workload timing; ordinary builds do not copy coordination diagnostics.
fn conflict_snapshot(o: &Options, db: &Coordinator, label: &str) -> Result<()> {
    #[cfg(feature = "diagnostics")]
    if let Some(diagnostics) = db.conflict_diagnostics()? {
        let mut output = BufWriter::new(File::create_new(
            o.output.with_extension(format!("{label}.conflicts.csv")),
        )?);
        writeln!(
            output,
            "domain,acquisitions,immediate,waits,victims,timeouts,cancellations,total_wait_ns,maximum_wait_ns,histogram,active"
        )?;
        for (domain, stats) in [("row", diagnostics.row), ("unique", diagnostics.unique)] {
            let histogram = stats
                .histogram
                .iter()
                .map(u64::to_string)
                .collect::<Vec<_>>()
                .join(";");
            writeln!(
                output,
                "{domain},{},{},{},{},{},{},{},{},{histogram},{}",
                stats.acquisitions,
                stats.immediate,
                stats.waits,
                stats.victims,
                stats.timeouts,
                stats.cancellations,
                stats.total_wait_ns,
                stats.maximum_wait_ns,
                diagnostics.active.len()
            )?;
        }
        output.flush()?;
    }
    #[cfg(not(feature = "diagnostics"))]
    let _ = (o, db, label);
    Ok(())
}

struct Counter(usize);
impl phobos_execution::ResultSink for Counter {
    fn start(&mut self, _: Vec<String>) -> std::result::Result<(), phobos_error::PhobosError> {
        Ok(())
    }
    fn row(&mut self, _: Row) -> std::result::Result<(), phobos_error::PhobosError> {
        self.0 += 1;
        Ok(())
    }
    fn finish(&mut self) -> std::result::Result<(), phobos_error::PhobosError> {
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> std::result::Result<(), phobos_error::PhobosError> {
        Err(phobos_error::PhobosError::new(
            phobos_error::ErrorCode::Semantic,
            "benchmark expected rows",
        ))
    }
}
