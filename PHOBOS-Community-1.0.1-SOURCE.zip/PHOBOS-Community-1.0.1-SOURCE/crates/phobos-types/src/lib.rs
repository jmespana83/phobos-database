#![forbid(unsafe_code)]
//! Shared logical types, schemas, rows, and stable identifiers.

use std::cmp::Ordering;
use std::fmt;

/// Physical page identifier.
pub type PageId = u64;
/// Slot identifier within a heap page.
pub type SlotId = u16;
/// Catalog table identifier.
pub type TableId = u64;
/// Catalog index identifier.
pub type IndexId = u64;

/// Stable record identifier for the current storage generation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RecordId {
    pub page_id: PageId,
    pub slot_id: SlotId,
}

/// Logical column data type used by the Phase 1 row codec and catalog.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DataType {
    Int64,
    Boolean,
    Float64,
    Text,
    Binary,
    Date,
    Timestamp,
    Decimal { precision: u8, scale: u8 },
}

/// A typed SQL value. `Null` has no intrinsic type and is checked against its column.
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Null,
    Int64(i64),
    Boolean(bool),
    Float64(f64),
    Text(String),
    Binary(Vec<u8>),
    /// Days since 1970-01-01.
    Date(i32),
    /// Microseconds since 1970-01-01 UTC.
    Timestamp(i64),
    /// Base-10 integer scaled by `scale` decimal places.
    Decimal {
        unscaled: i128,
        scale: u8,
    },
}

/// Comparison class of a non-NULL value under the canonical PHOBOS key contract.
///
/// Two values are comparable (orderable, equality-testable, joinable, groupable)
/// exactly when they share a class. `Int64` and `Float64` share the `Number`
/// class and compare by exact mathematical value; every other class is a single
/// data type. `Decimal` values are comparable only at the same scale.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum KeyClass {
    Boolean,
    Number,
    Text,
    Binary,
    Date,
    Timestamp,
    Decimal { scale: u8 },
}

impl DataType {
    /// Class every non-NULL value stored in a column of this type belongs to.
    #[must_use]
    pub fn key_class(&self) -> KeyClass {
        match self {
            Self::Int64 | Self::Float64 => KeyClass::Number,
            Self::Boolean => KeyClass::Boolean,
            Self::Text => KeyClass::Text,
            Self::Binary => KeyClass::Binary,
            Self::Date => KeyClass::Date,
            Self::Timestamp => KeyClass::Timestamp,
            Self::Decimal { scale, .. } => KeyClass::Decimal { scale: *scale },
        }
    }
}

const KEY_TAG_NULL: u8 = 0;
const KEY_TAG_BOOLEAN: u8 = 1;
const KEY_TAG_NUMBER: u8 = 2;
const KEY_TAG_TEXT: u8 = 3;
const KEY_TAG_BINARY: u8 = 4;
const KEY_TAG_DATE: u8 = 5;
const KEY_TAG_TIMESTAMP: u8 = 6;
const KEY_TAG_DECIMAL: u8 = 7;
const NUMBER_INTEGRAL: u8 = 1;
const NUMBER_FRACTIONAL: u8 = 2;
const NUMBER_NAN: u8 = 3;
/// 2^63 as f64; the smallest float that is not below `i64::MAX`.
const TWO_POW_63: f64 = 9_223_372_036_854_775_808.0;

/// Canonical PHOBOS value equality, ordering and hash-key contract.
///
/// Every equality-based relational operation (join predicates, GROUP BY keys,
/// distinctness, `=`/`<>` and the ordering comparisons, ORDER BY, MIN/MAX) is
/// defined in terms of these three methods, so switching between execution
/// algorithms (hash versus sort/nested-loop, collecting versus streaming) can
/// never change a result. The invariant every caller relies on is:
///
/// for non-NULL `a` and `b`,
/// `a.canonical_cmp(b) == Some(Ordering::Equal)` **iff** `a.canonical_key() == b.canonical_key()`.
///
/// Semantics:
/// - NULL is not comparable to anything through `canonical_cmp` (callers apply
///   SQL NULL rules themselves); its key is a distinct tag so GROUP BY can treat
///   all NULLs as one group.
/// - `Int64` and `Float64` compare by exact mathematical value (no lossy
///   int→float coercion), so `9007199254740993 <> 9007199254740992.0`.
/// - `-0.0` and `+0.0` are equal. NaN equals NaN regardless of payload and sorts
///   after every other number (the PostgreSQL convention), which makes the
///   `Number` order total.
/// - `Text` and `Binary` compare bytewise (no collation); `Boolean` false < true;
///   `Date`/`Timestamp` by their integer representation.
/// - `Decimal` compares by unscaled value at equal scale; different scales are
///   not comparable (`None`).
/// - Values of different classes are not comparable (`None`), never "unequal".
impl Value {
    #[must_use]
    pub fn is_null(&self) -> bool {
        matches!(self, Self::Null)
    }

    /// Comparison class of this value; `None` for NULL.
    #[must_use]
    pub fn key_class(&self) -> Option<KeyClass> {
        Some(match self {
            Self::Null => return None,
            Self::Int64(_) | Self::Float64(_) => KeyClass::Number,
            Self::Boolean(_) => KeyClass::Boolean,
            Self::Text(_) => KeyClass::Text,
            Self::Binary(_) => KeyClass::Binary,
            Self::Date(_) => KeyClass::Date,
            Self::Timestamp(_) => KeyClass::Timestamp,
            Self::Decimal { scale, .. } => KeyClass::Decimal { scale: *scale },
        })
    }

    /// Total order within a class; `None` when the values are not comparable
    /// (different classes, different DECIMAL scales, or either side NULL).
    #[must_use]
    pub fn canonical_cmp(&self, other: &Self) -> Option<Ordering> {
        // 0.2-B: `ValueRef` is the single implementation of the contract, so
        // borrowed (page-resident) and owned values can never disagree.
        self.as_value_ref().canonical_cmp(&other.as_value_ref())
    }

    /// Canonical equality: `Some(true)` iff the values are comparable and equal.
    #[must_use]
    pub fn canonical_eq(&self, other: &Self) -> Option<bool> {
        self.canonical_cmp(other)
            .map(|ordering| ordering == Ordering::Equal)
    }

    /// Appends the canonical hash key of this value. Keys of comparable values
    /// are equal iff the values are canonically equal; keys of values from
    /// different classes never collide. NULL has its own key.
    pub fn write_canonical_key(&self, out: &mut Vec<u8>) {
        self.as_value_ref().write_canonical_key(out);
    }

    /// The canonical hash key as an owned byte string. See [`Value::write_canonical_key`].
    #[must_use]
    pub fn canonical_key(&self) -> Vec<u8> {
        let mut key = Vec::new();
        self.write_canonical_key(&mut key);
        key
    }
}

impl Value {
    /// Borrowed view with identical comparison, key and conversion semantics.
    #[must_use]
    pub fn as_value_ref(&self) -> ValueRef<'_> {
        match self {
            Self::Null => ValueRef::Null,
            Self::Int64(v) => ValueRef::Int64(*v),
            Self::Boolean(v) => ValueRef::Boolean(*v),
            Self::Float64(v) => ValueRef::Float64(*v),
            Self::Text(v) => ValueRef::Text(v),
            Self::Binary(v) => ValueRef::Binary(v),
            Self::Date(v) => ValueRef::Date(*v),
            Self::Timestamp(v) => ValueRef::Timestamp(*v),
            Self::Decimal { unscaled, scale } => ValueRef::Decimal {
                unscaled: *unscaled,
                scale: *scale,
            },
        }
    }
}

/// 0.2-B Execution Engine v2: a borrowed SQL value, typically pointing into an
/// immutable committed page image. It carries exactly the semantics of
/// [`Value`] (which delegates its canonical comparison and hash-key contract
/// here) without allocating for TEXT/BINARY.
///
/// `Absent` marks a column the producing operator did not decode because the
/// plan does not reference it. It is never a SQL value: comparing, keying or
/// converting it is an internal error rather than a silent NULL.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ValueRef<'a> {
    Null,
    Int64(i64),
    Boolean(bool),
    Float64(f64),
    Text(&'a str),
    Binary(&'a [u8]),
    Date(i32),
    Timestamp(i64),
    Decimal { unscaled: i128, scale: u8 },
    Absent,
}

impl ValueRef<'_> {
    #[must_use]
    pub fn is_null(&self) -> bool {
        matches!(self, Self::Null)
    }
    #[must_use]
    pub fn is_absent(&self) -> bool {
        matches!(self, Self::Absent)
    }

    /// Owned copy. `None` only for `Absent`.
    #[must_use]
    pub fn to_value(&self) -> Option<Value> {
        Some(match *self {
            Self::Null => Value::Null,
            Self::Int64(v) => Value::Int64(v),
            Self::Boolean(v) => Value::Boolean(v),
            Self::Float64(v) => Value::Float64(v),
            Self::Text(v) => Value::Text(v.to_owned()),
            Self::Binary(v) => Value::Binary(v.to_vec()),
            Self::Date(v) => Value::Date(v),
            Self::Timestamp(v) => Value::Timestamp(v),
            Self::Decimal { unscaled, scale } => Value::Decimal { unscaled, scale },
            Self::Absent => return None,
        })
    }

    /// See [`Value::canonical_cmp`]. `Absent` is never comparable.
    #[must_use]
    pub fn canonical_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(match (*self, *other) {
            (Self::Int64(a), Self::Int64(b)) => a.cmp(&b),
            (Self::Float64(a), Self::Float64(b)) => cmp_float(a, b),
            (Self::Int64(a), Self::Float64(b)) => cmp_int_float(a, b),
            (Self::Float64(a), Self::Int64(b)) => cmp_int_float(b, a).reverse(),
            (Self::Boolean(a), Self::Boolean(b)) => a.cmp(&b),
            (Self::Text(a), Self::Text(b)) => a.as_bytes().cmp(b.as_bytes()),
            (Self::Binary(a), Self::Binary(b)) => a.cmp(b),
            (Self::Date(a), Self::Date(b)) => a.cmp(&b),
            (Self::Timestamp(a), Self::Timestamp(b)) => a.cmp(&b),
            (
                Self::Decimal {
                    unscaled: a,
                    scale: sa,
                },
                Self::Decimal {
                    unscaled: b,
                    scale: sb,
                },
            ) if sa == sb => a.cmp(&b),
            _ => return None,
        })
    }

    /// See [`Value::write_canonical_key`]. Returns false (writing nothing)
    /// only for `Absent`.
    pub fn write_canonical_key(&self, out: &mut Vec<u8>) -> bool {
        match *self {
            Self::Null => out.push(KEY_TAG_NULL),
            Self::Boolean(value) => out.extend_from_slice(&[KEY_TAG_BOOLEAN, u8::from(value)]),
            Self::Int64(value) => {
                out.extend_from_slice(&[KEY_TAG_NUMBER, NUMBER_INTEGRAL]);
                out.extend_from_slice(&value.to_le_bytes());
            }
            Self::Float64(value) => {
                out.push(KEY_TAG_NUMBER);
                if value.is_nan() {
                    out.push(NUMBER_NAN);
                } else if let Some(integral) = float_as_i64(value) {
                    // Every integral float in i64 range (including -0.0) keys
                    // exactly like the equal Int64.
                    out.push(NUMBER_INTEGRAL);
                    out.extend_from_slice(&integral.to_le_bytes());
                } else {
                    // Non-integral, infinite, or beyond i64: non-NaN, non-zero
                    // floats have one bit pattern per value.
                    out.push(NUMBER_FRACTIONAL);
                    out.extend_from_slice(&value.to_bits().to_le_bytes());
                }
            }
            Self::Text(value) => {
                out.push(KEY_TAG_TEXT);
                out.extend_from_slice(value.as_bytes());
            }
            Self::Binary(value) => {
                out.push(KEY_TAG_BINARY);
                out.extend_from_slice(value);
            }
            Self::Date(value) => {
                out.push(KEY_TAG_DATE);
                out.extend_from_slice(&value.to_le_bytes());
            }
            Self::Timestamp(value) => {
                out.push(KEY_TAG_TIMESTAMP);
                out.extend_from_slice(&value.to_le_bytes());
            }
            Self::Decimal { unscaled, scale } => {
                out.extend_from_slice(&[KEY_TAG_DECIMAL, scale]);
                out.extend_from_slice(&unscaled.to_le_bytes());
            }
            Self::Absent => return false,
        }
        true
    }
}

/// Total order on floats: NaN equals NaN and sorts last; `-0.0 == +0.0`.
fn cmp_float(a: f64, b: f64) -> Ordering {
    match (a.is_nan(), b.is_nan()) {
        (true, true) => Ordering::Equal,
        (true, false) => Ordering::Greater,
        (false, true) => Ordering::Less,
        (false, false) => a.partial_cmp(&b).unwrap_or(Ordering::Equal),
    }
}

/// Exact comparison of an integer with a float (no rounding of the integer).
fn cmp_int_float(int: i64, float: f64) -> Ordering {
    if float.is_nan() || float >= TWO_POW_63 {
        return Ordering::Less;
    }
    if float < -TWO_POW_63 {
        return Ordering::Greater;
    }
    let truncated = float.trunc();
    // `truncated` lies in [-2^63, 2^63) so the conversion is exact.
    let truncated_int = truncated as i64;
    match int.cmp(&truncated_int) {
        Ordering::Equal => {
            if float > truncated {
                Ordering::Less
            } else if float < truncated {
                Ordering::Greater
            } else {
                Ordering::Equal
            }
        }
        ordering => ordering,
    }
}

/// The exact i64 value of an integral float within i64 range (`-0.0` maps to 0).
fn float_as_i64(float: f64) -> Option<i64> {
    if !float.is_finite() || !(-TWO_POW_63..TWO_POW_63).contains(&float) || float.fract() != 0.0 {
        return None;
    }
    Some(float as i64)
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Null => f.write_str("NULL"),
            Self::Int64(v) => write!(f, "{v}"),
            Self::Boolean(v) => write!(f, "{v}"),
            Self::Float64(v) => write!(f, "{v}"),
            Self::Text(v) => f.write_str(v),
            Self::Binary(v) => {
                f.write_str("0x")?;
                for byte in v {
                    write!(f, "{byte:02x}")?;
                }
                Ok(())
            }
            Self::Date(v) => write!(f, "DATE({v})"),
            Self::Timestamp(v) => write!(f, "TIMESTAMP({v})"),
            Self::Decimal { unscaled, scale } => {
                if *scale == 0 {
                    return write!(f, "{unscaled}");
                }
                let negative = *unscaled < 0;
                let digits = unscaled.unsigned_abs().to_string();
                let scale = usize::from(*scale);
                if negative {
                    f.write_str("-")?;
                }
                if digits.len() <= scale {
                    f.write_str("0.")?;
                    for _ in 0..(scale - digits.len()) {
                        f.write_str("0")?;
                    }
                    f.write_str(&digits)
                } else {
                    let split = digits.len() - scale;
                    write!(f, "{}.{}", &digits[..split], &digits[split..])
                }
            }
        }
    }
}

/// Column metadata persisted in the catalog.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ColumnSchema {
    pub name: String,
    pub data_type: DataType,
    pub nullable: bool,
}

/// Table schema persisted in the catalog.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TableSchema {
    pub id: TableId,
    pub name: String,
    pub columns: Vec<ColumnSchema>,
}

impl TableSchema {
    #[must_use]
    pub fn column_index(&self, name: &str) -> Option<usize> {
        self.columns
            .iter()
            .position(|column| column.name.eq_ignore_ascii_case(name))
    }
}

/// Index metadata persisted by the catalog. Column order is significant for composite keys.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IndexSchema {
    pub id: IndexId,
    pub name: String,
    pub table_id: TableId,
    pub columns: Vec<String>,
    pub unique: bool,
}

/// Materialized row used by the Phase 1 execution path.
#[derive(Debug, Clone, PartialEq)]
pub struct Row {
    pub values: Vec<Value>,
}

impl Row {
    #[must_use]
    pub fn new(values: Vec<Value>) -> Self {
        Self { values }
    }
}

#[cfg(test)]
mod canonical_key_tests {
    use super::*;

    fn decimal(unscaled: i128, scale: u8) -> Value {
        Value::Decimal { unscaled, scale }
    }

    /// A corpus that covers every class and every numeric boundary the contract
    /// has to get right: signed zero, NaN payloads, infinities, the 2^53 and
    /// 2^63 edges, fractional neighbours of integers, and cross-scale decimals.
    fn corpus() -> Vec<Value> {
        let mut values = vec![
            Value::Null,
            Value::Boolean(false),
            Value::Boolean(true),
            Value::Int64(i64::MIN),
            Value::Int64(-9_007_199_254_740_993),
            Value::Int64(-9_007_199_254_740_992),
            Value::Int64(-6),
            Value::Int64(-5),
            Value::Int64(-1),
            Value::Int64(0),
            Value::Int64(1),
            Value::Int64(5),
            Value::Int64(6),
            Value::Int64(9_007_199_254_740_992),
            Value::Int64(9_007_199_254_740_993),
            Value::Int64(i64::MAX - 1),
            Value::Int64(i64::MAX),
            Value::Float64(f64::NEG_INFINITY),
            Value::Float64(-1.0e300),
            Value::Float64(-9_223_372_036_854_775_808.0),
            Value::Float64(-9_007_199_254_740_992.0),
            Value::Float64(-5.5),
            Value::Float64(-5.0),
            Value::Float64(-4.5),
            Value::Float64(-0.5),
            Value::Float64(-0.0),
            Value::Float64(0.0),
            Value::Float64(f64::MIN_POSITIVE),
            Value::Float64(0.5),
            Value::Float64(1.0),
            Value::Float64(5.0),
            Value::Float64(5.5),
            Value::Float64(9_007_199_254_740_992.0),
            Value::Float64(9_007_199_254_740_994.0),
            Value::Float64(9_223_372_036_854_775_808.0),
            Value::Float64(1.0e300),
            Value::Float64(f64::INFINITY),
            Value::Float64(f64::NAN),
            Value::Float64(-f64::NAN),
            Value::Float64(f64::from_bits(0x7ff8_0000_0000_0001)),
            Value::Float64(f64::from_bits(0x7ff0_0000_0000_0001)),
            Value::Text(String::new()),
            Value::Text("a".into()),
            Value::Text("A".into()),
            Value::Text("ab".into()),
            Value::Text("b".into()),
            Value::Binary(Vec::new()),
            Value::Binary(b"a".to_vec()),
            Value::Binary(b"ab".to_vec()),
            Value::Date(-1),
            Value::Date(0),
            Value::Date(1),
            Value::Timestamp(-1),
            Value::Timestamp(0),
            Value::Timestamp(1),
            decimal(-100, 2),
            decimal(0, 2),
            decimal(100, 2),
            decimal(100, 0),
            decimal(10, 1),
            decimal(1, 0),
        ];
        // Duplicates by value (not by identity) make the equality checks meaningful.
        values.push(Value::Int64(5));
        values.push(Value::Float64(-0.0));
        values.push(Value::Text("ab".into()));
        values
    }

    #[test]
    fn equality_and_key_agree_for_every_pair() {
        let corpus = corpus();
        for a in &corpus {
            for b in &corpus {
                let (ka, kb) = (a.canonical_key(), b.canonical_key());
                match (a.is_null(), b.is_null()) {
                    (true, true) => assert_eq!(ka, kb),
                    (true, false) | (false, true) => {
                        assert_ne!(ka, kb);
                        assert_eq!(a.canonical_cmp(b), None, "{a:?} {b:?}");
                    }
                    (false, false) => {
                        let cmp = a.canonical_cmp(b);
                        // The contract: comparable-and-equal iff the keys are equal.
                        assert_eq!(
                            cmp == Some(Ordering::Equal),
                            ka == kb,
                            "cmp={cmp:?} for {a:?} vs {b:?}"
                        );
                        // Comparable iff same class; incomparable pairs never share a key.
                        assert_eq!(cmp.is_some(), a.key_class() == b.key_class(), "{a:?} {b:?}");
                        // Antisymmetry.
                        assert_eq!(
                            cmp,
                            b.canonical_cmp(a).map(Ordering::reverse),
                            "{a:?} {b:?}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn ordering_is_reflexive_and_transitive_within_each_class() {
        let corpus: Vec<_> = corpus().into_iter().filter(|v| !v.is_null()).collect();
        for a in &corpus {
            assert_eq!(a.canonical_cmp(a), Some(Ordering::Equal), "{a:?}");
        }
        for a in &corpus {
            for b in &corpus {
                for c in &corpus {
                    let (Some(ab), Some(bc), Some(ac)) =
                        (a.canonical_cmp(b), b.canonical_cmp(c), a.canonical_cmp(c))
                    else {
                        continue;
                    };
                    if ab != Ordering::Greater && bc != Ordering::Greater {
                        assert_ne!(ac, Ordering::Greater, "{a:?} <= {b:?} <= {c:?}");
                    }
                    if ab == Ordering::Equal && bc == Ordering::Equal {
                        assert_eq!(ac, Ordering::Equal, "{a:?} = {b:?} = {c:?}");
                    }
                }
            }
        }
    }

    #[test]
    fn numeric_boundaries_follow_the_documented_semantics() {
        let eq = |a: &Value, b: &Value| a.canonical_eq(b);
        assert_eq!(eq(&Value::Int64(1), &Value::Float64(1.0)), Some(true));
        assert_eq!(eq(&Value::Float64(-0.0), &Value::Float64(0.0)), Some(true));
        assert_eq!(eq(&Value::Int64(0), &Value::Float64(-0.0)), Some(true));
        assert_eq!(
            eq(
                &Value::Float64(f64::NAN),
                &Value::Float64(f64::from_bits(0x7ff8_0000_0000_0001))
            ),
            Some(true)
        );
        assert_eq!(
            eq(&Value::Float64(f64::NAN), &Value::Float64(-f64::NAN)),
            Some(true)
        );
        // Exact, not float-rounded: 2^53 + 1 is not 2^53.
        assert_eq!(
            eq(
                &Value::Int64(9_007_199_254_740_993),
                &Value::Float64(9_007_199_254_740_992.0)
            ),
            Some(false)
        );
        assert_eq!(
            Value::Int64(9_007_199_254_740_993)
                .canonical_cmp(&Value::Float64(9_007_199_254_740_992.0)),
            Some(Ordering::Greater)
        );
        // i64::MAX rounds up to 2^63 as a float; the exact comparison keeps it below.
        assert_eq!(
            Value::Int64(i64::MAX).canonical_cmp(&Value::Float64(9_223_372_036_854_775_808.0)),
            Some(Ordering::Less)
        );
        assert_eq!(
            Value::Int64(i64::MIN).canonical_cmp(&Value::Float64(-9_223_372_036_854_775_808.0)),
            Some(Ordering::Equal)
        );
        assert_eq!(
            Value::Int64(5).canonical_cmp(&Value::Float64(5.5)),
            Some(Ordering::Less)
        );
        assert_eq!(
            Value::Int64(-5).canonical_cmp(&Value::Float64(-5.5)),
            Some(Ordering::Greater)
        );
        assert_eq!(
            Value::Int64(-6).canonical_cmp(&Value::Float64(-5.5)),
            Some(Ordering::Less)
        );
        // NaN sorts after everything, including +infinity, and after any integer.
        assert_eq!(
            Value::Float64(f64::INFINITY).canonical_cmp(&Value::Float64(f64::NAN)),
            Some(Ordering::Less)
        );
        assert_eq!(
            Value::Int64(i64::MAX).canonical_cmp(&Value::Float64(f64::NAN)),
            Some(Ordering::Less)
        );
        assert_eq!(
            Value::Float64(f64::NAN).canonical_cmp(&Value::Int64(i64::MIN)),
            Some(Ordering::Greater)
        );
        // Decimals: same scale compares, different scale is not comparable (not "unequal").
        assert_eq!(eq(&decimal(100, 2), &decimal(100, 2)), Some(true));
        assert_eq!(eq(&decimal(100, 2), &decimal(10, 1)), None);
        assert_eq!(eq(&decimal(1, 0), &Value::Int64(1)), None);
        // Cross-class is not comparable.
        assert_eq!(eq(&Value::Int64(1), &Value::Text("1".into())), None);
        assert_eq!(eq(&Value::Boolean(true), &Value::Int64(1)), None);
        assert_eq!(eq(&Value::Null, &Value::Null), None);
    }
}
