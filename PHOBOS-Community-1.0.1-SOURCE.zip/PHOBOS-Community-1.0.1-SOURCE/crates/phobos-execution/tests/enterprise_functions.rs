use phobos_config::RuntimeConfig;
use phobos_error::ErrorCode;
use phobos_execution::{Database, QueryResult};
use phobos_types::Value;
use std::path::PathBuf;

fn root(label: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "phobos-enterprise-{label}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}

fn value(result: QueryResult) -> Value {
    let QueryResult::Rows { rows, .. } = result else {
        panic!("expected rows")
    };
    assert_eq!(rows.len(), 1);
    assert_eq!(rows[0].values.len(), 1);
    rows[0].values[0].clone()
}

#[test]
fn enterprise_function_unicode_null_numeric_and_argument_contracts() {
    let root = root("functions");
    let mut db = Database::open(&root).unwrap();
    db.execute("CREATE TABLE input (id BIGINT)").unwrap();
    db.execute("INSERT INTO input VALUES (1)").unwrap();
    for (expression, expected) in [
        ("TRIM('  café  ')", Value::Text("café".into())),
        ("LTRIM('  x  ')", Value::Text("x  ".into())),
        ("RTRIM('  x  ')", Value::Text("  x".into())),
        ("CHAR_LENGTH('é猫')", Value::Int64(2)),
        ("CHARACTER_LENGTH('é猫')", Value::Int64(2)),
        ("OCTET_LENGTH('é猫')", Value::Int64(5)),
        ("SUBSTR('é猫x',2,1)", Value::Text("猫".into())),
        ("SUBSTRING('abc',0,2)", Value::Text("a".into())),
        ("SUBSTRING('abc',2)", Value::Text("bc".into())),
        ("SUBSTRING('abc',4,10)", Value::Text(String::new())),
        ("REPLACE('abab','ab','x')", Value::Text("xx".into())),
        ("REPLACE('abc','','x')", Value::Text("abc".into())),
        ("CONCAT(NULL,NULL)", Value::Text(String::new())),
        ("CONCAT('a',NULL,'b')", Value::Text("ab".into())),
        ("FLOOR(-1.2)", Value::Float64(-2.0)),
        ("CEIL(-1.2)", Value::Float64(-1.0)),
        ("CEILING(1.2)", Value::Float64(2.0)),
        ("ROUND(1.5)", Value::Float64(2.0)),
        ("ROUND(-1.5)", Value::Float64(-2.0)),
        ("ROUND(2)", Value::Int64(2)),
    ] {
        assert_eq!(
            value(
                db.execute(&format!("SELECT {expression} FROM input"))
                    .unwrap()
            ),
            expected,
            "{expression}"
        );
    }
    for expression in [
        "TRIM(NULL)",
        "LTRIM(NULL)",
        "RTRIM(NULL)",
        "CHAR_LENGTH(NULL)",
        "CHARACTER_LENGTH(NULL)",
        "OCTET_LENGTH(NULL)",
        "SUBSTR(NULL,1)",
        "SUBSTRING('abc',NULL,2)",
        "REPLACE('abc',NULL,'x')",
        "FLOOR(NULL)",
        "CEIL(NULL)",
        "CEILING(NULL)",
        "ROUND(NULL)",
    ] {
        assert_eq!(
            value(
                db.execute(&format!("SELECT {expression} FROM input"))
                    .unwrap()
            ),
            Value::Null,
            "{expression}"
        );
    }
    for expression in [
        "TRIM(1)",
        "LTRIM(1)",
        "RTRIM(1)",
        "CHAR_LENGTH(TRUE)",
        "CHARACTER_LENGTH(1)",
        "OCTET_LENGTH(1)",
        "SUBSTR('x',1,-1)",
        "SUBSTRING('x','bad')",
        "REPLACE(1,'a','b')",
        "REPLACE('a','b')",
        "CONCAT('a',1)",
        "CONCAT()",
        "FLOOR('x')",
        "CEIL('x')",
        "CEILING('x')",
        "ROUND(1,2)",
    ] {
        assert!(
            db.execute(&format!("SELECT {expression} FROM input"))
                .is_err(),
            "{expression}"
        );
    }
    assert_eq!(
        value(
            db.execute_params(
                "SELECT OCTET_LENGTH($1) FROM input",
                &[Value::Binary(vec![0, 1, 255])]
            )
            .unwrap()
        ),
        Value::Int64(3)
    );
    drop(db);
    std::fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_expanding_functions_and_predicate_join_have_resource_guards() {
    let root = root("limits");
    let config = RuntimeConfig {
        query_memory_bytes: 1,
        ..RuntimeConfig::default()
    };
    let mut db = Database::open_with_config(&root, &config).unwrap();
    db.execute("CREATE TABLE input (id BIGINT)").unwrap();
    db.execute("INSERT INTO input VALUES (1),(2)").unwrap();
    let large = Value::Text("x".repeat(9 * 1024 * 1024));
    for (sql, params) in [
        (
            "SELECT CONCAT($1,$2) FROM input",
            vec![large.clone(), large.clone()],
        ),
        ("SELECT REPLACE('aa','a',$1) FROM input", vec![large]),
    ] {
        assert_eq!(
            db.execute_params(sql, &params).unwrap_err().code,
            ErrorCode::ResourceLimit
        );
    }
    assert_eq!(
        db.execute("SELECT * FROM input a CROSS JOIN input b")
            .unwrap_err()
            .code,
        ErrorCode::ResourceLimit
    );
    assert_eq!(
        value(db.execute("SELECT COUNT(*) FROM input").unwrap()),
        Value::Int64(2)
    );
    drop(db);
    std::fs::remove_dir_all(root).unwrap();
}
