//! Qualified outer references in WHERE EXISTS / NOT EXISTS. Each inner query
//! uses the same immutable statement snapshot and the transaction's own overlay.
use super::*;
impl Database {
    pub(super) fn resolve_filter_constants(
        &mut self,
        e: &mut Expr,
        params: &[Value],
    ) -> Result<(), PhobosError> {
        match e {
            Expr::Exists(_) => Ok(()),
            Expr::ScalarSubquery(_) | Expr::InSubquery { .. } => {
                self.resolve_expr_subqueries(e, params)
            }
            _ => visit_expr_children(e, |child| self.resolve_filter_constants(child, params)),
        }
    }
    pub(super) fn resolve_exists_for_row(
        &mut self,
        e: &mut Expr,
        qualified: &[String],
        row: &Row,
        params: &[Value],
    ) -> Result<(), PhobosError> {
        match e {
            Expr::Exists(query) => {
                let mut query = (**query).clone();
                substitute(&mut query, qualified, row, &[])?;
                let QueryResult::Rows { rows, .. } = self.execute_subquery(query, params)? else {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "EXISTS requires SELECT",
                    ));
                };
                *e = Expr::Literal(Value::Boolean(!rows.is_empty()));
                Ok(())
            }
            _ => visit_expr_children(e, |child| {
                self.resolve_exists_for_row(child, qualified, row, params)
            }),
        }
    }
}
fn visit_expr_children(
    e: &mut Expr,
    mut visit: impl FnMut(&mut Expr) -> Result<(), PhobosError>,
) -> Result<(), PhobosError> {
    match e {
        Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => visit(expr)?,
        Expr::Binary { left, right, .. }
        | Expr::Like {
            expr: left,
            pattern: right,
        } => {
            visit(left)?;
            visit(right)?;
        }
        Expr::Function { args, .. } => {
            for e in args {
                visit(e)?;
            }
        }
        Expr::InList { expr, values } => {
            visit(expr)?;
            for e in values {
                visit(e)?;
            }
        }
        Expr::Case {
            branches,
            else_expr,
        } => {
            for (a, b) in branches {
                visit(a)?;
                visit(b)?;
            }
            if let Some(e) = else_expr {
                visit(e)?;
            }
        }
        _ => (),
    }
    Ok(())
}
fn substitute_expr(
    e: &mut Expr,
    qualified: &[String],
    row: &Row,
    local: &[String],
) -> Result<(), PhobosError> {
    match e {
        Expr::Column(n) | Expr::QuotedColumn(n) => {
            if let Some((qualifier, _)) = n.split_once('.') {
                if !local.iter().any(|q| q.eq_ignore_ascii_case(qualifier)) {
                    if let Some(i) = qualified.iter().position(|q| q.eq_ignore_ascii_case(n)) {
                        *e = Expr::Literal(row.values[i].clone());
                    }
                }
            }
            Ok(())
        }
        Expr::Exists(q) | Expr::ScalarSubquery(q) => substitute(q, qualified, row, local),
        Expr::InSubquery { expr, query } => {
            substitute_expr(expr, qualified, row, local)?;
            substitute(query, qualified, row, local)
        }
        _ => visit_expr_children(e, |e| substitute_expr(e, qualified, row, local)),
    }
}
fn substitute(
    query: &mut Statement,
    qualified: &[String],
    row: &Row,
    shadowed: &[String],
) -> Result<(), PhobosError> {
    phobos_error::cancellation::check_now()?;
    match query {
        Statement::Union {
            left,
            right,
            limit,
            offset,
            ..
        } => {
            substitute(left, qualified, row, shadowed)?;
            substitute(right, qualified, row, shadowed)?;
            for e in [limit.as_mut(), offset.as_mut()].into_iter().flatten() {
                substitute_expr(e, qualified, row, shadowed)?;
            }
            Ok(())
        }
        Statement::Select {
            table,
            filter,
            limit,
            offset,
            ..
        } => {
            let mut local = shadowed.to_vec();
            local.push(table.clone());
            for e in [filter.as_mut(), limit.as_mut(), offset.as_mut()]
                .into_iter()
                .flatten()
            {
                substitute_expr(e, qualified, row, &local)?;
            }
            Ok(())
        }
        Statement::RelationalSelect(q) => {
            let mut local = shadowed.to_vec();
            local.push(q.alias.as_ref().unwrap_or(&q.table).clone());
            local.extend(
                q.joins
                    .iter()
                    .map(|j| j.alias.as_ref().unwrap_or(&j.table).clone()),
            );
            if let Some(source) = &mut q.source {
                substitute(source, qualified, row, &local)?;
            }
            for item in &mut q.items {
                match item {
                    SelectItem::Expression { expr, .. } => {
                        substitute_expr(expr, qualified, row, &local)?
                    }
                    SelectItem::Column { name, alias } => {
                        let mut e = Expr::Column(name.clone());
                        substitute_expr(&mut e, qualified, row, &local)?;
                        if matches!(e, Expr::Literal(_)) {
                            *item = SelectItem::Expression {
                                expr: e,
                                alias: Some(alias.clone().unwrap_or_else(|| name.clone())),
                            };
                        }
                    }
                    _ => (),
                }
            }
            for j in &mut q.joins {
                if let Some(e) = &mut j.predicate {
                    substitute_expr(e, qualified, row, &local)?;
                }
            }
            for e in [
                q.filter.as_mut(),
                q.having.as_mut(),
                q.limit.as_mut(),
                q.offset.as_mut(),
            ]
            .into_iter()
            .flatten()
            {
                substitute_expr(e, qualified, row, &local)?;
            }
            Ok(())
        }
        _ => Err(PhobosError::new(
            ErrorCode::Unsupported,
            "correlated input must be read-only",
        )),
    }
}
