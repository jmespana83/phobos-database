//! 0.2-K.4 Lazy Index Pruning V1.
//!
//! Under the persistent catalog capability `LAZY_INDEX_PRUNING_V1`, a reclaim
//! publication removes the exact entries of reclaimed versions only from
//! UNIQUE indexes (they take part in admission decisions). Entries of
//! non-unique indexes stay physically present ("stale") and are harmless:
//! every index-originated row access revalidates RID lifecycle state, key
//! and MVCC visibility (0.2-K Part H). A budgeted round-robin sweeper finds
//! stale entries outside the serialized commit step (statement view) and
//! removes them in a later reclaim publication, re-checking every candidate
//! inside serialized preparation and rewriting each leaf once.
//!
//! An entry is STALE iff its RID names a RETIRED, FREE or trimmed/vacant slot,
//! or an occupied slot whose version's index key differs from the entry's
//! key. An occupied slot with the same key is LIVE (slot reuse under the same
//! key is absorbed: `(key, RID)` is a set).
use super::*;
use phobos_txn::mvcc::sessions::Session;
use phobos_wal::v2::FileId;

/// `PHOBOS_LAZY_INDEX=0` keeps eager exact pruning for every index (and
/// never enables the capability). Default: lazy for non-unique indexes.
#[must_use]
pub fn lazy_index_requested() -> bool {
    std::env::var("PHOBOS_LAZY_INDEX").map_or(true, |value| value != "0")
}

/// Stale entries removed by sweeper publications (process-wide counter;
/// read into `ReclaimMetrics::sweep_stale_pruned`).
pub(super) static PRUNED: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn sweep_budget() -> usize {
    std::env::var("PHOBOS_LAZY_SWEEP_ENTRIES")
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .unwrap_or(4096)
        .clamp(16, 1 << 20)
}

/// Stale candidates of one sweep slice: per index, `(key, RID)` in index order.
pub(super) type PrunePlan = Vec<(IndexId, Vec<(IndexKey, RecordId)>)>;

/// Sweep cursor state (in memory; a restart starts a new cycle, which is
/// safe because stale entries are recognized from persistent state alone).
#[derive(Default)]
pub(super) struct SweepState {
    /// Round-robin position over `(table, index)` pairs.
    pub next: usize,
    /// Per index: last visited `(key, rid)`; `None` = start of the index.
    pub cursor: BTreeMap<IndexId, Option<(IndexKey, RecordId)>>,
    /// Stale entries created by lazy reclaim since the sweeper last completed
    /// a full cycle over every lazy index (drives the worker's wake-ups).
    pub debt: u64,
    /// Indexes whose current cycle has not wrapped yet.
    pub cycling: BTreeSet<IndexId>,
    /// Entries visited by the last complete cycle (all lazy indexes), and by
    /// the current one: the trigger keeps the stale ratio near
    /// `1 / SWEEP_TRIGGER_DIVISOR` so each cycle prunes many entries per
    /// entry inspected.
    pub last_cycle_entries: u64,
    pub cycle_entries: u64,
}

/// A sweep cycle starts once lazily created stale entries reach this many,
/// or `1 / SWEEP_TRIGGER_DIVISOR` of the entries the last cycle visited.
const SWEEP_MIN_DEBT: u64 = 2048;
const SWEEP_TRIGGER_DIVISOR: u64 = 10;

fn sweep_divisor() -> u64 {
    std::env::var("PHOBOS_LAZY_SWEEP_DIVISOR")
        .ok()
        .and_then(|value| value.parse::<u64>().ok())
        .unwrap_or(SWEEP_TRIGGER_DIVISOR)
        .clamp(1, 1000)
}

impl SweepState {
    fn due(&self) -> bool {
        !self.cycling.is_empty()
            || self.debt >= SWEEP_MIN_DEBT.max(self.last_cycle_entries / sweep_divisor())
    }
}

impl MvccDatabase {
    pub(super) fn lazy_index_enabled(&self) -> Result<bool, PhobosError> {
        Ok(self.lock_database()?.catalog.lazy_index_pruning())
    }

    /// Whether reclaim passes may leave non-unique entries stale now.
    pub(super) fn lazy_index_active(&self) -> Result<bool, PhobosError> {
        Ok(self.lazy_allowed.load(std::sync::atomic::Ordering::Acquire)
            && self.lazy_index_enabled()?)
    }

    /// Diagnostics/tests: allow or forbid lazy non-unique pruning for later
    /// passes (forbidden = eager exact pruning of every index, the 0.2-K.3
    /// behavior). It never clears the persistent capability; stale entries
    /// already present remain legal and are still swept.
    pub fn set_lazy_index_pruning(&self, allowed: bool) {
        self.lazy_allowed
            .store(allowed, std::sync::atomic::Ordering::Release);
    }

    /// Diagnostics/tests: pause or resume the stale-index sweeper.
    pub fn set_lazy_index_sweep(&self, allowed: bool) {
        self.sweep_allowed
            .store(allowed, std::sync::atomic::Ordering::Release);
    }

    /// Enables `LAZY_INDEX_PRUNING_V1` if lazy pruning is allowed and some
    /// table has a non-unique index. Called when a writable primary opens
    /// (no statement can conflict) and retried by reclaim passes. A schema
    /// conflict with active transactions is not an error: the pass simply
    /// stays eager. Returns whether the capability is enabled.
    pub fn try_enable_lazy_index_pruning(&self) -> Result<bool, PhobosError> {
        if self.lazy_index_enabled()? {
            return Ok(true);
        }
        if !self.lazy_allowed.load(std::sync::atomic::Ordering::Acquire)
            || !self.has_lazy_candidates()?
        {
            return Ok(false);
        }
        let session = self.connect(super::reclaim::CAPABILITY_SESSION)?;
        let result = self.try_enable_with(&session);
        drop(session);
        result
    }

    pub(super) fn try_enable_with(&self, session: &Session) -> Result<bool, PhobosError> {
        match self.enable_lazy_index_capability(session) {
            Ok(()) => Ok(true),
            Err(error) if error.code == ErrorCode::TransactionState => {
                phobos_observability::event("mvcc.lazy_index_enable_deferred", 1);
                Ok(false)
            }
            Err(error) => Err(error),
        }
    }

    /// Whether any table has a non-unique index (the only indexes made lazy).
    pub(super) fn has_lazy_candidates(&self) -> Result<bool, PhobosError> {
        let database = self.lock_database()?;
        Ok(database.catalog.indexes().any(|index| !index.unique))
    }

    /// Persistently enables `LAZY_INDEX_PRUNING_V1` through a schema
    /// publication: the new catalog image (version 3, capability bit set) is
    /// logged as WAL metadata and installed atomically, exactly like DDL, so
    /// crash recovery, backups, physical replication and PITR all carry it.
    /// Until this publication no stale entry can exist; after it, binaries
    /// without the capability refuse to open the database.
    pub(super) fn enable_lazy_index_capability(
        &self,
        session: &Session,
    ) -> Result<(), PhobosError> {
        if self.lazy_index_enabled()? {
            return Ok(());
        }
        session.begin_deferred()?;
        let result = (|| {
            let stable = session.ensure_transaction_id()?;
            let mut writes = SessionWrites::new(stable, 64 * 1024 * 1024)?;
            let lease = self.sessions.acquire_schema(stable)?;
            let (root, mut catalog, stats) = {
                let database = self.lock_database()?;
                let root = database
                    .data_dir
                    .join(format!(".phobos-mvcc-schema-{stable}"));
                fs::create_dir(&root)?;
                for file in [FileId::Tables, FileId::Indexes] {
                    fs::copy(database.data_dir.join(file.name()), root.join(file.name()))?;
                }
                persist_statistics(&root, &database.stats)?;
                (root, database.catalog.clone(), database.stats.clone())
            };
            catalog.redirect_persistence(&root)?;
            catalog.enable_capabilities(phobos_catalog::CAPABILITY_LAZY_INDEX_PRUNING_V1)?;
            writes.schema = Some(Arc::new(super::schema::Schema::new(
                root, catalog, stats, lease,
            )));
            self.commit(session, writes)
        })();
        if result.is_err() {
            let _ = session.rollback();
        } else {
            phobos_observability::event("mvcc.lazy_index_capability_enabled", 1);
        }
        result
    }

    /// Plans one bounded sweep slice over the next lazy (non-unique) index of
    /// `table` (or of the next table in rotation when `table` is `None`):
    /// visits at most the sweep budget of entries from the index's cursor on
    /// the statement view and returns the stale candidates (index order).
    pub(super) fn plan_index_sweep(
        &self,
        view: &mut SqlStatement<'_>,
        table: Option<TableId>,
    ) -> Result<Option<(TableId, PrunePlan)>, PhobosError> {
        let lazy: Vec<(TableId, IndexSchema)> = view
            .database
            .catalog
            .indexes()
            .filter(|index| !index.unique)
            .filter(|index| table.is_none_or(|table| index.table_id == table))
            .map(|index| (index.table_id, index.clone()))
            .collect();
        if lazy.is_empty() {
            return Ok(None);
        }
        let (position, cursor) = {
            let state = self
                .sweep_state
                .lock()
                .map_err(|_| self.fault_maintenance("lazy index sweep state poisoned"))?;
            let position = state.next % lazy.len();
            let id = lazy[position].1.id;
            (position, state.cursor.get(&id).cloned().flatten())
        };
        let (table_id, definition) = lazy[position].clone();
        let budget = sweep_budget();
        let schema = view
            .database
            .catalog
            .tables()
            .find(|schema| schema.id == table_id)
            .cloned()
            .ok_or_else(|| write_conflict("lazy sweep table missing"))?;
        let mut entries = Vec::with_capacity(budget.min(4096));
        {
            let tree = view
                .database
                .indexes
                .get_mut(&definition.id)
                .ok_or_else(|| write_conflict("lazy sweep index missing"))?;
            let lower = match &cursor {
                Some((key, _)) => phobos_index::Bound::Included(key),
                None => phobos_index::Bound::Unbounded,
            };
            tree.range_visit_keyed(lower, phobos_index::Bound::Unbounded, |key, rid| {
                if let Some((after_key, after_rid)) = &cursor {
                    if key == after_key && rid <= *after_rid {
                        return Ok(true);
                    }
                }
                entries.push((key.clone(), rid));
                Ok(entries.len() < budget)
            })?;
        }
        let wrapped = entries.len() < budget;
        let heap = view.database.heap_mut(table_id)?;
        let mut stale = Vec::new();
        for (key, rid) in &entries {
            match heap.get_version(*rid)? {
                None => {
                    if heap.slot_reclaimed(*rid)? {
                        stale.push((key.clone(), *rid));
                    }
                }
                Some((_, row)) => {
                    if index_key_for_row(&schema, &definition, &row)? != *key {
                        stale.push((key.clone(), *rid));
                    }
                }
            }
        }
        phobos_observability::event("mvcc.lazy_sweep_entries_inspected", entries.len() as u64);
        {
            let mut state = self
                .sweep_state
                .lock()
                .map_err(|_| self.fault_maintenance("lazy index sweep state poisoned"))?;
            let next_cursor = if wrapped {
                None
            } else {
                entries.last().cloned()
            };
            state.cursor.insert(definition.id, next_cursor);
            state.cycle_entries += entries.len() as u64;
            if wrapped {
                state.next = position + 1;
                state.cycling.remove(&definition.id);
                if state.cycling.is_empty() {
                    state.debt = 0;
                    state.last_cycle_entries = state.cycle_entries;
                    state.cycle_entries = 0;
                }
            } else {
                state.cycling.insert(definition.id);
            }
        }
        if let Ok(mut state) = self.reclaim_state.lock() {
            state.metrics.sweep_entries_inspected += entries.len() as u64;
            state.metrics.sweep_stale_found += stale.len() as u64;
            if wrapped {
                state.metrics.sweep_cycles += 1;
            }
        }
        if stale.is_empty() {
            return Ok(None);
        }
        Ok(Some((table_id, vec![(definition.id, stale)])))
    }

    /// Sweep work is due: a cycle is in progress, or enough stale entries
    /// accumulated since the last complete cycle (bounded stale ratio).
    pub(super) fn sweep_pending(&self) -> bool {
        self.sweep_state.lock().is_ok_and(|state| state.due())
    }

    pub(super) fn note_lazy_stale(&self, created: u64) {
        if created == 0 {
            return;
        }
        if let Ok(mut state) = self.sweep_state.lock() {
            state.debt = state.debt.saturating_add(created);
        }
    }
}

/// Inside serialized preparation: re-check every sweep candidate against the
/// current (rebased) heap and remove only those still stale. Returns the
/// number of entries removed.
pub(super) fn prune_stale_entries(
    database: &mut Database,
    table: TableId,
    prune: &[(IndexId, Vec<(IndexKey, RecordId)>)],
    stable: u64,
) -> Result<u64, PhobosError> {
    let mut removed_total = 0;
    for (index_id, candidates) in prune {
        let Some(definition) = database
            .catalog
            .indexes()
            .find(|index| index.id == *index_id)
            .cloned()
        else {
            continue; // dropped since planning
        };
        if definition.unique || definition.table_id != table {
            return Err(write_conflict("lazy sweep targets a non-lazy index"));
        }
        let schema = database.heaps[&table].schema().clone();
        let mut confirmed = Vec::with_capacity(candidates.len());
        {
            let heap = database.heap_mut(table)?;
            for (key, rid) in candidates {
                let stale = match heap.get_version(*rid)? {
                    None => heap.slot_reclaimed(*rid)?,
                    Some((_, row)) => index_key_for_row(&schema, &definition, &row)? != *key,
                };
                if stale {
                    confirmed.push((key.clone(), *rid));
                } else {
                    phobos_observability::event("mvcc.lazy_sweep_recheck_kept", 1);
                }
            }
        }
        if confirmed.is_empty() {
            continue;
        }
        confirmed.sort();
        let tree = database
            .indexes
            .get_mut(index_id)
            .ok_or_else(|| write_conflict("lazy sweep index missing"))?;
        let removed = tree.delete_versions_sorted(&confirmed, stable)?;
        let count = removed.iter().filter(|removed| **removed).count() as u64;
        phobos_observability::event("mvcc.lazy_sweep_pruned", count);
        removed_total += count;
    }
    Ok(removed_total)
}
