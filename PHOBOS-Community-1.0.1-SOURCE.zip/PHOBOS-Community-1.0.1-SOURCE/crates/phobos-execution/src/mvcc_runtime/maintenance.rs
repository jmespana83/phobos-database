//! 0.2-K Part K: bounded automatic reclamation.
//!
//! One worker thread per database, owned by whoever owns the database handle
//! (the server's `Coordinator`; embedded callers may start one explicitly).
//! It is event-driven, never a free-running loop:
//!
//! * it sleeps on a condition variable until a publication records new
//!   candidate pages (`MvccDatabase::note_candidate_pages`) or, only while a
//!   horizon-blocked backlog exists, until a bounded poll interval elapses
//!   (a snapshot release advances the horizon without any publication);
//! * on wake-up it runs reclaim passes only while the backlog of candidate
//!   pages that can make progress at the current horizon is at least
//!   `trigger_pages`, or new publications have accumulated since the last
//!   pass (so small, hot tables are maintained too); it stops as soon as a
//!   pass makes no progress or the backlog falls below the trigger;
//! * every pass is budgeted (`pages_per_pass` candidate pages, at most 8192
//!   dead versions), serialized with every other pass (`reclaim_lock`), and
//!   followed by a pause that bounds the worker's duty cycle (capped at
//!   `max_pause`, skipped while the eligible backlog exceeds one full pass);
//! * tables are served round-robin and pages rotate within a table
//!   (`reclaim.rs`), so no table or page range starves the others.
//!
//! The worker never runs on a physical standby (the server does not start
//! it for a read-only data directory) and stops before shutdown.
use super::*;
use std::sync::Condvar;
use std::time::Duration;

/// Tunables of the automatic reclamation worker.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MaintenanceConfig {
    /// Candidate pages one pass inspects.
    pub pages_per_pass: usize,
    /// Wake-up threshold: eligible candidate pages ...
    pub trigger_pages: usize,
    /// ... or publications since the last pass.
    pub trigger_publications: u64,
    /// Upper bound on passes per wake-up.
    pub max_passes_per_wake: usize,
    /// Share of wall time the worker may spend inside passes (1..=100).
    pub duty_cycle_percent: u32,
    /// Upper bound of one duty-cycle pause.
    pub max_pause: Duration,
    /// 0.2-K.2: minimum interval between two maintenance publications unless
    /// a full pass of eligible pages is waiting (catch-up). Every reclaim
    /// pass is one durable publication (one WAL force) competing with
    /// foreground commits; batching pages over this interval bounds that
    /// competition to about `1 / min_interval` publications per second while
    /// a small backlog is still taken within the interval.
    pub min_interval: Duration,
    /// 0.2-K.2: longest time a due pass waits for a gap in the foreground
    /// commit pipeline before publishing anyway. Maintenance publishes when
    /// no user commit is queued or running; under continuous load it is
    /// deferred at most this long, so reclamation keeps pace (bounded
    /// storage) while coalescing more pages into each publication.
    pub yield_window: Duration,
    /// When a candidate page is worth an automatic rewrite.
    pub worth: reclaim::WorthPolicy,
    /// Re-check interval while only horizon-blocked work is pending.
    pub blocked_poll: Duration,
    /// Minimum interval between opportunistic status-freeze attempts.
    pub freeze_interval: Duration,
}
impl Default for MaintenanceConfig {
    fn default() -> Self {
        Self {
            pages_per_pass: 512,
            trigger_pages: 8,
            trigger_publications: 64,
            max_passes_per_wake: 64,
            duty_cycle_percent: 50,
            max_pause: Duration::from_millis(50),
            min_interval: Duration::from_millis(100),
            yield_window: Duration::from_millis(1000),
            worth: reclaim::WorthPolicy {
                min_versions: 4,
                max_age: Duration::from_secs(10),
            },
            blocked_poll: Duration::from_millis(250),
            freeze_interval: Duration::from_secs(2),
        }
    }
}
impl MaintenanceConfig {
    /// Defaults, overridable through `PHOBOS_AUTO_RECLAIM_*` environment
    /// variables (benchmarks and tests). Invalid values are refused.
    pub fn from_env() -> Result<Self, PhobosError> {
        let mut config = Self::default();
        let read = |name: &str| -> Result<Option<u64>, PhobosError> {
            match std::env::var(name) {
                Ok(value) => value.parse::<u64>().map(Some).map_err(|_| {
                    PhobosError::new(ErrorCode::ResourceLimit, format!("invalid {name}"))
                }),
                Err(_) => Ok(None),
            }
        };
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_PAGES")? {
            config.pages_per_pass = (value as usize).clamp(1, 4096);
        }
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_TRIGGER_PAGES")? {
            config.trigger_pages = (value as usize).max(1);
        }
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_TRIGGER_PUBLICATIONS")? {
            config.trigger_publications = value.max(1);
        }
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_DUTY_PERCENT")? {
            config.duty_cycle_percent = (value as u32).clamp(1, 100);
        }
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_MIN_INTERVAL_MS")? {
            config.min_interval = Duration::from_millis(value.clamp(1, 60_000));
        }
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_MIN_VERSIONS")? {
            config.worth.min_versions = (value as u32).clamp(1, 1024);
        }
        if let Some(value) = read("PHOBOS_AUTO_RECLAIM_YIELD_MS")? {
            config.yield_window = Duration::from_millis(value.min(60_000));
        }
        Ok(config)
    }
    /// Whether automatic reclamation is enabled (`PHOBOS_AUTO_RECLAIM=0`
    /// disables it; default on).
    #[must_use]
    pub fn enabled_from_env() -> bool {
        std::env::var("PHOBOS_AUTO_RECLAIM").map_or(true, |value| value != "0")
    }
}

#[derive(Default)]
struct SignalState {
    publications: u64,
    stop: bool,
}

/// Wake-up channel between publications and the worker.
#[derive(Default)]
pub(super) struct Signal {
    state: Mutex<SignalState>,
    changed: Condvar,
}
impl Signal {
    pub(super) fn notify_publication(&self) {
        if let Ok(mut state) = self.state.lock() {
            state.publications = state.publications.wrapping_add(1);
        }
        self.changed.notify_one();
    }
    pub(super) fn stop(&self) {
        if let Ok(mut state) = self.state.lock() {
            state.stop = true;
        }
        self.changed.notify_all();
    }
    fn stopped(&self) -> bool {
        self.state.lock().map_or(true, |state| state.stop)
    }
    /// Wait until stopped, until `publications` changes, or for `timeout`.
    /// Returns (stopped, current publication count).
    fn wait(&self, seen: u64, timeout: Option<Duration>) -> (bool, u64) {
        let Ok(mut state) = self.state.lock() else {
            return (true, seen);
        };
        loop {
            if state.stop {
                return (true, state.publications);
            }
            if state.publications != seen {
                return (false, state.publications);
            }
            match timeout {
                None => {
                    state = match self.changed.wait(state) {
                        Ok(state) => state,
                        Err(_) => return (true, seen),
                    };
                }
                Some(timeout) => {
                    let (next, result) = match self.changed.wait_timeout(state, timeout) {
                        Ok(pair) => pair,
                        Err(_) => return (true, seen),
                    };
                    state = next;
                    if result.timed_out() {
                        return (state.stop, state.publications);
                    }
                }
            }
        }
    }
    /// Interruptible pause; returns whether the worker was stopped.
    fn pause(&self, duration: Duration) -> bool {
        let Ok(state) = self.state.lock() else {
            return true;
        };
        if state.stop {
            return true;
        }
        match self
            .changed
            .wait_timeout_while(state, duration, |state| !state.stop)
        {
            Ok((state, _)) => state.stop,
            Err(_) => true,
        }
    }
    fn publications(&self) -> u64 {
        self.state.lock().map_or(0, |state| state.publications)
    }
}

/// Handle of a running maintenance worker. Dropping it stops and joins it.
pub struct MaintenanceWorker {
    signal: Arc<Signal>,
    handle: Option<std::thread::JoinHandle<()>>,
}
impl MaintenanceWorker {
    /// Starts the worker for `database`.
    pub fn start(
        database: Arc<MvccDatabase>,
        config: MaintenanceConfig,
    ) -> Result<Self, PhobosError> {
        let signal = database.maintenance.clone();
        if signal.stopped() {
            return Err(write_conflict("database maintenance already stopped"));
        }
        let handle = std::thread::Builder::new()
            .name("phobos-reclaim".into())
            .spawn(move || {
                let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    worker_loop(&database, config);
                }));
                if result.is_err() {
                    phobos_observability::event("maintenance.worker_panicked", 1);
                    // 0.2-K.1: fail safe and say so (CHECKPOINT, reclaim_once
                    // and diagnostics report it; restart resumes).
                    let _ = database.fault_maintenance("the maintenance worker panicked");
                }
            })?;
        Ok(Self {
            signal,
            handle: Some(handle),
        })
    }
    /// Stops the worker and waits for its current pass to finish.
    pub fn stop(&mut self) {
        self.signal.stop();
        if let Some(handle) = self.handle.take() {
            let _ = handle.join();
        }
    }
}
impl Drop for MaintenanceWorker {
    fn drop(&mut self) {
        self.stop();
    }
}

fn worker_loop(database: &MvccDatabase, config: MaintenanceConfig) {
    let _maintenance = phobos_error::cancellation::suspend();
    phobos_observability::mark_maintenance_thread();
    let Ok(session) = database.connect(reclaim::MAINTENANCE_SESSION) else {
        phobos_observability::event("maintenance.connect_failed", 1);
        return;
    };
    let signal = database.maintenance.clone();
    let mut seen = signal.publications();
    let mut since_pass = 0u64;
    let mut last_freeze = Instant::now();
    let mut blocked_backlog = true; // probe once after open (header rebuild)
    let mut pending_backlog = false;
    let mut last_pass: Option<Instant> = None;
    loop {
        // 0.2-K.2: an eligible backlog below the catch-up size is taken when
        // `min_interval` has elapsed, even without new publications.
        let timeout = if pending_backlog {
            Some(config.min_interval)
        } else {
            blocked_backlog.then_some(config.blocked_poll)
        };
        let (stopped, now) = signal.wait(seen, timeout);
        if stopped || database.fenced.load(std::sync::atomic::Ordering::Acquire) {
            break;
        }
        since_pass = since_pass.saturating_add(now.wrapping_sub(seen));
        seen = now;
        let mut passes = 0;
        loop {
            if passes >= config.max_passes_per_wake || signal.stopped() {
                break;
            }
            let Ok((_, horizon, _)) = database.sessions.publication_state() else {
                return;
            };
            let (eligible, total, rebuilding) = match database.reclaim_state.lock() {
                Ok(state) => (
                    state.eligible_total(horizon, Some(config.worth)),
                    state.candidate_total(),
                    state.rebuild_pending(),
                ),
                Err(_) => return,
            };
            blocked_backlog = total > eligible;
            // 0.2-K.4: pending lazy-index sweep work keeps the worker waking
            // (at most once per `min_interval`) until a full cycle completes.
            let sweep = database.sweep_pending();
            pending_backlog = eligible > 0 || sweep;
            // 0.2-K.2: batch reclaim publications. A pass runs at once only
            // for catch-up (a full pass of eligible pages) or the post-open
            // header scan; otherwise at most once per `min_interval`, taking
            // everything eligible by then in one publication.
            let interval_elapsed =
                last_pass.is_none_or(|at: Instant| at.elapsed() >= config.min_interval);
            let due = rebuilding
                || eligible >= config.pages_per_pass
                || ((eligible > 0 || sweep) && interval_elapsed)
                || (eligible > 0 && since_pass >= config.trigger_publications.saturating_mul(16));
            if !due {
                break;
            }
            if !rebuilding && !config.yield_window.is_zero() {
                // 0.2-K.2: do not compete with user commits as if this were
                // another user transaction: wait for a gap in the commit
                // pipeline, bounded by the yield window.
                let waiting = Instant::now();
                while database.commit_pipeline_busy() && waiting.elapsed() < config.yield_window {
                    if signal.pause(Duration::from_millis(1)) {
                        return;
                    }
                }
                if waiting.elapsed() >= config.yield_window {
                    phobos_observability::event("maintenance.yield_window_expired", 1);
                }
            }
            last_pass = Some(Instant::now());
            let started = Instant::now();
            let report =
                database.reclaim_with_session(&session, config.pages_per_pass, Some(config.worth));
            let elapsed = started.elapsed();
            match report {
                Ok(report) => {
                    since_pass = 0;
                    passes += 1;
                    if let Ok(mut state) = database.reclaim_state.lock() {
                        state.metrics.automatic_passes += 1;
                    }
                    phobos_observability::event("maintenance.automatic_passes", 1);
                    let progress = report.pages_compacted > 0
                        || (rebuilding && report.pages_examined + report.pages_deferred > 0);
                    if !progress && !rebuilding {
                        break;
                    }
                    if !progress && report.bookkeeping_complete {
                        break;
                    }
                }
                Err(_) => {
                    phobos_observability::event("maintenance.pass_failed", 1);
                    if database.maintenance_fault.get().is_some() {
                        // 0.2-K.1: faulted maintenance stays stopped.
                        return;
                    }
                    if database.fenced.load(std::sync::atomic::Ordering::Acquire) {
                        return;
                    }
                    // The pass rolled back; leave the session usable.
                    let _ = session.rollback();
                    if signal.pause(Duration::from_secs(1)) {
                        return;
                    }
                    break;
                }
            }
            // Duty cycle: pause in proportion to the pass just run, capped
            // (`max_pause`) so that a pass stalled by I/O (a slow WAL force or
            // checkpoint) is not followed by an equally long pause in which
            // the backlog grows unchecked. In catch-up (the eligible backlog
            // still exceeds one full pass) the worker does not pause at all.
            let duty = config.duty_cycle_percent.clamp(1, 100);
            let catch_up = match (
                database.sessions.publication_state(),
                database.reclaim_state.lock(),
            ) {
                (Ok((_, horizon, _)), Ok(state)) => {
                    state.eligible_total(horizon, Some(config.worth)) >= config.pages_per_pass
                }
                _ => false,
            };
            if duty < 100 && !catch_up {
                let pause = elapsed
                    .mul_f64(f64::from(100 - duty) / f64::from(duty))
                    .min(config.max_pause);
                if signal.pause(pause) {
                    return;
                }
            }
        }
        // Opportunistic logical status freeze (needs an idle database).
        if last_freeze.elapsed() >= config.freeze_interval
            && database.sessions.is_idle().unwrap_or(false)
        {
            last_freeze = Instant::now();
            let _ = database.freeze_once(CHECKPOINT_RECLAIM_PAGES);
        }
    }
    drop(session);
}
