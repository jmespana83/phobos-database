use super::*;
use std::time::Duration;
#[test]
fn c5_pinned_horizon_then_freeze_preserves_visibility_and_restart() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(db.freeze_metrics().unwrap().0, 1);
    let session = db.connect(90).unwrap();
    let mut old = db.statement(&session, None).unwrap();
    db.execute(1, "UPDATE t SET v=v+10000").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=900").unwrap();
    let reclaimed = db.reclaim_once(64).unwrap();
    assert_eq!(reclaimed.versions_reclaimed, 0);
    assert!(db.freeze_once(64).unwrap().deferred_busy);
    assert_eq!(db.freeze_metrics().unwrap().0, 1);
    assert_eq!(
        old.execute("SELECT v FROM t WHERE id=5", &[]).unwrap(),
        QueryResult::Rows {
            columns: vec!["v".into()],
            rows: vec![Row::new(vec![Value::Int64(5)])]
        }
    );
    assert_eq!(
        old.execute("SELECT COUNT(*) AS n FROM t", &[]).unwrap(),
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(1000)])]
        }
    );
    drop(old);
    drop(session);
    db.disconnect(90);
    assert!(db.reclaim_once(64).unwrap().versions_reclaimed >= 1000);
    for _ in 0..32 {
        if db.freeze_once(1).unwrap().sweep_complete {
            break;
        }
    }
    let boundary = db.freeze_metrics().unwrap().0;
    assert!(boundary > 1);
    let reads = db.sessions.status_metrics().status_page_reads;
    assert!(db.sessions.lookup(1).is_err());
    assert_eq!(db.sessions.status_metrics().status_page_reads, reads);
    let expected = db.execute(1, "SELECT id,v FROM t ORDER BY id").unwrap();
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "UPDATE t SET v=0 WHERE id=5").unwrap();
    assert!(db.freeze_once(64).unwrap().deferred_busy);
    db.execute(2, "ROLLBACK").unwrap();
    assert_eq!(
        db.execute(1, "SELECT id,v FROM t ORDER BY id").unwrap(),
        expected
    );
    db.disconnect(1);
    db.disconnect(2);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(db.freeze_metrics().unwrap().0, boundary);
    assert_eq!(
        db.execute(1, "SELECT id,v FROM t ORDER BY id").unwrap(),
        expected
    );
    eprintln!(
        "C5 pinned boundary 1 held; after release {boundary}; reopen IDs examined {}",
        db.freeze_metrics().unwrap().1
    );
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c4_bounded_sweep_restarts_after_allocation_and_live_references_hold_boundary() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let first = db.freeze_once(1).unwrap();
    assert_eq!(first.pages_examined, 1);
    assert!(!first.sweep_complete);
    // D1: a plain BEGIN/ROLLBACK allocates nothing and cannot disturb the
    // sweep; the first write allocates the identity that resets it.
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    assert_eq!(db.freeze_once(1).unwrap().pages_examined, 1);
    assert_eq!(db.freeze_state.lock().unwrap().page, 2);
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v WHERE id=1").unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    let next = db.freeze_once(1).unwrap();
    assert_eq!(next.pages_examined, 1);
    assert_eq!(
        db.freeze_state.lock().unwrap().page,
        1,
        "allocation invalidates the earlier proof"
    );
    for _ in 0..32 {
        if db.freeze_once(1).unwrap().sweep_complete {
            break;
        }
    }
    assert_eq!(
        db.freeze_metrics().unwrap().0,
        1,
        "surviving seed tuples retain creator status"
    );
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
