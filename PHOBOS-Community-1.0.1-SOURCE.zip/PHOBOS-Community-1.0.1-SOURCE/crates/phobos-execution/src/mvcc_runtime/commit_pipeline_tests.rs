//! 0.2-G: commit-pipeline changes — Stage A / Stage B in place under the
//! database mutex, store entry through the verified-image proof (resident
//! "produced in process" path and the spilled full-validation path), shared
//! reader handles. Every test checks the unchanged contract: atomic
//! visibility, snapshot isolation, UNIQUE, index/heap parity, recovery.
//!
//! Fixture: `t(id,v,g)` with 1000 committed rows (`v = id`), unique `u(id)`,
//! composite unique `c(v,g)`, non-unique `d(g)`.
use super::*;
use std::{
    sync::{Arc, Barrier, mpsc},
    thread,
    time::Duration,
};
use tests::fixture;

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            Value::Null => 0,
            ref other => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}
fn count(db: &MvccDatabase, session: u64, predicate: &str) -> i64 {
    scalar(
        db,
        session,
        &format!("SELECT COUNT(*) AS n FROM t WHERE {predicate}"),
    )
}
fn validate_all(db: &MvccDatabase) -> usize {
    let mut database = db.lock_database().unwrap();
    database
        .indexes
        .values_mut()
        .map(|tree| tree.validate().unwrap().entries)
        .sum()
}
fn dump(db: &MvccDatabase, session: u64) -> Vec<Vec<Value>> {
    match db
        .execute(session, "SELECT id, v, g FROM t ORDER BY id")
        .unwrap()
    {
        QueryResult::Rows { rows, .. } => rows.into_iter().map(|row| row.values).collect(),
        other => panic!("dump {other:?}"),
    }
}
fn rows(from: i64, to: i64) -> String {
    (from..to)
        .map(|n| format!("({n},{n},{})", n % 97))
        .collect::<Vec<_>>()
        .join(",")
}
fn close(db: Arc<MvccDatabase>, sessions: impl IntoIterator<Item = u64>, root: &Path) {
    for session in sessions {
        db.disconnect(session);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// G1 (publication 1–3, 6–8): a transaction touching several heap pages and
/// leaves of three indexes is invisible to an older snapshot and completely
/// visible to a newer one, through both store-entry paths (a small resident
/// transaction and a large one whose private pages spill).
#[test]
fn g1_multi_page_multi_index_publication_is_atomic_for_snapshots() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(9, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    assert_eq!(count(&db, 9, "id>=100000"), 0);
    // Resident path: a few pages.
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", rows(100_000, 100_020)),
    )
    .unwrap();
    // Spilled path: many pages in one transaction.
    db.execute(1, "BEGIN").unwrap();
    for batch in 0..6 {
        let from = 200_000 + batch * 500;
        db.execute(
            1,
            &format!("INSERT INTO t VALUES {}", rows(from, from + 500)),
        )
        .unwrap();
    }
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(count(&db, 9, "id>=100000"), 0, "old snapshot unchanged");
    assert_eq!(count(&db, 9, "g=5 AND id>=100000"), 0);
    db.execute(9, "COMMIT").unwrap();
    assert_eq!(count(&db, 2, "id>=100000 AND id<100020"), 20);
    assert_eq!(count(&db, 2, "id>=200000"), 3000);
    assert_eq!(
        count(&db, 2, "g=5 AND id>=100000"),
        (100_000..100_020)
            .chain(200_000..203_000)
            .filter(|n| n % 97 == 5)
            .count() as i64
    );
    let entries = validate_all(&db);
    assert_eq!(entries, 3 * (1000 + 3020));
    close(db, [1, 2, 9], &root);
}

/// G2 (publication 5, 9): a UNIQUE conflict inside a batch-shaped workload
/// aborts only its member; nothing of it is published.
#[test]
fn g2_unique_conflict_member_aborts_alone_with_nothing_published() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let before = validate_all(&db);
    let error = db
        .execute(1, "INSERT INTO t VALUES (300000,300000,1),(5,9,9)")
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ConstraintViolation);
    assert_eq!(count(&db, 2, "id=300000"), 0);
    assert_eq!(validate_all(&db), before);
    db.execute(1, "INSERT INTO t VALUES (300000,300000,1)")
        .unwrap();
    assert_eq!(count(&db, 2, "id=300000"), 1);
    close(db, [1, 2], &root);
}

/// G3 (race 16): sixteen sessions on a barrier, half on the shared hot table
/// (in-place Stage A batches), half also touching a second table (parallel
/// wave domains), interleaved with snapshot readers. Exact final counts,
/// one owner per contested UNIQUE key, valid trees.
#[test]
fn g3_sixteen_sessions_in_place_and_wave_paths_preserve_unique_and_counts() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(90, "CREATE TABLE s (id BIGINT NOT NULL, w BIGINT)")
        .unwrap();
    db.execute(90, "CREATE UNIQUE INDEX su ON s(id)").unwrap();
    let barrier = Arc::new(Barrier::new(16));
    let handles = (1..=16u64)
        .map(|session| {
            let db = db.clone();
            let barrier = barrier.clone();
            thread::spawn(move || {
                barrier.wait();
                let mut won = 0;
                for k in 0..30i64 {
                    let id = 400_000 + k * 16 + session as i64;
                    db.execute(session, &format!("INSERT INTO t VALUES ({id},{id},NULL)"))
                        .unwrap();
                    if session % 2 == 0 {
                        db.execute(session, &format!("INSERT INTO s VALUES ({id},{k})"))
                            .unwrap();
                    }
                    if k % 5 == 0 {
                        let hot = 500_000 + k;
                        match db
                            .execute(session, &format!("INSERT INTO t VALUES ({hot},{hot},NULL)"))
                        {
                            Ok(_) => won += 1,
                            Err(error) => assert!(matches!(
                                error.code,
                                ErrorCode::ConstraintViolation | ErrorCode::TransactionState
                            )),
                        }
                    }
                }
                won
            })
        })
        .collect::<Vec<_>>();
    let won: i64 = handles.into_iter().map(|h| h.join().unwrap()).sum();
    assert_eq!(won, 6);
    assert_eq!(count(&db, 99, "id>=400000 AND id<500000"), 16 * 30);
    assert_eq!(count(&db, 99, "id>=500000"), 6);
    assert_eq!(scalar(&db, 99, "SELECT COUNT(*) AS n FROM s"), 8 * 30);
    validate_all(&db);
    close(db, (1..=16).chain([90, 99]), &root);
}

/// G4 (publication 10, Part Z 14): recovery, then more publications through
/// the in-place stages; a checkpoint between them.
#[test]
fn g4_recovery_and_checkpoint_between_publications() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", rows(600_000, 600_400)),
    )
    .unwrap();
    db.execute(1, "CHECKPOINT").unwrap();
    db.execute(1, "UPDATE t SET g=g+1 WHERE id>=600000 AND id<600010")
        .unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=600390").unwrap();
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    validate_all(&db);
    assert_eq!(count(&db, 2, "id>=600000"), 390);
    db.execute(
        2,
        &format!("INSERT INTO t VALUES {}", rows(600_390, 600_400)),
    )
    .unwrap();
    db.execute(2, "CHECKPOINT").unwrap();
    db.execute(2, "INSERT INTO t VALUES (600400,600400,1)")
        .unwrap();
    assert_eq!(count(&db, 2, "id>=600000"), 401);
    assert_eq!(
        db.execute(2, "INSERT INTO t VALUES (600005,0,0)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    validate_all(&db);
    close(db, [2], &root);
}

/// G5 (Part Z 18): the same logical changes applied as many small
/// transactions (resident images, produced-in-process proof) and as one
/// large transaction (spilled images, full validation) produce identical
/// final states.
#[test]
fn g5_resident_and_spilled_publication_paths_reach_identical_state() {
    let small = fixture();
    let large = fixture();
    let a = Arc::new(MvccDatabase::open(&small).unwrap());
    let b = Arc::new(MvccDatabase::open(&large).unwrap());
    for batch in 0..20 {
        let from = 700_000 + batch * 50;
        a.execute(
            1,
            &format!("INSERT INTO t VALUES {}", rows(from, from + 50)),
        )
        .unwrap();
    }
    a.execute(1, "UPDATE t SET g=7 WHERE id>=700100 AND id<700200")
        .unwrap();
    a.execute(1, "DELETE FROM t WHERE id>=700900").unwrap();
    b.execute(1, "BEGIN").unwrap();
    b.execute(
        1,
        &format!("INSERT INTO t VALUES {}", rows(700_000, 700_500)),
    )
    .unwrap();
    b.execute(
        1,
        &format!("INSERT INTO t VALUES {}", rows(700_500, 701_000)),
    )
    .unwrap();
    b.execute(1, "UPDATE t SET g=7 WHERE id>=700100 AND id<700200")
        .unwrap();
    b.execute(1, "DELETE FROM t WHERE id>=700900").unwrap();
    b.execute(1, "COMMIT").unwrap();
    assert_eq!(dump(&a, 2), dump(&b, 2));
    assert_eq!(count(&a, 2, "g=7"), count(&b, 2, "g=7"));
    validate_all(&a);
    validate_all(&b);
    close(a, [1, 2], &small);
    close(b, [1, 2], &large);
}

/// G6: maintenance that takes the database mutex (reclaim, CHECKPOINT)
/// runs concurrently with in-place Stage A/B without deadlock (lock order
/// commits -> database -> WAL), and every write survives.
#[test]
fn g6_maintenance_concurrent_with_in_place_stages_never_deadlocks() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let (done_tx, done_rx) = mpsc::channel();
    let writers = (1..=4u64)
        .map(|session| {
            let db = db.clone();
            thread::spawn(move || {
                for k in 0..60i64 {
                    let id = 800_000 + session as i64 * 1000 + k;
                    db.execute(session, &format!("INSERT INTO t VALUES ({id},{id},NULL)"))
                        .unwrap();
                    if k % 10 == 0 {
                        db.execute(session, &format!("DELETE FROM t WHERE id={id}"))
                            .unwrap();
                    }
                }
            })
        })
        .collect::<Vec<_>>();
    let maintenance = {
        let db = db.clone();
        thread::spawn(move || {
            for _ in 0..6 {
                db.execute(50, "CHECKPOINT").unwrap();
                db.reclaim_once(64).unwrap();
                thread::sleep(Duration::from_millis(5));
            }
            done_tx.send(()).unwrap();
        })
    };
    for writer in writers {
        writer.join().unwrap();
    }
    done_rx
        .recv_timeout(Duration::from_secs(120))
        .expect("maintenance finished (no deadlock)");
    maintenance.join().unwrap();
    assert_eq!(count(&db, 99, "id>=800000"), 4 * 54);
    validate_all(&db);
    close(db, [1, 2, 3, 4, 50, 99], &root);
}

/// G7 (publication V2 under concurrency): snapshot readers racing with
/// in-place publications through the produced-in-process store entry. Every
/// writer statement inserts a pair of rows (one heap page or two, three index
/// leaves); a reader must never see half a pair through either index, and a
/// snapshot must return the same answer for its whole lifetime.
#[test]
fn g7_snapshot_readers_never_observe_half_published_pairs() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let stop = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let writers = (1..=4u64)
        .map(|session| {
            let db = db.clone();
            thread::spawn(move || {
                let group = 1000 + session as i64;
                for k in 0..80i64 {
                    let a = 900_000 + session as i64 * 10_000 + 2 * k;
                    let b = a + 1;
                    db.execute(
                        session,
                        &format!("INSERT INTO t VALUES ({a},{a},{group}),({b},{b},{group})"),
                    )
                    .unwrap();
                }
            })
        })
        .collect::<Vec<_>>();
    let readers = (11..=12u64)
        .map(|session| {
            let db = db.clone();
            let stop = stop.clone();
            thread::spawn(move || {
                let mut checks = 0u32;
                while !stop.load(std::sync::atomic::Ordering::Acquire) || checks < 4 {
                    db.execute(session, "BEGIN ISOLATION LEVEL SNAPSHOT")
                        .unwrap();
                    for group in 1001..=1004i64 {
                        let by_group = count(&db, session, &format!("g={group}"));
                        let lo = 900_000 + (group - 1000) * 10_000;
                        let by_id =
                            count(&db, session, &format!("id>={lo} AND id<{}", lo + 10_000));
                        assert_eq!(by_group % 2, 0, "half a pair visible via d(g)");
                        assert_eq!(by_group, by_id, "u(id) and d(g) disagree");
                        assert_eq!(
                            count(&db, session, &format!("g={group}")),
                            by_group,
                            "snapshot changed"
                        );
                    }
                    db.execute(session, "COMMIT").unwrap();
                    checks += 1;
                }
                checks
            })
        })
        .collect::<Vec<_>>();
    for writer in writers {
        writer.join().unwrap();
    }
    stop.store(true, std::sync::atomic::Ordering::Release);
    for reader in readers {
        assert!(reader.join().unwrap() >= 4);
    }
    for group in 1001..=1004i64 {
        assert_eq!(count(&db, 99, &format!("g={group}")), 160);
    }
    assert_eq!(validate_all(&db), 3 * (1000 + 4 * 160));
    close(db, [1, 2, 3, 4, 11, 12, 99], &root);
}
