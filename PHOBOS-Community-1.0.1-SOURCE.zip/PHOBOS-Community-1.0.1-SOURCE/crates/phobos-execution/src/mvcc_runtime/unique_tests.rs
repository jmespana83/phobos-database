use super::*;
use std::time::Duration;
fn pair(nan: bool) -> (Value, Value) {
    if nan {
        (
            Value::Float64(f64::from_bits(0x7ff8000000000001)),
            Value::Float64(f64::from_bits(0xfff8000000000042)),
        )
    } else {
        (Value::Float64(0.0), Value::Float64(-0.0))
    }
}
fn setup() -> (PathBuf, Arc<MvccDatabase>) {
    let path = super::tests::fixture();
    let db = Arc::new(MvccDatabase::open(&path).unwrap());
    db.execute(80, "CREATE TABLE f (k DOUBLE, g BIGINT)")
        .unwrap();
    db.execute(80, "CREATE UNIQUE INDEX fu ON f(k,g)").unwrap();
    db.disconnect(80);
    (path, db)
}
fn stage(db: &MvccDatabase, id: u64, v: Value) -> Result<QueryResult, PhobosError> {
    let connection = db.connection(id)?;
    let mut guard = connection.lock().unwrap();
    // D1: BEGIN allocates nothing; the first write creates the session writes.
    db.ensure_writes(id, &mut guard)?;
    let sql_sessions::Connection {
        session, writes, ..
    } = &mut *guard;
    db.stage(
        session,
        writes.as_mut().unwrap(),
        "INSERT INTO f VALUES ($1,10)",
        &[v],
    )
}
fn finish(path: PathBuf, db: Arc<MvccDatabase>) {
    for id in [1, 2, 80] {
        db.disconnect(id);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(path).unwrap();
}
fn concurrent_order(nan: bool, owner: u64) {
    let (path, db) = setup();
    let (a, b) = pair(nan);
    db.execute(1, "BEGIN").unwrap();
    db.execute(2, "BEGIN").unwrap();
    // Younger transaction holds the key; older waits then rechecks after commit.
    stage(&db, owner, b).unwrap();
    let contender = 3 - owner;
    let other = db.clone();
    let thread = std::thread::spawn(move || {
        let staged = stage(&other, contender, a);
        if staged.is_ok() {
            other.execute(contender, "COMMIT").is_ok()
        } else {
            let _ = other.execute(contender, "ROLLBACK");
            false
        }
    });
    std::thread::sleep(Duration::from_millis(30));
    db.execute(owner, "COMMIT").unwrap();
    let second = thread.join().unwrap();
    finish(path, db);
    assert!(!second, "both canonical duplicates committed");
}
#[test]
fn a12_concurrent_zero() {
    concurrent_order(false, 1);
    concurrent_order(false, 2);
}
#[test]
fn a12_concurrent_nan() {
    concurrent_order(true, 1);
    concurrent_order(true, 2);
}
fn bulk(nan: bool, existing: bool) {
    let (path, db) = setup();
    let (a, b) = pair(nan);
    if existing {
        db.execute(1, "BEGIN").unwrap();
        stage(&db, 1, a.clone()).unwrap();
        db.execute(1, "COMMIT").unwrap();
    }
    db.bulk_begin(1, "f").unwrap();
    let mut rows = vec![Row::new(vec![b, Value::Int64(10)])];
    if !existing {
        rows.push(Row::new(vec![a, Value::Int64(10)]));
    }
    db.bulk_batch(1, &rows).unwrap();
    let result = db.execute(1, "COMMIT");
    let code = result.as_ref().err().map(|e| e.code);
    let _ = db.execute(1, "ROLLBACK");
    assert_eq!(
        db.execute(2, "SELECT COUNT(*) AS n FROM f").unwrap(),
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(if existing { 1 } else { 0 })])],
        },
        "failed bulk import published rows"
    );
    finish(path, db);
    assert_eq!(code, Some(ErrorCode::ConstraintViolation), "{result:?}");
}
#[test]
fn a12_bulk_zero() {
    bulk(false, false);
}
#[test]
fn a12_bulk_nan() {
    bulk(true, false);
}
#[test]
fn a12_bulk_existing_zero() {
    bulk(false, true);
}
#[test]
fn a12_bulk_existing_nan() {
    bulk(true, true);
}

#[test]
fn a12_pending_update_create_and_historical_versions() {
    for nan in [false, true] {
        let (path, db) = setup();
        let (a, b) = pair(nan);
        db.execute(1, "BEGIN").unwrap();
        stage(&db, 1, a.clone()).unwrap();
        assert_eq!(
            stage(&db, 1, b.clone()).unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        db.execute(1, "ROLLBACK").unwrap();
        db.execute(1, "BEGIN").unwrap();
        stage(&db, 1, a.clone()).unwrap();
        db.execute(1, "COMMIT").unwrap();
        db.execute(1, "INSERT INTO f VALUES (42.0,10)").unwrap();
        db.execute(1, "BEGIN").unwrap();
        let result = {
            let c = db.connection(1).unwrap();
            let mut guard = c.lock().unwrap();
            db.ensure_writes(1, &mut guard).unwrap();
            let sql_sessions::Connection {
                session, writes, ..
            } = &mut *guard;
            db.stage(
                session,
                writes.as_mut().unwrap(),
                "UPDATE f SET k=$1 WHERE k=42.0",
                std::slice::from_ref(&b),
            )
        };
        assert_eq!(result.unwrap_err().code, ErrorCode::ConstraintViolation);
        db.execute(1, "ROLLBACK").unwrap();
        db.execute(1, "DELETE FROM f").unwrap();
        db.execute(1, "BEGIN").unwrap();
        stage(&db, 1, b.clone()).unwrap();
        db.execute(1, "COMMIT").unwrap();
        // Deleted canonical-equivalent historical entries must not conflict
        // or make the compatibility gate reject a valid database.
        db.disconnect(1);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
        let db = Arc::new(MvccDatabase::open(&path).unwrap());
        db.execute(1, "DROP INDEX fu").unwrap();
        db.execute(1, "BEGIN").unwrap();
        stage(&db, 1, a).unwrap();
        db.execute(1, "COMMIT").unwrap();
        assert_eq!(
            db.execute(1, "CREATE UNIQUE INDEX again ON f(k,g)")
                .unwrap_err()
                .code,
            ErrorCode::ConstraintViolation
        );
        finish(path, db);
    }
}

#[test]
fn a12_bulk_nonadjacent_composite_and_null_controls() {
    for nan in [false, true] {
        let (path, db) = setup();
        let (a, b) = pair(nan);
        db.bulk_begin(1, "f").unwrap();
        db.bulk_test_bounds(1, u64::MAX, 1).unwrap();
        db.bulk_batch(
            1,
            &[
                Row::new(vec![a.clone(), Value::Int64(10)]),
                Row::new(vec![a, Value::Int64(11)]),
                Row::new(vec![b, Value::Int64(10)]),
            ],
        )
        .unwrap();
        assert_eq!(
            db.execute(1, "COMMIT").unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        let _ = db.execute(1, "ROLLBACK");
        let (a, b) = pair(nan);
        db.bulk_begin(1, "f").unwrap();
        db.bulk_batch(
            1,
            &[
                Row::new(vec![a, Value::Int64(10)]),
                Row::new(vec![b, Value::Int64(11)]),
                Row::new(vec![Value::Null, Value::Int64(10)]),
                Row::new(vec![Value::Null, Value::Int64(10)]),
            ],
        )
        .unwrap();
        db.execute(1, "COMMIT").unwrap();
        finish(path, db);
    }
}

#[test]
fn a12_mvcc_existing_canonical_violation_fails_open() {
    let (path, db) = setup();
    db.execute(1, "DROP INDEX fu").unwrap();
    let (a, b) = pair(true);
    db.execute(1, "BEGIN").unwrap();
    stage(&db, 1, a).unwrap();
    stage(&db, 1, b).unwrap();
    db.execute(1, "COMMIT").unwrap();
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    let mut catalog = Catalog::open(&path).unwrap();
    let table = catalog.tables().find(|t| t.name == "f").unwrap().id;
    let index = catalog
        .create_index(
            "old_unique".into(),
            table,
            vec!["k".into(), "g".into()],
            true,
        )
        .unwrap();
    drop(BPlusTree::open(index_path(&path, index.id), true, 2).unwrap());
    drop(catalog);
    let error = MvccDatabase::open(&path)
        .err()
        .expect("old canonical duplicates accepted");
    assert_eq!(error.code, ErrorCode::ConstraintViolation);
    assert!(error.message.contains("canonical equality"));
    fs::remove_dir_all(path).unwrap();
}
