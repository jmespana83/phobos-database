//! Dedicated all-or-nothing imports. Only bounded batches reside in memory;
//! encoded tuples and index keys spill before ordinary C6 admission.
//!
//! C9: index maintenance is a bulk build/merge. Staging generates sorted key
//! runs per index; COMMIT (before admission) merges the runs, detects in-batch
//! duplicates and validates unique keys against the committed index with an
//! ordered probe; preparation (after admission) fills heap pages and rebuilds
//! each index from the sorted key stream through the existing private overlay.
use super::*;
use phobos_index::{decode_key_bytes, encode_key_bytes};
use phobos_storage::tuple_version::TupleVersion;
use phobos_txn::mvcc::Version;
use std::{
    collections::BinaryHeap,
    io::{BufReader, BufWriter, Write},
};

pub const BATCH_ROWS: usize = 1024;
pub const BATCH_BYTES: usize = 1024 * 1024;
/// Sorted-run bounds: keys buffered per index before a run is spilled.
const RUN_KEYS: usize = 65_536;
const RUN_BYTES: usize = 8 * 1024 * 1024;
/// Open run readers per merge pass. 512 covers 512 × 65,536 = 33.5M rows per
/// index in a single pass (a 10M import produces 153 runs per index, which
/// previously cascaded through an extra full read/write of every key). Read
/// buffers share a fixed budget (`MERGE_READ_BUFFER_BYTES`), so memory does not
/// grow with the fan-in; handles are bounded by fan-in + 1 writer per merge.
/// When the OS refuses that many open files the merge falls back to
/// `MERGE_FAN_IN_FALLBACK` and cascades exactly as before.
pub(super) const MERGE_FAN_IN: usize = 512;
pub(super) const MERGE_FAN_IN_FALLBACK: usize = 128;
/// Total read-buffer bytes shared by the open run readers of one merge
/// (64 KiB each at the fallback fan-in, 16 KiB each at 512).
const MERGE_READ_BUFFER_BYTES: usize = 8 * 1024 * 1024;
const MERGE_READ_BUFFER_MIN: usize = 16 * 1024;
const MERGE_HANDLE_LIMIT_MESSAGE: &str = "bulk merge fan-in exceeds the open-file limit";
/// Ascending unique keys probed per consistent committed-index window.
const PROBE_KEYS: usize = 1024;
pub(super) struct Spool {
    pub schema: TableSchema,
    definitions: Option<phobos_catalog::SchemaDefinitions>,
    pub indexes: Vec<phobos_types::IndexSchema>,
    root: PathBuf,
    roots: Vec<PathBuf>,
    output: Option<BufWriter<File>>,
    keys: BTreeMap<IndexId, KeyRuns>,
    /// Sorted key files ready for preparation, in index order.
    sorted: BTreeMap<IndexId, PathBuf>,
    count: u32,
    stable: u64,
    /// Exact scratch accounting: every byte this spool has written under
    /// `root` and not yet removed (row spool, key runs, merge outputs, sorted
    /// key files). The quota is enforced against this counter after every
    /// chunk; the directory itself is only walked once, at COMMIT.
    scratch_bytes: u64,
    /// Scratch quota; `SCRATCH_BYTES` outside tests.
    scratch_quota: u64,
    /// Readers per merge pass; `MERGE_FAN_IN` outside tests.
    merge_fan_in: usize,
    index_workers: usize,
    active_index_builders: std::sync::atomic::AtomicUsize,
    max_index_builders: Arc<std::sync::atomic::AtomicUsize>,
    /// Test-only simulated open-file limit (runs a merge may open at once) and
    /// a merge attempt number to refuse once.
    #[cfg(test)]
    test_open_limit: Option<usize>,
    #[cfg(test)]
    test_fail_at: Option<u32>,
    /// Test-only count of fan-in fallbacks taken.
    #[cfg(test)]
    test_fallbacks: u32,
}
impl Drop for Spool {
    fn drop(&mut self) {
        self.keys.clear();
        self.output.take(); // Close every Windows handle before removing scratch.
        for root in &self.roots {
            let _ = fs::remove_dir_all(root);
        }
    }
}
fn checksum(bytes: &[u8]) -> u32 {
    bytes.iter().fold(0x811c9dc5u32, |hash, byte| {
        (hash ^ u32::from(*byte)).wrapping_mul(0x01000193)
    })
}
fn scratch_overflow() -> PhobosError {
    write_conflict("bulk scratch accounting overflow")
}
fn scratch_underflow() -> PhobosError {
    write_conflict("bulk scratch accounting underflow")
}
/// Add bytes the spool has just written to its scratch directory.
fn scratch_add(total: &mut u64, bytes: u64) -> Result<(), PhobosError> {
    *total = total.checked_add(bytes).ok_or_else(scratch_overflow)?;
    Ok(())
}
/// Remove the bytes of a scratch file the spool has just deleted.
fn scratch_sub(total: &mut u64, bytes: u64) -> Result<(), PhobosError> {
    *total = total.checked_sub(bytes).ok_or_else(scratch_underflow)?;
    Ok(())
}

/// Bounded in-memory key buffer plus the spilled sorted runs of one index.
struct KeyRuns {
    buffer: Vec<(IndexKey, u32)>,
    bytes: usize,
    /// Spilled run files with their exact lengths, for quota accounting.
    runs: Vec<(PathBuf, u64)>,
    next_run: u32,
    /// Keys per run before a spill; `RUN_KEYS` outside tests.
    run_keys: usize,
}
impl KeyRuns {
    /// Buffers one key; returns the bytes of a run spilled to make room (0 if none).
    fn push(
        &mut self,
        key: IndexKey,
        ordinal: u32,
        root: &Path,
        id: IndexId,
    ) -> Result<u64, PhobosError> {
        let estimate = encode_key_bytes(&key)?.len() + 32;
        let mut spilled = 0;
        if !self.buffer.is_empty()
            && (self.buffer.len() >= self.run_keys
                || self.bytes.saturating_add(estimate) > RUN_BYTES)
        {
            spilled = self.spill(root, id)?;
        }
        self.bytes += estimate;
        self.buffer.push((key, ordinal));
        Ok(spilled)
    }
    /// Sorts and writes the buffered keys as one run; returns its exact length.
    fn spill(&mut self, root: &Path, id: IndexId) -> Result<u64, PhobosError> {
        if self.buffer.is_empty() {
            return Ok(0);
        }
        let _cost = phobos_observability::span("bulk.sort");
        let mut buffer = std::mem::take(&mut self.buffer);
        self.bytes = 0;
        buffer.sort_by(|(a, ao), (b, bo)| a.cmp(b).then_with(|| ao.cmp(bo)));
        let path = root.join(format!("keys-{id}-{}", self.next_run));
        self.next_run += 1;
        let mut writer = BufWriter::new(
            fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&path)?,
        );
        let mut written = 0u64;
        for (key, ordinal) in &buffer {
            scratch_add(
                &mut written,
                write_record(&mut writer, &encode_key_bytes(key)?, *ordinal)?,
            )?;
        }
        writer.flush()?;
        drop(writer);
        self.runs.push((path, written));
        Ok(written)
    }
}

/// Writes one checksummed key record; returns its exact length in bytes.
fn write_record(writer: &mut impl Write, key: &[u8], ordinal: u32) -> Result<u64, PhobosError> {
    phobos_error::cancellation::checkpoint_at("bulk.write_record")?;
    let len = u16::try_from(key.len())
        .map_err(|_| write_conflict("bulk key record exceeds the index key limit"))?;
    let mut crc = checksum(key);
    crc = (crc ^ ordinal).wrapping_mul(0x01000193);
    writer.write_all(&len.to_le_bytes())?;
    writer.write_all(key)?;
    writer.write_all(&ordinal.to_le_bytes())?;
    writer.write_all(&crc.to_le_bytes())?;
    Ok(2 + u64::from(len) + 4 + 4)
}

/// Sequential reader over one checksummed run/sorted key file.
struct RunReader {
    input: BufReader<File>,
    head: Option<(IndexKey, u32)>,
}
/// Too many open files (EMFILE/ENFILE on Unix, ERROR_TOO_MANY_OPEN_FILES /
/// ERROR_NO_SYSTEM_RESOURCES on Windows): the only error a merge retries at a
/// smaller fan-in. Anything else is a real failure.
fn is_handle_limit(error: &std::io::Error) -> bool {
    match error.raw_os_error() {
        #[cfg(unix)]
        Some(code) => code == 23 || code == 24,
        #[cfg(windows)]
        Some(code) => code == 4 || code == 1450,
        #[cfg(not(any(unix, windows)))]
        Some(_) => false,
        None => false,
    }
}
fn handle_limit() -> PhobosError {
    PhobosError::new(ErrorCode::ResourceLimit, MERGE_HANDLE_LIMIT_MESSAGE)
}
impl RunReader {
    fn open(path: &Path, buffer: usize) -> Result<Self, PhobosError> {
        let file = File::open(path).map_err(|error| {
            if is_handle_limit(&error) {
                handle_limit()
            } else {
                PhobosError::from(error)
            }
        })?;
        let mut reader = Self {
            input: BufReader::with_capacity(buffer, file),
            head: None,
        };
        reader.advance()?;
        Ok(reader)
    }
    fn advance(&mut self) -> Result<(), PhobosError> {
        self.head = read_record(&mut self.input)?;
        Ok(())
    }
}
fn read_record(input: &mut BufReader<File>) -> Result<Option<(IndexKey, u32)>, PhobosError> {
    phobos_error::cancellation::checkpoint_at("bulk.read_record")?;
    let mut len = [0; 2];
    match input.read(&mut len)? {
        0 => return Ok(None),
        1 => input.read_exact(&mut len[1..])?,
        _ => {}
    }
    let len = usize::from(u16::from_le_bytes(len));
    let mut key = vec![0; len];
    input.read_exact(&mut key)?;
    let mut tail = [0; 8];
    input.read_exact(&mut tail)?;
    let ordinal = u32::from_le_bytes(tail[..4].try_into().expect("ordinal"));
    let expected = u32::from_le_bytes(tail[4..].try_into().expect("checksum"));
    if (checksum(&key) ^ ordinal).wrapping_mul(0x01000193) != expected {
        return Err(write_conflict("bulk key spool checksum"));
    }
    Ok(Some((decode_key_bytes(&key)?, ordinal)))
}

struct HeapItem(IndexKey, u32, usize);
impl PartialEq for HeapItem {
    fn eq(&self, other: &Self) -> bool {
        self.cmp(other) == std::cmp::Ordering::Equal
    }
}
impl Eq for HeapItem {}
impl PartialOrd for HeapItem {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}
impl Ord for HeapItem {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        // Reversed: BinaryHeap is a max-heap; the smallest (key, ordinal) wins.
        other
            .0
            .cmp(&self.0)
            .then_with(|| other.1.cmp(&self.1))
            .then_with(|| other.2.cmp(&self.2))
    }
}

/// k-way merge of sorted runs into `output`, invoking `sink` per record in order.
/// `scratch` is the owning spool's accounting: the output's bytes are added as
/// they are written and each consumed run's bytes are subtracted once it has
/// been removed. Returns the exact length of `output`.
///
/// Every reader and the writer are opened before the first byte is written or
/// any run removed, so an open-file-limit error (`handle_limit`) leaves the runs,
/// the accounting and `sink`'s state untouched and the caller may retry with a
/// smaller fan-in.
fn merge_runs(
    runs: &[(PathBuf, u64)],
    output: &Path,
    scratch: &mut u64,
    sink: &mut impl FnMut(&IndexKey, u32) -> Result<(), PhobosError>,
) -> Result<u64, PhobosError> {
    let buffer =
        (MERGE_READ_BUFFER_BYTES / runs.len().max(1)).clamp(MERGE_READ_BUFFER_MIN, 64 * 1024);
    let mut heap = BinaryHeap::new();
    let mut readers = Vec::with_capacity(runs.len());
    for (order, (path, _)) in runs.iter().enumerate() {
        let mut reader = RunReader::open(path, buffer)?;
        if let Some((key, ordinal)) = reader.head.take() {
            heap.push(HeapItem(key, ordinal, order));
        }
        readers.push(reader);
    }
    let mut writer = BufWriter::new(
        fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(output)
            .map_err(|error| {
                if is_handle_limit(&error) {
                    handle_limit()
                } else {
                    PhobosError::from(error)
                }
            })?,
    );
    let mut written = 0u64;
    while let Some(HeapItem(key, ordinal, order)) = heap.pop() {
        sink(&key, ordinal)?;
        let record = write_record(&mut writer, &encode_key_bytes(&key)?, ordinal)?;
        scratch_add(&mut written, record)?;
        scratch_add(scratch, record)?;
        readers[order].advance()?;
        if let Some((key, ordinal)) = readers[order].head.take() {
            heap.push(HeapItem(key, ordinal, order));
        }
    }
    writer.flush()?;
    drop(writer);
    drop(readers);
    for (path, bytes) in runs {
        fs::remove_file(path)?;
        scratch_sub(scratch, *bytes)?;
    }
    Ok(written)
}

/// Test-only simulation of the OS open-file limit: `open_limit` refuses any
/// merge that would open more readers than the limit; `fail_at` refuses exactly
/// the n-th merge attempt once (a mid-pass failure). Both are inert in
/// production builds (always `None`).
#[derive(Default)]
struct MergeSimulation {
    open_limit: Option<usize>,
    fail_at: Option<u32>,
    attempts: u32,
}
impl MergeSimulation {
    fn refuses(&mut self, readers: usize) -> bool {
        self.attempts += 1;
        if self.open_limit.is_some_and(|limit| readers > limit) {
            return true;
        }
        if self.fail_at == Some(self.attempts) {
            self.fail_at = None;
            return true;
        }
        false
    }
}

/// Merge `runs` into `output` with at most `fan_in` readers per pass. Passes
/// cascade only while more runs remain than the fan-in; each pass consumes
/// whole groups of runs into `merge-*` intermediates that the next pass reads.
/// `runs` always reflects what is on disk: a group is replaced only after its
/// merge completed, so a handle-limit error mid-pass leaves a consistent list
/// (finished intermediates plus the untouched remaining runs) for a retry.
#[allow(clippy::too_many_arguments)]
fn merge_all(
    root: &Path,
    index: IndexId,
    runs: &mut Vec<(PathBuf, u64)>,
    output: &Path,
    fan_in: usize,
    scratch: &mut u64,
    sink: &mut impl FnMut(&IndexKey, u32) -> Result<(), PhobosError>,
    control: &ownership::WaitControl,
    sequence: &mut u32,
    simulate: &mut MergeSimulation,
) -> Result<(), PhobosError> {
    let fan_in = fan_in.max(2);
    while runs.len() > fan_in {
        let _cost = phobos_observability::span("bulk.sort_cascade_pass");
        let remaining = std::mem::take(runs);
        let mut merged = Vec::new();
        let mut groups = remaining
            .chunks(fan_in)
            .map(<[_]>::to_vec)
            .collect::<Vec<_>>();
        groups.reverse(); // pop from the front in order
        let result = (|| -> Result<(), PhobosError> {
            while let Some(group) = groups.pop() {
                control.check()?;
                // Intermediate names come from a per-index sequence that survives a
                // fan-in retry, so finished intermediates are never re-created.
                let path = root.join(format!("merge-{index}-{}", *sequence));
                *sequence = sequence
                    .checked_add(1)
                    .ok_or_else(|| write_conflict("bulk merge sequence overflow"))?;
                if simulate.refuses(group.len()) {
                    groups.push(group);
                    return Err(handle_limit());
                }
                let bytes = match merge_runs(&group, &path, scratch, &mut |_, _| Ok(())) {
                    Ok(bytes) => bytes,
                    Err(error) => {
                        groups.push(group);
                        return Err(error);
                    }
                };
                merged.push((path, bytes));
            }
            Ok(())
        })();
        // Finished intermediates first, then whatever was not merged, in order.
        let mut restored = merged;
        while let Some(group) = groups.pop() {
            restored.extend(group);
        }
        *runs = restored;
        result?;
    }
    if simulate.refuses(runs.len()) {
        return Err(handle_limit());
    }
    let _final = phobos_observability::span("bulk.merge_final");
    merge_runs(runs, output, scratch, sink)?;
    runs.clear();
    Ok(())
}

/// Ordinal -> RID map with one entry per heap page the import filled.
/// Bulk heap slots are appended, so RIDs are consecutive within a page.
#[derive(Default)]
struct RidMap {
    pages: Vec<(u32, RecordId)>,
    next_ordinal: u32,
}
impl RidMap {
    fn extend(&mut self, ids: &[RecordId]) -> Result<(), PhobosError> {
        for rid in ids {
            let ordinal = self.next_ordinal.checked_add(1).ok_or_else(limit)?;
            let contiguous = self.pages.last().is_some_and(|(first, start)| {
                start.page_id == rid.page_id
                    && u32::from(start.slot_id) + (ordinal - first) == u32::from(rid.slot_id)
            });
            if !contiguous {
                if self.pages.last().is_some_and(|(_, start)| *start >= *rid) {
                    return Err(write_conflict("bulk heap RIDs are not ascending"));
                }
                self.pages.push((ordinal, *rid));
            }
            self.next_ordinal = ordinal;
        }
        Ok(())
    }
    fn resolve(&self, ordinal: u32) -> Result<RecordId, PhobosError> {
        if ordinal == 0 || ordinal > self.next_ordinal {
            return Err(write_conflict("bulk key ordinal out of range"));
        }
        let index = self.pages.partition_point(|(first, _)| *first <= ordinal);
        let (first, start) = self.pages[index - 1];
        let slot = u32::from(start.slot_id) + (ordinal - first);
        Ok(RecordId {
            page_id: start.page_id,
            slot_id: u16::try_from(slot).map_err(|_| write_conflict("bulk slot overflow"))?,
        })
    }
}

impl Spool {
    fn new(
        root: &Path,
        config: &phobos_config::RuntimeConfig,
        max_index_builders: Arc<std::sync::atomic::AtomicUsize>,
        stable: u64,
        schema: TableSchema,
        indexes: Vec<phobos_types::IndexSchema>,
    ) -> Result<Self, PhobosError> {
        let bases = if config.bulk_scratch_directories.is_empty() {
            vec![root.to_path_buf()]
        } else {
            config
                .bulk_scratch_directories
                .iter()
                .map(|path| {
                    if path.is_absolute() {
                        path.clone()
                    } else {
                        root.join(path)
                    }
                })
                .collect()
        };
        let mut roots = Vec::with_capacity(bases.len());
        for base in bases {
            fs::create_dir_all(&base)?;
            let scratch = base.join(format!(".phobos-mvcc-bulk-{stable}"));
            fs::create_dir(&scratch)?;
            roots.push(scratch);
        }
        let root = roots[0].clone();
        let scratch_quota = config
            .bulk_scratch_quota_bytes
            .checked_mul(roots.len() as u64)
            .ok_or_else(scratch_overflow)?;
        let mut spool = Self {
            definitions: None,
            schema,
            indexes,
            root,
            roots,
            output: None,
            keys: BTreeMap::new(),
            sorted: BTreeMap::new(),
            count: 0,
            stable,
            scratch_bytes: 0,
            scratch_quota,
            merge_fan_in: MERGE_FAN_IN,
            index_workers: config.bulk_index_build_workers,
            active_index_builders: std::sync::atomic::AtomicUsize::new(0),
            max_index_builders,
            #[cfg(test)]
            test_open_limit: None,
            #[cfg(test)]
            test_fail_at: None,
            #[cfg(test)]
            test_fallbacks: 0,
        };
        spool.output = Some(BufWriter::new(
            fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(spool.root.join("rows"))?,
        ));
        for index in &spool.indexes {
            spool.keys.insert(
                index.id,
                KeyRuns {
                    buffer: Vec::new(),
                    bytes: 0,
                    runs: Vec::new(),
                    next_run: 0,
                    run_keys: RUN_KEYS,
                },
            );
        }
        Ok(spool)
    }
    /// Test-only bounds: a smaller quota and shorter runs exercise the quota,
    /// spill, merge and cascade paths without gigabytes of scratch.
    #[cfg(test)]
    pub(super) fn set_test_bounds(&mut self, scratch_quota: u64, run_keys: usize) {
        self.scratch_quota = scratch_quota;
        for runs in self.keys.values_mut() {
            runs.run_keys = run_keys.max(1);
        }
    }
    /// Simulated open-file behaviour; inert outside tests. A one-shot refusal
    /// fires for one index only, like a transient OS condition would.
    fn merge_simulation(&mut self) -> MergeSimulation {
        #[cfg(test)]
        {
            MergeSimulation {
                open_limit: self.test_open_limit,
                fail_at: self.test_fail_at.take(),
                attempts: 0,
            }
        }
        #[cfg(not(test))]
        {
            MergeSimulation::default()
        }
    }
    /// Test-only merge bounds: readers per pass, a simulated open-file limit and
    /// a merge attempt to refuse once.
    #[cfg(test)]
    pub(super) fn set_test_merge(
        &mut self,
        fan_in: usize,
        open_limit: Option<usize>,
        fail_at: Option<u32>,
    ) {
        self.merge_fan_in = fan_in;
        self.test_open_limit = open_limit;
        self.test_fail_at = fail_at;
    }
    /// Test-only: fan-in fallbacks taken during finalize.
    #[cfg(test)]
    pub(super) fn merge_fallbacks(&self) -> u32 {
        self.test_fallbacks
    }
    /// Bytes currently accounted under the scratch directory.
    #[cfg(test)]
    pub(super) fn scratch_bytes(&self) -> u64 {
        self.scratch_bytes
    }
    /// Exact byte total of the scratch directory, measured through live handles.
    #[cfg(test)]
    pub(super) fn measured_scratch_bytes(&self) -> Result<u64, PhobosError> {
        self.measure_scratch()
    }
    /// Number of run files currently on disk for each index.
    #[cfg(test)]
    pub(super) fn run_file_counts(&self) -> Vec<usize> {
        self.keys.values().map(|runs| runs.runs.len()).collect()
    }
    #[cfg(test)]
    pub(super) fn scratch_directory_state(&self) -> Result<Vec<(u64, usize)>, PhobosError> {
        self.roots
            .iter()
            .map(|root| {
                let mut bytes = 0u64;
                let mut runs = 0usize;
                for entry in fs::read_dir(root)? {
                    let entry = entry?;
                    bytes = bytes
                        .checked_add(File::open(entry.path())?.metadata()?.len())
                        .ok_or_else(scratch_overflow)?;
                    runs += usize::from(entry.file_name().to_string_lossy().starts_with("keys-"));
                }
                Ok((bytes, runs))
            })
            .collect()
    }
    fn append(&mut self, database: &MvccDatabase, rows: &[Row]) -> Result<u64, PhobosError> {
        if rows.is_empty() || rows.len() > BATCH_ROWS {
            return Err(limit());
        }
        if !self.sorted.is_empty() {
            return Err(write_conflict("bulk import already finalized"));
        }
        let mut encoded = Vec::with_capacity(rows.len());
        let mut bytes = 0usize;
        for row in rows {
            if row.values.len() != self.schema.columns.len() {
                return Err(PhobosError::new(
                    ErrorCode::ConstraintViolation,
                    "bulk row column count",
                ));
            }
            if row.values.iter().any(|value| match value {
                Value::Text(text) => text.len() > 64 * 1024,
                Value::Binary(bytes) => bytes.len() > 64 * 1024,
                _ => false,
            }) {
                return Err(limit());
            }
            let row = Row::new(
                self.schema
                    .columns
                    .iter()
                    .zip(&row.values)
                    .map(|(column, value)| coerce_value(column, value.clone()))
                    .collect::<Result<Vec<_>, _>>()?,
            );
            if let Some(definition) = &self.definitions {
                definition.validate_row(&row)?;
            }
            self.count = self.count.checked_add(1).ok_or_else(limit)?;
            let tuple = TupleVersion {
                logical_row: (self.stable << 32) | u64::from(self.count),
                visibility: Version {
                    creator: self.stable,
                    deleter: None,
                },
                previous: None,
            };
            let image = {
                let _encode = phobos_observability::span("bulk.encode");
                tuple.encode(&self.schema, &row)?
            };
            bytes = bytes.checked_add(image.len()).ok_or_else(limit)?;
            if bytes > BATCH_BYTES {
                return Err(limit());
            }
            {
                let _cost = phobos_observability::span("bulk.key_generate");
                for index in &self.indexes {
                    let key = index_key_for_row(&self.schema, index, &row)?;
                    key.validate_columns(index.columns.len())?;
                    let runs = self.keys.get_mut(&index.id).expect("bulk key runs");
                    let root = &self.roots[runs.next_run as usize % self.roots.len()];
                    let spilled = runs.push(key, self.count, root, index.id)?;
                    scratch_add(&mut self.scratch_bytes, spilled)?;
                }
            }
            encoded.push(image);
        }
        let output = self.output.as_mut().expect("open spool");
        for image in encoded {
            output.write_all(&(image.len() as u32).to_le_bytes())?;
            output.write_all(&checksum(&image).to_le_bytes())?;
            output.write_all(&image)?;
            // 4-byte length + 4-byte checksum + image: exactly what was written.
            scratch_add(&mut self.scratch_bytes, 8 + image.len() as u64)?;
        }
        output.flush()?;
        self.check_scratch()?;
        phobos_observability::event("bulk.rows_staged", rows.len() as u64);
        phobos_observability::synchronization_boundary("c7_batch_staged", &database.data_dir);
        Ok(u64::from(self.count))
    }
    /// Quota check against the exact running total: O(1) per chunk. The
    /// directory is never scanned here; `verify_scratch` does that once at COMMIT.
    fn check_scratch(&self) -> Result<(), PhobosError> {
        if self.scratch_bytes > self.scratch_quota {
            return Err(limit());
        }
        Ok(())
    }
    /// Sum of every scratch file length, read through live handles.
    fn measure_scratch(&self) -> Result<u64, PhobosError> {
        self.roots.iter().try_fold(0u64, |total, root| {
            fs::read_dir(root)?.try_fold(total, |total, entry| -> Result<u64, PhobosError> {
                // Query a live handle so Windows reports accepted buffered bytes.
                Ok(total.saturating_add(File::open(entry?.path())?.metadata()?.len()))
            })
        })
    }
    /// One directory walk per import, at COMMIT before admission: the running
    /// total must equal what is on disk, and the quota is re-applied to the
    /// measured size. A mismatch aborts the import before anything is admitted.
    fn verify_scratch(&self) -> Result<(), PhobosError> {
        let measured = self.measure_scratch()?;
        if measured != self.scratch_bytes {
            return Err(write_conflict("bulk scratch accounting mismatch"));
        }
        if measured > self.scratch_quota {
            return Err(limit());
        }
        Ok(())
    }

    /// COMMIT, before admission: sort every index's keys, reject duplicate
    /// unique keys inside the import, and validate unique keys against the
    /// committed index with an ordered probe. Errors abort the whole import;
    /// nothing has been admitted and no index page has been touched.
    pub fn finalize(
        &mut self,
        database: &MvccDatabase,
        session: &Session,
        control: &ownership::WaitControl,
    ) -> Result<(), PhobosError> {
        if !self.sorted.is_empty() {
            return Err(write_conflict("bulk import already finalized"));
        }
        let _cost = phobos_observability::span("bulk.finalize");
        let mut view = database.statement(session, None)?;
        let indexes = self.indexes.clone();
        let table = self.schema.id;
        for index in &indexes {
            control.check()?;
            let runs = self.keys.get_mut(&index.id).expect("bulk key runs");
            let root = &self.roots[runs.next_run as usize % self.roots.len()];
            let spilled = runs.spill(root, index.id)?;
            scratch_add(&mut self.scratch_bytes, spilled)?;
            let mut runs = std::mem::take(&mut runs.runs);
            let merge_root = self.roots[index.id as usize % self.roots.len()].clone();
            let output = merge_root.join(format!("sorted-{}", index.id));
            let unique = index.unique;
            let table_schema = self.schema.clone();
            let mut previous: Option<IndexKey> = None;
            // Physical sorting does not make canonical zero/NaN composite
            // duplicates adjacent. Retain their exact logical identities.
            let mut ambiguous = HashSet::new();
            let mut probe: Vec<IndexKey> = Vec::new();
            let mut unique_ns = 0u128;
            let mut probe_batch = |keys: &mut Vec<IndexKey>| -> Result<(), PhobosError> {
                if keys.is_empty() {
                    return Ok(());
                }
                control.check()?;
                let _cost = phobos_observability::span("bulk.existing_merge");
                let heap = view.database.heaps.get_mut(&table).expect("bulk heap");
                let tree = view
                    .database
                    .indexes
                    .get_mut(&index.id)
                    .expect("bulk index");
                let mut matches = Vec::new();
                if keys.iter().any(IndexKey::needs_canonical_probe) {
                    for (position, key) in keys.iter().enumerate() {
                        tree.typed_unique_visit(key, |rid| {
                            matches.push((position, rid));
                            Ok(true)
                        })?;
                    }
                } else {
                    tree.probe_sorted(keys, |position, rid| {
                        matches.push((position, rid));
                        Ok(())
                    })?;
                }
                for (position, rid) in matches {
                    let Some((version, candidate)) = heap.get_version(rid)? else {
                        // 0.2-K: a RETIRED/FREE/trimmed slot held a globally
                        // dead version (entry copied before its reclaim).
                        if heap.slot_reclaimed(rid)? {
                            continue;
                        }
                        return Err(write_conflict("bulk unique reference missing"));
                    };
                    // 0.2-K Part H: a reused slot names another logical key.
                    let probe = keys
                        .get(position)
                        .ok_or_else(|| write_conflict("bulk unique probe position"))?;
                    if index_key_for_row(&table_schema, index, &candidate)?.logical_unique_key()
                        != probe.logical_unique_key()
                    {
                        phobos_observability::event("mvcc.stale_rid_skipped", 1);
                        continue;
                    }
                    if view
                        .pin
                        .snapshot()
                        .visible(version.visibility, &mut view.pin.as_ref())?
                    {
                        return Err(unique_conflict());
                    }
                }
                keys.clear();
                Ok(())
            };
            let mut sink = |key: &IndexKey, _: u32| -> Result<(), PhobosError> {
                if !unique || key.contains_null() {
                    return Ok(());
                }
                let started = Instant::now();
                let duplicate = if key.needs_canonical_probe() {
                    !ambiguous.insert(key.logical_unique_key().expect("non-null unique key"))
                } else {
                    previous
                        .as_ref()
                        .is_some_and(|prior| prior.logical_unique_key() == key.logical_unique_key())
                };
                previous = Some(key.clone());
                unique_ns += started.elapsed().as_nanos();
                if duplicate {
                    return Err(unique_conflict());
                }
                probe.push(key.clone());
                if probe.len() >= PROBE_KEYS {
                    probe_batch(&mut probe)?;
                }
                Ok(())
            };
            {
                let _sort = phobos_observability::span("bulk.sort");
                let mut fan_in = self.merge_fan_in;
                let mut simulate = self.merge_simulation();
                let mut sequence = 0u32;
                let mut fell_back = false;
                loop {
                    match merge_all(
                        &merge_root,
                        index.id,
                        &mut runs,
                        &output,
                        fan_in,
                        &mut self.scratch_bytes,
                        &mut sink,
                        control,
                        &mut sequence,
                        &mut simulate,
                    ) {
                        Ok(()) => break,
                        Err(error)
                            if error.message == MERGE_HANDLE_LIMIT_MESSAGE
                                && fan_in > MERGE_FAN_IN_FALLBACK =>
                        {
                            // No reader opened for the pass had side effects: the
                            // remaining runs are intact. Cascade with fewer handles.
                            fan_in = MERGE_FAN_IN_FALLBACK;
                            fell_back = true;
                        }
                        Err(error) => return Err(error),
                    }
                }
                if fell_back {
                    // Later indexes of this import start at the fan-in the OS allowed.
                    self.merge_fan_in = fan_in;
                    #[cfg(test)]
                    {
                        self.test_fallbacks += 1;
                    }
                }
            }
            probe_batch(&mut probe)?;
            phobos_observability::event(
                "bulk.unique_check_ns",
                u64::try_from(unique_ns).unwrap_or(u64::MAX),
            );
            self.sorted.insert(index.id, output);
        }
        drop(view);
        // The only directory walk of the import: prove the running total exact
        // and re-apply the quota to the measured size before admission.
        self.verify_scratch()?;
        phobos_observability::synchronization_boundary("c9_bulk_finalized", &database.data_dir);
        Ok(())
    }

    pub fn prepare(&self, database: &mut Database) -> Result<(), PhobosError> {
        if self.sorted.len() != self.indexes.len() {
            return Err(write_conflict("bulk import was not finalized"));
        }
        let mut input = BufReader::new(File::open(self.root.join("rows"))?);
        let mut remaining = self.count;
        let mut rids = RidMap::default();
        while remaining > 0 {
            let mut batch = Vec::new();
            let mut bytes = 0;
            while remaining > 0 && batch.len() < BATCH_ROWS && bytes <= BATCH_BYTES - 8192 {
                let mut header = [0; 8];
                input.read_exact(&mut header)?;
                let length = u32::from_le_bytes(header[..4].try_into().expect("length")) as usize;
                if !(48..=BATCH_BYTES).contains(&length) {
                    return Err(write_conflict("invalid bulk spool length"));
                }
                let mut image = vec![0; length];
                input.read_exact(&mut image)?;
                if checksum(&image) != u32::from_le_bytes(header[4..].try_into().expect("checksum"))
                {
                    return Err(write_conflict("bulk spool checksum"));
                }
                let (tuple, _) = TupleVersion::decode(&self.schema, &image)?;
                let expected = (self.stable << 32) | u64::from(self.count - remaining + 1);
                if tuple.logical_row != expected {
                    return Err(write_conflict("bulk spool identity"));
                }
                bytes += length;
                batch.push(image);
                remaining -= 1;
            }
            let ids = database
                .heap_mut(self.schema.id)?
                .insert_version_batch(&batch)?;
            rids.extend(&ids)?;
            phobos_observability::synchronization_boundary(
                "c7_private_batch_prepared",
                &database.data_dir,
            );
        }
        let mut trailing = [0];
        if input.read(&mut trailing)? != 0 {
            return Err(write_conflict("bulk spool trailing bytes"));
        }
        drop(input);
        let _index = phobos_observability::span("bulk.index_maintenance");
        let mut jobs = Vec::new();
        for index in &self.indexes {
            jobs.push((
                index.id,
                self.sorted[&index.id].clone(),
                database.indexes.remove(&index.id).expect("bulk index"),
            ));
        }
        while !jobs.is_empty() {
            let take = self.index_workers.min(jobs.len()).max(1);
            let batch = jobs.drain(..take).collect::<Vec<_>>();
            let completed = std::thread::scope(|scope| {
                #[cfg(test)]
                let barrier = std::sync::Arc::new(std::sync::Barrier::new(batch.len()));
                let handles = batch
                    .into_iter()
                    .map(|(id, path, mut tree)| {
                        let rids = &rids;
                        #[cfg(test)]
                        let barrier = barrier.clone();
                        scope.spawn(move || {
                            let active = self
                                .active_index_builders
                                .fetch_add(1, std::sync::atomic::Ordering::SeqCst)
                                + 1;
                            self.max_index_builders
                                .fetch_max(active, std::sync::atomic::Ordering::SeqCst);
                            #[cfg(test)]
                            barrier.wait();
                            let mut reader = match File::open(path) {
                                Ok(file) => BufReader::with_capacity(64 * 1024, file),
                                Err(error) => {
                                    self.active_index_builders
                                        .fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
                                    return (id, tree, Err(error.into()), 0);
                                }
                            };
                            let mut seen = 0u32;
                            let entries = std::iter::from_fn(|| match read_record(&mut reader) {
                                Ok(Some((key, ordinal))) => {
                                    seen += 1;
                                    Some(rids.resolve(ordinal).map(|rid| (key, rid)))
                                }
                                Ok(None) => None,
                                Err(error) => Some(Err(error)),
                            });
                            let result = tree.bulk_merge(self.stable, entries);
                            self.active_index_builders
                                .fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
                            (id, tree, result, seen)
                        })
                    })
                    .collect::<Vec<_>>();
                handles
                    .into_iter()
                    .map(|handle| {
                        handle
                            .join()
                            .map_err(|_| write_conflict("bulk index worker panicked"))
                    })
                    .collect::<Result<Vec<_>, _>>()
            })?;
            let mut results = Vec::new();
            for (id, tree, result, seen) in completed {
                database.indexes.insert(id, tree);
                results.push((result, seen));
            }
            let mut failure = None;
            for (result, seen) in results {
                let report = match result {
                    Ok(report) => report,
                    Err(error) => {
                        failure = Some(error);
                        break;
                    }
                };
                if seen != self.count || report.entries != u64::from(self.count) {
                    failure = Some(write_conflict("bulk sorted key count mismatch"));
                    break;
                }
                phobos_observability::event("bulk.index_leaves_built", report.leaves);
                phobos_observability::event("bulk.index_internal_built", report.internal);
                phobos_observability::event("bulk.index_pages_freed", report.freed_pages);
                phobos_observability::synchronization_boundary(
                    "c9_bulk_index_built",
                    &database.data_dir,
                );
            }
            if let Some(error) = failure {
                for (id, _, tree) in jobs.drain(..) {
                    database.indexes.insert(id, tree);
                }
                return Err(error);
            }
        }
        phobos_observability::event(
            "bulk.max_concurrent_index_builders",
            self.max_index_builders
                .load(std::sync::atomic::Ordering::Relaxed) as u64,
        );
        Ok(())
    }
}
fn limit() -> PhobosError {
    PhobosError::new(
        ErrorCode::ResourceLimit,
        "bulk batch/row/scratch limit exceeded",
    )
}

impl MvccDatabase {
    /// Dedicated import starts its own transaction; it cannot be mixed with SQL.
    pub fn bulk_begin(&self, id: u64, table: &str) -> Result<(), PhobosError> {
        self.bulk_max_index_builders
            .store(0, std::sync::atomic::Ordering::SeqCst);
        let _admitted = self.admit_statement("BEGIN")?;
        let connection = self.connection(id)?;
        let mut connection = connection
            .lock()
            .map_err(|_| write_conflict("bulk connection poisoned"))?;
        let stable = connection.session.begin()?;
        let mut writes = SessionWrites::new(stable, BATCH_BYTES)?;
        writes.control = Arc::new(ownership::WaitControl::with_timeout(
            std::time::Duration::from_millis(self.runtime_config.lock_timeout_ms),
        ));
        self.register_control(id, &writes)?;
        writes.ownership = Some(self.ownership.lease(stable));
        let result = (|| {
            let view = self.statement(&connection.session, None)?;
            let schema = view.database.table_schema(table)?;
            if view.database.catalog.has_foreign_keys() {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "bulk import is unavailable in FK databases; use INSERT SELECT or INSERT",
                ));
            }
            if view
                .database
                .catalog
                .definitions(schema.id)
                .is_some_and(|d| d.identity.is_some())
            {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "bulk import into identity tables is unsupported; use INSERT",
                ));
            }
            let indexes = view
                .database
                .catalog
                .indexes_for_table(schema.id)
                .cloned()
                .collect();
            let definitions = view.database.catalog.definitions(schema.id).cloned();
            drop(view);
            self.ownership
                .acquire(stable, ownership::Key::Table(schema.id), &writes.control)?;
            let mut spool = Spool::new(
                &self.data_dir,
                &self.runtime_config,
                self.bulk_max_index_builders.clone(),
                stable,
                schema,
                indexes,
            )?;
            spool.definitions = definitions;
            spool.merge_fan_in = self.runtime_config.merge_fan_in;
            writes.bulk = Some(spool);
            Ok(())
        })();
        if result.is_err() {
            writes.discard();
            connection.session.rollback()?;
            self.finish_control(id);
        } else {
            connection.writes = Some(writes);
        }
        result
    }
    #[cfg(test)]
    pub(super) fn bulk_max_index_builders_for_test(&self) -> usize {
        self.bulk_max_index_builders
            .load(std::sync::atomic::Ordering::SeqCst)
    }
    /// Test-only: shrink the active import's scratch quota and run bound.
    #[cfg(test)]
    pub(super) fn bulk_test_bounds(
        &self,
        id: u64,
        scratch_quota: u64,
        run_keys: usize,
    ) -> Result<(), PhobosError> {
        self.with_bulk(id, |bulk| {
            bulk.set_test_bounds(scratch_quota, run_keys);
            Ok(())
        })
    }
    /// Test-only: readers per merge pass and a simulated open-file limit.
    #[cfg(test)]
    pub(super) fn bulk_test_merge(
        &self,
        id: u64,
        fan_in: usize,
        open_limit: Option<usize>,
        fail_at: Option<u32>,
    ) -> Result<(), PhobosError> {
        self.with_bulk(id, |bulk| {
            bulk.set_test_merge(fan_in, open_limit, fail_at);
            Ok(())
        })
    }
    /// Test-only: fan-in fallbacks the active import's finalize has taken.
    #[cfg(test)]
    pub(super) fn bulk_merge_fallbacks(&self, id: u64) -> Result<u32, PhobosError> {
        self.with_bulk(id, |bulk| Ok(bulk.merge_fallbacks()))
    }
    /// Test-only: (accounted bytes, measured directory bytes, run files per index).
    #[cfg(test)]
    pub(super) fn bulk_scratch_state(
        &self,
        id: u64,
    ) -> Result<(u64, u64, Vec<usize>), PhobosError> {
        self.with_bulk(id, |bulk| {
            Ok((
                bulk.scratch_bytes(),
                bulk.measured_scratch_bytes()?,
                bulk.run_file_counts(),
            ))
        })
    }
    #[cfg(test)]
    pub(super) fn bulk_scratch_directories_for_test(
        &self,
        id: u64,
    ) -> Result<Vec<(u64, usize)>, PhobosError> {
        self.with_bulk(id, |bulk| bulk.scratch_directory_state())
    }
    /// Test-only: run the COMMIT-time finalize (sort/merge/validate) of the
    /// active import without admitting it, then report the scratch state and
    /// the file names left in the scratch directory.
    #[cfg(test)]
    pub(super) fn bulk_finalize_for_test(
        &self,
        id: u64,
    ) -> Result<(u64, u64, Vec<String>), PhobosError> {
        let connection = self.connection(id)?;
        let mut connection = connection
            .lock()
            .map_err(|_| write_conflict("bulk connection poisoned"))?;
        let sql_sessions::Connection {
            session, writes, ..
        } = &mut *connection;
        let writes = writes
            .as_mut()
            .ok_or_else(|| write_conflict("no active bulk import"))?;
        self.finalize_bulk(session, writes)?;
        let bulk = writes
            .bulk
            .as_ref()
            .ok_or_else(|| write_conflict("not a bulk transaction"))?;
        let mut names = fs::read_dir(&bulk.root)?
            .map(|entry| Ok(entry?.file_name().to_string_lossy().into_owned()))
            .collect::<Result<Vec<_>, PhobosError>>()?;
        names.sort();
        Ok((bulk.scratch_bytes(), bulk.measured_scratch_bytes()?, names))
    }
    #[cfg(test)]
    fn with_bulk<T>(
        &self,
        id: u64,
        f: impl FnOnce(&mut Spool) -> Result<T, PhobosError>,
    ) -> Result<T, PhobosError> {
        let connection = self.connection(id)?;
        let mut connection = connection
            .lock()
            .map_err(|_| write_conflict("bulk connection poisoned"))?;
        let bulk = connection
            .writes
            .as_mut()
            .and_then(|writes| writes.bulk.as_mut())
            .ok_or_else(|| write_conflict("no active bulk import"))?;
        f(bulk)
    }
    /// An error discards the entire import, including all previously accepted chunks.
    pub fn bulk_batch(&self, id: u64, rows: &[Row]) -> Result<u64, PhobosError> {
        let _admitted = self.admit_statement("SELECT 1")?;
        let connection = self.connection(id)?;
        let mut connection = connection
            .lock()
            .map_err(|_| write_conflict("bulk connection poisoned"))?;
        let sql_sessions::Connection {
            session, writes, ..
        } = &mut *connection;
        let writes = writes
            .as_mut()
            .ok_or_else(|| write_conflict("no active bulk import"))?;
        let result = writes.control.check().and_then(|()| {
            writes
                .bulk
                .as_mut()
                .ok_or_else(|| write_conflict("not a bulk transaction"))?
                .append(self, rows)
        });
        if result.is_err() {
            writes.discard();
            session.abort_failed()?;
        }
        result
    }
    /// COMMIT of a bulk import runs sort/uniqueness validation before the
    /// irrevocable admission; a non-bulk transaction is unaffected.
    pub(super) fn finalize_bulk(
        &self,
        session: &Session,
        writes: &mut SessionWrites,
    ) -> Result<(), PhobosError> {
        let control = writes.control.clone();
        match writes.bulk.as_mut() {
            Some(bulk) => bulk.finalize(self, session, &control),
            None => Ok(()),
        }
    }
    /// Iterator errors abort all rows. COMMIT uses C6 admission, WAL and visibility.
    pub fn bulk_load(
        &self,
        id: u64,
        table: &str,
        rows: impl IntoIterator<Item = Result<Row, PhobosError>>,
    ) -> Result<u64, PhobosError> {
        self.bulk_begin(id, table)?;
        let result = (|| {
            let mut batch = Vec::new();
            let mut count = 0;
            for row in rows {
                let row = row?;
                let size = row.values.iter().fold(0usize, |size, value| {
                    size.saturating_add(std::mem::size_of_val(value))
                        .saturating_add(match value {
                            Value::Text(text) => text.len(),
                            Value::Binary(bytes) => bytes.len(),
                            _ => 0,
                        })
                });
                if size > 64 * 1024 {
                    return Err(limit());
                }
                batch.push(row);
                if batch.len() == 64 {
                    count = self.bulk_batch(id, &batch)?;
                    batch.clear();
                }
            }
            if !batch.is_empty() {
                count = self.bulk_batch(id, &batch)?;
            }
            self.execute(id, "COMMIT")?;
            Ok(count)
        })();
        if result.is_err() {
            let _ = self.execute(id, "ROLLBACK");
        }
        result
    }
}

#[cfg(test)]
mod config_tests {
    use super::*;
    #[test]
    fn a5_config_reaches_mvcc_query_spill_cache_lock_and_bulk() {
        let root = super::super::tests::fixture();
        let config = phobos_config::RuntimeConfig::from_json(
            r#"{
            "max_connections": 17, "max_result_bytes": 65536,
            "statement_timeout_ms": 12345, "idle_timeout_ms": 6789,
            "lock_timeout_ms": 37, "status_growth_extent_records": 11,
            "write_spill_threshold_bytes": 1024, "write_spill_scratch_quota_bytes": 1048576,
            "query_memory_bytes": 23, "bulk_scratch_quota_bytes": 2097152,
            "merge_fan_in": 7, "page_cache_bytes": 2097152
        }"#,
        )
        .unwrap();
        let db = MvccDatabase::open_with_config(&root, &config).unwrap();
        assert_eq!(db.write_spill(), (1024, 1048576));
        assert_eq!(db.readers.read().unwrap().query_memory_bytes, 23);
        assert_eq!(
            db.lock_database()
                .unwrap()
                .committed_store
                .as_ref()
                .unwrap()
                .config()
                .page_cache_bytes,
            2_097_152
        );
        db.execute(1, "BEGIN").unwrap();
        for id in 5000..5020 {
            db.execute(1, &format!("INSERT INTO t VALUES ({id},{id},NULL)"))
                .unwrap();
        }
        {
            let connection = db.connection(1).unwrap();
            let connection = connection.lock().unwrap();
            let writes = connection.writes.as_ref().unwrap();
            assert!(writes.spill_stats().runs > 0);
            assert_eq!(
                writes.control.timeout(),
                std::time::Duration::from_millis(37)
            );
        }
        db.execute(1, "ROLLBACK").unwrap();
        db.bulk_begin(1, "t").unwrap();
        {
            let connection = db.connection(1).unwrap();
            let connection = connection.lock().unwrap();
            let writes = connection.writes.as_ref().unwrap();
            let spool = writes.bulk.as_ref().unwrap();
            assert_eq!(spool.scratch_quota, 2097152);
            assert_eq!(spool.merge_fan_in, 7);
            assert_eq!(spool.index_workers, 4);
            assert_eq!(
                writes.control.timeout(),
                std::time::Duration::from_millis(37)
            );
        }
        db.execute(1, "ROLLBACK").unwrap();
        db.disconnect(1);
        db.shutdown(std::time::Duration::from_secs(10)).unwrap();
        drop(db);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn f6_spans_scratch_roots_cleans_up_and_builds_indexes_concurrently() {
        let root = super::super::tests::fixture();
        let config = phobos_config::RuntimeConfig::from_json(
            r#"{
                "bulk_scratch_quota_bytes":2000,
                "bulk_scratch_directories":["scratch-a","scratch-b","scratch-c"],
                "bulk_index_build_workers":3
            }"#,
        )
        .unwrap();
        let db = MvccDatabase::open_with_config(&root, &config).unwrap();
        let row = |id| Row::new(vec![Value::Int64(id), Value::Int64(id), Value::Int64(id)]);
        db.bulk_begin(1, "t").unwrap();
        db.bulk_test_bounds(1, 6000, 1).unwrap();
        db.bulk_batch(1, &(10_000..10_030).map(row).collect::<Vec<_>>())
            .unwrap();
        let directories = db.bulk_scratch_directories_for_test(1).unwrap();
        println!("F6_COUNTERS directories={directories:?}");
        assert!(directories.iter().filter(|(_, runs)| *runs > 0).count() >= 2);
        assert!(directories.iter().map(|(bytes, _)| *bytes).sum::<u64>() > 2000);
        db.execute(1, "COMMIT").unwrap();
        assert_eq!(db.bulk_max_index_builders_for_test(), 3);
        println!("F6_COUNTERS max_concurrent_index_builders=3");
        for name in ["scratch-a", "scratch-b", "scratch-c"] {
            assert_eq!(fs::read_dir(root.join(name)).unwrap().count(), 0);
        }
        db.bulk_begin(1, "t").unwrap();
        db.bulk_test_bounds(1, 6000, 1).unwrap();
        db.bulk_batch(1, &(20_000..20_010).map(row).collect::<Vec<_>>())
            .unwrap();
        db.execute(1, "ROLLBACK").unwrap();
        for name in ["scratch-a", "scratch-b", "scratch-c"] {
            assert_eq!(fs::read_dir(root.join(name)).unwrap().count(), 0);
        }
        db.disconnect(1);
        db.shutdown(std::time::Duration::from_secs(10)).unwrap();
        drop(db);
        fs::remove_dir_all(root).unwrap();
    }
}
