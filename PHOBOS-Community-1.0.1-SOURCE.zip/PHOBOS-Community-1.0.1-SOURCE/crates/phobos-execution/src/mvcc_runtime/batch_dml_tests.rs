//! 0.2-H Batch DML V2: encode-once admission keys, logical-key own-row
//! UNIQUE checks, encoded index batch insertion and the in-place heap
//! mutation path, exercised end to end. Every test checks the unchanged
//! contract: UNIQUE (statement, transaction and committed state), snapshot
//! isolation, index/heap parity and recovery.
//!
//! Fixture `t(id,v,g)`: 1000 rows (`v = id`, `g` NULL), unique `u(id)`,
//! composite unique `c(v,g)`, non-unique `d(g)`.
use super::*;
use std::{sync::Arc, thread, time::Duration};
use tests::fixture;

fn count(db: &MvccDatabase, session: u64, predicate: &str) -> i64 {
    match db
        .execute(
            session,
            &format!("SELECT COUNT(*) AS n FROM t WHERE {predicate}"),
        )
        .unwrap()
    {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            ref other => panic!("count {other:?}"),
        },
        other => panic!("count result {other:?}"),
    }
}
fn entries(db: &MvccDatabase) -> usize {
    let mut database = db.lock_database().unwrap();
    database
        .indexes
        .values_mut()
        .map(|tree| tree.validate().unwrap().entries)
        .sum()
}
fn rows(from: i64, to: i64, g: impl Fn(i64) -> String) -> String {
    (from..to)
        .map(|n| format!("({n},{n},{})", g(n)))
        .collect::<Vec<_>>()
        .join(",")
}
fn violation(db: &MvccDatabase, session: u64, sql: &str) {
    let error = db.execute(session, sql).unwrap_err();
    assert_eq!(error.code, ErrorCode::ConstraintViolation, "{sql}: {error}");
}
fn close(db: Arc<MvccDatabase>, sessions: impl IntoIterator<Item = u64>, root: &Path) {
    for session in sessions {
        db.disconnect(session);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// U1–U5, U9: duplicates inside one 500-row statement (single and composite
/// keys, far apart so they land in different leaves), NULL semantics,
/// incoming + committed duplicates, a second UNIQUE index. A failing
/// statement leaves nothing behind.
#[test]
fn h_b1_statement_level_unique_detection_in_500_row_statements() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let before = entries(&db);
    // U1: id 10_003 twice in one statement (positions 3 and 499).
    let mut dup = rows(10_000, 10_499, |n| (n % 7).to_string());
    dup.push_str(",(10003,99999,1)");
    violation(&db, 1, &format!("INSERT INTO t VALUES {dup}"));
    // U2: composite (v,g) twice with distinct ids.
    let mut dup = rows(20_000, 20_499, |n| (n % 7).to_string());
    dup.push_str(",(29999,20005,6)");
    violation(&db, 1, &format!("INSERT INTO t VALUES {dup}"));
    // U5: incoming duplicate plus a committed duplicate (id 5 exists).
    let mut dup = rows(30_000, 30_499, |n| (n % 7).to_string());
    dup.push_str(",(30001,1,1),(5,5,5)");
    violation(&db, 1, &format!("INSERT INTO t VALUES {dup}"));
    // U9: only the second UNIQUE index (c) conflicts with committed state:
    // v = 7, g NULL exists; (7, NULL) is not a conflict (NULL), (7, 3) is
    // new, then (7, 3) again from a different id is a conflict.
    violation(
        &db,
        1,
        &format!(
            "INSERT INTO t VALUES {},(40500,7,3),(40501,7,3)",
            rows(40_000, 40_400, |_| "NULL".into())
        ),
    );
    assert_eq!(count(&db, 2, "id>=10000"), 0, "failed statements left rows");
    assert_eq!(entries(&db), before);
    // U3: NULL never conflicts — 500 rows sharing v with g NULL.
    db.execute(
        1,
        &format!(
            "INSERT INTO t VALUES {}",
            (50_000..50_500)
                .map(|n| format!("({n},4242,NULL)"))
                .collect::<Vec<_>>()
                .join(",")
        ),
    )
    .unwrap();
    assert_eq!(count(&db, 2, "v=4242"), 500);
    // U4: the same keys again, far apart in the index (first and last
    // leaves): every row conflicts with committed state.
    violation(&db, 1, "INSERT INTO t VALUES (60000,60000,1),(50499,1,1)");
    violation(&db, 1, "INSERT INTO t VALUES (0,99000,1),(60001,60001,1)");
    assert_eq!(entries(&db), before + 3 * 500);
    close(db, [1, 2], &root);
}

/// U6–U8: a concurrent transaction holding the same key (the younger
/// competitor is the wait-die victim while the key is held; afterwards it
/// fails if the holder committed and succeeds if it aborted), and rollback of
/// a 500-row transaction.
#[test]
fn h_b2_concurrent_unique_competitor_commit_abort_and_rollback() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    for commit in [true, false] {
        let base = if commit { 70_000 } else { 80_000 };
        db.execute(1, "BEGIN").unwrap();
        db.execute(
            1,
            &format!(
                "INSERT INTO t VALUES {}",
                rows(base, base + 500, |n| (n % 5).to_string())
            ),
        )
        .unwrap();
        // A concurrent (younger) transaction inserting a held key is the
        // wait-die victim: it fails without inserting, while the key is held.
        let held = db
            .execute(2, &format!("INSERT INTO t VALUES ({},1,1)", base + 250))
            .unwrap_err();
        assert!(
            matches!(
                held.code,
                ErrorCode::TransactionState | ErrorCode::ConstraintViolation
            ),
            "{held}"
        );
        db.execute(1, if commit { "COMMIT" } else { "ROLLBACK" })
            .unwrap();
        let result = db.execute(2, &format!("INSERT INTO t VALUES ({},1,1)", base + 250));
        if commit {
            assert_eq!(result.unwrap_err().code, ErrorCode::ConstraintViolation);
            assert_eq!(
                count(&db, 3, &format!("id>={base} AND id<{}", base + 500)),
                500
            );
        } else {
            result.unwrap();
            assert_eq!(
                count(&db, 3, &format!("id>={base} AND id<{}", base + 500)),
                1
            );
        }
    }
    // U8: rollback, then the same 500 rows succeed.
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        &format!(
            "INSERT INTO t VALUES {}",
            rows(90_000, 90_500, |_| "1".into())
        ),
    )
    .unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    db.execute(
        1,
        &format!(
            "INSERT INTO t VALUES {}",
            rows(90_000, 90_500, |n| (n % 3).to_string())
        ),
    )
    .unwrap();
    assert_eq!(count(&db, 3, "id>=90000"), 500);
    entries(&db);
    close(db, [1, 2, 3], &root);
}

/// U10 + heap: indexed UPDATE creating a duplicate (u and c), UPDATE that
/// expands rows (new page), DELETE; then checkpoint, reopen (recovery) and
/// the same checks.
#[test]
fn h_b3_indexed_update_duplicates_row_growth_delete_checkpoint_recovery() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    violation(&db, 1, "UPDATE t SET id=5 WHERE id=6");
    db.execute(1, "UPDATE t SET g=3 WHERE id=10").unwrap();
    violation(&db, 1, "UPDATE t SET v=10, g=3 WHERE id=11");
    db.execute(1, "CREATE TABLE s (id BIGINT NOT NULL, p TEXT NOT NULL)")
        .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX s_id ON s(id)").unwrap();
    let values = (0..500)
        .map(|n| format!("({n},'p{n}')"))
        .collect::<Vec<_>>()
        .join(",");
    db.execute(1, &format!("INSERT INTO s VALUES {values}"))
        .unwrap();
    // Expanding rows: each version grows ~600 bytes, forcing new pages.
    db.execute(
        1,
        &format!("UPDATE s SET p='{}' WHERE id<300", "x".repeat(600)),
    )
    .unwrap();
    db.execute(1, "DELETE FROM s WHERE id>=450").unwrap();
    db.execute(1, "CHECKPOINT").unwrap();
    db.execute(1, "UPDATE s SET p='short' WHERE id<10").unwrap();
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    entries(&db);
    let text = |sql: &str| match db.execute(2, sql).unwrap() {
        QueryResult::Rows { rows, .. } => format!("{:?}", rows[0].values[0]),
        other => panic!("{other:?}"),
    };
    assert_eq!(text("SELECT COUNT(*) AS n FROM s"), "Int64(450)");
    assert_eq!(
        text("SELECT COUNT(*) AS n FROM s WHERE p='short'"),
        "Int64(10)"
    );
    assert_eq!(
        text(&format!(
            "SELECT COUNT(*) AS n FROM s WHERE p='{}'",
            "x".repeat(600)
        )),
        "Int64(290)"
    );
    assert_eq!(count(&db, 2, "g=3 AND id=10"), 1);
    violation(&db, 2, "INSERT INTO s VALUES (7,'again')");
    close(db, [2], &root);
}

/// Heap/index under concurrency: 16 sessions each commit 500-row
/// transactions (in-place heap pages, encoded index merges, splits), while a
/// snapshot opened before them never changes (no committed image mutated).
#[test]
fn h_b4_sixteen_concurrent_500_row_transactions_and_unchanged_old_snapshot() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(99, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    assert_eq!(count(&db, 99, "id>=0"), 1000);
    let workers = (1..=16u64)
        .map(|session| {
            let db = db.clone();
            thread::spawn(move || {
                for round in 0..2i64 {
                    let base = 1_000_000 + session as i64 * 10_000 + round * 1000;
                    db.execute(session, "BEGIN").unwrap();
                    db.execute(
                        session,
                        &format!(
                            "INSERT INTO t VALUES {}",
                            rows(base, base + 250, |n| (n % 11).to_string())
                        ),
                    )
                    .unwrap();
                    db.execute(
                        session,
                        &format!(
                            "INSERT INTO t VALUES {}",
                            rows(base + 250, base + 500, |n| (n % 11).to_string())
                        ),
                    )
                    .unwrap();
                    db.execute(session, "COMMIT").unwrap();
                }
            })
        })
        .collect::<Vec<_>>();
    for worker in workers {
        worker.join().unwrap();
    }
    assert_eq!(count(&db, 99, "id>=0"), 1000, "old snapshot changed");
    assert_eq!(count(&db, 99, "g=3"), 0);
    db.execute(99, "COMMIT").unwrap();
    assert_eq!(count(&db, 98, "id>=1000000"), 16 * 2 * 500);
    assert_eq!(
        count(&db, 98, "g=3 AND id>=1000000"),
        (0..16 * 2 * 500).filter(|_| false).count() as i64 + {
            let mut n = 0;
            for session in 1..=16i64 {
                for round in 0..2i64 {
                    let base = 1_000_000 + session * 10_000 + round * 1000;
                    n += (base..base + 500).filter(|v| v % 11 == 3).count() as i64;
                }
            }
            n
        }
    );
    assert_eq!(entries(&db), 3 * (1000 + 16_000));
    close(db, (1..=16).chain([98, 99]), &root);
}
