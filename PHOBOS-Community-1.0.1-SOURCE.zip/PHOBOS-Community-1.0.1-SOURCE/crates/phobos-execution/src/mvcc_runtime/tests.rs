use super::*;
use phobos_storage::tuple_version::TupleVersion;
use phobos_txn::mvcc::{TransactionRegistry, Version};
use phobos_wal::v2::{FileId, PageAction, Wal};
use std::sync::atomic::{AtomicU64, Ordering};

#[test]
fn g5_snapshot_is_stable_lazy_and_sees_own_writes() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let before = db.commit_metrics();
    db.execute(10, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    db.execute(10, "SELECT COUNT(*) AS n FROM t").unwrap();
    db.execute(10, "COMMIT").unwrap();
    assert_eq!(db.commit_metrics(), before);

    db.execute(10, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    let first = db.execute(10, "SELECT COUNT(*) AS n FROM t").unwrap();
    db.execute(11, "INSERT INTO t VALUES (9001,9001,NULL)")
        .unwrap();
    assert_eq!(
        db.execute(10, "SELECT COUNT(*) AS n FROM t").unwrap(),
        first
    );
    db.execute(10, "COMMIT").unwrap();
    let after = db.commit_metrics();
    assert_eq!(after.ids_allocated, before.ids_allocated + 1); // session 11 only

    db.execute(10, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    db.execute(10, "INSERT INTO t VALUES (9002,9002,NULL)")
        .unwrap();
    assert_eq!(
        values(db.execute(10, "SELECT id FROM t WHERE id=9002").unwrap()).len(),
        1
    );
    db.execute(10, "ROLLBACK").unwrap();
    db.disconnect(10);
    db.disconnect(11);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn g5_snapshot_first_committer_wins_only_on_same_row() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(12, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    db.execute(12, "SELECT v FROM t WHERE id=1").unwrap();
    db.execute(13, "UPDATE t SET v=7001 WHERE id=1").unwrap();
    let error = db
        .execute(12, "UPDATE t SET v=7002 WHERE id=1")
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::TransactionState);
    db.execute(12, "ROLLBACK").unwrap();

    db.execute(12, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    db.execute(13, "UPDATE t SET v=7003 WHERE id=1").unwrap();
    db.execute(12, "UPDATE t SET v=7004 WHERE id=2").unwrap();
    db.execute(12, "COMMIT").unwrap();
    db.disconnect(12);
    db.disconnect(13);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn g5_nested_savepoints_restore_staged_and_failed_state() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(20, "BEGIN").unwrap();
    db.execute(20, "INSERT INTO t VALUES (9100,9100,NULL)")
        .unwrap();
    db.execute(20, "SAVEPOINT s1").unwrap();
    db.execute(20, "INSERT INTO t VALUES (9101,9101,NULL)")
        .unwrap();
    db.execute(20, "SAVEPOINT s2").unwrap();
    db.execute(20, "INSERT INTO t VALUES (9102,9102,NULL)")
        .unwrap();
    db.execute(20, "ROLLBACK TO SAVEPOINT s2").unwrap();
    db.execute(20, "RELEASE SAVEPOINT s2").unwrap();
    assert!(
        db.execute(20, "INSERT INTO t VALUES (9100,1,NULL)")
            .is_err()
    );
    db.execute(20, "ROLLBACK TO s1").unwrap();
    db.execute(20, "INSERT INTO t VALUES (9103,9103,NULL)")
        .unwrap();
    db.execute(20, "COMMIT").unwrap();
    assert_eq!(
        values(
            db.execute(21, "SELECT id FROM t WHERE id>=9100 ORDER BY id")
                .unwrap()
        )
        .into_iter()
        .map(|row| row.values[0].clone())
        .collect::<Vec<_>>(),
        vec![Value::Int64(9100), Value::Int64(9103)]
    );
    db.disconnect(20);
    db.disconnect(21);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn g5_savepoint_rollback_truncates_spilled_runs() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.set_write_spill(512, 8 * 1024 * 1024).unwrap();
    db.execute(22, "BEGIN").unwrap();
    db.execute(
        22,
        "INSERT INTO t VALUES (9200,1,NULL),(9201,1,NULL),(9202,1,NULL)",
    )
    .unwrap();
    db.execute(22, "SAVEPOINT kept").unwrap();
    db.execute(
        22,
        "INSERT INTO t VALUES (9203,1,NULL),(9204,1,NULL),(9205,1,NULL),(9206,1,NULL)",
    )
    .unwrap();
    db.execute(22, "ROLLBACK TO kept").unwrap();
    db.execute(22, "COMMIT").unwrap();
    assert_eq!(
        values(db.execute(23, "SELECT id FROM t WHERE id>=9200").unwrap()).len(),
        3
    );
    db.disconnect(22);
    db.disconnect(23);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn g6_range_partition_routes_reads_writes_and_reopens() {
    let root = fixture();
    let config = phobos_config::RuntimeConfig {
        parallel_scan_workers: 2,
        parallel_scan_min_pages: 1,
        ..phobos_config::RuntimeConfig::default()
    };
    let db = MvccDatabase::open_with_config(&root, &config).unwrap();
    db.execute(
        30,
        "CREATE TABLE events (id BIGINT NOT NULL, label TEXT) PARTITION BY RANGE (id)",
    )
    .unwrap();
    db.execute(
        30,
        "CREATE TABLE events_low PARTITION OF events FOR VALUES FROM (0) TO (100)",
    )
    .unwrap();
    db.execute(
        30,
        "CREATE TABLE events_high PARTITION OF events FOR VALUES FROM (100) TO (200)",
    )
    .unwrap();
    assert!(
        db.execute(
            30,
            "CREATE TABLE events_bad PARTITION OF events FOR VALUES FROM (50) TO (120)"
        )
        .is_err()
    );
    db.execute(30, "INSERT INTO events VALUES (150,'high'),(10,'low')")
        .unwrap();
    assert_eq!(
        values(db.execute(30, "SELECT id FROM events ORDER BY id").unwrap())
            .into_iter()
            .map(|row| row.values[0].clone())
            .collect::<Vec<_>>(),
        vec![Value::Int64(10), Value::Int64(150)]
    );
    assert_eq!(
        values(db.execute(30, "SELECT id FROM events_low").unwrap()).len(),
        1
    );
    assert!(
        db.execute(30, "INSERT INTO events VALUES (250,'missing')")
            .is_err()
    );
    db.disconnect(30);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        values(db.execute(31, "SELECT id FROM events ORDER BY id").unwrap()).len(),
        2
    );
    db.disconnect(31);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn g5_g6_snapshot_parallel_partition_count_shares_one_visibility_model() {
    let root = fixture();
    let config = phobos_config::RuntimeConfig {
        parallel_scan_workers: 4,
        parallel_scan_min_pages: 1,
        ..phobos_config::RuntimeConfig::default()
    };
    let db = MvccDatabase::open_with_config(&root, &config).unwrap();
    db.execute(
        40,
        "CREATE TABLE measurements (id BIGINT NOT NULL, value BIGINT) PARTITION BY RANGE (id)",
    )
    .unwrap();
    for (name, lower, upper) in [
        ("measurements_p0", 0, 100),
        ("measurements_p1", 100, 200),
        ("measurements_p2", 200, 300),
        ("measurements_p3", 300, 400),
    ] {
        db.execute(
            40,
            &format!(
                "CREATE TABLE {name} PARTITION OF measurements FOR VALUES FROM ({lower}) TO ({upper})"
            ),
        )
        .unwrap();
    }
    db.execute(
        40,
        "INSERT INTO measurements VALUES (10,1),(110,1),(210,1),(310,1)",
    )
    .unwrap();

    db.execute(41, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    let before = db
        .execute(41, "SELECT COUNT(*) AS n FROM measurements")
        .unwrap();
    db.execute(42, "INSERT INTO measurements VALUES (111,2)")
        .unwrap();
    assert_eq!(
        db.execute(41, "SELECT COUNT(*) AS n FROM measurements")
            .unwrap(),
        before
    );
    db.execute(41, "COMMIT").unwrap();
    assert_eq!(
        db.execute(41, "SELECT COUNT(*) AS n FROM measurements")
            .unwrap(),
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(5)])],
        }
    );
    db.disconnect(40);
    db.disconnect(41);
    db.disconnect(42);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c7_bulk_force_error_returns_no_success_fences_and_recovers_atomically() {
    use std::time::Duration;
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.bulk_begin(1, "t").unwrap();
    db.bulk_batch(
        1,
        &(2000..2100)
            .map(|id| Row::new(vec![Value::Int64(id), Value::Int64(id), Value::Null]))
            .collect::<Vec<_>>(),
    )
    .unwrap();
    db.wal.lock().unwrap().fail_next_force_for_test();
    assert!(db.execute(1, "COMMIT").is_err());
    assert!(db.execute(2, "SELECT id FROM t").is_err());
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    // A complete appended chain may recover despite an unacknowledged force
    // failure. It must never recover only a prefix of this import.
    // 0.2-E Mode E: the failed force wrote nothing, so the whole import is
    // absent; Mode A may recover the complete appended chain. Never a prefix,
    // and both reopens agree.
    let mut seen = None;
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        let result = db
            .execute(1, "SELECT COUNT(*) AS n FROM t WHERE id>=2000")
            .unwrap();
        assert!(
            [0, 100].into_iter().any(|n| result
                == QueryResult::Rows {
                    columns: vec!["n".into()],
                    rows: vec![Row::new(vec![Value::Int64(n)])]
                }),
            "{result:?}"
        );
        assert_eq!(*seen.get_or_insert(result.clone()), result);
        db.disconnect(1);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
    }
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c7_bulk_internal_atomic_batches_constraints_and_reader_visibility() {
    use std::time::Duration;
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let row = |id| Row::new(vec![Value::Int64(id), Value::Int64(id), Value::Null]);
    db.bulk_begin(1, "t").unwrap();
    db.bulk_batch(1, &(2000..2200).map(row).collect::<Vec<_>>())
        .unwrap();
    assert_eq!(
        db.execute(2, "SELECT COUNT(*) AS n FROM t WHERE id>=2000")
            .unwrap(),
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(0)])]
        }
    );
    assert!(
        db.execute(2, "INSERT INTO t VALUES (3000,3000,NULL)")
            .is_err()
    );
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(
        db.execute(2, "SELECT COUNT(*) AS n FROM t WHERE id>=2000")
            .unwrap(),
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(200)])]
        }
    );
    for failure in 0..7 {
        db.bulk_begin(1, "t").unwrap();
        db.bulk_batch(1, &[row(3000)]).unwrap();
        match failure {
            // C9: unique violations against the committed index (0) and inside
            // the import (1) are detected by the sorted COMMIT validation.
            0 => {
                db.bulk_batch(1, &[row(2000)]).unwrap();
            }
            1 => {
                db.bulk_batch(1, &[row(3000)]).unwrap();
            }
            2 => {
                assert!(db.bulk_batch(1, &[Row::new(vec![Value::Null])]).is_err());
            }
            3 => {
                assert!(db.bulk_batch(1, &vec![row(4000); 1025]).is_err());
            }
            4 => {
                assert!(
                    db.bulk_batch(
                        1,
                        &[Row::new(vec![Value::Null, Value::Int64(1), Value::Null])]
                    )
                    .is_err()
                );
            }
            _ => {
                let value = if failure == 5 {
                    Value::Binary(vec![0; 2 * 1024 * 1024])
                } else {
                    Value::Text("x".repeat(2 * 1024 * 1024))
                };
                assert_eq!(
                    db.bulk_batch(1, &[Row::new(vec![Value::Int64(4000), value, Value::Null])])
                        .unwrap_err()
                        .code,
                    ErrorCode::ResourceLimit
                );
            }
        }
        assert!(db.execute(1, "COMMIT").is_err());
        db.execute(1, "ROLLBACK").unwrap();
    }
    db.bulk_begin(1, "t").unwrap();
    db.bulk_batch(1, &[row(3000)]).unwrap();
    db.disconnect(1);
    assert!(
        db.bulk_load(
            1,
            "t",
            (3000..3100).map(|id| if id == 3080 {
                Err(write_conflict("input error"))
            } else {
                Ok(row(id))
            })
        )
        .is_err()
    );
    assert_eq!(
        db.bulk_load(1, "t", (3000..3300).map(|id| Ok(row(id))))
            .unwrap(),
        300
    );
    for id in [1, 2] {
        db.disconnect(id);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        assert_eq!(
            db.execute(1, "SELECT COUNT(*) AS n FROM t WHERE id>=2000")
                .unwrap(),
            QueryResult::Rows {
                columns: vec!["n".into()],
                rows: vec![Row::new(vec![Value::Int64(500)])]
            }
        );
        db.disconnect(1);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
    }
    assert!(!fs::read_dir(&root).unwrap().any(|p| {
        p.unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with(".phobos-mvcc-bulk-")
    }));
    fs::remove_dir_all(root).unwrap();
}

fn bulk_scratch_dirs(root: &Path) -> Vec<PathBuf> {
    fs::read_dir(root)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| {
            path.file_name()
                .unwrap()
                .to_string_lossy()
                .starts_with(".phobos-mvcc-bulk-")
        })
        .collect()
}
fn count_from(db: &MvccDatabase, session: u64, from: i64) -> i64 {
    match db
        .execute(
            session,
            &format!("SELECT COUNT(*) AS n FROM t WHERE id>={from}"),
        )
        .unwrap()
    {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            _ => panic!("count"),
        },
        _ => panic!("count result"),
    }
}

/// C9 scratch accounting: the quota is enforced from an exact running total
/// instead of a per-chunk directory walk. Oversized imports are still rejected
/// with the same error, at staging and at COMMIT, and ROLLBACK removes scratch.
#[test]
fn c9_scratch_quota_rejects_oversized_import_at_staging_and_commit_then_rolls_back() {
    use std::time::Duration;
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let row = |id| {
        Row::new(vec![
            Value::Int64(id),
            Value::Int64(id),
            Value::Int64(id % 7),
        ])
    };
    // 1. Staging: a 1 KiB quota cannot hold one 64-row chunk.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, 1024, 8).unwrap();
    assert_eq!(
        db.bulk_batch(1, &(5000..5064).map(row).collect::<Vec<_>>())
            .unwrap_err()
            .code,
        ErrorCode::ResourceLimit
    );
    assert!(db.execute(1, "COMMIT").is_err());
    db.execute(1, "ROLLBACK").unwrap();
    assert!(bulk_scratch_dirs(&root).is_empty());
    assert_eq!(count_from(&db, 2, 5000), 0);
    // 2. COMMIT: staging fits, but the final spill of the buffered keys at
    //    finalize crosses the quota. Detected before admission; nothing lands.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 1 << 20).unwrap();
    db.bulk_batch(1, &(5000..5040).map(row).collect::<Vec<_>>())
        .unwrap();
    let (accounted, measured, runs) = db.bulk_scratch_state(1).unwrap();
    assert_eq!(accounted, measured);
    assert!(accounted > 0);
    assert!(runs.iter().all(|count| *count == 0), "no spill yet");
    db.bulk_test_bounds(1, accounted + 1, 1 << 20).unwrap();
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::ResourceLimit
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert!(bulk_scratch_dirs(&root).is_empty());
    assert_eq!(count_from(&db, 2, 5000), 0);
    // 3. The same rows import under the production quota.
    assert_eq!(
        db.bulk_load(1, "t", (5000..5064).map(|id| Ok(row(id))))
            .unwrap(),
        64
    );
    assert_eq!(count_from(&db, 2, 5000), 64);
    for id in [1, 2] {
        db.disconnect(id);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    assert!(bulk_scratch_dirs(&root).is_empty());
    fs::remove_dir_all(root).unwrap();
}

/// C9 scratch accounting stays byte-exact through every spill, the k-way
/// merge, a cascaded merge (more runs than the fan-in), the removal of
/// consumed run and merge files, ROLLBACK after finalize, a real cascaded
/// COMMIT, and an unacknowledged force with recovery.
#[test]
fn c9_scratch_accounting_exact_across_spills_cascade_deletion_rollback_and_recovery() {
    use std::time::Duration;
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let row = |id| {
        Row::new(vec![
            Value::Int64(id),
            Value::Int64(id),
            Value::Int64(id % 7),
        ])
    };
    // 4 keys per run: 700 rows -> 175 runs per index, beyond the fallback
    // fan-in (128) used here so the cascade path is exercised.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, bulk::MERGE_FAN_IN_FALLBACK, None, None)
        .unwrap();
    let mut staged = 0;
    for chunk in (5000..5700).collect::<Vec<_>>().chunks(7) {
        staged = db
            .bulk_batch(1, &chunk.iter().map(|id| row(*id)).collect::<Vec<_>>())
            .unwrap();
        let (accounted, measured, _) = db.bulk_scratch_state(1).unwrap();
        assert_eq!(accounted, measured, "after {staged} rows");
    }
    assert_eq!(staged, 700);
    let (before, measured, runs) = db.bulk_scratch_state(1).unwrap();
    assert_eq!(before, measured);
    assert_eq!(runs.len(), 3, "one run set per index");
    assert!(
        runs.iter()
            .all(|count| *count > bulk::MERGE_FAN_IN_FALLBACK),
        "{runs:?}"
    );
    // Finalize (sort, cascade, merge, validate) without admitting: the total
    // must still match the directory, and only the row spool plus one sorted
    // file per index may remain (every run and merge file removed).
    let (accounted, measured, names) = db.bulk_finalize_for_test(1).unwrap();
    assert_eq!(accounted, measured);
    assert!(accounted > 0);
    assert_eq!(names.len(), 4, "{names:?}");
    assert_eq!(names.iter().filter(|name| *name == "rows").count(), 1);
    assert_eq!(
        names
            .iter()
            .filter(|name| name.starts_with("sorted-"))
            .count(),
        3,
        "{names:?}"
    );
    // Rollback after finalize drops every scratch file; nothing was admitted.
    db.execute(1, "ROLLBACK").unwrap();
    assert!(bulk_scratch_dirs(&root).is_empty());
    assert_eq!(count_from(&db, 2, 5000), 0);
    // The same cascaded import through the real COMMIT path (finalize proves
    // its own accounting against the directory before admission).
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, bulk::MERGE_FAN_IN_FALLBACK, None, None)
        .unwrap();
    for chunk in (5000..5700).collect::<Vec<_>>().chunks(64) {
        db.bulk_batch(1, &chunk.iter().map(|id| row(*id)).collect::<Vec<_>>())
            .unwrap();
    }
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(count_from(&db, 2, 5000), 700);
    assert!(bulk_scratch_dirs(&root).is_empty());
    // A duplicate inside a cascaded import is still caught at COMMIT.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, bulk::MERGE_FAN_IN_FALLBACK, None, None)
        .unwrap();
    db.bulk_batch(1, &(6000..6600).map(row).collect::<Vec<_>>())
        .unwrap();
    db.bulk_batch(1, &[row(6100)]).unwrap();
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::ConstraintViolation
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert_eq!(count_from(&db, 2, 6000), 0);
    // Unacknowledged force after a cascaded import: no success is reported and
    // recovery is all-or-nothing, exactly as for C7/C9 imports before this change.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, bulk::MERGE_FAN_IN_FALLBACK, None, None)
        .unwrap();
    db.bulk_batch(1, &(6000..6600).map(row).collect::<Vec<_>>())
        .unwrap();
    db.wal.lock().unwrap().fail_next_force_for_test();
    assert!(db.execute(1, "COMMIT").is_err());
    assert!(db.execute(2, "SELECT id FROM t").is_err());
    for id in [1, 2] {
        db.disconnect(id);
    }
    drop(db);
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        // All-or-nothing (Mode E writes nothing of a failed force).
        let n = count_from(&db, 1, 5000);
        assert!(n == 700 + 600 || n == 700, "{n}");
        db.disconnect(1);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
    }
    assert!(bulk_scratch_dirs(&root).is_empty());
    fs::remove_dir_all(root).unwrap();
}

/// Bounded fan-in merge: single pass up to the fan-in, cascades beyond it,
/// exact accounting and cleanup at every boundary, duplicate unique keys across
/// distant runs still rejected, the open-file-limit fallback, rollback, and
/// recovery after an unacknowledged force of a cascaded import.
#[test]
fn c9_merge_fan_in_boundaries_cascade_fallback_duplicates_rollback_and_recovery() {
    use std::time::Duration;
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let row = |id| {
        Row::new(vec![
            Value::Int64(id),
            Value::Int64(id),
            Value::Int64(id % 7),
        ])
    };
    // 4 keys per run. (fan-in, rows -> runs per index, expected fallbacks).
    /// (fan-in, rows, simulated open limit, merge attempt refused once, expected fallbacks)
    type MergeCase = (usize, i64, Option<usize>, Option<u32>, u32);
    let cases: [MergeCase; 10] = [
        (8, 28, None, None, 0),         // 7 runs: below fan-in, single pass
        (8, 32, None, None, 0),         // 8 runs: exactly fan-in, single pass
        (8, 36, None, None, 0),         // 9 runs: fan-in + 1, one cascade pass
        (8, 612, None, None, 0),        // 153 runs: the 10M shape, multi-level cascade
        (8, 5200, None, None, 0),       // 1,300 runs: three cascade levels
        (512, 2044, None, None, 0),     // 511 runs: below the production fan-in
        (512, 2048, None, None, 0),     // 512 runs: exactly the production fan-in
        (512, 2052, None, None, 0),     // 513 runs: production fan-in + 1
        (512, 612, Some(128), None, 1), // 153 runs, OS allows 128: fallback, then cascade
        (512, 5200, None, Some(2), 1),  // 1,300 runs: refusal after 1 finished intermediate
    ];
    let mut next = 5000i64;
    for (case, (fan_in, rows, open_limit, fail_at, fallbacks)) in cases.iter().enumerate() {
        let start = next;
        next += rows;
        db.bulk_begin(1, "t").unwrap();
        db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
        db.bulk_test_merge(1, *fan_in, *open_limit, *fail_at)
            .unwrap();
        for chunk in (start..start + rows).collect::<Vec<_>>().chunks(64) {
            db.bulk_batch(1, &chunk.iter().map(|id| row(*id)).collect::<Vec<_>>())
                .unwrap();
        }
        let (_, _, runs) = db.bulk_scratch_state(1).unwrap();
        let expected_runs = ((*rows as usize) / 4).saturating_sub(1);
        assert!(
            runs.iter().all(|count| *count >= expected_runs),
            "case {case}: {runs:?}"
        );
        // Finalize without admitting: accounting exact, only rows + sorted files remain.
        let (accounted, measured, names) = db.bulk_finalize_for_test(1).unwrap();
        assert_eq!(accounted, measured, "case {case}");
        assert_eq!(names.len(), 4, "case {case}: {names:?}");
        assert!(
            names
                .iter()
                .all(|name| name == "rows" || name.starts_with("sorted-")),
            "case {case}: intermediates left behind: {names:?}"
        );
        assert_eq!(
            db.bulk_merge_fallbacks(1).unwrap(),
            *fallbacks,
            "case {case}"
        );
        db.execute(1, "ROLLBACK").unwrap();
        assert!(bulk_scratch_dirs(&root).is_empty(), "case {case}");
        assert_eq!(count_from(&db, 2, start), 0, "case {case}");
        // The same rows through the real COMMIT: exact count, sorted keys usable.
        db.bulk_begin(1, "t").unwrap();
        db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
        db.bulk_test_merge(1, *fan_in, *open_limit, *fail_at)
            .unwrap();
        for chunk in (start..start + rows).collect::<Vec<_>>().chunks(64) {
            db.bulk_batch(1, &chunk.iter().map(|id| row(*id)).collect::<Vec<_>>())
                .unwrap();
        }
        db.execute(1, "COMMIT").unwrap();
        assert_eq!(count_from(&db, 2, start), *rows, "case {case}");
        assert_eq!(
            db.execute(
                2,
                &format!("SELECT COUNT(*) AS n FROM t WHERE id={}", start + rows - 1)
            )
            .unwrap(),
            QueryResult::Rows {
                columns: vec!["n".into()],
                rows: vec![Row::new(vec![Value::Int64(1)])]
            },
            "case {case}: last key reachable through the unique index"
        );
        assert!(bulk_scratch_dirs(&root).is_empty(), "case {case}");
    }
    let committed = next - 5000;
    // Duplicate unique keys in distant runs (cascaded merge) are still rejected at COMMIT.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, 8, None, None).unwrap();
    db.bulk_batch(1, &(next..next + 600).map(row).collect::<Vec<_>>())
        .unwrap();
    db.bulk_batch(1, &[row(next + 3)]).unwrap();
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::ConstraintViolation
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert!(bulk_scratch_dirs(&root).is_empty());
    // A committed key duplicated by a later cascaded import is rejected too.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, 8, None, None).unwrap();
    db.bulk_batch(1, &(next..next + 600).map(row).collect::<Vec<_>>())
        .unwrap();
    db.bulk_batch(1, &[row(5000)]).unwrap();
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::ConstraintViolation
    );
    db.execute(1, "ROLLBACK").unwrap();
    // The OS refusing even the fallback fan-in fails the import cleanly (no partial state).
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, 512, Some(8), None).unwrap();
    db.bulk_batch(1, &(next..next + 600).map(row).collect::<Vec<_>>())
        .unwrap();
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::ResourceLimit
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert!(bulk_scratch_dirs(&root).is_empty());
    assert_eq!(count_from(&db, 2, 5000), committed);
    // Unacknowledged force after a cascaded import: all-or-nothing on two reopens.
    db.bulk_begin(1, "t").unwrap();
    db.bulk_test_bounds(1, u64::MAX, 4).unwrap();
    db.bulk_test_merge(1, 8, None, None).unwrap();
    db.bulk_batch(1, &(next..next + 600).map(row).collect::<Vec<_>>())
        .unwrap();
    db.wal.lock().unwrap().fail_next_force_for_test();
    assert!(db.execute(1, "COMMIT").is_err());
    assert!(db.execute(2, "SELECT id FROM t").is_err());
    for id in [1, 2] {
        db.disconnect(id);
    }
    drop(db);
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        // All-or-nothing (Mode E writes nothing of a failed force).
        let n = count_from(&db, 1, 5000);
        assert!(n == committed + 600 || n == committed, "{n}");
        db.disconnect(1);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
    }
    assert!(bulk_scratch_dirs(&root).is_empty());
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c6_oversized_index_key_is_rejected_before_irrevocable_commit_admission() {
    use std::time::Duration;
    for unique in [false, true] {
        let root = fixture();
        let database = MvccDatabase::open(&root).unwrap();
        database
            .execute(1, "CREATE TABLE names (label TEXT)")
            .unwrap();
        database
            .execute(
                1,
                if unique {
                    "CREATE UNIQUE INDEX labels ON names(label)"
                } else {
                    "CREATE INDEX labels ON names(label)"
                },
            )
            .unwrap();
        database.execute(1, "BEGIN").unwrap();
        let error = database
            .execute(
                1,
                &format!("INSERT INTO names VALUES ('{}')", "x".repeat(3000)),
            )
            .unwrap_err();
        assert_eq!(error.code, ErrorCode::ConstraintViolation);
        database.execute(1, "ROLLBACK").unwrap();
        database
            .execute(2, "INSERT INTO names VALUES ('valid')")
            .unwrap();
        assert_eq!(
            database
                .execute(2, "SELECT label FROM names WHERE label='valid'")
                .unwrap(),
            QueryResult::Rows {
                columns: vec!["label".into()],
                rows: vec![Row::new(vec![Value::Text("valid".into())])]
            }
        );
        database.disconnect(1);
        database.disconnect(2);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn c6_sql_row_and_unique_timeout_release_prior_ownership_before_rollback() {
    use std::time::Duration;
    for unique in [false, true] {
        let root = fixture();
        let database = MvccDatabase::open(&root).unwrap();
        database.execute(1, "BEGIN").unwrap();
        database.execute(2, "BEGIN").unwrap();
        database
            .execute(1, "UPDATE t SET v=10001 WHERE id=1")
            .unwrap();
        let sql = if unique {
            "INSERT INTO t VALUES (2000,2000,0)"
        } else {
            "UPDATE t SET v=10002 WHERE id=2"
        };
        database.execute(2, sql).unwrap();
        let error = database.execute(1, sql).unwrap_err();
        assert_eq!(error.code, ErrorCode::LockTimeout);
        database
            .execute(2, "UPDATE t SET v=10003 WHERE id=1")
            .unwrap();
        database.execute(2, "COMMIT").unwrap();
        // A timed-out transaction is failed, not an invisible active owner.
        assert!(database.execute(1, "SELECT id FROM t").is_err());
        database.execute(1, "ROLLBACK").unwrap();
        database.execute(1, "BEGIN").unwrap();
        database
            .execute(1, "UPDATE t SET v=10004 WHERE id=1")
            .unwrap();
        database.execute(1, "COMMIT").unwrap();
        let diagnostics = database.conflict_diagnostics().unwrap();
        let stats = if unique {
            diagnostics.unique
        } else {
            diagnostics.row
        };
        assert_eq!(stats.timeouts, 1);
        assert_eq!(stats.waits, 1);
        assert!(diagnostics.active.is_empty());
        database.disconnect(1);
        database.disconnect(2);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn c6_dependent_heap_and_index_prepare_after_predecessor_redo_in_queue_order() {
    use std::{sync::mpsc, thread, time::Duration};
    let root = fixture();
    let database = Arc::new(MvccDatabase::open(&root).unwrap());
    for id in 1..=3 {
        database.execute(id, "BEGIN").unwrap();
        database
            .execute(id, &format!("UPDATE t SET v=v+10000 WHERE id={id}"))
            .unwrap();
    }
    let (queued, queue) = mpsc::channel();
    let (started, start) = mpsc::channel();
    let (release, released) = mpsc::channel();
    let released = Mutex::new(released);
    let events = Arc::new(Mutex::new(Vec::new()));
    let recorded = events.clone();
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |point| {
            if point == "c6_commit_enqueued" {
                queued.send(()).unwrap();
            }
            if matches!(
                point,
                "c6_private_preparation_begin"
                    | "c6_private_redo_staged"
                    | "c5_after_visibility_publication"
            ) {
                let mut events = recorded.lock().unwrap();
                events.push(point.to_owned());
                let first = events.len() == 1;
                drop(events);
                if first {
                    started.send(()).unwrap();
                    released
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
            }
        }),
    );
    let first_db = database.clone();
    let mut commits = vec![thread::spawn(move || first_db.execute(1, "COMMIT"))];
    start.recv_timeout(Duration::from_secs(10)).unwrap();
    queue.recv_timeout(Duration::from_secs(10)).unwrap();
    // The leader is paused with the physical owner. Enqueue the dependent
    // commits in a known order before allowing it to finish its first cohort.
    for id in 2..=3 {
        let database = database.clone();
        commits.push(thread::spawn(move || database.execute(id, "COMMIT")));
        queue.recv_timeout(Duration::from_secs(10)).unwrap();
    }
    release.send(()).unwrap();
    for commit in commits {
        commit.join().unwrap().unwrap();
    }
    drop(hook);
    // 0.2-C pipelined group commit: the second cohort may prepare (on its
    // predecessor's staged redo, in queue order) while the first cohort's WAL
    // force is outstanding, so publication of cohort 1 may land before or
    // after cohort 2's preparation. Preparation stays strictly ordered and
    // serialized, and every publication follows its own staged redo.
    let events = events.lock().unwrap().clone();
    let preparation: Vec<_> = events
        .iter()
        .filter(|event| *event != "c5_after_visibility_publication")
        .cloned()
        .collect();
    assert_eq!(
        preparation,
        [
            "c6_private_preparation_begin",
            "c6_private_redo_staged",
            "c6_private_preparation_begin",
            "c6_private_redo_staged",
            "c6_private_preparation_begin",
            "c6_private_redo_staged",
        ]
    );
    assert_eq!(events.len(), 9);
    assert_eq!(events[0], "c6_private_preparation_begin");
    assert_eq!(events[1], "c6_private_redo_staged");
    let first_publication = events
        .iter()
        .position(|event| event == "c5_after_visibility_publication")
        .unwrap();
    assert!(first_publication >= 2);
    // The later whole-page image must contain its predecessor's tuple and
    // index additions. Point and range paths must resolve every new version.
    for reopen in 0..2 {
        let db = if reopen == 0 {
            database.clone()
        } else {
            Arc::new(MvccDatabase::open(&root).unwrap())
        };
        for id in 1..=3 {
            assert_eq!(
                db.execute(99, &format!("SELECT v FROM t WHERE id={id}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["v".into()],
                    rows: vec![Row::new(vec![Value::Int64(id + 10000)])]
                }
            );
        }
        assert_eq!(
            db.execute(
                99,
                "SELECT COUNT(*) AS n FROM t WHERE id>=1 AND id<=3 AND v>=10001"
            )
            .unwrap(),
            QueryResult::Rows {
                columns: vec!["n".into()],
                rows: vec![Row::new(vec![Value::Int64(3)])]
            }
        );
        for id in [1, 2, 3, 99] {
            db.disconnect(id);
        }
        db.shutdown(Duration::from_secs(10)).unwrap();
    }
    drop(database);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c6_sql_two_four_eight_same_page_writers_resolve_without_database_owner() {
    use std::{sync::mpsc, thread, time::Duration};
    for writers in [2, 4, 8] {
        let root = fixture();
        let database = Arc::new(MvccDatabase::open(&root).unwrap());
        for id in 1..=writers {
            database.execute(id, "BEGIN").unwrap();
        }
        let physical_owner = database.lock_database().unwrap();
        let (send, completed) = mpsc::channel();
        let mut workers = Vec::new();
        for id in 1..=writers {
            let database = database.clone();
            let send = send.clone();
            workers.push(thread::spawn(move || {
                send.send(database.execute(id, &format!("UPDATE t SET v=v+10000 WHERE id={id}")))
                    .unwrap();
            }));
        }
        let mut results = Vec::new();
        for _ in 1..=writers {
            results.push(completed.recv_timeout(Duration::from_secs(10)));
        }
        drop(physical_owner);
        for worker in workers {
            worker.join().unwrap();
        }
        for result in results {
            result.unwrap().unwrap();
        }
        for id in 1..=writers {
            assert_eq!(
                database
                    .execute(id, &format!("SELECT v FROM t WHERE id={id}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["v".into()],
                    rows: vec![Row::new(vec![Value::Int64(id as i64 + 10000)])]
                }
            );
            assert_eq!(
                database
                    .execute(99, &format!("SELECT v FROM t WHERE id={id}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["v".into()],
                    rows: vec![Row::new(vec![Value::Int64(id as i64)])]
                }
            );
        }
        let mut commits = Vec::new();
        for id in 1..=writers {
            let database = database.clone();
            commits.push(thread::spawn(move || database.execute(id, "COMMIT")));
        }
        for commit in commits {
            commit.join().unwrap().unwrap();
        }
        for id in 1..=writers {
            assert_eq!(
                database
                    .execute(99, &format!("SELECT v FROM t WHERE id={id}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["v".into()],
                    rows: vec![Row::new(vec![Value::Int64(id as i64 + 10000)])]
                }
            );
            database.disconnect(id);
        }
        database.disconnect(99);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        let reopened = MvccDatabase::open(&root).unwrap();
        for id in 1..=writers {
            assert_eq!(
                reopened
                    .execute(99, &format!("SELECT v FROM t WHERE id={id}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["v".into()],
                    rows: vec![Row::new(vec![Value::Int64(id as i64 + 10000)])]
                }
            );
        }
        reopened.disconnect(99);
        reopened.shutdown(Duration::from_secs(10)).unwrap();
        drop(reopened);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn c6_sql_two_four_eight_disjoint_domains_prepare_in_parallel() {
    use std::{
        sync::{Condvar, mpsc},
        thread,
        time::Duration,
    };
    for writers in [2, 4, 8] {
        let root = fixture();
        let database = Arc::new(MvccDatabase::open(&root).unwrap());
        for n in 0..writers {
            database
                .execute(99, &format!("CREATE TABLE p{n} (id BIGINT NOT NULL)"))
                .unwrap();
            database
                .execute(99, &format!("CREATE UNIQUE INDEX p{n}_id ON p{n}(id)"))
                .unwrap();
        }
        for n in 0..writers {
            database.execute(n + 10, "BEGIN").unwrap();
            database
                .execute(n + 10, &format!("INSERT INTO p{n} VALUES (1)"))
                .unwrap();
        }
        database.execute(1, "BEGIN").unwrap();
        database
            .execute(1, "INSERT INTO t VALUES (9000,9000,NULL)")
            .unwrap();
        let (enqueued, queue_wait) = mpsc::channel();
        let (prepared, prepare_wait) = mpsc::channel();
        let (release_leader, leader_wait) = mpsc::channel();
        let leader_wait = Mutex::new(leader_wait);
        let gate = Arc::new((Mutex::new(false), Condvar::new()));
        let hook_gate = gate.clone();
        let started = AtomicU64::new(0);
        let hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |point| {
                if point == "c6_commit_enqueued" {
                    let _ = enqueued.send(());
                }
                if point == "c6_private_preparation_begin" {
                    let sequence = started.fetch_add(1, Ordering::AcqRel);
                    prepared.send(sequence).unwrap();
                    if sequence == 0 {
                        leader_wait
                            .lock()
                            .unwrap()
                            .recv_timeout(Duration::from_secs(10))
                            .unwrap();
                    } else {
                        let (lock, changed) = &*hook_gate;
                        let (released, timeout) = changed
                            .wait_timeout_while(
                                lock.lock().unwrap(),
                                Duration::from_secs(10),
                                |released| !*released,
                            )
                            .unwrap();
                        assert!(
                            *released && !timeout.timed_out(),
                            "parallel preparation did not overlap"
                        );
                    }
                }
            }),
        );
        let (finished, completion) = mpsc::channel();
        let worker_db = database.clone();
        let done = finished.clone();
        let mut handles = vec![thread::spawn(move || {
            done.send(worker_db.execute(1, "COMMIT")).unwrap();
        })];
        assert_eq!(
            prepare_wait.recv_timeout(Duration::from_secs(10)).unwrap(),
            0
        );
        for n in 0..writers {
            let worker_db = database.clone();
            let done = finished.clone();
            handles.push(thread::spawn(move || {
                done.send(worker_db.execute(n + 10, "COMMIT")).unwrap();
            }));
        }
        for _ in 0..=writers {
            queue_wait.recv_timeout(Duration::from_secs(10)).unwrap();
        }
        release_leader.send(()).unwrap();
        for _ in 0..writers {
            assert!(prepare_wait.recv_timeout(Duration::from_secs(10)).unwrap() > 0);
        }
        // All physical workers are simultaneously paused, owning separate files.
        // Ordinary SQL readers still progress and cannot see their private rows.
        for n in 0..writers {
            assert_eq!(
                database
                    .execute(99, &format!("SELECT COUNT(*) AS n FROM p{n}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["n".into()],
                    rows: vec![Row::new(vec![Value::Int64(0)])]
                }
            );
        }
        *gate.0.lock().unwrap() = true;
        gate.1.notify_all();
        for _ in 0..=writers {
            completion
                .recv_timeout(Duration::from_secs(10))
                .unwrap()
                .unwrap();
        }
        for handle in handles {
            handle.join().unwrap();
        }
        drop(hook);
        for n in 0..writers {
            assert_eq!(
                database
                    .execute(99, &format!("SELECT id FROM p{n}"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["id".into()],
                    rows: vec![Row::new(vec![Value::Int64(1)])]
                }
            );
            database.disconnect(n + 10);
        }
        database.disconnect(1);
        database.disconnect(99);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn c6_statement_readers_progress_while_mutable_database_owner_is_paused() {
    use std::{sync::mpsc, thread, time::Duration};
    let root = fixture();
    let database = Arc::new(MvccDatabase::open(&root).unwrap());
    let owner = database.lock_database().unwrap();
    let (complete, completed) = mpsc::channel();
    let worker_db = database.clone();
    let worker = thread::spawn(move || {
        complete
            .send(worker_db.execute(1, "SELECT v FROM t WHERE id=1"))
            .unwrap();
    });
    let result = completed.recv_timeout(Duration::from_secs(10));
    drop(owner);
    worker.join().unwrap();
    assert_eq!(
        result.unwrap().unwrap(),
        QueryResult::Rows {
            columns: vec!["v".into()],
            rows: vec![Row::new(vec![Value::Int64(1)])],
        }
    );
    database.disconnect(1);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c6_two_row_cycle_aborts_younger_and_releases_ownership_in_both_begin_orders() {
    use std::{sync::mpsc, thread, time::Duration};
    for (older, younger) in [(11, 12), (12, 11)] {
        let root = fixture();
        let database = Arc::new(MvccDatabase::open(&root).unwrap());
        database.execute(older, "BEGIN").unwrap();
        database.execute(younger, "BEGIN").unwrap();
        database
            .execute(older, "UPDATE t SET v=10001 WHERE id=1")
            .unwrap();
        database
            .execute(younger, "UPDATE t SET v=10002 WHERE id=2")
            .unwrap();
        let (signal, waiting) = mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |point| {
                if point == "c5_row_wait" {
                    let _ = signal.send(());
                }
            }),
        );
        let (complete, completed) = mpsc::channel();
        let worker_db = database.clone();
        let worker = thread::spawn(move || {
            let result = worker_db.execute(older, "UPDATE t SET v=10003 WHERE id=2");
            complete.send(result).unwrap();
        });
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        let error = database
            .execute(younger, "UPDATE t SET v=10004 WHERE id=1")
            .unwrap_err();
        assert!(error.message.contains("younger transaction"), "{error:?}");
        // The older transaction must wake before the client rolls its victim back.
        completed
            .recv_timeout(Duration::from_secs(10))
            .unwrap()
            .unwrap();
        worker.join().unwrap();
        assert!(database.execute(younger, "COMMIT").is_err());
        database.execute(older, "COMMIT").unwrap();
        database.execute(younger, "ROLLBACK").unwrap();
        let diagnostics = database.conflict_diagnostics().unwrap();
        assert_eq!(diagnostics.row.victims, 1);
        assert_eq!(diagnostics.row.waits, 1);
        assert!(diagnostics.active.is_empty());
        assert_eq!(diagnostics.row.histogram.iter().sum::<u64>(), 1);
        drop(hook);
        database.disconnect(older);
        database.disconnect(younger);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn c6_cancel_row_and_unique_wait_discards_private_changes_before_rollback() {
    use std::{sync::mpsc, thread, time::Duration};
    for unique in [false, true] {
        let root = fixture();
        let database = Arc::new(MvccDatabase::open(&root).unwrap());
        database.execute(1, "BEGIN").unwrap();
        database.execute(2, "BEGIN").unwrap();
        database
            .execute(1, "UPDATE t SET v=10001 WHERE id=1")
            .unwrap();
        let sql = if unique {
            "INSERT INTO t VALUES (2000,2000,0)"
        } else {
            "UPDATE t SET v=10002 WHERE id=2"
        };
        database.execute(2, sql).unwrap();
        let (signal, waiting) = mpsc::channel();
        let hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |point| {
                if point
                    == if unique {
                        "c5_unique_wait"
                    } else {
                        "c5_row_wait"
                    }
                {
                    let _ = signal.send(());
                }
            }),
        );
        let worker_db = database.clone();
        let (complete, completed) = mpsc::channel();
        let worker = thread::spawn(move || {
            complete.send(worker_db.execute(1, sql)).unwrap();
        });
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        database.cancel(1);
        let error = completed
            .recv_timeout(Duration::from_secs(10))
            .unwrap()
            .unwrap_err();
        assert!(error.message.contains("cancelled"), "{error:?}");
        worker.join().unwrap();
        // Cancellation also releases the first row, before explicit ROLLBACK.
        database
            .execute(2, "UPDATE t SET v=10003 WHERE id=1")
            .unwrap();
        database.execute(2, "COMMIT").unwrap();
        database.execute(1, "ROLLBACK").unwrap();
        let diagnostics = database.conflict_diagnostics().unwrap();
        let stats = if unique {
            diagnostics.unique
        } else {
            diagnostics.row
        };
        assert_eq!(stats.cancellations, 1);
        assert_eq!(stats.histogram.iter().sum::<u64>(), 1);
        assert!(diagnostics.active.is_empty());
        drop(hook);
        database.disconnect(1);
        database.disconnect(2);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }
}

pub(super) fn fixture() -> PathBuf {
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let root = std::env::temp_dir().join(format!(
        "phobos-c5-runtime-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    let mut wal = Wal::create_with_versioned_heap(&root).unwrap();
    let root = fs::canonicalize(root).unwrap();
    let mut registry =
        TransactionRegistry::new(StatusFile::create(&root, 1024).unwrap(), 16).unwrap();
    let stable = registry.allocate().unwrap();
    let mut catalog = Catalog::open(&root).unwrap();
    let schema = catalog
        .create_table(
            "t".into(),
            vec![
                ColumnSchema {
                    name: "id".into(),
                    data_type: DataType::Int64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "v".into(),
                    data_type: DataType::Int64,
                    nullable: true,
                },
                ColumnSchema {
                    name: "g".into(),
                    data_type: DataType::Int64,
                    nullable: true,
                },
            ],
        )
        .unwrap();
    let big = catalog
        .create_table(
            "big".into(),
            vec![
                ColumnSchema {
                    name: "id".into(),
                    data_type: DataType::Int64,
                    nullable: false,
                },
                ColumnSchema {
                    name: "payload".into(),
                    data_type: DataType::Text,
                    nullable: false,
                },
            ],
        )
        .unwrap();
    drop(HeapTable::open_versioned(heap_path(&root, big.id), big, 2).unwrap());
    let unique = catalog
        .create_index("u".into(), schema.id, vec!["id".into()], true)
        .unwrap();
    let duplicate = catalog
        .create_index("d".into(), schema.id, vec!["g".into()], false)
        .unwrap();
    let composite = catalog
        .create_index("c".into(), schema.id, vec!["v".into(), "g".into()], true)
        .unwrap();
    let mut heap =
        HeapTable::open_versioned(heap_path(&root, schema.id), schema.clone(), 2).unwrap();
    heap.begin_private(&root.join("seed-heap"), stable, &root)
        .unwrap();
    let definitions = [unique, duplicate, composite];
    let mut indexes = definitions
        .iter()
        .map(|definition| {
            let mut tree = BPlusTree::open(
                index_path(&root, definition.id),
                definition.unique,
                definition.columns.len(),
            )
            .unwrap();
            tree.begin_private(
                &root.join(format!("seed-index-{}", definition.id)),
                stable,
                &root,
            )
            .unwrap();
            tree
        })
        .collect::<Vec<_>>();
    for id in 0..1000 {
        let row = Row::new(vec![Value::Int64(id), Value::Int64(id), Value::Null]);
        let rid = heap
            .insert_version(
                TupleVersion {
                    logical_row: id as u64 + 1,
                    visibility: Version {
                        creator: stable,
                        deleter: None,
                    },
                    previous: None,
                },
                &row,
            )
            .unwrap();
        for (definition, tree) in definitions.iter().zip(&mut indexes) {
            tree.insert(index_key_for_row(&schema, definition, &row).unwrap(), rid)
                .unwrap();
        }
    }
    wal.begin_mvcc(stable).unwrap();
    heap.prepare_private_redo(FileId::Heap(schema.id), |page, bytes, _| {
        wal.append_page(PageAction::Initialize, FileId::Heap(schema.id), page, bytes)?;
        Ok(())
    })
    .unwrap();
    for (definition, tree) in definitions.iter().zip(&mut indexes) {
        tree.prepare_private_redo(FileId::Index(definition.id), |page, bytes, _| {
            wal.append_page(PageAction::Index, FileId::Index(definition.id), page, bytes)?;
            Ok(())
        })
        .unwrap();
    }
    let receipt = wal.commit().unwrap();
    heap.install_private(&receipt).unwrap();
    for tree in &mut indexes {
        tree.install_private(&receipt).unwrap();
    }
    registry.commit(&receipt).unwrap();
    drop(heap);
    drop(indexes);
    drop(registry);
    drop(wal);
    root
}

fn values(result: QueryResult) -> Vec<Row> {
    let QueryResult::Rows { rows, .. } = result else {
        panic!("rows required")
    };
    rows
}

#[test]
fn sql_own_overlay_same_page_rebase_reverse_group_commit_and_repeat_recovery() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let a = db.connect(1).unwrap();
    let b = db.connect(2).unwrap();
    let reader = db.connect(3).unwrap();
    let mut aw = SessionWrites::new(a.begin().unwrap(), 1024 * 1024).unwrap();
    let mut bw = SessionWrites::new(b.begin().unwrap(), 1024 * 1024).unwrap();
    db.stage(&a, &mut aw, "UPDATE t SET v=v+1000 WHERE id=7", &[])
        .unwrap();
    db.stage(&b, &mut bw, "UPDATE t SET v=v+2000 WHERE id=8", &[])
        .unwrap();
    {
        let mut own = db.statement(&a, Some(&aw)).unwrap();
        assert_eq!(
            values(own.execute("SELECT v FROM t WHERE id=7", &[]).unwrap())[0].values,
            vec![Value::Int64(1007)]
        );
        assert_eq!(own.last_access_path(), Some("INDEX u"));
    }
    let mut old = db.statement(&reader, None).unwrap();
    assert_eq!(
        values(old.execute("SELECT v FROM t WHERE id=7", &[]).unwrap())[0].values,
        vec![Value::Int64(7)]
    );
    let forces = Arc::new(AtomicU64::new(0));
    let observed = forces.clone();
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |at| {
            if at == "wal.after_force" {
                observed.fetch_add(1, Ordering::Relaxed);
            }
        }),
    );
    for result in db.commit_group(vec![
        (b.submit_commit().unwrap(), bw),
        (a.submit_commit().unwrap(), aw),
    ]) {
        result.unwrap();
    }
    assert_eq!(forces.load(Ordering::Relaxed), 1);
    drop(hook);
    assert_eq!(
        values(old.execute("SELECT v FROM t WHERE id=8", &[]).unwrap())[0].values,
        vec![Value::Int64(8)]
    );
    drop(old);
    {
        let mut fresh = db.statement(&reader, None).unwrap();
        assert_eq!(
            values(
                fresh
                    .execute("SELECT v FROM t WHERE id>=7 AND id<=8 ORDER BY id", &[])
                    .unwrap()
            ),
            vec![
                Row::new(vec![Value::Int64(1007)]),
                Row::new(vec![Value::Int64(2008)])
            ]
        );
        assert_eq!(
            values(fresh.execute("SELECT COUNT(*) FROM t", &[]).unwrap())[0].values,
            vec![Value::Int64(1000)]
        );
    }
    drop(a);
    drop(b);
    drop(reader);
    drop(db);
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        let reader = db.connect(1).unwrap();
        let mut view = db.statement(&reader, None).unwrap();
        assert_eq!(
            values(view.execute("SELECT v FROM t WHERE id=7", &[]).unwrap())[0].values,
            vec![Value::Int64(1007)]
        );
    }
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn mvcc_oversized_successor_survives_wal_batch_split_and_repeat_recovery() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let mut requests = Vec::new();
    let mut sessions = Vec::new();
    for (id, count) in [(1, 1), (2, 180), (3, 1)] {
        let session = db.connect(id).unwrap();
        let stable = session.begin().unwrap();
        let mut writes = SessionWrites::new(stable, 4 * 1024 * 1024).unwrap();
        let payload = if count == 180 {
            "x".repeat(7000)
        } else {
            "prefix-or-suffix".into()
        };
        let rows = (0..count)
            .map(|row| format!("({},'{}')", id * 1000 + row, payload))
            .collect::<Vec<_>>()
            .join(",");
        db.stage(
            &session,
            &mut writes,
            &format!("INSERT INTO big VALUES {rows}"),
            &[],
        )
        .unwrap();
        requests.push((session.submit_commit().unwrap(), writes));
        sessions.push(session);
    }
    let forces = Arc::new(AtomicU64::new(0));
    let observed = forces.clone();
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |at| {
            if at == "wal.after_force" {
                observed.fetch_add(1, Ordering::Relaxed);
            }
        }),
    );
    for result in db.commit_group(requests) {
        result.unwrap();
    }
    assert_eq!(forces.load(Ordering::Relaxed), 3);
    drop(hook);
    drop(sessions);
    drop(db);
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        let reader = db.connect(1).unwrap();
        let mut view = db.statement(&reader, None).unwrap();
        assert_eq!(
            values(view.execute("SELECT COUNT(*) FROM big", &[]).unwrap())[0].values,
            vec![Value::Int64(182)]
        );
        assert_eq!(
            values(
                view.execute(
                    "SELECT id FROM big WHERE id=1000 OR id=3000 ORDER BY id",
                    &[]
                )
                .unwrap()
            ),
            vec![
                Row::new(vec![Value::Int64(1000)]),
                Row::new(vec![Value::Int64(3000)])
            ]
        );
    }
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn unique_recheck_crosses_retained_version_batches_without_losing_snapshot() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let reader = db.connect(900).unwrap();
    let mut old = db.statement(&reader, None).unwrap();
    let schema = old.database.catalog.table("t").unwrap().clone();
    let Statement::Update { filter, .. } = parse("UPDATE t SET v=v+1 WHERE id=7").unwrap() else {
        panic!("update")
    };
    // Seed the old reader's page cache before later index entries refer to
    // additional slots and eventually pages outside its scan traversal bound.
    let initial = old
        .database
        .mvcc_dml_snapshot(&schema, filter.as_ref(), &[], 4096)
        .unwrap();
    for _ in 0..130 {
        db.execute(1, "UPDATE t SET v=v+1 WHERE id=7").unwrap();
        assert_eq!(
            old.database
                .mvcc_dml_snapshot(&schema, filter.as_ref(), &[], 4096)
                .unwrap(),
            initial
        );
    }
    assert_eq!(
        values(old.execute("SELECT v FROM t WHERE id=7", &[]).unwrap())[0].values,
        vec![Value::Int64(7)]
    );
    assert!(db.execute(2, "INSERT INTO t VALUES (7,999,NULL)").is_err());
    drop(old);
    let mut fresh = db.statement(&reader, None).unwrap();
    let rows = values(fresh.execute("SELECT v FROM t WHERE id=7", &[]).unwrap());
    assert_eq!(rows, vec![Row::new(vec![Value::Int64(137)])]);
    drop(fresh);
    drop(reader);
    db.disconnect(1);
    db.disconnect(2);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn sql_schema_transaction_commit_rollback_analyze_and_reopen() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "CREATE TABLE names (id BIGINT NOT NULL, label TEXT)")
        .unwrap();
    db.execute(1, "INSERT INTO names VALUES (1,'one'),(2,'two')")
        .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX names_id ON names(id)")
        .unwrap();
    db.execute(1, "ANALYZE names").unwrap();
    assert_eq!(
        values(db.execute(1, "SELECT COUNT(*) FROM names").unwrap())[0].values,
        vec![Value::Int64(2)]
    );
    assert!(db.execute(2, "SELECT * FROM names").is_err());
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(
        values(db.execute(2, "SELECT label FROM names WHERE id=2").unwrap())[0].values,
        vec![Value::Text("two".into())]
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "DROP INDEX names_id").unwrap();
    db.execute(1, "INSERT INTO names VALUES (2,'duplicate')")
        .unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    assert!(
        db.execute(1, "INSERT INTO names VALUES (2,'duplicate')")
            .is_err()
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "CREATE TABLE aborted (id BIGINT)").unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    assert!(db.execute(1, "SELECT * FROM aborted").is_err());
    db.execute(1, "DROP INDEX names_id").unwrap();
    db.execute(1, "CREATE INDEX names_label ON names(label)")
        .unwrap();
    db.disconnect(1);
    db.disconnect(2);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        assert_eq!(
            values(
                db.execute(1, "SELECT label FROM names WHERE label='one'")
                    .unwrap()
            )[0]
            .values,
            vec![Value::Text("one".into())]
        );
        db.disconnect(1);
        db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn bounded_resolution_rejects_before_session_changes_and_housekeeping_is_scoped() {
    let root = fixture();
    let scratch = root.join(".phobos-mvcc-private-999");
    fs::create_dir(&scratch).unwrap();
    fs::write(scratch.join("partial"), b"abandoned").unwrap();
    let retired = root.join(".phobos-retired-private-998");
    fs::create_dir(&retired).unwrap();
    fs::write(retired.join("committed"), b"disposable").unwrap();
    let unrelated = root.join("user-notes");
    fs::create_dir(&unrelated).unwrap();
    fs::write(unrelated.join("keep"), b"keep").unwrap();
    let db = MvccDatabase::open(&root).unwrap();
    assert!(!scratch.exists());
    assert!(!retired.exists());
    assert!(unrelated.join("keep").exists());
    let session = db.connect(77).unwrap();
    let mut writes = SessionWrites::new(session.begin().unwrap(), 512).unwrap();
    let error = db
        .stage(&session, &mut writes, "UPDATE t SET v=v+1", &[])
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ResourceLimit);
    assert_eq!(writes.changes().unwrap().count(), 0);
    drop(writes);
    session.rollback().unwrap();
    let mut writes = SessionWrites::new(session.begin().unwrap(), 512).unwrap();
    let error = db
        .stage(
            &session,
            &mut writes,
            "INSERT INTO t VALUES (2000,1,NULL),(2001,1,NULL),(2002,1,NULL),(2003,1,NULL)",
            &[],
        )
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ResourceLimit);
    assert_eq!(writes.changes().unwrap().count(), 0);
    drop(writes);
    session.rollback().unwrap();
    drop(session);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c1_statement_views_include_only_ast_relations_and_indexes() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    for n in 0..5 {
        db.execute(
            980,
            &format!("CREATE TABLE pad{n} (id BIGINT NOT NULL, v TEXT)"),
        )
        .unwrap();
        db.execute(980, &format!("CREATE UNIQUE INDEX pad{n}_id ON pad{n}(id)"))
            .unwrap();
    }
    let session = db.connect(981).unwrap();
    let inspect = |sql: &str| {
        let statement = parse(sql).unwrap_or_else(|error| panic!("{sql}: {error}"));
        let view = db
            .statement_for_at(&session, None, None, &statement)
            .unwrap();
        (
            view.database.heaps.keys().copied().collect::<Vec<_>>(),
            view.database.indexes.keys().copied().collect::<Vec<_>>(),
        )
    };

    let catalog = db.readers.read().unwrap().catalog.clone();
    let t = catalog.table("t").unwrap().id;
    let big = catalog.table("big").unwrap().id;
    let mut t_indexes = catalog
        .indexes_for_table(t)
        .map(|index| index.id)
        .collect::<Vec<_>>();
    t_indexes.sort_unstable();
    assert_eq!(
        inspect("SELECT v FROM t WHERE id=7"),
        (vec![t], t_indexes.clone())
    );

    let (heaps, indexes) = inspect(
        "SELECT t.id, big.id FROM t LEFT JOIN big ON t.id=big.id WHERE t.id IN (SELECT id FROM big)",
    );
    assert_eq!(heaps, vec![t, big]);
    assert_eq!(indexes, t_indexes);

    assert_eq!(
        inspect("EXPLAIN ANALYZE SELECT g, COUNT(*) AS n FROM t GROUP BY g HAVING n>0"),
        (vec![t], t_indexes.clone())
    );
    assert_eq!(
        inspect("UPDATE t SET v=v+1 WHERE id IN (SELECT id FROM big)"),
        (vec![t, big], t_indexes.clone())
    );

    let (all_heaps, all_indexes) = inspect("SELECT * FROM phobos_metrics");
    assert_eq!(all_heaps.len(), 7);
    assert_eq!(all_indexes.len(), 8);
    let missing = parse("SELECT * FROM missing_relation").unwrap();
    let error = db
        .statement_for_at(&session, None, None, &missing)
        .err()
        .expect("missing relation must fail");
    assert_eq!(error.code, ErrorCode::NotFound);

    drop(session);
    db.disconnect(980);
    db.disconnect(981);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn c1_partition_view_includes_parent_and_children_without_unrelated_schema() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(
        990,
        "CREATE TABLE events (id BIGINT NOT NULL, label TEXT) PARTITION BY RANGE (id)",
    )
    .unwrap();
    db.execute(
        990,
        "CREATE TABLE events_low PARTITION OF events FOR VALUES FROM (0) TO (100)",
    )
    .unwrap();
    db.execute(
        990,
        "CREATE TABLE events_high PARTITION OF events FOR VALUES FROM (100) TO (200)",
    )
    .unwrap();
    db.execute(990, "CREATE TABLE unrelated (id BIGINT NOT NULL)")
        .unwrap();
    let session = db.connect(991).unwrap();
    let statement = parse("SELECT id FROM events WHERE id>=100").unwrap();
    let view = db
        .statement_for_at(&session, None, None, &statement)
        .unwrap();
    let names = view
        .database
        .heaps
        .keys()
        .map(|id| {
            view.database
                .catalog
                .tables()
                .find(|table| table.id == *id)
                .unwrap()
                .name
                .clone()
        })
        .collect::<BTreeSet<_>>();
    assert_eq!(
        names,
        BTreeSet::from([
            "events".to_string(),
            "events_low".to_string(),
            "events_high".to_string(),
        ])
    );
    drop(view);
    assert_eq!(
        values(
            db.execute(992, "SELECT id FROM events WHERE id>=100")
                .unwrap()
        )
        .len(),
        0
    );
    drop(session);
    db.disconnect(990);
    db.disconnect(991);
    db.disconnect(992);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
