//! Session-owned schema changes use the existing mapped WAL and page publisher.
use super::*;
use phobos_txn::mvcc::sessions::SchemaLease;
use phobos_wal::v2::{Body, FileId};

pub(super) struct Schema {
    pub root: PathBuf,
    pub catalog: Catalog,
    pub stats: BTreeMap<TableId, TableStatistics>,
    _lease: SchemaLease,
}
impl Schema {
    /// 0.2-K.4: a schema owner built outside `stage_schema` (capability
    /// enabling); same lease and directory lifecycle.
    pub(super) fn new(
        root: PathBuf,
        catalog: Catalog,
        stats: BTreeMap<TableId, TableStatistics>,
        lease: SchemaLease,
    ) -> Self {
        Self {
            root,
            catalog,
            stats,
            _lease: lease,
        }
    }
}
impl Drop for Schema {
    fn drop(&mut self) {
        // All statement readers are dropped before the last schema owner.
        let _ = fs::remove_dir_all(&self.root);
    }
}
impl MvccDatabase {
    /// Explicit offline-copy upgrade. Metadata is published through ordinary schema WAL.
    pub fn upgrade_catalog_format(&self, session: &Session) -> Result<(), PhobosError> {
        session.begin_deferred()?;
        let result = (|| {
            let stable = session.ensure_transaction_id()?;
            let lease = self.sessions.acquire_schema(stable)?;
            let (root, mut catalog, stats) = {
                let database = self.lock_database()?;
                let root = database
                    .data_dir
                    .join(format!(".phobos-mvcc-schema-{stable}"));
                fs::create_dir(&root)?;
                for file in [FileId::Tables, FileId::Indexes] {
                    fs::copy(database.data_dir.join(file.name()), root.join(file.name()))?;
                }
                persist_statistics(&root, &database.stats)?;
                (root, database.catalog.clone(), database.stats.clone())
            };
            catalog.redirect_persistence(&root)?;
            let mut schema = Schema::new(root, catalog, stats, lease);
            schema.catalog.upgrade_format_staged()?;
            let mut writes = SessionWrites::new(stable, DEFAULT_QUERY_MEMORY_BYTES)?;
            writes.schema = Some(Arc::new(schema));
            self.commit(session, writes)
        })();
        if result.is_err() {
            let _ = session.rollback();
        }
        result
    }
}
impl MvccDatabase {
    pub(super) fn stage_schema(
        &self,
        session: &Session,
        writes: &mut SessionWrites,
        statement: Statement,
    ) -> Result<QueryResult, PhobosError> {
        if writes.schema.is_none() {
            let lease = self.sessions.acquire_schema(writes.stable_id())?;
            let database = self.lock_database()?;
            let root = database
                .data_dir
                .join(format!(".phobos-mvcc-schema-{}", writes.stable_id()));
            fs::create_dir(&root)?;
            for file in [FileId::Tables, FileId::Indexes] {
                fs::copy(database.data_dir.join(file.name()), root.join(file.name()))?;
            }
            persist_statistics(&root, &database.stats)?;
            let mut catalog = database.catalog.clone();
            catalog.redirect_persistence(&root)?;
            writes.schema = Some(Arc::new(Schema {
                root,
                catalog,
                stats: database.stats.clone(),
                _lease: lease,
            }));
        }
        let mut view = self.statement_for_at(session, Some(writes), None, &statement)?;
        let root = writes.schema.as_ref().expect("schema owner").root.clone();
        let result = match statement {
            Statement::CreateView { name, query, sql } => {
                let mut shape = view.database.query_shape(&query, &[])?;
                if let Statement::RelationalSelect(q) = query.as_ref() {
                    if q.items.len() == shape.len() {
                        for ((name, _), item) in shape.iter_mut().zip(&q.items) {
                            if let SelectItem::Column {
                                name: column,
                                alias: None,
                            } = item
                            {
                                *name = column.rsplit('.').next().unwrap_or(column).to_owned();
                            }
                        }
                    }
                }
                let mut dependencies = BTreeSet::new();
                if !collect_statement_tables(&query, &view.database.catalog, &mut dependencies)? {
                    return Err(PhobosError::new(
                        ErrorCode::Unsupported,
                        "view dependency cannot be bound",
                    ));
                }
                view.database.execute_subquery(*query, &[])?;
                let columns = shape
                    .into_iter()
                    .map(|(name, t)| ColumnSchema {
                        name,
                        data_type: t.unwrap_or(DataType::Text),
                        nullable: true,
                    })
                    .collect();
                Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema")
                    .catalog
                    .create_view_staged(name, sql, columns, dependencies.into_iter().collect())?;
                command("CREATE VIEW", 0)
            }
            Statement::DropView { name } => {
                Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema")
                    .catalog
                    .drop_view_staged(&name)?;
                command("DROP VIEW", 0)
            }

            Statement::AlterNullable {
                table,
                column,
                nullable,
            } => {
                let old = view.database.table_schema(&table)?;
                if view.database.catalog.partition_key(&table).is_some()
                    || view.database.catalog.partition(&table).is_some()
                {
                    return Err(PhobosError::new(
                        ErrorCode::Unsupported,
                        "ALTER partition column unsupported",
                    ));
                }
                let ordinal = old
                    .column_index(&column)
                    .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "column missing"))?;
                if !nullable
                    && view
                        .database
                        .mvcc_dml_snapshot(&old, None, &[], DEFAULT_QUERY_MEMORY_BYTES)?
                        .iter()
                        .any(|(_, r)| r.values[ordinal].is_null())
                {
                    return Err(PhobosError::new(
                        ErrorCode::ConstraintViolation,
                        "existing NULL prevents SET NOT NULL",
                    ));
                }
                let owner = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let id = owner
                    .catalog
                    .alter_nullable_staged(&table, &column, nullable)?;
                owner.stats.remove(&id);
                persist_statistics(&root, &owner.stats)?;
                command("ALTER TABLE", 0)
            }
            Statement::AddColumn {
                table,
                column,
                default,
            } => {
                let old = view.database.table_schema(&table)?;
                if view.database.catalog.partition_key(&table).is_some()
                    || view.database.catalog.partition(&table).is_some()
                {
                    return Err(PhobosError::new(
                        ErrorCode::Unsupported,
                        "ALTER partition column unsupported",
                    ));
                }
                let mut physical = false;
                view.database.heap_mut(old.id)?.scan_versions(|_, _, _| {
                    physical = true;
                    Ok(false)
                })?;
                if physical
                    || !view
                        .database
                        .mvcc_dml_snapshot(&old, None, &[], DEFAULT_QUERY_MEMORY_BYTES)?
                        .is_empty()
                {
                    return Err(PhobosError::new(
                        ErrorCode::Unsupported,
                        "ADD COLUMN currently requires a physically empty table; populated-table rewrite is deferred",
                    ));
                }
                let default = default
                    .map(|e| coerce_value(&column, schema_literal(&e)?))
                    .transpose()?;
                let owner = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let id = owner.catalog.add_column_staged(&table, column, default)?;
                owner.stats.remove(&id);
                persist_statistics(&root, &owner.stats)?;
                command("ALTER TABLE", 0)
            }
            Statement::AlterDefault {
                table,
                column,
                value,
            } => {
                let owner = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let table = owner
                    .catalog
                    .table(&table)
                    .cloned()
                    .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "table missing"))?;
                let ordinal = table
                    .column_index(&column)
                    .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "column missing"))?;
                let mut definition = owner
                    .catalog
                    .definitions(table.id)
                    .cloned()
                    .unwrap_or_default();
                if let Some(expr) = value {
                    definition.defaults.insert(
                        ordinal,
                        coerce_value(&table.columns[ordinal], schema_literal(&expr)?)?,
                    );
                } else {
                    definition.defaults.remove(&ordinal);
                }
                owner.catalog.set_definitions(table.id, definition)?;
                command("ALTER TABLE", 0)
            }
            Statement::CreateDefinedTable {
                name,
                mut columns,
                defaults,
                checks,
                primary_key,
                identity,
                foreign_keys,
            } => {
                let mut seen = std::collections::BTreeSet::new();
                for key in &primary_key {
                    if !seen.insert(key.to_ascii_lowercase()) {
                        return Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "duplicate primary key column",
                        ));
                    }
                    let column = columns
                        .iter_mut()
                        .find(|c| c.name.eq_ignore_ascii_case(key))
                        .ok_or_else(|| {
                            PhobosError::new(ErrorCode::NotFound, "primary key column missing")
                        })?;
                    column.nullable = false;
                }
                let binding = TableSchema {
                    id: 0,
                    name: name.clone(),
                    columns: columns.clone(),
                };
                let mut definition = phobos_catalog::SchemaDefinitions::default();
                for (name, expr) in defaults {
                    let ordinal = binding.column_index(&name).ok_or_else(|| {
                        PhobosError::new(ErrorCode::NotFound, "default column missing")
                    })?;
                    definition.defaults.insert(
                        ordinal,
                        coerce_value(&columns[ordinal], schema_literal(&expr)?)?,
                    );
                }
                for expr in checks {
                    definition.checks.push(bind_check(&binding, expr)?);
                }
                let owner = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                if let Some((name, _)) = &identity {
                    let ordinal = binding.column_index(name).ok_or_else(|| {
                        PhobosError::new(ErrorCode::NotFound, "identity column missing")
                    })?;
                    columns[ordinal].nullable = false;
                }
                let table = owner.catalog.create_table(name, columns)?;
                if let Some((name, always)) = identity {
                    let ordinal = table.column_index(&name).expect("bound identity");
                    let sequence = owner.catalog.create_table(
                        format!("__phobos_sequence_{}", table.id),
                        vec![
                            ColumnSchema {
                                name: "singleton".into(),
                                data_type: DataType::Int64,
                                nullable: false,
                            },
                            ColumnSchema {
                                name: "next_value".into(),
                                data_type: DataType::Int64,
                                nullable: false,
                            },
                        ],
                    )?;
                    owner.catalog.create_index(
                        format!("__phobos_sequence_index_{}", table.id),
                        sequence.id,
                        vec!["singleton".into()],
                        true,
                    )?;
                    definition.identity = Some(phobos_catalog::IdentityDefinition {
                        column: ordinal,
                        sequence_table: sequence.id,
                        always,
                    });
                    drop(HeapTable::open_versioned(
                        heap_path(&root, sequence.id),
                        sequence,
                        1,
                    )?);
                }
                if !primary_key.is_empty() {
                    let key_columns = primary_key
                        .iter()
                        .map(|k| {
                            table.columns[table.column_index(k).expect("bound key")]
                                .name
                                .clone()
                        })
                        .collect();
                    // Fresh table: no equivalent index can exist. Stable ID prevents rename collisions.
                    let index = owner.catalog.create_index(
                        format!("phobos_pk_{}", table.id),
                        table.id,
                        key_columns,
                        true,
                    )?;
                    definition.primary_index = Some(index.id);
                }
                for (child, parent, referenced) in foreign_keys {
                    let parent = owner.catalog.table(&parent).ok_or_else(|| {
                        PhobosError::new(ErrorCode::NotFound, "FK parent missing")
                    })?;
                    let columns = child
                        .iter()
                        .map(|n| {
                            table.column_index(n).ok_or_else(|| {
                                PhobosError::new(ErrorCode::NotFound, "FK child column missing")
                            })
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let parent_columns = referenced
                        .iter()
                        .map(|n| {
                            parent.column_index(n).ok_or_else(|| {
                                PhobosError::new(ErrorCode::NotFound, "FK parent column missing")
                            })
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let parent_index = owner
                        .catalog
                        .indexes_for_table(parent.id)
                        .find(|i| {
                            i.unique
                                && i.columns
                                    .iter()
                                    .map(|n| parent.column_index(n))
                                    .collect::<Option<Vec<_>>>()
                                    .as_ref()
                                    == Some(&parent_columns)
                        })
                        .ok_or_else(|| {
                            PhobosError::new(
                                ErrorCode::ConstraintViolation,
                                "FK requires matching UNIQUE or PRIMARY KEY",
                            )
                        })?
                        .id;
                    definition
                        .foreign_keys
                        .push(phobos_catalog::ForeignKeyDefinition {
                            columns,
                            parent_table: parent.id,
                            parent_columns,
                            parent_index,
                        });
                }
                owner.catalog.set_definitions(table.id, definition)?;
                drop(HeapTable::open_versioned(
                    heap_path(&root, table.id),
                    table,
                    1,
                )?);
                command("CREATE TABLE", 0)
            }
            Statement::RenameTable {
                table,
                column,
                new_name,
            } => {
                let schema = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let id = schema
                    .catalog
                    .rename_staged(&table, column.as_deref(), &new_name)?;
                schema.stats.remove(&id);
                persist_statistics(&root, &schema.stats)?;
                command("ALTER TABLE", 0)
            }
            Statement::CreateTable { name, columns } => {
                if columns.is_empty()
                    || columns.iter().enumerate().any(|(i, c)| {
                        columns[..i]
                            .iter()
                            .any(|old| old.name.eq_ignore_ascii_case(&c.name))
                    })
                {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "invalid or duplicate table columns",
                    ));
                }
                let schema = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let table = schema.catalog.create_table(name, columns)?;
                drop(HeapTable::open_versioned(
                    heap_path(&root, table.id),
                    table,
                    1,
                )?);
                command("CREATE TABLE", 0)
            }
            Statement::CreatePartitionedTable { name, columns, key } => {
                if columns.is_empty()
                    || columns.iter().enumerate().any(|(i, c)| {
                        columns[..i]
                            .iter()
                            .any(|old| old.name.eq_ignore_ascii_case(&c.name))
                    })
                {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "invalid or duplicate table columns",
                    ));
                }
                let schema = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let table = schema.catalog.create_table(name.clone(), columns)?;
                schema.catalog.mark_partitioned(&name, &key)?;
                drop(HeapTable::open_versioned(
                    heap_path(&root, table.id),
                    table,
                    1,
                )?);
                command("CREATE TABLE", 0)
            }
            Statement::CreateRangePartition {
                name,
                parent,
                lower,
                upper,
            } => {
                let bound = |expr: Expr| -> Result<Value, PhobosError> {
                    match expr {
                        Expr::Literal(value) if !value.is_null() => Ok(value),
                        Expr::Unary {
                            op: UnaryOp::Negate,
                            expr,
                        } => match *expr {
                            Expr::Literal(Value::Int64(value)) => {
                                Ok(Value::Int64(value.checked_neg().ok_or_else(|| {
                                    PhobosError::new(
                                        ErrorCode::Semantic,
                                        "partition bound overflow",
                                    )
                                })?))
                            }
                            Expr::Literal(Value::Float64(value)) => Ok(Value::Float64(-value)),
                            _ => Err(PhobosError::new(
                                ErrorCode::Semantic,
                                "partition bounds must be constants",
                            )),
                        },
                        _ => Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "partition bounds must be non-NULL constants",
                        )),
                    }
                };
                let lower = bound(lower)?;
                let upper = bound(upper)?;
                let schema = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let parent_schema = schema.catalog.table(&parent).cloned().ok_or_else(|| {
                    PhobosError::new(ErrorCode::NotFound, "partition parent does not exist")
                })?;
                let key = schema
                    .catalog
                    .partition_key(&parent)
                    .ok_or_else(|| {
                        PhobosError::new(ErrorCode::Semantic, "table is not partitioned")
                    })?
                    .to_string();
                let column = parent_schema.column_index(&key).expect("catalog key");
                if lower.key_class() != Some(parent_schema.columns[column].data_type.key_class())
                    || upper.key_class() != lower.key_class()
                {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "partition bound type does not match key",
                    ));
                }
                let child = schema
                    .catalog
                    .create_table(name.clone(), parent_schema.columns.clone())?;
                schema.catalog.add_range_partition(RangePartition {
                    parent,
                    child: name,
                    key_column: key,
                    lower,
                    upper,
                })?;
                drop(HeapTable::open_versioned(
                    heap_path(&root, child.id),
                    child,
                    1,
                )?);
                command("CREATE TABLE", 0)
            }
            Statement::CreateIndex {
                name,
                table,
                columns,
                unique,
            } => {
                let table = view.database.table_schema(&table)?;
                let schema = Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema");
                let definition = schema
                    .catalog
                    .create_index(name, table.id, columns, unique)?;
                // 0.2-K.4: the first non-unique index enables
                // LAZY_INDEX_PRUNING_V1 in the same DDL publication, so the
                // background worker never needs a schema transaction of its own.
                if !unique
                    && self.lazy_allowed.load(std::sync::atomic::Ordering::Acquire)
                    && !schema.catalog.lazy_index_pruning()
                {
                    schema
                        .catalog
                        .enable_capabilities(phobos_catalog::CAPABILITY_LAZY_INDEX_PRUNING_V1)?;
                }
                let path = index_path(&root, definition.id);
                let mut validation = BPlusTree::open(&path, unique, definition.columns.len())?;
                view.database.heap_mut(table.id)?.scan_visit(|rid, row| {
                    validation.insert(index_key_for_row(&table, &definition, &row)?, rid)?;
                    Ok(true)
                })?;
                drop(validation);
                // This tree only validates the statement. Publication builds all
                // retained physical versions after rebasing the transaction.
                fs::remove_file(path)?;
                command("CREATE INDEX", 0)
            }
            Statement::DropIndex { name } => {
                Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema")
                    .catalog
                    .drop_index(&name)?;
                command("DROP INDEX", 0)
            }
            Statement::Analyze { table } => {
                view.database.data_dir = root.clone();
                let result = view.database.analyze_table(&table)?;
                Arc::get_mut(writes.schema.as_mut().expect("schema"))
                    .expect("exclusive schema")
                    .stats = view.database.stats.clone();
                result
            }
            _ => return Err(write_conflict("not a schema statement")),
        };
        Ok(result)
    }
}
fn command(tag: &str, rows_affected: u64) -> QueryResult {
    QueryResult::Command {
        tag: tag.into(),
        rows_affected,
    }
}

pub(super) fn log_metadata(
    wal: &Mutex<phobos_wal::v2::Wal>,
    schema: &Schema,
) -> Result<(), PhobosError> {
    for file in [FileId::Tables, FileId::Indexes, FileId::Statistics] {
        let mut input = File::open(schema.root.join(file.name()))?;
        let total_len = input.metadata()?.len();
        let mut offset = 0;
        loop {
            let mut bytes = vec![0; (total_len - offset).min(32768) as usize];
            input.read_exact(&mut bytes)?;
            let count = bytes.len() as u64;
            super::publication::writer(wal)?.append(Body::Metadata {
                file,
                offset,
                total_len,
                bytes,
            })?;
            offset += count;
            if offset == total_len {
                break;
            }
        }
    }
    Ok(())
}
pub(super) fn install_metadata(
    database: &mut Database,
    schema: &Schema,
) -> Result<(), PhobosError> {
    for file in [FileId::Tables, FileId::Indexes, FileId::Statistics] {
        let path = database.data_dir.join(file.name());
        fs::copy(schema.root.join(file.name()), &path)?;
        OpenOptions::new().write(true).open(path)?.sync_all()?;
    }
    #[cfg(unix)]
    File::open(&database.data_dir)?.sync_all()?;
    phobos_observability::synchronization_boundary(
        "c5_schema_metadata_installed",
        &database.data_dir,
    );
    database.catalog = schema.catalog.clone();
    database.catalog.redirect_persistence(&database.data_dir)?;
    database.stats = schema.stats.clone();
    Ok(())
}

fn schema_literal(expr: &Expr) -> Result<Value, PhobosError> {
    match expr {
        Expr::Literal(value) => Ok(value.clone()),
        Expr::Unary {
            op: UnaryOp::Negate,
            expr,
        } => match schema_literal(expr)? {
            Value::Int64(n) => n
                .checked_neg()
                .map(Value::Int64)
                .ok_or_else(|| PhobosError::new(ErrorCode::Semantic, "literal overflow")),
            Value::Float64(n) => Ok(Value::Float64(-n)),
            _ => Err(PhobosError::new(
                ErrorCode::Unsupported,
                "schema literal negation requires a number",
            )),
        },
        _ => Err(PhobosError::new(
            ErrorCode::Unsupported,
            "schema expressions currently require a literal",
        )),
    }
}
fn bind_check(
    table: &TableSchema,
    expr: Expr,
) -> Result<phobos_catalog::CheckDefinition, PhobosError> {
    let unsupported = || {
        PhobosError::new(
            ErrorCode::Unsupported,
            "CHECK supports column comparison literal, or column IS [NOT] NULL",
        )
    };
    let (column, operator, value) = match expr {
        Expr::Binary { left, op, right } => {
            let operator = match op {
                BinaryOp::Eq => 0,
                BinaryOp::NotEq => 1,
                BinaryOp::Lt => 2,
                BinaryOp::LtEq => 3,
                BinaryOp::Gt => 4,
                BinaryOp::GtEq => 5,
                _ => return Err(unsupported()),
            };
            (left, operator, schema_literal(&right)?)
        }
        Expr::IsNull { expr, negated } => (expr, if negated { 7 } else { 6 }, Value::Null),
        _ => return Err(unsupported()),
    };
    let name = match *column {
        Expr::Column(name) | Expr::QuotedColumn(name) => name,
        _ => return Err(unsupported()),
    };
    let ordinal = table
        .column_index(&name)
        .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "CHECK column missing"))?;
    let mut column = table.columns[ordinal].clone();
    column.nullable = true;
    // Preserve exact mixed BIGINT/DOUBLE comparison semantics: coercing a large
    // integer to DOUBLE here would round the constraint boundary.
    let value = if value.key_class() == Some(column.data_type.key_class()) {
        value
    } else {
        coerce_value(&column, value)?
    };
    Ok(phobos_catalog::CheckDefinition {
        column: ordinal,
        operator,
        value,
    })
}
