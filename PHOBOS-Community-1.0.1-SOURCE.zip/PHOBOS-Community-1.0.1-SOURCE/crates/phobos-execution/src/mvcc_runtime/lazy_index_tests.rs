//! 0.2-K.4 Lazy Index Pruning V1: adversarial read-path, UNIQUE, integrity,
//! restart and sweeper tests. Fixture: table `t(id, v, g)` with UNIQUE `u(id)`,
//! non-unique `d(g)` and UNIQUE `c(v, g)`; ids 0..1000, v = id, g NULL. Each
//! test first sets g = id % 10 (eager, before the capability is enabled).
use super::tests::fixture;
use super::*;

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(value) => value,
            ref other => panic!("{other:?}"),
        },
        other => panic!("{other:?}"),
    }
}
fn ids(db: &MvccDatabase, session: u64, sql: &str) -> Vec<i64> {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => {
            let mut out = rows
                .iter()
                .map(|row| match row.values[0] {
                    Value::Int64(value) => value,
                    ref other => panic!("{other:?}"),
                })
                .collect::<Vec<_>>();
            out.sort_unstable();
            out
        }
        other => panic!("{other:?}"),
    }
}
fn entries(db: &MvccDatabase, name: &str) -> usize {
    let mut database = db.lock_database().unwrap();
    let id = database.catalog.index(name).unwrap().id;
    database
        .indexes
        .get_mut(&id)
        .unwrap()
        .all_entries()
        .unwrap()
        .len()
}
fn marker(db: &MvccDatabase) {
    db.execute(9, "INSERT INTO t VALUES (999999, 999999, 999999)")
        .unwrap();
    db.execute(9, "DELETE FROM t WHERE id=999999").unwrap();
}
/// Reclaim until nothing is left to retire or free (sweeper per switch).
fn drain(db: &MvccDatabase) {
    for _ in 0..200 {
        let report = db.reclaim_once(1024).unwrap();
        if report.versions_reclaimed == 0 && report.slots_freed == 0 {
            marker(db);
            let again = db.reclaim_once(1024).unwrap();
            if again.versions_reclaimed == 0 && again.slots_freed == 0 && !db.sweep_pending() {
                return;
            }
        }
    }
}
fn expected_g(db: &MvccDatabase, session: u64, g: i64) -> Vec<i64> {
    // Authoritative answer from a full scan (no index).
    let all = match db
        .execute(session, "SELECT id AS id, g AS g FROM t")
        .unwrap()
    {
        QueryResult::Rows { rows, .. } => rows,
        other => panic!("{other:?}"),
    };
    let mut out = all
        .iter()
        .filter(|row| row.values[1] == Value::Int64(g))
        .map(|row| match row.values[0] {
            Value::Int64(value) => value,
            ref other => panic!("{other:?}"),
        })
        .collect::<Vec<_>>();
    out.sort_unstable();
    out
}

fn setup_g(db: &MvccDatabase) {
    db.set_lazy_index_pruning(false);
    db.execute(1, "UPDATE t SET g=id-(id/10)*10").unwrap();
    drain(db);
    db.set_lazy_index_pruning(true);
}

#[test]
fn k4_lazy_stale_entries_are_harmless_survive_restart_and_are_swept() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup_g(&db);
    assert!(db.try_enable_lazy_index_pruning().unwrap());
    db.set_lazy_index_sweep(false);
    // Changes the non-unique key of 100 rows and deletes 100 rows.
    db.execute(1, "UPDATE t SET g=g+100 WHERE id<100").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=900").unwrap();
    drain(&db);
    let metrics = db.reclaim_metrics();
    assert!(metrics.lazy_stale_created >= 200, "{metrics:?}");
    // Stale entries remain physically present in `d` (RETIRED/FREE slots);
    // the UNIQUE indexes were pruned exactly.
    assert!(entries(&db, "d") > 900, "{}", entries(&db, "d"));
    assert_eq!(entries(&db, "u"), 900);
    assert_eq!(entries(&db, "c"), 900);
    let check = db.check_online().unwrap();
    assert!(check.index_stale_entries >= 200, "{check:?}");
    // Reads through the stale entries: no stale row, no duplicate, correct rows.
    for g in [0, 5, 100, 105, 9] {
        let via_index = ids(&db, 2, &format!("SELECT id AS id FROM t WHERE g={g}"));
        assert_eq!(via_index, expected_g(&db, 2, g), "g={g}");
    }
    assert_eq!(
        ids(&db, 2, "SELECT id AS id FROM t WHERE g>=0 AND g<1000").len(),
        900
    );
    // Reuse FREE slots: same key (g=3) and different keys (g=7777).
    let same = (2000..2100)
        .map(|id| format!("({id},{},3)", id + 1))
        .collect::<Vec<_>>();
    db.execute(1, &format!("INSERT INTO t VALUES {}", same.join(",")))
        .unwrap();
    let other = (3000..3100)
        .map(|id| format!("({id},{},7777)", id + 1))
        .collect::<Vec<_>>();
    db.execute(1, &format!("INSERT INTO t VALUES {}", other.join(",")))
        .unwrap();
    for g in [3, 7777, 0, 100, 109] {
        let via_index = ids(&db, 2, &format!("SELECT id AS id FROM t WHERE g={g}"));
        assert_eq!(via_index, expected_g(&db, 2, g), "after reuse g={g}");
    }
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE g=3") as usize,
        expected_g(&db, 2, 3).len()
    );
    db.check_online().unwrap();
    // Restart with stale entries present.
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert!(db.lazy_index_enabled().unwrap());
    let check = db.check_online().unwrap();
    assert!(check.index_stale_entries > 0, "{check:?}");
    for g in [3, 7777, 100] {
        assert_eq!(
            ids(&db, 2, &format!("SELECT id AS id FROM t WHERE g={g}")),
            expected_g(&db, 2, g)
        );
    }
    // The sweeper removes every stale entry; nothing live is lost.
    db.set_lazy_index_sweep(true);
    db.note_lazy_stale(1 << 40); // force a full sweep cycle
    for _ in 0..50 {
        db.reclaim_once(1024).unwrap();
        if !db.sweep_pending() {
            break;
        }
    }
    let check = db.check_online().unwrap();
    assert_eq!(check.index_stale_entries, 0, "{check:?}");
    assert_eq!(
        entries(&db, "d"),
        1100,
        "exactly the live rows remain indexed"
    );
    for g in [3, 7777, 100] {
        assert_eq!(
            ids(&db, 2, &format!("SELECT id AS id FROM t WHERE g={g}")),
            expected_g(&db, 2, g)
        );
    }
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn k4_unique_semantics_unaffected_by_lazy_secondary_entries() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup_g(&db);
    assert!(db.try_enable_lazy_index_pruning().unwrap());
    db.set_lazy_index_sweep(false);
    db.execute(1, "UPDATE t SET g=g+50 WHERE id<200").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=800").unwrap();
    drain(&db);
    assert!(entries(&db, "d") > 800);
    // Same-key INSERT on a live UNIQUE key fails; no false conflict for a
    // deleted key whose slot (and stale secondary entry) may be reused.
    assert!(
        db.execute(1, "INSERT INTO t VALUES (5, 123456, 1)")
            .is_err()
    );
    db.execute(1, "INSERT INTO t VALUES (850, 851, 0)").unwrap();
    assert!(db.execute(1, "INSERT INTO t VALUES (850, 852, 0)").is_err());
    // UPDATE into an occupied UNIQUE key fails and rolls back cleanly.
    db.execute(3, "BEGIN").unwrap();
    assert!(db.execute(3, "UPDATE t SET id=6 WHERE id=7").is_err());
    let _ = db.execute(3, "ROLLBACK");
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=7"), 1);
    // Delete then reinsert the same key (slot reuse under the same key).
    db.execute(1, "DELETE FROM t WHERE id=10").unwrap();
    drain(&db);
    db.execute(1, "INSERT INTO t VALUES (10, 11, 60)").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=10"), 11);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=10"), 1);
    // Concurrent same-key INSERT: exactly one wins.
    db.execute(3, "BEGIN").unwrap();
    db.execute(4, "BEGIN").unwrap();
    let a = db.execute(3, "INSERT INTO t VALUES (5000, 5001, 1)");
    let b = db.execute(4, "INSERT INTO t VALUES (5000, 5002, 1)");
    let ca = a.is_ok() && db.execute(3, "COMMIT").is_ok();
    let cb = b.is_ok() && db.execute(4, "COMMIT").is_ok();
    if !ca {
        let _ = db.execute(3, "ROLLBACK");
    }
    if !cb {
        let _ = db.execute(4, "ROLLBACK");
    }
    assert!(ca ^ cb, "exactly one concurrent same-key insert commits");
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=5000"),
        1
    );
    // Stale secondary entries coexist with valid UNIQUE entries.
    let check = db.check_online().unwrap();
    assert!(check.index_stale_entries > 0, "{check:?}");
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    db.check_online().unwrap();
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=5000"),
        1
    );
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn k4_capability_is_persistent_and_absent_until_enabled() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    assert!(!db.lazy_index_enabled().unwrap());
    // Without the capability nothing is lazy: eager exact pruning.
    db.set_lazy_index_pruning(false);
    db.execute(1, "UPDATE t SET g=g+1 WHERE id<10").unwrap();
    drain(&db);
    assert!(!db.lazy_index_enabled().unwrap());
    assert_eq!(entries(&db, "d"), 1000);
    let header = fs::read(root.join("catalog.phc")).unwrap();
    assert_eq!(u16::from_le_bytes([header[4], header[5]]), 2);
    db.set_lazy_index_pruning(true);
    assert!(db.try_enable_lazy_index_pruning().unwrap());
    let header = fs::read(root.join("catalog.phc")).unwrap();
    assert_eq!(
        u16::from_le_bytes([header[4], header[5]]),
        3,
        "catalog v3 = capability present"
    );
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert!(db.lazy_index_enabled().unwrap());
    db.check_online().unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
