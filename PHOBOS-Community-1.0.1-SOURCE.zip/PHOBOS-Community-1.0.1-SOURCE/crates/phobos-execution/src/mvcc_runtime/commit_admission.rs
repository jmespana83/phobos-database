use super::*;
use phobos_txn::mvcc::sessions::CommitPermit;
use std::{collections::VecDeque, sync::Condvar};

#[derive(Default)]
pub(super) struct Queue {
    state: Mutex<State>,
    changed: Condvar,
}
#[derive(Default)]
struct State {
    next: u64,
    running: bool,
    pending: VecDeque<(u64, CommitPermit, SessionWrites)>,
    results: BTreeMap<u64, Option<Result<(), PhobosError>>>,
}
impl MvccDatabase {
    /// 0.2-K.2: whether foreground publications are queued or running.
    /// The maintenance worker defers its own publication while this holds
    /// (bounded by its yield window), so it fills gaps in the commit
    /// pipeline instead of queueing in front of user commits.
    pub(super) fn commit_pipeline_busy(&self) -> bool {
        self.queue
            .state
            .lock()
            .is_ok_and(|state| state.running || !state.pending.is_empty())
    }
    pub(super) fn enqueue_commit(
        &self,
        session: &Session,
        writes: &mut Option<SessionWrites>,
    ) -> Result<(), PhobosError> {
        let _wait = phobos_observability::span("mvcc.commit_queue_wait");
        let acquire = phobos_observability::span("mvcc.commit_queue_acquire");
        let mut state = self
            .queue
            .state
            .lock()
            .map_err(|_| write_conflict("commit queue poisoned"))?;
        drop(acquire);
        if state.results.len() >= 1024 {
            return Err(write_conflict("commit admission capacity exhausted"));
        }
        let next = state
            .next
            .checked_add(1)
            .ok_or_else(|| write_conflict("commit admission identity exhausted"))?;
        phobos_observability::synchronization_boundary(
            "a2_before_commit_admission",
            &self.data_dir,
        );
        // Reject capacity/identity exhaustion before creating an irrevocable
        // permit. Cancellation and acceptance race at this atomic transition.
        writes
            .as_ref()
            .ok_or_else(|| write_conflict("COMMIT without transaction"))?
            .control
            .submit()?;
        // The token lost to commit admission: all subsequent publication is non-interruptible.
        let _durability = phobos_error::cancellation::suspend();
        let permit = session.submit_commit()?;
        let writes = writes.take().expect("validated session writes");
        state.next = next;
        let own = next;
        state.results.insert(own, None);
        state.pending.push_back((own, permit, writes));
        phobos_observability::synchronization_boundary("c6_commit_enqueued", &self.data_dir);
        loop {
            if state.results.get(&own).is_some_and(Option::is_some) {
                return state
                    .results
                    .remove(&own)
                    .expect("admitted result")
                    .expect("completed result");
            }
            if !state.running && !state.pending.is_empty() {
                state.running = true;
                let mut ids = Vec::new();
                let mut requests = Vec::new();
                while requests.len() < 64 {
                    let Some((id, permit, writes)) = state.pending.pop_front() else {
                        break;
                    };
                    ids.push(id);
                    requests.push((permit, writes));
                }
                drop(state);
                // Panic after admission must complete/fence every waiter rather
                // than leave the running flag and submitted permits stranded.
                // D2: one result per member; a panic is durability-uncertain
                // for everyone (the batch fenced when its permits dropped).
                // 0.2-C: the next leader is elected as soon as this batch has
                // left the ordered Stage A (prepare + WAL append), so its own
                // preparation overlaps this batch's WAL force.
                let mut released = false;
                let mut release = || {
                    if !released {
                        released = true;
                        if let Ok(mut state) = self.queue.state.lock() {
                            state.running = false;
                        }
                        self.queue.changed.notify_all();
                    }
                };
                let mut absorb = |limit: usize| {
                    let mut extra = Vec::new();
                    if let Ok(mut state) = self.queue.state.lock() {
                        while extra.len() < limit {
                            let Some((id, permit, writes)) = state.pending.pop_front() else {
                                break;
                            };
                            ids.push(id);
                            extra.push((permit, writes));
                        }
                    }
                    extra
                };
                let results = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    self.commit_group_staged(requests, &mut release, &mut absorb)
                }))
                .unwrap_or_else(|_| {
                    (0..64)
                        .map(|_| Err(write_conflict("commit worker panicked; recovery required")))
                        .collect()
                });
                release();
                state = self
                    .queue
                    .state
                    .lock()
                    .map_err(|_| write_conflict("commit queue poisoned"))?;
                for (id, result) in ids.into_iter().zip(results) {
                    *state.results.get_mut(&id).expect("accepted commit") = Some(result);
                }
                self.queue.changed.notify_all();
                // Completed leaders return here; remaining waiters elect the
                // next leader. No leader drains an unbounded later workload.
            } else {
                let _wait = phobos_observability::span("mvcc.commit_completion_wait");
                state = self
                    .queue
                    .changed
                    .wait(state)
                    .map_err(|_| write_conflict("commit queue poisoned"))?;
            }
        }
    }
}
