//! Move mutable file owners out of the database directory for physical work.
//! The ordered commit owner chooses disjoint table/index sets before extraction.
//! Readers use immutable registrations; no directory guard spans private I/O.
use super::*;
use std::collections::BTreeSet;

pub(super) fn tables(writes: &SessionWrites) -> BTreeSet<TableId> {
    writes
        .tables()
        .iter()
        .copied()
        .chain(writes.bulk.iter().map(|bulk| bulk.schema.id))
        .collect()
}
impl MvccDatabase {
    pub(super) fn take_domain(&self, writes: &SessionWrites) -> Result<Database, PhobosError> {
        self.take_domain_tables(tables(writes))
    }
    /// 0.2-C: one physical domain for a whole commit batch (union of the
    /// members' tables), instead of one extraction per member and phase.
    pub(super) fn take_domain_tables(
        &self,
        tables: BTreeSet<TableId>,
    ) -> Result<Database, PhobosError> {
        let _take_domain = phobos_observability::span("mvcc.take_domain");
        let mut database = self.lock_database()?;
        let index_ids = database
            .catalog
            .indexes()
            .filter(|index| tables.contains(&index.table_id))
            .map(|index| index.id)
            .collect::<Vec<_>>();
        if tables.iter().any(|id| !database.heaps.contains_key(id))
            || index_ids
                .iter()
                .any(|id| !database.indexes.contains_key(id))
        {
            return Err(write_conflict(
                "physical domain is not independently available",
            ));
        }
        let heaps = tables
            .into_iter()
            .map(|id| (id, database.heaps.remove(&id).expect("checked heap")))
            .collect();
        let indexes = index_ids
            .into_iter()
            .map(|id| (id, database.indexes.remove(&id).expect("checked index")))
            .collect();
        let catalog = {
            let _catalog_clone = phobos_observability::span("mvcc.domain_catalog_clone");
            database.catalog.clone()
        };
        Ok(Database {
            data_dir: database.data_dir.clone(),
            catalog,
            heaps,
            indexes,
            private_txn: None,
            committed_store: database.committed_store.clone(),
            buffer_pages: database.buffer_pages,
            query_memory_bytes: database.query_memory_bytes,
            last_access_path: None,
            last_plan: None,
            stats: database.stats.clone(),
            wal: None,
            wal_v2: None,
            fenced: false,
            txn_manager: None,
            active_txn: None,
            private_staging: false,
            mvcc_view: false,
        })
    }
    pub(super) fn return_domain(&self, mut domain: Database) -> Result<(), PhobosError> {
        let _return_domain = phobos_observability::span("mvcc.return_domain");
        let mut database = self
            .database
            .lock()
            .map_err(|_| write_conflict("database directory poisoned"))?;
        for (id, heap) in std::mem::take(&mut domain.heaps) {
            if database.heaps.insert(id, heap).is_some() {
                database.fenced = true;
                return Err(write_conflict("duplicate physical heap owner"));
            }
        }
        for (id, tree) in std::mem::take(&mut domain.indexes) {
            if database.indexes.insert(id, tree).is_some() {
                database.fenced = true;
                return Err(write_conflict("duplicate physical index owner"));
            }
        }
        Ok(())
    }
    /// `with_domain` for an explicit table set (never a schema change).
    /// 0.2-G: run a commit-order stage on the shared database in place,
    /// under its mutex, instead of extracting and re-inserting a physical
    /// domain (two map rebuilds and large struct moves per stage). Only for
    /// stages that already hold the commit-order lock and touch no other
    /// lock that is taken before the database mutex (lock order is always
    /// commits -> database -> WAL). A panic fences the database.
    pub(super) fn with_database_in_place<T>(
        &self,
        operation: impl FnOnce(&mut Database) -> Result<T, PhobosError>,
    ) -> Result<T, PhobosError> {
        let mut database = self.lock_database()?;
        let result =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| operation(&mut database)));
        match result {
            Ok(result) => result,
            Err(payload) => {
                drop(database);
                self.fence_database();
                std::panic::resume_unwind(payload)
            }
        }
    }
    pub(super) fn with_domain<T>(
        &self,
        writes: &SessionWrites,
        operation: impl FnOnce(&mut Database) -> Result<T, PhobosError>,
    ) -> Result<T, PhobosError> {
        if writes.schema.is_some() {
            return operation(&mut *self.lock_database()?);
        }
        let mut domain = self.take_domain(writes)?;
        let result =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| operation(&mut domain)));
        self.return_domain(domain)?;
        match result {
            Ok(result) => result,
            Err(payload) => std::panic::resume_unwind(payload),
        }
    }
}
