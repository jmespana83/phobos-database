//! 0.1.9-D1/D2/D3: lazy transaction identities, one durability force per
//! commit, independent batch-member results and single-pass admission.
//!
//! Every test uses the C5 runtime fixture (`t(id,v,g)` with 1000 committed
//! rows, unique index `u(id)`, composite unique `c(v,g)`).
use super::*;
use std::{
    process::{Command, exit},
    sync::atomic::{AtomicU64, Ordering},
    time::Duration,
};
use tests::fixture;

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            Value::Null => 0,
            ref other => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}
fn close(db: MvccDatabase, sessions: &[u64]) {
    for session in sessions {
        db.disconnect(*session);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
}
/// Counts WAL forces through the existing `wal.after_force` hook.
fn force_counter(
    root: &Path,
) -> (
    Arc<AtomicU64>,
    phobos_observability::test_hooks::Registration,
) {
    let forces = Arc::new(AtomicU64::new(0));
    let observed = forces.clone();
    let hook = phobos_observability::test_hooks::register(
        root,
        Arc::new(move |at| {
            if at == "wal.after_force" {
                observed.fetch_add(1, Ordering::Relaxed);
            }
        }),
    );
    (forces, hook)
}

#[cfg(feature = "db1-diagnostics")]
fn validate_all_indexes(db: &MvccDatabase) {
    let mut database = db.lock_database().unwrap();
    for tree in database.indexes.values_mut() {
        tree.validate().unwrap();
    }
}

#[cfg(feature = "db1-diagnostics")]
#[test]
fn db1_logical_write_staged_before_other_splits_rebases_on_commit() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    phobos_index::reset_db1_diagnostic_counters();

    // B retains only a logical RowChange. While it is open, A publishes enough
    // hot-key history to force consecutive splits in the same key range.
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "UPDATE t SET g=g WHERE id=43").unwrap();
    for _ in 0..450 {
        db.execute(1, "UPDATE t SET g=g WHERE id=42").unwrap();
    }
    db.execute(2, "COMMIT").unwrap();
    validate_all_indexes(&db);
    let counters = phobos_index::db1_diagnostic_counters();
    println!("DB1_SCENARIO_B {counters:?} rebases=451 staged_private_pages_before_commit=0");
    assert!(counters.splits > 0);
    assert_eq!(counters.splits, counters.successor_checks);
    assert_eq!(counters.failures, 0);
    close(db, &[1, 2]);
    let db = MvccDatabase::open(&root).unwrap();
    validate_all_indexes(&db);
    close(db, &[]);
    fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "db1-diagnostics")]
#[test]
fn db1_same_table_second_commit_cannot_prepare_while_first_is_paused() {
    use std::{sync::mpsc, thread};
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET g=g WHERE id=42").unwrap();
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "UPDATE t SET g=g WHERE id=43").unwrap();

    let (queued_tx, queued_rx) = mpsc::channel();
    let (prepared_tx, prepared_rx) = mpsc::channel();
    let (release_tx, release_rx) = mpsc::channel();
    let release_rx = Mutex::new(release_rx);
    let preparations = Arc::new(AtomicU64::new(0));
    let seen = preparations.clone();
    let first = std::sync::atomic::AtomicBool::new(true);
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |point| {
            if point == "c6_commit_enqueued" {
                queued_tx.send(()).unwrap();
            }
            if point == "c6_private_preparation_begin" {
                seen.fetch_add(1, Ordering::SeqCst);
                if first.swap(false, Ordering::SeqCst) {
                    prepared_tx.send(()).unwrap();
                    release_rx.lock().unwrap().recv().unwrap();
                }
            }
        }),
    );
    let a_db = db.clone();
    let a = thread::spawn(move || a_db.execute(1, "COMMIT"));
    queued_rx.recv_timeout(Duration::from_secs(10)).unwrap();
    prepared_rx.recv_timeout(Duration::from_secs(10)).unwrap();
    let b_db = db.clone();
    let b = thread::spawn(move || b_db.execute(2, "COMMIT"));
    queued_rx.recv_timeout(Duration::from_secs(10)).unwrap();
    assert_eq!(preparations.load(Ordering::SeqCst), 1);
    release_tx.send(()).unwrap();
    a.join().unwrap().unwrap();
    b.join().unwrap().unwrap();
    assert_eq!(preparations.load(Ordering::SeqCst), 2);
    drop(hook);
    validate_all_indexes(&db);
    let db = Arc::try_unwrap(db).ok().expect("sole database owner");
    close(db, &[1, 2]);
    fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "db1-diagnostics")]
#[test]
fn db1_sixteen_session_hot_and_adjacent_split_stress() {
    use std::thread;
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    phobos_index::reset_db1_diagnostic_counters();
    let mut workers = Vec::new();
    for session in 1..=16u64 {
        let db = db.clone();
        workers.push(thread::spawn(move || {
            let mut committed = 0;
            let mut attempts = 0;
            while committed < 50 && attempts < 4000 {
                attempts += 1;
                let sql = if session == 1 {
                    "UPDATE t SET g=g WHERE id=42".to_owned()
                } else {
                    format!("UPDATE t SET g=g WHERE id={}", 100 + session)
                };
                if db.execute(session, &sql).is_ok() {
                    committed += 1;
                }
            }
            assert_eq!(committed, 50, "worker exhausted retries");
            db.disconnect(session);
        }));
    }
    for worker in workers {
        worker.join().unwrap();
    }
    let db = Arc::try_unwrap(db).ok().expect("sole database owner");
    validate_all_indexes(&db);
    let wal_evidence = root.join("db1-diagnostic-wal-before-checkpoint");
    let wal_files = phobos_wal::v2::preserve_wal_for_test(&root, &wal_evidence).unwrap();
    assert!(wal_files > 0);
    db.execute(99, "CHECKPOINT").unwrap();
    validate_all_indexes(&db);
    let counters = phobos_index::db1_diagnostic_counters();
    println!(
        "DB1_STRESS transactions=800 checkpoints=1 same_leaf_overlapping_preparations=0 rebases=800 retained_wal_files={wal_files} {counters:?}"
    );
    assert_eq!(counters.splits, counters.successor_checks);
    assert_eq!(counters.failures, 0);
    close(db, &[99]);
    let db = MvccDatabase::open(&root).unwrap();
    validate_all_indexes(&db);
    close(db, &[]);
    fs::remove_dir_all(root).unwrap();
}

#[cfg(feature = "db1-diagnostics")]
#[test]
fn db1_sixteen_session_original_style_mixed_campaign() {
    use std::thread;
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    phobos_index::reset_db1_diagnostic_counters();
    let mut workers = Vec::new();
    for session in 1..=16u64 {
        let db = db.clone();
        workers.push(thread::spawn(move || {
            for operation in 0..40u64 {
                let sql = match operation % 4 {
                    0 => format!("UPDATE t SET g=g WHERE id={}", 100 + session),
                    1 => format!(
                        "INSERT INTO t VALUES ({},{},NULL)",
                        1_000_000 + session * 1000 + operation,
                        operation
                    ),
                    _ => format!("SELECT v FROM t WHERE id={}", operation % 1000),
                };
                db.execute(session, &sql).unwrap();
            }
            db.disconnect(session);
        }));
    }
    for worker in workers {
        worker.join().unwrap();
    }
    let db = Arc::try_unwrap(db).ok().expect("sole database owner");
    validate_all_indexes(&db);
    db.execute(99, "CHECKPOINT").unwrap();
    validate_all_indexes(&db);
    let counters = phobos_index::db1_diagnostic_counters();
    println!("DB1_MIXED clients=16 statements=640 writes=320 reads=320 checkpoints=1 {counters:?}");
    assert_eq!(counters.splits, counters.successor_checks);
    assert_eq!(counters.failures, 0);
    close(db, &[99]);
    let db = MvccDatabase::open(&root).unwrap();
    validate_all_indexes(&db);
    close(db, &[]);
    fs::remove_dir_all(root).unwrap();
}

/// D1 (1, 2): read-only COMMIT and ROLLBACK consume no identity and force
/// nothing; the next writer receives the identity the reads did not take.
#[test]
fn d1_read_only_commit_and_rollback_consume_no_identity_and_no_force() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let before = db.commit_metrics();
    let (forces, hook) = force_counter(&root);
    db.execute(1, "BEGIN").unwrap();
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 1000);
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=7"), 7);
    db.execute(1, "COMMIT").unwrap();
    db.execute(1, "BEGIN").unwrap();
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 1000);
    db.execute(1, "ROLLBACK").unwrap();
    // Statement boundaries inside the read-only transaction are ordinary.
    db.execute(1, "BEGIN").unwrap();
    assert!(db.execute(1, "SELECT nope FROM t").is_err());
    assert!(
        db.execute(1, "COMMIT").is_err(),
        "failed transaction needs ROLLBACK"
    );
    db.execute(1, "ROLLBACK").unwrap();
    let after = db.commit_metrics();
    assert_eq!(
        after.ids_allocated, before.ids_allocated,
        "no identity for reads"
    );
    assert_eq!(after.status_writes, before.status_writes);
    assert_eq!(after.status_forces, before.status_forces);
    assert_eq!(forces.load(Ordering::Relaxed), 0, "no WAL force for reads");
    drop(hook);
    // COMMIT/ROLLBACK outside a transaction are still errors.
    assert!(db.execute(1, "COMMIT").is_err());
    assert!(db.execute(1, "ROLLBACK").is_err());
    // The seed transaction took identity 1; the first real writer gets 2.
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (5000,5000,NULL)")
        .unwrap();
    let connection = db.connection(1).unwrap();
    let stable = connection.lock().unwrap().session.transaction_id().unwrap();
    assert_eq!(stable, Some(2));
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(db.commit_metrics().ids_allocated, before.ids_allocated + 1);
    close(db, &[1]);
    fs::remove_dir_all(root).unwrap();
}

/// D1 (3): the first write allocates exactly one identity; every later
/// statement of the transaction reuses it and its versions carry it.
#[test]
fn d1_first_write_allocates_one_identity_reused_by_later_statements() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let before = db.commit_metrics();
    db.execute(1, "BEGIN").unwrap();
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 1000);
    let connection = db.connection(1).unwrap();
    assert_eq!(
        connection.lock().unwrap().session.transaction_id().unwrap(),
        None
    );
    db.execute(1, "INSERT INTO t VALUES (5001,1,NULL)").unwrap();
    let stable = connection
        .lock()
        .unwrap()
        .session
        .transaction_id()
        .unwrap()
        .expect("allocated by the first write");
    db.execute(1, "UPDATE t SET v=2 WHERE id=5001").unwrap();
    db.execute(1, "DELETE FROM t WHERE id=1").unwrap();
    db.execute(1, "INSERT INTO t VALUES (5002,3,NULL)").unwrap();
    assert_eq!(
        connection.lock().unwrap().session.transaction_id().unwrap(),
        Some(stable)
    );
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=5001"), 2);
    db.execute(1, "COMMIT").unwrap();
    let after = db.commit_metrics();
    assert_eq!(after.ids_allocated, before.ids_allocated + 1);
    assert_eq!(after.status_forces, before.status_forces);
    assert_eq!(
        db.sessions
            .lookup(stable)
            .map(|s| matches!(s, phobos_txn::mvcc::Status::Committed { .. })),
        Ok(true)
    );
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1001);
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5002"), 3);
    close(db, &[1, 2]);
    fs::remove_dir_all(root).unwrap();
}

/// D1 (4): an autocommit write allocates one identity, commits through one
/// WAL force and writes (never forces) its status record.
#[test]
fn d1_autocommit_write_commits_with_one_wal_force_and_no_status_force() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let before = db.commit_metrics();
    let (forces, hook) = force_counter(&root);
    db.execute(1, "INSERT INTO t VALUES (6000,6000,NULL)")
        .unwrap();
    drop(hook);
    let after = db.commit_metrics();
    assert_eq!(after.ids_allocated, before.ids_allocated + 1);
    assert_eq!(
        after.status_writes,
        before.status_writes + 2,
        "reserve + commit records"
    );
    assert_eq!(
        after.status_forces, before.status_forces,
        "no status-file force"
    );
    assert_eq!(forces.load(Ordering::Relaxed), 1, "one WAL force");
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=6000"), 6000);
    // The connection is out of the transaction: a plain COMMIT is an error.
    assert!(db.execute(1, "COMMIT").is_err());
    close(db, &[1, 2]);
    fs::remove_dir_all(root).unwrap();
}

const CRASH_POINT: &str = "PHOBOS_D1_CRASH_POINT";
const CRASH_ROOT: &str = "PHOBOS_D1_CRASH_ROOT";
const CRASH_TEST: &str =
    "mvcc_runtime::commit_path_tests::d1_committed_write_survives_crash_before_any_status_force";

/// D1 (5, 6): a committed write survives a crash that happens before the
/// status file is ever forced, and recovery reconstructs its committed
/// status from the retained WAL even when the status record itself is lost.
#[test]
fn d1_committed_write_survives_crash_before_any_status_force() {
    if let Ok(point) = std::env::var(CRASH_POINT) {
        let root = PathBuf::from(std::env::var_os(CRASH_ROOT).unwrap());
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(1, "INSERT INTO t VALUES (7000,7000,NULL)")
            .unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "UPDATE t SET v=70 WHERE id=7000").unwrap();
        db.execute(1, "DELETE FROM t WHERE id=2").unwrap();
        db.execute(1, "COMMIT").unwrap();
        // A transaction left open at the crash: its identity is lazily
        // reserved and nothing of it may survive.
        db.execute(2, "BEGIN").unwrap();
        db.execute(2, "INSERT INTO t VALUES (7001,1,NULL)").unwrap();
        assert_eq!(point, "after_commit");
        exit(86); // No destructors, no shutdown checkpoint.
    }
    let root = fixture();
    let output = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", CRASH_TEST, "--nocapture"])
        .env(CRASH_POINT, "after_commit")
        .env(CRASH_ROOT, &root)
        .output()
        .unwrap();
    assert_eq!(
        output.status.code(),
        Some(86),
        "child did not crash at the boundary\n{}",
        String::from_utf8_lossy(&output.stderr)
    );
    // Simulate the loss of every status byte written since the last force:
    // truncate the status file to the records the durable header boundary
    // vouches for (the seed transaction only).
    let path = root.join("phobos.mvcc-status");
    let mut header = [0; 32];
    std::io::Read::read_exact(&mut fs::File::open(&path).unwrap(), &mut header).unwrap();
    let boundary = u64::from_le_bytes(header[16..24].try_into().unwrap());
    assert_eq!(boundary, 2, "only the seed identity was ever forced");
    let file = fs::OpenOptions::new().write(true).open(&path).unwrap();
    file.set_len(32 + (boundary - 1) * 32).unwrap();
    file.sync_all().unwrap();
    for round in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        assert_eq!(
            scalar(&db, 1, "SELECT v FROM t WHERE id=7000"),
            70,
            "round {round}"
        );
        assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id=2"), 0);
        assert_eq!(
            scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id=7001"),
            0
        );
        assert_eq!(
            scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"),
            1000 + round as i64
        );
        // Identities 2 and 3 committed (reconstructed from the WAL). The
        // open transaction held identity 4 in memory only: it never reached
        // the WAL and its lazily written record was lost, so after the
        // crash the identity is unknown and is re-issued to the next writer
        // (nothing durable can observe that).
        for id in [2, 3] {
            assert!(matches!(
                db.sessions.lookup(id).unwrap(),
                phobos_txn::mvcc::Status::Committed { .. }
            ));
        }
        if round == 0 {
            assert!(db.sessions.lookup(4).is_err());
        }
        db.execute(
            1,
            &format!("INSERT INTO t VALUES ({},2,NULL)", 7002 + round),
        )
        .unwrap();
        let connection = db.connection(1).unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "UPDATE t SET v=3 WHERE id=7002").unwrap();
        let stable = connection.lock().unwrap().session.transaction_id().unwrap();
        assert_eq!(stable, Some(5 + 2 * round));
        db.execute(1, "ROLLBACK").unwrap();
        if round == 0 {
            db.disconnect(1);
            drop(db);
        } else {
            db.execute(1, "CHECKPOINT").unwrap();
            close(db, &[1]);
        }
    }
    // After the checkpoint the statuses are durable in the file alone.
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=7000"), 70);
    assert_eq!(
        scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id>=7002"),
        2
    );
    close(db, &[1]);
    fs::remove_dir_all(root).unwrap();
}

/// D2 (7, 8, 10): three members in one batch — A commits, B fails a
/// logical check during preparation, C commits. Each member receives its
/// own result, B fences nothing, and later transactions proceed.
#[test]
fn d2_batch_member_logical_failure_is_independent_and_non_fencing() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let sessions = (1..=3)
        .map(|id| db.connect(id).unwrap())
        .collect::<Vec<_>>();
    let mut requests = Vec::new();
    for (index, session) in sessions.iter().enumerate() {
        let id = 8000 + index as i64;
        session.begin_deferred().unwrap();
        let stable = session.ensure_transaction_id().unwrap();
        let mut writes = db.session_writes(stable).unwrap();
        db.stage(
            session,
            &mut writes,
            &format!("INSERT INTO t VALUES ({id},{id},NULL)"),
            &[],
        )
        .unwrap();
        if index == 1 {
            writes.fail_prepare = Some("duplicate key violates unique index");
        }
        requests.push((session.submit_commit().unwrap(), writes));
    }
    let stables = sessions
        .iter()
        .map(|session| session.transaction_id().unwrap().unwrap())
        .collect::<Vec<_>>();
    let results = db.commit_group(requests);
    assert_eq!(results.len(), 3);
    assert!(results[0].is_ok(), "{:?}", results[0]);
    assert_eq!(
        results[1].as_ref().unwrap_err().code,
        ErrorCode::ConstraintViolation
    );
    assert!(results[2].is_ok(), "{:?}", results[2]);
    // Nothing fenced: the database, the sessions and the failed member's
    // own session all continue.
    assert!(!db.fenced.load(Ordering::Acquire));
    assert!(db.sessions.is_idle().unwrap());
    assert_eq!(
        scalar(&db, 9, "SELECT COUNT(*) AS n FROM t WHERE id>=8000"),
        2
    );
    assert_eq!(
        scalar(&db, 9, "SELECT COUNT(*) AS n FROM t WHERE id=8001"),
        0
    );
    assert!(matches!(
        db.sessions.lookup(stables[0]).unwrap(),
        phobos_txn::mvcc::Status::Committed { .. }
    ));
    assert_eq!(
        db.sessions.lookup(stables[1]).unwrap(),
        phobos_txn::mvcc::Status::Aborted
    );
    assert!(matches!(
        db.sessions.lookup(stables[2]).unwrap(),
        phobos_txn::mvcc::Status::Committed { .. }
    ));
    // No private image of the failed member survives.
    assert!(fs::read_dir(&root).unwrap().all(|entry| {
        !entry
            .unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with(".phobos-mvcc-private-")
    }));
    // The failed member's session commits a later transaction normally,
    // with the key it could not insert.
    let stable = sessions[1].begin().unwrap();
    let mut writes = db.session_writes(stable).unwrap();
    db.stage(
        &sessions[1],
        &mut writes,
        "INSERT INTO t VALUES (8001,1,NULL)",
        &[],
    )
    .unwrap();
    db.commit(&sessions[1], writes).unwrap();
    drop(sessions);
    assert_eq!(
        scalar(&db, 9, "SELECT COUNT(*) AS n FROM t WHERE id>=8000"),
        3
    );
    db.execute(9, "CHECKPOINT").unwrap();
    close(db, &[9]);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        scalar(&db, 9, "SELECT COUNT(*) AS n FROM t WHERE id>=8000"),
        3
    );
    close(db, &[9]);
    fs::remove_dir_all(root).unwrap();
}

/// D2 (7) at the SQL level: three explicit transactions whose COMMITs form
/// one group; B's INSERT violated UNIQUE, so its COMMIT fails alone while
/// A and C commit. The failed connection recovers with ROLLBACK.
#[test]
fn d2_sql_group_commit_reports_independent_results() {
    use std::{sync::mpsc, thread};
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    for id in 1..=3u64 {
        db.execute(id, "BEGIN").unwrap();
        let sql = if id == 2 {
            "INSERT INTO t VALUES (1,1,NULL)".to_owned()
        } else {
            format!("INSERT INTO t VALUES ({},{},NULL)", 8100 + id, 8100 + id)
        };
        let result = db.execute(id, &sql);
        if id == 2 {
            assert_eq!(result.unwrap_err().code, ErrorCode::ConstraintViolation);
        } else {
            result.unwrap();
        }
    }
    // Hold the leader (a fourth transaction) inside its preparation so the
    // three COMMITs queue up and run as one group behind it.
    db.execute(4, "BEGIN").unwrap();
    db.execute(4, "INSERT INTO t VALUES (8200,8200,NULL)")
        .unwrap();
    let (queued, queue) = mpsc::channel();
    let (started, start) = mpsc::channel();
    let (release, released) = mpsc::channel();
    let released = Mutex::new(released);
    let once = std::sync::atomic::AtomicBool::new(false);
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |point| {
            if point == "c6_commit_enqueued" {
                queued.send(()).unwrap();
            }
            if point == "c6_private_preparation_begin" && !once.swap(true, Ordering::SeqCst) {
                started.send(()).unwrap();
                released
                    .lock()
                    .unwrap()
                    .recv_timeout(Duration::from_secs(10))
                    .unwrap();
            }
        }),
    );
    let leader_db = db.clone();
    let leader = thread::spawn(move || leader_db.execute(4, "COMMIT"));
    start.recv_timeout(Duration::from_secs(10)).unwrap();
    queue.recv_timeout(Duration::from_secs(10)).unwrap();
    let mut commits = Vec::new();
    for id in [1u64, 3] {
        let db = db.clone();
        commits.push((id, thread::spawn(move || db.execute(id, "COMMIT"))));
        queue.recv_timeout(Duration::from_secs(10)).unwrap();
    }
    // B's COMMIT of a failed transaction is rejected before admission and
    // never reaches the group; the connection needs ROLLBACK.
    let b = db.execute(2, "COMMIT");
    assert!(b.is_err(), "failed transaction cannot commit");
    release.send(()).unwrap();
    leader.join().unwrap().unwrap();
    for (id, commit) in commits {
        commit
            .join()
            .unwrap()
            .unwrap_or_else(|e| panic!("member {id}: {e:?}"));
    }
    drop(hook);
    db.execute(2, "ROLLBACK").unwrap();
    assert_eq!(
        scalar(&db, 5, "SELECT COUNT(*) AS n FROM t WHERE id>=8100"),
        3
    );
    assert_eq!(scalar(&db, 5, "SELECT COUNT(*) AS n FROM t WHERE id=1"), 1);
    // B works again.
    db.execute(2, "INSERT INTO t VALUES (8102,8102,NULL)")
        .unwrap();
    assert_eq!(
        scalar(&db, 5, "SELECT COUNT(*) AS n FROM t WHERE id>=8100"),
        4
    );
    let db = Arc::try_unwrap(db).ok().expect("sole owner");
    close(db, &[1, 2, 3, 4, 5]);
    fs::remove_dir_all(root).unwrap();
}

/// D2 (9): a real durability failure (the WAL force) still fences the
/// database, the commit reports the failure, nothing partial survives.
#[test]
fn d2_injected_wal_force_failure_still_fences() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (8300,8300,NULL)")
        .unwrap();
    db.wal.lock().unwrap().fail_next_force_for_test();
    let error = db.execute(1, "COMMIT").unwrap_err();
    assert_ne!(error.code, ErrorCode::ConstraintViolation);
    assert!(
        db.fenced.load(Ordering::Acquire),
        "durability uncertainty fences"
    );
    assert!(db.execute(2, "SELECT id FROM t").is_err());
    assert!(db.execute(2, "INSERT INTO t VALUES (8301,1,NULL)").is_err());
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    // Recovery: the appended chain may or may not have reached the disk;
    // either the row is there or it is not, never a partial state, and the
    // database works afterwards.
    let db = MvccDatabase::open(&root).unwrap();
    let rows = scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id=8300");
    assert!(rows == 0 || rows == 1);
    db.execute(1, "INSERT INTO t VALUES (8302,1,NULL)").unwrap();
    assert_eq!(
        scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id=8302"),
        1
    );
    close(db, &[1]);
    fs::remove_dir_all(root).unwrap();
}

/// D1/A4 (11): a spilled transaction commits through the lazy-identity path.
#[test]
fn d1_spilled_transaction_commits_through_the_new_path() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.set_write_spill(4096, 64 * 1024 * 1024).unwrap();
    let before = db.commit_metrics();
    db.execute(1, "BEGIN").unwrap();
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 1000);
    for chunk in 0..8 {
        let values = (0..250)
            .map(|n| {
                let id = 20000 + chunk * 250 + n;
                format!("({id},{id},NULL)")
            })
            .collect::<Vec<_>>()
            .join(",");
        db.execute(1, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
    }
    db.execute(1, "UPDATE t SET v=v+1 WHERE id>=20000").unwrap();
    let stats = {
        let connection = db.connection(1).unwrap();
        let guard = connection.lock().unwrap();
        guard.writes.as_ref().unwrap().spill_stats()
    };
    assert!(stats.runs > 0 && stats.spilled_changes > 0, "{stats:?}");
    assert_eq!(
        scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id>=20000"),
        2000
    );
    db.execute(1, "COMMIT").unwrap();
    let after = db.commit_metrics();
    assert_eq!(after.ids_allocated, before.ids_allocated + 1);
    assert_eq!(after.status_forces, before.status_forces);
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id>=20000"),
        2000
    );
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=20999"), 21000);
    close(db, &[1, 2]);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id>=20000"),
        2000
    );
    close(db, &[2]);
    fs::remove_dir_all(root).unwrap();
}

/// D1/A3/C4 (12): growth of the status grant and the freezing watermark
/// keep working when identities are allocated lazily; identities stay
/// monotonic across reopen and read-only transactions never disturb them.
#[test]
fn d1_status_growth_and_freeze_watermark_with_lazy_allocation() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let capacity = |root: &Path| {
        let mut header = [0; 32];
        std::io::Read::read_exact(
            &mut fs::File::open(root.join("phobos.mvcc-status")).unwrap(),
            &mut header,
        )
        .unwrap();
        u64::from_le_bytes(header[8..16].try_into().unwrap())
    };
    let capacity_before = capacity(&root);
    let mut expected = 2u64;
    for round in 0..40 {
        db.execute(1, "BEGIN").unwrap();
        assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id<0"), 0);
        db.execute(1, "COMMIT").unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, &format!("UPDATE t SET v=v+1 WHERE id={}", round + 1))
            .unwrap();
        let connection = db.connection(1).unwrap();
        let stable = connection.lock().unwrap().session.transaction_id().unwrap();
        assert_eq!(stable, Some(expected), "round {round}");
        expected += 1;
        if round % 3 == 0 {
            db.execute(1, "ROLLBACK").unwrap();
        } else {
            db.execute(1, "COMMIT").unwrap();
        }
    }
    // Reopen: the next writer continues the sequence.
    close(db, &[1]);
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    db.execute(1, "INSERT INTO t VALUES (9000,1,NULL)").unwrap();
    assert_eq!(db.commit_metrics().ids_allocated, 1);
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=2 WHERE id=9000").unwrap();
    let connection = db.connection(1).unwrap();
    assert_eq!(
        connection.lock().unwrap().session.transaction_id().unwrap(),
        Some(expected + 1)
    );
    db.execute(1, "COMMIT").unwrap();
    // C4: churn the early rows so the seed identity is no longer referenced,
    // then a bounded freeze advances the watermark past resolved identities.
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    db.execute(1, "CHECKPOINT").unwrap();
    for _ in 0..64 {
        if db.freeze_once(64).unwrap().sweep_complete {
            break;
        }
    }
    let (boundary, _) = db.freeze_metrics().unwrap();
    assert!(boundary > 1, "watermark advanced: {boundary}");
    assert!(
        db.sessions.lookup(1).is_err(),
        "frozen identities fail closed"
    );
    // A3: many more writers grow the grant past its initial capacity.
    let sql = "INSERT INTO t VALUES (9001,1,NULL)";
    db.execute(1, sql).unwrap();
    db.execute(1, "DELETE FROM t WHERE id=9001").unwrap();
    let mut allocated = db.commit_metrics().ids_allocated;
    while capacity(&root) == capacity_before {
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "UPDATE t SET v=v WHERE id=9000").unwrap();
        db.execute(1, "ROLLBACK").unwrap();
        allocated += 1;
        assert_eq!(db.commit_metrics().ids_allocated, allocated);
        assert!(allocated < 4096, "grant never grew");
    }
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=3 WHERE id=9000").unwrap();
    db.execute(1, "COMMIT").unwrap();
    close(db, &[1]);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=9000"), 3);
    assert!(db.freeze_metrics().unwrap().0 >= boundary);
    close(db, &[1]);
    fs::remove_dir_all(root).unwrap();
}

/// A2 (13): cancellation immediately before admission aborts the transaction
/// (no effects, ROLLBACK required); cancellation immediately after the
/// irrevocable boundary lets the commit complete with its true result.
#[test]
fn a2_cancellation_boundary_unchanged_with_lazy_identities() {
    use std::{sync::mpsc, thread};
    for before in [true, false] {
        let root = fixture();
        let db = Arc::new(MvccDatabase::open(&root).unwrap());
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "UPDATE t SET v=100 WHERE id=1").unwrap();
        let (signal, reached) = mpsc::channel();
        let (resume, resumed) = mpsc::channel();
        let resumed = Mutex::new(resumed);
        let boundary = if before {
            "a2_before_commit_admission"
        } else {
            "c6_commit_enqueued"
        };
        let hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |point| {
                if point == boundary {
                    signal.send(()).unwrap();
                    resumed
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
            }),
        );
        let worker_db = db.clone();
        let commit = thread::spawn(move || worker_db.execute(1, "COMMIT"));
        reached.recv_timeout(Duration::from_secs(10)).unwrap();
        db.cancel(1);
        resume.send(()).unwrap();
        let result = commit.join().unwrap();
        drop(hook);
        if before {
            // `MvccDatabase::cancel` cancels the transaction's wait control;
            // the server maps this to StatementCancelled for the client.
            assert_eq!(result.unwrap_err().code, ErrorCode::TransactionState);
            assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=1"), 1);
            assert!(db.execute(1, "COMMIT").is_err());
            db.execute(1, "ROLLBACK").unwrap();
        } else {
            result.unwrap();
            assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=1"), 100);
            assert!(db.execute(1, "ROLLBACK").is_err(), "already committed");
        }
        assert!(!db.fenced.load(Ordering::Acquire));
        db.execute(1, "UPDATE t SET v=v+1 WHERE id=1").unwrap();
        let db = Arc::try_unwrap(db).ok().expect("sole owner");
        close(db, &[1, 2]);
        fs::remove_dir_all(root).unwrap();
    }
}

/// D3 (14): one committed view per write statement, however many changes it
/// admits (before D3: two full views per change), with UNIQUE and row
/// version checks still exact.
#[test]
fn d3_admission_builds_one_view_per_statement() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let before = db.admission_metrics();
    let values = (10000..10200)
        .map(|id| format!("({id},{id},NULL)"))
        .collect::<Vec<_>>()
        .join(",");
    db.execute(1, &format!("INSERT INTO t VALUES {values}"))
        .unwrap();
    let inserted = db.admission_metrics();
    assert_eq!(inserted.passes, before.passes + 1);
    assert_eq!(
        inserted.views_built,
        before.views_built + 1,
        "200 admitted inserts built one committed view"
    );
    db.execute(1, "UPDATE t SET v=v+1 WHERE id>=10000").unwrap();
    let updated = db.admission_metrics();
    assert_eq!(updated.passes, inserted.passes + 1);
    assert_eq!(updated.views_built, inserted.views_built + 1);
    db.execute(1, "DELETE FROM t WHERE id>=10100").unwrap();
    let deleted = db.admission_metrics();
    assert_eq!(deleted.views_built, updated.views_built + 1);
    // Correctness of the single pass: same-statement, same-transaction and
    // committed duplicates are still rejected; a stale row head is caught.
    assert_eq!(
        db.execute(1, "INSERT INTO t VALUES (10300,1,NULL),(10300,2,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    assert_eq!(
        db.execute(1, "INSERT INTO t VALUES (10000,1,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (10400,1,NULL)")
        .unwrap();
    assert_eq!(
        db.execute(1, "INSERT INTO t VALUES (10400,2,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    db.execute(1, "ROLLBACK").unwrap();
    // A concurrent committed insert during another session's transaction is
    // seen by the recheck, which runs against the latest published state.
    db.execute(2, "BEGIN").unwrap();
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=10500"),
        0
    );
    db.execute(1, "INSERT INTO t VALUES (10500,1,NULL)")
        .unwrap();
    assert_eq!(
        db.execute(2, "INSERT INTO t VALUES (10500,2,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    db.execute(2, "ROLLBACK").unwrap();
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id>=10000"),
        101
    );
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=10050"), 10051);
    close(db, &[1, 2]);
    fs::remove_dir_all(root).unwrap();
}
