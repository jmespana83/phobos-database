//! 0.1.9-C1/C2/C3 + 0.2-K Storage Lifecycle V1: bounded reclamation of
//! globally dead heap versions and horizon-gated slot reuse.
//!
//! C1 bookkeeping: every committed UPDATE/DELETE flags the page holding the
//! superseded version (`PAGE_FLAG_RECLAIM_CANDIDATE`, set in the same page
//! write) and the publisher records the page in this database's in-memory
//! candidate set. After a restart the in-memory set is rebuilt lazily by a
//! bounded cursor over page headers, so bookkeeping loss costs inspections,
//! never correctness.
//!
//! One pass (`reclaim_with_session`) inspects at most `limit` candidate pages
//! of ONE table under a statement snapshot and commits one internal
//! maintenance transaction whose private page images carry, per page:
//!
//! * phase 1, LIVE -> RETIRED: versions `globally_dead` proves invisible to
//!   every current and future snapshot (horizon observed before the pass),
//!   with their exact `(key, RID)` index entries (C3) in the same images;
//! * phase 2, RETIRED -> FREE: slots that were RETIRED in published state by
//!   a publication whose sequence the reclamation horizon has since passed
//!   (`retired_at < horizon`, see `docs/storage_lifecycle_0_2_k.md` for the
//!   proof), then trailing-FREE trim and whole-page reset.
//!
//! Everything flows through the ordinary private-page -> page-image WAL ->
//! force -> install -> publication path, so a crash shows either the old or
//! the complete new state of every page of the pass.
use super::*;
use phobos_storage::{LifecyclePage, PAGE_FLAG_RECLAIM_CANDIDATE};
use phobos_txn::mvcc::{Status, globally_dead};
use phobos_types::PageId;
use std::time::Duration;

/// Session identity reserved for API-driven reclaim passes.
const RECLAIM_SESSION: u64 = u64::MAX - 1;
/// 0.2-K: session identity of the automatic maintenance worker.
pub(super) const MAINTENANCE_SESSION: u64 = u64::MAX - 2;
/// 0.2-K.4: session enabling the lazy-index capability at open.
pub(super) const CAPABILITY_SESSION: u64 = u64::MAX - 3;
/// Candidate pages a `CHECKPOINT` statement inspects.
pub const CHECKPOINT_RECLAIM_PAGES: usize = 64;
/// Upper bound on versions reclaimed by one pass.
const MAX_VERSIONS_PER_PASS: usize = 8192;

/// Pages to rewrite and versions to drop, for one table, in one publication.
pub struct ReclaimPlan {
    pub table: TableId,
    /// 0.2-K: per page, the dead slots (LIVE -> RETIRED, with expected
    /// versions), the horizon-proven RETIRED slots to free, and whether the
    /// page keeps versions a live snapshot may need.
    pub pages: Vec<LifecyclePage>,
    pub prepared: BTreeMap<PageId, phobos_storage::PreparedLifecycle>,
    /// Dead versions with their rows, for exact index-entry removal.
    pub dead: Vec<(RecordId, Row)>,
    /// 0.2-K.4: stale non-unique index entries to remove (sweeper), per
    /// index, re-checked inside serialized preparation.
    pub prune: Vec<(IndexId, Vec<(IndexKey, RecordId)>)>,
    /// 0.2-K.4: leave this plan's non-unique entries stale (requires the
    /// catalog capability; checked again in preparation).
    pub lazy: bool,
}

/// What one pass did.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct ReclaimReport {
    pub table: Option<TableId>,
    pub horizon: u64,
    pub pages_examined: usize,
    pub pages_compacted: usize,
    pub versions_reclaimed: usize,
    /// Versions found on candidate pages that a live snapshot may still need.
    pub versions_deferred: usize,
    pub index_entries_pruned: usize,
    pub index_pages_freed: usize,
    /// Candidate pages still recorded for the table after the pass.
    pub candidates_remaining: usize,
    /// Whether the post-restart header scan of the table is complete.
    pub bookkeeping_complete: bool,
    /// 0.2-K: RETIRED slots made FREE (phase 2).
    pub slots_freed: usize,
    /// 0.2-K: RETIRED slots kept because the horizon has not passed their
    /// retire publication yet (deferred by horizon).
    pub retired_deferred: usize,
    /// 0.2-K: trailing FREE directory entries removed.
    pub slots_trimmed: usize,
    /// 0.2-K: pages reset to an empty page.
    pub pages_reset: usize,
    /// 0.2-K: candidate pages skipped because no progress is possible before
    /// the horizon advances (deferred by horizon, not inspected).
    pub pages_deferred: usize,
    /// 0.2-K: wall time of the pass, microseconds.
    pub elapsed_us: u64,
}

/// 0.2-K Part K/N: cumulative reclamation counters of this database (since
/// open; in memory).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct ReclaimMetrics {
    pub passes: u64,
    /// Passes run by the automatic maintenance worker.
    pub automatic_passes: u64,
    pub pages_examined: u64,
    pub versions_reclaimed: u64,
    pub slots_freed: u64,
    pub slots_trimmed: u64,
    pub pages_reset: u64,
    pub index_entries_pruned: u64,
    /// Sum over passes of versions deferred because a snapshot may need them.
    pub versions_deferred: u64,
    /// Sum over passes of RETIRED slots deferred by the horizon.
    pub retired_deferred: u64,
    /// Sum over passes of candidate pages skipped as horizon-blocked.
    pub pages_deferred: u64,
    pub elapsed_us: u64,
    /// Current candidate pages over all tables.
    pub candidate_pages: u64,
    /// Current pages holding RETIRED slots that await the horizon.
    pub retired_pages: u64,
    /// Versions reclaimed by the last pass that reclaimed anything, divided by
    /// its wall time (versions per second).
    pub last_rate_per_second: u64,
    /// 0.2-K.4: non-unique index entries left stale by lazy reclaim.
    pub lazy_stale_created: u64,
    /// 0.2-K.4: eager exact index deletions performed by reclaim (UNIQUE
    /// indexes; every index when lazy pruning is off).
    pub eager_index_deletions: u64,
    /// 0.2-K.4 sweeper: entries visited, stale candidates found, stale
    /// entries removed (after the in-prepare re-check), completed cycles.
    pub sweep_entries_inspected: u64,
    pub sweep_stale_found: u64,
    pub sweep_stale_pruned: u64,
    pub sweep_cycles: u64,
    pub sweep_passes: u64,
}

#[derive(Default)]
pub(super) struct ReclaimState {
    /// Pages that may hold reclaimable versions or RETIRED slots, per table,
    /// with the generation of the publication that last recorded them. A
    /// pass forgets a page only if no publication re-recorded it since the
    /// pass looked at it (otherwise new dead versions written after the
    /// pass's snapshot would be lost from the candidate set).
    candidates: BTreeMap<TableId, BTreeMap<PageId, u64>>,
    note_generation: u64,
    /// Next page of the header rebuild scan; `None` once complete.
    cursor: BTreeMap<TableId, Option<PageId>>,
    /// 0.2-K Part D: per page, the highest publication sequence that RETIRED
    /// one of its still-RETIRED slots in this process. Absent: the page's
    /// RETIRED slots (if any) were retired before this process opened the
    /// database, i.e. before every statement that can exist now.
    retired_at: BTreeMap<TableId, BTreeMap<PageId, u64>>,
    /// 0.2-K Part K: no progress is possible on the page until the
    /// reclamation horizon exceeds this value.
    blocked_until: BTreeMap<TableId, BTreeMap<PageId, u64>>,
    /// 0.2-K Part K: fair rotation; last page served per table and the next
    /// table to serve.
    rotation: BTreeMap<TableId, PageId>,
    next_table: usize,
    /// 0.2-K Part K (automatic passes only): per candidate page, how many
    /// publications recorded new dead versions on it since a pass last
    /// visited it, and since when. Rewriting a page costs one page image
    /// whatever it reclaims, so the worker waits until a page is worth it
    /// (`WorthPolicy`); CHECKPOINT and `reclaim_once` ignore this.
    worth: BTreeMap<TableId, BTreeMap<PageId, (u32, Instant)>>,
    pub(super) metrics: ReclaimMetrics,
}

/// 0.2-K Part K: when a candidate page is worth an automatic pass (one
/// page-image rewrite): at least `min_versions` of its versions gained a
/// deleter since the last visit, or it has waited `max_age`, or it is unknown
/// to this process (post-open header scan). A page below the threshold holds
/// fewer than `min_versions` unreclaimed dead versions from that period, so
/// the slack the policy adds is bounded per page, independent of time.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct WorthPolicy {
    pub min_versions: u32,
    pub max_age: Duration,
}

impl ReclaimState {
    pub(super) fn candidates_by_table(&self) -> Vec<(TableId, usize)> {
        self.candidates
            .iter()
            .map(|(table, pages)| (*table, pages.len()))
            .collect()
    }
    pub(super) fn candidate_total(&self) -> usize {
        self.candidates.values().map(BTreeMap::len).sum()
    }
    pub(super) fn rebuild_pending(&self) -> bool {
        self.cursor.values().any(Option::is_some) || self.cursor.is_empty()
    }
    /// Whether `page` is worth a pass under `policy` (`None`: always).
    fn worthy(
        &self,
        table: TableId,
        page: PageId,
        policy: Option<WorthPolicy>,
        now: Instant,
    ) -> bool {
        let Some(policy) = policy else {
            return true;
        };
        self.worth
            .get(&table)
            .and_then(|pages| pages.get(&page))
            .is_none_or(|(notes, since)| {
                *notes >= policy.min_versions
                    || now.saturating_duration_since(*since) >= policy.max_age
            })
    }
    /// Candidate pages that could make progress at `horizon` (and, with a
    /// policy, are worth an automatic pass now).
    pub(super) fn eligible_total(&self, horizon: u64, policy: Option<WorthPolicy>) -> usize {
        let now = Instant::now();
        self.candidates
            .iter()
            .map(|(table, pages)| {
                let blocked = self.blocked_until.get(table);
                pages
                    .keys()
                    .filter(|page| {
                        blocked
                            .and_then(|map| map.get(page))
                            .is_none_or(|until| horizon > *until)
                            && self.worthy(*table, **page, policy, now)
                    })
                    .count()
            })
            .sum()
    }
}

/// Lowest horizon value strictly above which a deferred version could become
/// globally dead (`globally_dead` needs `deleter_sequence <= horizon`).
fn deferred_threshold(
    database: &MvccDatabase,
    deleter: u64,
    published: u64,
) -> Result<Option<u64>, PhobosError> {
    Ok(match database.sessions.lookup(deleter)? {
        Status::Committed { sequence } => Some(sequence.saturating_sub(1)),
        // Commits after `published` get a larger sequence.
        Status::InProgress => Some(published),
        Status::Aborted => None,
    })
}

#[cfg(test)]
/// Test fault: panic in the next pass of the database at this directory
/// (scoped by directory so concurrently running tests are unaffected).
pub(super) static PANIC_NEXT_PASS: std::sync::Mutex<Option<std::path::PathBuf>> =
    std::sync::Mutex::new(None);

impl MvccDatabase {
    /// 0.2-K.1: record a maintenance fault (first cause wins) and return the
    /// actionable error every later reclaim / CHECKPOINT reports. Lifecycle
    /// bookkeeping (`retired_at` marks) is never reset or guessed: while
    /// faulted no slot is freed in this process; a restart re-establishes it
    /// exactly (restart rule).
    pub(super) fn fault_maintenance(&self, cause: &str) -> PhobosError {
        let _ = self.maintenance_fault.set(cause.to_string());
        phobos_observability::event("maintenance.faulted", 1);
        self.maintenance_fault_error()
    }
    fn maintenance_fault_error(&self) -> PhobosError {
        let cause = self
            .maintenance_fault
            .get()
            .map_or("unknown", String::as_str);
        PhobosError::new(
            ErrorCode::Recovery,
            format!(
                "storage maintenance is faulted ({cause}); reclamation and CHECKPOINT are \
                 suspended to protect slot-lifecycle bookkeeping; reads and writes continue; \
                 restart the database to resume maintenance (no data was changed by the fault)"
            ),
        )
    }
    /// 0.2-K.1: `Err` with the actionable fault error once maintenance faulted.
    pub(super) fn check_maintenance(&self) -> Result<(), PhobosError> {
        match self.maintenance_fault.get() {
            Some(_) => Err(self.maintenance_fault_error()),
            None => Ok(()),
        }
    }
    /// 0.2-K.1: the maintenance fault, if any (diagnostics).
    pub fn maintenance_fault(&self) -> Option<String> {
        self.maintenance_fault.get().cloned()
    }

    /// C1: remember pages whose versions gained a deleter in a publication.
    pub(super) fn note_candidate_pages(&self, pages: &BTreeMap<TableId, BTreeMap<PageId, u32>>) {
        if pages.is_empty() {
            return;
        }
        if let Ok(mut state) = self.reclaim_state.lock() {
            state.note_generation += 1;
            let generation = state.note_generation;
            let now = Instant::now();
            for (table, ids) in pages {
                let set = state.candidates.entry(*table).or_default();
                for id in ids.keys() {
                    set.insert(*id, generation);
                }
                let worth = state.worth.entry(*table).or_default();
                for (id, versions) in ids {
                    let entry = worth.entry(*id).or_insert((0, now));
                    entry.0 = entry.0.saturating_add(*versions);
                }
                // New dead versions may be reclaimable as soon as the
                // horizon passes their deleter: drop stale blocks.
                if let Some(blocked) = state.blocked_until.get_mut(table) {
                    for id in ids.keys() {
                        blocked.remove(id);
                    }
                }
            }
        }
        self.maintenance.notify_publication();
    }
    /// Candidate pages currently recorded for `table` (tests/diagnostics).
    pub fn reclaim_candidates(&self, table: TableId) -> usize {
        self.reclaim_state
            .lock()
            .map(|state| state.candidates.get(&table).map_or(0, BTreeMap::len))
            .unwrap_or(0)
    }
    /// 0.2-K Part N: cumulative reclamation counters and current backlog.
    pub fn reclaim_metrics(&self) -> ReclaimMetrics {
        self.reclaim_state
            .lock()
            .map(|state| {
                let mut metrics = state.metrics;
                metrics.sweep_stale_pruned =
                    super::lazy_index::PRUNED.load(std::sync::atomic::Ordering::Relaxed);
                metrics.candidate_pages = state.candidate_total() as u64;
                metrics.retired_pages =
                    state.retired_at.values().map(BTreeMap::len).sum::<usize>() as u64;
                metrics
            })
            .unwrap_or_default()
    }

    /// 0.2-K.4: publish a sweep-only reclaim plan (stale non-unique index
    /// entries, re-checked in serialized preparation).
    fn commit_sweep(
        &self,
        session: &Session,
        table: TableId,
        prune: Vec<(IndexId, Vec<(IndexKey, RecordId)>)>,
        horizon: u64,
        started: Instant,
    ) -> Result<ReclaimReport, PhobosError> {
        let stable = session.ensure_transaction_id()?;
        let mut writes = SessionWrites::new(stable, 64 * 1024 * 1024)?;
        writes.set_reclaim(ReclaimPlan {
            table,
            prepared: BTreeMap::new(),
            pages: Vec::new(),
            dead: Vec::new(),
            prune,
            lazy: false,
        });
        let span = phobos_observability::span("mvcc.lazy_sweep_commit");
        self.commit(session, writes)?;
        drop(span);
        let elapsed_us = started.elapsed().as_micros() as u64;
        if let Ok(mut state) = self.reclaim_state.lock() {
            state.metrics.passes += 1;
            state.metrics.sweep_passes += 1;
            state.metrics.elapsed_us += elapsed_us;
        }
        Ok(ReclaimReport {
            table: Some(table),
            horizon,
            bookkeeping_complete: true,
            elapsed_us,
            ..ReclaimReport::default()
        })
    }

    /// One bounded reclaim pass over at most `limit` candidate pages.
    pub fn reclaim_once(&self, limit: usize) -> Result<ReclaimReport, PhobosError> {
        let _maintenance = phobos_error::cancellation::suspend();
        let session = self.connect(RECLAIM_SESSION)?;
        let result = self.reclaim_with_session(&session, limit, None);
        drop(session);
        if result.is_ok() {
            self.freeze_once(limit)?;
        }
        result
    }

    /// `policy`: `Some` for automatic passes (only pages worth a rewrite),
    /// `None` for CHECKPOINT and `reclaim_once` (every eligible page).
    pub(super) fn reclaim_with_session(
        &self,
        session: &Session,
        limit: usize,
        policy: Option<WorthPolicy>,
    ) -> Result<ReclaimReport, PhobosError> {
        self.check_maintenance()?;
        // 0.2-K.4: enable LAZY_INDEX_PRUNING_V1 (a durable schema
        // publication) before the first pass that could leave a non-unique
        // index entry stale; until then the database stays old-compatible.
        // Automatic passes never start a schema transaction (it would make
        // concurrent user statements retry); explicit passes may.
        if policy.is_none()
            && self.lazy_allowed.load(std::sync::atomic::Ordering::Acquire)
            && !self.lazy_index_enabled()?
            && self.has_lazy_candidates()?
            && self
                .reclaim_state
                .lock()
                .is_ok_and(|state| state.candidate_total() > 0)
        {
            self.try_enable_with(session)?;
        }
        let lazy_enabled = self.lazy_index_active()?;
        // Stale entries may exist whenever the capability is on (also while
        // lazy pruning is currently forbidden): keep sweeping them.
        let sweep_enabled = self.lazy_index_enabled()?
            && self
                .sweep_allowed
                .load(std::sync::atomic::Ordering::Acquire);
        let _serial = match self.reclaim_lock.lock() {
            Ok(guard) => guard,
            Err(_) => {
                return Err(self.fault_maintenance(
                    "a previous reclaim pass panicked (reclaim serialization poisoned)",
                ));
            }
        };
        #[cfg(test)]
        if PANIC_NEXT_PASS.lock().is_ok_and(|mut target| {
            target.as_deref() == Some(self.data_dir.as_path()) && target.take().is_some()
        }) {
            panic!("0.2-K.1 test: injected reclaim panic");
        }
        let _cost = phobos_observability::span("mvcc.reclaim_pass");
        let started = Instant::now();
        let limit = limit.max(1);
        let tables = self
            .lock_database()?
            .catalog
            .tables()
            .map(|table| table.id)
            .collect::<Vec<_>>();
        // The horizon is observed before the snapshot is pinned; it only
        // moves forward, so every snapshot alive now or created later has a
        // sequence at or above it. `published` bounds the sequence of any
        // commit that has not happened yet (deferred-threshold bookkeeping).
        let (published, horizon, _) = self.sessions.publication_state()?;
        // 0.2-K: no transaction identity (and no status record) unless the
        // pass actually publishes something.
        session.begin_deferred()?;
        let view_span = phobos_observability::span("mvcc.reclaim_view");
        let mut view = self.statement(session, None)?;
        drop(view_span);
        // 0.2-K Part K: fair rotation. Tables are served round-robin
        // starting after the last table served; within a table, candidate
        // pages are taken after the last page served (wrapping), skipping
        // pages that cannot make progress before the horizon advances.
        let mut scanned = 0;
        let mut chosen = None;
        let mut skipped_blocked = 0;
        // Generation at which each candidate of the chosen table was seen.
        let mut seen: BTreeMap<PageId, u64> = BTreeMap::new();
        {
            let start = self
                .reclaim_state
                .lock()
                .map_err(|_| self.fault_maintenance("reclaim bookkeeping poisoned"))?
                .next_table;
            let order = (0..tables.len())
                .map(|offset| (start + offset) % tables.len().max(1))
                .collect::<Vec<_>>();
            for position in order {
                let table = tables[position];
                let (mut pages, mut cursor) = {
                    let mut state = self
                        .reclaim_state
                        .lock()
                        .map_err(|_| self.fault_maintenance("reclaim bookkeeping poisoned"))?;
                    for table in &tables {
                        state.cursor.entry(*table).or_insert(Some(0));
                    }
                    let after = state.rotation.get(&table).copied();
                    let blocked = state.blocked_until.get(&table).cloned().unwrap_or_default();
                    let set = state.candidates.get(&table).cloned().unwrap_or_default();
                    let mut pages = Vec::new();
                    let rotated = match after {
                        Some(after) => set
                            .range(after + 1..)
                            .chain(set.range(..=after))
                            .map(|(page, _)| *page)
                            .collect::<Vec<_>>(),
                        None => set.keys().copied().collect(),
                    };
                    seen = set;
                    let now = Instant::now();
                    for page in rotated {
                        if pages.len() >= limit {
                            break;
                        }
                        if blocked.get(&page).is_some_and(|until| horizon <= *until) {
                            skipped_blocked += 1;
                            continue;
                        }
                        if !state.worthy(table, page, policy, now) {
                            continue;
                        }
                        pages.push(page);
                    }
                    (pages, state.cursor.get(&table).copied().flatten())
                };
                if pages.is_empty() {
                    // Header rebuild scan (fresh open): flagged pages become
                    // candidates. Bounded by `limit` pages per call.
                    while let Some(page) = cursor {
                        if scanned >= limit {
                            break;
                        }
                        scanned += 1;
                        match view.database.heap_mut(table)?.page_census(page)? {
                            None => cursor = None,
                            Some((flags, overflow, census, _)) => {
                                // 0.2-K: RETIRED slots found by the scan were
                                // retired before this process opened the
                                // database (restart rule), so they are
                                // freeable; this also upgrades pre-0.2-K
                                // tombstones on pages whose candidate flag
                                // an older release had cleared.
                                if flags & PAGE_FLAG_RECLAIM_CANDIDATE != 0
                                    || (!overflow && census.retired > 0)
                                {
                                    pages.push(page);
                                }
                                cursor = Some(page + 1);
                            }
                        }
                    }
                    if let Ok(mut state) = self.reclaim_state.lock() {
                        state.cursor.insert(table, cursor);
                        let generation = state.note_generation;
                        let set = state.candidates.entry(table).or_default();
                        for page in &pages {
                            let recorded = *set.entry(*page).or_insert(generation);
                            seen.insert(*page, recorded);
                        }
                    }
                    if pages.is_empty() && (cursor.is_some() || scanned >= limit) {
                        // Scan budget exhausted for this call.
                        chosen = Some((table, position, pages));
                        break;
                    }
                }
                if !pages.is_empty() {
                    chosen = Some((table, position, pages));
                    break;
                }
                if scanned >= limit {
                    chosen = Some((table, position, pages));
                    break;
                }
            }
        }
        let Some((table, position, pages)) = chosen else {
            // 0.2-K.4: no heap work; a stale-index sweep slice may be due.
            let sweep = if sweep_enabled && self.sweep_pending() {
                self.plan_index_sweep(&mut view, None)?
            } else {
                None
            };
            drop(view);
            if let Some((table, prune)) = sweep {
                return self.commit_sweep(session, table, prune, horizon, started);
            }
            session.rollback()?;
            let elapsed_us = started.elapsed().as_micros() as u64;
            if let Ok(mut state) = self.reclaim_state.lock() {
                state.metrics.passes += 1;
                state.metrics.pages_deferred += skipped_blocked as u64;
                state.metrics.elapsed_us += elapsed_us;
            }
            return Ok(ReclaimReport {
                horizon,
                bookkeeping_complete: true,
                pages_deferred: skipped_blocked,
                elapsed_us,
                ..ReclaimReport::default()
            });
        };
        let mut report = ReclaimReport {
            table: Some(table),
            horizon,
            pages_deferred: skipped_blocked,
            ..ReclaimReport::default()
        };
        let _plan_span = phobos_observability::span("mvcc.reclaim_plan_and_commit");
        let mut plan = ReclaimPlan {
            table,
            prepared: BTreeMap::new(),
            pages: Vec::new(),
            dead: Vec::new(),
            prune: Vec::new(),
            lazy: false,
        };
        let retired_at = self
            .reclaim_state
            .lock()
            .map_err(|_| self.fault_maintenance("reclaim bookkeeping poisoned"))?
            .retired_at
            .get(&table)
            .cloned()
            .unwrap_or_default();
        let mut clean = Vec::new();
        let mut blocked = Vec::new();
        let mut last_page = None;
        for page in pages {
            if plan.dead.len() >= MAX_VERSIONS_PER_PASS {
                break;
            }
            last_page = Some(page);
            report.pages_examined += 1;
            // Rows (and overflow chains) are decoded only for the versions
            // that are reclaimed (their exact index entries are needed).
            let sessions = self.sessions.clone();
            let Some((lifecycle, versions)) = view
                .database
                .heap_mut(table)?
                .page_lifecycle_selective(page, |tuple| {
                    globally_dead(horizon, tuple.visibility, &mut sessions.as_ref())
                })?
            else {
                clean.push(page);
                continue;
            };
            if lifecycle.overflow {
                // Overflow pages are recycled by the overflow writer only.
                clean.push(page);
                continue;
            }
            let mut dead = Vec::new();
            let mut deferred = 0;
            let mut threshold: Option<u64> = None;
            for (slot, tuple, row) in versions {
                let rid = RecordId {
                    page_id: page,
                    slot_id: slot,
                };
                if let Some(row) = row {
                    dead.push((slot, tuple));
                    plan.dead.push((rid, row));
                } else if let Some(deleter) = tuple.visibility.deleter {
                    deferred += 1;
                    if let Some(at) = deferred_threshold(self, deleter, published)? {
                        threshold = Some(threshold.map_or(at, |old| old.min(at)));
                    }
                }
            }
            // Phase 2 gate (Part C/D): the page's RETIRED slots were all
            // retired by publications <= `retired`; every statement that may
            // hold a RID of their former occupants pinned a sequence below
            // that publication, so `horizon > retired` proves all of them
            // have finished.
            let mut free = Vec::new();
            if !lifecycle.retired.is_empty() {
                let retired = retired_at.get(&page).copied().unwrap_or(0);
                if horizon > retired {
                    free = lifecycle.retired;
                } else {
                    report.retired_deferred += lifecycle.retired.len();
                    threshold = Some(threshold.map_or(retired, |old| old.min(retired)));
                }
            }
            report.versions_deferred += deferred;
            if dead.is_empty() && free.is_empty() {
                match threshold {
                    None => clean.push(page),
                    Some(until) => blocked.push((page, until)),
                }
                continue;
            }
            plan.pages.push(LifecyclePage {
                page,
                dead,
                free,
                keep_candidate: deferred > 0,
            });
        }
        plan.lazy = lazy_enabled;
        {
            let _prepare = phobos_observability::span("reclaim.prepare_outside_order");
            let _profile = phobos_observability::lifecycle_profile();
            let heap = view.database.heap_mut(table)?;
            for page in &plan.pages {
                if let Some(delta) = heap.prepare_lifecycle_delta(page)? {
                    plan.prepared.insert(page.page, delta);
                }
            }
        }
        if sweep_enabled && self.sweep_pending() {
            if let Some((_, prune)) = self.plan_index_sweep(&mut view, Some(table))? {
                plan.prune = prune;
            }
        }
        drop(view);
        let swept = !plan.prune.is_empty();
        report.pages_compacted = plan.pages.len();
        report.versions_reclaimed = plan.dead.len();
        report.slots_freed = plan.pages.iter().map(|page| page.free.len()).sum();
        let committed = if plan.pages.is_empty() && plan.prune.is_empty() {
            session.rollback()?;
            None
        } else {
            let (index_count, lazy_count) = {
                let database = self.lock_database()?;
                let all = database.catalog.indexes_for_table(table).count();
                let lazy = if lazy_enabled {
                    database
                        .catalog
                        .indexes_for_table(table)
                        .filter(|index| !index.unique)
                        .count()
                } else {
                    0
                };
                (all - lazy, lazy)
            };
            let free_span = phobos_observability::span("mvcc.reclaim_free_list");
            let free_before = self.free_index_pages(table)?;
            drop(free_span);
            let touched = plan
                .pages
                .iter()
                .map(|page| (page.page, page.dead.len(), page.keep_candidate))
                .collect::<Vec<_>>();
            // Until the exact retire publication is known, the pages this
            // plan retires slots on are recorded as retired "now or later"
            // (u64::MAX: never freeable). A failure restores the previous
            // marks only if nothing was published (the database is fenced
            // otherwise and runs no further pass).
            let previous_marks = {
                let mut state = self
                    .reclaim_state
                    .lock()
                    .map_err(|_| self.fault_maintenance("reclaim bookkeeping poisoned"))?;
                let marks = state.retired_at.entry(table).or_default();
                touched
                    .iter()
                    .filter(|(_, retired, _)| *retired > 0)
                    .map(|(page, _, _)| (*page, marks.insert(*page, u64::MAX)))
                    .collect::<Vec<_>>()
            };
            let stable = session.ensure_transaction_id()?;
            let mut writes = SessionWrites::new(stable, 64 * 1024 * 1024)?;
            writes.set_reclaim(plan);
            let commit_span = phobos_observability::span("mvcc.reclaim_commit");
            let committed = self.commit(session, writes);
            drop(commit_span);
            if let Err(error) = committed {
                if !self.fenced.load(std::sync::atomic::Ordering::Acquire) {
                    if let Ok(mut state) = self.reclaim_state.lock() {
                        let marks = state.retired_at.entry(table).or_default();
                        for (page, previous) in previous_marks {
                            match previous {
                                Some(previous) => marks.insert(page, previous),
                                None => marks.remove(&page),
                            };
                        }
                    }
                }
                return Err(error);
            }
            let retired_publication = self
                .last_reclaim_publication
                .load(std::sync::atomic::Ordering::Acquire);
            report.index_entries_pruned = report.versions_reclaimed * index_count;
            let stale = (report.versions_reclaimed * lazy_count) as u64;
            self.note_lazy_stale(stale);
            if let Ok(mut state) = self.reclaim_state.lock() {
                state.metrics.lazy_stale_created += stale;
                state.metrics.eager_index_deletions += report.index_entries_pruned as u64;
                state.metrics.sweep_passes += u64::from(swept);
            }
            report.index_pages_freed = self.free_index_pages(table)?.saturating_sub(free_before);
            if report.versions_reclaimed > 0 {
                phobos_observability::event(
                    "mvcc.versions_reclaimed",
                    report.versions_reclaimed as u64,
                );
            }
            let outcome = self
                .last_reclaim_outcome
                .lock()
                .map(|outcome| *outcome)
                .unwrap_or_default();
            report.slots_trimmed = outcome.trimmed;
            report.pages_reset = outcome.reset;
            Some((touched, retired_publication))
        };
        report.elapsed_us = started.elapsed().as_micros() as u64;
        let mut state = self.reclaim_state.lock().map_err(|_| {
            self.fault_maintenance("reclaim bookkeeping poisoned after publication")
        })?;
        {
            state.next_table = position + 1;
            if let Some(page) = last_page {
                state.rotation.insert(table, page);
            }
            // Only pages no publication re-recorded since the pass saw them.
            let unchanged = |state: &ReclaimState, page: &PageId| {
                state
                    .candidates
                    .get(&table)
                    .and_then(|set| set.get(page))
                    .is_none_or(|generation| seen.get(page) == Some(generation))
            };
            let clean = clean
                .into_iter()
                .filter(|page| unchanged(&state, page))
                .collect::<Vec<_>>();
            let blocked = blocked
                .into_iter()
                .filter(|(page, _)| unchanged(&state, page))
                .collect::<Vec<_>>();
            {
                let set = state.candidates.entry(table).or_default();
                for page in &clean {
                    set.remove(page);
                }
            }
            let retired_map = state.retired_at.entry(table).or_default();
            for page in &clean {
                retired_map.remove(page);
            }
            {
                // Horizon-blocked pages keep their accumulated worth: once the
                // horizon passes (e.g. a long snapshot ends) they are taken
                // at once. Pages a committed pass rewrote start a new worth
                // period below.
                let worth = state.worth.entry(table).or_default();
                for page in &clean {
                    worth.remove(page);
                }
            }
            let block_map = state.blocked_until.entry(table).or_default();
            for page in &clean {
                block_map.remove(page);
            }
            for (page, until) in &blocked {
                block_map.insert(*page, *until);
            }
            if let Some((touched, retired_publication)) = &committed {
                for (page, retired, keep) in touched {
                    let retired_now = &(*retired > 0);
                    let retired_map = state.retired_at.entry(table).or_default();
                    if *retired_now {
                        // The page's RETIRED slots are now those retired by
                        // this publication plus, when the horizon blocked
                        // them, older ones: the high-water mark is this
                        // publication (it exceeds every earlier one).
                        retired_map.insert(*page, *retired_publication);
                    } else {
                        retired_map.remove(page);
                    }
                    let block_map = state.blocked_until.entry(table).or_default();
                    if *retired_now {
                        block_map.insert(*page, *retired_publication);
                    } else {
                        block_map.remove(page);
                    }
                    if !*retired_now && !*keep && unchanged(&state, page) {
                        state.candidates.entry(table).or_default().remove(page);
                        state.worth.entry(table).or_default().remove(page);
                    } else {
                        // The slots retired now count toward the page's next
                        // (freeing) visit, which the horizon gates anyway.
                        let retired = u32::try_from(*retired).unwrap_or(u32::MAX);
                        state
                            .worth
                            .entry(table)
                            .or_default()
                            .insert(*page, (retired, Instant::now()));
                    }
                }
            }
            report.candidates_remaining = state.candidates.get(&table).map_or(0, BTreeMap::len);
            report.bookkeeping_complete = tables
                .iter()
                .all(|table| state.cursor.get(table).is_some_and(Option::is_none));
            let metrics = &mut state.metrics;
            metrics.passes += 1;
            metrics.pages_examined += report.pages_examined as u64;
            metrics.versions_reclaimed += report.versions_reclaimed as u64;
            metrics.slots_freed += report.slots_freed as u64;
            metrics.slots_trimmed += report.slots_trimmed as u64;
            metrics.pages_reset += report.pages_reset as u64;
            metrics.index_entries_pruned += report.index_entries_pruned as u64;
            metrics.versions_deferred += report.versions_deferred as u64;
            metrics.retired_deferred += report.retired_deferred as u64;
            metrics.pages_deferred += report.pages_deferred as u64;
            metrics.elapsed_us += report.elapsed_us;
            if report.versions_reclaimed > 0 && report.elapsed_us > 0 {
                metrics.last_rate_per_second =
                    report.versions_reclaimed as u64 * 1_000_000 / report.elapsed_us;
            }
        }
        Ok(report)
    }

    /// Pages on the free lists of the table's indexes (tests/diagnostics).
    pub fn free_index_pages(&self, table: TableId) -> Result<usize, PhobosError> {
        let mut database = self.lock_database()?;
        let ids = database
            .catalog
            .indexes_for_table(table)
            .map(|index| index.id)
            .collect::<Vec<_>>();
        let mut total = 0;
        for id in ids {
            if let Some(tree) = database.indexes.get_mut(&id) {
                total += tree.free_list_len()?;
            }
        }
        Ok(total)
    }
}
