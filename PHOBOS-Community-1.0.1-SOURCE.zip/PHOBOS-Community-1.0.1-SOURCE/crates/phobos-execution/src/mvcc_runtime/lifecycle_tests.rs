//! 0.2-K Storage Lifecycle V1 through the SQL runtime: horizon-gated slot
//! reuse, snapshot pins, churn steady state, index/UNIQUE correctness, stale
//! RID re-validation, bulk/COPY, CHECKPOINT and duplicate-heavy pruning.
use super::reclaim_tests::publish_marker;
use super::*;
use phobos_storage::SlotState;
use std::collections::BTreeSet;
use tests::fixture;

fn table_id(db: &MvccDatabase, name: &str) -> TableId {
    db.lock_database()
        .unwrap()
        .catalog
        .tables()
        .find(|table| table.name == name)
        .expect("table")
        .id
}

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows.first().map(|row| &row.values[0]) {
            Some(Value::Int64(n)) => *n,
            Some(Value::Null) | None => 0,
            Some(other) => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}

fn rows(db: &MvccDatabase, session: u64, sql: &str) -> Vec<Row> {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => rows,
        other => panic!("rows {other:?}"),
    }
}

fn affected(result: QueryResult) -> u64 {
    match result {
        QueryResult::Command { rows_affected, .. } => rows_affected,
        other => panic!("command {other:?}"),
    }
}

/// `(rid, id)` of every occupied slot, and every RETIRED / FREE RID.
struct Physical {
    occupied: Vec<(RecordId, i64)>,
    retired: BTreeSet<RecordId>,
    free: BTreeSet<RecordId>,
    pages: u64,
}

fn physical(db: &MvccDatabase, table: TableId) -> Physical {
    let session = db.connect(901).unwrap();
    let mut view = db.statement(&session, None).unwrap();
    let heap = view.database.heap_mut(table).unwrap();
    let mut out = Physical {
        occupied: Vec::new(),
        retired: BTreeSet::new(),
        free: BTreeSet::new(),
        pages: 0,
    };
    let mut page = 0;
    while let Some(lifecycle) = heap.page_lifecycle(page).unwrap() {
        out.pages += 1;
        if !lifecycle.overflow {
            for (slot, _, row) in &lifecycle.versions {
                let Value::Int64(id) = row.values[0] else {
                    panic!("id")
                };
                out.occupied.push((
                    RecordId {
                        page_id: page,
                        slot_id: *slot,
                    },
                    id,
                ));
            }
            for slot in &lifecycle.retired {
                out.retired.insert(RecordId {
                    page_id: page,
                    slot_id: *slot,
                });
            }
            for slot in 0..lifecycle.census.slots {
                let rid = RecordId {
                    page_id: page,
                    slot_id: slot,
                };
                if heap.slot_state(rid).unwrap() == Some(SlotState::Free) {
                    out.free.insert(rid);
                }
            }
        }
        page += 1;
    }
    drop(view);
    drop(session);
    db.disconnect(901);
    out
}

/// Reclaim until a pass neither retires nor frees anything, publishing a
/// marker between passes so the horizon can pass each retire publication.
fn drain(db: &MvccDatabase) -> (usize, usize) {
    let (mut retired, mut freed) = (0, 0);
    for _ in 0..10_000 {
        let report = db.reclaim_once(256).unwrap();
        retired += report.versions_reclaimed;
        freed += report.slots_freed;
        if report.versions_reclaimed == 0 && report.slots_freed == 0 && report.bookkeeping_complete
        {
            if report.retired_deferred == 0 && report.pages_deferred == 0 {
                break;
            }
            publish_marker(db);
            let again = db.reclaim_once(256).unwrap();
            retired += again.versions_reclaimed;
            freed += again.slots_freed;
            if again.versions_reclaimed == 0 && again.slots_freed == 0 {
                break;
            }
        } else {
            publish_marker(db);
        }
    }
    // 0.2-K.4: lazy pruning leaves non-unique entries stale until the
    // sweeper's next cycle; force one complete cycle so callers observe the
    // exact (fully pruned) index state, as with eager pruning.
    db.note_lazy_stale(1 << 40);
    for _ in 0..1_000 {
        if !db.sweep_pending() {
            break;
        }
        db.reclaim_once(256).unwrap();
    }
    (retired, freed)
}

fn setup(db: &MvccDatabase, rows: i64, pad: usize) {
    db.execute(
        1,
        "CREATE TABLE k (id BIGINT NOT NULL, kv BIGINT, u BIGINT, v BIGINT, pad TEXT)",
    )
    .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX k_id ON k(id)").unwrap();
    db.execute(1, "CREATE INDEX k_kv ON k(kv)").unwrap();
    db.execute(1, "CREATE UNIQUE INDEX k_u ON k(u)").unwrap();
    insert_range(db, 1, rows, pad, 0);
    // The marker table exists before any test pins a snapshot (DDL waits
    // for pins).
    publish_marker(db);
}

fn insert_range(db: &MvccDatabase, from: i64, to: i64, pad: usize, generation: i64) {
    let mut id = from;
    while id <= to {
        let end = (id + 199).min(to);
        let values = (id..=end)
            .map(|id| {
                format!(
                    "({id},{},{},{id},'{}')",
                    id % 7,
                    id + generation * 10_000_000,
                    "p".repeat(pad)
                )
            })
            .collect::<Vec<_>>()
            .join(",");
        db.execute(1, &format!("INSERT INTO k VALUES {values}"))
            .unwrap();
        id = end + 1;
    }
}

fn index_entries(db: &MvccDatabase, table: TableId) -> Vec<usize> {
    let mut database = db.lock_database().unwrap();
    let ids = database
        .catalog
        .indexes_for_table(table)
        .map(|index| index.id)
        .collect::<Vec<_>>();
    ids.into_iter()
        .map(|id| {
            database
                .indexes
                .get_mut(&id)
                .unwrap()
                .validate()
                .unwrap()
                .entries
        })
        .collect()
}

/// Part O 1, 2, 3, 5: RETIRED is never reused; once the horizon passes the
/// retire publication the slot becomes FREE and the next inserts reuse it.
#[test]
fn k_retired_slots_become_free_after_the_horizon_and_are_reused() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    // 0.2-K.4: asserts exact index entry counts right after explicit passes
    // (eager pruning path); lazy pruning is covered by `lazy_index_tests`.
    db.set_lazy_index_pruning(false);
    setup(&db, 60, 20);
    let table = table_id(&db, "k");
    assert_eq!(
        affected(db.execute(1, "DELETE FROM k WHERE id<=10").unwrap()),
        10
    );
    let deleted = physical(&db, table)
        .occupied
        .iter()
        .filter(|(_, id)| *id <= 10)
        .map(|(rid, _)| *rid)
        .collect::<BTreeSet<_>>();
    let first = db.reclaim_once(256).unwrap();
    assert_eq!(first.versions_reclaimed, 10, "{first:?}");
    assert_eq!(physical(&db, table).retired, deleted, "phase 1: RETIRED");
    // No publication since the retire: horizon == retire publication.
    let blocked = db.reclaim_once(256).unwrap();
    assert_eq!(
        blocked.slots_freed, 0,
        "never freed before the horizon passes"
    );
    // Inserts now must not land on RETIRED slots.
    insert_range(&db, 1001, 1005, 20, 0);
    let state = physical(&db, table);
    assert!(
        state
            .occupied
            .iter()
            .filter(|(_, id)| *id > 1000)
            .all(|(rid, _)| !deleted.contains(rid)),
        "RETIRED slot reused prematurely"
    );
    assert_eq!(state.retired, deleted);
    // That insert was a publication: the horizon has passed the retire.
    let second = db.reclaim_once(256).unwrap();
    assert_eq!(second.slots_freed, 10, "{second:?}");
    let state = physical(&db, table);
    assert!(state.retired.is_empty());
    // New rows reuse the freed slots (no new page, no directory growth).
    let pages = state.pages;
    insert_range(&db, 2001, 2010, 20, 0);
    let state = physical(&db, table);
    let reused = state
        .occupied
        .iter()
        .filter(|(_, id)| *id > 2000)
        .filter(|(rid, _)| deleted.contains(rid))
        .count();
    assert_eq!(reused, 10, "every freed slot reused");
    assert_eq!(state.pages, pages);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 65);
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM k WHERE id>2000"),
        10
    );
    let entries = index_entries(&db, table);
    assert!(entries.iter().all(|entries| *entries == 65), "{entries:?}");
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 4, 5: a live snapshot that predates the retire publication keeps
/// the slots RETIRED (deferred by horizon) and still reads its own snapshot;
/// releasing it allows FREE.
#[test]
fn k_old_snapshot_pins_retired_slots_until_released() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 200, 10);
    let table = table_id(&db, "k");
    db.execute(1, "UPDATE k SET v=v+1000 WHERE id<=50").unwrap();
    // The pin is taken after the update committed: the superseded versions
    // are globally dead for it, so they retire; but it predates the retire.
    let pinned = db.connect(60).unwrap();
    let mut old = db.statement(&pinned, None).unwrap();
    let retire = db.reclaim_once(256).unwrap();
    assert_eq!(retire.versions_reclaimed, 50, "{retire:?}");
    publish_marker(&db);
    let blocked = db.reclaim_once(256).unwrap();
    assert_eq!(blocked.slots_freed, 0, "{blocked:?}");
    assert!(
        blocked.retired_deferred + blocked.pages_deferred > 0,
        "deferred by horizon: {blocked:?}"
    );
    assert_eq!(physical(&db, table).retired.len(), 50);
    // The old statement still reads exactly its snapshot, through the
    // index and through a scan.
    let QueryResult::Rows { rows, .. } = old.execute("SELECT v FROM k WHERE id=7", &[]).unwrap()
    else {
        panic!()
    };
    assert_eq!(rows, vec![Row::new(vec![Value::Int64(1007)])]);
    let QueryResult::Rows { rows, .. } = old
        .execute("SELECT COUNT(*) AS n FROM k WHERE v>=1000", &[])
        .unwrap()
    else {
        panic!()
    };
    assert_eq!(rows, vec![Row::new(vec![Value::Int64(50)])]);
    drop(old);
    drop(pinned);
    db.disconnect(60);
    publish_marker(&db);
    let freeing = db.reclaim_once(256).unwrap();
    assert_eq!(freeing.slots_freed, 50, "{freeing:?}");
    assert!(physical(&db, table).retired.is_empty());
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 9 (+P hot table): a 100-row table updated 20,000 times reaches a
/// bounded steady state: page count and slot directory stop growing.
#[test]
fn k_hot_update_churn_reaches_a_bounded_steady_state() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 100, 40);
    let table = table_id(&db, "k");
    let mut history = Vec::new();
    for round in 1..=200 {
        db.execute(1, "UPDATE k SET v=v+1 WHERE id>=1 AND id<=100")
            .unwrap();
        if round % 5 == 0 {
            drain(&db);
        }
        if round % 20 == 0 {
            let state = physical(&db, table);
            history.push((
                state.pages,
                state.occupied.len() + state.retired.len() + state.free.len(),
            ));
        }
    }
    drain(&db);
    let state = physical(&db, table);
    // Before 0.2-K: 2 -> ~24 pages after 40K updates (slot leak). Now the
    // whole history fits in a handful of pages and the directory is bounded.
    let (late_max_pages, late_max_slots) = history[history.len() / 2..]
        .iter()
        .fold((0, 0), |(p, s), (pages, slots)| {
            ((*pages).max(p), (*slots).max(s))
        });
    // Bounded by the reclaim cadence (5 rounds = 500 versions between
    // drains), not by history.
    assert!(late_max_pages <= 12, "{history:?}");
    assert!(late_max_slots <= 1000, "{history:?}");
    assert_eq!(
        history.last().unwrap().0,
        history[history.len() / 2].0,
        "{history:?}"
    );
    assert_eq!(state.occupied.len(), 100);
    assert_eq!(
        scalar(&db, 2, "SELECT SUM(v) AS s FROM k"),
        (1..=100).sum::<i64>() + 200 * 100
    );
    let entries = index_entries(&db, table);
    assert!(entries.iter().all(|entries| *entries == 100), "{entries:?}");
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 10: constant-cardinality DELETE+INSERT generations stay bounded.
#[test]
fn k_delete_insert_generations_stay_bounded() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 2000, 30);
    let table = table_id(&db, "k");
    let initial = physical(&db, table).pages;
    let mut low = 1i64;
    let mut next = 2001i64;
    let mut peak = 0;
    for generation in 1..=60 {
        db.execute(
            1,
            &format!("DELETE FROM k WHERE id>={low} AND id<{}", low + 200),
        )
        .unwrap();
        insert_range(&db, next, next + 199, 30, generation);
        low += 200;
        next += 200;
        drain(&db);
        if generation > 20 {
            peak = peak.max(physical(&db, table).pages);
        }
    }
    assert!(peak <= initial + 3, "initial {initial} peak {peak}");
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 2000);
    let entries = index_entries(&db, table);
    assert!(
        entries.iter().all(|entries| *entries == 2000),
        "{entries:?}"
    );
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 11, 12, 24: indexed and UNIQUE churn with three indexes keeps
/// every index exact and UNIQUE enforcement correct across slot reuse.
#[test]
fn k_indexed_and_unique_churn_keeps_indexes_and_uniqueness_exact() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 300, 10);
    let table = table_id(&db, "k");
    for round in 1..=40i64 {
        db.execute(1, "UPDATE k SET kv=kv+1 WHERE id<=150").unwrap();
        db.execute(
            1,
            &format!("UPDATE k SET u=id+{} WHERE id>150", round * 1_000_000),
        )
        .unwrap();
        // Same-key delete and re-insert of a UNIQUE value.
        db.execute(1, "DELETE FROM k WHERE id=300").unwrap();
        db.execute(
            1,
            &format!(
                "INSERT INTO k VALUES (300,1,{},0,'x')",
                300 + round * 1_000_000
            ),
        )
        .unwrap();
        if round % 4 == 0 {
            drain(&db);
        }
    }
    drain(&db);
    assert!(physical(&db, table).free.len() + physical(&db, table).occupied.len() > 300);
    let entries = index_entries(&db, table);
    assert!(entries.iter().all(|entries| *entries == 300), "{entries:?}");
    // UNIQUE: an existing value conflicts; a freed (old) value does not.
    let current = scalar(&db, 2, "SELECT u FROM k WHERE id=200");
    let error = db
        .execute(1, &format!("INSERT INTO k VALUES (9001,0,{current},0,'d')"))
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ConstraintViolation);
    db.disconnect(1);
    db.execute(
        1,
        "INSERT INTO k VALUES (9002,0,1000200,0,'old u of round 1')",
    )
    .unwrap();
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM k WHERE kv>=40"),
        {
            // ids 1..=150 had kv=id%7 and +40.
            150
        }
    );
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 301);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 13 (SQL level): a rolled-back transaction consumes no slot and
/// leaves FREE slots FREE.
#[test]
fn k_rollback_consumes_no_slot_and_keeps_free_slots() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 100, 10);
    let table = table_id(&db, "k");
    db.execute(1, "DELETE FROM k WHERE id<=20").unwrap();
    drain(&db);
    let before = physical(&db, table);
    assert_eq!(before.free.len() + before.occupied.len(), 100);
    for _ in 0..20 {
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "UPDATE k SET v=v+1 WHERE id>20").unwrap();
        insert_range(&db, 5000, 5030, 10, 0);
        db.execute(1, "ROLLBACK").unwrap();
    }
    let after = physical(&db, table);
    assert_eq!(after.free, before.free);
    assert_eq!(after.occupied, before.occupied);
    assert_eq!(after.pages, before.pages);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 14: bulk/COPY uses the same allocation (FREE slots, reclaimed
/// pages) instead of appending.
#[test]
fn k_bulk_load_reuses_free_slots_and_reclaimed_pages() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    // 0.2-K.4: asserts exact index entry counts right after explicit passes
    // (eager pruning path); lazy pruning is covered by `lazy_index_tests`.
    db.set_lazy_index_pruning(false);
    setup(&db, 1000, 30);
    let table = table_id(&db, "k");
    db.execute(1, "DELETE FROM k WHERE id<=500").unwrap();
    drain(&db);
    let before = physical(&db, table);
    let freed = before.free.len();
    assert!(freed > 0 || before.pages > 0);
    let rows = (0..400i64)
        .map(|n| {
            Ok(Row::new(vec![
                Value::Int64(10_000 + n),
                Value::Int64(n % 7),
                Value::Int64(20_000 + n),
                Value::Int64(n),
                Value::Text("b".repeat(30)),
            ]))
        })
        .collect::<Vec<_>>();
    assert_eq!(db.bulk_load(1, "k", rows).unwrap(), 400);
    let after = physical(&db, table);
    assert_eq!(
        after.pages, before.pages,
        "bulk load must fill reclaimed space"
    );
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 900);
    let entries = index_entries(&db, table);
    assert!(entries.iter().all(|entries| *entries == 900), "{entries:?}");
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 19: CHECKPOINT keeps running one bounded pass (both phases).
#[test]
fn k_checkpoint_statement_retires_and_frees() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 100, 10);
    let table = table_id(&db, "k");
    db.execute(1, "DELETE FROM k WHERE id<=30").unwrap();
    db.execute(1, "CHECKPOINT").unwrap();
    assert_eq!(physical(&db, table).retired.len(), 30);
    publish_marker(&db);
    db.execute(1, "CHECKPOINT").unwrap();
    let state = physical(&db, table);
    assert!(state.retired.is_empty());
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 25 + L: duplicate-heavy index pruning stays exact and fast; RIDs
/// are pruned through runs of thousands of equal keys spanning many leaves.
#[test]
fn k_duplicate_heavy_index_pruning_is_exact() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    // 0.2-K.4: pins the eager exact-pruning path of a non-unique index.
    db.set_lazy_index_pruning(false);
    db.execute(1, "CREATE TABLE d (id BIGINT NOT NULL, g BIGINT, v BIGINT)")
        .unwrap();
    db.execute(1, "CREATE INDEX d_g ON d(g)").unwrap();
    let mut id = 0;
    while id < 6000 {
        let values = (id..id + 500)
            .map(|id| format!("({id},{},{id})", id % 2))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(1, &format!("INSERT INTO d VALUES {values}"))
            .unwrap();
        id += 500;
    }
    let table = table_id(&db, "d");
    db.execute(1, "UPDATE d SET v=v+1 WHERE id<3000").unwrap();
    let started = Instant::now();
    let (retired, _) = drain(&db);
    let elapsed = started.elapsed();
    assert_eq!(retired, 3000);
    println!(
        "k_duplicate_heavy_index_pruning: {retired} versions in {:?} ({:.0}/s)",
        elapsed,
        retired as f64 / elapsed.as_secs_f64()
    );
    let entries = index_entries(&db, table);
    assert_eq!(entries, vec![6000]);
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM d WHERE g=1"),
        3000
    );
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM d WHERE g=0"), {
        (0..6000i64)
            .filter(|n| n % 2 == 0)
            .map(|n| n + i64::from(n < 3000))
            .sum::<i64>()
    });
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part O 26: wide (overflow) rows churn: overflow pages never receive
/// ordinary tuples and are never reset/trimmed by the slot lifecycle.
#[test]
fn k_wide_overflow_row_churn_keeps_overflow_pages_intact() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 50, 10);
    let table = table_id(&db, "k");
    let wide = "w".repeat(20_000);
    db.execute(1, &format!("INSERT INTO k VALUES (500,1,500,0,'{wide}')"))
        .unwrap();
    for round in 0..30 {
        db.execute(1, &format!("UPDATE k SET v={round} WHERE id=500"))
            .unwrap();
        db.execute(1, "UPDATE k SET v=v+1 WHERE id<=50").unwrap();
        drain(&db);
    }
    assert_eq!(
        scalar(&db, 2, "SELECT LENGTH(pad) AS n FROM k WHERE id=500"),
        20_000
    );
    let path = heap_path(&db.data_dir, table);
    db.checkpoint().unwrap();
    let violations = phobos_storage::overflow_safety::scan_overflow_violations(&path).unwrap();
    assert!(violations.is_empty(), "{violations:?}");
    let report = db.storage_lifecycle_report(None).unwrap();
    let entry = report
        .tables
        .iter()
        .find(|entry| entry.table == "k")
        .unwrap();
    assert!(entry.heap_pages <= 12, "{entry:?}");
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Part H: an index entry whose RID now names a row with another key (a
/// stale reference: here injected offline) is skipped by every dereference
/// path: indexed SELECT (streamed and materialized), indexed UPDATE/DELETE,
/// the UNIQUE recheck and the bulk UNIQUE merge. Never a wrong row, a false
/// UNIQUE conflict or an error.
#[test]
fn k_stale_index_references_are_skipped_on_every_path() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 50, 10);
    let table = table_id(&db, "k");
    let (u_index, kv_index) = {
        let database = db.lock_database().unwrap();
        let find = |name: &str| {
            database
                .catalog
                .indexes()
                .find(|index| index.name == name)
                .unwrap()
                .id
        };
        (find("k_u"), find("k_kv"))
    };
    // Row id=7: kv = 0, u = 7. Inject (kv=6 -> rid(7)) and (u=777 -> rid(7)).
    let rid = physical(&db, table)
        .occupied
        .iter()
        .find(|(_, id)| *id == 7)
        .unwrap()
        .0;
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    for (index, key, unique) in [(kv_index, 6i64, false), (u_index, 777i64, true)] {
        let mut tree = BPlusTree::open(index_path(&root, index), unique, 1).unwrap();
        tree.insert_reindex_entry(IndexKey(vec![Value::Int64(key)]), rid)
            .unwrap();
        tree.sync().unwrap();
    }
    let db = MvccDatabase::open(&root).unwrap();
    // Indexed SELECT (projected, rows, COUNT) must not return row 7 for kv=6.
    let expected_kv6 = (1..=50i64).filter(|id| id % 7 == 6).count() as i64;
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM k WHERE kv=6"),
        expected_kv6
    );
    let ids = rows(&db, 2, "SELECT id FROM k WHERE kv=6");
    assert!(!ids.contains(&Row::new(vec![Value::Int64(7)])), "{ids:?}");
    assert!(rows(&db, 2, "SELECT id, pad FROM k WHERE u=777").is_empty());
    // Indexed UPDATE/DELETE never touch row 7 through the stale entries.
    assert_eq!(
        affected(db.execute(1, "UPDATE k SET v=-1 WHERE kv=6").unwrap()),
        expected_kv6 as u64
    );
    assert_eq!(
        affected(db.execute(1, "DELETE FROM k WHERE u=777").unwrap()),
        0
    );
    assert_eq!(scalar(&db, 2, "SELECT v FROM k WHERE id=7"), 7);
    // UNIQUE recheck: u=777 is free (the stale entry names u=7) ...
    db.execute(1, "INSERT INTO k VALUES (100,1,777,0,'new')")
        .unwrap();
    // ... and the bulk merge agrees for another stale-looking value.
    let error = db
        .execute(1, "INSERT INTO k VALUES (101,1,7,0,'dup')")
        .unwrap_err();
    assert_eq!(
        error.code,
        ErrorCode::ConstraintViolation,
        "true conflict kept"
    );
    db.disconnect(1);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k WHERE u=777"), 1);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// 0.2-K.1 Part A: a panic inside a reclaim pass fails safe. Later passes and
/// CHECKPOINT return the actionable maintenance-fault error (not an opaque
/// poisoned lock), reads and writes continue, diagnostics expose the fault,
/// no slot is freed while faulted, and a restart resumes maintenance with
/// integrity intact.
#[test]
fn k1_reclaim_panic_faults_maintenance_safely_and_restart_resumes() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db, 200, 10);
    db.execute(1, "UPDATE k SET v=v+1 WHERE id<=100").unwrap();
    db.disconnect(1);
    *super::reclaim::PANIC_NEXT_PASS.lock().unwrap() = Some(fs::canonicalize(&root).unwrap());
    let panicked = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| db.reclaim_once(64)));
    assert!(
        panicked.is_err(),
        "the injected panic propagates to the caller"
    );
    let error = db.reclaim_once(64).unwrap_err();
    assert_eq!(error.code, ErrorCode::Recovery, "{error:?}");
    assert!(error.message.contains("restart the database"), "{error:?}");
    let error = db.execute(1, "CHECKPOINT").unwrap_err();
    assert_eq!(error.code, ErrorCode::Recovery, "{error:?}");
    db.disconnect(1);
    // Reads and writes continue.
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 200);
    db.execute(1, "UPDATE k SET v=v+1 WHERE id<=10").unwrap();
    db.execute(1, "INSERT INTO k VALUES (1000,0,1000,0,'x')")
        .unwrap();
    db.disconnect(1);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 201);
    let report = db.storage_lifecycle_report(None).unwrap();
    assert!(report.maintenance_fault.is_some(), "{report:?}");
    db.disconnect(2);
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    // Restart: maintenance resumes exactly; dead versions are reclaimed.
    let db = MvccDatabase::open(&root).unwrap();
    assert!(db.maintenance_fault().is_none());
    let mut reclaimed = 0;
    for _ in 0..8 {
        reclaimed += db.reclaim_once(256).unwrap().versions_reclaimed;
    }
    assert!(reclaimed >= 110, "{reclaimed}");
    db.execute(1, "CHECKPOINT").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM k"), 201);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    std::fs::remove_dir_all(root).unwrap();
}
