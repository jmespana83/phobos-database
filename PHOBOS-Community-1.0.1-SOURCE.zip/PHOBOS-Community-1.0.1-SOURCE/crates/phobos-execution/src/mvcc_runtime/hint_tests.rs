//! 0.1.9-B1/B2 through the SQL runtime: settled hints skip repeated status
//! lookups on stable data, the shared status cache and paged status reads
//! serve the lookups that remain, and query results never change.
//!
//! Counters are per database (`SessionManager::status_metrics`), but the
//! `hint_bits_enabled` switch is process-wide, so every test that asserts
//! on counters holds `HINT_TEST_LOCK`.
use super::*;
use phobos_txn::mvcc::sessions::StatusMetrics;
use std::sync::Mutex as StdMutex;
use tests::fixture;

static HINT_TEST_LOCK: StdMutex<()> = StdMutex::new(());

fn lock() -> std::sync::MutexGuard<'static, ()> {
    HINT_TEST_LOCK
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
}
/// Restores hint bits on drop, including on panic.
struct HintsOff;
impl HintsOff {
    fn new() -> Self {
        phobos_storage::set_hint_bits_enabled(false);
        Self
    }
}
impl Drop for HintsOff {
    fn drop(&mut self) {
        phobos_storage::set_hint_bits_enabled(true);
    }
}
fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            Value::Null => 0,
            ref other => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}
fn rows(db: &MvccDatabase, session: u64, sql: &str) -> Vec<Row> {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => rows,
        other => panic!("rows result {other:?}"),
    }
}
fn delta(after: StatusMetrics, before: StatusMetrics) -> StatusMetrics {
    StatusMetrics {
        status_lookups: after.status_lookups - before.status_lookups,
        shared_cache_hits: after.shared_cache_hits - before.shared_cache_hits,
        status_page_reads: after.status_page_reads - before.status_page_reads,
        hint_hits: after.hint_hits - before.hint_hits,
    }
}
/// Runs `sql` and returns the counter deltas it caused.
fn measured(db: &MvccDatabase, session: u64, sql: &str) -> (i64, StatusMetrics) {
    let before = db.sessions.status_metrics();
    let value = scalar(db, session, sql);
    (value, delta(db.sessions.status_metrics(), before))
}
fn table_id(db: &MvccDatabase, name: &str) -> TableId {
    db.lock_database()
        .unwrap()
        .catalog
        .tables()
        .find(|table| table.name == name)
        .expect("table")
        .id
}
fn hint_cache(db: &MvccDatabase, table: TableId) -> Arc<phobos_storage::HintCache> {
    db.readers.read().unwrap().heaps[&table].hints().clone()
}
/// 100 further autocommit transactions of 5 rows: 101 distinct creators.
fn widen(db: &MvccDatabase) {
    for batch in 0..100i64 {
        let values = (0..5)
            .map(|k| format!("({},{k},NULL)", 2000 + batch * 5 + k))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(9, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
    }
    db.disconnect(9);
}

/// Acceptance check (tests 1–2): the same full scan twice over stable data.
/// The first scan resolves every tuple's creator; the second answers from
/// hints and performs almost no status lookups.
#[test]
fn b1_second_stable_scan_uses_hints_and_skips_status_lookups() {
    let _lock = lock();
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    widen(&db);
    // Reopen so the status page cache and hint cache start cold.
    db.shutdown(std::time::Duration::from_secs(10)).unwrap();
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    let (count, first) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1500);
    let (count, second) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1500);
    let (count, third) = measured(&db, 2, "SELECT SUM(id) AS s FROM t");
    assert_eq!(count, (0..1000).sum::<i64>() + (2000..2500).sum::<i64>());
    eprintln!(
        "B1/B2 acceptance (1500 committed rows, 101 creators, cold reopen)\n  first scan:  {first:?}\n  second scan: {second:?}\n  third scan (other session, SUM): {third:?}\n  status lookups reduced by {:.1}%",
        100.0 * (1.0 - second.status_lookups as f64 / first.status_lookups as f64)
    );
    // First scan: one resolution per tuple, served mostly by the shared
    // cache (101 misses, satisfied by one or two 4 KiB status pages), no
    // hints yet.
    assert!(first.status_lookups >= 1500, "{first:?}");
    assert!(
        first.shared_cache_hits >= first.status_lookups - 101,
        "{first:?}"
    );
    assert!(
        first.status_page_reads >= 1 && first.status_page_reads <= 4,
        "{first:?}"
    );
    assert!(first.hint_hits < 1500, "{first:?}");
    // Second scan: > 95 % fewer status lookups; every tuple answered by a hint.
    assert!(
        second.status_lookups * 20 <= first.status_lookups,
        "second scan still resolved {} statuses (first {})",
        second.status_lookups,
        first.status_lookups
    );
    assert!(second.hint_hits >= 1500, "{second:?}");
    assert_eq!(second.status_page_reads, 0, "{second:?}");
    assert!(third.hint_hits >= 1500 && third.status_lookups * 20 <= first.status_lookups);
    let cache = hint_cache(&db, table_id(&db, "t"));
    assert!(cache.hinted_pages() > 0);
    assert!(cache.get(0, 0).creator_committed());
    assert!(!cache.get(0, 0).deleter_committed());
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Test 3: a committed delete is resolved once, then the deleter hint marks
/// the version dead for every snapshot without a lookup.
#[test]
fn b1_committed_delete_uses_deleter_hint() {
    let _lock = lock();
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let (count, _) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1000);
    db.execute(1, "DELETE FROM t WHERE id<100").unwrap();
    let (count, first) = measured(&db, 2, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 900);
    // The 100 deleted versions resolve their deleter once (creators were
    // already hinted by the earlier scan); nothing else needs a lookup.
    assert!(
        first.status_lookups >= 100 && first.status_lookups <= 200,
        "{first:?}"
    );
    let (count, second) = measured(&db, 2, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 900);
    assert_eq!(second.status_lookups, 0, "{second:?}");
    assert!(second.hint_hits >= 1000, "{second:?}");
    let cache = hint_cache(&db, table_id(&db, "t"));
    let deleted = cache.get(0, 0);
    assert!(
        deleted.creator_committed() && deleted.deleter_committed(),
        "{deleted:?}"
    );
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id<100"),
        0
    );
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=100"), 100);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Test 5: with `hint_bits_enabled = false` every scan resolves every
/// tuple through the (cached, paged) status path, and nothing is hinted.
#[test]
fn b1_disabled_hint_bits_return_to_ordinary_status_resolution() {
    let _lock = lock();
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    {
        let _off = HintsOff::new();
        assert!(!phobos_storage::hint_bits_enabled());
        let (count, first) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
        let (again, second) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
        assert_eq!((count, again), (1000, 1000));
        assert_eq!(first.hint_hits + second.hint_hits, 0);
        assert!(first.status_lookups >= 1000 && second.status_lookups >= 1000);
        assert!(second.shared_cache_hits >= 1000, "{second:?}");
        assert_eq!(hint_cache(&db, table_id(&db, "t")).hinted_pages(), 0);
    }
    assert!(phobos_storage::hint_bits_enabled());
    let (_, first) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
    let (count, second) = measured(&db, 1, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1000);
    assert!(
        first.status_lookups >= 1000 && second.status_lookups == 0,
        "{first:?} {second:?}"
    );
    assert!(second.hint_hits >= 1000);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Test 4 at the runtime level: a commit above the hint bound of a live
/// older statement is visible to new statements but not hinted while that
/// older pin exists; once it is released the next scan hints it.
#[test]
fn b1_hints_respect_the_horizon_of_older_statements() {
    let _lock = lock();
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    scalar(&db, 1, "SELECT COUNT(*) AS n FROM t");
    let old_session = db.connect(50).unwrap();
    let mut old_view = db.statement(&old_session, None).unwrap();
    db.execute(
        2,
        &format!(
            "INSERT INTO t VALUES {}",
            (0..20)
                .map(|k| format!("({},{k},NULL)", 3000 + k))
                .collect::<Vec<_>>()
                .join(",")
        ),
    )
    .unwrap();
    let table = table_id(&db, "t");
    let cache = hint_cache(&db, table);
    let new_rids = |db: &MvccDatabase| {
        let session = db.connect(51).unwrap();
        let mut view = db.statement(&session, None).unwrap();
        let mut rids = Vec::new();
        view.database
            .heap_mut(table)
            .unwrap()
            .scan_versions(|rid, _, row| {
                if matches!(row.values[0], Value::Int64(id) if id >= 3000) {
                    rids.push(rid);
                }
                Ok(true)
            })
            .unwrap();
        drop(view);
        drop(session);
        db.disconnect(51);
        rids
    };
    let rids = new_rids(&db);
    assert_eq!(rids.len(), 20);
    let (count, first) = measured(&db, 3, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1020);
    assert!(first.status_lookups >= 20, "{first:?}");
    for rid in &rids {
        assert!(
            !cache.get(rid.page_id, rid.slot_id).creator_committed(),
            "{rid:?} hinted while an older statement pin holds the horizon"
        );
    }
    let (count, second) = measured(&db, 3, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1020);
    assert!(second.status_lookups >= 20, "{second:?}");
    // The old statement still cannot see those rows (Read Committed pin).
    assert_eq!(
        old_view
            .execute("SELECT COUNT(*) AS n FROM t", &[])
            .unwrap(),
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(1000)])]
        }
    );
    drop(old_view);
    drop(old_session);
    db.disconnect(50);
    let (count, third) = measured(&db, 3, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1020);
    let (count, fourth) = measured(&db, 3, "SELECT COUNT(*) AS n FROM t");
    assert_eq!(count, 1020);
    assert!(
        third.status_lookups >= 20 && fourth.status_lookups == 0,
        "{third:?} {fourth:?}"
    );
    for rid in &rids {
        assert!(
            cache.get(rid.page_id, rid.slot_id).creator_committed(),
            "{rid:?}"
        );
    }
    db.disconnect(1);
    db.disconnect(2);
    db.disconnect(3);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Tests 10–13 (semantics): the same statements produce identical results
/// with and without hints — own writes, spilled writes, UPDATE/DELETE
/// chains, index probes, aggregates and the canonical UNIQUE index.
#[test]
fn b1_results_are_identical_with_and_without_hints_including_spilled_writes() {
    let _lock = lock();
    let run = |hints: bool| -> Vec<Vec<Row>> {
        let _off = (!hints).then(HintsOff::new);
        let root = fixture();
        let db = MvccDatabase::open(&root).unwrap();
        db.set_write_spill(4096, 64 * 1024 * 1024).unwrap();
        let mut results = Vec::new();
        let queries = [
            "SELECT COUNT(*) AS n FROM t",
            "SELECT SUM(v) AS s FROM t",
            "SELECT v FROM t WHERE id=5",
            "SELECT COUNT(*) AS n FROM t WHERE id>=2000",
            "SELECT id FROM t WHERE v=3 ORDER BY id",
        ];
        scalar(&db, 1, "SELECT COUNT(*) AS n FROM t");
        db.execute(1, "BEGIN").unwrap();
        db.execute(
            1,
            &format!(
                "INSERT INTO t VALUES {}",
                (2000..2300)
                    .map(|id| format!("({id},{id},NULL)"))
                    .collect::<Vec<_>>()
                    .join(",")
            ),
        )
        .unwrap();
        db.execute(1, "UPDATE t SET v=3 WHERE id<50").unwrap();
        db.execute(1, "UPDATE t SET v=v+1 WHERE id>=2000").unwrap();
        db.execute(1, "DELETE FROM t WHERE id>=2200 AND id<2300")
            .unwrap();
        db.execute(1, "DELETE FROM t WHERE id=5").unwrap();
        db.execute(1, "INSERT INTO t VALUES (5,55,NULL)").unwrap();
        for query in queries {
            results.push(rows(&db, 1, query));
            results.push(rows(&db, 2, query));
        }
        db.execute(1, "COMMIT").unwrap();
        assert_eq!(
            db.execute(2, "INSERT INTO t VALUES (2100,1,NULL)")
                .unwrap_err()
                .code,
            ErrorCode::ConstraintViolation
        );
        for query in queries {
            results.push(rows(&db, 2, query));
            results.push(rows(&db, 2, query));
        }
        db.execute(2, "DELETE FROM t WHERE id<50").unwrap();
        for query in queries {
            results.push(rows(&db, 3, query));
        }
        db.disconnect(1);
        db.disconnect(2);
        db.disconnect(3);
        drop(db);
        fs::remove_dir_all(root).unwrap();
        results
    };
    let with_hints = run(true);
    let without_hints = run(false);
    assert_eq!(with_hints, without_hints);
}

/// Multi-reader smoke: concurrent scans on several threads see the same
/// counts; after the first resolutions the rest are hint hits.
#[test]
fn b1_multi_reader_smoke_counts_agree_and_hints_serve_all_threads() {
    let _lock = lock();
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    widen(&db);
    scalar(&db, 1, "SELECT COUNT(*) AS n FROM t");
    let before = db.sessions.status_metrics();
    let workers = (10..14u64)
        .map(|session| {
            let db = db.clone();
            std::thread::spawn(move || {
                for _ in 0..5 {
                    assert_eq!(scalar(&db, session, "SELECT COUNT(*) AS n FROM t"), 1500);
                    assert_eq!(
                        scalar(&db, session, "SELECT COUNT(*) AS n FROM t WHERE v>=0"),
                        1500
                    );
                }
                db.disconnect(session);
            })
        })
        .collect::<Vec<_>>();
    for worker in workers {
        worker.join().unwrap();
    }
    let smoke = delta(db.sessions.status_metrics(), before);
    eprintln!("multi-reader smoke (4 threads x 10 scans): {smoke:?}");
    assert!(smoke.hint_hits >= 4 * 10 * 1500, "{smoke:?}");
    assert!(smoke.status_lookups * 20 <= smoke.hint_hits, "{smoke:?}");
    db.disconnect(1);
    fs::remove_dir_all(root).unwrap();
}
