//! Canonical conflict identities, wait-die and bounded wait diagnostics.
use super::*;
use std::{
    sync::{
        Condvar,
        atomic::{AtomicU8, Ordering},
    },
    time::{Duration, Instant},
};

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Key {
    Table(TableId),
    Row(TableId, u64),
    Unique(IndexId, phobos_index::LogicalUniqueKey),
}

pub(super) struct WaitControl {
    // 0 = cancellable, 1 = cancelled, 2 = submitted to the commit worker.
    state: AtomicU8,
    timeout: Duration,
}
impl Default for WaitControl {
    fn default() -> Self {
        Self {
            state: AtomicU8::new(0),
            timeout: Duration::from_secs(2),
        }
    }
}
impl WaitControl {
    #[cfg(test)]
    pub(super) fn timeout(&self) -> Duration {
        self.timeout
    }
    pub(super) fn with_timeout(timeout: Duration) -> Self {
        Self {
            timeout,
            ..Self::default()
        }
    }
    pub fn cancel(&self) {
        let _ = self
            .state
            .compare_exchange(0, 1, Ordering::AcqRel, Ordering::Acquire);
    }
    pub fn check(&self) -> Result<(), PhobosError> {
        phobos_error::cancellation::check_now()?;
        if self.state.load(Ordering::Acquire) == 1 {
            Err(failed("transaction cancelled"))
        } else {
            Ok(())
        }
    }
    pub fn submit(&self) -> Result<(), PhobosError> {
        phobos_error::cancellation::commit()?;
        self.state
            .compare_exchange(0, 2, Ordering::AcqRel, Ordering::Acquire)
            .map(|_| ())
            .map_err(|_| failed("transaction cancelled or already submitted"))
    }
}

#[derive(Clone, Debug, Default)]
pub struct WaitStats {
    pub acquisitions: u64,
    pub immediate: u64,
    pub waits: u64,
    pub victims: u64,
    pub timeouts: u64,
    pub cancellations: u64,
    pub total_wait_ns: u64,
    pub maximum_wait_ns: u64,
    /// Inclusive upper bounds in microseconds: 1, 10, 100, 1000, 10000,
    /// 100000, 1000000, infinity. Counts include all completed wait outcomes.
    pub histogram: [u64; 8],
}
#[derive(Clone, Debug)]
pub struct ActiveWait {
    pub transaction: u64,
    pub owner: u64,
    pub resource: Key,
    pub elapsed_ns: u64,
}
#[derive(Clone, Debug, Default)]
pub struct ConflictDiagnostics {
    pub row: WaitStats,
    pub unique: WaitStats,
    pub active: Vec<ActiveWait>,
}
struct Waiting {
    owner: u64,
    key: Key,
    since: Instant,
}
#[derive(Default)]
struct State {
    owners: BTreeMap<Key, u64>,
    waiting: BTreeMap<u64, Waiting>,
    stats: WaitStats,
}
#[derive(Default)]
struct Domain {
    state: Mutex<State>,
    changed: Condvar,
}
pub(super) struct Ownership {
    directory: PathBuf,
    rows: Domain,
    unique: Domain,
}
pub(super) struct Lease {
    pub owner: Arc<Ownership>,
    stable: u64,
}
impl Ownership {
    pub fn new(directory: PathBuf) -> Self {
        Self {
            directory,
            rows: Domain::default(),
            unique: Domain::default(),
        }
    }
    pub fn lease(self: &Arc<Self>, stable: u64) -> Lease {
        Lease {
            owner: self.clone(),
            stable,
        }
    }
    pub fn wake(&self) {
        // Serialize each notification with the condvar check-to-wait transition.
        // Cancellation never takes a connection/structural guard.
        for domain in [&self.rows, &self.unique] {
            if let Ok(_state) = domain.state.lock() {
                domain.changed.notify_all();
            }
        }
    }
    pub fn diagnostics(&self) -> Result<ConflictDiagnostics, PhobosError> {
        let mut result = ConflictDiagnostics::default();
        for (domain, stats) in [
            (&self.rows, &mut result.row),
            (&self.unique, &mut result.unique),
        ] {
            let state = domain
                .state
                .lock()
                .map_err(|_| failed("ownership poisoned"))?;
            *stats = state.stats.clone();
            result
                .active
                .extend(state.waiting.iter().map(|(id, wait)| ActiveWait {
                    transaction: *id,
                    owner: wait.owner,
                    resource: wait.key.clone(),
                    elapsed_ns: nanos(wait.since.elapsed()),
                }));
        }
        Ok(result)
    }
    pub fn acquire(&self, stable: u64, key: Key, control: &WaitControl) -> Result<(), PhobosError> {
        let domain = match &key {
            Key::Row(..) | Key::Table(..) => &self.rows,
            Key::Unique(..) => &self.unique,
        };
        let _cost = phobos_observability::span(match &key {
            Key::Row(..) => "mvcc.row_wait",
            Key::Table(..) => "bulk.table_wait",
            Key::Unique(..) => "mvcc.unique_wait",
        });
        let deadline = Instant::now() + control.timeout;
        let mut state = domain
            .state
            .lock()
            .map_err(|_| failed("write ownership poisoned"))?;
        let result = loop {
            if let Err(error) = control.check() {
                state.stats.cancellations += 1;
                break Err(error);
            }
            let holder = match &key {
                Key::Row(table, _) => state
                    .owners
                    .get(&Key::Table(*table))
                    .copied()
                    .filter(|owner| *owner != stable)
                    .or_else(|| state.owners.get(&key).copied()),
                Key::Table(table) => state.owners.iter().find_map(|(resource, owner)| {
                    (matches!(resource, Key::Table(id) | Key::Row(id, _) if id == table)
                        && *owner != stable)
                        .then_some(*owner)
                }),
                Key::Unique(..) => state.owners.get(&key).copied(),
            };
            match holder {
                None => {
                    state.owners.insert(key.clone(), stable);
                    state.stats.acquisitions += 1;
                    if !state.waiting.contains_key(&stable) {
                        state.stats.immediate += 1;
                    }
                    break Ok(());
                }
                Some(owner) if owner == stable => {
                    state.stats.acquisitions += 1;
                    state.stats.immediate += 1;
                    break Ok(());
                }
                // Dynamic edges always point from older to younger stable IDs.
                Some(owner) if stable > owner => {
                    state.stats.victims += 1;
                    break Err(failed("write conflict: younger transaction is victim"));
                }
                Some(owner) => {
                    if !state.waiting.contains_key(&stable) {
                        if state.waiting.len() == 1024 {
                            break Err(PhobosError::new(
                                ErrorCode::ResourceLimit,
                                "conflict waiter limit",
                            ));
                        }
                        state.waiting.insert(
                            stable,
                            Waiting {
                                owner,
                                key: key.clone(),
                                since: Instant::now(),
                            },
                        );
                        state.stats.waits += 1;
                    } else {
                        state.waiting.get_mut(&stable).expect("waiter").owner = owner;
                    }
                    phobos_observability::synchronization_boundary(
                        match &key {
                            Key::Row(..) => "c5_row_wait",
                            Key::Table(..) => "c7_table_wait",
                            Key::Unique(..) => "c5_unique_wait",
                        },
                        &self.directory,
                    );
                    let remaining = deadline.saturating_duration_since(Instant::now());
                    if remaining.is_zero() {
                        state.stats.timeouts += 1;
                        break Err(PhobosError::new(
                            ErrorCode::LockTimeout,
                            "write ownership wait timed out",
                        ));
                    }
                    let (next, _) = domain
                        .changed
                        .wait_timeout(state, remaining.min(Duration::from_millis(10)))
                        .map_err(|_| failed("write ownership poisoned"))?;
                    state = next;
                }
            }
        };
        if let Some(wait) = state.waiting.remove(&stable) {
            let ns = nanos(wait.since.elapsed());
            state.stats.total_wait_ns = state.stats.total_wait_ns.saturating_add(ns);
            state.stats.maximum_wait_ns = state.stats.maximum_wait_ns.max(ns);
            let bucket = [
                1_000,
                10_000,
                100_000,
                1_000_000,
                10_000_000,
                100_000_000,
                1_000_000_000,
            ]
            .iter()
            .position(|limit| ns <= *limit)
            .unwrap_or(7);
            state.stats.histogram[bucket] += 1;
        }
        result
    }
}
impl Drop for Lease {
    fn drop(&mut self) {
        for domain in [&self.owner.rows, &self.owner.unique] {
            if let Ok(mut state) = domain.state.lock() {
                state.owners.retain(|_, stable| *stable != self.stable);
                domain.changed.notify_all();
            }
        }
    }
}
fn nanos(duration: Duration) -> u64 {
    duration.as_nanos().min(u128::from(u64::MAX)) as u64
}
fn failed(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TransactionState, message)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn c6_timeout_removes_wait_record_and_submission_wins_over_late_cancel() {
        let ownership = Arc::new(Ownership::new(PathBuf::new()));
        let younger = ownership.lease(2);
        let key = Key::Row(1, 1);
        ownership
            .acquire(2, key.clone(), &WaitControl::default())
            .unwrap();
        let control = WaitControl {
            state: AtomicU8::new(0),
            timeout: Duration::ZERO,
        };
        assert_eq!(
            ownership
                .acquire(1, key.clone(), &control)
                .unwrap_err()
                .code,
            ErrorCode::LockTimeout
        );
        let stats = ownership.diagnostics().unwrap();
        assert_eq!(stats.row.timeouts, 1);
        assert!(stats.active.is_empty());
        drop(younger);
        ownership.acquire(1, key, &control).unwrap();
        control.submit().unwrap();
        control.cancel();
        control.check().unwrap();
        assert!(control.submit().is_err());
        let cancelled = WaitControl::default();
        cancelled.cancel();
        assert!(cancelled.submit().is_err());
    }
}
