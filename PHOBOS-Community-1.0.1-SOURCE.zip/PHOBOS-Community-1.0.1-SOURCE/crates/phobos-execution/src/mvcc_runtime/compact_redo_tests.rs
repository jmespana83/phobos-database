//! 0.2-D compact page redo through the SQL engine: crash (process exit with
//! no shutdown/checkpoint) after acknowledged work and at commit-pipeline
//! boundaries, raw redo repeated, then recovery and full integrity checks.
//! The benchmark-shaped table `w(id, b, p)` has a UNIQUE index on `id` and a
//! secondary index on `(b, id)`; `p` is not indexed.
use super::*;
use phobos_wal::v2::{Body, FileId, visit_validated};
use std::{
    io::{Read, Seek, SeekFrom, Write},
    process::{Command, exit},
    sync::atomic::{AtomicU64, Ordering},
    time::Duration,
};
use tests::fixture;

const POINT: &str = "PHOBOS_V3_CRASH_POINT";
const ROOT: &str = "PHOBOS_V3_CRASH_ROOT";

fn rows(db: &MvccDatabase, sql: &str) -> Vec<Vec<Value>> {
    match db.execute(1, sql).unwrap() {
        QueryResult::Rows { rows, .. } => rows.into_iter().map(|row| row.values).collect(),
        other => panic!("rows required, got {other:?}"),
    }
}
fn count(db: &MvccDatabase, sql: &str) -> i64 {
    match rows(db, sql)[0][0] {
        Value::Int64(n) => n,
        ref other => panic!("count {other:?}"),
    }
}
fn create(db: &MvccDatabase) {
    db.execute(
        1,
        "CREATE TABLE w (id BIGINT NOT NULL, b BIGINT NOT NULL, p TEXT NOT NULL)",
    )
    .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX w_id ON w(id)").unwrap();
    db.execute(1, "CREATE INDEX w_b ON w(b, id)").unwrap();
}
fn insert(db: &MvccDatabase, session: u64, ids: impl Iterator<Item = i64>) {
    let values: Vec<_> = ids.map(|i| format!("({i},{},'p{i:08}')", i % 97)).collect();
    db.execute(
        session,
        &format!("INSERT INTO w VALUES {}", values.join(",")),
    )
    .unwrap();
}
/// WAL record mix (deltas, full images) over every retained segment.
fn wal_mix(root: &Path) -> (usize, usize) {
    let (mut deltas, mut images) = (0, 0);
    visit_validated(root.join("phobos.wal"), |_, record| {
        match record.body {
            Body::PageDelta { .. } => deltas += 1,
            Body::Page { .. } => images += 1,
            _ => {}
        }
        Ok(())
    })
    .unwrap();
    (deltas, images)
}
fn spawn(test: &str, point: &str, root: &Path) -> std::process::Output {
    Command::new(std::env::current_exe().unwrap())
        .args(["--exact", test, "--nocapture"])
        .env(POINT, point)
        .env(ROOT, root)
        .output()
        .unwrap()
}
/// Every index is a valid B+tree whose entries equal the heap (both ways),
/// UNIQUE holds, COUNT equals the scan and each index answers like the scan.
fn verify_integrity(db: &MvccDatabase) -> usize {
    db.check_online().unwrap();
    let mut height = 0;
    {
        let mut database = db.lock_database().unwrap();
        for tree in database.indexes.values_mut() {
            height = height.max(tree.validate().unwrap().height);
        }
    }
    let scan = rows(db, "SELECT id, b, p FROM w ORDER BY id");
    let n = count(db, "SELECT COUNT(*) AS n FROM w");
    assert_eq!(scan.len() as i64, n);
    let ids: Vec<_> = scan.iter().map(|row| row[0].clone()).collect();
    let mut unique = ids.clone();
    unique.dedup();
    assert_eq!(unique.len(), ids.len(), "duplicate ids");
    for probe in [0, 13, 96] {
        let via_index = count(db, &format!("SELECT COUNT(*) AS n FROM w WHERE b={probe}"));
        let via_scan = scan
            .iter()
            .filter(|row| row[1] == Value::Int64(probe))
            .count() as i64;
        assert_eq!(via_index, via_scan, "secondary index b={probe}");
    }
    height
}

/// Deterministic DML history: inserts, non-key and key updates, deletes and
/// a multi-statement transaction. Returns the expected (id -> (b, p)) state.
fn history(db: &MvccDatabase) -> BTreeMap<i64, (i64, String)> {
    let mut expected = BTreeMap::new();
    for chunk in 0..30 {
        let ids = (chunk * 10)..(chunk * 10 + 10);
        insert(db, 1, ids.clone());
        for i in ids {
            expected.insert(i, (i % 97, format!("p{i:08}")));
        }
    }
    for i in (0..300).step_by(7) {
        db.execute(1, &format!("UPDATE w SET p='u{i}' WHERE id={i}"))
            .unwrap();
        expected.get_mut(&i).unwrap().1 = format!("u{i}");
    }
    for i in (3..300).step_by(11) {
        db.execute(1, &format!("UPDATE w SET b={} WHERE id={i}", (i * 5) % 97))
            .unwrap();
        expected.get_mut(&i).unwrap().0 = (i * 5) % 97;
    }
    for i in (5..300).step_by(13) {
        db.execute(1, &format!("DELETE FROM w WHERE id={i}"))
            .unwrap();
        expected.remove(&i);
    }
    db.execute(1, "BEGIN").unwrap();
    insert(db, 1, 1000..1040);
    db.execute(1, "UPDATE w SET p='txn' WHERE id>=1000 AND id<1010")
        .unwrap();
    db.execute(1, "DELETE FROM w WHERE id=1039").unwrap();
    db.execute(1, "COMMIT").unwrap();
    for i in 1000..1039 {
        let p = if i < 1010 {
            "txn".into()
        } else {
            format!("p{i:08}")
        };
        expected.insert(i, (i % 97, p));
    }
    expected
}
fn assert_state(db: &MvccDatabase, expected: &BTreeMap<i64, (i64, String)>) {
    let scan = rows(db, "SELECT id, b, p FROM w ORDER BY id");
    let actual: BTreeMap<i64, (i64, String)> = scan
        .into_iter()
        .map(|row| match (&row[0], &row[1], &row[2]) {
            (Value::Int64(id), Value::Int64(b), Value::Text(p)) => (*id, (*b, p.clone())),
            other => panic!("row {other:?}"),
        })
        .collect();
    assert_eq!(&actual, expected);
}

const DML_TEST: &str =
    "mvcc_runtime::compact_redo_tests::v3_heap_and_index_deltas_survive_crash_and_repeated_redo";

/// Targeted tests 1–5, 11, 18: heap insert/update/delete and index
/// insert/delete deltas, crash after the acknowledgement (no shutdown), raw
/// redo three times, then two recover/reopen cycles with integrity checks.
#[test]
fn v3_heap_and_index_deltas_survive_crash_and_repeated_redo() {
    if std::env::var(POINT).is_ok() {
        let root = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let db = MvccDatabase::open(&root).unwrap();
        create(&db);
        history(&db);
        // Open, never committed: must vanish.
        db.execute(2, "BEGIN").unwrap();
        insert(&db, 2, 5000..5010);
        exit(86);
    }
    let root = fixture();
    let output = spawn(DML_TEST, "after_ack", &root);
    assert_eq!(
        output.status.code(),
        Some(86),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let (deltas, images) = wal_mix(&root);
    assert!(deltas > 5 * images, "deltas {deltas} images {images}");
    for _ in 0..3 {
        phobos_wal::v2::redo(&root).unwrap();
    }
    let expected = {
        let scratch = fixture();
        let db = MvccDatabase::open(&scratch).unwrap();
        create(&db);
        let expected = history(&db);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
        fs::remove_dir_all(scratch).unwrap();
        expected
    };
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        assert_state(&db, &expected);
        verify_integrity(&db);
        db.execute(1, "INSERT INTO w VALUES (9000000,1,'post')")
            .unwrap();
        db.execute(1, "DELETE FROM w WHERE id=9000000").unwrap();
        db.shutdown(Duration::from_secs(10)).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}

const SPLIT_TEST: &str =
    "mvcc_runtime::compact_redo_tests::v3_leaf_internal_and_root_splits_recover";

/// Targeted tests 6–8: wide keys force leaf splits, internal splits and root
/// splits across many small commits whose other changes are deltas.
#[test]
fn v3_leaf_internal_and_root_splits_recover() {
    let wide = |i: i64| format!("{:0>500}", (i * 7919) % 100_003);
    if std::env::var(POINT).is_ok() {
        let root = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(1, "CREATE TABLE s (id BIGINT NOT NULL, k TEXT NOT NULL)")
            .unwrap();
        db.execute(1, "CREATE UNIQUE INDEX s_id ON s(id)").unwrap();
        db.execute(1, "CREATE INDEX s_k ON s(k)").unwrap();
        for chunk in 0..60 {
            let values: Vec<_> = (chunk * 5..chunk * 5 + 5)
                .map(|i| format!("({i},'{}')", wide(i)))
                .collect();
            db.execute(1, &format!("INSERT INTO s VALUES {}", values.join(",")))
                .unwrap();
        }
        for i in (0..300).step_by(9) {
            db.execute(1, &format!("DELETE FROM s WHERE id={i}"))
                .unwrap();
        }
        exit(86);
    }
    let root = fixture();
    let output = spawn(SPLIT_TEST, "after_ack", &root);
    assert_eq!(
        output.status.code(),
        Some(86),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let (deltas, images) = wal_mix(&root);
    assert!(deltas > 0 && images > 0);
    phobos_wal::v2::redo(&root).unwrap();
    phobos_wal::v2::redo(&root).unwrap();
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        db.check_online().unwrap();
        let height = {
            let mut database = db.lock_database().unwrap();
            database
                .indexes
                .values_mut()
                .map(|tree| tree.validate().unwrap().height)
                .max()
                .unwrap()
        };
        assert!(
            height >= 3,
            "root and internal splits expected, height {height}"
        );
        assert_eq!(count(&db, "SELECT COUNT(*) AS n FROM s"), 300 - 34);
        for i in [1, 2, 150, 298] {
            let expected = i64::from(i % 9 != 0);
            assert_eq!(
                count(
                    &db,
                    &format!("SELECT COUNT(*) AS n FROM s WHERE k='{}'", wide(i))
                ),
                expected
            );
            assert_eq!(
                count(&db, &format!("SELECT COUNT(*) AS n FROM s WHERE id={i}")),
                expected
            );
        }
        db.shutdown(Duration::from_secs(10)).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}

const BOUNDARY_TEST: &str =
    "mvcc_runtime::compact_redo_tests::v3_crash_at_commit_pipeline_boundaries_is_atomic";

/// Targeted tests 9–10 (and Stage A): process exit at the Nth crossing of
/// a pipeline boundary while 4 sessions commit two-row transactions.
/// Acknowledged transactions survive; unacknowledged ones are all-or-nothing.
#[test]
fn v3_crash_at_commit_pipeline_boundaries_is_atomic() {
    if let Ok(point) = std::env::var(POINT) {
        let root = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let db = Arc::new(MvccDatabase::open(&root).unwrap());
        create(&db);
        insert(&db, 1, 0..200);
        let crossings = Arc::new(AtomicU64::new(0));
        let (name, nth) = point.split_once('#').unwrap();
        let (name, nth) = (name.to_string(), nth.parse::<u64>().unwrap());
        let seen = crossings.clone();
        let _hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |at| {
                if at == name && seen.fetch_add(1, Ordering::SeqCst) + 1 == nth {
                    exit(86);
                }
            }),
        );
        std::thread::scope(|scope| {
            for client in 0..4u64 {
                let db = db.clone();
                scope.spawn(move || {
                    let session = 10 + client;
                    for n in 0..400i64 {
                        let id = 1_000_000 + client as i64 * 100_000 + n * 2;
                        db.execute(session, "BEGIN").unwrap();
                        insert(&db, session, [id, id + 1].into_iter());
                        db.execute(
                            session,
                            &format!("UPDATE w SET p='x{id}' WHERE id={}", n % 200),
                        )
                        .unwrap();
                        db.execute(session, "COMMIT").unwrap();
                        eprintln!("ACK {id}");
                    }
                });
            }
        });
        exit(87);
    }
    for point in [
        "c6_private_redo_staged#7",
        "wal.before_force#5",
        "wal.after_force#9",
        "c6_private_redo_staged#40",
        "wal.after_force#33",
        // 0.2-E write-through pipeline: range reserved, durable write done
        // but frontier not advanced, around ordered publication.
        "wal.e_reserved#6",
        "wal.after_write#8",
        "wal.after_write#41",
        "mvcc.before_publication#10",
        "mvcc.after_publication#12",
    ] {
        let root = fixture();
        let output = spawn(BOUNDARY_TEST, point, &root);
        assert_eq!(
            output.status.code(),
            Some(86),
            "{point}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        let acked: Vec<i64> = String::from_utf8_lossy(&output.stderr)
            .lines()
            .filter_map(|line| line.strip_prefix("ACK ")?.parse().ok())
            .collect();
        phobos_wal::v2::redo(&root).unwrap();
        for round in 0..2 {
            let db = MvccDatabase::open(&root).unwrap();
            verify_integrity(&db);
            for id in &acked {
                assert_eq!(
                    count(
                        &db,
                        &format!("SELECT COUNT(*) AS n FROM w WHERE id={id} OR id={}", id + 1)
                    ),
                    2,
                    "{point} round {round}: acknowledged {id} lost"
                );
            }
            let all = rows(&db, "SELECT id FROM w WHERE id>=1000000 ORDER BY id");
            let ids: BTreeSet<i64> = all
                .iter()
                .map(|row| match row[0] {
                    Value::Int64(id) => id,
                    _ => unreachable!(),
                })
                .collect();
            for id in &ids {
                let pair = if id % 2 == 0 { id + 1 } else { id - 1 };
                assert!(ids.contains(&pair), "{point}: partial transaction {id}");
            }
            assert_eq!(count(&db, "SELECT COUNT(*) AS n FROM w WHERE id<200"), 200);
            db.shutdown(Duration::from_secs(10)).unwrap();
        }
        fs::remove_dir_all(root).unwrap();
    }
}

const TORN_TEST: &str =
    "mvcc_runtime::compact_redo_tests::v3_torn_data_pages_after_checkpoint_are_repaired";

/// Torn-page fault injection: after a CHECKPOINT (all data forced, WAL
/// rewritten), later commits change the same pages with deltas; the crash
/// leaves an on-disk heap page and index leaf torn. Recovery must repair both
/// from the first-touch images logged after the checkpoint.
#[test]
fn v3_torn_data_pages_after_checkpoint_are_repaired() {
    if std::env::var(POINT).is_ok() {
        let root = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let db = MvccDatabase::open(&root).unwrap();
        create(&db);
        let expected = history(&db);
        db.execute(1, "CHECKPOINT").unwrap();
        for i in (0..300).step_by(4) {
            if expected.contains_key(&i) {
                db.execute(1, &format!("UPDATE w SET p='after{i}' WHERE id={i}"))
                    .unwrap();
            }
        }
        insert(&db, 1, 2000..2050);
        exit(86);
    }
    let root = fixture();
    let output = spawn(TORN_TEST, "after_ack", &root);
    assert_eq!(
        output.status.code(),
        Some(86),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    // Only pages changed after the checkpoint can have a write in flight at a
    // crash: exactly the pages with records in the retained WAL. Tear the
    // on-disk copy of up to 8 of them (heap and index), second half garbage.
    let mut changed = BTreeSet::<(FileId, u64)>::new();
    visit_validated(root.join("phobos.wal"), |_, record| {
        if let Body::Page { file, page, .. } | Body::PageDelta { file, page, .. } = &record.body {
            changed.insert((*file, *page));
        }
        Ok(())
    })
    .unwrap();
    let mut torn = 0;
    let mut kinds = BTreeSet::new();
    for (file, page) in changed {
        let path = root.join(file.name());
        if torn == 8 || !path.exists() || fs::metadata(&path).unwrap().len() < (page + 1) * 8192 {
            continue;
        }
        let mut handle = fs::OpenOptions::new()
            .read(true)
            .write(true)
            .open(&path)
            .unwrap();
        let mut bytes = [0; 8192];
        handle.seek(SeekFrom::Start(page * 8192)).unwrap();
        handle.read_exact(&mut bytes).unwrap();
        bytes[4096..]
            .iter_mut()
            .for_each(|b| *b = b.wrapping_add(0x5d));
        handle.seek(SeekFrom::Start(page * 8192)).unwrap();
        handle.write_all(&bytes).unwrap();
        handle.sync_all().unwrap();
        kinds.insert(matches!(file, FileId::Heap(_)));
        torn += 1;
    }
    assert_eq!(kinds.len(), 2, "heap and index pages torn");
    assert!(torn >= 2, "no data pages to tear");
    let mut expected = {
        let scratch = fixture();
        let db = MvccDatabase::open(&scratch).unwrap();
        create(&db);
        let expected = history(&db);
        db.shutdown(Duration::from_secs(10)).unwrap();
        drop(db);
        fs::remove_dir_all(scratch).unwrap();
        expected
    };
    for i in (0..300).step_by(4) {
        if let Some(row) = expected.get_mut(&i) {
            row.1 = format!("after{i}");
        }
    }
    for i in 2000..2050 {
        expected.insert(i, (i % 97, format!("p{i:08}")));
    }
    for _ in 0..2 {
        let db = MvccDatabase::open(&root).unwrap();
        assert_state(&db, &expected);
        verify_integrity(&db);
        db.shutdown(Duration::from_secs(10)).unwrap();
    }
    fs::remove_dir_all(root).unwrap();
}

/// Delta records reference the file identities they change.
#[test]
fn v3_wal_after_checkpoint_starts_every_page_with_an_image() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    create(&db);
    insert(&db, 1, 0..100);
    db.execute(1, "CHECKPOINT").unwrap();
    for i in 0..20 {
        db.execute(1, &format!("UPDATE w SET p='z{i}' WHERE id={i}"))
            .unwrap();
    }
    let mut seen = BTreeSet::<(FileId, u64)>::new();
    visit_validated(root.join("phobos.wal"), |_, record| {
        match &record.body {
            Body::Page { file, page, .. } => {
                seen.insert((*file, *page));
            }
            Body::PageDelta { file, page, .. } => {
                assert!(seen.contains(&(*file, *page)), "delta before first image");
            }
            _ => {}
        }
        Ok(())
    })
    .unwrap();
    assert!(wal_mix(&root).0 > 20);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
