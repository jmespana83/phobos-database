//! Conservative C4: freeze only IDs with no surviving heap references. No
//! persistent hint changes, tuple normalization, guessed commits or ID reuse.
use super::*;

#[derive(Default)]
pub(super) struct FreezeSweep {
    generation: u64,
    tables: Vec<TableId>,
    table: usize,
    pub(super) page: u64,
    minimum: u64,
}
#[derive(Debug, Default, Clone, Copy)]
pub struct FreezeReport {
    pub before: u64,
    pub after: u64,
    pub pages_examined: usize,
    pub sweep_complete: bool,
    pub deferred_busy: bool,
}
impl MvccDatabase {
    /// Inspect at most `limit` heap pages and 4096 status IDs. A pin/transaction
    /// defers this pass. Allocations between passes restart its reference proof.
    /// Unchanged live tuple creators/deleters conservatively hold the boundary.
    pub fn freeze_once(&self, limit: usize) -> Result<FreezeReport, PhobosError> {
        let _maintenance = phobos_error::cancellation::suspend();
        let _order = self.lock_commits_quiescent()?;
        let mut database = self.lock_database()?;
        let mut sweep = self
            .freeze_state
            .lock()
            .map_err(|_| write_conflict("freeze sweep poisoned"))?;
        let mut report = FreezeReport::default();
        let result = self.sessions.freeze_if_idle(4096, |generation, before| {
            let tables = database.catalog.tables().map(|t| t.id).collect::<Vec<_>>();
            if sweep.generation != generation || sweep.tables != tables {
                *sweep = FreezeSweep {
                    generation,
                    tables,
                    minimum: generation,
                    ..FreezeSweep::default()
                };
            }
            report.before = before;
            while sweep.table < sweep.tables.len() && report.pages_examined < limit.max(1) {
                let table = sweep.tables[sweep.table];
                match database.heap_mut(table)?.page_versions(sweep.page)? {
                    Some((_, versions)) => {
                        report.pages_examined += 1;
                        for (_, tuple, _) in versions {
                            sweep.minimum = sweep.minimum.min(tuple.visibility.creator);
                            if let Some(id) = tuple.visibility.deleter {
                                sweep.minimum = sweep.minimum.min(id);
                            }
                        }
                        sweep.page += 1;
                    }
                    None => {
                        sweep.table += 1;
                        sweep.page = 0;
                    }
                }
            }
            report.sweep_complete = sweep.table == sweep.tables.len();
            if sweep.minimum < before {
                return Err(write_conflict("heap references frozen transaction history"));
            }
            Ok(report.sweep_complete.then_some(sweep.minimum))
        })?;
        match result {
            Some((before, after)) => {
                report.before = before;
                report.after = after;
            }
            None => {
                report.deferred_busy = true;
            }
        }
        Ok(report)
    }
    /// 0.2-K Part M: records of frozen status history worth one physical
    /// release (default `phobos_txn::mvcc::DEFAULT_TRIM_RECORDS`).
    pub fn set_status_trim_threshold(&self, records: u64) -> Result<(), PhobosError> {
        self.sessions.set_status_trim_threshold(records)
    }
    /// (exclusive watermark, status IDs examined during startup).
    pub fn freeze_metrics(&self) -> Result<(u64, u64), PhobosError> {
        self.sessions.freeze_metrics()
    }
}
