use super::*;

fn rows(result: QueryResult) -> Vec<Row> {
    match result {
        QueryResult::Rows { rows, .. } => rows,
        _ => panic!("expected rows"),
    }
}

#[test]
fn enterprise_alias_self_join_subqueries_restart() {
    let root = tests::fixture();
    let query = "SELECT a.id AS left_id, b.id AS right_id FROM names AS a LEFT JOIN names b ON b.id=a.parent ORDER BY left_id";
    {
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(
            1,
            "CREATE TABLE names (id BIGINT NOT NULL, parent BIGINT, label TEXT)",
        )
        .unwrap();
        db.execute(
            1,
            "INSERT INTO names VALUES (1,NULL,'root'),(2,1,'child'),(3,9,'orphan')",
        )
        .unwrap();
        assert_eq!(
            rows(db.execute(1, query).unwrap()),
            vec![
                Row::new(vec![Value::Int64(1), Value::Null]),
                Row::new(vec![Value::Int64(2), Value::Int64(1)]),
                Row::new(vec![Value::Int64(3), Value::Null])
            ]
        );
        assert_eq!(rows(db.execute(1, "SELECT n.id FROM names n WHERE n.id=(SELECT MAX(id) FROM names) AND EXISTS (SELECT id FROM names WHERE id=2)").unwrap()), vec![Row::new(vec![Value::Int64(3)])]);
        assert_eq!(
            rows(
                db.execute(
                    1,
                    "SELECT (SELECT id FROM names WHERE id=99) AS missing FROM names n LIMIT 1"
                )
                .unwrap()
            ),
            vec![Row::new(vec![Value::Null])]
        );
        assert!(
            db.execute(1, "SELECT (SELECT id FROM names) FROM names")
                .is_err()
        );
        assert!(db.execute(1, "SELECT names.id FROM names n").is_err());
        assert!(
            db.execute(1, "SELECT id FROM names a JOIN names b ON a.id=b.id")
                .is_err()
        );
        assert!(
            db.execute(1, "SELECT * FROM names a JOIN names a ON a.id=a.id")
                .is_err()
        );
        assert!(
            db.execute(1, "SELECT (SELECT id,parent FROM names LIMIT 1) FROM names")
                .is_err()
        );
        db.disconnect(1);
    }
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(rows(db.execute(1, query).unwrap()).len(), 3);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_catalog_own_ddl_rollback_and_restart() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        "CREATE TABLE catalog_test (id BIGINT NOT NULL, value DECIMAL(12,2))",
    )
    .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX catalog_unique ON catalog_test (id)")
        .unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SHOW CATALOG COLUMNS FROM catalog_test")
                .unwrap()
        )
        .len(),
        2
    );
    assert_eq!(
        rows(
            db.execute(1, "SHOW CATALOG CONSTRAINTS FROM catalog_test")
                .unwrap()
        )
        .len(),
        2
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert!(
        db.execute(1, "SHOW CATALOG COLUMNS FROM catalog_test")
            .is_err()
    );
    db.execute(1, "CREATE TABLE catalog_test (id BIGINT NOT NULL)")
        .unwrap();
    let expected = db
        .execute(1, "SHOW CATALOG COLUMNS FROM catalog_test")
        .unwrap();
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        db.execute(2, "SHOW CATALOG COLUMNS FROM catalog_test")
            .unwrap(),
        expected
    );
    assert!(!rows(db.execute(2, "SHOW CATALOG CAPABILITIES").unwrap()).is_empty());
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_alias_subquery_snapshot_and_own_writes() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "CREATE TABLE numbers (id BIGINT)").unwrap();
    db.execute(1, "INSERT INTO numbers VALUES (1)").unwrap();
    db.execute(1, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    let sql = "SELECT n.id FROM numbers n WHERE n.id=(SELECT MAX(id) FROM numbers)";
    let before = db.execute(1, sql).unwrap();
    db.execute(2, "INSERT INTO numbers VALUES (2)").unwrap();
    assert_eq!(db.execute(1, sql).unwrap(), before);
    db.execute(1, "INSERT INTO numbers VALUES (3)").unwrap();
    assert_eq!(
        rows(db.execute(1, sql).unwrap()),
        vec![Row::new(vec![Value::Int64(3)])]
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert_eq!(
        rows(db.execute(1, sql).unwrap()),
        vec![Row::new(vec![Value::Int64(2)])]
    );
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_cte_derived_functions_and_errors() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "CREATE TABLE strings (id BIGINT, label TEXT)")
        .unwrap();
    db.execute(1, "INSERT INTO strings VALUES (1,'  café  '),(2,NULL)")
        .unwrap();
    let sql = "WITH clean AS (SELECT id, TRIM(label) AS label FROM strings), sized AS (SELECT id, CHAR_LENGTH(label) AS n FROM clean) SELECT s.id, s.n FROM sized s ORDER BY id";
    assert_eq!(
        rows(db.execute(1, sql).unwrap()),
        vec![
            Row::new(vec![Value::Int64(1), Value::Int64(4)]),
            Row::new(vec![Value::Int64(2), Value::Null])
        ]
    );
    assert_eq!(rows(db.execute(1, "SELECT d.label FROM (SELECT UPPER(TRIM(label)) AS label FROM strings WHERE id=1) AS d").unwrap()), vec![Row::new(vec![Value::Text("CAFÉ".into())])]);
    assert_eq!(rows(db.execute(1, "SELECT SUBSTRING(TRIM(label),2,2), OCTET_LENGTH(TRIM(label)), CONCAT('x',NULL,'y'), REPLACE(label,'é','e'), FLOOR(1.8), CEIL(1.2), ROUND(-1.5) FROM strings WHERE id=1").unwrap()), vec![Row::new(vec![Value::Text("af".into()),Value::Int64(5),Value::Text("xy".into()),Value::Text("  cafe  ".into()),Value::Float64(1.0),Value::Float64(2.0),Value::Float64(-2.0)])]);
    for sql in [
        "SELECT SUBSTRING(label,1,-1) FROM strings",
        "SELECT CONCAT(1,'x') FROM strings",
        "SELECT TRIM(1) FROM strings",
        "WITH x AS (SELECT id FROM x) SELECT * FROM x",
        "WITH x AS (DELETE FROM strings) SELECT * FROM x",
        "WITH x AS (SELECT * FROM strings), x AS (SELECT * FROM strings) SELECT * FROM x",
        "SELECT * FROM (SELECT * FROM strings)",
        "WITH x AS (SELECT * FROM strings) SELECT * FROM strings JOIN x ON strings.id=x.id",
    ] {
        assert!(db.execute(1, sql).is_err(), "{sql}");
    }
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(rows(db.execute(1, sql).unwrap()).len(), 2);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_rename_preserves_index_and_rollback() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "CREATE TABLE original (id BIGINT NOT NULL, label TEXT)")
        .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX original_pk ON original (id)")
        .unwrap();
    db.execute(1, "INSERT INTO original VALUES (1,'one')")
        .unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "ALTER TABLE original RENAME TO renamed")
        .unwrap();
    db.execute(1, "ALTER TABLE renamed RENAME COLUMN id TO key")
        .unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SELECT key FROM renamed WHERE key=1")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(1)])]
    );
    db.execute(1, "INSERT INTO renamed (key,label) VALUES (4,'private')")
        .unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT id FROM original").unwrap()).len(),
        1
    );
    db.execute(1, "ALTER TABLE original RENAME TO renamed")
        .unwrap();
    db.execute(1, "ALTER TABLE renamed RENAME COLUMN id TO key")
        .unwrap();
    assert!(
        db.execute(1, "INSERT INTO renamed VALUES (1,'duplicate')")
            .is_err()
    );
    db.execute(1, "INSERT INTO renamed VALUES (2,'two')")
        .unwrap();
    db.execute(1, "UPDATE renamed SET key=3 WHERE key=2")
        .unwrap();
    assert!(
        db.execute(1, "ALTER TABLE renamed RENAME COLUMN key TO label")
            .is_err()
    );
    let metadata = db.execute(1, "SHOW CATALOG INDEXES FROM renamed").unwrap();
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SELECT key FROM renamed ORDER BY key")
                .unwrap()
        ),
        vec![
            Row::new(vec![Value::Int64(1)]),
            Row::new(vec![Value::Int64(3)])
        ]
    );
    assert_eq!(
        db.execute(1, "SHOW CATALOG INDEXES FROM renamed").unwrap(),
        metadata
    );
    assert!(
        db.execute(1, "INSERT INTO renamed VALUES (3,'duplicate')")
            .is_err()
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_predicate_joins_and_column_lists() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "CREATE TABLE a (id BIGINT NOT NULL, label TEXT)")
        .unwrap();
    db.execute(1, "CREATE TABLE b (id BIGINT, enabled BOOLEAN)")
        .unwrap();
    db.execute(1, "INSERT INTO a (label,id) VALUES ('one',1),('two',2)")
        .unwrap();
    db.execute(1, "INSERT INTO a (id) VALUES (3)").unwrap();
    db.execute(1, "INSERT INTO b VALUES (1,FALSE),(2,TRUE),(4,NULL)")
        .unwrap();
    let sql = "SELECT a.id AS id, b.id AS bid FROM a LEFT JOIN b ON a.id=b.id AND b.enabled=TRUE ORDER BY id";
    assert!(
        db.execute(1, &format!("EXPLAIN {sql}"))
            .unwrap()
            .to_text()
            .contains("Nested Loop Join")
    );
    assert!(
        db.execute(1, "EXPLAIN WITH q AS (SELECT id FROM a) SELECT id FROM q")
            .unwrap()
            .to_text()
            .contains("Derived Scan")
    );

    assert_eq!(
        rows(db.execute(1, sql).unwrap()),
        vec![
            Row::new(vec![Value::Int64(1), Value::Null]),
            Row::new(vec![Value::Int64(2), Value::Int64(2)]),
            Row::new(vec![Value::Int64(3), Value::Null])
        ]
    );
    assert_eq!(
        rows(
            db.execute(1, "SELECT COUNT(*) FROM a CROSS JOIN b")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(9)])]
    );
    assert_eq!(
        rows(
            db.execute(
                1,
                "SELECT x.id FROM a x JOIN b y ON (x.id=y.id) ORDER BY x.id"
            )
            .unwrap()
        )
        .len(),
        2
    );
    assert_eq!(rows(db.execute(1, "WITH joined AS (SELECT a.id FROM a JOIN b ON a.id<b.id) SELECT j.id FROM joined j ORDER BY j.id").unwrap()).len(), 4);
    for sql in [
        "INSERT INTO a (label) VALUES ('missing required')",
        "INSERT INTO a (id,id) VALUES (5,6)",
        "INSERT INTO a (unknown) VALUES (5)",
        "INSERT INTO a (id) VALUES (5,6)",
    ] {
        assert!(db.execute(1, sql).is_err(), "{sql}");
    }
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO a (id) VALUES (10)").unwrap();
    db.execute(1, "ROLLBACK").unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT COUNT(*) FROM a").unwrap()),
        vec![Row::new(vec![Value::Int64(3)])]
    );
    assert!(
        db.execute(
            1,
            "SELECT x.id, COUNT(*) FROM a x JOIN a y ON x.id=y.id GROUP BY y.id"
        )
        .is_err()
    );
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(rows(db.execute(1, sql).unwrap()).len(), 3);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn enterprise_ddl_column_binding_and_partition_boundaries() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "CREATE TABLE staged (id BIGINT NOT NULL, label TEXT)")
        .unwrap();
    db.execute(1, "CREATE UNIQUE INDEX staged_id ON staged (id)")
        .unwrap();
    db.execute(1, "INSERT INTO staged (id) VALUES (1)").unwrap();
    db.execute(1, "ALTER TABLE staged RENAME COLUMN id TO key")
        .unwrap();
    db.execute(1, "INSERT INTO staged (key) VALUES (2)")
        .unwrap();
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SELECT key FROM staged ORDER BY key")
                .unwrap()
        ),
        vec![
            Row::new(vec![Value::Int64(1)]),
            Row::new(vec![Value::Int64(2)])
        ]
    );
    db.execute(
        1,
        "CREATE TABLE partitions (id BIGINT NOT NULL) PARTITION BY RANGE (id)",
    )
    .unwrap();
    db.execute(
        1,
        "CREATE TABLE low PARTITION OF partitions FOR VALUES FROM (0) TO (10)",
    )
    .unwrap();
    db.execute(1, "INSERT INTO partitions (id) VALUES (1)")
        .unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT id FROM partitions").unwrap()).len(),
        1
    );
    assert_eq!(
        rows(
            db.execute(1, "SELECT COUNT(*) FROM partitions p WHERE p.id=1")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(1)])]
    );
    for sql in [
        "SELECT p.id FROM partitions p",
        "SELECT s.key FROM staged s JOIN partitions p ON s.key=p.id",
        "ALTER TABLE partitions RENAME TO nope",
        "ALTER TABLE low RENAME COLUMN id TO key",
        "WITH p AS (SELECT id FROM partitions) SELECT * FROM p",
        "SELECT (SELECT id FROM partitions) FROM staged",
    ] {
        assert_eq!(
            db.execute(1, sql).unwrap_err().code,
            ErrorCode::Unsupported,
            "{sql}"
        );
    }
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SELECT key FROM staged ORDER BY key")
                .unwrap()
        )
        .len(),
        2
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
