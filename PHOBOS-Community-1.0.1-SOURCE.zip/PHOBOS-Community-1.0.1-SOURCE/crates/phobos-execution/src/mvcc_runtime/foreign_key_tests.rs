use super::*;
fn rows(r: QueryResult) -> Vec<Row> {
    match r {
        QueryResult::Rows { rows, .. } => rows,
        _ => panic!("rows expected"),
    }
}
fn setup(db: &MvccDatabase) {
    db.execute(1, "CREATE TABLE parents (id BIGINT PRIMARY KEY)")
        .unwrap();
    db.execute(1,"CREATE TABLE children (id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, parent_id BIGINT, FOREIGN KEY(parent_id) REFERENCES parents(id) ON DELETE RESTRICT ON UPDATE NO ACTION)").unwrap();
    db.execute(1, "INSERT INTO parents VALUES(1),(2)").unwrap();
}
#[test]
fn foreign_keys_transaction_restart_restrict_and_self_reference() {
    let root = tests::fixture();
    {
        let db = MvccDatabase::open(&root).unwrap();
        setup(&db);
        db.execute(
            1,
            "INSERT INTO children(parent_id) VALUES(1),(NULL) RETURNING id",
        )
        .unwrap();
        for sql in [
            "INSERT INTO children(parent_id) VALUES(999)",
            "UPDATE children SET parent_id=999",
            "DELETE FROM parents WHERE id=1",
            "UPDATE parents SET id=3 WHERE id=1",
        ] {
            assert!(db.execute(1, sql).is_err(), "{sql}");
        }
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "INSERT INTO parents VALUES(3)").unwrap();
        db.execute(1, "INSERT INTO children(parent_id) VALUES(3)")
            .unwrap();
        db.execute(1, "ROLLBACK").unwrap();
        assert!(
            db.execute(1, "INSERT INTO children(parent_id) VALUES(3)")
                .is_err()
        );
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "SAVEPOINT s").unwrap();
        db.execute(1, "DELETE FROM children WHERE parent_id=1")
            .unwrap();
        db.execute(1, "DELETE FROM parents WHERE id=1").unwrap();
        db.execute(1, "ROLLBACK TO s").unwrap();
        assert!(db.execute(1, "DELETE FROM parents WHERE id=1").is_err());
        db.execute(1, "ROLLBACK").unwrap();
        db.execute(1,"CREATE TABLE tree (id BIGINT PRIMARY KEY, parent BIGINT, FOREIGN KEY(parent) REFERENCES tree(id))").unwrap();
        db.execute(1, "INSERT INTO tree VALUES(1,1),(2,1),(3,2)")
            .unwrap();
        assert!(db.execute(1, "DELETE FROM tree WHERE id=1").is_err());
        db.execute(1, "DELETE FROM tree").unwrap();
        db.execute(1, "ALTER TABLE parents RENAME COLUMN id TO pk")
            .unwrap();
        db.execute(1, "ALTER TABLE parents RENAME TO renamed")
            .unwrap();
        assert!(db.execute(1, "DELETE FROM renamed WHERE pk=1").is_err());
        db.check_online().unwrap();
        db.disconnect(1);
    }
    {
        let db = MvccDatabase::open(&root).unwrap();
        assert!(
            db.execute(1, "INSERT INTO children(parent_id) VALUES(999)")
                .is_err()
        );
        assert!(db.execute(1, "DELETE FROM renamed WHERE pk=1").is_err());
        db.check_online().unwrap();
        db.disconnect(1);
    }
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn foreign_keys_concurrent_parent_delete_child_insert() {
    let root = tests::fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    setup(&db);
    db.disconnect(1);
    for id in 10..30 {
        db.execute(1, &format!("INSERT INTO parents VALUES({id})"))
            .unwrap();
        let barrier = Arc::new(std::sync::Barrier::new(2));
        let threads: Vec<_> = (0..2)
            .map(|n| {
                let db = db.clone();
                let barrier = barrier.clone();
                std::thread::spawn(move || {
                    barrier.wait();
                    let sql = if n == 0 {
                        format!("INSERT INTO children(parent_id) VALUES({id})")
                    } else {
                        format!("DELETE FROM parents WHERE id={id}")
                    };
                    let mut result = None;
                    for _ in 0..10000 {
                        match db.execute(n + 10, &sql) {
                            Err(e)
                                if matches!(
                                    e.code,
                                    ErrorCode::TransactionState | ErrorCode::LockTimeout
                                ) =>
                            {
                                std::thread::sleep(std::time::Duration::from_millis(2))
                            }
                            r => {
                                result = Some(r);
                                break;
                            }
                        }
                    }
                    db.disconnect(n + 10);
                    result.expect("retry exhaustion")
                })
            })
            .collect();
        let outcomes: Vec<_> = threads.into_iter().map(|t| t.join().unwrap()).collect();
        assert_eq!(outcomes.iter().filter(|r| r.is_ok()).count(), 1);
        assert_eq!(
            outcomes.iter().find_map(|r| r.as_ref().err()).unwrap().code,
            ErrorCode::ConstraintViolation
        );
    }
    db.check_online().unwrap();
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn foreign_keys_snapshot_and_composite_errors() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    setup(&db);
    db.execute(2, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    db.execute(1, "INSERT INTO parents VALUES(4)").unwrap();
    assert_eq!(
        db.execute(2, "INSERT INTO children(parent_id) VALUES(1)")
            .unwrap_err()
            .code,
        ErrorCode::TransactionState
    );
    db.execute(2, "ROLLBACK").unwrap();
    for sql in [
        "CREATE TABLE bad (n TEXT, FOREIGN KEY(n) REFERENCES parents(id))",
        "CREATE TABLE bad (n BIGINT, FOREIGN KEY(n) REFERENCES parents(missing))",
        "CREATE TABLE bad (n BIGINT, FOREIGN KEY(n) REFERENCES parents(id) ON DELETE CASCADE)",
    ] {
        assert!(db.execute(1, sql).is_err(), "{sql}");
    }
    db.execute(
        1,
        "CREATE TABLE composite (a BIGINT, b BIGINT, PRIMARY KEY(a,b))",
    )
    .unwrap();
    db.execute(
        1,
        "CREATE TABLE cc (a BIGINT,b BIGINT,FOREIGN KEY(a,b) REFERENCES composite(a,b))",
    )
    .unwrap();
    db.execute(1, "INSERT INTO composite VALUES(1,2)").unwrap();
    db.execute(1, "INSERT INTO cc VALUES(1,2),(1,NULL)")
        .unwrap();
    assert!(db.execute(1, "INSERT INTO cc VALUES(1,3)").is_err());
    assert!(db.execute(1, "DELETE FROM composite").is_err());
    db.check_online().unwrap();
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn foreign_keys_crash_boundaries() {
    const TEST: &str = "mvcc_runtime::foreign_key_tests::foreign_keys_crash_boundaries";
    if let Ok(point) = std::env::var("PHOBOS_FK_POINT") {
        let root = PathBuf::from(std::env::var_os("PHOBOS_FK_ROOT").unwrap());
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(
            1,
            "INSERT INTO generated(name) VALUES ('crash') RETURNING id",
        )
        .unwrap();
        db.execute(
            1,
            "CREATE VIEW generated_view AS SELECT id,name FROM generated",
        )
        .unwrap();
        let _hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |at| {
                if at == point {
                    std::process::exit(86)
                }
            }),
        );
        db.execute(1, "COMMIT").unwrap();
        std::process::exit(87);
    }
    for point in [
        "c6_private_redo_staged",
        "wal.before_force",
        "wal.after_force",
        "mvcc.before_publication",
        "mvcc.after_publication",
    ] {
        let root = tests::fixture();
        {
            let db = MvccDatabase::open(&root).unwrap();
            db.execute(1, "CREATE TABLE parent (id BIGINT PRIMARY KEY)")
                .unwrap();
            db.execute(1, "INSERT INTO parent VALUES(7)").unwrap();
            db.execute(1,"CREATE TABLE generated (id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name TEXT, amount BIGINT DEFAULT 7, FOREIGN KEY(amount) REFERENCES parent(id))").unwrap();
            db.execute(1, "INSERT INTO generated(name) VALUES ('seed')")
                .unwrap();
            db.disconnect(1);
        }
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env("PHOBOS_FK_POINT", point)
            .env("PHOBOS_FK_ROOT", &root)
            .output()
            .unwrap();
        assert_eq!(
            output.status.code(),
            Some(86),
            "{point}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        for _ in 0..2 {
            let db = MvccDatabase::open(&root).unwrap();
            let count = rows(db.execute(1, "SELECT * FROM generated").unwrap()).len();
            assert!(count == 1 || count == 2);
            if !matches!(point, "c6_private_redo_staged" | "wal.before_force") {
                assert_eq!(count, 2);
            }
            db.execute(1, "BEGIN").unwrap();
            assert_eq!(
                rows(
                    db.execute(
                        1,
                        "INSERT INTO generated(name) VALUES ('verify') RETURNING id"
                    )
                    .unwrap()
                )[0]
                .values[0],
                Value::Int64(count as i64 + 1)
            );
            db.execute(1, "ROLLBACK").unwrap();
            db.check_online().unwrap();
            db.disconnect(1);
        }
        fs::remove_dir_all(root).unwrap();
    }
}
