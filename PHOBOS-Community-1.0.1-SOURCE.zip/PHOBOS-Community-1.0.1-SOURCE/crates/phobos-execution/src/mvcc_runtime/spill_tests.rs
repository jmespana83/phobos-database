//! 0.1.9-A4: bounded-memory transaction write spilling.
//!
//! Every test uses the C5 runtime fixture (`t(id,v,g)` with 1000 committed
//! rows, unique index `u(id)`, composite unique `c(v,g)`, and `big`). A
//! 4 KiB memtable threshold makes an ordinary statement spill dozens of
//! sorted runs, so the whole path (memtable, runs, read-your-own-writes,
//! same-transaction UNIQUE, streaming commit, cleanup) is exercised with a
//! few thousand rows.
use super::*;
use spill::SpillFault;
use std::{sync::atomic::Ordering, time::Duration};
use tests::fixture;

const TINY: usize = 4096;
const QUOTA: u64 = 64 * 1024 * 1024;

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            Value::Null => 0,
            ref other => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}
fn spill_dirs(root: &Path) -> Vec<PathBuf> {
    fs::read_dir(root)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| {
            path.file_name()
                .unwrap()
                .to_string_lossy()
                .starts_with(".phobos-mvcc-writes-")
        })
        .collect()
}
fn with_writes<T>(db: &MvccDatabase, session: u64, f: impl FnOnce(&mut SessionWrites) -> T) -> T {
    let connection = db.connection(session).unwrap();
    let mut connection = connection.lock().unwrap();
    f(connection.writes.as_mut().expect("active transaction"))
}
fn stats(db: &MvccDatabase, session: u64) -> SpillStats {
    with_writes(db, session, |writes| writes.spill_stats())
}
fn values_sql(from: i64, to: i64, v: impl Fn(i64) -> i64) -> String {
    (from..to)
        .map(|id| format!("({id},{},NULL)", v(id)))
        .collect::<Vec<_>>()
        .join(",")
}
fn open_tiny() -> (PathBuf, MvccDatabase) {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.set_write_spill(TINY, QUOTA).unwrap();
    (root, db)
}

/// Before A4 the 64 MiB session budget was a hard transaction-size ceiling:
/// the in-memory-only constructor still behaves that way (bulk batches and
/// legacy callers), and the same tiny budget as a spill threshold accepts
/// the same statements while keeping the memtable bounded.
#[test]
fn a4_before_fix_tiny_write_budget_is_a_hard_ceiling() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let insert = |writes: &mut SessionWrites, session: &Session| {
        let mut staged = 0;
        let mut failure = None;
        for id in 0..40 {
            match db.stage(
                session,
                writes,
                &format!("INSERT INTO t VALUES ({},{},NULL)", 5000 + id, id),
                &[],
            ) {
                Ok(_) => staged += 1,
                Err(error) => {
                    failure = Some(error);
                    break;
                }
            }
        }
        (staged, failure)
    };
    let session = db.connect(11).unwrap();
    let mut writes = SessionWrites::new(session.begin().unwrap(), 2048).unwrap();
    assert!(!writes.spill_enabled());
    let (staged, failure) = insert(&mut writes, &session);
    let failure = failure.expect("in-memory-only writes hit the ceiling");
    assert_eq!(failure.code, ErrorCode::ResourceLimit);
    assert!(
        failure
            .message
            .contains("session write memory limit exceeded")
    );
    assert!(staged < 40, "ceiling reached after {staged} rows");
    drop(writes);
    session.rollback().unwrap();
    let session = db.connect(12).unwrap();
    let mut writes =
        SessionWrites::spilling(session.begin().unwrap(), 64 << 20, 2048, &root, QUOTA).unwrap();
    assert!(writes.spill_enabled());
    let (staged, failure) = insert(&mut writes, &session);
    assert!(failure.is_none(), "{failure:?}");
    assert_eq!(staged, 40);
    let stats = writes.spill_stats();
    assert!(stats.runs > 0 && stats.spilled_changes > 0, "{stats:?}");
    assert!(writes.memtable_bytes() <= 2048);
    assert_eq!(writes.changes().unwrap().count(), 40);
    assert_eq!(spill_dirs(&root).len(), 1);
    drop(writes);
    assert!(spill_dirs(&root).is_empty());
    session.rollback().unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_large_insert_update_delete_spill_and_commit() {
    let (root, db) = open_tiny();
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", values_sql(1000, 1500, |id| id)),
    )
    .unwrap();
    let after_insert = stats(&db, 1);
    assert!(after_insert.runs > 0, "{after_insert:?}");
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=1400").unwrap();
    let pending = stats(&db, 1);
    assert!(pending.runs > after_insert.runs, "{pending:?}");
    assert!(pending.peak_memtable_bytes <= TINY + 256, "{pending:?}");
    assert_eq!(spill_dirs(&root).len(), 1);
    // Another session sees nothing until COMMIT.
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1000);
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM t"), 499_500);
    db.execute(1, "COMMIT").unwrap();
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1400);
    // Every surviving row gained one: 0..1400 summed plus 1400.
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM t"), 979_300 + 1400);
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=1399"), 1400);
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id>=1400"),
        0
    );
    db.disconnect(1);
    db.disconnect(2);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_multiple_statements_spill_cumulatively() {
    let (root, db) = open_tiny();
    db.execute(1, "BEGIN").unwrap();
    let mut first_spill = None;
    for id in 0..120 {
        db.execute(
            1,
            &format!("INSERT INTO t VALUES ({},{id},NULL)", 3000 + id),
        )
        .unwrap();
        let stats = stats(&db, 1);
        if stats.runs > 0 && first_spill.is_none() {
            first_spill = Some(id + 1);
        }
    }
    let statements = first_spill.expect("single-row statements spilled cumulatively");
    assert!(
        statements > 5,
        "each statement fits alone: first spill after {statements}"
    );
    let stats = stats(&db, 1);
    assert!(stats.runs >= 2, "{stats:?}");
    assert_eq!(with_writes(&db, 1, |w| w.changes().unwrap().count()), 120);
    db.execute(1, "COMMIT").unwrap();
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id>=3000"),
        120
    );
    assert_eq!(
        scalar(&db, 2, "SELECT SUM(v) AS s FROM t WHERE id>=3000"),
        7140
    );
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_read_your_own_writes_after_spill() {
    let (root, db) = open_tiny();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v+1000").unwrap();
    assert!(stats(&db, 1).runs > 0);
    // Sequential scan, index probe (unique u(id)) and aggregates all see the
    // spilled own image; the memtable holds only the tail of the update.
    assert_eq!(
        scalar(&db, 1, "SELECT SUM(v) AS s FROM t"),
        499_500 + 1_000_000
    );
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=5"), 1005);
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=999"), 1999);
    assert_eq!(
        scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE v>=1000"),
        1000
    );
    db.execute(1, "INSERT INTO t VALUES (2000,1,NULL)").unwrap();
    db.execute(1, "DELETE FROM t WHERE id=7").unwrap();
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 1000);
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id=7"), 0);
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=2000"), 1);
    assert_eq!(
        scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id>=2000"),
        1
    );
    // Own writes are bounded in memory while fully readable.
    let stats = stats(&db, 1);
    assert!(stats.peak_memtable_bytes <= TINY + 256, "{stats:?}");
    assert!(with_writes(&db, 1, |w| w.memtable_bytes()) <= TINY);
    // Other sessions keep the committed image.
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5"), 5);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1000);
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5"), 1005);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=7"), 0);
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1000);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// A→B→C ⇒ C; UPDATE then DELETE ⇒ DELETE; INSERT then UPDATE ⇒ updated
/// INSERT, with spills between every step so each newer version lands in a
/// newer run or the memtable while older versions stay on disk.
#[test]
fn a4_repeated_changes_to_same_row_across_spills() {
    let (root, db) = open_tiny();
    let filler = |db: &MvccDatabase, from: i64| {
        db.execute(
            1,
            &format!(
                "INSERT INTO t VALUES {}",
                values_sql(from, from + 60, |_| 0)
            ),
        )
        .unwrap();
    };
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=1 WHERE id<50").unwrap();
    filler(&db, 10_000);
    db.execute(1, "UPDATE t SET v=2 WHERE id<50").unwrap();
    filler(&db, 10_100);
    db.execute(1, "UPDATE t SET v=3 WHERE id<50").unwrap();
    db.execute(1, "UPDATE t SET v=99 WHERE id=60").unwrap();
    filler(&db, 10_200);
    db.execute(1, "DELETE FROM t WHERE id=60").unwrap();
    db.execute(1, "INSERT INTO t VALUES (5000,1,NULL)").unwrap();
    filler(&db, 10_300);
    db.execute(1, "UPDATE t SET v=42 WHERE id=5000").unwrap();
    filler(&db, 10_400);
    db.execute(1, "INSERT INTO t VALUES (5001,1,NULL)").unwrap();
    filler(&db, 10_500);
    db.execute(1, "DELETE FROM t WHERE id=5001").unwrap();
    let stats = stats(&db, 1);
    assert!(stats.runs >= 6, "{stats:?}");
    // One pending change per distinct logical row: 50 + 1 + 1 + 1 + 6*60.
    assert_eq!(
        with_writes(&db, 1, |w| w.changes().unwrap().count()),
        50 + 3 + 360
    );
    let check = |session: u64| {
        assert_eq!(
            scalar(&db, session, "SELECT SUM(v) AS s FROM t WHERE id<50"),
            150
        );
        assert_eq!(
            scalar(&db, session, "SELECT COUNT(*) AS n FROM t WHERE v=3"),
            50
        );
        assert_eq!(
            scalar(&db, session, "SELECT COUNT(*) AS n FROM t WHERE id=60"),
            0
        );
        assert_eq!(scalar(&db, session, "SELECT v FROM t WHERE id=5000"), 42);
        assert_eq!(
            scalar(&db, session, "SELECT COUNT(*) AS n FROM t WHERE id=5001"),
            0
        );
        assert_eq!(
            scalar(&db, session, "SELECT COUNT(*) AS n FROM t"),
            1000 - 1 + 1 + 360
        );
    };
    check(1);
    db.execute(1, "COMMIT").unwrap();
    assert!(spill_dirs(&root).is_empty());
    check(2);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_rollback_removes_spill_files() {
    let (root, db) = open_tiny();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    let dirs = spill_dirs(&root);
    assert_eq!(dirs.len(), 1);
    assert!(fs::read_dir(&dirs[0]).unwrap().count() >= 2);
    db.execute(1, "ROLLBACK").unwrap();
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(scalar(&db, 1, "SELECT SUM(v) AS s FROM t"), 499_500);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_cancellation_timeout_and_disconnect_remove_spill_state() {
    use phobos_error::cancellation::StatementContext;
    use std::sync::mpsc;
    let (root, db) = open_tiny();
    // Out-of-band cancel while the statement is spilling: the run write is
    // the interruption point, and the failed transaction leaves no scratch.
    let context = StatementContext::new("update".into(), None);
    let token = context.token.clone();
    let (spilled, observed) = mpsc::channel();
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |point| {
            if point == "a4_spill_run_written" {
                let _ = spilled.send(());
                token.cancel();
            }
        }),
    );
    db.execute(1, "BEGIN").unwrap();
    let error = {
        let _scope = context.enter();
        db.execute(1, "UPDATE t SET v=v+1").unwrap_err()
    };
    observed.recv_timeout(Duration::from_secs(20)).unwrap();
    assert_eq!(error.code, ErrorCode::StatementCancelled);
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::TransactionState
    );
    db.execute(1, "ROLLBACK").unwrap();
    drop(hook);
    // Expire the test clock at the first written run. A wall-clock deadline
    // can otherwise expire before this hook under slower/parallel Windows I/O.
    let (spilled, observed) = mpsc::channel();
    let first = std::sync::atomic::AtomicBool::new(true);
    let context = StatementContext::new("update".into(), None);
    let hook = phobos_observability::test_hooks::register(
        &root,
        Arc::new(move |point| {
            if point == "a4_spill_run_written" && first.swap(false, Ordering::Relaxed) {
                let _ = spilled.send(());
                phobos_error::cancellation::test_hooks::expire_current();
            }
        }),
    );
    db.execute(1, "BEGIN").unwrap();
    let error = {
        let _scope = context.enter();
        db.execute(1, "UPDATE t SET v=v+1").unwrap_err()
    };
    assert_eq!(error.code, ErrorCode::StatementTimeout, "{error:?}");
    observed.recv_timeout(Duration::from_secs(20)).unwrap();
    assert!(spill_dirs(&root).is_empty());
    db.execute(1, "ROLLBACK").unwrap();
    drop(hook);
    // Disconnect with a spilled transaction open.
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    assert_eq!(spill_dirs(&root).len(), 1);
    db.disconnect(1);
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM t"), 499_500);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_scratch_quota_exceeded_fails_cleanly() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.set_write_spill(TINY, 24 * 1024).unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (2000,1,NULL)").unwrap();
    let error = db.execute(1, "UPDATE t SET v=v+1").unwrap_err();
    assert_eq!(error.code, ErrorCode::ResourceLimit, "{error:?}");
    assert!(
        error.message.contains("scratch quota exceeded"),
        "{}",
        error.message
    );
    // The failed statement left no partial run behind and the pending set
    // is still readable; the transaction requires ROLLBACK (nothing of it
    // can ever commit) and the database is not fenced.
    assert!(with_writes(&db, 1, |w| w.changes().unwrap().count()) >= 1);
    assert!(with_writes(&db, 1, |w| w.spill_stats().spilled_bytes) <= 24 * 1024);
    let dirs = spill_dirs(&root);
    for dir in &dirs {
        for entry in fs::read_dir(dir).unwrap() {
            let name = entry.unwrap().file_name().to_string_lossy().into_owned();
            assert!(name.starts_with("run-"), "{name}");
        }
    }
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::TransactionState
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1000);
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "UPDATE t SET v=v+1 WHERE id<20").unwrap();
    db.execute(2, "COMMIT").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM t"), 499_520);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_injected_spill_write_and_read_errors_fail_cleanly() {
    let (root, db) = open_tiny();
    // Run write fails (ENOSPC-like) before any byte is written.
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (2000,1,NULL)").unwrap();
    with_writes(&db, 1, |w| w.arm_spill_fault(SpillFault::WriteFails)).unwrap();
    let error = db.execute(1, "UPDATE t SET v=v+1").unwrap_err();
    assert_eq!(error.code, ErrorCode::Io, "{error:?}");
    assert!(error.message.contains("spill run write failed"));
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(
        db.execute(1, "COMMIT").unwrap_err().code,
        ErrorCode::TransactionState
    );
    db.execute(1, "ROLLBACK").unwrap();
    // Reads of spilled changes fail: read-your-own-writes and COMMIT both
    // report the I/O error before any irrevocable step; nothing is fenced.
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    assert!(stats(&db, 1).runs > 0);
    with_writes(&db, 1, |w| w.arm_spill_fault(SpillFault::ReadFails)).unwrap();
    let error = db.execute(1, "SELECT SUM(v) AS s FROM t").unwrap_err();
    assert_eq!(error.code, ErrorCode::Io, "{error:?}");
    let error = db.execute(1, "COMMIT").unwrap_err();
    assert!(
        matches!(error.code, ErrorCode::Io | ErrorCode::TransactionState),
        "{error:?}"
    );
    let _ = db.execute(1, "ROLLBACK");
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM t"), 499_500);
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "UPDATE t SET v=v+1").unwrap();
    db.execute(2, "COMMIT").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT SUM(v) AS s FROM t"), 500_500);
    db.disconnect(1);
    db.disconnect(2);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Crash (process exit without COMMIT) with a spilled transaction open: the
/// child leaves its scratch directory behind; reopening exposes none of the
/// pending changes and housekeeping removes the directory.
#[test]
fn a4_uncommitted_spilled_transaction_exposes_nothing_after_crash() {
    if let Ok(root) = std::env::var("PHOBOS_A4_CRASH_CHILD") {
        let db = MvccDatabase::open(Path::new(&root)).unwrap();
        db.set_write_spill(TINY, QUOTA).unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "UPDATE t SET v=v+1").unwrap();
        db.execute(1, "INSERT INTO t VALUES (2000,1,NULL)").unwrap();
        assert_eq!(spill_dirs(Path::new(&root)).len(), 1);
        std::process::exit(0);
    }
    let root = fixture();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .arg("--exact")
        .arg("mvcc_runtime::spill_tests::a4_uncommitted_spilled_transaction_exposes_nothing_after_crash")
        .arg("--nocapture")
        .env("PHOBOS_A4_CRASH_CHILD", &root)
        .status()
        .unwrap();
    assert!(status.success());
    assert_eq!(spill_dirs(&root).len(), 1, "crash left scratch behind");
    let db = MvccDatabase::open(&root).unwrap();
    assert!(spill_dirs(&root).is_empty(), "housekeeping removed it");
    assert_eq!(scalar(&db, 1, "SELECT SUM(v) AS s FROM t"), 499_500);
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 1000);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn a4_canonical_unique_holds_across_spilled_writes() {
    let (root, db) = open_tiny();
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", values_sql(2000, 2300, |id| id)),
    )
    .unwrap();
    assert!(stats(&db, 1).runs > 0);
    // Duplicate of a spilled pending row, of a committed row, and an UPDATE
    // moving a spilled row onto another spilled row's key.
    for sql in [
        "INSERT INTO t VALUES (2005,1,NULL)",
        "INSERT INTO t VALUES (5,1,NULL)",
        "UPDATE t SET id=2007 WHERE id=2299",
    ] {
        db.execute(1, "ROLLBACK").unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(
            1,
            &format!("INSERT INTO t VALUES {}", values_sql(2000, 2300, |id| id)),
        )
        .unwrap();
        let error = db.execute(1, sql).unwrap_err();
        assert_eq!(
            error.code,
            ErrorCode::ConstraintViolation,
            "{sql}: {error:?}"
        );
    }
    db.execute(1, "ROLLBACK").unwrap();
    // Keys freed by spilled own updates/deletes are reusable in the same
    // transaction; keys taken by spilled own inserts are not.
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET id=id+5000 WHERE id<100")
        .unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=900 AND id<1000")
        .unwrap();
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", values_sql(2000, 2200, |id| id)),
    )
    .unwrap();
    assert!(stats(&db, 1).runs > 3);
    db.execute(1, "INSERT INTO t VALUES (5,5,NULL),(950,950,NULL)")
        .unwrap();
    let error = db
        .execute(1, "INSERT INTO t VALUES (5005,1,NULL)")
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::ConstraintViolation);
    db.execute(1, "ROLLBACK").unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET id=id+5000 WHERE id<100")
        .unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=900 AND id<1000")
        .unwrap();
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", values_sql(2000, 2200, |id| id)),
    )
    .unwrap();
    db.execute(1, "INSERT INTO t VALUES (5,5,NULL),(950,950,NULL)")
        .unwrap();
    db.execute(1, "DELETE FROM t WHERE id=2100").unwrap();
    db.execute(1, "INSERT INTO t VALUES (2100,7,NULL)").unwrap();
    db.execute(1, "COMMIT").unwrap();
    assert!(spill_dirs(&root).is_empty());
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"),
        1000 - 100 + 200 + 2
    );
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5005"), 5);
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5"), 5);
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=2100"), 7);
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=999"),
        0
    );
    // The committed unique index is consistent: a duplicate is still rejected.
    assert_eq!(
        db.execute(2, "INSERT INTO t VALUES (5005,1,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    db.disconnect(1);
    db.disconnect(2);
    db.shutdown(Duration::from_secs(10)).unwrap();
    // Reopen validates canonical uniqueness over the committed state.
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=5005"), 5);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Default settings: ordinary transactions never touch the spill path, and
/// the default 64 MiB budget is wired as a spill threshold, not a ceiling.
#[test]
fn a4_small_transactions_stay_on_fast_path_with_default_threshold() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(db.write_spill(), (64 << 20, DEFAULT_SCRATCH_QUOTA));
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    db.execute(1, "INSERT INTO t VALUES (2000,1,NULL)").unwrap();
    db.execute(1, "DELETE FROM t WHERE id=3").unwrap();
    with_writes(&db, 1, |writes| {
        assert!(writes.spill_enabled());
        assert_eq!(writes.spill_threshold(), 64 << 20);
        let stats = writes.spill_stats();
        assert_eq!(stats.runs, 0);
        assert_eq!(stats.spilled_changes, 0);
        assert!(writes.memtable_bytes() > 0);
    });
    assert!(spill_dirs(&root).is_empty());
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(
        scalar(&db, 1, "SELECT SUM(v) AS s FROM t"),
        499_500 + 1000 - 4 + 1
    );
    // Autocommit statements take the same constructor.
    db.execute(1, "UPDATE t SET v=v+1 WHERE id<10").unwrap();
    assert!(spill_dirs(&root).is_empty());
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Bounded-memory instrumentation: the charged memtable never exceeds the
/// threshold by more than one change, and COMMIT streams the spilled runs
/// (at most one buffered record per source) instead of rehydrating them.
#[test]
fn a4_bounded_memory_peak_memtable_and_streaming_commit() {
    let (root, db) = open_tiny();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "UPDATE t SET v=v+1").unwrap();
    db.execute(
        1,
        &format!("INSERT INTO t VALUES {}", values_sql(2000, 2500, |id| id)),
    )
    .unwrap();
    let (stats, probe) = with_writes(&db, 1, |w| (w.spill_stats(), w.merge_peak_probe()));
    assert!(stats.runs >= 20, "{stats:?}");
    assert_eq!(with_writes(&db, 1, |w| w.changes().unwrap().count()), 1500);
    assert!(stats.spilled_changes >= 1400, "{stats:?}");
    assert!(stats.peak_memtable_bytes <= TINY + 256, "{stats:?}");
    assert!(stats.spilled_bytes > 0 && stats.spilled_bytes < 2 * 1024 * 1024);
    let runs = stats.runs as usize;
    probe.store(0, std::sync::atomic::Ordering::Relaxed);
    db.execute(1, "COMMIT").unwrap();
    let peak = probe.load(std::sync::atomic::Ordering::Relaxed);
    assert!(
        peak > 1 && peak <= runs + 1,
        "commit buffered {peak} records over {runs} runs"
    );
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 1500);
    assert_eq!(
        scalar(&db, 2, "SELECT SUM(v) AS s FROM t WHERE id<1000"),
        500_500
    );
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Concurrent spilling writers on disjoint rows commit independently; each
/// has its own scratch directory and both are removed.
#[test]
fn a4_concurrent_spilled_transactions_commit_in_both_orders() {
    let (root, db) = open_tiny();
    let db = Arc::new(db);
    for order in 0..2u8 {
        let workers = (0..2u8)
            .map(|worker| {
                let db = db.clone();
                std::thread::spawn(move || {
                    let session = 10 + u64::from(worker);
                    db.execute(session, "BEGIN").unwrap();
                    let (low, high) = if worker == 0 { (0, 500) } else { (500, 1000) };
                    db.execute(
                        session,
                        &format!("UPDATE t SET v=v+1 WHERE id>={low} AND id<{high}"),
                    )
                    .unwrap();
                    assert!(stats(&db, session).runs > 0);
                    if worker == order {
                        std::thread::sleep(Duration::from_millis(50));
                    }
                    db.execute(session, "COMMIT").unwrap();
                    db.disconnect(session);
                })
            })
            .collect::<Vec<_>>();
        for worker in workers {
            worker.join().unwrap();
        }
        assert!(spill_dirs(&root).is_empty());
        assert_eq!(
            scalar(&db, 1, "SELECT SUM(v) AS s FROM t"),
            499_500 + 1000 * (i64::from(order) + 1)
        );
    }
    db.disconnect(1);
    fs::remove_dir_all(root).unwrap();
}
