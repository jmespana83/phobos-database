//! Recovery owns the directory lock before removing abandoned private state.
use super::*;

fn reparse(metadata: &fs::Metadata) -> bool {
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        metadata.file_attributes() & 0x400 != 0
    }
    #[cfg(not(windows))]
    {
        metadata.file_type().is_symlink()
    }
}
fn validate_tree(directory: &Path, root: &Path) -> Result<(), PhobosError> {
    let metadata = fs::symlink_metadata(directory)?;
    if reparse(&metadata) || !fs::canonicalize(directory)?.starts_with(root) {
        return Err(write_conflict(
            "abandoned directory contains a link or escapes database",
        ));
    }
    if metadata.is_dir() {
        for child in fs::read_dir(directory)? {
            validate_tree(&child?.path(), root)?;
        }
    } else if !metadata.is_file() {
        return Err(write_conflict("unexpected private file type"));
    }
    Ok(())
}
pub(super) fn cleanup(directory: &Path, catalog: &Catalog) -> Result<(), PhobosError> {
    let root = fs::canonicalize(directory)?;
    for entry in fs::read_dir(&root)? {
        let path = entry?.path();
        let Some(name) = path.file_name().and_then(|name| name.to_str()) else {
            continue;
        };
        let scratch = [
            ".phobos-mvcc-private-",
            ".phobos-retired-private-",
            ".phobos-mvcc-schema-",
            ".phobos-mvcc-bulk-",
            ".phobos-mvcc-writes-",
        ]
        .iter()
        .any(|prefix| {
            name.strip_prefix(prefix)
                .is_some_and(|id| id.parse::<u64>().is_ok_and(|id| id > 0))
        });
        if scratch {
            validate_tree(&path, &root)?;
            if !path.is_dir() {
                return Err(write_conflict("private scratch must be a directory"));
            }
            fs::remove_dir_all(path)?;
            continue;
        }
        let orphan = [("table-", ".heap", true), ("index-", ".idx", false)]
            .iter()
            .any(|(prefix, suffix, heap)| {
                name.strip_prefix(prefix)
                    .and_then(|name| name.strip_suffix(suffix))
                    .filter(|id| id.len() == 16)
                    .and_then(|id| u64::from_str_radix(id, 16).ok())
                    .is_some_and(|id| {
                        if *heap {
                            !catalog.tables().any(|table| table.id == id)
                        } else {
                            !catalog.indexes().any(|index| index.id == id)
                        }
                    })
            });
        if orphan {
            let metadata = fs::symlink_metadata(&path)?;
            if !metadata.is_file() || reparse(&metadata) {
                return Err(write_conflict("orphan page file is not a regular file"));
            }
            fs::remove_file(path)?;
        }
    }
    Ok(())
}
