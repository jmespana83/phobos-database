//! F5 live operational snapshots. Publication is briefly serialized while
//! durable files are forced/copied or structurally inspected; statement readers
//! retain their normal committed snapshots.
use super::*;
use phobos_index::{Bound, IndexKey};
use std::{fs, fs::OpenOptions, io::Write, path::Path};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct OnlineBackupReport {
    pub start_lsn: u64,
    pub end_lsn: u64,
    pub files_copied: usize,
    pub wal_files_copied: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct OnlineCheckReport {
    pub tables: usize,
    pub indexes: usize,
    pub index_pages: usize,
    /// 0.2-K.4: live / stale index entries (stale only legal for non-unique
    /// indexes under LAZY_INDEX_PRUNING_V1).
    pub index_live_entries: u64,
    pub index_stale_entries: u64,
}

fn operational(message: impl Into<String>) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}

fn durable_file(path: &Path) -> bool {
    let name = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("");
    matches!(
        path.extension().and_then(|extension| extension.to_str()),
        Some("phc" | "heap" | "idx" | "wal" | "txn" | "stats" | "seg")
    ) || matches!(
        name,
        "phobos.wal.gen"
            | "phobos.auth"
            | "phobos.mvcc-status"
            | "phobos.mvcc-freeze"
            | "phobos.system-id"
    )
}

impl MvccDatabase {
    pub fn wal_position(&self) -> Result<(u64, u64), PhobosError> {
        let wal = self
            .wal
            .lock()
            .map_err(|_| operational("WAL poisoned while reading its position"))?;
        Ok((wal.durable_lsn(), wal.last_commit_lsn()))
    }

    pub fn backup_online(&self, destination: &Path) -> Result<OnlineBackupReport, PhobosError> {
        if destination.exists() && fs::read_dir(destination)?.next().is_some() {
            return Err(PhobosError::new(
                ErrorCode::AlreadyExists,
                "online backup destination must be empty",
            ));
        }
        fs::create_dir_all(destination)?;
        phobos_wal::v2::ensure_system_id(&self.data_dir)?;
        let destination = fs::canonicalize(destination)?;
        if destination.starts_with(&self.data_dir) || self.data_dir.starts_with(&destination) {
            return Err(operational(
                "online backup must be outside the database directory",
            ));
        }
        let _order = self
            .lock_commits_quiescent()
            .map_err(|_| operational("commit order poisoned during online backup"))?;
        let mut database = self.lock_database()?;
        database
            .committed_store
            .as_ref()
            .expect("MVCC store")
            .cancel_checkpoint()?;
        for heap in database.heaps.values_mut() {
            heap.force_committed()?;
        }
        for tree in database.indexes.values_mut() {
            tree.force_committed()?;
        }
        let mut wal = self
            .wal
            .lock()
            .map_err(|_| operational("WAL poisoned during online backup"))?;
        let start_lsn = wal.last_commit_lsn();
        self.sessions.checkpoint(&mut wal)?;
        let end_lsn = wal.last_commit_lsn();

        let mut files = fs::read_dir(&self.data_dir)?
            .filter_map(|entry| entry.ok().map(|entry| entry.path()))
            .filter(|path| path.is_file() && durable_file(path))
            .collect::<Vec<_>>();
        files.sort();
        let mut wal_files = 0;
        for source in &files {
            let name = source
                .file_name()
                .ok_or_else(|| operational("database file has no name"))?;
            if name.to_string_lossy().starts_with("phobos.wal") {
                wal_files += 1;
            }
            fs::copy(source, destination.join(name))?;
        }
        let marker = destination.join("PHOBOS_BACKUP_2");
        let mut marker_file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(marker)?;
        writeln!(marker_file, "start_lsn={start_lsn}")?;
        writeln!(marker_file, "end_lsn={end_lsn}")?;
        marker_file.sync_all()?;
        for path in fs::read_dir(&destination)? {
            let path = path?.path();
            if path.is_file() {
                OpenOptions::new().write(true).open(path)?.sync_all()?;
            }
        }
        Ok(OnlineBackupReport {
            start_lsn,
            end_lsn,
            files_copied: files.len(),
            wal_files_copied: wal_files,
        })
    }

    pub fn check_online(&self) -> Result<OnlineCheckReport, PhobosError> {
        let _order = self
            .lock_commits_quiescent()
            .map_err(|_| operational("commit order poisoned during online check"))?;
        let mut database = self.lock_database()?;
        database.catalog.validate_definitions()?;
        let tables = database.catalog.tables().cloned().collect::<Vec<_>>();
        let indexes = database.catalog.indexes().cloned().collect::<Vec<_>>();
        let mut index_pages = 0;
        let lazy = database.catalog.lazy_index_pruning();
        let (mut live_entries, mut stale_entries) = (0u64, 0u64);
        for table in &tables {
            if !database.heaps.contains_key(&table.id) {
                return Err(operational("catalog heap is missing"));
            }
        }
        for definition in &indexes {
            let columns = definition
                .columns
                .iter()
                .map(|name| {
                    tables
                        .iter()
                        .find(|table| table.id == definition.table_id)
                        .and_then(|table| table.column_index(name))
                        .ok_or_else(|| operational("index column is missing"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let entries = {
                let tree = database
                    .indexes
                    .get_mut(&definition.id)
                    .ok_or_else(|| operational("catalog index is missing"))?;
                index_pages += tree.validate()?.pages;
                let mut entries = Vec::new();
                tree.inspect_entries(|key, rid| {
                    entries.push((key.clone(), rid));
                    Ok(true)
                })?;
                entries
            };
            let heap = database
                .heaps
                .get_mut(&definition.table_id)
                .ok_or_else(|| operational("index table is missing"))?;
            let lazy_index = lazy && !definition.unique;
            for (key, rid) in entries {
                let Some((_, row)) = heap.get_version(rid)? else {
                    if lazy_index && heap.slot_reclaimed(rid)? {
                        stale_entries += 1;
                        continue;
                    }
                    return Err(operational("index references missing tuple"));
                };
                let expected = IndexKey(
                    columns
                        .iter()
                        .map(|column| row.values[*column].clone())
                        .collect(),
                );
                if key != expected {
                    if lazy_index {
                        stale_entries += 1;
                        continue;
                    }
                    return Err(operational("index key differs from tuple"));
                }
                live_entries += 1;
            }
            // Every physical tuple retains its matching historical index entry.
            let mut tuples = Vec::new();
            database
                .heaps
                .get_mut(&definition.table_id)
                .expect("checked heap")
                .scan_versions(|rid, _, row| {
                    let key = IndexKey(
                        columns
                            .iter()
                            .map(|column| row.values[*column].clone())
                            .collect(),
                    );
                    tuples.push((rid, key));
                    Ok(true)
                })?;
            let tree = database
                .indexes
                .get_mut(&definition.id)
                .expect("checked index");
            for (rid, key) in tuples {
                let mut found = false;
                tree.range_visit(Bound::Included(&key), Bound::Included(&key), |candidate| {
                    found |= candidate == rid;
                    Ok(true)
                })?;
                if !found {
                    return Err(operational("tuple has no matching index entry"));
                }
            }
        }
        // A full heap traversal checks page checksums, tuple envelopes, version
        // links' physical framing, and overflow chains even on tables without indexes.
        let mut snapshots =
            phobos_txn::mvcc::SnapshotRegistry::new(self.sessions.publication_state()?.0, 1)?;
        let pin = snapshots.pin(None)?;
        let mut statuses = self.sessions.as_ref();
        for table in &tables {
            let definition = database.catalog.definitions(table.id).cloned();
            database
                .heaps
                .get_mut(&table.id)
                .expect("checked heap")
                .scan_versions(|_, tuple, row| {
                    if pin.snapshot().visible(tuple.visibility, &mut statuses)? {
                        if table
                            .columns
                            .iter()
                            .zip(&row.values)
                            .any(|(c, v)| !c.nullable && v.is_null())
                        {
                            return Err(operational("visible row violates NOT NULL"));
                        }
                        if let Some(definition) = &definition {
                            definition.validate_row(&row)?;
                        }
                    }
                    Ok(true)
                })?;
        }
        snapshots.release(pin)?;
        let catalog = database.catalog.clone();
        if catalog.has_foreign_keys()
            || catalog.tables().any(|t| {
                catalog
                    .definitions(t.id)
                    .is_some_and(|d| d.identity.is_some())
            })
        {
            let mut snapshots =
                phobos_txn::mvcc::SnapshotRegistry::new(self.sessions.publication_state()?.0, 1)?;
            let pin = snapshots.pin(None)?;
            let mut statuses = self.sessions.as_ref();
            let mut live_rows = |id| {
                let mut rows = Vec::new();
                database
                    .heaps
                    .get_mut(&id)
                    .ok_or_else(|| operational("FK heap missing"))?
                    .scan_versions(|_, tuple, row| {
                        if pin.snapshot().visible(tuple.visibility, &mut statuses)? {
                            rows.push(row);
                        }
                        Ok(true)
                    })?;
                Ok(rows)
            };
            catalog.validate_identity_rows(&mut live_rows)?;
            catalog.validate_foreign_key_rows(&mut live_rows)?;

            snapshots.release(pin)?;
        }
        Ok(OnlineCheckReport {
            tables: tables.len(),
            indexes: indexes.len(),
            index_pages,
            index_live_entries: live_entries,
            index_stale_entries: stale_entries,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        io::{Seek, SeekFrom},
        sync::{Arc, Barrier},
    };

    #[test]
    fn f5_live_backup_restores_and_live_check_runs_with_writes() {
        let root = super::super::tests::fixture();
        let backup = root.with_extension("f5-backup");
        let db = Arc::new(MvccDatabase::open(&root).unwrap());
        fs::create_dir(root.join(".phobos-mvcc-bulk-uncommitted")).unwrap();
        fs::write(
            root.join(".phobos-mvcc-bulk-uncommitted").join("rows"),
            b"temporary",
        )
        .unwrap();
        let ready = Arc::new(Barrier::new(2));
        let resume = Arc::new(Barrier::new(2));
        let writer_db = db.clone();
        let writer_ready = ready.clone();
        let writer_resume = resume.clone();
        let writer = std::thread::spawn(move || {
            for id in 30_000..30_005 {
                writer_db
                    .execute(7, &format!("INSERT INTO t VALUES ({id},{id},NULL)"))
                    .unwrap();
            }
            writer_ready.wait();
            writer_resume.wait();
            for id in 30_005..30_010 {
                writer_db
                    .execute(7, &format!("INSERT INTO t VALUES ({id},{id},NULL)"))
                    .unwrap();
            }
            writer_db.disconnect(7);
        });
        ready.wait();
        let report = db.backup_online(&backup).unwrap();
        println!(
            "F5_COUNTERS start_lsn={} end_lsn={} wal_files={} restored_integrity=PASS",
            report.start_lsn, report.end_lsn, report.wal_files_copied
        );
        assert!(report.end_lsn >= report.start_lsn);
        assert!(report.wal_files_copied >= 1);
        assert!(!backup.join(".phobos-mvcc-bulk-uncommitted").exists());
        resume.wait();
        writer.join().unwrap();
        let live = db.check_online().unwrap();
        assert_eq!(live.tables, 2);
        assert_eq!(live.indexes, 3);

        let restored = MvccDatabase::open(&backup).unwrap();
        let restored_report = restored.check_online().unwrap();
        // 0.2-K.4: entry counters may differ (the live check ran after more
        // writes than the backup captured); the structural result must not.
        assert_eq!(
            (
                restored_report.tables,
                restored_report.indexes,
                restored_report.index_pages
            ),
            (live.tables, live.indexes, live.index_pages)
        );
        assert_eq!(restored_report.index_stale_entries, 0);
        let rows = restored
            .execute(8, "SELECT COUNT(*) AS n FROM t WHERE id>=30000")
            .unwrap();
        match rows {
            QueryResult::Rows { rows, .. } => {
                assert_eq!(rows[0].values, vec![Value::Int64(5)]);
            }
            _ => panic!("count did not return rows"),
        }
        restored.disconnect(8);
        restored
            .shutdown(std::time::Duration::from_secs(10))
            .unwrap();
        drop(restored);
        let db = Arc::try_unwrap(db).ok().unwrap();
        db.shutdown(std::time::Duration::from_secs(10)).unwrap();
        drop(db);
        fs::remove_dir_all(root).unwrap();
        fs::remove_dir_all(backup).unwrap();
    }

    #[test]
    fn f5_live_check_rejects_a_corrupted_uncached_heap_page() {
        let root = super::super::tests::fixture();
        let config = phobos_config::RuntimeConfig {
            page_cache_bytes: 8192,
            ..Default::default()
        };
        let db = MvccDatabase::open_with_config(&root, &config).unwrap();
        let rows = (40_000..40_500).map(|id| {
            Ok(Row::new(vec![
                Value::Int64(id),
                Value::Int64(id),
                Value::Null,
            ]))
        });
        db.bulk_load(3, "t", rows).unwrap();
        db.checkpoint().unwrap();
        let table = Catalog::open(&root).unwrap().table("t").unwrap().id;
        let path = root.join(phobos_wal::v2::FileId::Heap(table).name());
        let mut file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(path)
            .unwrap();
        file.seek(SeekFrom::Start(100)).unwrap();
        file.write_all(&[0xff]).unwrap();
        file.sync_all().unwrap();
        drop(file);
        assert!(db.check_online().is_err());
        db.disconnect(3);
        drop(db); // Deliberate external corruption: do not attempt clean shutdown.
        fs::remove_dir_all(root).unwrap();
    }
}
