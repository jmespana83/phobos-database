//! 0.1.9-A4: transaction-local spilling of pending session writes.
//!
//! `SessionWrites` keeps its pending `RowChange`s in an in-memory table
//! ("memtable") up to a spill threshold. When the next change would exceed
//! it, the whole memtable is written as one immutable **sorted run** under
//! `<data_dir>/.phobos-mvcc-writes-<stable>/` and the memtable is emptied, so
//! pending write state never holds more than about one threshold of rows in
//! memory. Every run carries three fixed-size, sorted, binary-searchable
//! sections next to its payload, so read-your-own-writes and same-transaction
//! UNIQUE checks are answered with bounded I/O instead of resident entries:
//!
//! - rows: `(table, synthetic rid) -> payload offset/len`
//! - hidden: `(table, original rid)` of every UPDATE/DELETE
//! - keys: `(unique index, hash of the canonical key, table, synthetic rid)`
//!
//! Newer sources shadow older ones: memtable, then runs newest first. Full
//! iteration (statement overlays, commit preparation) is a k-way merge over
//! the sorted memtable and runs that yields each change exactly once (newest
//! version), holding one buffered record per source. Files are scratch only:
//! they are removed when the `SessionWrites` is dropped (COMMIT, ROLLBACK,
//! failure, cancellation, disconnect) and by startup housekeeping.
use super::*;
use phobos_storage::tuple_version::TupleVersion;
use phobos_txn::mvcc::Version;
use std::{
    fs::{self, File, OpenOptions},
    io::{BufReader, BufWriter, Read, Seek, SeekFrom, Write},
    sync::Mutex,
};

/// Default per-transaction scratch quota (bytes of spilled runs).
pub const DEFAULT_SCRATCH_QUOTA: u64 = 2 * 1024 * 1024 * 1024;

pub(super) type ChangeKey = (TableId, RecordId);

const ROW_ENTRY: usize = 32;
const HIDDEN_ENTRY: usize = 24;
const KEY_ENTRY: usize = 40;
const READ_BUFFER: usize = 64 * 1024;
/// Largest encoded change a run may reference (a row is bounded by the
/// statement limit); larger lengths mean a corrupt index entry.
const MAX_CHANGE: u32 = 256 * 1024 * 1024;

#[cfg(test)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SpillFault {
    /// Writing a run fails (e.g. ENOSPC) before any byte is written.
    WriteFails,
    /// Reading a spilled record back fails.
    ReadFails,
}

/// Counters for tests and diagnostics.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct SpillStats {
    pub runs: u64,
    pub spilled_changes: u64,
    pub spilled_bytes: u64,
    /// Largest charged memtable size observed.
    pub peak_memtable_bytes: usize,
    /// Largest number of records simultaneously buffered by a merge.
    pub peak_merge_records: usize,
}

fn io(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::Io, message)
}

pub(super) fn key_hash(key: &phobos_index::LogicalUniqueKey) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    key.hash(&mut hasher);
    hasher.finish()
}

/// `(unique index, key hash)` pairs of a change's row, computed at staging.
pub(super) fn unique_hashes(
    catalog: &Catalog,
    schema: &TableSchema,
    row: &Row,
) -> Result<Vec<(IndexId, u64)>, PhobosError> {
    let mut hashes = Vec::new();
    for definition in catalog.indexes_for_table(schema.id).filter(|d| d.unique) {
        if let Some(key) = index_key_for_row(schema, definition, row)?.logical_unique_key() {
            hashes.push((definition.id, key_hash(&key)));
        }
    }
    Ok(hashes)
}

fn encode_change(change: &RowChange) -> Result<Vec<u8>, PhobosError> {
    let mut out = Vec::with_capacity(96);
    out.extend_from_slice(&change.table.to_le_bytes());
    out.extend_from_slice(&change.synthetic.page_id.to_le_bytes());
    out.extend_from_slice(&change.synthetic.slot_id.to_le_bytes());
    out.extend_from_slice(&change.logical_row.to_le_bytes());
    out.push(u8::from(change.original.is_some()) | (u8::from(change.row.is_some()) << 1));
    if let Some((rid, tuple)) = change.original {
        out.extend_from_slice(&rid.page_id.to_le_bytes());
        out.extend_from_slice(&rid.slot_id.to_le_bytes());
        out.extend_from_slice(&tuple.logical_row.to_le_bytes());
        out.extend_from_slice(&tuple.visibility.creator.to_le_bytes());
        out.extend_from_slice(&tuple.visibility.deleter.unwrap_or(0).to_le_bytes());
        out.push(u8::from(tuple.previous.is_some()));
        if let Some(previous) = tuple.previous {
            out.extend_from_slice(&previous.page_id.to_le_bytes());
            out.extend_from_slice(&previous.slot_id.to_le_bytes());
        }
    }
    let count =
        u16::try_from(change.unique_hashes.len()).map_err(|_| io("too many unique keys"))?;
    out.extend_from_slice(&count.to_le_bytes());
    for (index, hash) in &change.unique_hashes {
        out.extend_from_slice(&index.to_le_bytes());
        out.extend_from_slice(&hash.to_le_bytes());
    }
    if let Some(row) = &change.row {
        out.extend_from_slice(&encode_spill_row(row)?);
    }
    Ok(out)
}

struct Cursor<'a> {
    bytes: &'a [u8],
    at: usize,
}
impl Cursor<'_> {
    fn take<const N: usize>(&mut self) -> Result<[u8; N], PhobosError> {
        let end = self
            .at
            .checked_add(N)
            .ok_or_else(|| io("spill cursor overflow"))?;
        let slice = self
            .bytes
            .get(self.at..end)
            .ok_or_else(|| io("truncated spilled change"))?;
        self.at = end;
        Ok(slice.try_into().expect("sized"))
    }
    fn u64(&mut self) -> Result<u64, PhobosError> {
        Ok(u64::from_le_bytes(self.take::<8>()?))
    }
    fn u16(&mut self) -> Result<u16, PhobosError> {
        Ok(u16::from_le_bytes(self.take::<2>()?))
    }
    fn u8(&mut self) -> Result<u8, PhobosError> {
        Ok(self.take::<1>()?[0])
    }
    fn rid(&mut self) -> Result<RecordId, PhobosError> {
        Ok(RecordId {
            page_id: self.u64()?,
            slot_id: self.u16()?,
        })
    }
}

fn decode_change(bytes: &[u8], charge: usize) -> Result<RowChange, PhobosError> {
    let mut cursor = Cursor { bytes, at: 0 };
    let table = cursor.u64()?;
    let synthetic = cursor.rid()?;
    let logical_row = cursor.u64()?;
    let flags = cursor.u8()?;
    if flags > 3 {
        return Err(io("corrupt spilled change flags"));
    }
    let original = if flags & 1 != 0 {
        let rid = cursor.rid()?;
        let tuple_logical_row = cursor.u64()?;
        let creator = cursor.u64()?;
        let deleter = cursor.u64()?;
        let has_previous = cursor.u8()?;
        let previous = match has_previous {
            0 => None,
            1 => Some(cursor.rid()?),
            _ => return Err(io("corrupt spilled tuple")),
        };
        Some((
            rid,
            TupleVersion {
                logical_row: tuple_logical_row,
                visibility: Version {
                    creator,
                    deleter: (deleter != 0).then_some(deleter),
                },
                previous,
            },
        ))
    } else {
        None
    };
    let count = cursor.u16()?;
    let mut unique_hashes = Vec::with_capacity(usize::from(count));
    for _ in 0..count {
        let index = cursor.u64()?;
        let hash = cursor.u64()?;
        unique_hashes.push((index, hash));
    }
    let row = if flags & 2 != 0 {
        Some(decode_spill_row(&bytes[cursor.at..])?)
    } else {
        None
    };
    Ok(RowChange {
        table,
        logical_row,
        original,
        row,
        synthetic,
        unique_hashes,
        charge,
    })
}

// Index-section keys are big-endian so that byte order, numeric order and
// `BTreeMap<ChangeKey, _>` order all agree; sections can then be sorted as
// byte strings and binary-searched by byte comparison.
fn rid_bytes(out: &mut Vec<u8>, table: TableId, rid: RecordId) {
    out.extend_from_slice(&table.to_be_bytes());
    out.extend_from_slice(&rid.page_id.to_be_bytes());
    out.extend_from_slice(&rid.slot_id.to_be_bytes());
}
fn rid_key(bytes: &[u8]) -> ChangeKey {
    (
        u64::from_be_bytes(bytes[..8].try_into().expect("8")),
        RecordId {
            page_id: u64::from_be_bytes(bytes[8..16].try_into().expect("8")),
            slot_id: u16::from_be_bytes(bytes[16..18].try_into().expect("2")),
        },
    )
}

/// One immutable sorted run. All I/O goes through a mutex so a statement
/// overlay (shared with the session) and the session itself may use it.
pub(super) struct Run {
    data: Mutex<File>,
    index: Mutex<File>,
    rows: u64,
    hidden: u64,
    keys: u64,
    hidden_offset: u64,
    keys_offset: u64,
    #[cfg(test)]
    fault: Option<SpillFault>,
}

impl Run {
    #[cfg(test)]
    fn check_read(&self) -> Result<(), PhobosError> {
        if self.fault == Some(SpillFault::ReadFails) {
            return Err(io("injected: spilled write read failed"));
        }
        Ok(())
    }
    #[cfg(not(test))]
    fn check_read(&self) -> Result<(), PhobosError> {
        Ok(())
    }
    fn read_at(file: &Mutex<File>, offset: u64, bytes: &mut [u8]) -> Result<(), PhobosError> {
        let mut file = file.lock().map_err(|_| io("spill run poisoned"))?;
        file.seek(SeekFrom::Start(offset))?;
        file.read_exact(bytes)?;
        Ok(())
    }
    fn entry(&self, base: u64, size: usize, position: u64) -> Result<Vec<u8>, PhobosError> {
        let offset = position
            .checked_mul(size as u64)
            .and_then(|bytes| bytes.checked_add(base))
            .ok_or_else(|| io("spill index offset overflow"))?;
        let mut bytes = vec![0; size];
        Self::read_at(&self.index, offset, &mut bytes)?;
        Ok(bytes)
    }
    /// First entry whose key is >= `target`, by binary search over a sorted
    /// fixed-size section (keys are the leading 18 bytes in byte order, or
    /// the leading 16 bytes for the keys section).
    fn lower_bound(
        &self,
        base: u64,
        size: usize,
        count: u64,
        target: &[u8],
    ) -> Result<u64, PhobosError> {
        let (mut low, mut high) = (0u64, count);
        while low < high {
            phobos_error::cancellation::checkpoint_at("spill.lower_bound")?;
            let mid = low + (high - low) / 2;
            let entry = self.entry(base, size, mid)?;
            if entry[..target.len()] < *target {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
        Ok(low)
    }
    fn payload(&self, offset: u64, len: u32, charge: usize) -> Result<RowChange, PhobosError> {
        self.check_read()?;
        if len > MAX_CHANGE {
            return Err(io("corrupt spilled change length"));
        }
        let mut bytes = vec![0; len as usize];
        Self::read_at(&self.data, offset, &mut bytes)?;
        decode_change(&bytes, charge)
    }
    pub(super) fn find(&self, key: ChangeKey) -> Result<Option<RowChange>, PhobosError> {
        self.check_read()?;
        let mut target = Vec::with_capacity(18);
        rid_bytes(&mut target, key.0, key.1);
        let position = self.lower_bound(0, ROW_ENTRY, self.rows, &target)?;
        if position >= self.rows {
            return Ok(None);
        }
        let entry = self.entry(0, ROW_ENTRY, position)?;
        if entry[..18] != target[..] {
            return Ok(None);
        }
        let len = u32::from_le_bytes(entry[20..24].try_into().expect("4"));
        let offset = u64::from_le_bytes(entry[24..32].try_into().expect("8"));
        Ok(Some(self.payload(offset, len, 128 + len as usize)?))
    }
    pub(super) fn is_hidden(&self, table: TableId, rid: RecordId) -> Result<bool, PhobosError> {
        self.check_read()?;
        let mut target = Vec::with_capacity(18);
        rid_bytes(&mut target, table, rid);
        let position = self.lower_bound(self.hidden_offset, HIDDEN_ENTRY, self.hidden, &target)?;
        if position >= self.hidden {
            return Ok(false);
        }
        let entry = self.entry(self.hidden_offset, HIDDEN_ENTRY, position)?;
        Ok(entry[..18] == target[..])
    }
    /// Changes whose row carried `hash` for `index` when the run was written.
    pub(super) fn key_candidates(
        &self,
        index: IndexId,
        hash: u64,
    ) -> Result<Vec<ChangeKey>, PhobosError> {
        self.check_read()?;
        let mut target = Vec::with_capacity(16);
        target.extend_from_slice(&index.to_be_bytes());
        target.extend_from_slice(&hash.to_be_bytes());
        let mut position = self.lower_bound(self.keys_offset, KEY_ENTRY, self.keys, &target)?;
        let mut out = Vec::new();
        while position < self.keys {
            phobos_error::cancellation::checkpoint_at("spill.key_candidates")?;
            let entry = self.entry(self.keys_offset, KEY_ENTRY, position)?;
            if entry[..16] != target[..] {
                break;
            }
            out.push(rid_key(&entry[16..34]));
            position += 1;
        }
        Ok(out)
    }
    /// Sequential iterator in key order.
    pub(super) fn iter(self: &Arc<Self>) -> Result<RunIter, PhobosError> {
        self.check_read()?;
        let index = self
            .index
            .lock()
            .map_err(|_| io("spill run poisoned"))?
            .try_clone()?;
        let data = self
            .data
            .lock()
            .map_err(|_| io("spill run poisoned"))?
            .try_clone()?;
        let mut index = BufReader::with_capacity(READ_BUFFER, index);
        index.seek(SeekFrom::Start(0))?;
        let mut data = BufReader::with_capacity(READ_BUFFER, data);
        data.seek(SeekFrom::Start(0))?;
        Ok(RunIter {
            run: self.clone(),
            index,
            data,
            remaining: self.rows,
            next_offset: 0,
        })
    }
}

pub(super) struct RunIter {
    run: Arc<Run>,
    index: BufReader<File>,
    data: BufReader<File>,
    remaining: u64,
    next_offset: u64,
}
impl RunIter {
    pub(super) fn next_change(&mut self) -> Result<Option<(ChangeKey, RowChange)>, PhobosError> {
        if self.remaining == 0 {
            return Ok(None);
        }
        self.run.check_read()?;
        phobos_error::cancellation::checkpoint_at("spill.run_iter")?;
        let mut entry = [0u8; ROW_ENTRY];
        self.index.read_exact(&mut entry)?;
        self.remaining -= 1;
        let key = rid_key(&entry[..18]);
        let len = u32::from_le_bytes(entry[20..24].try_into().expect("4"));
        let offset = u64::from_le_bytes(entry[24..32].try_into().expect("8"));
        if len > MAX_CHANGE {
            return Err(io("corrupt spilled change length"));
        }
        if offset != self.next_offset {
            self.data.seek(SeekFrom::Start(offset))?;
        }
        let mut bytes = vec![0; len as usize];
        self.data.read_exact(&mut bytes)?;
        self.next_offset = offset
            .checked_add(u64::from(len))
            .ok_or_else(|| io("spill payload offset overflow"))?;
        Ok(Some((key, decode_change(&bytes, 128 + len as usize)?)))
    }
}

/// Owner of one transaction's runs and scratch directory.
pub(super) struct SpillStore {
    directory: PathBuf,
    created: bool,
    runs: Vec<Arc<Run>>,
    quota: u64,
    used: u64,
    pub(super) stats: SpillStats,
    #[cfg(test)]
    pub fault: Option<SpillFault>,
}

impl SpillStore {
    pub(super) fn new(data_dir: &Path, stable: u64, quota: u64) -> Self {
        Self {
            directory: data_dir.join(format!(".phobos-mvcc-writes-{stable}")),
            created: false,
            runs: Vec::new(),
            quota,
            used: 0,
            stats: SpillStats::default(),
            #[cfg(test)]
            fault: None,
        }
    }
    pub(super) fn runs(&self) -> &[Arc<Run>] {
        &self.runs
    }
    /// Discards immutable runs newer than a savepoint. Callers guarantee no
    /// statement overlay is live; ownership claims may be retained separately.
    pub(super) fn truncate(&mut self, retained: usize) -> Result<(), PhobosError> {
        if retained > self.runs.len() {
            return Err(io("invalid spill savepoint"));
        }
        let removed = self.runs.split_off(retained);
        drop(removed);
        for sequence in retained..self.stats.runs as usize {
            let data = self.directory.join(format!("run-{sequence:06}.dat"));
            let index = self.directory.join(format!("run-{sequence:06}.idx"));
            let _ = fs::remove_file(data);
            let _ = fs::remove_file(index);
        }
        self.used = 0;
        for sequence in 0..retained {
            for extension in ["dat", "idx"] {
                self.used = self
                    .used
                    .checked_add(
                        fs::metadata(
                            self.directory
                                .join(format!("run-{sequence:06}.{extension}")),
                        )?
                        .len(),
                    )
                    .ok_or_else(|| io("scratch accounting overflow"))?;
            }
        }
        self.stats.runs = retained as u64;
        self.stats.spilled_bytes = self.used;
        Ok(())
    }
    /// Writes the memtable as the newest run. The memtable must be sorted by
    /// `ChangeKey` (a `BTreeMap` is). Nothing is retained in memory per row.
    pub(super) fn flush(
        &mut self,
        memtable: &BTreeMap<ChangeKey, RowChange>,
    ) -> Result<(), PhobosError> {
        let _span = phobos_observability::span("mvcc.writes_spill");
        #[cfg(test)]
        if self.fault == Some(SpillFault::WriteFails) {
            return Err(io("injected: spill run write failed"));
        }
        if !self.created {
            // The stable identity is unique to this transaction: anything
            // already under its name is abandoned scratch.
            if self.directory.exists() {
                fs::remove_dir_all(&self.directory)?;
            }
            fs::create_dir(&self.directory)?;
            self.created = true;
        }
        let sequence = self.runs.len();
        let data_path = self.directory.join(format!("run-{sequence:06}.dat"));
        let index_path = self.directory.join(format!("run-{sequence:06}.idx"));
        let result = self.write_run(memtable, &data_path, &index_path);
        if result.is_err() {
            let _ = fs::remove_file(&data_path);
            let _ = fs::remove_file(&index_path);
        }
        if let Some(data_dir) = self.directory.parent() {
            phobos_observability::synchronization_boundary("a4_spill_run_written", data_dir);
        }
        result
    }
    fn charge_scratch(&mut self, bytes: u64) -> Result<(), PhobosError> {
        let next = self
            .used
            .checked_add(bytes)
            .ok_or_else(|| io("scratch accounting overflow"))?;
        if next > self.quota {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                format!(
                    "transaction write spill scratch quota exceeded ({} of {} bytes)",
                    next, self.quota
                ),
            ));
        }
        self.used = next;
        Ok(())
    }
    fn write_run(
        &mut self,
        memtable: &BTreeMap<ChangeKey, RowChange>,
        data_path: &Path,
        index_path: &Path,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let mut data = BufWriter::with_capacity(
            READ_BUFFER,
            OpenOptions::new()
                .read(true)
                .write(true)
                .create_new(true)
                .open(data_path)?,
        );
        let mut row_entries = Vec::with_capacity(memtable.len() * ROW_ENTRY);
        let mut hidden: Vec<Vec<u8>> = Vec::new();
        let mut keys: Vec<Vec<u8>> = Vec::new();
        let mut offset = 0u64;
        let mut changes = 0u64;
        for ((table, synthetic), change) in memtable {
            cancellation_poll.checkpoint_at("spill.write_run")?;
            let bytes = encode_change(change)?;
            let len = u32::try_from(bytes.len())
                .ok()
                .filter(|len| *len <= MAX_CHANGE)
                .ok_or_else(|| io("spilled change too large"))?;
            self.charge_scratch(u64::from(len) + ROW_ENTRY as u64)?;
            data.write_all(&bytes)?;
            rid_bytes(&mut row_entries, *table, *synthetic);
            row_entries.extend_from_slice(&[0, 0]);
            row_entries.extend_from_slice(&len.to_le_bytes());
            row_entries.extend_from_slice(&offset.to_le_bytes());
            offset = offset
                .checked_add(u64::from(len))
                .ok_or_else(|| io("spill payload offset overflow"))?;
            if let Some((rid, _)) = change.original {
                let mut entry = Vec::with_capacity(HIDDEN_ENTRY);
                rid_bytes(&mut entry, *table, rid);
                entry.resize(HIDDEN_ENTRY, 0);
                hidden.push(entry);
            }
            for (index, hash) in &change.unique_hashes {
                let mut entry = Vec::with_capacity(KEY_ENTRY);
                entry.extend_from_slice(&index.to_be_bytes());
                entry.extend_from_slice(&hash.to_be_bytes());
                rid_bytes(&mut entry, *table, *synthetic);
                entry.resize(KEY_ENTRY, 0);
                keys.push(entry);
            }
            changes += 1;
        }
        data.flush()?;
        hidden.sort_unstable();
        keys.sort_unstable();
        self.charge_scratch(((hidden.len() * HIDDEN_ENTRY) + (keys.len() * KEY_ENTRY)) as u64)?;
        let mut index = BufWriter::with_capacity(
            READ_BUFFER,
            OpenOptions::new()
                .read(true)
                .write(true)
                .create_new(true)
                .open(index_path)?,
        );
        index.write_all(&row_entries)?;
        let hidden_offset = row_entries.len() as u64;
        for entry in &hidden {
            index.write_all(entry)?;
        }
        let keys_offset = hidden_offset + (hidden.len() * HIDDEN_ENTRY) as u64;
        for entry in &keys {
            index.write_all(entry)?;
        }
        index.flush()?;
        let data = data.into_inner().map_err(|error| io(&error.to_string()))?;
        let index = index.into_inner().map_err(|error| io(&error.to_string()))?;
        self.stats.runs += 1;
        self.stats.spilled_changes += changes;
        self.stats.spilled_bytes = self.used;
        self.runs.push(Arc::new(Run {
            data: Mutex::new(data),
            index: Mutex::new(index),
            rows: memtable.len() as u64,
            hidden: hidden.len() as u64,
            keys: keys.len() as u64,
            hidden_offset,
            keys_offset,
            #[cfg(test)]
            fault: self.fault,
        }));
        Ok(())
    }
    #[cfg(test)]
    pub(super) fn arm_read_fault(&mut self) {
        self.fault = Some(SpillFault::ReadFails);
        // Runs are immutable and shared through Arc; rebuild them with the
        // fault so later statement overlays observe it too.
        let rebuilt: Vec<Arc<Run>> = self
            .runs
            .iter()
            .map(|run| {
                Arc::new(Run {
                    data: Mutex::new(run.data.lock().unwrap().try_clone().unwrap()),
                    index: Mutex::new(run.index.lock().unwrap().try_clone().unwrap()),
                    rows: run.rows,
                    hidden: run.hidden,
                    keys: run.keys,
                    hidden_offset: run.hidden_offset,
                    keys_offset: run.keys_offset,
                    fault: Some(SpillFault::ReadFails),
                })
            })
            .collect();
        self.runs = rebuilt;
    }
}
impl Drop for SpillStore {
    fn drop(&mut self) {
        self.runs.clear();
        if self.created {
            let _ = fs::remove_dir_all(&self.directory);
        }
    }
}

/// Newest-wins k-way merge over sorted sources. Source 0 is the newest.
pub(super) struct MergeIter {
    sources: Vec<Source>,
    peak: usize,
}
enum Source {
    Memory(
        std::vec::IntoIter<(ChangeKey, RowChange)>,
        Option<(ChangeKey, RowChange)>,
    ),
    Run(RunIter, Option<(ChangeKey, RowChange)>),
}
impl Source {
    fn peek(&mut self) -> Result<Option<&(ChangeKey, RowChange)>, PhobosError> {
        match self {
            Source::Memory(iter, slot) => {
                if slot.is_none() {
                    *slot = iter.next();
                }
                Ok(slot.as_ref())
            }
            Source::Run(iter, slot) => {
                if slot.is_none() {
                    *slot = iter.next_change()?;
                }
                Ok(slot.as_ref())
            }
        }
    }
    fn take(&mut self) -> Option<(ChangeKey, RowChange)> {
        match self {
            Source::Memory(_, slot) | Source::Run(_, slot) => slot.take(),
        }
    }
}
impl MergeIter {
    pub(super) fn new(
        memtable: Vec<(ChangeKey, RowChange)>,
        runs: &[Arc<Run>],
    ) -> Result<Self, PhobosError> {
        let mut sources = vec![Source::Memory(memtable.into_iter(), None)];
        for run in runs.iter().rev() {
            sources.push(Source::Run(run.iter()?, None));
        }
        Ok(Self { sources, peak: 0 })
    }
    pub(super) fn peak_records(&self) -> usize {
        self.peak
    }
    /// The next change in key order, taken from the newest source holding
    /// that key; older versions of the same key are discarded.
    pub(super) fn next_change(&mut self) -> Result<Option<RowChange>, PhobosError> {
        let mut smallest: Option<ChangeKey> = None;
        let mut buffered = 0usize;
        for source in &mut self.sources {
            if let Some((key, _)) = source.peek()? {
                buffered += 1;
                if smallest.is_none_or(|current| *key < current) {
                    smallest = Some(*key);
                }
            }
        }
        self.peak = self.peak.max(buffered);
        let Some(key) = smallest else {
            return Ok(None);
        };
        let mut chosen = None;
        for source in &mut self.sources {
            let matches = matches!(source.peek()?, Some((candidate, _)) if *candidate == key);
            if matches {
                let (_, change) = source.take().expect("peeked");
                if chosen.is_none() {
                    chosen = Some(change);
                }
            }
        }
        Ok(chosen)
    }
}
