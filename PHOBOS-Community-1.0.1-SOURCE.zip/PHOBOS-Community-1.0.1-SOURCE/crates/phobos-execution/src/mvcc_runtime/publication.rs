//! Rebase resolved logical mutations onto the latest pending/committed images.
//! C1's opaque complete-batch durability receipts remain the publication authority.
use super::*;
use phobos_storage::tuple_version::TupleVersion;
use phobos_txn::mvcc::{Version, sessions::CommitPermit};
use phobos_types::PageId;
use phobos_wal::v2::{FileId, PageAction, PendingCommit};
use std::collections::{BTreeSet, VecDeque};
use std::sync::MutexGuard;

struct Prepared {
    ticket: Option<PendingCommit>,
    bound: u64,
    tables: BTreeSet<TableId>,
    indexes: BTreeSet<IndexId>,
    root: PathBuf,
    schema: Option<Arc<super::schema::Schema>>,
    created: Vec<FileId>,
    dropped: Vec<IndexId>,
    /// C1: pages whose versions gained a deleter in this publication.
    /// Per table and page: versions that gained a deleter in this publication.
    candidate_pages: BTreeMap<TableId, BTreeMap<PageId, u32>>,
    /// 0.2-K: this publication carries a storage-lifecycle (reclaim) plan;
    /// what its page rewrites did.
    reclaim: Option<phobos_storage::PageLifecycleOutcome>,
}

/// D2: what a failure inside the commit path means for the database.
///
/// `Member`: the failing transaction alone is lost. Nothing of it is durable
/// (no WAL record was appended, no page installed, no status published) and
/// its private images have been rolled back, so it aborts like an
/// unsubmitted transaction and every other batch member proceeds. This is
/// the class of constraint/validation errors, ownership conflicts and clean
/// pre-durability I/O failures.
///
/// `Fence`: the outcome of some member is no longer certain (a WAL append or
/// force failed, a committed image could not be installed after the WAL was
/// forced, a status publication failed, or private state could not be
/// undone). The database is fenced and every unresolved member reports the
/// error; nothing is ever reported as rolled back after a durable receipt.
enum Failure {
    Member(PhobosError),
    Fence(PhobosError),
}

type MemberResults = Vec<Option<Result<(), PhobosError>>>;
type Member = (usize, CommitPermit, SessionWrites);
type StagedMember = (usize, CommitPermit, SessionWrites, Prepared);
/// Members at or below this staged-write size share one Stage A domain.
const SMALL_MEMBER_BYTES: usize = 256 * 1024;

/// 0.2-C commit-order state, guarded by `MvccDatabase::commits`.
#[derive(Default)]
pub(super) struct CommitOrder {
    /// Batches that entered Stage A and have not finished Stage B.
    in_flight: usize,
    next_batch: u64,
    /// Highest batch whose Stage B completed (batches publish in order).
    published: u64,
    /// 0.2-G: a batch is between Stage-A entry and its end. Stage A may
    /// release the commit-order lock to let an earlier batch publish (the
    /// publisher yield, the maintenance drain, the bounded inline force);
    /// no other batch may enter Stage A meanwhile, or its WAL appends would
    /// interleave with this batch's and Stage B (which receipts each batch's
    /// tickets as the oldest pending commits) would fail and fence. The SQL
    /// admission queue never has two Stage-A leaders; direct `commit`
    /// callers (dead-version reclamation) could race it before this guard.
    stage_a_active: bool,
}

/// 0.2-C single-flight WAL force state.
#[derive(Default)]
pub(super) struct ForceGate {
    running: bool,
    failed: bool,
    /// Highest WAL LSN made durable by a completed gate force.
    durable: u64,
}

/// Completes a batch's turn if its leader unwinds between Stage A and the
/// end of Stage B, so successors and maintenance never wait forever; the
/// database is fenced (a panicking commit is durability-uncertain).
struct BatchTurn<'a> {
    database: &'a MvccDatabase,
    seq: u64,
    done: bool,
}
impl Drop for BatchTurn<'_> {
    fn drop(&mut self) {
        if self.done {
            return;
        }
        self.database.fence_database();
        let mut order = self
            .database
            .commits
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        order.published = order.published.max(self.seq);
        order.in_flight = order.in_flight.saturating_sub(1);
        self.database.commit_turn.notify_all();
    }
}

impl MvccDatabase {
    pub fn commit(&self, session: &Session, writes: SessionWrites) -> Result<(), PhobosError> {
        let permit = session.submit_commit()?;
        self.commit_group(vec![(permit, writes)])
            .pop()
            .expect("one result per request")
    }

    /// Caller supplies at most 64 admitted commits. Their session-owned logical
    /// changes may have prepared concurrently, including disjoint rows on one page.
    ///
    /// D2: one result per request, in request order. A member that fails
    /// before anything of it is durable is aborted and reported alone; only
    /// a durability-uncertain failure fences the database (and is reported
    /// to every member that had not already been published).
    pub fn commit_group(
        &self,
        requests: Vec<(CommitPermit, SessionWrites)>,
    ) -> Vec<Result<(), PhobosError>> {
        self.commit_group_staged(requests, &mut || {}, &mut |_| Vec::new())
    }

    /// 0.2-C Durable Commit Engine v2. A batch runs in three stages:
    ///
    /// * Stage A, under the commit-order lock: ordered private preparation
    ///   and WAL append of every member; each member's images are staged
    ///   into the ordered pending chain (successors rebase on them, exactly as
    ///   later members of one batch always did).
    /// * Force, with no engine lock held: one physical WAL sync covers every
    ///   record written before it was captured. A later batch may run its
    ///   Stage A meanwhile; a force already covering it is not repeated.
    /// * Stage B, under the commit-order lock in batch order: receipts are
    ///   issued only for durable COMMIT records (the WAL enforces this),
    ///   then pages and statuses are published and members acknowledged.
    ///
    /// `staged` is called exactly once, when Stage A has released the
    /// commit-order lock, so the admission queue can elect the next leader.
    /// The acknowledgement point is unchanged: no member's result is
    /// produced before its COMMIT record is durable and its publication done.
    pub(super) fn commit_group_staged(
        &self,
        requests: Vec<(CommitPermit, SessionWrites)>,
        staged: &mut dyn FnMut(),
        more: &mut dyn FnMut(usize) -> Vec<(CommitPermit, SessionWrites)>,
    ) -> Vec<Result<(), PhobosError>> {
        phobos_observability::event("mvcc.batch_members", requests.len() as u64);
        if requests.is_empty() || requests.len() > 64 {
            staged();
            // Nothing was submitted to the WAL: abort the members cleanly.
            let mut results = Vec::with_capacity(requests.len());
            for (permit, writes) in requests {
                let error = write_conflict("invalid MVCC commit batch");
                results.push(Err(error));
                drop(writes);
                if let Err(error) = permit.abort() {
                    self.fence_database();
                    *results.last_mut().expect("pushed") = Err(error);
                }
            }
            return results;
        }
        let count = requests.len();
        let mut results: MemberResults = (0..count).map(|_| None).collect();
        let finish = |results: MemberResults| -> Vec<Result<(), PhobosError>> {
            results
                .into_iter()
                .map(|result| {
                    result.unwrap_or_else(|| Err(write_conflict("commit result missing")))
                })
                .collect()
        };
        let fail_all = |results: &mut MemberResults, error: &PhobosError| {
            for result in results.iter_mut() {
                if result.is_none() {
                    *result = Some(Err(error.clone()));
                }
            }
        };
        let order_wait = phobos_observability::span("mvcc.commit_order_acquire");
        let order = self.commits.lock();
        drop(order_wait);
        let Ok(order) = order else {
            staged();
            let error = write_conflict("commit order poisoned");
            self.fence_database();
            fail_all(&mut results, &error);
            drop(requests);
            return finish(results);
        };
        // ---- Stage A -------------------------------------------------------
        let mut order = order;
        while order.stage_a_active && !self.fenced.load(std::sync::atomic::Ordering::Acquire) {
            phobos_observability::event("mvcc.stage_a_entry_waits", 1);
            order = match self.commit_turn.wait(order) {
                Ok(order) => order,
                Err(_) => {
                    staged();
                    let error = write_conflict("commit order poisoned");
                    self.fence_database();
                    fail_all(&mut results, &error);
                    drop(requests);
                    return finish(results);
                }
            };
        }
        order.stage_a_active = true;
        let hold = phobos_observability::span("mvcc.commit_order_hold");
        let members = requests
            .into_iter()
            .enumerate()
            .map(|(index, (permit, writes))| (index, permit, writes))
            .collect();
        let (mut order, maintenance) = self.quiesce_for_maintenance(order);
        order.next_batch += 1;
        let seq = order.next_batch;
        order.in_flight += 1;
        let mut turn = BatchTurn {
            database: self,
            seq,
            done: false,
        };
        let (mut order, stage_a) = match maintenance {
            Ok(()) => self.stage_members(members, &mut results, order, seq),
            Err(error) => (order, Err(error)),
        };
        let (mut members, mut stage_error) = match stage_a {
            Ok(members) => (members, None),
            // Durability-uncertain Stage A failure: the batch still takes its
            // turn in order so successors observe the fence.
            Err(error) => (Vec::new(), Some(error)),
        };
        // Natural batching: while an earlier batch's WAL force is still in
        // flight this batch could not force anyway, so commits that became
        // ready meanwhile join it (one later force covers them all). With no
        // force in flight (e.g. a single client) the batch forces at once.
        while stage_error.is_none() && results.len() < 64 && self.force_in_flight() {
            let extra = more(64 - results.len());
            if extra.is_empty() {
                break;
            }
            phobos_observability::event("mvcc.batch_absorbed", extra.len() as u64);
            let base = results.len();
            results.extend((0..extra.len()).map(|_| None));
            let extra = extra
                .into_iter()
                .enumerate()
                .map(|(offset, (permit, writes))| (base + offset, permit, writes))
                .collect();
            let (next, staged_extra) = self.stage_members(extra, &mut results, order, seq);
            order = next;
            match staged_extra {
                Ok(staged_extra) => members.extend(staged_extra),
                Err(error) => stage_error = Some(error),
            }
        }
        drop(hold);
        order.stage_a_active = false;
        self.commit_turn.notify_all();
        drop(order);
        staged();
        // ---- Force (no engine lock held) -----------------------------------
        let target = members
            .iter()
            .filter_map(|(_, _, _, prepared)| prepared.ticket.as_ref().map(|t| t.lsn()))
            .max();
        let forced = match target {
            Some(target) => self.force_through(target),
            None => Ok(()),
        };
        // ---- Stage B (batch order) -------------------------------------------
        let order = {
            let _turn = phobos_observability::span("mvcc.publication_turn_wait");
            self.publishers_waiting
                .fetch_add(1, std::sync::atomic::Ordering::AcqRel);
            let locked = self.commits.lock();
            self.publishers_waiting
                .fetch_sub(1, std::sync::atomic::Ordering::AcqRel);
            let mut order = match locked {
                Ok(order) => order,
                Err(_) => {
                    let error = write_conflict("commit order poisoned");
                    self.fence_database();
                    fail_all(&mut results, &error);
                    return finish(results);
                }
            };
            while order.published + 1 < seq
                && !self.fenced.load(std::sync::atomic::Ordering::Acquire)
            {
                order = match self.commit_turn.wait(order) {
                    Ok(order) => order,
                    Err(_) => {
                        let error = write_conflict("commit order poisoned");
                        self.fence_database();
                        fail_all(&mut results, &error);
                        return finish(results);
                    }
                };
            }
            order
        };
        let mut order = order;
        let publish = phobos_observability::span("mvcc.publication_hold");
        phobos_observability::event("wal.group_commits", members.len() as u64);
        let published = match stage_error {
            Some(error) => Err(error),
            None => forced.and_then(|()| {
                if self.fenced.load(std::sync::atomic::Ordering::Acquire) {
                    Err(write_conflict("database fenced; recovery required"))
                } else {
                    self.publish_staged(members, &mut results)
                }
            }),
        };
        if let Err(error) = published {
            self.fence_database();
            fail_all(&mut results, &error);
        }
        order.published = order.published.max(seq);
        order.in_flight -= 1;
        turn.done = true;
        self.commit_turn.notify_all();
        if order.in_flight == 0 {
            let _advance = phobos_observability::span("mvcc.advance_checkpoint");
            if let Err(error) = self.advance_checkpoint() {
                self.fence_database();
                fail_all(&mut results, &error);
            }
        }
        drop(publish);
        drop(order);
        finish(results)
    }

    /// Commit-order ownership with no batch in flight: for maintenance that
    /// needs every appended commit published (checkpoint, backup, freeze).
    pub(super) fn lock_commits_quiescent(
        &self,
    ) -> Result<MutexGuard<'_, CommitOrder>, PhobosError> {
        let order = self
            .commits
            .lock()
            .map_err(|_| write_conflict("commit order poisoned"))?;
        let (order, result) = self.wait_turn(order, None);
        result.map(|()| order)
    }

    /// Checkpoint advancement and WAL segment rotation require a quiescent
    /// writer (no appended-but-unpublished commit). With batches pipelined,
    /// drain only when such maintenance is actually due.
    fn quiesce_for_maintenance<'a>(
        &'a self,
        order: MutexGuard<'a, CommitOrder>,
    ) -> (MutexGuard<'a, CommitOrder>, Result<(), PhobosError>) {
        if order.in_flight == 0 {
            return (order, Ok(()));
        }
        let due = (|| -> Result<bool, PhobosError> {
            let store = self
                .lock_database()?
                .committed_store
                .as_ref()
                .expect("MVCC store")
                .clone();
            let (running, ready) = store.checkpoint_progress()?;
            let wal = writer(&self.wal)?;
            Ok(wal.maintenance_due()
                || ready
                || (wal.checkpoint_due() && !wal.checkpoint_pending() && !running))
        })();
        match due {
            Ok(false) => (order, Ok(())),
            Err(error) => (order, Err(error)),
            Ok(true) => {
                phobos_observability::event("mvcc.pipeline_maintenance_drains", 1);
                let (order, drained) = self.wait_turn(order, None);
                let result = drained.and_then(|()| self.advance_checkpoint());
                (order, result)
            }
        }
    }

    /// Wait (lock released) until no batch is in flight (`seq == None`) or
    /// until every batch before `seq` is published. Returns the reacquired
    /// guard; a fenced database stops waiting.
    fn wait_turn<'a>(
        &'a self,
        mut order: MutexGuard<'a, CommitOrder>,
        seq: Option<u64>,
    ) -> (MutexGuard<'a, CommitOrder>, Result<(), PhobosError>) {
        let _wait = phobos_observability::span("mvcc.pipeline_drain_wait");
        loop {
            let ready = match seq {
                None => order.in_flight == 0,
                Some(seq) => order.published + 1 >= seq,
            };
            if ready || self.fenced.load(std::sync::atomic::Ordering::Acquire) {
                return (order, Ok(()));
            }
            order = match self.commit_turn.wait(order) {
                Ok(order) => order,
                Err(poisoned) => {
                    return (
                        poisoned.into_inner(),
                        Err(write_conflict("commit order poisoned")),
                    );
                }
            };
        }
    }

    fn force_in_flight(&self) -> bool {
        self.force_gate.lock().is_ok_and(|gate| gate.running)
    }

    /// Single-flight WAL force through `target`. Followers wait for the
    /// in-progress force and re-check; a force that already covers `target`
    /// is not repeated. The sync runs with no engine lock held.
    fn force_through(&self, target: u64) -> Result<(), PhobosError> {
        let _wait = phobos_observability::span("mvcc.wal_force_wait");
        let mut gate = self
            .force_gate
            .lock()
            .map_err(|_| write_conflict("WAL force gate poisoned"))?;
        loop {
            if gate.failed {
                return Err(write_conflict("WAL force failed; recovery required"));
            }
            if gate.durable >= target {
                phobos_observability::event("wal.force_already_covered", 1);
                return Ok(());
            }
            if !gate.running {
                break;
            }
            gate = self
                .force_done
                .wait(gate)
                .map_err(|_| write_conflict("WAL force gate poisoned"))?;
        }
        gate.running = true;
        drop(gate);
        let outcome = (|| -> Result<u64, PhobosError> {
            let intent = writer(&self.wal)?.begin_force()?;
            let Some(intent) = intent else {
                return Ok(writer(&self.wal)?.durable_lsn());
            };
            phobos_observability::certification_crash("before_wal_sync");
            phobos_observability::synchronization_boundary("wal.before_force", &self.data_dir);
            let result = {
                let _sync = phobos_observability::span("wal.fsync");
                phobos_observability::event("wal.force_bytes", intent.write_len() as u64);
                intent.sync()
            };
            // 0.2-E: the durability I/O completed; the frontier is not yet advanced.
            phobos_observability::synchronization_boundary("wal.after_write", &self.data_dir);
            let reached = intent.target();
            writer(&self.wal)?.complete_force(intent, result)?;
            phobos_observability::synchronization_boundary("wal.after_force", &self.data_dir);
            phobos_observability::certification_crash("after_wal_sync");
            phobos_observability::event("wal.group_forces", 1);
            Ok(reached)
        })();
        let mut gate = self
            .force_gate
            .lock()
            .map_err(|_| write_conflict("WAL force gate poisoned"))?;
        gate.running = false;
        let result = match outcome {
            Ok(reached) => {
                gate.durable = gate.durable.max(reached);
                if gate.durable >= target {
                    Ok(())
                } else {
                    Err(write_conflict("WAL force did not cover its commits"))
                }
            }
            Err(error) => {
                gate.failed = true;
                Err(error)
            }
        };
        self.force_done.notify_all();
        result
    }

    /// Stage A: ordered preparation and WAL append. Members that fail before
    /// anything of them is durable abort alone (D2). A batch exceeding the
    /// 1 MiB redo bound is forced and published inline once every earlier
    /// batch has been published (unchanged bounded-memory behavior).
    fn stage_members<'a>(
        &'a self,
        requests: VecDeque<Member>,
        results: &mut MemberResults,
        mut order: MutexGuard<'a, CommitOrder>,
        seq: u64,
    ) -> (
        MutexGuard<'a, CommitOrder>,
        Result<Vec<StagedMember>, PhobosError>,
    ) {
        // 0.2-C: a batch of small, schema-free members prepares and appends
        // inside one physical domain, serially and in queue order (no
        // per-member extraction, catalog clone or worker thread). Only when
        // the C6 waves would be serial anyway: every member shares a table
        // with its successor. Disjoint neighbours keep parallel preparation.
        let small = requests.iter().all(|(_, _, writes)| {
            writes.schema.is_none()
                && writes.bulk.is_none()
                && writes.memtable_bytes() <= SMALL_MEMBER_BYTES
        });
        if small
            && requests
                .iter()
                .zip(requests.iter().skip(1))
                .all(|((_, _, left), (_, _, right))| {
                    !domains::tables(left).is_disjoint(&domains::tables(right))
                })
        {
            return self.stage_small_members(requests, results, order, seq);
        }
        let mut pending = Vec::new();
        let mut bytes = 0u64;
        let mut requests = requests;
        while !requests.is_empty() {
            // Between members no private generation is active and every
            // staged member is in the ordered pending chain: let a durable
            // earlier batch publish (and acknowledge) first.
            if self
                .publishers_waiting
                .load(std::sync::atomic::Ordering::Acquire)
                > 0
            {
                phobos_observability::event("mvcc.stage_a_yields", 1);
                order = match self
                    .commit_turn
                    .wait_timeout(order, std::time::Duration::from_micros(200))
                {
                    Ok((order, _)) => order,
                    Err(poisoned) => {
                        return (
                            poisoned.into_inner().0,
                            Err(write_conflict("commit order poisoned")),
                        );
                    }
                };
            }
            let mut wave = Vec::new();
            let mut occupied = BTreeSet::new();
            while wave.len() < 8 {
                let Some((_, _, writes)) = requests.front() else {
                    break;
                };
                let tables = domains::tables(writes);
                if !wave.is_empty() && (writes.schema.is_some() || !occupied.is_disjoint(&tables)) {
                    break;
                }
                occupied.extend(tables);
                let schema = writes.schema.is_some();
                wave.push(requests.pop_front().expect("front request"));
                if schema {
                    break;
                }
            }
            phobos_observability::event("mvcc.wave_count", 1);
            phobos_observability::event("mvcc.wave_size", wave.len() as u64);
            let prepared = match self.prepare_wave(&wave) {
                Ok(prepared) => prepared,
                Err(error) => return (order, Err(error)),
            };
            for ((index, permit, writes), prepared) in wave.into_iter().zip(prepared) {
                let mut prepared = match prepared {
                    Ok(prepared) => prepared,
                    Err(error) => {
                        // D2: nothing of this member is durable and its
                        // private images are gone; it aborts alone.
                        phobos_observability::event("mvcc.commit_member_aborted", 1);
                        results[index] = Some(Err(error));
                        drop(writes);
                        if let Err(error) = permit.abort() {
                            return (order, Err(error));
                        }
                        continue;
                    }
                };
                if !pending.is_empty() && bytes.saturating_add(prepared.bound) > 1024 * 1024 {
                    let (next, result) = self.force_publish_inline(
                        std::mem::take(&mut pending),
                        results,
                        order,
                        seq,
                    );
                    order = next;
                    if let Err(error) = result {
                        return (order, Err(error));
                    }
                    bytes = 0;
                }
                // From here on the member has WAL records: any failure is
                // durability-uncertain and fences.
                let appended = {
                    let _wal_append = phobos_observability::span("mvcc.wal_append");
                    self.with_domain(&writes, |database| {
                        log_prepared(database, &self.wal, writes.stable_id(), &mut prepared)
                    })
                };
                if let Err(error) = appended {
                    return (order, Err(error));
                }
                bytes = bytes.saturating_add(prepared.bound);
                pending.push((index, permit, writes, prepared));
                if bytes >= 1024 * 1024 {
                    let (next, result) = self.force_publish_inline(
                        std::mem::take(&mut pending),
                        results,
                        order,
                        seq,
                    );
                    order = next;
                    if let Err(error) = result {
                        return (order, Err(error));
                    }
                    bytes = 0;
                }
            }
        }
        (order, Ok(pending))
    }

    fn stage_small_members<'a>(
        &'a self,
        requests: VecDeque<Member>,
        results: &mut MemberResults,
        mut order: MutexGuard<'a, CommitOrder>,
        seq: u64,
    ) -> (
        MutexGuard<'a, CommitOrder>,
        Result<Vec<StagedMember>, PhobosError>,
    ) {
        let mut pending: Vec<StagedMember> = Vec::new();
        let mut bytes = 0u64;
        let mut requests = requests;
        while !requests.is_empty() {
            if self
                .publishers_waiting
                .load(std::sync::atomic::Ordering::Acquire)
                > 0
            {
                phobos_observability::event("mvcc.stage_a_yields", 1);
                order = match self
                    .commit_turn
                    .wait_timeout(order, std::time::Duration::from_micros(200))
                {
                    Ok((order, _)) => order,
                    Err(poisoned) => {
                        return (
                            poisoned.into_inner().0,
                            Err(write_conflict("commit order poisoned")),
                        );
                    }
                };
            }
            // Stage members in one domain until the bounded redo budget is
            // reached (checked after each small member's append); inline
            // publication needs the domain returned first.
            let mut inline = false;
            let staged = self.with_database_in_place(|database| {
                while let Some((index, permit, writes)) = requests.pop_front() {
                    phobos_observability::event("mvcc.wave_count", 1);
                    phobos_observability::event("mvcc.wave_size", 1);
                    let foreign = permit.stable_id() != writes.stable_id()
                        || writes
                            .ownership
                            .as_ref()
                            .is_some_and(|lease| !Arc::ptr_eq(&lease.owner, &self.ownership));
                    let prepared = if foreign {
                        Err(Failure::Member(write_conflict(
                            "foreign commit/write ownership",
                        )))
                    } else {
                        let _serial = phobos_observability::span("mvcc.prepare_serial");
                        prepare(database, &writes)
                    };
                    let mut prepared = match prepared {
                        Ok(prepared) => prepared,
                        Err(Failure::Member(error)) => {
                            // D2: nothing of this member is durable and its
                            // private images are gone; it aborts alone.
                            phobos_observability::event("mvcc.commit_member_aborted", 1);
                            results[index] = Some(Err(error));
                            drop(writes);
                            permit.abort()?;
                            continue;
                        }
                        Err(Failure::Fence(error)) => return Err(error),
                    };
                    // From here on the member has WAL records: any failure is
                    // durability-uncertain and fences.
                    {
                        let _wal_append = phobos_observability::span("mvcc.wal_append");
                        log_prepared(database, &self.wal, writes.stable_id(), &mut prepared)?;
                    }
                    bytes = bytes.saturating_add(prepared.bound);
                    pending.push((index, permit, writes, prepared));
                    if bytes >= 1024 * 1024 && !requests.is_empty() {
                        inline = true;
                        return Ok(());
                    }
                }
                Ok(())
            });
            if let Err(error) = staged {
                return (order, Err(error));
            }
            if inline {
                let (next, result) =
                    self.force_publish_inline(std::mem::take(&mut pending), results, order, seq);
                order = next;
                if let Err(error) = result {
                    return (order, Err(error));
                }
                bytes = 0;
            }
        }
        (order, Ok(pending))
    }

    /// Bounded-memory path inside Stage A: wait (lock released) until every
    /// earlier batch is published, then force and publish what is staged.
    fn force_publish_inline<'a>(
        &'a self,
        pending: Vec<StagedMember>,
        results: &mut MemberResults,
        order: MutexGuard<'a, CommitOrder>,
        seq: u64,
    ) -> (MutexGuard<'a, CommitOrder>, Result<(), PhobosError>) {
        let (order, waited) = self.wait_turn(order, Some(seq));
        if let Err(error) = waited {
            return (order, Err(error));
        }
        if self.fenced.load(std::sync::atomic::Ordering::Acquire) {
            return (
                order,
                Err(write_conflict("database fenced; recovery required")),
            );
        }
        phobos_observability::event("mvcc.inline_bounded_publications", 1);
        let result = self.force_publish(pending, results);
        (order, result)
    }

    /// Stage B: receipts (durable COMMITs only, oldest first), then ordered
    /// installation/status publication exactly as before.
    fn publish_staged(
        &self,
        mut pending: Vec<StagedMember>,
        results: &mut MemberResults,
    ) -> Result<(), PhobosError> {
        if pending.is_empty() {
            return Ok(());
        }
        let tickets = pending
            .iter_mut()
            .map(|(_, _, _, prepared)| prepared.ticket.take().expect("prepared ticket"))
            .collect::<Vec<_>>();
        let receipts = writer(&self.wal)?.receipts_for(&tickets)?;
        self.publish_receipted(pending, receipts, results)
    }

    pub(super) fn fence_database(&self) {
        self.fenced
            .store(true, std::sync::atomic::Ordering::Release);
        if let Ok(mut database) = self.database.lock() {
            database.fenced = true;
        }
    }

    /// Prepares one wave; the outer `Err` is a fencing failure (a worker
    /// panicked or a physical domain could not be returned), the inner one a
    /// member failure whose private state has already been rolled back.
    fn prepare_wave(
        &self,
        requests: &[Member],
    ) -> Result<Vec<Result<Prepared, PhobosError>>, PhobosError> {
        let foreign = |permit: &CommitPermit, writes: &SessionWrites| {
            permit.stable_id() != writes.stable_id()
                || writes
                    .ownership
                    .as_ref()
                    .is_some_and(|lease| !Arc::ptr_eq(&lease.owner, &self.ownership))
        };
        let lift = |result: Result<Prepared, Failure>| match result {
            Ok(prepared) => Ok(Ok(prepared)),
            Err(Failure::Member(error)) => Ok(Err(error)),
            Err(Failure::Fence(error)) => Err(error),
        };
        if requests.len() == 1 {
            let _serial = phobos_observability::span("mvcc.prepare_serial");
            let (_, permit, writes) = &requests[0];
            if foreign(permit, writes) {
                return Ok(vec![Err(write_conflict("foreign commit/write ownership"))]);
            }
            return self
                .with_domain(writes, |database| Ok(prepare(database, writes)))
                .and_then(lift)
                .map(|prepared| vec![prepared]);
        }
        let _parallel = phobos_observability::span("mvcc.prepare_parallel");
        // Sets are disjoint before acquiring file owners. Each worker owns all
        // heap/index state it mutates; no database, WAL or publication guard is
        // retained while private pages are encoded, split, or spilled.
        let mut work = Vec::new();
        for (_, permit, writes) in requests {
            if foreign(permit, writes) {
                work.push(None);
                continue;
            }
            work.push(Some((self.take_domain(writes)?, writes)));
        }
        let completed = std::thread::scope(|scope| {
            let workers = work
                .into_iter()
                .map(|work| {
                    work.map(|(mut database, writes)| {
                        let _spawn = phobos_observability::span("mvcc.thread_spawn");
                        scope.spawn(move || {
                            let result = prepare(&mut database, writes);
                            (database, result)
                        })
                    })
                })
                .collect::<Vec<_>>();
            workers
                .into_iter()
                .map(|worker| {
                    worker
                        .map(|worker| {
                            worker.join().map_err(|_| {
                                write_conflict("private preparation panicked; recovery required")
                            })
                        })
                        .transpose()
                })
                .collect::<Result<Vec<_>, PhobosError>>()
        })?;
        let mut prepared = Vec::new();
        for worker in completed {
            let Some((database, result)) = worker else {
                prepared.push(Err(write_conflict("foreign commit/write ownership")));
                continue;
            };
            self.return_domain(database)?;
            prepared.push(lift(result)?);
        }
        Ok(prepared)
    }

    fn force_publish(
        &self,
        mut pending: Vec<(usize, CommitPermit, SessionWrites, Prepared)>,
        results: &mut MemberResults,
    ) -> Result<(), PhobosError> {
        let tickets = pending
            .iter_mut()
            .map(|(_, _, _, prepared)| prepared.ticket.take().expect("prepared ticket"))
            .collect::<Vec<_>>();
        // Complete-batch force never retains the database execution guard.
        // D1: this WAL force is the one durability boundary of every member;
        // status records that follow are written, not forced.
        let receipts = writer(&self.wal)?.force_commits(&tickets)?;
        self.publish_receipted(pending, receipts, results)
    }

    /// Ordered installation and status publication of durable members. A
    /// batch without schema changes publishes inside one physical domain.
    fn publish_receipted(
        &self,
        pending: Vec<StagedMember>,
        receipts: Vec<phobos_wal::v2::DurableCommit>,
        results: &mut MemberResults,
    ) -> Result<(), PhobosError> {
        phobos_observability::synchronization_boundary("mvcc.before_publication", &self.data_dir);
        let published = self.publish_receipted_inner(pending, receipts, results);
        phobos_observability::synchronization_boundary("mvcc.after_publication", &self.data_dir);
        published
    }

    fn publish_receipted_inner(
        &self,
        pending: Vec<StagedMember>,
        receipts: Vec<phobos_wal::v2::DurableCommit>,
        results: &mut MemberResults,
    ) -> Result<(), PhobosError> {
        if pending
            .iter()
            .all(|(_, _, writes, _)| writes.schema.is_none())
        {
            return self.with_database_in_place(|database| {
                for ((index, permit, writes, prepared), receipt) in
                    pending.into_iter().zip(receipts)
                {
                    self.publish_one(database, permit, &receipt, prepared)?;
                    results[index] = Some(Ok(()));
                    // Ownership survives durability AND installation/status publication.
                    drop(writes);
                }
                Ok(())
            });
        }
        for ((index, permit, writes, prepared), receipt) in pending.into_iter().zip(receipts) {
            self.with_domain(&writes, |database| {
                self.publish_one(database, permit, &receipt, prepared)
            })?;
            results[index] = Some(Ok(()));
            drop(writes);
        }
        Ok(())
    }

    fn publish_one(
        &self,
        database: &mut Database,
        permit: CommitPermit,
        receipt: &phobos_wal::v2::DurableCommit,
        prepared: Prepared,
    ) -> Result<(), PhobosError> {
        let _cost = phobos_observability::span("mvcc.ordered_publication");
        phobos_observability::synchronization_boundary(
            "c5_before_visibility_publication",
            &database.data_dir,
        );
        permit.publish(receipt, || {
            for table in &prepared.tables {
                let _profile = prepared
                    .reclaim
                    .as_ref()
                    .map(|_| phobos_observability::lifecycle_profile());
                let _heap_publish = prepared
                    .reclaim
                    .as_ref()
                    .map(|_| phobos_observability::span("reclaim.heap_install"));
                let heap = database.heap_mut(*table)?;
                heap.defer_private_cleanup()?;
                heap.install_pending(receipt)?;
            }
            for index in &prepared.indexes {
                let tree = database.indexes.get_mut(index).expect("prepared index");
                tree.defer_private_cleanup()?;
                tree.install_pending(receipt)?;
            }
            if let Some(schema) = &prepared.schema {
                super::schema::install_metadata(database, schema)?;
                let readers = read_directory::ReadDirectory::new(database)?;
                *self
                    .readers
                    .write()
                    .map_err(|_| write_conflict("read directory poisoned"))? = Arc::new(readers);
                for id in &prepared.dropped {
                    fs::remove_file(index_path(&database.data_dir, *id))?;
                }
                // Schema/lifecycle publication uses the existing full data
                // force barrier before any incremental WAL retirement.
                for heap in database.heaps.values_mut() {
                    heap.force_committed()?;
                }
                for tree in database.indexes.values_mut() {
                    tree.force_committed()?;
                }
                #[cfg(unix)]
                File::open(&database.data_dir)?.sync_all()?;
            }
            Ok(())
        })?;
        phobos_observability::synchronization_boundary(
            "c5_after_visibility_publication",
            &database.data_dir,
        );
        if let Some(outcome) = prepared.reclaim {
            // 0.2-K Part C/D: the exact publication sequence that RETIRED
            // the plan's slots (its COMMIT LSN, the value `advance_publication`
            // just published). Reclaim passes are serialized, so the pass
            // that submitted this plan reads it back after `commit` returns.
            self.last_reclaim_publication
                .store(receipt.lsn(), std::sync::atomic::Ordering::Release);
            if let Ok(mut last) = self.last_reclaim_outcome.lock() {
                *last = outcome;
            }
        }
        database
            .committed_store
            .as_ref()
            .expect("MVCC committed store")
            .retire_scratch_if_created(&prepared.root)?;
        self.note_candidate_pages(&prepared.candidate_pages);
        Ok(())
    }
}

/// Private state a failed preparation must undo before its member can abort
/// alone (D2). Anything not recorded here was never touched.
#[derive(Default)]
struct Undo {
    root: Option<PathBuf>,
    heaps: Vec<TableId>,
    indexes: Vec<IndexId>,
    /// Catalog/file lifecycle changes cannot be undone in place: fence.
    schema: bool,
}

fn prepare(database: &mut Database, writes: &SessionWrites) -> Result<Prepared, Failure> {
    let mut undo = Undo::default();
    let error = match prepare_inner(database, writes, &mut undo) {
        Ok(prepared) => return Ok(prepared),
        Err(error) => error,
    };
    if undo.schema {
        return Err(Failure::Fence(error));
    }
    for table in &undo.heaps {
        if let Err(undo_error) = database
            .heap_mut(*table)
            .and_then(|heap| heap.rollback_private())
        {
            return Err(Failure::Fence(undo_error));
        }
    }
    for index in &undo.indexes {
        let Some(tree) = database.indexes.get_mut(index) else {
            return Err(Failure::Fence(write_conflict("prepared index missing")));
        };
        if let Err(undo_error) = tree.rollback_private() {
            return Err(Failure::Fence(undo_error));
        }
    }
    if let Some(root) = &undo.root {
        match fs::remove_dir_all(root) {
            Ok(()) => {}
            Err(undo_error) if undo_error.kind() == std::io::ErrorKind::NotFound => {}
            Err(undo_error) => return Err(Failure::Fence(undo_error.into())),
        }
    }
    Err(Failure::Member(error))
}

fn prepare_inner(
    database: &mut Database,
    writes: &SessionWrites,
    undo: &mut Undo,
) -> Result<Prepared, PhobosError> {
    let _cost = phobos_observability::span("mvcc.rebase_preparation");
    phobos_observability::synchronization_boundary(
        "c6_private_preparation_begin",
        &database.data_dir,
    );
    let stable = writes.stable_id();
    let root = database
        .data_dir
        .join(format!(".phobos-mvcc-private-{stable}"));
    // 0.2-B: the directory is created by the first private image that spills
    // to scratch; small commits stay resident and never create it.
    undo.root = Some(root.clone());
    let mut created = Vec::new();
    let mut dropped = Vec::new();
    let mut rebuild = BTreeSet::new();
    if let Some(schema) = &writes.schema {
        undo.schema = true;
        let store = database
            .committed_store
            .as_ref()
            .expect("MVCC store")
            .clone();
        store.cancel_checkpoint()?;
        for table in schema.catalog.tables() {
            if let std::collections::btree_map::Entry::Vacant(entry) =
                database.heaps.entry(table.id)
            {
                let mut heap = HeapTable::open_versioned(
                    heap_path(&database.data_dir, table.id),
                    table.clone(),
                    database.buffer_pages,
                )?;
                heap.attach_committed(&store, FileId::Heap(table.id))?;
                entry.insert(heap);
                created.push(FileId::Heap(table.id));
            }
            // Schema publication is serialized and failures fence the owner.
            // Existing statement read handles retain their previous generation.
            database
                .heaps
                .get_mut(&table.id)
                .expect("catalog heap")
                .rebind_names(table)?;
        }
        for definition in schema.catalog.indexes() {
            if let std::collections::btree_map::Entry::Vacant(entry) =
                database.indexes.entry(definition.id)
            {
                let mut tree = BPlusTree::open(
                    index_path(&database.data_dir, definition.id),
                    definition.unique,
                    definition.columns.len(),
                )?;
                tree.attach_committed(&store, FileId::Index(definition.id))?;
                entry.insert(tree);
                created.push(FileId::Index(definition.id));
                rebuild.insert(definition.id);
            }
        }
        dropped = database
            .indexes
            .keys()
            .filter(|id| !schema.catalog.indexes().any(|index| index.id == **id))
            .copied()
            .collect();
        for id in &dropped {
            database.indexes.remove(id);
        }
        database.catalog = schema.catalog.clone();
    }
    let mut tables = writes.tables().clone();
    if let Some(bulk) = &writes.bulk {
        tables.insert(bulk.schema.id);
    }
    for file in &created {
        if let FileId::Heap(id) = file {
            tables.insert(*id);
        }
    }
    for index in database
        .catalog
        .indexes()
        .filter(|index| rebuild.contains(&index.id))
    {
        tables.insert(index.table_id);
    }
    let indexes = database
        .catalog
        .indexes()
        .filter(|index| tables.contains(&index.table_id))
        .map(|index| index.id)
        .collect::<BTreeSet<_>>();
    for table in &tables {
        let directory = database.data_dir.clone();
        database.heap_mut(*table)?.begin_private(
            &root.join(FileId::Heap(*table).name()),
            stable,
            &directory,
        )?;
        undo.heaps.push(*table);
    }
    for index in &indexes {
        database
            .indexes
            .get_mut(index)
            .expect("catalog index")
            .begin_private(
                &root.join(FileId::Index(*index).name()),
                stable,
                &database.data_dir,
            )?;
        undo.indexes.push(*index);
    }
    #[cfg(test)]
    if let Some(message) = writes.fail_prepare {
        // D2 test fault: a logical failure after the private images exist.
        return Err(PhobosError::new(ErrorCode::ConstraintViolation, message));
    }
    if let Some(bulk) = &writes.bulk {
        bulk.prepare(database)?;
    }
    let mut lifecycle = None;
    if let Some(plan) = &writes.reclaim {
        // C2/C3: drop globally dead versions and their exact index entries in
        // the same private images, so they publish (or fail) together.
        let _cost = phobos_observability::span("mvcc.reclaim_prepare");
        // 0.2-K: LIVE -> RETIRED, horizon-proven RETIRED -> FREE, trailing
        // trim and whole-page reset, in the same private images.
        let heap_span = phobos_observability::span("mvcc.reclaim_heap");
        let profile = phobos_observability::lifecycle_profile();
        lifecycle = Some(
            database
                .heap_mut(plan.table)?
                .reclaim_lifecycle_prepared(&plan.pages, &plan.prepared)?,
        );
        drop(heap_span);
        drop(profile);
        let _index_span = phobos_observability::span("mvcc.reclaim_index");
        let schema = database.heaps[&plan.table].schema().clone();
        let definitions = database
            .catalog
            .indexes_for_table(plan.table)
            .cloned()
            .collect::<Vec<_>>();
        // 0.2-K.4: under LAZY_INDEX_PRUNING_V1 only UNIQUE indexes are
        // pruned eagerly here; non-unique entries stay (harmless, revalidated
        // on every read) until the sweeper removes them (`plan.prune`).
        let lazy = plan.lazy && database.catalog.lazy_index_pruning();
        for definition in definitions {
            if lazy && !definition.unique {
                continue;
            }
            let tree = database
                .indexes
                .get_mut(&definition.id)
                .ok_or_else(|| write_conflict("reclaim index missing"))?;
            // 0.2-K Part L: exact `(key, RID)` deletions in index order, so
            // consecutive deletions revisit the same (private) leaves.
            let mut entries = plan
                .dead
                .iter()
                .map(|(rid, row)| Ok((index_key_for_row(&schema, &definition, row)?, *rid)))
                .collect::<Result<Vec<_>, PhobosError>>()?;
            entries.sort();
            let removed = tree.delete_versions_sorted(&entries, stable)?;
            if let Some(missing) = removed.iter().position(|removed| !removed) {
                let (key, rid) = &entries[missing];
                return Err(write_conflict(&format!(
                    "reclaimed version has no index entry (index {} key {:?} rid {:?})",
                    definition.id, key, rid
                )));
            }
        }
        if !plan.prune.is_empty() {
            let pruned =
                super::lazy_index::prune_stale_entries(database, plan.table, &plan.prune, stable)?;
            super::lazy_index::PRUNED.fetch_add(pruned, std::sync::atomic::Ordering::Relaxed);
        }
    }
    let mut candidate_pages: BTreeMap<TableId, BTreeMap<PageId, u32>> = BTreeMap::new();
    // 0.2-B: index entries are collected per index and inserted as sorted
    // batches after the heap changes (each touched leaf is decoded and
    // encoded once per batch instead of once per row). Heap changes never
    // read these private index images, and MVCC index maintenance only adds
    // entries, so deferring them within one private preparation is exact.
    let mut index_entries: BTreeMap<IndexId, Vec<(IndexKey, RecordId)>> = BTreeMap::new();
    for change in writes.changes()? {
        let change = change?;
        if change.original.is_none() && change.row.is_none() {
            continue;
        }
        if let Some((rid, _)) = change.original {
            *candidate_pages
                .entry(change.table)
                .or_default()
                .entry(rid.page_id)
                .or_insert(0) += 1;
        }
        let heap_mutation = phobos_observability::span("mvcc.heap_mutation");
        let rid = match (change.original, &change.row) {
            (Some((rid, expected)), Some(row)) => Some(
                database
                    .heap_mut(change.table)?
                    .update_version(rid, expected, row)?,
            ),
            (Some((rid, expected)), None) => {
                database
                    .heap_mut(change.table)?
                    .delete_version(rid, expected)?;
                None
            }
            (None, Some(row)) => Some(database.heap_mut(change.table)?.insert_version(
                TupleVersion {
                    logical_row: change.logical_row,
                    visibility: Version {
                        creator: stable,
                        deleter: None,
                    },
                    previous: None,
                },
                row,
            )?),
            (None, None) => unreachable!(),
        };
        drop(heap_mutation);
        if let (Some(rid), Some(row)) = (rid, &change.row) {
            // 0.2-G: borrow the schema and index definitions (read-only here)
            // instead of cloning them for every changed row.
            let schema = database.heaps[&change.table].schema();
            for definition in database.catalog.indexes_for_table(change.table) {
                if rebuild.contains(&definition.id) {
                    continue;
                }
                index_entries
                    .entry(definition.id)
                    .or_default()
                    .push((index_key_for_row(schema, definition, row)?, rid));
            }
        }
    }
    let _index_batch = phobos_observability::span("mvcc.index_batch");
    for (id, entries) in index_entries {
        let tree = database.indexes.get_mut(&id).expect("catalog index");
        if entries.len() == 1 {
            let (key, rid) = entries.into_iter().next().expect("one entry");
            tree.insert_version(key, rid, stable)?;
            continue;
        }
        let mut entries = entries;
        while !entries.is_empty() {
            let rest = entries.split_off(entries.len().min(1024));
            tree.insert_versions_batch(entries, stable)?;
            entries = rest;
        }
    }
    for id in &rebuild {
        let definition = database
            .catalog
            .indexes()
            .find(|index| index.id == *id)
            .expect("new index")
            .clone();
        let heap = database
            .heaps
            .get_mut(&definition.table_id)
            .expect("index heap");
        let table = heap.schema().clone();
        let tree = database.indexes.get_mut(id).expect("new index");
        heap.scan_versions(|rid, _, row| {
            tree.insert_version(index_key_for_row(&table, &definition, &row)?, rid, stable)?;
            Ok(true)
        })?;
    }
    let mut pages = 0u64;
    for table in &tables {
        pages = pages
            .checked_add(database.heap_mut(*table)?.private_page_count()?)
            .ok_or_else(|| write_conflict("redo bound overflow"))?;
    }
    for index in &indexes {
        pages = pages
            .checked_add(database.indexes[index].private_page_count()?)
            .ok_or_else(|| write_conflict("redo bound overflow"))?;
    }
    let bound = pages
        .checked_mul(8192 + 128)
        .and_then(|bytes| bytes.checked_add(256))
        .ok_or_else(|| write_conflict("redo bound overflow"))?;
    Ok(Prepared {
        ticket: None,
        bound,
        tables,
        indexes,
        root,
        schema: writes.schema.clone(),
        created,
        dropped,
        candidate_pages,
        reclaim: lifecycle,
    })
}

fn log_prepared(
    database: &mut Database,
    wal: &Mutex<phobos_wal::v2::Wal>,
    stable: u64,
    prepared: &mut Prepared,
) -> Result<(), PhobosError> {
    writer(wal)?.begin_mvcc(stable)?;
    for file in &prepared.created {
        writer(wal)?.append(phobos_wal::v2::Body::Create(*file))?;
        let mut input = File::open(database.data_dir.join(file.name()))?;
        let len = input.metadata()?.len();
        if len % 8192 != 0 {
            return Err(write_conflict("new file is not page aligned"));
        }
        for page in 0..len / 8192 {
            let mut image = Box::new([0; 8192]);
            input.read_exact(image.as_mut())?;
            writer(wal)?.append_page(PageAction::Initialize, *file, page, &mut image)?;
        }
    }
    for id in &prepared.dropped {
        writer(wal)?.append(phobos_wal::v2::Body::Delete(FileId::Index(*id)))?;
    }
    if let Some(schema) = &prepared.schema {
        super::schema::log_metadata(wal, schema)?;
    }

    let mut wal = writer(wal)?;
    let tables = &prepared.tables;
    let indexes = &prepared.indexes;
    let directory = database.data_dir.clone();
    for table in tables {
        let _profile = prepared
            .reclaim
            .as_ref()
            .map(|_| phobos_observability::lifecycle_profile());
        let _heap_wal = prepared
            .reclaim
            .as_ref()
            .map(|_| phobos_observability::span("reclaim.heap_wal"));
        let file = FileId::Heap(*table);
        let heap = database.heap_mut(*table)?;
        heap.prepare_private_redo_based(file, |page, bytes, base, allocated, phase| {
            let action = if allocated {
                PageAction::Initialize
            } else {
                PageAction::HeapUpdate
            };
            match phase {
                phobos_storage::page_io::RedoPhase::Stamp => {
                    wal.stamp_next_page(file, page, bytes)?;
                }
                phobos_storage::page_io::RedoPhase::Append => {
                    wal.append_prepared_page_with_base(action, file, page, bytes, base)?;
                    if prepared.reclaim.is_some() {
                        phobos_observability::synchronization_boundary(
                            "k5_lifecycle_wal_append",
                            &directory,
                        );
                    }
                }
            }
            Ok(())
        })?;
        heap.stage_private()?;
    }
    for index in indexes {
        let file = FileId::Index(*index);
        let tree = database.indexes.get_mut(index).expect("catalog index");
        tree.prepare_private_redo_based(file, |page, bytes, base, allocated, phase| {
            let action = if allocated {
                PageAction::Initialize
            } else {
                PageAction::Index
            };
            match phase {
                phobos_storage::page_io::RedoPhase::Stamp => {
                    wal.stamp_next_page(file, page, bytes)?;
                }
                phobos_storage::page_io::RedoPhase::Append => {
                    wal.append_prepared_page_with_base(action, file, page, bytes, base)?;
                }
            }
            Ok(())
        })?;
        tree.stage_private()?;
    }
    prepared.ticket = Some(wal.append_commit()?);
    phobos_observability::synchronization_boundary("c6_private_redo_staged", &database.data_dir);
    Ok(())
}

pub(super) fn writer(
    wal: &Mutex<phobos_wal::v2::Wal>,
) -> Result<MutexGuard<'_, phobos_wal::v2::Wal>, PhobosError> {
    let _wait = phobos_observability::span("mvcc.wal_writer_acquire");
    wal.lock()
        .map_err(|_| write_conflict("WAL writer poisoned"))
}
