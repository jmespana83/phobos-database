//! Resolved logical writes. No SQL expression is reevaluated during page rebasing.
//!
//! 0.1.9-A4: the in-memory budget is a spill threshold, not a transaction-size
//! ceiling. Pending changes live in a bounded memtable; when it fills, it is
//! flushed as a sorted run (see `spill.rs`) and emptied. Lookups and
//! iteration consult the memtable first, then runs newest first.
use super::*;
use phobos_storage::{OverlaySource, StatementOverlay, tuple_version::TupleVersion};
#[cfg(test)]
use spill::SpillFault;
use spill::{ChangeKey, MergeIter, Run, SpillStats, SpillStore};
use std::{
    collections::BTreeSet,
    sync::atomic::{AtomicUsize, Ordering},
};

#[derive(Clone, Debug)]
pub struct RowChange {
    pub table: TableId,
    pub logical_row: u64,
    pub original: Option<(RecordId, TupleVersion)>,
    pub row: Option<Row>,
    pub(super) synthetic: RecordId,
    /// `(unique index, hash of the canonical key)` of `row`, for spilled
    /// same-transaction UNIQUE checks.
    pub(super) unique_hashes: Vec<(IndexId, u64)>,
    pub(super) charge: usize,
}
pub struct SessionWrites {
    pub(super) bulk: Option<super::bulk::Spool>,
    /// C2/C3 maintenance unit: dead versions to drop from one table's pages
    /// and indexes in this publication.
    pub(super) reclaim: Option<super::reclaim::ReclaimPlan>,
    pub(super) control: Arc<super::ownership::WaitControl>,
    pub(super) schema: Option<Arc<super::schema::Schema>>,
    pub(super) ownership: Option<super::ownership::Lease>,
    stable: u64,
    next: u32,
    /// Memtable: newest version of every change not yet spilled.
    changes: BTreeMap<ChangeKey, RowChange>,
    /// Originals hidden by memtable changes.
    hidden: BTreeSet<ChangeKey>,
    /// `(unique index, key hash, change)` for memtable rows.
    keys: BTreeSet<(IndexId, u64, ChangeKey)>,
    /// Tables with at least one effective (non no-op) pending change.
    tables: BTreeSet<TableId>,
    bytes: usize,
    /// Bound on one statement's resolution/candidate working memory.
    statement_limit: usize,
    /// Memtable size at which pending changes are spilled.
    spill_threshold: usize,
    /// `None`: in-memory only (bulk batches, legacy callers) — exceeding the
    /// threshold is a ResourceLimit exactly as before A4.
    spill_root: Option<(PathBuf, u64)>,
    spill: Option<SpillStore>,
    stats: SpillStats,
    merge_peak: Arc<AtomicUsize>,
    /// D2 test fault: fail this transaction's preparation (after its private
    /// images exist) with a logical error, to exercise the non-fencing path.
    #[cfg(test)]
    pub(super) fail_prepare: Option<&'static str>,
}
#[derive(Clone)]
pub(super) struct SavepointMarker {
    runs: usize,
    next: u32,
    tables: BTreeSet<TableId>,
}
impl SessionWrites {
    /// In-memory only: the budget is a hard bound (pre-A4 behaviour).
    pub fn new(stable: u64, byte_limit: usize) -> Result<Self, PhobosError> {
        if stable == 0 || stable > u64::from(u32::MAX) || byte_limit == 0 {
            return Err(state("invalid stable write identity or memory bound"));
        }
        Ok(Self {
            bulk: None,
            reclaim: None,
            control: Arc::new(super::ownership::WaitControl::default()),
            schema: None,
            ownership: None,
            stable,
            next: 0,
            changes: BTreeMap::new(),
            hidden: BTreeSet::new(),
            keys: BTreeSet::new(),
            tables: BTreeSet::new(),
            bytes: 0,
            statement_limit: byte_limit,
            spill_threshold: byte_limit,
            spill_root: None,
            spill: None,
            stats: SpillStats::default(),
            merge_peak: Arc::new(AtomicUsize::new(0)),
            #[cfg(test)]
            fail_prepare: None,
        })
    }
    /// Spilling session writes: `statement_limit` bounds one statement's
    /// working memory, `spill_threshold` the memtable, `scratch_quota` the
    /// bytes of runs under `data_dir`.
    pub fn spilling(
        stable: u64,
        statement_limit: usize,
        spill_threshold: usize,
        data_dir: &Path,
        scratch_quota: u64,
    ) -> Result<Self, PhobosError> {
        if spill_threshold == 0 || scratch_quota == 0 {
            return Err(state("invalid write spill threshold or scratch quota"));
        }
        let mut writes = Self::new(stable, statement_limit)?;
        writes.spill_threshold = spill_threshold;
        writes.spill_root = Some((data_dir.to_path_buf(), scratch_quota));
        Ok(writes)
    }
    pub(super) fn discard(&mut self) {
        self.bulk.take();
        self.reclaim.take();
        self.changes.clear();
        self.hidden.clear();
        self.keys.clear();
        self.tables.clear();
        self.bytes = 0;
        self.spill.take();
        self.ownership.take();
        self.schema.take();
    }
    /// Seals the current bounded memtable and records an immutable run
    /// boundary. No row payload is copied into the savepoint marker.
    pub(super) fn savepoint(&mut self) -> Result<SavepointMarker, PhobosError> {
        if self.bulk.is_some() || self.reclaim.is_some() || self.schema.is_some() {
            return Err(state(
                "SAVEPOINT is unavailable during bulk, maintenance, or schema changes",
            ));
        }
        if !self.changes.is_empty() {
            self.flush_memtable()?;
        }
        Ok(SavepointMarker {
            runs: self.runs().len(),
            next: self.next,
            tables: self.tables.clone(),
        })
    }
    pub(super) fn rollback_to(&mut self, marker: &SavepointMarker) -> Result<(), PhobosError> {
        self.changes.clear();
        self.hidden.clear();
        self.keys.clear();
        self.bytes = 0;
        if let Some(spill) = self.spill.as_mut() {
            spill.truncate(marker.runs)?;
        } else if marker.runs != 0 {
            return Err(state("missing spill savepoint"));
        }
        self.next = marker.next;
        self.tables = marker.tables.clone();
        Ok(())
    }
    pub fn stable_id(&self) -> u64 {
        self.stable
    }
    #[must_use]
    pub fn spill_stats(&self) -> SpillStats {
        let mut stats = self.spill.as_ref().map_or(self.stats, |store| store.stats);
        stats.peak_memtable_bytes = self.stats.peak_memtable_bytes;
        stats.peak_merge_records = self.merge_peak.load(Ordering::Relaxed);
        stats
    }
    /// Whether pending writes beyond the threshold spill (SQL sessions) or
    /// are rejected (in-memory-only writes).
    #[must_use]
    pub fn spill_enabled(&self) -> bool {
        self.spill_root.is_some()
    }
    #[must_use]
    pub fn spill_threshold(&self) -> usize {
        self.spill_threshold
    }
    /// Shared probe of the largest number of records a merge over this
    /// write set ever buffered at once; survives the commit consuming `self`.
    #[cfg(test)]
    pub(super) fn merge_peak_probe(&self) -> Arc<AtomicUsize> {
        self.merge_peak.clone()
    }
    #[cfg(test)]
    pub(super) fn arm_spill_fault(&mut self, fault: SpillFault) -> Result<(), PhobosError> {
        let Some((root, quota)) = &self.spill_root else {
            return Err(state("spill faults need spilling writes"));
        };
        if self.spill.is_none() {
            self.spill = Some(SpillStore::new(root, self.stable, *quota));
        }
        let store = self.spill.as_mut().expect("spill store");
        match fault {
            SpillFault::WriteFails => store.fault = Some(fault),
            SpillFault::ReadFails => store.arm_read_fault(),
        }
        Ok(())
    }
    #[must_use]
    pub fn memtable_bytes(&self) -> usize {
        self.bytes
    }
    /// Tables touched by effective pending changes (bounded metadata; no I/O).
    pub fn tables(&self) -> &BTreeSet<TableId> {
        &self.tables
    }
    /// Attaches a C2/C3 reclaim plan; its table joins the publication domain.
    pub(super) fn set_reclaim(&mut self, plan: super::reclaim::ReclaimPlan) {
        self.tables.insert(plan.table);
        self.reclaim = Some(plan);
    }
    fn runs(&self) -> &[Arc<Run>] {
        self.spill.as_ref().map_or(&[], SpillStore::runs)
    }
    /// Every pending change exactly once (newest version), streamed in
    /// `(table, synthetic)` order from the memtable and the runs.
    pub fn changes(&self) -> Result<ChangeIter<'_>, PhobosError> {
        let memtable = self
            .changes
            .iter()
            .map(|(key, change)| (*key, change.clone()))
            .collect();
        Ok(ChangeIter {
            merge: MergeIter::new(memtable, self.runs())?,
            peak: &self.merge_peak,
        })
    }
    /// Newest pending version of a change, if any.
    fn lookup(&self, key: ChangeKey) -> Result<Option<RowChange>, PhobosError> {
        if let Some(change) = self.changes.get(&key) {
            return Ok(Some(change.clone()));
        }
        for run in self.runs().iter().rev() {
            if let Some(change) = run.find(key)? {
                return Ok(Some(change));
            }
        }
        Ok(None)
    }
    /// Own-write image of `table` for one statement (not cancellable).
    pub fn overlay(&self, table: TableId) -> Result<StatementOverlay, PhobosError> {
        let _compatibility = phobos_error::cancellation::suspend();
        self.overlay_cancellable(table)
    }
    pub(super) fn overlay_cancellable(
        &self,
        table: TableId,
    ) -> Result<StatementOverlay, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let mut overlay = StatementOverlay::default();
        let mut memtable_keys = BTreeSet::new();
        for ((_, synthetic), change) in self.changes.range(
            (
                table,
                RecordId {
                    page_id: 0,
                    slot_id: 0,
                },
            )
                ..=(
                    table,
                    RecordId {
                        page_id: u64::MAX,
                        slot_id: u16::MAX,
                    },
                ),
        ) {
            cancellation_poll.checkpoint_at("writes.overlay")?;
            if let Some((rid, _)) = change.original {
                overlay.hidden.insert(rid);
            }
            if let Some(row) = &change.row {
                overlay.rows.insert(change.synthetic, row.clone());
            }
            memtable_keys.insert(*synthetic);
        }
        if !self.runs().is_empty() {
            overlay.spilled = Some(Arc::new(SpilledOverlay {
                table,
                runs: self.runs().to_vec(),
                memtable_keys,
            }));
        }
        Ok(overlay)
    }

    /// Resolve against this statement's committed snapshot plus its own overlay.
    /// Admission must acquire/recheck logical-row and unique-key ownership before
    /// this method publishes changes into the session write set. Resolution and
    /// admission errors leave the prior write set intact; a scratch I/O or
    /// quota error while publishing may leave part of the statement's admitted
    /// changes pending. Either way the SQL transaction must then require
    /// rollback, so nothing of the failed statement can ever commit.
    pub fn stage_sql(
        &mut self,
        view: &mut SqlStatement<'_>,
        sql: &str,
        params: &[Value],
        admit: impl FnMut(&RowChange, &PendingView<'_>) -> Result<(), PhobosError>,
    ) -> Result<QueryResult, PhobosError> {
        if sql.len() > self.statement_limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC statement resolution input limit exceeded",
            ));
        }
        self.stage_statement(view, parse(sql)?, params, admit)
    }

    pub(super) fn stage_statement(
        &mut self,
        view: &mut SqlStatement<'_>,
        statement: Statement,
        params: &[Value],
        mut admit: impl FnMut(&RowChange, &PendingView<'_>) -> Result<(), PhobosError>,
    ) -> Result<QueryResult, PhobosError> {
        let _clock = sql_surface::StatementClock::enter();
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        if view.pin.snapshot().own_transaction() != Some(self.stable) {
            return Err(state("statement/write transaction mismatch"));
        }
        let (statement, returning) = match statement {
            Statement::InsertReturning { statement, columns } => (*statement, Some(columns)),
            statement => (statement, None),
        };
        let statement = match statement {
            Statement::InsertSelect {
                table,
                columns,
                query,
            } => {
                let schema = view.database.table_schema(&table)?;
                let expected = columns.as_ref().map_or(schema.columns.len(), Vec::len);
                let types = view.database.query_types(&query, params)?;
                if types.len() != expected {
                    return Err(PhobosError::new(
                        ErrorCode::TypeMismatch,
                        "INSERT SELECT column count mismatch",
                    ));
                }
                let targets = if let Some(names) = &columns {
                    names
                        .iter()
                        .map(|name| {
                            schema.column_index(name).ok_or_else(|| {
                                PhobosError::new(ErrorCode::NotFound, "INSERT column missing")
                            })
                        })
                        .collect::<Result<Vec<_>, _>>()?
                } else {
                    (0..schema.columns.len()).collect()
                };
                for (ty, ordinal) in types.iter().zip(targets) {
                    if ty.as_ref().is_some_and(|t| {
                        !modern_sql::assignment_type(t, &schema.columns[ordinal].data_type)
                    }) {
                        return Err(PhobosError::new(
                            ErrorCode::TypeMismatch,
                            "INSERT SELECT source and target types differ",
                        ));
                    }
                }
                let rows =
                    view.database
                        .collect_query_bounded(*query, params, self.statement_limit)?;
                let rows = rows
                    .into_iter()
                    .map(|r| r.values.into_iter().map(Expr::Literal).collect())
                    .collect();
                match columns {
                    Some(columns) => Statement::InsertColumns {
                        table,
                        columns,
                        rows,
                    },
                    None => Statement::Insert { table, rows },
                }
            }
            other => other,
        };
        let statement = if let Statement::InsertColumns {
            table,
            columns,
            rows,
        } = statement
        {
            expand_insert_columns(&view.database.catalog, table, columns, rows)?
        } else {
            statement
        };
        let mut resolved = Vec::new();
        let mut resolution_bytes = 0usize;
        let (tag, schema) = match statement {
            Statement::Insert { table, rows } => {
                let schema = view.database.table_schema(&table)?;
                if view.database.catalog.partition_key(&table).is_some() {
                    return Err(state(
                        "INSERT RETURNING on partition parents is unsupported",
                    ));
                }
                let definition = view
                    .database
                    .catalog
                    .definitions(schema.id)
                    .cloned()
                    .unwrap_or_default();
                let generated_count = definition.identity.as_ref().map_or(0, |i| {
                    rows.iter()
                        .filter(|r| r.get(i.column).is_some_and(is_default_expr))
                        .count()
                });
                let mut next_identity = if generated_count > 0 {
                    Some(self.reserve_identity(
                        view,
                        definition.identity.as_ref().expect("identity"),
                        generated_count,
                        &mut admit,
                    )?)
                } else {
                    None
                };
                for exprs in rows {
                    cancellation_poll.checkpoint_at("writes.stage_sql")?;
                    if exprs.len() != schema.columns.len() {
                        return Err(state("INSERT column count mismatch"));
                    }
                    let values = schema
                        .columns
                        .iter()
                        .zip(&exprs)
                        .enumerate()
                        .map(|(ordinal, (column, expr))| {
                            if let Some(identity) =
                                definition.identity.as_ref().filter(|i| i.column == ordinal)
                            {
                                if is_default_expr(expr) {
                                    let value = next_identity.as_mut().expect("reserved identity");
                                    let result = *value;
                                    *value += 1;
                                    return Ok(Value::Int64(result));
                                }
                                if identity.always {
                                    return Err(PhobosError::new(
                                        ErrorCode::ConstraintViolation,
                                        "GENERATED ALWAYS identity rejects explicit values",
                                    ));
                                }
                            }
                            let value = if is_default_expr(expr) {
                                definition
                                    .defaults
                                    .get(&ordinal)
                                    .cloned()
                                    .unwrap_or(Value::Null)
                            } else {
                                eval_expr(expr, &schema, None, params)?
                            };
                            coerce_value(column, value)
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let row = Row::new(values);
                    view.database
                        .catalog
                        .validate_row_definitions(schema.id, &row)?;
                    let change = self.change(&schema, None, Some(row), view)?;
                    self.resolve(&schema, change, &mut resolved, &mut resolution_bytes)?;
                }
                ("INSERT", schema)
            }
            Statement::Update {
                table,
                assignments,
                filter,
            } => {
                let schema = view.database.table_schema(&table)?;
                let mut bound = Vec::new();
                for (name, expr) in &assignments {
                    cancellation_poll.checkpoint_at("writes.stage_sql")?;
                    let index = schema
                        .column_index(name)
                        .ok_or_else(|| state("unknown UPDATE column"))?;
                    if view
                        .database
                        .catalog
                        .definitions(schema.id)
                        .and_then(|d| d.identity.as_ref())
                        .is_some_and(|i| i.always && i.column == index)
                    {
                        return Err(PhobosError::new(
                            ErrorCode::ConstraintViolation,
                            "GENERATED ALWAYS identity cannot be updated",
                        ));
                    }
                    if bound.iter().any(|(existing, _)| *existing == index) {
                        return Err(state("column assigned twice"));
                    }
                    bound.push((index, expr));
                }
                for (rid, row) in view.database.mvcc_dml_snapshot(
                    &schema,
                    filter.as_ref(),
                    params,
                    self.statement_limit,
                )? {
                    if !matches_filter(filter.as_ref(), &schema, &row, params)? {
                        continue;
                    }
                    let mut next = row.clone();
                    for (index, expr) in &bound {
                        cancellation_poll.checkpoint_at("writes.stage_sql")?;
                        next.values[*index] = coerce_value(
                            &schema.columns[*index],
                            eval_expr(expr, &schema, Some(&row), params)?,
                        )?;
                    }
                    view.database
                        .catalog
                        .validate_row_definitions(schema.id, &next)?;
                    let change = self.change(&schema, Some(rid), Some(next), view)?;
                    self.resolve(&schema, change, &mut resolved, &mut resolution_bytes)?;
                }
                ("UPDATE", schema)
            }
            Statement::Delete { table, filter } => {
                let schema = view.database.table_schema(&table)?;
                for (rid, row) in view.database.mvcc_dml_snapshot(
                    &schema,
                    filter.as_ref(),
                    params,
                    self.statement_limit,
                )? {
                    if matches_filter(filter.as_ref(), &schema, &row, params)? {
                        let change = self.change(&schema, Some(rid), None, view)?;
                        self.resolve(&schema, change, &mut resolved, &mut resolution_bytes)?;
                    }
                }
                ("DELETE", schema)
            }
            _ => {
                return Err(state(
                    "session write statement must be INSERT, UPDATE or DELETE",
                ));
            }
        };
        let mut bytes = self.bytes;
        for change in &mut resolved {
            cancellation_poll.checkpoint_at("writes.stage_sql")?;
            change.charge = 128
                + change
                    .row
                    .as_ref()
                    .map(|row| {
                        phobos_storage::RowCodec::encode(&schema, row).map(|bytes| bytes.len())
                    })
                    .transpose()?
                    .unwrap_or(0);
            change.unique_hashes = match &change.row {
                Some(row) => spill::unique_hashes(&view.database.catalog, &schema, row)?,
                None => Vec::new(),
            };
            let old = self
                .changes
                .get(&(change.table, change.synthetic))
                .map_or(0, |old| old.charge);
            bytes = bytes
                .checked_sub(old)
                .and_then(|bytes| bytes.checked_add(change.charge))
                .ok_or_else(|| state("write accounting overflow"))?;
            if self.spill_root.is_none() && bytes > self.spill_threshold {
                return Err(PhobosError::new(
                    ErrorCode::ResourceLimit,
                    "session write memory limit exceeded",
                ));
            }
        }
        if view.database.catalog.has_foreign_keys() {
            let catalog = view.database.catalog.clone();
            catalog.validate_foreign_key_rows(|id| {
                let table = catalog
                    .tables()
                    .find(|t| t.id == id)
                    .ok_or_else(|| state("FK table missing"))?;
                let mut rows =
                    view.database
                        .mvcc_dml_snapshot(table, None, &[], self.statement_limit)?;
                for change in resolved.iter().filter(|c| c.table == id) {
                    rows.retain(|(rid, _)| {
                        *rid != change.synthetic
                            && change
                                .original
                                .as_ref()
                                .is_none_or(|(original, _)| rid != original)
                    });
                    if let Some(row) = &change.row {
                        rows.push((change.synthetic, row.clone()));
                    }
                }
                Ok(rows.into_iter().map(|(_, row)| row).collect())
            })?;
        }
        let pending = PendingView { writes: self };
        for change in &resolved {
            cancellation_poll.checkpoint_at("writes.stage_sql")?;
            admit(change, &pending)?;
        }
        let output = returning
            .map(|columns| {
                let names = match columns {
                    SelectColumns::All => schema.columns.iter().map(|c| c.name.clone()).collect(),
                    SelectColumns::Named(names) => names,
                };
                let positions = names
                    .iter()
                    .map(|n| {
                        schema.column_index(n).ok_or_else(|| {
                            PhobosError::new(ErrorCode::NotFound, "RETURNING column missing")
                        })
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                let rows = resolved
                    .iter()
                    .map(|c| {
                        Row::new(
                            positions
                                .iter()
                                .map(|i| c.row.as_ref().expect("INSERT row").values[*i].clone())
                                .collect(),
                        )
                    })
                    .collect();
                Ok::<_, PhobosError>(QueryResult::Rows {
                    columns: names,
                    rows,
                })
            })
            .transpose()?;
        let count = resolved.len() as u64;
        for change in resolved {
            cancellation_poll.checkpoint_at("writes.stage_sql")?;
            self.insert(change)?;
        }
        Ok(output.unwrap_or_else(|| QueryResult::Command {
            tag: tag.into(),
            rows_affected: count,
        }))
    }

    /// Transactional allocator row: uses ordinary ownership, UNIQUE, WAL and MVCC.
    /// Aborted transactions/savepoints may reuse values; committed counters never rewind.
    fn reserve_identity(
        &mut self,
        view: &mut SqlStatement<'_>,
        identity: &phobos_catalog::IdentityDefinition,
        count: usize,
        admit: &mut impl FnMut(&RowChange, &PendingView<'_>) -> Result<(), PhobosError>,
    ) -> Result<i64, PhobosError> {
        let schema = view
            .database
            .catalog
            .tables()
            .find(|t| t.id == identity.sequence_table)
            .cloned()
            .ok_or_else(|| state("identity allocator missing"))?;
        let rows = view
            .database
            .mvcc_dml_snapshot(&schema, None, &[], self.statement_limit)?;
        let (rid, first) = match rows.as_slice() {
            [] => (None, 1),
            [(rid, row)] => match row.values.as_slice() {
                [Value::Int64(1), Value::Int64(value)] if *value > 0 => (Some(*rid), *value),
                _ => {
                    return Err(PhobosError::new(
                        ErrorCode::InvalidCatalog,
                        "invalid identity allocator row",
                    ));
                }
            },
            _ => {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "multiple identity allocator rows",
                ));
            }
        };
        let next = first
            .checked_add(i64::try_from(count).map_err(|_| state("identity count overflow"))?)
            .ok_or_else(|| {
                PhobosError::new(ErrorCode::ConstraintViolation, "identity exhausted")
            })?;
        let row = Row::new(vec![Value::Int64(1), Value::Int64(next)]);
        let mut change = self.change(&schema, rid, Some(row), view)?;
        change.charge = 128
            + phobos_storage::RowCodec::encode(&schema, change.row.as_ref().expect("row"))?.len();
        change.unique_hashes = spill::unique_hashes(
            &view.database.catalog,
            &schema,
            change.row.as_ref().expect("row"),
        )?;
        admit(&change, &PendingView { writes: self }).map_err(|e| {
            if e.code == ErrorCode::ConstraintViolation {
                state("identity allocator changed concurrently; retry transaction")
            } else {
                e
            }
        })?;
        self.insert(change)?;
        Ok(first)
    }

    /// Publishes one admitted change into the memtable, spilling first when
    /// the memtable would exceed its threshold. A single change larger than
    /// the threshold is held alone and spilled by the next insertion.
    fn insert(&mut self, change: RowChange) -> Result<(), PhobosError> {
        let key = (change.table, change.synthetic);
        let old = self.changes.get(&key).map_or(0, |old| old.charge);
        let next = self
            .bytes
            .checked_sub(old)
            .and_then(|bytes| bytes.checked_add(change.charge))
            .ok_or_else(|| state("write accounting overflow"))?;
        if self.spill_root.is_some() && next > self.spill_threshold && !self.changes.is_empty() {
            self.flush_memtable()?;
            return self.insert(change);
        }
        if let Some(old) = self.changes.remove(&key) {
            for (index, hash) in &old.unique_hashes {
                self.keys.remove(&(*index, *hash, key));
            }
        }
        if let Some((rid, _)) = change.original {
            self.hidden.insert((change.table, rid));
        }
        for (index, hash) in &change.unique_hashes {
            self.keys.insert((*index, *hash, key));
        }
        if change.original.is_some() || change.row.is_some() {
            self.tables.insert(change.table);
        }
        self.bytes = next;
        self.stats.peak_memtable_bytes = self.stats.peak_memtable_bytes.max(next);
        self.changes.insert(key, change);
        Ok(())
    }
    fn flush_memtable(&mut self) -> Result<(), PhobosError> {
        let Some((root, quota)) = &self.spill_root else {
            return Err(state("spill requested without scratch root"));
        };
        if self.spill.is_none() {
            self.spill = Some(SpillStore::new(root, self.stable, *quota));
        }
        self.spill
            .as_mut()
            .expect("spill store")
            .flush(&self.changes)?;
        self.changes.clear();
        self.hidden.clear();
        self.keys.clear();
        self.bytes = 0;
        Ok(())
    }

    fn resolve(
        &self,
        schema: &TableSchema,
        mut change: RowChange,
        resolved: &mut Vec<RowChange>,
        bytes: &mut usize,
    ) -> Result<(), PhobosError> {
        change.charge = 128
            + change
                .row
                .as_ref()
                .map(|row| phobos_storage::RowCodec::encode(schema, row).map(|bytes| bytes.len()))
                .transpose()?
                .unwrap_or(0);
        *bytes = bytes
            .checked_add(change.charge)
            .ok_or_else(|| state("resolution accounting overflow"))?;
        if *bytes > self.statement_limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC resolved write memory limit exceeded",
            ));
        }
        resolved.push(change);
        Ok(())
    }
    fn change(
        &mut self,
        schema: &TableSchema,
        rid: Option<RecordId>,
        row: Option<Row>,
        view: &mut SqlStatement<'_>,
    ) -> Result<RowChange, PhobosError> {
        if let Some(rid) = rid {
            // The candidate may be this transaction's own synthetic row: keep its
            // identity (and original) and replace the row image.
            if let Some(existing) = self.lookup((schema.id, rid))? {
                return Ok(RowChange { row, ..existing });
            }
        }
        self.next = self
            .next
            .checked_add(1)
            .ok_or_else(|| state("transaction logical row namespace exhausted"))?;
        let synthetic = RecordId {
            page_id: (1u64 << 63) | u64::from(self.next),
            slot_id: 0,
        };
        let original = rid
            .map(|rid| {
                let (tuple, _) = view
                    .database
                    .heap_mut(schema.id)?
                    .get_version(rid)?
                    .ok_or_else(|| state("visible row version missing"))?;
                // 0.2-K Part H: the candidate was visible to this statement's
                // snapshot a moment ago, and visibility under one snapshot
                // does not change. A version that is not visible here is a
                // different occupant of a reused slot: never adopt it as the
                // original (that would update another logical row).
                if !view
                    .pin
                    .snapshot()
                    .visible(tuple.visibility, &mut view.pin.as_ref())?
                {
                    phobos_observability::event("mvcc.stale_rid_skipped", 1);
                    return Err(state("tuple version changed; transaction must retry"));
                }
                Ok::<_, PhobosError>((rid, tuple))
            })
            .transpose()?;
        let logical_row = original
            .map_or((self.stable << 32) | u64::from(self.next), |(_, tuple)| {
                tuple.logical_row
            });
        Ok(RowChange {
            table: schema.id,
            logical_row,
            original,
            row,
            synthetic,
            unique_hashes: Vec::new(),
            charge: 0,
        })
    }
}

/// Streaming view of every pending change (see `SessionWrites::changes`).
pub struct ChangeIter<'a> {
    merge: MergeIter,
    peak: &'a AtomicUsize,
}
impl std::fmt::Debug for ChangeIter<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ChangeIter").finish_non_exhaustive()
    }
}
impl Iterator for ChangeIter<'_> {
    type Item = Result<RowChange, PhobosError>;
    fn next(&mut self) -> Option<Self::Item> {
        self.merge.next_change().transpose()
    }
}
impl Drop for ChangeIter<'_> {
    fn drop(&mut self) {
        self.peak
            .fetch_max(self.merge.peak_records(), Ordering::Relaxed);
    }
}

/// Bounded-memory queries over the pending write set, for admission.
pub struct PendingView<'a> {
    writes: &'a SessionWrites,
}
impl PendingView<'_> {
    /// Whether the transaction already changed the row at `rid`.
    pub(super) fn owns_original(&self, table: TableId, rid: RecordId) -> Result<bool, PhobosError> {
        if self.writes.hidden.contains(&(table, rid)) {
            return Ok(true);
        }
        for run in self.writes.runs().iter().rev() {
            if run.is_hidden(table, rid)? {
                return Ok(true);
            }
        }
        Ok(false)
    }
    /// Whether a pending row other than `logical_row` (and not superseded by
    /// a change in `statement`) currently carries `key` for `definition`.
    pub(super) fn unique_conflict(
        &self,
        schema: &TableSchema,
        definition: &IndexSchema,
        key: &IndexKey,
        logical_row: u64,
        statement: &StatementOwn,
    ) -> Result<bool, PhobosError> {
        let Some(logical) = key.logical_unique_key() else {
            return Ok(false);
        };
        let hash = spill::key_hash(&logical);
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let mut candidates: Vec<ChangeKey> = self
            .writes
            .keys
            .range(
                (
                    definition.id,
                    hash,
                    (
                        0,
                        RecordId {
                            page_id: 0,
                            slot_id: 0,
                        },
                    ),
                )
                    ..=(
                        definition.id,
                        hash,
                        (
                            u64::MAX,
                            RecordId {
                                page_id: u64::MAX,
                                slot_id: u16::MAX,
                            },
                        ),
                    ),
            )
            .map(|(_, _, key)| *key)
            .collect();
        for run in self.writes.runs().iter().rev() {
            candidates.extend(run.key_candidates(definition.id, hash)?);
        }
        for candidate in candidates {
            cancellation_poll.checkpoint_at("writes.unique_conflict")?;
            if statement.contains(candidate) {
                continue;
            }
            let Some(current) = self.writes.lookup(candidate)? else {
                continue;
            };
            if current.logical_row == logical_row {
                continue;
            }
            if let Some(row) = &current.row {
                if index_key_for_row(schema, definition, row)?.logical_unique_key()
                    == Some(logical.clone())
                {
                    return Ok(true);
                }
            }
        }
        Ok(false)
    }
}

/// Changes admitted earlier in the current statement, indexed for the same
/// checks `PendingView` answers for earlier statements: one entry per logical
/// row (a later change to the same row replaces the earlier one), the
/// originals they replace, and their unique keys by hash.
#[derive(Default)]
pub struct StatementOwn {
    changes: BTreeMap<(TableId, u64), OwnRow>,
    originals: BTreeSet<ChangeKey>,
    synthetics: BTreeSet<ChangeKey>,
    keys: BTreeMap<(IndexId, u64), BTreeSet<(TableId, u64)>>,
}
/// 0.2-H: what a statement's own-row UNIQUE check needs of an earlier change
/// of the same statement — its UNIQUE key hashes and logical UNIQUE keys,
/// built once at admission — instead of a clone of the whole row change.
struct OwnRow {
    table: TableId,
    original: Option<RecordId>,
    synthetic: RecordId,
    unique_hashes: Vec<(IndexId, u64)>,
    logical: Vec<(IndexId, phobos_index::LogicalUniqueKey)>,
}
impl StatementOwn {
    /// `logical`: the change's logical UNIQUE key per UNIQUE index of its
    /// table (keys containing NULL omitted), exactly as admission built them.
    pub(super) fn push(
        &mut self,
        change: &RowChange,
        logical: Vec<(IndexId, phobos_index::LogicalUniqueKey)>,
    ) {
        let row = (change.table, change.logical_row);
        if let Some(prior) = self.changes.remove(&row) {
            for (index, hash) in &prior.unique_hashes {
                if let Some(rows) = self.keys.get_mut(&(*index, *hash)) {
                    rows.remove(&row);
                    if rows.is_empty() {
                        self.keys.remove(&(*index, *hash));
                    }
                }
            }
            if let Some(rid) = prior.original {
                self.originals.remove(&(prior.table, rid));
            }
            self.synthetics.remove(&(prior.table, prior.synthetic));
        }
        for (index, hash) in &change.unique_hashes {
            self.keys.entry((*index, *hash)).or_default().insert(row);
        }
        if let Some((rid, _)) = change.original {
            self.originals.insert((change.table, rid));
        }
        self.synthetics.insert((change.table, change.synthetic));
        self.changes.insert(
            row,
            OwnRow {
                table: change.table,
                original: change.original.map(|(rid, _)| rid),
                synthetic: change.synthetic,
                unique_hashes: change.unique_hashes.clone(),
                logical: if change.row.is_some() {
                    logical
                } else {
                    Vec::new()
                },
            },
        );
    }
    pub(super) fn owns_original(&self, table: TableId, rid: RecordId) -> bool {
        self.originals.contains(&(table, rid))
    }
    pub(super) fn contains(&self, key: ChangeKey) -> bool {
        self.synthetics.contains(&key)
    }
    /// Whether an earlier change of this statement to a row other than
    /// `logical_row` carries `key` for `definition`.
    pub(super) fn unique_conflict(
        &self,
        schema: &TableSchema,
        definition: &IndexSchema,
        key: &IndexKey,
        logical_row: u64,
    ) -> Result<bool, PhobosError> {
        let Some(logical) = key.logical_unique_key() else {
            return Ok(false);
        };
        let Some(rows) = self.keys.get(&(definition.id, spill::key_hash(&logical))) else {
            return Ok(false);
        };
        for row in rows {
            if row.0 != schema.id || row.1 == logical_row {
                continue;
            }
            let Some(prior) = self.changes.get(row) else {
                continue;
            };
            if prior
                .logical
                .iter()
                .any(|(index, prior)| *index == definition.id && *prior == logical)
            {
                return Ok(true);
            }
        }
        Ok(false)
    }
}

/// Spilled part of one table's own-write image for one statement. Rows and
/// originals of the memtable are held by the in-memory overlay fields; this
/// source answers for the runs, shadowed by any memtable version.
struct SpilledOverlay {
    table: TableId,
    runs: Vec<Arc<Run>>,
    memtable_keys: BTreeSet<RecordId>,
}
/// Synthetic rids (own rows) live above the physical page space.
fn synthetic(rid: RecordId) -> bool {
    rid.page_id & (1u64 << 63) != 0
}
impl OverlaySource for SpilledOverlay {
    fn hidden(&self, rid: RecordId) -> Result<bool, PhobosError> {
        if synthetic(rid) {
            return Ok(false);
        }
        for run in self.runs.iter().rev() {
            if run.is_hidden(self.table, rid)? {
                return Ok(true);
            }
        }
        Ok(false)
    }
    fn row(&self, rid: RecordId) -> Result<Option<Row>, PhobosError> {
        if !synthetic(rid) || self.memtable_keys.contains(&rid) {
            return Ok(None);
        }
        for run in self.runs.iter().rev() {
            if let Some(change) = run.find((self.table, rid))? {
                return Ok(change.row);
            }
        }
        Ok(None)
    }
    fn visit(
        &self,
        visitor: &mut dyn FnMut(RecordId, Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut merge = MergeIter::new(Vec::new(), &self.runs)?;
        while let Some(change) = merge.next_change()? {
            if change.table != self.table || self.memtable_keys.contains(&change.synthetic) {
                continue;
            }
            if let Some(row) = change.row {
                if !visitor(change.synthetic, row)? {
                    break;
                }
            }
        }
        Ok(())
    }
}

fn state(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TransactionState, message)
}
