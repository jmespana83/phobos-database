//! 0.2-F Part W: deterministic engine races around the store-validated index
//! images, memoized node layouts and cached navigation. Every interleaving is
//! forced with barriers or by holding a transaction open; the assertions are
//! the unchanged engine contract (UNIQUE authority, snapshot isolation, index
//! completeness), checked after every step through full B+tree validation.
//!
//! Fixture: `t(id,v,g)` with 1000 committed rows (`v = id`), unique `u(id)`,
//! composite unique `c(v,g)`, non-unique `d(g)`.
use super::*;
use std::{
    sync::{Arc, Barrier},
    thread,
    time::Duration,
};
use tests::fixture;

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            Value::Null => 0,
            ref other => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}
fn count(db: &MvccDatabase, session: u64, predicate: &str) -> i64 {
    scalar(
        db,
        session,
        &format!("SELECT COUNT(*) AS n FROM t WHERE {predicate}"),
    )
}
fn validate_all(db: &MvccDatabase) -> usize {
    let mut database = db.lock_database().unwrap();
    database
        .indexes
        .values_mut()
        .map(|tree| tree.validate().unwrap().entries)
        .sum()
}
fn is_conflict(result: Result<QueryResult, PhobosError>) -> bool {
    matches!(result, Err(error) if error.code == ErrorCode::ConstraintViolation)
}
fn rows(from: i64, to: i64, g: impl Fn(i64) -> String) -> String {
    (from..to)
        .map(|n| format!("({n},{n},{})", g(n)))
        .collect::<Vec<_>>()
        .join(",")
}
fn close(db: Arc<MvccDatabase>, sessions: impl IntoIterator<Item = u64>, root: &Path) {
    for session in sessions {
        db.disconnect(session);
    }
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// W1: two sessions insert the same UNIQUE key; the older one waits on the
/// younger owner and fails its final recheck after the owner commits.
#[test]
fn w1_concurrent_unique_insert_same_key_exactly_one_commits() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    // Session 2 writes first: it is the older transaction (waits, never victim).
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "INSERT INTO t VALUES (5100,5100,NULL)")
        .unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (5000,5000,1)").unwrap();
    let other = db.clone();
    let started = Arc::new(Barrier::new(2));
    let gate = started.clone();
    let contender = thread::spawn(move || {
        gate.wait();
        let staged = other.execute(2, "INSERT INTO t VALUES (5000,7,2)");
        let committed = staged.is_ok() && other.execute(2, "COMMIT").is_ok();
        if !committed {
            let _ = other.execute(2, "ROLLBACK");
        }
        committed
    });
    started.wait();
    thread::sleep(Duration::from_millis(30));
    db.execute(1, "COMMIT").unwrap();
    assert!(!contender.join().unwrap(), "duplicate UNIQUE key committed");
    assert_eq!(count(&db, 3, "id=5000"), 1);
    assert_eq!(
        count(&db, 3, "id=5100"),
        0,
        "the failed transaction rolled back"
    );
    assert_eq!(scalar(&db, 3, "SELECT v FROM t WHERE id=5000"), 5000);
    validate_all(&db);
    close(db, [1, 2, 3], &root);
}

/// W2: the competitor that owns the key aborts; the waiter's recheck sees no
/// committed duplicate and commits.
#[test]
fn w2_aborted_competitor_releases_the_key() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(2, "BEGIN").unwrap();
    db.execute(2, "INSERT INTO t VALUES (6100,6100,NULL)")
        .unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO t VALUES (6000,6000,1)").unwrap();
    let other = db.clone();
    let started = Arc::new(Barrier::new(2));
    let gate = started.clone();
    let contender = thread::spawn(move || {
        gate.wait();
        other.execute(2, "INSERT INTO t VALUES (6000,6001,2)")?;
        other.execute(2, "COMMIT")
    });
    started.wait();
    thread::sleep(Duration::from_millis(30));
    db.execute(1, "ROLLBACK").unwrap();
    contender.join().unwrap().unwrap();
    assert_eq!(count(&db, 3, "id=6000"), 1);
    assert_eq!(scalar(&db, 3, "SELECT v FROM t WHERE id=6000"), 6001);
    assert!(is_conflict(
        db.execute(3, "INSERT INTO t VALUES (6000,1,NULL)")
    ));
    validate_all(&db);
    close(db, [1, 2, 3], &root);
}

/// W3: leaf, internal and root splits published while an older snapshot is
/// open; the old snapshot's probes (served through cached navigation and
/// memoized layouts) never see the new keys, new snapshots see all of them,
/// and UNIQUE probes after the splits still find every committed key.
#[test]
fn w3_splits_and_root_change_during_open_snapshot() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(1, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
    assert_eq!(count(&db, 1, "id=500"), 1);
    assert_eq!(count(&db, 1, "id>=10000"), 0);
    let before = validate_all(&db);
    for batch in 0..20i64 {
        let from = 10_000 + batch * 250;
        db.execute(
            2,
            &format!(
                "INSERT INTO t VALUES {}",
                rows(from, from + 250, |n| n.to_string())
            ),
        )
        .unwrap();
        // The open snapshot keeps its view between publications.
        assert_eq!(count(&db, 1, &format!("id={from}")), 0);
        assert_eq!(count(&db, 1, "id=999"), 1);
    }
    assert!(validate_all(&db) >= before + 3 * 5000);
    assert_eq!(count(&db, 1, "id>=10000"), 0);
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(count(&db, 3, "id>=10000"), 5000);
    for probe in [10_000i64, 12_345, 14_999, 0, 999] {
        assert!(is_conflict(
            db.execute(3, &format!("INSERT INTO t VALUES ({probe},-1,-1)"))
        ));
    }
    db.execute(3, "INSERT INTO t VALUES (15000,15000,15000)")
        .unwrap();
    validate_all(&db);
    close(db, [1, 2, 3], &root);
}

/// W4: indexed UPDATE that changes the key: the old key disappears from the
/// UNIQUE index for new snapshots, the new key conflicts, the old key is free.
#[test]
fn w4_indexed_update_key_change() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(1, "UPDATE t SET id=id+100000 WHERE id<50")
        .unwrap();
    assert_eq!(count(&db, 2, "id<50"), 0);
    assert_eq!(count(&db, 2, "id>=100000 AND id<100050"), 50);
    assert!(is_conflict(
        db.execute(2, "INSERT INTO t VALUES (100007,1,1)")
    ));
    db.execute(2, "INSERT INTO t VALUES (7,7,7)").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT g FROM t WHERE id=7"), 7);
    // A composite key change through the same path.
    db.execute(1, "UPDATE t SET v=v+500000 WHERE id=600")
        .unwrap();
    assert_eq!(count(&db, 2, "v=600"), 0);
    assert_eq!(count(&db, 2, "v=500600"), 1);
    validate_all(&db);
    close(db, [1, 2], &root);
}

/// W5: DELETE then INSERT of the same UNIQUE key, inside one transaction and
/// across transactions; the deleted version never blocks the new owner.
#[test]
fn w5_delete_then_insert_same_key() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "DELETE FROM t WHERE id=10").unwrap();
    db.execute(1, "INSERT INTO t VALUES (10,-10,NULL)").unwrap();
    assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=10"), -10);
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=10"), -10);
    assert!(is_conflict(
        db.execute(2, "INSERT INTO t VALUES (10,0,NULL)")
    ));
    db.execute(2, "DELETE FROM t WHERE id=11").unwrap();
    db.execute(2, "INSERT INTO t VALUES (11,-11,NULL)").unwrap();
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=11"), -11);
    assert_eq!(count(&db, 2, "id=10 OR id=11"), 2);
    validate_all(&db);
    close(db, [1, 2], &root);
}

/// W6: a rolled-back multi-row transaction that split pages leaves no index
/// entry behind; the same keys commit afterwards.
#[test]
fn w6_rollback_after_splits_leaves_no_entries() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let before = validate_all(&db);
    db.execute(1, "BEGIN").unwrap();
    for batch in 0..8i64 {
        let from = 20_000 + batch * 500;
        db.execute(
            1,
            &format!(
                "INSERT INTO t VALUES {}",
                rows(from, from + 500, |n| n.to_string())
            ),
        )
        .unwrap();
    }
    assert_eq!(count(&db, 1, "id>=20000"), 4000);
    db.execute(1, "ROLLBACK").unwrap();
    assert_eq!(count(&db, 2, "id>=20000"), 0);
    assert_eq!(validate_all(&db), before);
    db.execute(
        2,
        &format!(
            "INSERT INTO t VALUES {}",
            rows(20_000, 24_000, |n| n.to_string())
        ),
    )
    .unwrap();
    assert_eq!(count(&db, 2, "id>=20000"), 4000);
    validate_all(&db);
    close(db, [1, 2], &root);
}

/// W7: a checkpoint between concurrent writers (barrier-aligned rounds);
/// all writes stay visible, UNIQUE stays enforced, the trees stay valid.
#[test]
fn w7_checkpoint_during_concurrent_workload() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let rounds = 6;
    let writers = 4u64;
    let barrier = Arc::new(Barrier::new(writers as usize + 1));
    let mut handles = Vec::new();
    for session in 1..=writers {
        let db = db.clone();
        let barrier = barrier.clone();
        handles.push(thread::spawn(move || {
            for round in 0..rounds {
                barrier.wait();
                for k in 0..25i64 {
                    let id = 30_000 + (session as i64) * 1000 + round * 25 + k;
                    db.execute(session, &format!("INSERT INTO t VALUES ({id},{id},{id})"))
                        .unwrap();
                }
                // Everyone also races on one shared key per round.
                let shared = 40_000 + round;
                let _ = db.execute(
                    session,
                    &format!("INSERT INTO t VALUES ({shared},{shared},1)"),
                );
                barrier.wait();
            }
        }));
    }
    for _ in 0..rounds {
        barrier.wait();
        db.execute(99, "CHECKPOINT").unwrap();
        barrier.wait();
    }
    for handle in handles {
        handle.join().unwrap();
    }
    db.execute(99, "CHECKPOINT").unwrap();
    assert_eq!(count(&db, 98, "id>=30000 AND id<40000"), 4 * 6 * 25);
    assert_eq!(count(&db, 98, "id>=40000"), 6);
    validate_all(&db);
    close(db, [1, 2, 3, 4, 98, 99], &root);
}

/// W8: reclaimed versions and emptied index pages; probes and UNIQUE checks
/// after reclamation never use a stale image of a reclaimed page.
#[test]
fn w8_reclaimed_pages_are_never_served_stale() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(
        1,
        &format!(
            "INSERT INTO t VALUES {}",
            rows(50_000, 53_000, |n| (1_000_000 + n).to_string())
        ),
    )
    .unwrap();
    // Warm every cached path, then delete and reclaim.
    assert_eq!(count(&db, 2, "id>=50000"), 3000);
    assert_eq!(count(&db, 2, "g>=1050000"), 3000);
    db.execute(1, "DELETE FROM t WHERE id>=50000").unwrap();
    let mut reclaimed = 0;
    for _ in 0..16 {
        let report = db.reclaim_once(1024).unwrap();
        reclaimed += report.versions_reclaimed;
        if report.versions_reclaimed == 0 {
            break;
        }
    }
    assert_eq!(reclaimed, 3000);
    assert_eq!(count(&db, 2, "id>=50000"), 0);
    assert_eq!(count(&db, 2, "g>=1050000"), 0);
    // Reused pages: new keys appear, old ones stay gone, UNIQUE intact.
    db.execute(
        1,
        &format!(
            "INSERT INTO t VALUES {}",
            rows(60_000, 61_500, |n| (2_000_000 + n).to_string())
        ),
    )
    .unwrap();
    assert_eq!(count(&db, 2, "id>=60000"), 1500);
    assert_eq!(count(&db, 2, "id>=50000 AND id<53000"), 0);
    db.execute(2, "INSERT INTO t VALUES (51234,1,NULL)")
        .unwrap();
    assert!(is_conflict(
        db.execute(2, "INSERT INTO t VALUES (60001,1,NULL)")
    ));
    validate_all(&db);
    close(db, [1, 2], &root);
}

/// W9: restart (recovery path) then writes: the store revalidates every
/// image read from disk; lookups, UNIQUE conflicts and new keys are exact.
#[test]
fn w9_recovery_then_writes() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(
        1,
        &format!(
            "INSERT INTO t VALUES {}",
            rows(70_000, 72_000, |n| n.to_string())
        ),
    )
    .unwrap();
    db.execute(1, "UPDATE t SET id=id+1000000 WHERE id<10")
        .unwrap();
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    validate_all(&db);
    assert_eq!(count(&db, 2, "id>=70000 AND id<72000"), 2000);
    assert_eq!(count(&db, 2, "id<10"), 0);
    assert!(is_conflict(
        db.execute(2, "INSERT INTO t VALUES (71999,1,1)")
    ));
    assert!(is_conflict(
        db.execute(2, "INSERT INTO t VALUES (1000003,1,1)")
    ));
    db.execute(2, "INSERT INTO t VALUES (3,3,3)").unwrap();
    db.execute(2, "INSERT INTO t VALUES (72000,72000,72000)")
        .unwrap();
    assert_eq!(count(&db, 2, "id>=70000 AND id<=72000"), 2001);
    validate_all(&db);
    close(db, [2], &root);
}

/// W10: sixteen sessions start together (barrier) and race on hot shared
/// keys and on adjacent fresh keys that split the same leaves. Exactly one
/// owner per shared key; every fresh key present once; trees valid.
#[test]
fn w10_sixteen_session_hot_key_and_adjacent_split_race() {
    let root = fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    let sessions = 16u64;
    let barrier = Arc::new(Barrier::new(sessions as usize));
    let mut handles = Vec::new();
    for session in 1..=sessions {
        let db = db.clone();
        let barrier = barrier.clone();
        handles.push(thread::spawn(move || {
            barrier.wait();
            let mut won = 0;
            for k in 0..40i64 {
                // Adjacent keys from all sessions interleave in the same leaves.
                let fresh = 100_000 + k * 16 + session as i64;
                db.execute(
                    session,
                    &format!("INSERT INTO t VALUES ({fresh},{fresh},NULL)"),
                )
                .unwrap();
                if k % 4 == 0 {
                    let hot = 200_000 + k;
                    match db.execute(session, &format!("INSERT INTO t VALUES ({hot},{hot},NULL)")) {
                        Ok(_) => won += 1,
                        // Lost the race: a UNIQUE violation after waiting, or
                        // the younger-victim rule while the owner was in flight.
                        Err(error) => assert!(matches!(
                            error.code,
                            ErrorCode::ConstraintViolation | ErrorCode::TransactionState
                        )),
                    }
                }
            }
            won
        }));
    }
    let won: i64 = handles.into_iter().map(|h| h.join().unwrap()).sum();
    assert_eq!(won, 10, "each hot key has exactly one owner");
    assert_eq!(count(&db, 99, "id>=100000 AND id<200000"), 16 * 40);
    assert_eq!(count(&db, 99, "id>=200000"), 10);
    validate_all(&db);
    close(db, (1..=sessions).chain([99]), &root);
}
