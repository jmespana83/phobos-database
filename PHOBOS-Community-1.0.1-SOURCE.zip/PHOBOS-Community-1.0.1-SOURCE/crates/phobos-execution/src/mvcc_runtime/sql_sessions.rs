//! Ordinary SQL connection dispatch. An explicit transaction owns logical writes,
//! never a database execution lease between statements.
use super::*;
use std::{sync::Condvar, time::Duration};

#[derive(Default)]
pub(super) struct Admission {
    state: Mutex<(bool, usize)>,
    changed: Condvar,
}
pub(super) struct Admitted<'a>(&'a Admission);
impl Drop for Admitted<'_> {
    fn drop(&mut self) {
        if let Ok(mut state) = self.0.state.lock() {
            state.1 -= 1;
        }
        self.0.changed.notify_all();
    }
}

pub(super) struct Connection {
    pub(super) session: Session,
    /// D1: created by the first write of a transaction (which allocates the
    /// stable identity), never by BEGIN. `None` inside an explicit
    /// transaction means it has not written yet.
    pub(super) writes: Option<SessionWrites>,
    /// An explicit `BEGIN` is open (with or without writes).
    pub(super) explicit: bool,
    /// A2 cancellation control of the open transaction generation. BEGIN
    /// registers it at once (a cancel before the first write still marks the
    /// transaction cancelled, exactly as before D1); the first write hands it
    /// to the session writes.
    pub(super) control: Option<Arc<ownership::WaitControl>>,
    /// Long-lived G5 Snapshot Isolation retention pin. Ordinary BEGIN leaves
    /// this empty and therefore retains Read Committed statement snapshots.
    pub(super) snapshot: Option<SnapshotPin>,
    pub(super) savepoints: Vec<NamedSavepoint>,
}
pub(super) struct NamedSavepoint {
    name: String,
    marker: Option<writes::SavepointMarker>,
}
impl Drop for Connection {
    fn drop(&mut self) {
        // Session destruction can persist abort status. Discard private state
        // and release conflict ownership before that terminal transition.
        drop(self.writes.take());
        self.savepoints.clear();
        self.snapshot.take();
    }
}
impl MvccDatabase {
    fn partition_write_statements(
        &self,
        writes: &SessionWrites,
        statement: Statement,
    ) -> Result<Vec<Statement>, PhobosError> {
        let statement = if let Statement::InsertColumns {
            table,
            columns,
            rows,
        } = statement
        {
            let catalog = if let Some(schema) = &writes.schema {
                schema.catalog.clone()
            } else {
                self.readers
                    .read()
                    .map_err(|_| write_conflict("read directory poisoned"))?
                    .catalog
                    .clone()
            };
            expand_insert_columns(&catalog, table, columns, rows)?
        } else {
            statement
        };
        let target = match &statement {
            Statement::Insert { table, .. }
            | Statement::Update { table, .. }
            | Statement::Delete { table, .. } => Some(table.as_str()),
            _ => None,
        };
        let Some(target) = target else {
            return Ok(vec![statement]);
        };
        let partitioned = if let Some(schema) = writes.schema.as_deref() {
            schema.catalog.partition_key(target).is_some()
        } else {
            self.readers
                .read()
                .map_err(|_| write_conflict("read directory poisoned"))?
                .catalog
                .partition_key(target)
                .is_some()
        };
        if !partitioned {
            return Ok(vec![statement]);
        }
        let catalog = if let Some(schema) = writes.schema.as_deref() {
            schema.catalog.clone()
        } else {
            self.readers
                .read()
                .map_err(|_| write_conflict("read directory poisoned"))?
                .catalog
                .clone()
        };
        let literal = |expr: &Expr| -> Result<Value, PhobosError> {
            match expr {
                Expr::Literal(value) => Ok(value.clone()),
                Expr::Unary {
                    op: UnaryOp::Negate,
                    expr,
                } => match expr.as_ref() {
                    Expr::Literal(Value::Int64(value)) => {
                        Ok(Value::Int64(value.checked_neg().ok_or_else(|| {
                            PhobosError::new(ErrorCode::Semantic, "partition key overflow")
                        })?))
                    }
                    Expr::Literal(Value::Float64(value)) => Ok(Value::Float64(-value)),
                    _ => Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "partition routing requires constant INSERT keys",
                    )),
                },
                _ => Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "partition routing requires constant INSERT keys",
                )),
            }
        };
        let choose = |parent: &str, value: &Value| -> Result<String, PhobosError> {
            catalog
                .partitions_for_parent(parent)
                .find(|part| {
                    value
                        .canonical_cmp(&part.lower)
                        .is_some_and(|o| o != std::cmp::Ordering::Less)
                        && value.canonical_cmp(&part.upper) == Some(std::cmp::Ordering::Less)
                })
                .map(|part| part.child.clone())
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::ConstraintViolation, "no partition accepts row")
                })
        };
        Ok(match statement {
            Statement::Insert { table, rows } if catalog.partition_key(&table).is_some() => {
                let schema = catalog.table(&table).ok_or_else(|| {
                    PhobosError::new(ErrorCode::NotFound, "partition parent missing")
                })?;
                let key = schema
                    .column_index(catalog.partition_key(&table).expect("checked"))
                    .expect("catalog partition key");
                let mut groups = BTreeMap::<String, Vec<Vec<Expr>>>::new();
                for row in rows {
                    let value = row
                        .get(key)
                        .ok_or_else(|| {
                            PhobosError::new(ErrorCode::Semantic, "INSERT column count mismatch")
                        })
                        .and_then(literal)?;
                    groups.entry(choose(&table, &value)?).or_default().push(row);
                }
                groups
                    .into_iter()
                    .map(|(table, rows)| Statement::Insert { table, rows })
                    .collect()
            }
            Statement::Update {
                table,
                assignments,
                filter,
            } if catalog.partition_key(&table).is_some() => {
                let key = catalog.partition_key(&table).expect("checked");
                if assignments
                    .iter()
                    .any(|(name, _)| name.eq_ignore_ascii_case(key))
                {
                    return Err(PhobosError::new(
                        ErrorCode::Unsupported,
                        "cross-partition key UPDATE is not supported",
                    ));
                }
                catalog
                    .partitions_for_parent(&table)
                    .map(|part| Statement::Update {
                        table: part.child.clone(),
                        assignments: assignments.clone(),
                        filter: filter.clone(),
                    })
                    .collect()
            }
            Statement::Delete { table, filter } if catalog.partition_key(&table).is_some() => {
                catalog
                    .partitions_for_parent(&table)
                    .map(|part| Statement::Delete {
                        table: part.child.clone(),
                        filter: filter.clone(),
                    })
                    .collect()
            }
            statement => vec![statement],
        })
    }
    pub(super) fn admit_statement(&self, sql: &str) -> Result<Admitted<'_>, PhobosError> {
        let mut state = self
            .admission
            .state
            .lock()
            .map_err(|_| write_conflict("admission poisoned"))?;
        if state.0 && !matches!(parse(sql)?, Statement::Commit | Statement::Rollback) {
            return Err(write_conflict("database is shutting down"));
        }
        state.1 = state
            .1
            .checked_add(1)
            .ok_or_else(|| write_conflict("admission exhausted"))?;
        Ok(Admitted(&self.admission))
    }
    pub fn shutdown(&self, timeout: Duration) -> Result<(), PhobosError> {
        let deadline = Instant::now() + timeout;
        // 0.2-K: the automatic reclamation worker (if any) stops after its
        // current pass; its idle session does not hold the drain below.
        self.maintenance.stop();
        let mut admission = self
            .admission
            .state
            .lock()
            .map_err(|_| write_conflict("admission poisoned"))?;
        admission.0 = true;
        while admission.1 != 0 || !self.sessions.is_idle()? {
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err(write_conflict(
                    "shutdown requires active statements/transactions to drain",
                ));
            }
            let (next, _) = self
                .admission
                .changed
                .wait_timeout(admission, remaining)
                .map_err(|_| write_conflict("admission poisoned"))?;
            admission = next;
        }
        drop(admission);
        let drain = self
            .lock_database()?
            .committed_store
            .as_ref()
            .expect("MVCC store")
            .config()
            .drain_on_shutdown;
        if drain {
            self.checkpoint()?;
        }
        let mut database = self.lock_database()?;
        database
            .committed_store
            .as_ref()
            .expect("MVCC store")
            .stop()?;
        database.fenced = true;
        self.fenced
            .store(true, std::sync::atomic::Ordering::Release);
        Ok(())
    }
    pub fn is_capable(path: &Path) -> Result<bool, PhobosError> {
        let directory = path;
        let path = path.join("phobos.wal");
        // 0.2-I.3: an interrupted segment rotation leaves no complete active
        // WAL. The sealed history (validated by `inspect`; any error fails the
        // open) decides the capability, and WAL recovery repairs the layout.
        let interrupted = || -> Result<bool, PhobosError> {
            Ok(phobos_wal::v2::interrupted_rotation(directory)?
                && phobos_wal::v2::inspect(&path)?.page_format == 4)
        };
        if !path.exists() {
            return interrupted();
        }
        let mut file = File::open(&path)?;
        let mut prefix = [0; 6];
        if file.metadata()?.len() < 6 {
            return interrupted();
        }
        file.read_exact(&mut prefix)?;
        if prefix != *b"PHWL\x02\x00" {
            return interrupted();
        }
        Ok(phobos_wal::v2::inspect(path)?.page_format == 4)
    }
    pub(super) fn connection(&self, id: u64) -> Result<Arc<Mutex<Connection>>, PhobosError> {
        let mut connections = self
            .connections
            .lock()
            .map_err(|_| write_conflict("connection map poisoned"))?;
        if let Some(connection) = connections.get(&id) {
            return Ok(connection.clone());
        }
        let connection = Arc::new(Mutex::new(Connection {
            session: self.connect(id)?,
            writes: None,
            explicit: false,
            control: None,
            snapshot: None,
            savepoints: Vec::new(),
        }));
        connections.insert(id, connection.clone());
        Ok(connection)
    }
    pub fn disconnect(&self, id: u64) {
        let removed = self
            .connections
            .lock()
            .ok()
            .and_then(|mut connections| connections.remove(&id));
        let control = self
            .controls
            .lock()
            .ok()
            .and_then(|mut controls| controls.remove(&id));
        if let Some(control) = control {
            control.cancel();
            self.ownership.wake();
        }
        // Destruction can abort/force status; never do it under the map guard.
        drop(removed);
        self.admission.changed.notify_all();
    }
    pub(super) fn register_control(
        &self,
        id: u64,
        writes: &SessionWrites,
    ) -> Result<(), PhobosError> {
        self.register_wait_control(id, &writes.control)
    }
    fn register_wait_control(
        &self,
        id: u64,
        control: &Arc<ownership::WaitControl>,
    ) -> Result<(), PhobosError> {
        // Registration and removal use the same order. A disconnect that races
        // BEGIN cannot miss a control inserted after its cancellation lookup.
        let connections = self
            .connections
            .lock()
            .map_err(|_| write_conflict("connection map poisoned"))?;
        if !connections.contains_key(&id) {
            control.cancel();
            return Err(write_conflict("session disconnected"));
        }
        self.controls
            .lock()
            .map_err(|_| write_conflict("cancellation map poisoned"))?
            .insert(id, control.clone());
        Ok(())
    }
    pub(super) fn finish_control(&self, id: u64) {
        if let Ok(mut controls) = self.controls.lock() {
            controls.remove(&id);
        }
    }
    /// The transaction's cancellation control, registered on first use.
    fn transaction_control(
        &self,
        id: u64,
        connection: &mut Connection,
    ) -> Result<Arc<ownership::WaitControl>, PhobosError> {
        if let Some(control) = &connection.control {
            return Ok(control.clone());
        }
        let control = Arc::new(ownership::WaitControl::with_timeout(
            std::time::Duration::from_millis(self.runtime_config.lock_timeout_ms),
        ));
        self.register_wait_control(id, &control)?;
        connection.control = Some(control.clone());
        Ok(control)
    }
    /// Leaves the transaction: the control is unregistered and forgotten.
    fn leave_transaction(&self, id: u64, connection: &mut Connection) {
        connection.explicit = false;
        connection.control = None;
        connection.savepoints.clear();
        connection.snapshot.take();
        self.finish_control(id);
    }
    /// D1: the first write of a transaction allocates its identity and its
    /// session writes; later writes reuse both.
    pub(super) fn ensure_writes(
        &self,
        id: u64,
        connection: &mut Connection,
    ) -> Result<(), PhobosError> {
        if connection.writes.is_some() {
            return Ok(());
        }
        let control = self.transaction_control(id, connection)?;
        let stable = connection.session.ensure_transaction_id()?;
        let mut writes = self.session_writes(stable)?;
        writes.control = control;
        connection.writes = Some(writes);
        Ok(())
    }
    fn submit_connection(
        &self,
        id: u64,
        session: &Session,
        writes: &mut Option<SessionWrites>,
    ) -> Result<(), PhobosError> {
        // C9: a bulk import sorts/validates its index keys first. Failures
        // here precede any irrevocable permit, so they abort like a bad chunk.
        let result = match writes.as_mut() {
            Some(active) => self.finalize_bulk(session, active),
            None => Ok(()),
        }
        .and_then(|()| self.enqueue_commit(session, writes));
        self.finish_control(id);
        if result.is_err() {
            if let Some(writes) = writes {
                // Session ownership means no irrevocable permit was created.
                writes.discard();
                session.abort_failed()?;
            }
        }
        result
    }
    pub fn execute(&self, id: u64, sql: &str) -> Result<QueryResult, PhobosError> {
        let _admitted = self.admit_statement(sql)?;
        let result = self.execute_inner(id, sql);
        if let Err(error) = &result {
            self.statement_error(id, sql, error)?;
        }
        result
    }
    /// Execute a previously parsed, parameterless read against a fresh MVCC
    /// statement view. DDL generation validation is performed by the server
    /// before this entry point is called.
    pub fn execute_prepared_read(
        &self,
        id: u64,
        statement: Statement,
    ) -> Result<QueryResult, PhobosError> {
        read_statement(&statement)?;
        let _admitted = {
            let mut state = self
                .admission
                .state
                .lock()
                .map_err(|_| write_conflict("admission poisoned"))?;
            if state.0 {
                return Err(write_conflict("database is shutting down"));
            }
            state.1 = state
                .1
                .checked_add(1)
                .ok_or_else(|| write_conflict("admission exhausted"))?;
            Admitted(&self.admission)
        };
        phobos_error::cancellation::check_now()?;
        let connection = self.connection(id)?;
        let connection = connection
            .lock()
            .map_err(|_| write_conflict("SQL session poisoned"))?;
        if connection
            .writes
            .as_ref()
            .is_some_and(|writes| writes.bulk.is_some())
        {
            return Err(write_conflict(
                "prepared reads are unavailable inside a bulk import",
            ));
        }
        let sequence = connection
            .snapshot
            .as_ref()
            .map(|pin| pin.snapshot().sequence());
        let mut view = self.statement_for_at(
            &connection.session,
            connection.writes.as_ref(),
            sequence,
            &statement,
        )?;
        drop(connection);
        view.execute_parsed(statement)
    }
    fn statement_error(&self, id: u64, sql: &str, error: &PhobosError) -> Result<(), PhobosError> {
        if phobos_error::cancellation::is_interrupted(error) {
            let _cleanup = phobos_error::cancellation::suspend();
            // There are no statement savepoints. Read-only cancellation releases
            // the statement pin; write cancellation aborts all staged effects.
            if parse(sql).is_ok_and(|statement| read_statement(&statement).is_ok()) {
                return Ok(());
            }
            if let Ok(connections) = self.connections.lock() {
                if let Some(connection) = connections.get(&id).cloned() {
                    drop(connections);
                    if let Ok(mut connection) = connection.lock() {
                        if let Some(writes) = connection.writes.as_mut() {
                            writes.discard();
                        }
                        if connection.writes.is_some() || connection.explicit {
                            connection.session.abort_failed()?;
                        }
                    }
                }
            }
            return Ok(());
        }
        self.mark_statement_failed(id);
        Ok(())
    }
    fn mark_statement_failed(&self, id: u64) {
        let connection = self
            .connections
            .lock()
            .ok()
            .and_then(|connections| connections.get(&id).cloned());
        if let Some(connection) = connection {
            if let Ok(connection) = connection.lock() {
                let _ = connection.session.fail_statement();
            }
        }
    }
    fn execute_inner(&self, id: u64, sql: &str) -> Result<QueryResult, PhobosError> {
        let connection = self.connection(id)?;
        let mut connection = connection
            .lock()
            .map_err(|_| write_conflict("SQL session poisoned"))?;
        let parse_site = phobos_observability::span("sql.parse_site.session_dispatch");
        let statement = parse(sql)?;
        drop(parse_site);
        if !matches!(
            statement,
            Statement::Rollback | Statement::RollbackTo { .. }
        ) {
            phobos_error::cancellation::check_now()?;
        }
        if connection
            .writes
            .as_ref()
            .is_some_and(|writes| writes.bulk.is_some())
            && !matches!(statement, Statement::Commit | Statement::Rollback)
        {
            return Err(write_conflict(
                "bulk import accepts only chunks, COMMIT or ROLLBACK",
            ));
        }
        match statement {
            Statement::Begin | Statement::BeginSnapshot => {
                // D1: no identity, no status record, no session writes until
                // the first write statement; only the A2 cancellation control
                // exists from here on.
                connection.session.begin_deferred()?;
                connection.explicit = true;
                if matches!(statement, Statement::BeginSnapshot) {
                    connection.snapshot = Some(connection.session.pin_transaction_snapshot()?);
                }
                if let Err(error) = self.transaction_control(id, &mut connection) {
                    connection.session.rollback()?;
                    connection.explicit = false;
                    connection.snapshot.take();
                    return Err(error);
                }
                Ok(command(if connection.snapshot.is_some() {
                    "BEGIN SNAPSHOT"
                } else {
                    "BEGIN"
                }))
            }
            Statement::Commit => {
                if connection.writes.is_none() {
                    if !connection.explicit {
                        return Err(write_conflict("COMMIT without transaction"));
                    }
                    // D1: read-only COMMIT — nothing to publish or persist.
                    connection.session.finish_read_only()?;
                    self.leave_transaction(id, &mut connection);
                    return Ok(command("COMMIT"));
                }
                let result = {
                    let Connection {
                        session, writes, ..
                    } = &mut *connection;
                    self.submit_connection(id, session, writes)
                };
                if connection.writes.is_none() {
                    // Admitted: the transaction resolved (committed, or D2
                    // aborted alone) and the connection is out of it.
                    self.leave_transaction(id, &mut connection);
                }
                result?;
                Ok(command("COMMIT"))
            }
            Statement::Rollback => {
                if connection.writes.is_none() && !connection.explicit {
                    return Err(write_conflict("ROLLBACK without transaction"));
                }
                drop(connection.writes.take());
                connection.session.rollback()?;
                self.leave_transaction(id, &mut connection);
                Ok(command("ROLLBACK"))
            }
            Statement::Savepoint { name } => {
                if !connection.explicit {
                    return Err(write_conflict("SAVEPOINT requires an explicit transaction"));
                }
                let marker = connection
                    .writes
                    .as_mut()
                    .map(SessionWrites::savepoint)
                    .transpose()?;
                connection.savepoints.push(NamedSavepoint {
                    name: name.to_ascii_lowercase(),
                    marker,
                });
                Ok(command("SAVEPOINT"))
            }
            Statement::RollbackTo { name } => {
                if !connection.explicit {
                    return Err(write_conflict(
                        "ROLLBACK TO requires an explicit transaction",
                    ));
                }
                let name = name.to_ascii_lowercase();
                let position = connection
                    .savepoints
                    .iter()
                    .rposition(|point| point.name == name)
                    .ok_or_else(|| write_conflict("savepoint does not exist"))?;
                let marker = connection.savepoints[position].marker.clone();
                match (connection.writes.as_mut(), marker.as_ref()) {
                    (Some(writes), Some(marker)) => writes.rollback_to(marker)?,
                    (Some(writes), None) => writes.discard(),
                    (None, Some(_)) => {
                        return Err(write_conflict("savepoint write state is missing"));
                    }
                    (None, None) => {}
                }
                connection.savepoints.truncate(position + 1);
                connection.session.recover_to_savepoint()?;
                Ok(command("ROLLBACK TO"))
            }
            Statement::ReleaseSavepoint { name } => {
                if !connection.explicit {
                    return Err(write_conflict(
                        "RELEASE SAVEPOINT requires an explicit transaction",
                    ));
                }
                let name = name.to_ascii_lowercase();
                let position = connection
                    .savepoints
                    .iter()
                    .rposition(|point| point.name == name)
                    .ok_or_else(|| write_conflict("savepoint does not exist"))?;
                connection.savepoints.truncate(position);
                Ok(command("RELEASE"))
            }
            Statement::Checkpoint => {
                if connection.writes.is_some() || connection.explicit {
                    return Err(write_conflict("CHECKPOINT requires no active transaction"));
                }
                phobos_error::cancellation::commit()?;
                let _durability = phobos_error::cancellation::suspend();
                // C2: one bounded reclaim pass rides on the existing
                // maintenance statement, before the checkpoint covers it.
                self.reclaim_with_session(&connection.session, CHECKPOINT_RECLAIM_PAGES, None)?;
                self.freeze_once(CHECKPOINT_RECLAIM_PAGES)?;
                self.checkpoint()?;
                Ok(command("CHECKPOINT"))
            }
            statement @ (Statement::InsertSelect { .. }
            | Statement::InsertReturning { .. }
            | Statement::InsertColumns { .. }
            | Statement::Insert { .. }
            | Statement::Update { .. }
            | Statement::Delete { .. }
            | Statement::RenameTable { .. }
            | Statement::CreateView { .. }
            | Statement::DropView { .. }
            | Statement::CreateDefinedTable { .. }
            | Statement::AddColumn { .. }
            | Statement::AlterNullable { .. }
            | Statement::AlterDefault { .. }
            | Statement::CreateTable { .. }
            | Statement::CreatePartitionedTable { .. }
            | Statement::CreateRangePartition { .. }
            | Statement::CreateIndex { .. }
            | Statement::DropIndex { .. }
            | Statement::Analyze { .. }) => {
                let autocommit = !connection.explicit && connection.writes.is_none();
                if autocommit {
                    connection.session.begin_deferred()?;
                }
                // D1: the first write allocates exactly one identity.
                let prepared = self.ensure_writes(id, &mut connection);
                let result =
                    self.write_statement(id, &mut connection, statement, sql, prepared, autocommit);
                if autocommit {
                    self.leave_transaction(id, &mut connection);
                }
                result
            }
            statement => {
                read_statement(&statement)?;
                let sequence = connection
                    .snapshot
                    .as_ref()
                    .map(|pin| pin.snapshot().sequence());
                let mut view = self.statement_for_at(
                    &connection.session,
                    connection.writes.as_ref(),
                    sequence,
                    &statement,
                )?;
                drop(connection);
                view.execute(sql, &[])
            }
        }
    }
    /// One write statement of an explicit or autocommit transaction.
    fn write_statement(
        &self,
        id: u64,
        connection: &mut Connection,
        statement: Statement,
        sql: &str,
        prepared: Result<(), PhobosError>,
        autocommit: bool,
    ) -> Result<QueryResult, PhobosError> {
        let snapshot_sequence = connection
            .snapshot
            .as_ref()
            .map(|pin| pin.snapshot().sequence());
        let routed = match connection.writes.as_ref() {
            Some(writes) => self.partition_write_statements(writes, statement.clone()),
            None => Ok(vec![statement.clone()]),
        };
        let Connection {
            session, writes, ..
        } = &mut *connection;
        let mut result = prepared
            .and_then(|()| routed.clone().map(|_| ()))
            .and_then(|()| writes.as_ref().expect("active writes").control.check())
            .and_then(|()| {
                if matches!(
                    statement,
                    Statement::RenameTable { .. }
                        | Statement::CreateView { .. }
                        | Statement::DropView { .. }
                        | Statement::CreateDefinedTable { .. }
                        | Statement::AddColumn { .. }
                        | Statement::AlterNullable { .. }
                        | Statement::AlterDefault { .. }
                        | Statement::CreateTable { .. }
                        | Statement::CreatePartitionedTable { .. }
                        | Statement::CreateRangePartition { .. }
                        | Statement::CreateIndex { .. }
                        | Statement::DropIndex { .. }
                        | Statement::Analyze { .. }
                ) {
                    self.stage_schema(session, writes.as_mut().expect("active writes"), statement)
                } else {
                    let statements = routed.as_ref().expect("routing succeeded");
                    if statements.len() == 1 && statements[0] == statement {
                        return self.stage_at(
                            session,
                            writes.as_mut().expect("active writes"),
                            sql,
                            &[],
                            snapshot_sequence,
                        );
                    }
                    let mut affected = 0u64;
                    for routed in statements.iter().cloned() {
                        match self.stage_parsed_at(
                            session,
                            writes.as_mut().expect("active writes"),
                            routed,
                            &[],
                            snapshot_sequence,
                        )? {
                            QueryResult::Command { rows_affected, .. } => {
                                affected = affected.saturating_add(rows_affected)
                            }
                            QueryResult::Rows { .. } => {
                                return Err(write_conflict("partition mutation returned rows"));
                            }
                        }
                    }
                    Ok(QueryResult::Command {
                        tag: match statement {
                            Statement::InsertColumns { .. } | Statement::Insert { .. } => "INSERT",
                            Statement::Update { .. } => "UPDATE",
                            _ => "DELETE",
                        }
                        .into(),
                        rows_affected: affected,
                    })
                }
            })
            .and_then(|result| phobos_error::cancellation::check_now().map(|()| result));
        if result.as_ref().is_err_and(|error| {
            matches!(
                error.code,
                ErrorCode::TransactionState | ErrorCode::LockTimeout
            )
        }) && writes.is_some()
        {
            writes.as_mut().expect("active writes").discard();
            session.abort_failed()?;
        }
        if autocommit {
            if result.is_ok() {
                result = self.submit_connection(id, session, writes).and(result);
            }
            if result.is_err() && session.in_transaction()? {
                drop(writes.take());
                session.rollback()?;
            }
        }
        result
    }
    pub fn execute_stream(
        &self,
        id: u64,
        sql: &str,
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        let _admitted = self.admit_statement(sql)?;
        let result = self.stream_inner(id, sql, sink);
        if let Err(error) = &result {
            self.statement_error(id, sql, error)?;
        }
        result
    }
    fn stream_inner(
        &self,
        id: u64,
        sql: &str,
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        let parsed = parse(sql)?;
        if read_statement(&parsed).is_ok() {
            let connection = self.connection(id)?;
            let connection = connection
                .lock()
                .map_err(|_| write_conflict("SQL session poisoned"))?;
            if connection
                .writes
                .as_ref()
                .is_some_and(|writes| writes.bulk.is_some())
            {
                return Err(write_conflict(
                    "SQL streams are unavailable inside a bulk import",
                ));
            }
            let sequence = connection
                .snapshot
                .as_ref()
                .map(|pin| pin.snapshot().sequence());
            let mut view = self.statement_for_at(
                &connection.session,
                connection.writes.as_ref(),
                sequence,
                &parsed,
            )?;
            drop(connection);
            view.stream_parsed(parsed, sql, &[], sink)
        } else {
            match self.execute(id, sql)? {
                QueryResult::Command { tag, rows_affected } => sink.command(tag, rows_affected),
                QueryResult::Rows { columns, rows } => {
                    // INSERT RETURNING is already admitted (and committed in autocommit).
                    // A delivery failure cannot undo a durable commit or justify replay.
                    sink.start(columns)?;
                    for row in rows {
                        sink.row(row)?;
                    }
                    sink.finish()
                }
            }
        }
    }
    pub fn flush_stats(&self) -> Result<FlushStats, PhobosError> {
        self.lock_database()?.flush_stats()
    }
    pub fn checkpoint(&self) -> Result<(), PhobosError> {
        let _order = self.lock_commits_quiescent()?;
        let mut database = self.lock_database()?;
        database
            .committed_store
            .as_ref()
            .expect("MVCC store")
            .cancel_checkpoint()?;
        for heap in database.heaps.values_mut() {
            heap.force_committed()?;
        }
        for tree in database.indexes.values_mut() {
            tree.force_committed()?;
        }
        let mut wal = self
            .wal
            .lock()
            .map_err(|_| write_conflict("WAL poisoned"))?;
        self.sessions.checkpoint(&mut wal)
    }
    pub(super) fn advance_checkpoint(&self) -> Result<(), PhobosError> {
        let store = self
            .lock_database()?
            .committed_store
            .as_ref()
            .expect("MVCC store")
            .clone();
        let mut wal = self
            .wal
            .lock()
            .map_err(|_| write_conflict("WAL poisoned"))?;
        wal.poll_checkpoint()?;
        if !wal.checkpoint_pending() {
            if let Some((_target, safe)) = store.take_checkpoint()? {
                self.sessions.request_checkpoint(&mut wal, safe)?;
            } else if wal.checkpoint_due() {
                store.request_checkpoint(wal.last_commit_lsn())?;
            }
        }
        Ok(())
    }
    /// Safe reclamation foundation only: no physical tuple/index reclamation is
    /// attempted. Retained/leaked statement pins continue to constrain this value.
    pub fn reclamation_horizon(&self) -> Result<u64, PhobosError> {
        self.sessions.reclamation_horizon()
    }
}
fn command(tag: &str) -> QueryResult {
    QueryResult::Command {
        tag: tag.into(),
        rows_affected: 0,
    }
}
