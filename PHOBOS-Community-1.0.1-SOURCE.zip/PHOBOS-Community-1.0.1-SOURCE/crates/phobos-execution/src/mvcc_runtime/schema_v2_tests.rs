use super::*;
fn rows(r: QueryResult) -> Vec<Row> {
    match r {
        QueryResult::Rows { rows, .. } => rows,
        _ => panic!("rows expected"),
    }
}
const CREATE: &str = "CREATE TABLE accounts (id BIGINT PRIMARY KEY, balance BIGINT DEFAULT 10 CHECK (balance >= 0), active BOOLEAN DEFAULT TRUE, label TEXT DEFAULT 'unknown')";
#[test]
fn schema_v2_defaults_checks_pk_restart_atomicity() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, CREATE).unwrap();
    db.execute(1, "INSERT INTO accounts (id) VALUES (1),(2)")
        .unwrap();
    db.execute(
        1,
        "INSERT INTO accounts (id,balance,active,label) VALUES (3,NULL,NULL,NULL)",
    )
    .unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SELECT balance,active,label FROM accounts WHERE id=1")
                .unwrap()
        ),
        vec![Row::new(vec![
            Value::Int64(10),
            Value::Boolean(true),
            Value::Text("unknown".into())
        ])]
    );
    assert_eq!(
        rows(
            db.execute(1, "SELECT balance FROM accounts WHERE id=3")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Null])]
    );
    for sql in [
        "INSERT INTO accounts (id,balance) VALUES (4,5),(5,-1)",
        "UPDATE accounts SET balance=balance-11",
        "INSERT INTO accounts (id) VALUES (1)",
        "INSERT INTO accounts (id) VALUES (NULL)",
        "DROP INDEX phobos_pk_2",
    ] {
        assert!(db.execute(1, sql).is_err(), "{sql}");
    }
    assert_eq!(
        rows(db.execute(1, "SELECT id FROM accounts").unwrap()).len(),
        3
    );
    assert_eq!(
        rows(
            db.execute(1, "SELECT balance FROM accounts WHERE id=1")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(10)])]
    );
    let meta = db
        .execute(1, "SHOW CATALOG CONSTRAINTS FROM accounts")
        .unwrap();
    assert!(meta.to_text().contains("PRIMARY KEY"));
    assert!(meta.to_text().contains("CHECK"));
    if let QueryResult::Rows { columns, rows } = &meta {
        assert!(rows.iter().all(|r| r.values.len() == columns.len()));
    }
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        db.execute(1, "SHOW CATALOG CONSTRAINTS FROM accounts")
            .unwrap(),
        meta
    );
    db.execute(1, "INSERT INTO accounts (id) VALUES (4)")
        .unwrap();
    assert!(
        db.execute(1, "UPDATE accounts SET balance=-1 WHERE id=4")
            .is_err()
    );
    assert!(
        db.execute(1, "INSERT INTO accounts (id) VALUES (4)")
            .is_err()
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn schema_v2_transaction_rename_default_and_old_format() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "CREATE TABLE old_table (id BIGINT, value BIGINT)")
        .unwrap();
    assert_eq!(
        u16::from_le_bytes(
            fs::read(root.join("catalog.phc")).unwrap()[4..6]
                .try_into()
                .unwrap()
        ),
        2
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, CREATE).unwrap();
    db.execute(1, "INSERT INTO accounts (id) VALUES (1)")
        .unwrap();
    assert!(db.execute(2, "SELECT * FROM accounts").is_err());
    db.execute(1, "ROLLBACK").unwrap();
    assert!(db.execute(1, "SELECT * FROM accounts").is_err());
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, CREATE).unwrap();
    db.execute(1, "COMMIT").unwrap();
    assert_eq!(
        u16::from_le_bytes(
            fs::read(root.join("catalog.phc")).unwrap()[4..6]
                .try_into()
                .unwrap()
        ),
        4
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        "ALTER TABLE accounts ALTER COLUMN balance SET DEFAULT 20",
    )
    .unwrap();
    db.execute(1, "INSERT INTO accounts (id) VALUES (1)")
        .unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT balance FROM accounts").unwrap()),
        vec![Row::new(vec![Value::Int64(20)])]
    );
    db.execute(1, "ROLLBACK").unwrap();
    db.execute(1, "ALTER TABLE accounts RENAME COLUMN balance TO amount")
        .unwrap();
    db.execute(1, "ALTER TABLE accounts RENAME TO renamed")
        .unwrap();
    db.execute(1, "INSERT INTO renamed (id) VALUES (1)")
        .unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT amount FROM renamed").unwrap()),
        vec![Row::new(vec![Value::Int64(10)])]
    );
    assert!(db.execute(1, "UPDATE renamed SET amount=-1").is_err());
    db.execute(1, "ALTER TABLE renamed ALTER COLUMN amount DROP DEFAULT")
        .unwrap();
    db.execute(1, "INSERT INTO renamed (id) VALUES (2)")
        .unwrap();
    assert_eq!(
        rows(
            db.execute(1, "SELECT amount FROM renamed WHERE id=2")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Null])]
    );
    db.execute(1, "ALTER TABLE old_table ALTER COLUMN value SET DEFAULT -7")
        .unwrap();
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "INSERT INTO old_table (id) VALUES (1)")
        .unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT value FROM old_table").unwrap()),
        vec![Row::new(vec![Value::Int64(-7)])]
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn schema_v2_rejected_definitions_and_composite_key() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    for sql in [
        "CREATE TABLE bad (id BIGINT DEFAULT 'bad')",
        "CREATE TABLE bad (id BIGINT DEFAULT id)",
        "CREATE TABLE bad (id BIGINT DEFAULT CURRENT_TIMESTAMP)",
        "CREATE TABLE bad (id BIGINT CHECK (missing > 0))",
        "CREATE TABLE bad (id BIGINT CHECK (id > 0 AND id < 5))",
        "CREATE TABLE bad (id BIGINT PRIMARY KEY DEFAULT NULL)",
        "CREATE TABLE bad (id BIGINT, PRIMARY KEY (missing))",
        "CREATE TABLE bad (id BIGINT, PRIMARY KEY (id,id))",
        "CREATE TABLE bad (id BIGINT DEFAULT 1) PARTITION BY RANGE (id)",
        "CREATE TABLE bad (id BIGINT REFERENCES other(id))",
    ] {
        assert!(db.execute(1, sql).is_err(), "{sql}");
        assert!(db.execute(1, "SELECT * FROM bad").is_err());
    }
    db.execute(
        1,
        "CREATE TABLE pairs (a BIGINT, b BIGINT, PRIMARY KEY(a,b), CHECK (a IS NOT NULL))",
    )
    .unwrap();
    db.execute(1, "INSERT INTO pairs VALUES (1,2),(1,3)")
        .unwrap();
    assert!(db.execute(1, "INSERT INTO pairs VALUES (1,2)").is_err());
    assert!(db.execute(1, "INSERT INTO pairs VALUES (NULL,4)").is_err());
    db.execute(1, "CREATE TABLE nullable (x BIGINT CHECK (x IS NULL))")
        .unwrap();
    db.execute(1, "INSERT INTO nullable VALUES (NULL)").unwrap();
    assert!(db.execute(1, "INSERT INTO nullable VALUES (1)").is_err());
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn schema_v2_bulk_cannot_bypass_check() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, CREATE).unwrap();
    db.bulk_begin(2, "accounts").unwrap();
    assert!(
        db.bulk_batch(
            2,
            &[Row::new(vec![
                Value::Int64(1),
                Value::Int64(-1),
                Value::Boolean(true),
                Value::Null
            ])]
        )
        .is_err()
    );
    db.disconnect(2);
    assert!(rows(db.execute(1, "SELECT * FROM accounts").unwrap()).is_empty());
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn schema_v2_concurrent_primary_key_and_schema_isolation() {
    use std::sync::Barrier;
    let root = tests::fixture();
    let db = Arc::new(MvccDatabase::open(&root).unwrap());
    db.execute(1, CREATE).unwrap();
    let gate = Arc::new(Barrier::new(3));
    let mut workers = Vec::new();
    for session in [2, 3] {
        let db = db.clone();
        let gate = gate.clone();
        workers.push(std::thread::spawn(move || {
            gate.wait();
            let result = db.execute(session, "INSERT INTO accounts (id) VALUES (7)");
            db.disconnect(session);
            result.is_ok()
        }));
    }
    gate.wait();
    assert_eq!(
        workers
            .into_iter()
            .map(|w| usize::from(w.join().unwrap()))
            .sum::<usize>(),
        1
    );
    assert_eq!(
        rows(db.execute(1, "SELECT id FROM accounts").unwrap()).len(),
        1
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        "ALTER TABLE accounts ALTER COLUMN balance SET DEFAULT 20",
    )
    .unwrap();
    assert!(
        db.execute(1, "SHOW CATALOG COLUMNS FROM accounts")
            .unwrap()
            .to_text()
            .contains("true\t20")
    );
    assert!(db.execute(4, "SHOW CATALOG COLUMNS FROM accounts").is_err());
    assert!(
        db.execute(
            4,
            "ALTER TABLE accounts ALTER COLUMN balance SET DEFAULT 30"
        )
        .is_err()
    );
    db.execute(1, "COMMIT").unwrap();
    db.execute(4, "INSERT INTO accounts (id) VALUES (8)")
        .unwrap();
    assert_eq!(
        rows(
            db.execute(4, "SELECT balance FROM accounts WHERE id=8")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(20)])]
    );
    db.disconnect(1);
    db.disconnect(4);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn schema_v2_crash_publication_boundaries() {
    const TEST: &str = "mvcc_runtime::schema_v2_tests::schema_v2_crash_publication_boundaries";
    if let Ok(point) = std::env::var("PHOBOS_SCHEMA_V2_POINT") {
        let root = PathBuf::from(std::env::var_os("PHOBOS_SCHEMA_V2_ROOT").unwrap());
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, CREATE).unwrap();
        db.execute(1, "INSERT INTO accounts (id) VALUES (1)")
            .unwrap();
        let _hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |at| {
                if at == point {
                    std::process::exit(86);
                }
            }),
        );
        db.execute(1, "COMMIT").unwrap();
        std::process::exit(87);
    }
    for point in [
        "c6_private_redo_staged",
        "wal.before_force",
        "wal.after_force",
        "mvcc.before_publication",
        "c5_schema_metadata_installed",
        "mvcc.after_publication",
    ] {
        let root = tests::fixture();
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env("PHOBOS_SCHEMA_V2_POINT", point)
            .env("PHOBOS_SCHEMA_V2_ROOT", &root)
            .output()
            .unwrap();
        assert_eq!(
            output.status.code(),
            Some(86),
            "{point}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        for _ in 0..2 {
            let db = MvccDatabase::open(&root).unwrap();
            db.check_online().unwrap();
            if let Ok(result) = db.execute(1, "SELECT * FROM accounts") {
                assert_eq!(rows(result).len(), 1);
                assert!(
                    db.execute(1, "INSERT INTO accounts (id) VALUES (1)")
                        .is_err()
                );
                assert!(db.execute(1, "UPDATE accounts SET balance=-1").is_err());
                assert!(
                    db.execute(1, "SHOW CATALOG COLUMNS FROM accounts")
                        .unwrap()
                        .to_text()
                        .contains("true\t10")
                );
            } else {
                assert!(
                    matches!(point, "c6_private_redo_staged" | "wal.before_force"),
                    "durable schema lost at {point}"
                );
                assert!(
                    !db.execute(1, "SHOW CATALOG TABLES")
                        .unwrap()
                        .to_text()
                        .contains("accounts")
                );
            }
            db.disconnect(1);
            drop(db);
        }
        fs::remove_dir_all(root).unwrap();
    }
}

#[test]
fn schema_v2_typed_defaults_and_null_checks() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1,"CREATE TABLE types (id BIGINT PRIMARY KEY, f DOUBLE DEFAULT 1.25, d DECIMAL(8,2) DEFAULT '12.34' CHECK(d>='0.00'), day DATE DEFAULT '2026-10-26', stamp TIMESTAMP DEFAULT '2026-10-26 12:00:00', b BINARY DEFAULT 'abc', n BIGINT DEFAULT NULL CHECK(n = NULL))").unwrap();
    db.execute(1, "INSERT INTO types (id) VALUES (1)").unwrap();
    let result = rows(db.execute(1, "SELECT * FROM types").unwrap());
    assert_eq!(result[0].values[1], Value::Float64(1.25));
    assert_eq!(
        result[0].values[2],
        Value::Decimal {
            unscaled: 1234,
            scale: 2
        }
    );
    assert!(matches!(result[0].values[3], Value::Date(_)));
    assert!(matches!(result[0].values[4], Value::Timestamp(_)));
    assert_eq!(result[0].values[5], Value::Binary(b"abc".to_vec()));
    assert_eq!(result[0].values[6], Value::Null);
    db.execute(1, "UPDATE types SET n=9").unwrap(); // UNKNOWN passes a CHECK.
    assert!(db.execute(1, "UPDATE types SET d='-0.01'").is_err());
    db.execute(1, "ALTER TABLE types ALTER COLUMN d SET DEFAULT '-1.00'")
        .unwrap();
    assert!(db.execute(1, "INSERT INTO types (id) VALUES (2)").is_err()); // Defaults do not bypass CHECK.
    assert_eq!(
        rows(db.execute(1, "SELECT id FROM types").unwrap()).len(),
        1
    );
    db.execute(1, "ALTER TABLE types ALTER COLUMN id DROP DEFAULT")
        .unwrap();
    assert!(db.execute(1, "INSERT INTO types (n) VALUES (1)").is_err());
    db.check_online().unwrap();
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert!(db.execute(1, "INSERT INTO types (id) VALUES (2)").is_err());
    db.check_online().unwrap();
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn schema_v2_checks_preserve_canonical_numeric_comparisons() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(
        1,
        "CREATE TABLE exact (n DOUBLE CHECK(n<>9007199254740993), i BIGINT CHECK(i<1.5))",
    )
    .unwrap();
    db.execute(1, "INSERT INTO exact VALUES (9007199254740992.0,1)")
        .unwrap();
    assert!(db.execute(1, "INSERT INTO exact VALUES (0.0,2)").is_err());
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "INSERT INTO exact VALUES (9007199254740992.0,1)")
        .unwrap();
    db.check_online().unwrap();
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
