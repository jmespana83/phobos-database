//! Immutable schema generations keep statement construction independent of
//! physical transaction preparation. DDL replaces the generation under its
//! existing exclusive schema lease, before releasing that lease to new readers.
use super::*;

pub(super) struct ReadDirectory {
    pub data_dir: PathBuf,
    pub catalog: Catalog,
    pub heaps: BTreeMap<TableId, phobos_storage::HeapReadHandle>,
    pub indexes: BTreeMap<IndexId, phobos_index::IndexReadHandle>,
    pub committed_store: Option<Arc<phobos_storage::committed_pages::CommittedStore>>,
    pub buffer_pages: usize,
    pub query_memory_bytes: usize,
    pub stats: BTreeMap<TableId, TableStatistics>,
}
impl ReadDirectory {
    pub fn new(database: &Database) -> Result<Self, PhobosError> {
        Ok(Self {
            data_dir: database.data_dir.clone(),
            catalog: database.catalog.clone(),
            heaps: database
                .heaps
                .iter()
                .map(|(id, heap)| Ok((*id, heap.read_handle()?)))
                .collect::<Result<_, PhobosError>>()?,
            indexes: database
                .indexes
                .iter()
                .map(|(id, tree)| Ok((*id, tree.read_handle()?)))
                .collect::<Result<_, PhobosError>>()?,
            committed_store: database.committed_store.clone(),
            buffer_pages: database.buffer_pages,
            query_memory_bytes: database.query_memory_bytes,
            stats: database.stats.clone(),
        })
    }
}
