//! 0.2-K Part N: storage-lifecycle diagnostics. One read-only pass over the
//! committed heap and index images of every table under a statement snapshot
//! (no CHECKPOINT, no flush, nothing written), plus the global status-file,
//! WAL-retention and reclamation state.
use super::*;
use phobos_index::Bound;
use phobos_storage::{HEADER_SIZE, PAGE_SIZE, SLOT_SIZE};
use phobos_txn::mvcc::globally_dead;

/// Session identity reserved for diagnostics.
const DIAGNOSTICS_SESSION: u64 = u64::MAX - 3;

/// Per-table storage-lifecycle state.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct TableLifecycle {
    pub table: String,
    pub table_id: TableId,
    pub heap_pages: u64,
    pub heap_bytes: u64,
    pub overflow_pages: u64,
    /// Slot-directory entries on ordinary pages (the RID high-water marks).
    pub slots_total: u64,
    pub slots_occupied: u64,
    pub slots_retired: u64,
    pub slots_free: u64,
    pub slot_directory_bytes: u64,
    /// Ordinary pages that cannot take a typical row even after compaction
    /// with their current directory, but could if their non-occupied
    /// directory entries were reusable (capacity lost to the slot leak).
    pub pages_slot_starved: u64,
    /// Ordinary pages holding no tuple at all (all entries RETIRED/FREE, or
    /// an empty directory).
    pub pages_all_free: u64,
    /// Ordinary pages that can take a typical row right now.
    pub pages_accepting_rows: u64,
    /// Σ (upper − lower) over ordinary pages.
    pub free_bytes: u64,
    /// Tuples present (all versions on the page).
    pub tuples_present: u64,
    /// Versions with a deleter that are still physically present.
    pub dead_versions: u64,
    /// Of those, versions reclaimable at the current horizon.
    pub reclaimable_versions: u64,
    /// In-memory reclaim candidates recorded for the table.
    pub reclaim_candidate_pages: u64,
    /// Typical row footprint used for the accept/starved classification.
    pub row_need_bytes: u64,
    pub index_pages: u64,
    pub index_bytes: u64,
    pub index_entries: u64,
    pub index_free_pages: u64,
}

/// Database-wide storage-lifecycle state.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct StorageLifecycleReport {
    pub tables: Vec<TableLifecycle>,
    /// `phobos.mvcc-status`: apparent length and allocated bytes (equal
    /// where the platform reports no allocation).
    pub status_file_bytes: u64,
    pub status_file_allocated_bytes: u64,
    /// Exclusive logical freeze boundary (transaction identities below it
    /// have no surviving references).
    pub status_frozen_before: u64,
    pub wal_history_bytes: u64,
    pub wal_retained_bytes: u64,
    /// Oldest replication slot `(name, protected LSN)`, if any.
    pub oldest_replication_slot: Option<(String, u64)>,
    pub published: u64,
    pub horizon: u64,
    pub live_pins: u64,
    pub reclaim: ReclaimMetrics,
    /// 0.2-K.1: storage maintenance fault (reclamation suspended until
    /// restart), if any.
    pub maintenance_fault: Option<String>,
}

/// Allocated bytes of a file (sparse-aware on Unix).
fn allocated_bytes(path: &Path) -> Result<(u64, u64), PhobosError> {
    let metadata = match fs::metadata(path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok((0, 0)),
        Err(error) => return Err(error.into()),
    };
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        Ok((metadata.len(), metadata.blocks() * 512))
    }
    #[cfg(not(unix))]
    {
        Ok((metadata.len(), metadata.len()))
    }
}

impl MvccDatabase {
    /// 0.2-K Part N: storage-lifecycle diagnostics. `row_need` overrides the
    /// "typical row" footprint (bytes, including its slot entry); by default
    /// each table's mean live tuple length + 4 is used.
    pub fn storage_lifecycle_report(
        &self,
        row_need: Option<usize>,
    ) -> Result<StorageLifecycleReport, PhobosError> {
        let _maintenance = phobos_error::cancellation::suspend();
        let (published, horizon, pins) = self.sessions.publication_state()?;
        let mut report = StorageLifecycleReport {
            published,
            horizon,
            live_pins: pins as u64,
            reclaim: self.reclaim_metrics(),
            maintenance_fault: self.maintenance_fault(),
            ..StorageLifecycleReport::default()
        };
        let (apparent, allocated) = allocated_bytes(&self.data_dir.join("phobos.mvcc-status"))?;
        report.status_file_bytes = apparent;
        report.status_file_allocated_bytes = allocated;
        report.status_frozen_before = self.sessions.freeze_metrics()?.0;
        let retention = phobos_wal::v2::retention_report(&self.data_dir)?;
        report.wal_history_bytes = retention.bytes;
        report.wal_retained_bytes = retention.retained_bytes;
        report.oldest_replication_slot =
            retention.slots.iter().min_by_key(|(_, lsn)| *lsn).cloned();
        let candidates = self
            .reclaim_state
            .lock()
            .map(|state| {
                state
                    .candidates_by_table()
                    .into_iter()
                    .collect::<BTreeMap<_, _>>()
            })
            .unwrap_or_default();
        let session = self.connect(DIAGNOSTICS_SESSION)?;
        let mut view = self.statement(&session, None)?;
        let tables = view
            .database
            .catalog
            .tables()
            .map(|table| (table.id, table.name.clone()))
            .collect::<Vec<_>>();
        for (table_id, name) in tables {
            let mut entry = TableLifecycle {
                table: name,
                table_id,
                reclaim_candidate_pages: candidates.get(&table_id).copied().unwrap_or(0) as u64,
                ..TableLifecycle::default()
            };
            // First pass: census and versions; per-page facts kept for the
            // accept/starved classification once the typical row is known.
            let mut pages = Vec::new();
            let mut live_bytes_total = 0u64;
            let mut page = 0;
            while let Some(headers) = view.database.heap_mut(table_id)?.page_headers(page)? {
                entry.heap_pages += 1;
                if headers.overflow {
                    entry.overflow_pages += 1;
                    page += 1;
                    continue;
                }
                let census = headers.census;
                entry.slots_total += u64::from(census.slots);
                entry.slots_occupied += u64::from(census.occupied);
                entry.slots_retired += u64::from(census.retired);
                entry.slots_free += u64::from(census.free);
                entry.free_bytes += headers.free_bytes as u64;
                entry.tuples_present += headers.versions.len() as u64;
                live_bytes_total += headers.live_bytes as u64;
                if census.occupied == 0 {
                    entry.pages_all_free += 1;
                }
                for version in &headers.versions {
                    if version.visibility.deleter.is_some() {
                        entry.dead_versions += 1;
                        if globally_dead(horizon, version.visibility, &mut self.sessions.as_ref())?
                        {
                            entry.reclaimable_versions += 1;
                        }
                    }
                }
                pages.push((census, headers.free_bytes, headers.live_bytes));
                page += 1;
            }
            entry.heap_bytes = entry.heap_pages * PAGE_SIZE as u64;
            entry.slot_directory_bytes = entry.slots_total * SLOT_SIZE as u64;
            let need = row_need.unwrap_or_else(|| {
                live_bytes_total
                    .checked_div(entry.tuples_present)
                    .map_or(64, |mean| mean as usize)
                    + SLOT_SIZE
            });
            entry.row_need_bytes = need as u64;
            for (census, free, live) in pages {
                let has_free_slot = census.free > 0;
                let accepts = free >= need || (has_free_slot && free + SLOT_SIZE >= need);
                if accepts {
                    entry.pages_accepting_rows += 1;
                }
                // After a perfect compaction with the current directory (a
                // FREE entry can serve the new row) vs. with only occupied
                // entries.
                let directory = usize::from(census.slots) - usize::from(has_free_slot);
                let with_directory =
                    PAGE_SIZE.saturating_sub(HEADER_SIZE + directory * SLOT_SIZE + live);
                let occupied_only = PAGE_SIZE
                    .saturating_sub(HEADER_SIZE + usize::from(census.occupied) * SLOT_SIZE + live);
                if with_directory < need && occupied_only >= need {
                    entry.pages_slot_starved += 1;
                }
            }
            let index_ids = view
                .database
                .catalog
                .indexes_for_table(table_id)
                .map(|index| index.id)
                .collect::<Vec<_>>();
            for id in index_ids {
                let Some(tree) = view.database.indexes.get_mut(&id) else {
                    continue;
                };
                let (pages, free) = tree.shape()?;
                entry.index_pages += pages;
                entry.index_bytes += pages * phobos_index::INDEX_PAGE_SIZE as u64;
                entry.index_free_pages += free as u64;
                let mut entries = 0u64;
                tree.range_visit_keyed(Bound::Unbounded, Bound::Unbounded, |_, _| {
                    entries += 1;
                    Ok(true)
                })?;
                entry.index_entries += entries;
            }
            report.tables.push(entry);
        }
        drop(view);
        drop(session);
        Ok(report)
    }
}
