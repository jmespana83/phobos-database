use super::*;
fn rows(result: QueryResult) -> Vec<Row> {
    match result {
        QueryResult::Rows { rows, .. } => rows,
        _ => panic!("rows expected"),
    }
}
#[test]
fn modern_constant_union_insert_select_combination() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT 1, LOWER('A'), NULL, 2+3").unwrap()),
        vec![Row::new(vec![
            Value::Int64(1),
            Value::Text("a".into()),
            Value::Null,
            Value::Int64(5)
        ])]
    );
    let clock = rows(
        db.execute(1, "SELECT CURRENT_TIMESTAMP, CURRENT_TIMESTAMP()")
            .unwrap(),
    );
    assert_eq!(clock[0].values[0], clock[0].values[1]);
    assert!(matches!(clock[0].values[0],Value::Timestamp(n) if n>0));
    assert!(rows(db.execute(1, "SELECT 1 WHERE FALSE").unwrap()).is_empty());
    assert_eq!(
        rows(
            db.execute(
                1,
                "SELECT 2 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 ORDER BY n LIMIT 2 OFFSET 1"
            )
            .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(2)]); 2]
    );
    assert_eq!(
        rows(db.execute(1, "SELECT NULL UNION SELECT NULL").unwrap()),
        vec![Row::new(vec![Value::Null])]
    );
    assert_eq!(
        rows(db.execute(1, "SELECT 1 UNION SELECT 1.0").unwrap()),
        vec![Row::new(vec![Value::Float64(1.0)])]
    );
    assert_eq!(
        rows(
            db.execute(
                1,
                "WITH u AS (SELECT 1 AS n UNION ALL SELECT 2) SELECT n FROM u ORDER BY n"
            )
            .unwrap()
        )
        .len(),
        2
    );
    db.execute(1,"CREATE TABLE destination (id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, n BIGINT CHECK(n>0), label TEXT DEFAULT 'auto')").unwrap();
    assert_eq!(
        rows(
            db.execute(
                1,
                "INSERT INTO destination(n) SELECT 2 UNION ALL SELECT 3 RETURNING id,n,label"
            )
            .unwrap()
        ),
        vec![
            Row::new(vec![
                Value::Int64(1),
                Value::Int64(2),
                Value::Text("auto".into())
            ]),
            Row::new(vec![
                Value::Int64(2),
                Value::Int64(3),
                Value::Text("auto".into())
            ])
        ]
    );
    db.execute(1, "BEGIN").unwrap();
    db.execute(1, "INSERT INTO destination(n) SELECT n FROM destination")
        .unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT * FROM destination").unwrap()).len(),
        4
    );
    db.execute(1, "ROLLBACK").unwrap();
    assert!(
        db.execute(1, "INSERT INTO destination(n) SELECT 1 UNION ALL SELECT -1")
            .is_err()
    );
    assert_eq!(
        rows(
            db.execute(1, "INSERT INTO destination(n) SELECT 5 RETURNING id")
                .unwrap()
        )[0]
        .values[0],
        Value::Int64(3)
    );
    assert_eq!(
        rows(db.execute(1, "SELECT * FROM destination").unwrap()).len(),
        3
    );
    db.check_online().unwrap();
    db.disconnect(1);
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(
        rows(db.execute(1, "SELECT * FROM destination").unwrap()).len(),
        3
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn modern_union_binding_and_atomic_errors() {
    let root = tests::fixture();
    let db = MvccDatabase::open(&root).unwrap();
    db.execute(1, "CREATE TABLE empty (i BIGINT, t TEXT)")
        .unwrap();
    for sql in [
        "SELECT *",
        "SELECT missing",
        "SELECT 1 UNION SELECT 1,2",
        "SELECT i FROM empty UNION SELECT t FROM empty",
        "SELECT 1 UNION SELECT 'a'",
        "SELECT 1 ORDER BY 1 UNION SELECT 2",
        "INSERT INTO empty SELECT 1",
        "INSERT INTO empty SELECT 'a',1",
    ] {
        assert!(db.execute(1, sql).is_err(), "{sql}");
    }
    assert!(rows(db.execute(1, "SELECT * FROM empty").unwrap()).is_empty());
    assert_eq!(
        rows(
            db.execute(1, "SELECT i FROM empty UNION SELECT NULL")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Null])]
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn modern_alter_nullable_empty_add_and_correlated_exists() {
    let root = tests::fixture();
    {
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(
            1,
            "CREATE TABLE customers (id BIGINT PRIMARY KEY, label TEXT)",
        )
        .unwrap();
        db.execute(
            1,
            "ALTER TABLE customers ADD COLUMN enabled BOOLEAN DEFAULT TRUE NOT NULL",
        )
        .unwrap();
        db.execute(
            1,
            "INSERT INTO customers(id,label) VALUES(1,'one'),(2,NULL),(3,'three')",
        )
        .unwrap();
        assert!(
            db.execute(1, "ALTER TABLE customers ALTER COLUMN label SET NOT NULL")
                .is_err()
        );
        db.execute(1, "UPDATE customers SET label='two' WHERE id=2")
            .unwrap();
        db.execute(1, "ALTER TABLE customers ALTER COLUMN label SET NOT NULL")
            .unwrap();
        assert!(
            db.execute(1, "INSERT INTO customers(id) VALUES(4)")
                .is_err()
        );
        assert!(
            db.execute(1, "ALTER TABLE customers ALTER COLUMN id DROP NOT NULL")
                .is_err()
        );
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "ALTER TABLE customers ALTER COLUMN label DROP NOT NULL")
            .unwrap();
        db.execute(1, "ROLLBACK").unwrap();
        assert!(db.execute(1, "UPDATE customers SET label=NULL").is_err());
        assert!(
            db.execute(1, "ALTER TABLE customers ADD COLUMN extra TEXT")
                .is_err()
        );
        db.execute(
            1,
            "CREATE TABLE orders (id BIGINT PRIMARY KEY, customer_id BIGINT)",
        )
        .unwrap();
        db.execute(1, "INSERT INTO orders VALUES(1,1),(2,1),(3,3),(4,NULL)")
            .unwrap();
        assert_eq!(rows(db.execute(1,"SELECT c.id FROM customers c WHERE EXISTS (SELECT 1 FROM orders o WHERE o.customer_id=c.id) ORDER BY c.id").unwrap()),vec![Row::new(vec![Value::Int64(1)]),Row::new(vec![Value::Int64(3)])]);
        assert_eq!(rows(db.execute(1,"SELECT c.id FROM customers c WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id=c.id)").unwrap()),vec![Row::new(vec![Value::Int64(2)])]);
        assert_eq!(rows(db.execute(1,"SELECT c.id FROM customers c WHERE EXISTS (SELECT 1 FROM orders c WHERE c.customer_id=1)").unwrap()).len(),3);
        db.execute(1, "BEGIN ISOLATION LEVEL SNAPSHOT").unwrap();
        db.execute(2, "INSERT INTO orders VALUES(5,2)").unwrap();
        assert_eq!(rows(db.execute(1,"SELECT c.id FROM customers c WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id=c.id)").unwrap()).len(),1);
        db.execute(1, "COMMIT").unwrap();
        assert!(rows(db.execute(1,"SELECT c.id FROM customers c WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id=c.id)").unwrap()).is_empty());
        db.execute(1, "CREATE TABLE fresh (id BIGINT)").unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "ALTER TABLE fresh ADD COLUMN text TEXT DEFAULT 'added'")
            .unwrap();
        db.execute(1, "INSERT INTO fresh(id) VALUES(1)").unwrap();
        db.execute(1, "COMMIT").unwrap();
        assert_eq!(
            rows(db.execute(1, "SELECT text FROM fresh").unwrap())[0].values[0],
            Value::Text("added".into())
        );
        db.check_online().unwrap();
        db.disconnect(1);
        db.disconnect(2);
    }
    let db = MvccDatabase::open(&root).unwrap();
    assert!(db.execute(1, "UPDATE customers SET label=NULL").is_err());
    db.check_online().unwrap();
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn modern_views_persist_metadata_dependencies_and_rollback() {
    let root = tests::fixture();
    {
        let db = MvccDatabase::open(&root).unwrap();
        db.execute(1, "CREATE TABLE base (id BIGINT PRIMARY KEY, name TEXT)")
            .unwrap();
        db.execute(1, "INSERT INTO base VALUES(1,'O''Brien'),(2,'two')")
            .unwrap();
        db.execute(1, "BEGIN").unwrap();
        db.execute(
            1,
            "CREATE VIEW names AS SELECT b.id,b.name FROM base b WHERE b.id>0",
        )
        .unwrap();
        assert_eq!(
            rows(
                db.execute(1, "SELECT id,name FROM names ORDER BY id")
                    .unwrap()
            )
            .len(),
            2
        );
        db.execute(1, "COMMIT").unwrap();
        db.execute(1,"CREATE VIEW nested AS WITH x AS (SELECT id,name FROM names) SELECT id,name FROM x WHERE id=1").unwrap();
        assert_eq!(
            rows(db.execute(1, "SELECT name FROM nested").unwrap())[0].values[0],
            Value::Text("O'Brien".into())
        );
        db.execute(1, "CREATE VIEW quoted AS SELECT 'O''Brien' AS label")
            .unwrap();
        assert_eq!(
            rows(db.execute(1, "SELECT label FROM quoted").unwrap())[0].values[0],
            Value::Text("O'Brien".into())
        );
        for sql in [
            "INSERT INTO names VALUES(3,'x')",
            "UPDATE names SET name='x'",
            "DELETE FROM names",
            "DROP VIEW names",
            "ALTER TABLE base RENAME TO other",
            "ALTER TABLE base RENAME COLUMN name TO other",
            "CREATE VIEW bad AS SELECT $1",
            "CREATE VIEW bad AS SELECT id,id FROM base",
            "CREATE VIEW bad AS INSERT INTO base VALUES(3,'x')",
        ] {
            assert!(db.execute(1, sql).is_err(), "{sql}");
        }
        assert!(
            db.execute(1, "SHOW CATALOG TABLES")
                .unwrap()
                .to_text()
                .contains("VIEW")
        );
        assert!(
            db.execute(1, "SHOW CATALOG COLUMNS FROM names")
                .unwrap()
                .to_text()
                .contains("BIGINT")
        );
        assert_eq!(rows(db.execute(1, "SHOW CATALOG VIEWS").unwrap()).len(), 3);
        db.execute(1, "BEGIN").unwrap();
        db.execute(1, "DROP VIEW nested").unwrap();
        db.execute(1, "ROLLBACK").unwrap();
        assert_eq!(
            rows(db.execute(1, "SELECT * FROM nested").unwrap()).len(),
            1
        );
        db.check_online().unwrap();
        db.disconnect(1);
    }
    {
        let db = MvccDatabase::open(&root).unwrap();
        assert_eq!(
            rows(db.execute(1, "SELECT * FROM nested").unwrap()).len(),
            1
        );
        assert_eq!(
            rows(db.execute(1, "SELECT * FROM quoted").unwrap())[0].values[0],
            Value::Text("O'Brien".into())
        );
        db.execute(1, "DROP VIEW nested").unwrap();
        db.execute(1, "DROP VIEW names").unwrap();
        db.execute(1, "ALTER TABLE base RENAME TO renamed").unwrap();
        db.disconnect(1);
    }
    fs::remove_dir_all(root).unwrap();
}
#[test]
fn current_timestamp_is_shared_with_parallel_partition_workers() {
    let root = tests::fixture();
    let config = phobos_config::RuntimeConfig {
        parallel_scan_workers: 2,
        parallel_scan_min_pages: 1,
        ..Default::default()
    };
    let db = MvccDatabase::open_with_config(&root, &config).unwrap();
    for sql in [
        "CREATE TABLE clock_parts (id BIGINT NOT NULL) PARTITION BY RANGE (id)",
        "CREATE TABLE clock_low PARTITION OF clock_parts FOR VALUES FROM (0) TO (10)",
        "CREATE TABLE clock_high PARTITION OF clock_parts FOR VALUES FROM (10) TO (20)",
        "INSERT INTO clock_parts VALUES (1),(11)",
    ] {
        db.execute(1, sql).unwrap();
    }
    db.execute(1, "CHECKPOINT").unwrap();
    let _clock = sql_surface::StatementClock::enter();
    let expected = sql_surface::eval_builtin("CURRENT_TIMESTAMP", vec![]).unwrap();
    let session = db.connect(91).unwrap();
    let mut statement = db.statement(&session, None).unwrap();
    assert_eq!(
        rows(
            statement
                .execute(
                    "SELECT id FROM clock_parts WHERE CURRENT_TIMESTAMP = $1 ORDER BY id",
                    &[expected]
                )
                .unwrap()
        ),
        vec![
            Row::new(vec![Value::Int64(1)]),
            Row::new(vec![Value::Int64(11)])
        ]
    );
    drop(statement);
    drop(session);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
