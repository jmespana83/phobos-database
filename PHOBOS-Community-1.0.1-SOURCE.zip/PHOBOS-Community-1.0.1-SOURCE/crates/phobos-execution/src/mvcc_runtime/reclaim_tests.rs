//! 0.1.9-C1/C2/C3: dead-version bookkeeping, horizon-safe page reclamation
//! and index pruning with free-page reuse, through the SQL runtime.
//! Fixture: `t(id,v,g)` with 1000 committed rows, unique `u(id)`,
//! non-unique `d(g)`, unique composite `c(v,g)`.
use super::*;
use phobos_storage::PAGE_FLAG_RECLAIM_CANDIDATE;
use std::{collections::BTreeSet, time::Duration};
use tests::fixture;

fn scalar(db: &MvccDatabase, session: u64, sql: &str) -> i64 {
    match db.execute(session, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows[0].values[0] {
            Value::Int64(n) => n,
            Value::Null => 0,
            ref other => panic!("scalar {other:?}"),
        },
        other => panic!("scalar result {other:?}"),
    }
}
fn table_id(db: &MvccDatabase, name: &str) -> TableId {
    db.lock_database()
        .unwrap()
        .catalog
        .tables()
        .find(|table| table.name == name)
        .expect("table")
        .id
}
fn index_id(db: &MvccDatabase, name: &str) -> IndexId {
    db.lock_database()
        .unwrap()
        .catalog
        .indexes()
        .find(|index| index.name == name)
        .expect("index")
        .id
}
/// `(rid, id, deleter?)` of every physical version, plus per-page flags.
type Versions = (Vec<(RecordId, i64, bool)>, BTreeMap<u64, u8>);
fn versions(db: &MvccDatabase, table: TableId) -> Versions {
    let session = db.connect(900).unwrap();
    let mut view = db.statement(&session, None).unwrap();
    let mut out = Vec::new();
    let mut flags = BTreeMap::new();
    let heap = view.database.heap_mut(table).unwrap();
    let mut page = 0;
    while let Some((page_flags, list)) = heap.page_versions(page).unwrap() {
        flags.insert(page, page_flags);
        for (slot, tuple, row) in list {
            let Value::Int64(id) = row.values[0] else {
                panic!("id")
            };
            out.push((
                RecordId {
                    page_id: page,
                    slot_id: slot,
                },
                id,
                tuple.visibility.deleter.is_some(),
            ));
        }
        page += 1;
    }
    drop(view);
    drop(session);
    db.disconnect(900);
    (out, flags)
}
fn index_entries(db: &MvccDatabase, index: IndexId) -> usize {
    let mut database = db.lock_database().unwrap();
    database
        .indexes
        .get_mut(&index)
        .unwrap()
        .validate()
        .unwrap()
        .entries
}
fn index_validation(db: &MvccDatabase, index: IndexId) -> phobos_index::IndexValidation {
    let mut database = db.lock_database().unwrap();
    database
        .indexes
        .get_mut(&index)
        .unwrap()
        .validate()
        .unwrap()
}

/// 0.2-K: one unrelated publication (advances the published frontier, and
/// with no pins the reclamation horizon, past earlier publications).
pub(super) fn publish_marker(db: &MvccDatabase) {
    if db
        .lock_database()
        .unwrap()
        .catalog
        .tables()
        .all(|table| table.name != "k_marker")
    {
        db.execute(899, "CREATE TABLE k_marker (x BIGINT)").unwrap();
    }
    db.execute(899, "INSERT INTO k_marker VALUES (1)").unwrap();
    db.disconnect(899);
}

/// Test 1: committed UPDATE/DELETE flag their pages and register candidates.
#[test]
fn c1_update_and_delete_mark_candidate_pages() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let t = table_id(&db, "t");
    let (_, flags) = versions(&db, t);
    assert!(flags.values().all(|f| f & PAGE_FLAG_RECLAIM_CANDIDATE == 0));
    assert_eq!(db.reclaim_candidates(t), 0);
    db.execute(1, "UPDATE t SET v=v+1 WHERE id<20").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=990").unwrap();
    let (list, flags) = versions(&db, t);
    // Superseded and deleted versions carry a deleter; their pages are flagged.
    let dead_pages = list
        .iter()
        .filter(|(_, _, deleted)| *deleted)
        .map(|(rid, _, _)| rid.page_id)
        .collect::<BTreeSet<_>>();
    assert!(!dead_pages.is_empty());
    for page in &dead_pages {
        assert_ne!(flags[page] & PAGE_FLAG_RECLAIM_CANDIDATE, 0, "page {page}");
    }
    assert_eq!(db.reclaim_candidates(t), dead_pages.len());
    // Pages without dead versions stay unflagged (a new successor page).
    assert!(
        flags
            .iter()
            .any(|(page, f)| !dead_pages.contains(page) && f & PAGE_FLAG_RECLAIM_CANDIDATE == 0)
    );
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Tests 2–3: a pinned old snapshot defers reclamation and still sees its
/// rows; once released, the same versions are reclaimed.
#[test]
fn c2_pinned_snapshot_defers_reclamation_until_released() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let t = table_id(&db, "t");
    let old_session = db.connect(50).unwrap();
    let mut old_view = db.statement(&old_session, None).unwrap();
    db.execute(1, "UPDATE t SET v=v+100 WHERE id<50").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=900").unwrap();
    let first = db.reclaim_once(64).unwrap();
    assert_eq!(first.table, Some(t));
    assert_eq!(first.versions_reclaimed, 0, "{first:?}");
    assert!(first.versions_deferred >= 150, "{first:?}");
    assert!(first.candidates_remaining > 0);
    // The old reader still sees exactly its snapshot.
    let count = old_view
        .execute("SELECT COUNT(*) AS n FROM t", &[])
        .unwrap();
    assert_eq!(
        count,
        QueryResult::Rows {
            columns: vec!["n".into()],
            rows: vec![Row::new(vec![Value::Int64(1000)])]
        }
    );
    assert_eq!(
        old_view.execute("SELECT v FROM t WHERE id=5", &[]).unwrap(),
        QueryResult::Rows {
            columns: vec!["v".into()],
            rows: vec![Row::new(vec![Value::Int64(5)])]
        }
    );
    let (list, _) = versions(&db, t);
    assert_eq!(list.len(), 1050, "nothing removed while the pin is live");
    drop(old_view);
    drop(old_session);
    db.disconnect(50);
    let second = db.reclaim_once(64).unwrap();
    assert_eq!(second.versions_reclaimed, 150, "{second:?}");
    assert_eq!(second.versions_deferred, 0);
    // 0.2-K: the retired slots stay recorded until phase 2 (RETIRED -> FREE)
    // once the horizon has passed the retire publication.
    assert!(second.candidates_remaining > 0, "{second:?}");
    publish_marker(&db);
    let freeing = db.reclaim_once(64).unwrap();
    assert_eq!(freeing.slots_freed, 150, "{freeing:?}");
    assert_eq!(freeing.candidates_remaining, 0, "{freeing:?}");
    let (list, flags) = versions(&db, t);
    assert_eq!(list.len(), 900);
    assert!(list.iter().all(|(_, _, deleted)| !deleted));
    assert!(flags.values().all(|f| f & PAGE_FLAG_RECLAIM_CANDIDATE == 0));
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t"), 900);
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5"), 105);
    assert_eq!(
        scalar(&db, 2, "SELECT SUM(v) AS s FROM t"),
        (0..900).sum::<i64>() + 50 * 100
    );
    let third = db.reclaim_once(64).unwrap();
    assert_eq!(third.versions_reclaimed, 0);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Test 4: compaction keeps every surviving RecordId and returns page space
/// that later inserts reuse.
#[test]
fn c2_compaction_preserves_live_rids_and_reuses_space() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let t = table_id(&db, "t");
    let (before, _) = versions(&db, t);
    let page0 = before.iter().filter(|(rid, _, _)| rid.page_id == 0).count();
    let last_page = before.iter().map(|(rid, _, _)| rid.page_id).max().unwrap();
    // Delete every other row of page 0 and update a few: page 0 gets holes.
    let ids_on_page0 = before
        .iter()
        .filter(|(rid, _, _)| rid.page_id == 0)
        .map(|(_, id, _)| *id)
        .collect::<Vec<_>>();
    for id in ids_on_page0.iter().step_by(2) {
        db.execute(1, &format!("DELETE FROM t WHERE id={id}"))
            .unwrap();
    }
    db.execute(1, "UPDATE t SET v=v+1 WHERE id=1 OR id=3")
        .unwrap();
    let survivors = before
        .iter()
        .filter(|(rid, id, _)| {
            rid.page_id == 0
                && ids_on_page0.iter().position(|x| x == id).unwrap() % 2 == 1
                && *id != 1
                && *id != 3
        })
        .cloned()
        .collect::<Vec<_>>();
    let report = db.reclaim_once(64).unwrap();
    assert!(report.versions_reclaimed >= page0 / 2, "{report:?}");
    assert!(report.pages_compacted >= 1);
    let (after, _) = versions(&db, t);
    for (rid, id, _) in &survivors {
        assert!(
            after.iter().any(|(r, i, _)| r == rid && i == id),
            "survivor {id} lost its rid {rid:?}"
        );
    }
    assert!(after.iter().all(|(_, _, deleted)| !deleted));
    // Point lookups through the unique index still resolve every survivor.
    for (_, id, _) in survivors.iter().take(5) {
        assert_eq!(
            scalar(&db, 2, &format!("SELECT id FROM t WHERE id={id}")),
            *id
        );
    }
    // K.5 may finish the current write page first. Exhaust that frontier
    // before requiring page-zero reuse; no allocation is allowed meanwhile.
    db.execute(
        2,
        "INSERT INTO t VALUES (5000,1,NULL),(5001,1,NULL),(5002,1,NULL)",
    )
    .unwrap();
    let (after_insert, _) = versions(&db, t);
    let new_pages = after_insert
        .iter()
        .filter(|(_, id, _)| *id >= 5000)
        .map(|(rid, _, _)| rid.page_id)
        .collect::<BTreeSet<_>>();
    assert!(
        new_pages.iter().all(|page| *page <= last_page),
        "{new_pages:?}"
    );
    let mut reused = new_pages.contains(&0);
    for id in 5003..5200 {
        if reused {
            break;
        }
        db.execute(2, &format!("INSERT INTO t VALUES ({id},1,NULL)"))
            .unwrap();
        let (current, _) = versions(&db, t);
        assert!(current.iter().all(|(rid, _, _)| rid.page_id <= last_page));
        reused = current
            .iter()
            .any(|(rid, row, _)| *row == id && rid.page_id == 0);
    }
    assert!(
        reused,
        "dense reclaimed page must be reused before heap growth"
    );
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=5000"), 1);
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Tests 5, 6, 8: dead index entries disappear with their versions, lookups
/// return the current rows, and UNIQUE keeps rejecting duplicates while a
/// reclaimed key can be reused.
#[test]
fn c3_dead_index_entries_pruned_lookups_and_unique_stay_correct() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    // 0.2-K.4: this test pins the eager exact-pruning path (still used for
    // UNIQUE indexes and whenever lazy pruning is off).
    db.set_lazy_index_pruning(false);
    let u = index_id(&db, "u");
    let c = index_id(&db, "c");
    assert_eq!(index_entries(&db, u), 1000);
    db.execute(1, "UPDATE t SET v=v+1 WHERE id<100").unwrap();
    db.execute(1, "DELETE FROM t WHERE id>=900").unwrap();
    assert_eq!(
        index_entries(&db, u),
        1100,
        "old and new versions both indexed"
    );
    let report = db.reclaim_once(64).unwrap();
    assert_eq!(report.versions_reclaimed, 200);
    assert_eq!(report.index_entries_pruned, 600, "three indexes");
    assert_eq!(index_entries(&db, u), 900);
    assert_eq!(index_entries(&db, c), 900);
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=7"), 8);
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE id=950"),
        0
    );
    assert_eq!(scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE v=8"), 1);
    // Duplicate of a live key is still rejected; a reclaimed key is free.
    assert_eq!(
        db.execute(2, "INSERT INTO t VALUES (7,1,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    db.execute(2, "INSERT INTO t VALUES (950,950,NULL)")
        .unwrap();
    assert_eq!(scalar(&db, 2, "SELECT v FROM t WHERE id=950"), 950);
    assert_eq!(
        db.execute(2, "INSERT INTO t VALUES (950,1,NULL)")
            .unwrap_err()
            .code,
        ErrorCode::ConstraintViolation
    );
    for index in [u, c, index_id(&db, "d")] {
        index_validation(&db, index);
    }
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Test 7: leaves emptied by pruning are detached onto the free list and a
/// later split reuses them instead of growing the file.
#[test]
fn c3_emptied_index_pages_join_free_list_and_are_reused() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let t = table_id(&db, "t");
    let d = index_id(&db, "d");
    // 3000 rows with distinct, high g values: several leaves of d(g).
    for batch in 0..30i64 {
        let values = (0..100)
            .map(|k| {
                let n = batch * 100 + k;
                format!("({},{},{})", 10_000 + n, n, 1_000_000 + n)
            })
            .collect::<Vec<_>>()
            .join(",");
        db.execute(1, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
    }
    let grown = index_validation(&db, d);
    assert!(grown.leaves >= 4, "{grown:?}");
    assert_eq!(db.free_index_pages(t), Ok(0));
    db.execute(1, "DELETE FROM t WHERE g>=1000000").unwrap();
    let mut freed = 0;
    for _ in 0..8 {
        let report = db.reclaim_once(64).unwrap();
        freed += report.index_pages_freed;
        if report.versions_reclaimed == 0 && report.candidates_remaining == 0 {
            break;
        }
    }
    assert!(freed >= 1, "at least one emptied leaf was detached");
    let after = index_validation(&db, d);
    let d_free_list = {
        let mut database = db.lock_database().unwrap();
        database
            .indexes
            .get_mut(&d)
            .unwrap()
            .free_list_len()
            .unwrap()
    };
    assert_eq!(after.entries, 1000);
    assert!(
        d_free_list >= 1 && after.free_pages == d_free_list,
        "{after:?} list {d_free_list}"
    );
    assert_eq!(after.pages, grown.pages, "the file did not shrink or grow");
    assert_eq!(
        db.free_index_pages(t).unwrap(),
        freed,
        "all three indexes freed pages"
    );
    eprintln!(
        "C3 free list: d(g) {} of {} pages freed, all indexes {freed} pages freed",
        d_free_list, after.pages
    );
    // Refill: splits reuse freed pages before allocating new ones.
    for batch in 0..30i64 {
        let values = (0..100)
            .map(|k| {
                let n = batch * 100 + k;
                format!("({},{},{})", 20_000 + n, n, 2_000_000 + n)
            })
            .collect::<Vec<_>>()
            .join(",");
        db.execute(1, &format!("INSERT INTO t VALUES {values}"))
            .unwrap();
    }
    let refilled = index_validation(&db, d);
    assert!(
        db.free_index_pages(t).unwrap() < freed,
        "a freed page was reused"
    );
    assert!(
        refilled.pages <= grown.pages + 1,
        "{grown:?} -> {refilled:?}"
    );
    assert_eq!(
        scalar(&db, 2, "SELECT COUNT(*) AS n FROM t WHERE g>=2000000"),
        3000
    );
    assert_eq!(scalar(&db, 2, "SELECT id FROM t WHERE g=2001234"), 21_234);
    assert_eq!(
        scalar(
            &db,
            2,
            "SELECT COUNT(*) AS n FROM t WHERE g>=1000000 AND g<2000000"
        ),
        0
    );
    db.disconnect(1);
    db.disconnect(2);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}

/// Test 9: a crash during a reclaim publication leaves either the old state
/// or the fully reclaimed state, never a heap/index mismatch. The child
/// exits at a publication boundary: before any WAL record (old state) and
/// after the WAL force but before installation (recovery completes it).
#[test]
fn c2_crash_around_reclaim_publication_leaves_old_or_reclaimed_state() {
    if let Ok(root) = std::env::var("PHOBOS_C2_CRASH_CHILD") {
        let point = std::env::var("PHOBOS_C2_CRASH_POINT").unwrap();
        let db = MvccDatabase::open(Path::new(&root)).unwrap();
        // 0.2-K.4: enable the lazy-index capability first (its own schema
        // publication) so the armed crash point hits the reclaim publication.
        assert!(db.try_enable_lazy_index_pruning().unwrap());
        db.execute(1, "UPDATE t SET v=v+1 WHERE id<100").unwrap();
        db.execute(1, "DELETE FROM t WHERE id>=900").unwrap();
        if std::env::var("PHOBOS_K5_FREE_PHASE").is_ok() {
            db.reclaim_once(64).unwrap();
            publish_marker(&db);
        }
        let _hook = phobos_observability::test_hooks::register(
            Path::new(&root),
            Arc::new(move |name| {
                if name == point {
                    std::process::exit(0);
                }
            }),
        );
        let _ = db.reclaim_once(64);
        panic!("crash point not reached");
    }
    for free_phase in [false, true] {
        for point in [
            "c6_private_preparation_begin",
            "k5_lifecycle_wal_append",
            "wal.before_force",
            "wal.after_force",
            "c5_before_visibility_publication",
            "k5_heap_installed",
        ] {
            let root = fixture();
            let mut command = std::process::Command::new(std::env::current_exe().unwrap());
            if free_phase {
                command.env("PHOBOS_K5_FREE_PHASE", "1");
            }
            let status = command
            .arg("--exact")
            .arg("mvcc_runtime::reclaim_tests::c2_crash_around_reclaim_publication_leaves_old_or_reclaimed_state")
            .arg("--nocapture")
            .env("PHOBOS_C2_CRASH_CHILD", &root)
            .env("PHOBOS_C2_CRASH_POINT", point)
            .status()
            .unwrap();
            assert!(status.success(), "{point}");
            let db = MvccDatabase::open(&root).unwrap();
            let t = table_id(&db, "t");
            let (list, _) = versions(&db, t);
            let dead = list.iter().filter(|(_, _, deleted)| *deleted).count();
            let u = index_id(&db, "u");
            let entries = index_entries(&db, u);
            match point {
                "c6_private_preparation_begin" if !free_phase => {
                    assert_eq!((list.len(), dead, entries), (1100, 200, 1100), "old state");
                }
                "k5_lifecycle_wal_append" | "wal.before_force" if !free_phase => {
                    assert!(
                        [(1100, 200, 1100), (900, 0, 900)].contains(&(list.len(), dead, entries)),
                        "atomic unforced outcome"
                    );
                }
                _ => {
                    assert_eq!(
                        (list.len(), dead, entries),
                        (900, 0, 900),
                        "reclaimed state"
                    );
                }
            }
            // Heap and index agree either way: every live row probes correctly.
            assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 900);
            assert_eq!(scalar(&db, 1, "SELECT v FROM t WHERE id=7"), 8);
            assert_eq!(
                scalar(&db, 1, "SELECT COUNT(*) AS n FROM t WHERE id>=900"),
                0
            );
            for index in [u, index_id(&db, "c"), index_id(&db, "d")] {
                index_validation(&db, index);
            }
            let report = db.reclaim_once(64).unwrap();
            assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 900);
            let (list, _) = versions(&db, t);
            assert_eq!(list.len(), 900, "{report:?}");
            db.disconnect(1);
            db.shutdown(Duration::from_secs(10)).unwrap();
            drop(db);
            fs::remove_dir_all(root).unwrap();
        }
    }
}

/// Bookkeeping survives loss: after a reopen the in-memory candidate set is
/// empty, the header scan rebuilds it, and CHECKPOINT runs a bounded pass.
#[test]
fn c1_bookkeeping_rebuilds_after_reopen_and_checkpoint_reclaims() {
    let root = fixture();
    let db = MvccDatabase::open(&root).unwrap();
    let t = table_id(&db, "t");
    db.execute(1, "DELETE FROM t WHERE id<300").unwrap();
    let flagged = db.reclaim_candidates(t);
    assert!(flagged > 0);
    db.disconnect(1);
    db.shutdown(Duration::from_secs(10)).unwrap();
    drop(db);
    let db = MvccDatabase::open(&root).unwrap();
    assert_eq!(db.reclaim_candidates(t), 0, "in-memory bookkeeping is gone");
    // A bounded scan with a small limit finds the flagged pages in steps.
    let mut reclaimed = 0;
    let mut passes = 0;
    loop {
        let report = db.reclaim_once(2).unwrap();
        passes += 1;
        reclaimed += report.versions_reclaimed;
        if report.bookkeeping_complete
            && report.candidates_remaining == 0
            && report.versions_reclaimed == 0
        {
            break;
        }
        assert!(passes < 200);
    }
    assert_eq!(reclaimed, 300);
    assert!(passes > 1);
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 700);
    // CHECKPOINT reclaims what a new delete leaves behind.
    db.execute(1, "DELETE FROM t WHERE id<400").unwrap();
    assert!(db.reclaim_candidates(t) > 0);
    db.execute(1, "CHECKPOINT").unwrap();
    let (list, _) = versions(&db, t);
    assert_eq!(list.len(), 600);
    assert!(list.iter().all(|(_, _, deleted)| !deleted));
    assert_eq!(scalar(&db, 1, "SELECT COUNT(*) AS n FROM t"), 600);
    db.disconnect(1);
    drop(db);
    fs::remove_dir_all(root).unwrap();
}
