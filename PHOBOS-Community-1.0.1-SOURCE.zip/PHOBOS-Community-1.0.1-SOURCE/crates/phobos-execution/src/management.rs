//! Versioned management interface over the transaction's catalog generation.
//! No filesystem paths, credentials, or physical encodings cross this interface.
use super::*;
use phobos_sql::CatalogKind;

impl Database {
    pub(super) fn management_catalog(
        &self,
        kind: CatalogKind,
        table: Option<&str>,
    ) -> Result<QueryResult, PhobosError> {
        let selected = table
            .map(|name| self.query_relation_schema(name))
            .transpose()?;
        let tables: Vec<_> = self
            .catalog
            .tables()
            .cloned()
            .chain(self.catalog.views().map(|v| TableSchema {
                id: v.id,
                name: v.name.clone(),
                columns: v.columns.clone(),
            }))
            .filter(|t| !t.name.starts_with("__phobos_"))
            .filter(|t| selected.as_ref().is_none_or(|s| s.id == t.id))
            .collect();
        let text = |s: &str| Value::Text(s.to_owned());
        let id = |n: u64| Value::Text(n.to_string()); // IDs are opaque, lossless strings.
        let mut rows = Vec::new();
        let columns: &[&str] = match kind {
            CatalogKind::Views => {
                for v in self
                    .catalog
                    .views()
                    .filter(|v| selected.as_ref().is_none_or(|s| s.id == v.id))
                {
                    rows.push(Row::new(vec![
                        id(v.id),
                        text(&v.name),
                        text(&v.sql),
                        Value::Boolean(false),
                        Value::Int64(v.dependencies.len() as i64),
                    ]));
                }
                &[
                    "view_id",
                    "view_name",
                    "definition",
                    "is_updatable",
                    "dependency_count",
                ]
            }

            CatalogKind::Tables => {
                for t in tables {
                    rows.push(Row::new(vec![
                        id(t.id),
                        text(&t.name),
                        text(if self.catalog.view(&t.name).is_some() {
                            "VIEW"
                        } else if self.catalog.partition_key(&t.name).is_some() {
                            "PARTITIONED TABLE"
                        } else {
                            "TABLE"
                        }),
                        Value::Int64(t.columns.len() as i64),
                    ]));
                }
                &["table_id", "table_name", "table_type", "column_count"]
            }
            CatalogKind::Columns => {
                for t in tables {
                    for (ordinal, c) in t.columns.iter().enumerate() {
                        rows.push(Row::new(vec![
                            id(t.id),
                            text(&t.name),
                            Value::Int64(ordinal as i64 + 1),
                            text(&c.name),
                            text(&sql_type(&c.data_type)),
                            Value::Boolean(c.nullable),
                            Value::Boolean(
                                self.catalog
                                    .definitions(t.id)
                                    .is_some_and(|d| d.defaults.contains_key(&ordinal)),
                            ),
                            self.catalog
                                .definitions(t.id)
                                .and_then(|d| d.defaults.get(&ordinal))
                                .map(|v| text(&schema_value_sql(v)))
                                .unwrap_or(Value::Null),
                            Value::Boolean(
                                self.catalog
                                    .definitions(t.id)
                                    .and_then(|d| d.identity.as_ref())
                                    .is_some_and(|i| i.column == ordinal),
                            ),
                            self.catalog
                                .definitions(t.id)
                                .and_then(|d| d.identity.as_ref())
                                .filter(|i| i.column == ordinal)
                                .map(|i| text(if i.always { "ALWAYS" } else { "BY DEFAULT" }))
                                .unwrap_or(Value::Null),
                        ]));
                    }
                }
                &[
                    "table_id",
                    "table_name",
                    "ordinal_position",
                    "column_name",
                    "data_type",
                    "is_nullable",
                    "has_default",
                    "default_expression",
                    "is_identity",
                    "identity_generation",
                ]
            }
            CatalogKind::Indexes => {
                for t in tables {
                    for i in self.catalog.indexes().filter(|i| i.table_id == t.id) {
                        for (ordinal, column) in i.columns.iter().enumerate() {
                            rows.push(Row::new(vec![
                                id(t.id),
                                text(&t.name),
                                id(i.id),
                                text(&i.name),
                                Value::Boolean(i.unique),
                                Value::Int64(ordinal as i64 + 1),
                                text(column),
                            ]));
                        }
                    }
                }
                &[
                    "table_id",
                    "table_name",
                    "index_id",
                    "index_name",
                    "is_unique",
                    "ordinal_position",
                    "column_name",
                ]
            }
            CatalogKind::Constraints => {
                for t in &tables {
                    for c in t.columns.iter().filter(|c| !c.nullable) {
                        rows.push(Row::new(vec![
                            id(t.id),
                            text(&t.name),
                            Value::Null,
                            text("NOT NULL"),
                            Value::Int64(1),
                            text(&c.name),
                            Value::Null,
                        ]));
                    }
                    for i in self
                        .catalog
                        .indexes()
                        .filter(|i| i.table_id == t.id && i.unique)
                    {
                        for (ordinal, column) in i.columns.iter().enumerate() {
                            rows.push(Row::new(vec![
                                id(t.id),
                                text(&t.name),
                                text(&i.name),
                                text(
                                    if self
                                        .catalog
                                        .definitions(t.id)
                                        .is_some_and(|d| d.primary_index == Some(i.id))
                                    {
                                        "PRIMARY KEY"
                                    } else {
                                        "UNIQUE INDEX"
                                    },
                                ),
                                Value::Int64(ordinal as i64 + 1),
                                text(column),
                                Value::Null,
                            ]));
                        }
                    }
                    if let Some(definition) = self.catalog.definitions(t.id) {
                        for (ordinal, check) in definition.checks.iter().enumerate() {
                            let column = &t.columns[check.column].name;
                            let operator =
                                ["=", "<>", "<", "<=", ">", ">=", "IS NULL", "IS NOT NULL"]
                                    [check.operator as usize];
                            let expression = if check.operator >= 6 {
                                format!("\"{column}\" {operator}")
                            } else {
                                format!(
                                    "\"{column}\" {operator} {}",
                                    schema_value_sql(&check.value)
                                )
                            };
                            rows.push(Row::new(vec![
                                id(t.id),
                                text(&t.name),
                                text(&format!("phobos_check_{}_{}", t.id, ordinal + 1)),
                                text("CHECK"),
                                Value::Int64(1),
                                text(column),
                                text(&expression),
                            ]));
                        }
                    }
                }
                for row in &mut rows {
                    row.values.extend([
                        Value::Null,
                        Value::Null,
                        Value::Null,
                        Value::Null,
                        Value::Null,
                    ]);
                }
                for t in tables {
                    if let Some(d) = self.catalog.definitions(t.id) {
                        for (number, fk) in d.foreign_keys.iter().enumerate() {
                            let parent = self
                                .catalog
                                .tables()
                                .find(|p| p.id == fk.parent_table)
                                .expect("validated FK");
                            for (ordinal, (&child, &reference)) in
                                fk.columns.iter().zip(&fk.parent_columns).enumerate()
                            {
                                rows.push(Row::new(vec![
                                    id(t.id),
                                    text(&t.name),
                                    text(&format!("phobos_fk_{}_{}", t.id, number + 1)),
                                    text("FOREIGN KEY"),
                                    Value::Int64(ordinal as i64 + 1),
                                    text(&t.columns[child].name),
                                    text("MATCH SIMPLE; immediate RESTRICT"),
                                    id(parent.id),
                                    text(&parent.name),
                                    text(&parent.columns[reference].name),
                                    text("RESTRICT"),
                                    text("RESTRICT"),
                                ]));
                            }
                        }
                    }
                }
                &[
                    "table_id",
                    "table_name",
                    "constraint_name",
                    "constraint_type",
                    "ordinal_position",
                    "column_name",
                    "definition",
                    "referenced_table_id",
                    "referenced_table_name",
                    "referenced_column_name",
                    "delete_rule",
                    "update_rule",
                ]
            }
            CatalogKind::Capabilities => {
                for (name, value) in [
                    ("management_api_version", "1"),
                    ("server_version", env!("CARGO_PKG_VERSION")),
                    ("edition", "Community"),
                    ("ddl_core", "true"),
                    (
                        "identity",
                        "BIGINT BY DEFAULT / ALWAYS; transactional allocator",
                    ),
                    ("insert_returning", "columns / star; multi-row"),
                    (
                        "foreign_keys",
                        "RESTRICT / NO ACTION; serialized writer transactions",
                    ),
                    ("views", "persistent read-only; dependency protection"),
                    ("union", "UNION / UNION ALL"),
                    ("insert_select", "true"),
                    ("correlated_exists", "qualified outer references in WHERE"),
                    (
                        "authorization",
                        "admin / writer / reader; external auth file",
                    ),
                    ("licensing_resource_limits", "none"),
                    ("database_scope", "one database per server instance"),
                    (
                        "catalog_visibility",
                        "statement catalog generation plus own transactional DDL",
                    ),
                    ("table_aliases", "true"),
                    ("cancel", "existing protocol cancellation"),
                    ("multiple_databases", "false"),
                    (
                        "schema_definitions",
                        "literal defaults; column-literal CHECK; primary key; ALTER DEFAULT",
                    ),
                    ("catalog_format_max", "5"),
                ] {
                    rows.push(Row::new(vec![text(name), text(value)]));
                }
                &["capability_name", "capability_value"]
            }
        };
        Ok(QueryResult::Rows {
            columns: columns.iter().map(|s| (*s).to_owned()).collect(),
            rows,
        })
    }
}

fn sql_type(t: &DataType) -> String {
    match t {
        DataType::Int64 => "BIGINT".into(),
        DataType::Boolean => "BOOLEAN".into(),
        DataType::Float64 => "DOUBLE".into(),
        DataType::Text => "TEXT".into(),
        DataType::Binary => "BINARY".into(),
        DataType::Date => "DATE".into(),
        DataType::Timestamp => "TIMESTAMP".into(),
        DataType::Decimal { precision, scale } => format!("DECIMAL({precision},{scale})"),
    }
}

fn schema_value_sql(value: &Value) -> String {
    match value {
        Value::Text(s) => format!("'{}'", s.replace('\'', "''")),
        _ => value.to_string(),
    }
}
