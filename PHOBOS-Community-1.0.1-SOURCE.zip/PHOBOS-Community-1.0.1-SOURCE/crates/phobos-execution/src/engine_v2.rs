//! 0.2-B Execution Engine v2: bound predicates and required-column analysis
//! for operators that consume borrowed tuple views (`ValueRef`) produced by the
//! storage scan kernel instead of owned `Row`s.
//!
//! The contract is strict equivalence with the collecting evaluator:
//! - a predicate is bound only when every node is a column/literal/parameter
//!   comparison, `IS [NOT] NULL`, `NOT`, `AND` or `OR`, and every column
//!   resolves exactly as the owned evaluator would resolve it;
//! - `AND`/`OR` evaluate both operands (the owned evaluator does not
//!   short-circuit, so errors surface identically);
//! - anything else is left unbound and the caller keeps the owned-row path.
use super::*;

/// Column resolution used by the owned evaluator for this scope.
pub(super) enum Scope<'a> {
    /// Single-table `SELECT` (`eval_expr`): `TableSchema::column_index`.
    Table(&'a TableSchema),
    /// Relational operators (`eval_expr_relation`).
    Relation {
        names: &'a [String],
        qualified_names: &'a [String],
    },
}

impl Scope<'_> {
    fn resolve(&self, expr: &Expr) -> Option<usize> {
        match (self, expr) {
            (Self::Table(schema), Expr::Column(name)) => schema.column_index(name),
            (Self::Table(schema), Expr::QuotedColumn(name)) => schema
                .columns
                .iter()
                .position(|column| column.name == *name),
            (
                Self::Relation {
                    names,
                    qualified_names,
                },
                Expr::Column(name),
            ) => relation_column_index(names, qualified_names, name).ok(),
            // Quoted relational names have their own ambiguity rules; keep them
            // on the owned evaluator.
            _ => None,
        }
    }
}

pub(super) enum BoundPredicate {
    Compare {
        column: usize,
        op: BinaryOp,
        literal: Value,
        /// `literal op column` rather than `column op literal`.
        literal_left: bool,
    },
    IsNull {
        column: usize,
        negated: bool,
    },
    Not(Box<BoundPredicate>),
    And(Box<BoundPredicate>, Box<BoundPredicate>),
    Or(Box<BoundPredicate>, Box<BoundPredicate>),
}

fn is_comparison(op: BinaryOp) -> bool {
    matches!(
        op,
        BinaryOp::Eq
            | BinaryOp::NotEq
            | BinaryOp::Lt
            | BinaryOp::LtEq
            | BinaryOp::Gt
            | BinaryOp::GtEq
    )
}

/// Byte equality for same-type Text/Binary operands (`None` otherwise).
fn bytes_equal(value: ValueRef<'_>, literal: &Value) -> Option<bool> {
    match (value, literal) {
        (ValueRef::Text(a), Value::Text(b)) => Some(a.as_bytes() == b.as_bytes()),
        (ValueRef::Binary(a), Value::Binary(b)) => Some(a == b.as_slice()),
        _ => None,
    }
}

fn constant(expr: &Expr, params: &[Value]) -> Option<Value> {
    match expr {
        Expr::Literal(value) => Some(value.clone()),
        // A missing parameter is an evaluation error; leave it unbound.
        Expr::Parameter(index) => params.get(*index).cloned(),
        _ => None,
    }
}

impl BoundPredicate {
    pub(super) fn bind(expr: &Expr, scope: &Scope<'_>, params: &[Value]) -> Option<Self> {
        match expr {
            Expr::Binary { left, op, right } if matches!(op, BinaryOp::And | BinaryOp::Or) => {
                let left = Box::new(Self::bind(left, scope, params)?);
                let right = Box::new(Self::bind(right, scope, params)?);
                Some(if *op == BinaryOp::And {
                    Self::And(left, right)
                } else {
                    Self::Or(left, right)
                })
            }
            Expr::Binary { left, op, right } if is_comparison(*op) => {
                if let (Some(column), Some(literal)) =
                    (scope.resolve(left), constant(right, params))
                {
                    return Some(Self::Compare {
                        column,
                        op: *op,
                        literal,
                        literal_left: false,
                    });
                }
                let (Some(literal), Some(column)) = (constant(left, params), scope.resolve(right))
                else {
                    return None;
                };
                Some(Self::Compare {
                    column,
                    op: *op,
                    literal,
                    literal_left: true,
                })
            }
            Expr::IsNull { expr, negated } => Some(Self::IsNull {
                column: scope.resolve(expr)?,
                negated: *negated,
            }),
            Expr::Unary {
                op: UnaryOp::Not,
                expr,
            } => Some(Self::Not(Box::new(Self::bind(expr, scope, params)?))),
            _ => None,
        }
    }

    pub(super) fn require(&self, required: &mut [bool]) {
        match self {
            Self::Compare { column, .. } | Self::IsNull { column, .. } => required[*column] = true,
            Self::Not(inner) => inner.require(required),
            Self::And(left, right) | Self::Or(left, right) => {
                left.require(required);
                right.require(required);
            }
        }
    }

    fn truth(&self, values: &[ValueRef<'_>]) -> Result<Truth, PhobosError> {
        Ok(match self {
            Self::Compare {
                column,
                op,
                literal,
                literal_left,
            } => {
                let value = values[*column];
                if value.is_absent() {
                    return Err(unprojected());
                }
                if value.is_null() || literal.is_null() {
                    Truth::Unknown
                } else if let (Some(equal), BinaryOp::Eq | BinaryOp::NotEq) =
                    (bytes_equal(value, literal), op)
                {
                    // Text/Binary order is bytewise, so equality is byte
                    // equality (length first) without a full ordering.
                    if equal == (*op == BinaryOp::Eq) {
                        Truth::True
                    } else {
                        Truth::False
                    }
                } else {
                    let ordering = if *literal_left {
                        compare_non_null_ref(literal.as_value_ref(), value)?
                    } else {
                        compare_non_null_ref(value, literal.as_value_ref())?
                    };
                    let holds = match op {
                        BinaryOp::Eq => ordering == Ordering::Equal,
                        BinaryOp::NotEq => ordering != Ordering::Equal,
                        BinaryOp::Lt => ordering == Ordering::Less,
                        BinaryOp::LtEq => ordering != Ordering::Greater,
                        BinaryOp::Gt => ordering == Ordering::Greater,
                        BinaryOp::GtEq => ordering != Ordering::Less,
                        _ => unreachable!("bound comparison"),
                    };
                    if holds { Truth::True } else { Truth::False }
                }
            }
            Self::IsNull { column, negated } => {
                let value = values[*column];
                if value.is_absent() {
                    return Err(unprojected());
                }
                if value.is_null() != *negated {
                    Truth::True
                } else {
                    Truth::False
                }
            }
            Self::Not(inner) => match inner.truth(values)? {
                Truth::True => Truth::False,
                Truth::False => Truth::True,
                Truth::Unknown => Truth::Unknown,
            },
            Self::And(left, right) => {
                let (left, right) = (left.truth(values)?, right.truth(values)?);
                truth_and(left, right)
            }
            Self::Or(left, right) => {
                let (left, right) = (left.truth(values)?, right.truth(values)?);
                truth_or(left, right)
            }
        })
    }

    /// Same structure with the same resolved columns: two scopes interpret
    /// this predicate identically.
    pub(super) fn same_columns(&self, other: &Self) -> bool {
        match (self, other) {
            (
                Self::Compare {
                    column: a,
                    op: op_a,
                    literal_left: left_a,
                    ..
                },
                Self::Compare {
                    column: b,
                    op: op_b,
                    literal_left: left_b,
                    ..
                },
            ) => a == b && op_a == op_b && left_a == left_b,
            (
                Self::IsNull {
                    column: a,
                    negated: na,
                },
                Self::IsNull {
                    column: b,
                    negated: nb,
                },
            ) => a == b && na == nb,
            (Self::Not(a), Self::Not(b)) => a.same_columns(b),
            (Self::And(al, ar), Self::And(bl, br)) | (Self::Or(al, ar), Self::Or(bl, br)) => {
                al.same_columns(bl) && ar.same_columns(br)
            }
            _ => false,
        }
    }

    /// `WHERE` semantics: only TRUE passes.
    pub(super) fn passes(&self, values: &[ValueRef<'_>]) -> Result<bool, PhobosError> {
        Ok(self.truth(values)? == Truth::True)
    }
}

/// A filter usable on borrowed tuples: bound, absent, or requiring owned rows.
pub(super) enum RowFilter {
    All,
    Bound(BoundPredicate),
}

impl RowFilter {
    /// `None`: the filter cannot be evaluated on borrowed values; use the
    /// owned-row operator.
    pub(super) fn bind(filter: Option<&Expr>, scope: &Scope<'_>, params: &[Value]) -> Option<Self> {
        match filter {
            None => Some(Self::All),
            Some(expr) => BoundPredicate::bind(expr, scope, params).map(Self::Bound),
        }
    }
    /// True when `filter` resolves to the same columns in single-table scope,
    /// so a table-scope index plan prunes exactly the rows this filter rejects.
    pub(super) fn table_scope_equivalent(
        &self,
        filter: Option<&Expr>,
        schema: &TableSchema,
        params: &[Value],
    ) -> bool {
        match (self, filter) {
            (Self::Bound(bound), Some(expr)) => {
                BoundPredicate::bind(expr, &Scope::Table(schema), params)
                    .is_some_and(|table| bound.same_columns(&table))
            }
            _ => false,
        }
    }
    pub(super) fn require(&self, required: &mut [bool]) {
        if let Self::Bound(predicate) = self {
            predicate.require(required);
        }
    }
    pub(super) fn passes(&self, values: &[ValueRef<'_>]) -> Result<bool, PhobosError> {
        phobos_error::cancellation::checkpoint_at("engine_v2.filter")?;
        match self {
            Self::All => Ok(true),
            Self::Bound(predicate) => predicate.passes(values),
        }
    }
}

/// Owned row with every required column materialized and every other column
/// NULL. Only for consumers whose column accesses are all in `required`.
pub(super) fn materialize(values: &[ValueRef<'_>], required: &[bool]) -> Result<Row, PhobosError> {
    let mut out = Vec::with_capacity(values.len());
    for (value, wanted) in values.iter().zip(required) {
        out.push(if *wanted {
            value.to_value().ok_or_else(unprojected)?
        } else {
            Value::Null
        });
    }
    Ok(Row::new(out))
}

/// Canonical GROUP BY key (see `group_key`) from borrowed values into reusable
/// storage; byte-identical to the owned form.
pub(super) fn group_key_into(
    values: &[ValueRef<'_>],
    indexes: &[usize],
    key: &mut Vec<u8>,
) -> Result<(), PhobosError> {
    key.clear();
    for index in indexes {
        let start = key.len();
        key.extend_from_slice(&[0; 8]);
        if !values[*index].write_canonical_key(key) {
            return Err(unprojected());
        }
        let length = (key.len() - start - 8) as u64;
        key[start..start + 8].copy_from_slice(&length.to_le_bytes());
    }
    Ok(())
}

/// Join probe key from a borrowed value; same bytes as `join_probe_key`.
pub(super) fn join_probe_key_ref<'k>(
    value: ValueRef<'_>,
    key: &'k mut Vec<u8>,
) -> Result<Option<&'k [u8]>, PhobosError> {
    key.clear();
    if value.is_null() {
        return Ok(None);
    }
    if !value.write_canonical_key(key) {
        return Err(unprojected());
    }
    Ok(Some(key))
}
