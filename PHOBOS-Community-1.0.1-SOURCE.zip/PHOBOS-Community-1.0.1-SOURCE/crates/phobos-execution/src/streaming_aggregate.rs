//! Per-group aggregate state; input and output sorts spill through the bounded sorter.
use super::*;

pub(super) enum Item {
    Column(usize, String),
    Aggregate(AggregateFunction, Option<usize>),
}
#[derive(Default)]
struct Cell {
    value: Option<Value>,
    sum: Option<Sum>,
    count: u64,
}
enum Sum {
    Integer(i128),
    Float(f64),
    Decimal(i128, u8),
}
pub(super) struct Group<'a> {
    items: &'a [Item],
    cells: Vec<Cell>,
}

fn overflow() -> PhobosError {
    PhobosError::new(ErrorCode::TypeMismatch, "SUM/COUNT overflow")
}
fn inconsistent() -> PhobosError {
    PhobosError::new(
        ErrorCode::TypeMismatch,
        "aggregate input types or DECIMAL scales are inconsistent",
    )
}

impl<'a> Group<'a> {
    pub(super) fn new(items: &'a [Item]) -> Self {
        Self {
            items,
            cells: items.iter().map(|_| Cell::default()).collect(),
        }
    }
    pub(super) fn push(&mut self, row: &Row) -> Result<(), PhobosError> {
        self.push_refs(|index| row.values[index].as_value_ref())
    }

    /// 0.2-B: the one implementation of aggregate-state update, over borrowed
    /// values. `value(i)` returns column `i` of the current input row; owned
    /// rows and page-resident tuples therefore share identical semantics, and
    /// TEXT/BINARY are copied only when they become a group's retained value.
    pub(super) fn push_refs<'v>(
        &mut self,
        value: impl Fn(usize) -> ValueRef<'v>,
    ) -> Result<(), PhobosError> {
        for (item, cell) in self.items.iter().zip(&mut self.cells) {
            phobos_error::cancellation::checkpoint_at("streaming_aggregate.push")?;
            match item {
                Item::Column(index, name) => {
                    let value = value(*index);
                    if value.is_absent() {
                        return Err(unprojected());
                    }
                    if let Some(first) = &cell.value {
                        if !grouping_equal_ref(first.as_value_ref(), value) {
                            return Err(PhobosError::new(
                                ErrorCode::Semantic,
                                format!("column {name} must appear in GROUP BY or be aggregated"),
                            ));
                        }
                    } else {
                        cell.value = Some(value.to_value().ok_or_else(unprojected)?);
                    }
                }
                Item::Aggregate(function, index) => {
                    let value = index.map(&value);
                    if value.is_some_and(|value| value.is_absent()) {
                        return Err(unprojected());
                    }
                    if *function == AggregateFunction::Count {
                        if value.is_none_or(|v| !v.is_null()) {
                            cell.count = cell.count.checked_add(1).ok_or_else(overflow)?;
                        }
                        continue;
                    }
                    let value = value.ok_or_else(|| {
                        PhobosError::new(ErrorCode::Semantic, "aggregate requires a column")
                    })?;
                    if value.is_null() {
                        continue;
                    }
                    match function {
                        AggregateFunction::Sum | AggregateFunction::Avg => {
                            let sum = cell.sum.get_or_insert(match value {
                                ValueRef::Int64(_) => Sum::Integer(0),
                                ValueRef::Float64(_) => Sum::Float(0.0),
                                ValueRef::Decimal { scale, .. } => Sum::Decimal(0, scale),
                                _ => Sum::Integer(0),
                            });
                            match (sum, value) {
                                (Sum::Integer(sum), ValueRef::Int64(v)) => {
                                    *sum = sum.checked_add(i128::from(v)).ok_or_else(overflow)?
                                }
                                (Sum::Float(sum), ValueRef::Float64(v)) => *sum += v,
                                (
                                    Sum::Decimal(sum, scale),
                                    ValueRef::Decimal {
                                        unscaled,
                                        scale: other,
                                    },
                                ) if *scale == other => {
                                    *sum = sum.checked_add(unscaled).ok_or_else(overflow)?
                                }
                                _ => return Err(inconsistent()),
                            }
                            cell.count = cell.count.checked_add(1).ok_or_else(overflow)?;
                        }
                        AggregateFunction::Min | AggregateFunction::Max => {
                            let replace = match &cell.value {
                                None => true,
                                Some(current) => {
                                    let order =
                                        compare_for_sort_ref(value, current.as_value_ref())?;
                                    if *function == AggregateFunction::Min {
                                        order == Ordering::Less
                                    } else {
                                        order == Ordering::Greater
                                    }
                                }
                            };
                            if replace {
                                cell.value = Some(value.to_value().ok_or_else(unprojected)?);
                            }
                        }
                        AggregateFunction::Count => unreachable!(),
                    }
                }
            }
        }
        Ok(())
    }
    pub(super) fn finish(&self) -> Result<Row, PhobosError> {
        let mut values = Vec::with_capacity(self.items.len());
        for (item, cell) in self.items.iter().zip(&self.cells) {
            values.push(match item {
                Item::Column(..)
                | Item::Aggregate(AggregateFunction::Min | AggregateFunction::Max, _) => {
                    cell.value.clone().unwrap_or(Value::Null)
                }
                Item::Aggregate(AggregateFunction::Count, _) => {
                    Value::Int64(i64::try_from(cell.count).map_err(|_| overflow())?)
                }
                Item::Aggregate(function, _) => match &cell.sum {
                    None => Value::Null,
                    Some(Sum::Integer(sum)) if *function == AggregateFunction::Avg => {
                        Value::Float64(*sum as f64 / cell.count as f64)
                    }
                    Some(Sum::Integer(sum)) => {
                        Value::Int64(i64::try_from(*sum).map_err(|_| overflow())?)
                    }
                    Some(Sum::Float(sum)) => {
                        Value::Float64(if *function == AggregateFunction::Avg {
                            *sum / cell.count as f64
                        } else {
                            *sum
                        })
                    }
                    Some(Sum::Decimal(sum, scale)) => Value::Decimal {
                        unscaled: if *function == AggregateFunction::Avg {
                            *sum / i128::from(cell.count)
                        } else {
                            *sum
                        },
                        scale: *scale,
                    },
                },
            });
        }
        Ok(Row::new(values))
    }

    pub(super) fn memory_bytes(&self) -> usize {
        std::mem::size_of::<Self>()
            + self.cells.capacity() * std::mem::size_of::<Cell>()
            + self
                .cells
                .iter()
                .filter_map(|cell| cell.value.as_ref())
                .map(|value| match value {
                    Value::Text(text) => text.capacity(),
                    Value::Binary(bytes) => bytes.capacity(),
                    _ => 0,
                })
                .sum::<usize>()
    }
}

struct GroupInput {
    directory: PathBuf,
    writer: Option<BufWriter<File>>,
    count: usize,
    bytes: usize,
}
impl Drop for GroupInput {
    fn drop(&mut self) {
        drop(self.writer.take());
        let _ = fs::remove_dir_all(&self.directory);
    }
}
impl GroupInput {
    fn new(data_dir: &Path) -> Result<Self, PhobosError> {
        let directory = data_dir.join(format!(
            ".phobos-spill-group-{}-{}",
            std::process::id(),
            unique_spill_suffix()
        ));
        fs::create_dir(&directory)?;
        let mut input = Self {
            directory,
            writer: None,
            count: 0,
            bytes: 0,
        };
        input.writer = Some(BufWriter::new(File::create(
            input.directory.join("input.bin"),
        )?));
        Ok(input)
    }
    pub(super) fn push(&mut self, row: &Row) -> Result<(), PhobosError> {
        write_spill_row(self.writer.as_mut().expect("input writer open"), row)?;
        self.count = self.count.checked_add(1).ok_or_else(overflow)?;
        let bytes = row_bytes(row);
        self.bytes = self.bytes.saturating_add(bytes);
        phobos_observability::event("aggregate.input_spool_rows", 1);
        phobos_observability::event("aggregate.input_spool_bytes", bytes as u64);
        Ok(())
    }
    fn finish_writing(&mut self) -> Result<(), PhobosError> {
        if let Some(mut writer) = self.writer.take() {
            writer.flush()?;
        }
        Ok(())
    }
    fn visit(
        &self,
        mut visitor: impl FnMut(Row) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let mut reader = BufReader::new(File::open(self.directory.join("input.bin"))?);
        while let Some(row) = bounded_sort::read_row(&mut reader)? {
            cancellation_poll.checkpoint_at("streaming_aggregate.visit")?;
            visitor(row)?;
        }
        Ok(())
    }
}

impl Database {
    pub(super) fn aggregate_into_sink(
        &mut self,
        query: RelationalSelect,
        params: &[Value],
        sink: &mut dyn ResultSink,
        metadata: Relation,
        left: TableSchema,
    ) -> Result<(), PhobosError> {
        let has_aggregate = query
            .items
            .iter()
            .any(|item| matches!(item, SelectItem::Aggregate { .. }));
        validate_grouping(&query.items, &query.group_by, has_aggregate, &metadata)?;
        if query.filter.is_none()
            && query.group_by.is_empty()
            && query.having.is_none()
            && query.order_by.is_empty()
            && query.limit.is_none()
            && query.offset.is_none()
            && matches!(
                query.items.as_slice(),
                [SelectItem::Aggregate {
                    function: AggregateFunction::Count,
                    column: None,
                    ..
                }]
            )
        {
            let count = if let Some(join) = query.joins.first() {
                let Some(count) = self.count_joined_rows(&left, join)? else {
                    return self.aggregate_into_sink_rows(query, params, sink, metadata, left);
                };
                count
            } else {
                self.heap_mut(left.id)?.count_visible()?
            };
            let count = i64::try_from(count).map_err(|_| {
                PhobosError::new(ErrorCode::ResourceLimit, "COUNT(*) exceeds BIGINT")
            })?;
            sink.start(vec![select_item_name(&query.items[0])])?;
            sink.row(Row {
                values: vec![Value::Int64(count)],
            })?;
            return sink.finish();
        }
        self.aggregate_into_sink_rows(query, params, sink, metadata, left)
    }

    /// Rows passing `bound` for a single-table aggregate, as borrowed values.
    /// The index planner is consulted only when the relational filter resolves
    /// to the same columns in table scope; every candidate is still re-checked
    /// against `bound`.
    fn visit_aggregate_input(
        &mut self,
        table: &TableSchema,
        filter: Option<&Expr>,
        bound: &engine_v2::RowFilter,
        required: &[bool],
        params: &[Value],
        visitor: &mut dyn FnMut(&[ValueRef<'_>]) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        if bound.table_scope_equivalent(filter, table, params) {
            phobos_observability::event("engine_v2.aggregate_access_planned", 1);
            return self.visit_selected_values(table, filter, bound, required, params, visitor);
        }
        self.heap_mut(table.id)?
            .scan_visit_projected(required, |_, values| {
                if bound.passes(values)? {
                    visitor(values)
                } else {
                    Ok(true)
                }
            })
    }

    fn aggregate_into_sink_rows(
        &mut self,
        query: RelationalSelect,
        params: &[Value],
        sink: &mut dyn ResultSink,
        metadata: Relation,
        left: TableSchema,
    ) -> Result<(), PhobosError> {
        let items = query
            .items
            .iter()
            .map(|item| match item {
                SelectItem::Column { name, .. } => {
                    Ok(Item::Column(metadata.column_index(name)?, name.clone()))
                }
                SelectItem::Aggregate {
                    function, column, ..
                } => {
                    let index = column
                        .as_ref()
                        .map(|name| metadata.column_index(name))
                        .transpose()?;
                    if index.is_none() && *function != AggregateFunction::Count {
                        return Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "aggregate requires a column",
                        ));
                    }
                    Ok(Item::Aggregate(*function, index))
                }
                SelectItem::All => Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "* is not valid with aggregate items",
                )),
                SelectItem::Expression { .. } => Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "expressions mixed with aggregates are not supported",
                )),
            })
            .collect::<Result<Vec<_>, _>>()?;
        let group_indexes = query
            .group_by
            .iter()
            .map(|name| metadata.column_index(name))
            .collect::<Result<Vec<_>, _>>()?;
        let names: Vec<_> = query.items.iter().map(select_item_name).collect();
        let output = Relation {
            names: names.clone(),
            qualified_names: names.clone(),
            rows: Vec::new(),
        };
        let order = bind_relation_order(&output, &query.order_by)?;
        let limit = eval_count(query.limit.as_ref(), params, "LIMIT")?;
        let offset = eval_count(query.offset.as_ref(), params, "OFFSET")?.unwrap_or(0);
        sink.start(names)?;
        let mut skipped = 0;
        let mut emitted = 0;
        let mut emit = |row: Row| -> Result<bool, PhobosError> {
            if limit.is_some_and(|max| emitted >= max) {
                return Ok(false);
            }
            if skipped < offset {
                skipped += 1;
                return Ok(true);
            }
            sink.row(row)?;
            emitted += 1;
            Ok(limit.is_none_or(|max| emitted < max))
        };
        let top_k = limit.and_then(|limit| limit.checked_add(offset));
        let mut output_top = (!order.is_empty())
            .then(|| top_k.map(|k| bounded_sort::TopK::new(order.clone(), k)))
            .flatten();
        let mut output_sort = if order.is_empty() || top_k.is_some() {
            None
        } else {
            Some(bounded_sort::Sorter::new(
                &self.data_dir,
                order,
                self.query_memory_bytes,
            )?)
        };
        let mut output_row = |row: Row| -> Result<bool, PhobosError> {
            if let Some(having) = &query.having {
                if !matches_filter_relation(
                    having,
                    &output.names,
                    &output.qualified_names,
                    &row,
                    params,
                )? {
                    return Ok(true);
                }
            }
            if let Some(top) = &mut output_top {
                top.push(row)?;
                return Ok(true);
            }
            match &mut output_sort {
                Some(sorter) => {
                    let _sort_push = phobos_observability::span("aggregate.sort_push");
                    sorter.push(row)?;
                    Ok(true)
                }
                None => emit(row),
            }
        };
        let passes = |row: &Row| -> Result<bool, PhobosError> {
            match &query.filter {
                Some(filter) => matches_filter_relation(
                    filter,
                    &metadata.names,
                    &metadata.qualified_names,
                    row,
                    params,
                ),
                None => Ok(true),
            }
        };
        // 0.2-B: a single-table aggregate whose filter binds to borrowed
        // values reads only the columns it uses, straight from the page image.
        let projected = if query.joins.is_empty() {
            let scope = engine_v2::Scope::Relation {
                names: &metadata.names,
                qualified_names: &metadata.qualified_names,
            };
            engine_v2::RowFilter::bind(query.filter.as_ref(), &scope, params)
        } else {
            None
        };
        let mut required = vec![false; left.columns.len()];
        if let Some(filter) = &projected {
            filter.require(&mut required);
            for index in &group_indexes {
                required[*index] = true;
            }
            for item in &items {
                match item {
                    Item::Column(index, _) | Item::Aggregate(_, Some(index)) => {
                        required[*index] = true;
                    }
                    Item::Aggregate(_, None) => {}
                }
            }
        }
        let mut group = Group::new(&items);
        if group_indexes.is_empty() {
            if let Some(filter) = &projected {
                phobos_observability::event("engine_v2.projected_aggregate", 1);
                self.visit_aggregate_input(
                    &left,
                    query.filter.as_ref(),
                    filter,
                    &required,
                    params,
                    &mut |values| {
                        group.push_refs(|index| values[index])?;
                        Ok(true)
                    },
                )?;
            } else {
                self.visit_joined_rows(&left, query.joins.first(), &mut |row| {
                    if passes(&row)? {
                        let _push = phobos_observability::span("aggregate.row_handoff");
                        group.push(&row)?;
                    }
                    Ok(true)
                })?;
            }
            output_row(group.finish()?)?;
        } else {
            // Retain only one aggregate state per canonical key. If group state
            // crosses the query-memory budget, abandon this pass and reuse the
            // existing bounded spool/sort implementation below.
            let mut groups: HashMap<Vec<u8>, Group<'_>> = HashMap::new();
            let mut state_bytes = 0usize;
            let mut exceeded = false;
            let memory_bytes = self.query_memory_bytes.max(1);
            if let Some(filter) = &projected {
                let _hash_build = phobos_observability::span("aggregate.hash_build");
                phobos_observability::event("engine_v2.projected_group_by", 1);
                let mut key = Vec::new();
                self.visit_aggregate_input(
                    &left,
                    query.filter.as_ref(),
                    filter,
                    &required,
                    params,
                    &mut |values| {
                        engine_v2::group_key_into(values, &group_indexes, &mut key)?;
                        // Borrowed lookup: a key is allocated only for a new group.
                        let group = match groups.get_mut(key.as_slice()) {
                            Some(group) => group,
                            None => {
                                let group = Group::new(&items);
                                state_bytes = state_bytes.saturating_add(
                                    std::mem::size_of::<(Vec<u8>, Group<'_>)>()
                                        + key.len()
                                        + 16
                                        + group.memory_bytes(),
                                );
                                groups.entry(key.clone()).or_insert(group)
                            }
                        };
                        let before = group.memory_bytes();
                        group.push_refs(|index| values[index])?;
                        let after = group.memory_bytes();
                        state_bytes = state_bytes.saturating_add(after).saturating_sub(before);
                        if state_bytes > memory_bytes {
                            exceeded = true;
                            return Ok(false);
                        }
                        Ok(true)
                    },
                )?;
            } else {
                let _hash_build = phobos_observability::span("aggregate.hash_build");
                self.visit_joined_rows(&left, query.joins.first(), &mut |row| {
                    if !passes(&row)? {
                        return Ok(true);
                    }
                    let key = group_key(&row, &group_indexes);
                    let group = groups.entry(key).or_insert_with_key(|key| {
                        let group = Group::new(&items);
                        state_bytes = state_bytes.saturating_add(
                            std::mem::size_of::<(Vec<u8>, Group<'_>)>()
                                + key.capacity()
                                + 16
                                + group.memory_bytes(),
                        );
                        group
                    });
                    let before = group.memory_bytes();
                    group.push(&row)?;
                    let after = group.memory_bytes();
                    state_bytes = state_bytes.saturating_add(after).saturating_sub(before);
                    if state_bytes > memory_bytes {
                        exceeded = true;
                        return Ok(false);
                    }
                    Ok(true)
                })?;
            }
            if !exceeded {
                phobos_observability::event("aggregate.group_count", groups.len() as u64);
                let mut groups: Vec<_> = groups.into_iter().collect();
                groups.sort_unstable_by(|a, b| a.0.cmp(&b.0));
                for (_, group) in groups {
                    if !output_row(group.finish()?)? {
                        break;
                    }
                }
            } else {
                phobos_observability::event("aggregate.hash_fallback", 1);
                drop(groups);
                let mut input = GroupInput::new(&self.data_dir)?;
                self.visit_joined_rows(&left, query.joins.first(), &mut |row| {
                    if passes(&row)? {
                        input.push(&row)?;
                    }
                    Ok(true)
                })?;
                input.finish_writing()?;
                let hash_semantics = input.bytes <= memory_bytes;
                let group_order = if hash_semantics {
                    vec![(0, true)]
                } else {
                    group_indexes.iter().map(|i| (*i, true)).collect()
                };
                let mut sorter =
                    bounded_sort::Sorter::new(&self.data_dir, group_order, memory_bytes)?;
                input.visit(|mut row| {
                    if hash_semantics {
                        let key = group_key(&row, &group_indexes);
                        row.values.insert(0, Value::Binary(key));
                    }
                    let _sort_push = phobos_observability::span("aggregate.sort_push");
                    sorter.push(row)
                })?;
                let mut key: Option<Vec<Value>> = None;
                let mut more = true;
                let _sort_finish = phobos_observability::span("aggregate.sort_finish");
                sorter.finish(|mut row| {
                    let next: Vec<Value> = if hash_semantics {
                        vec![row.values.remove(0)]
                    } else {
                        group_indexes
                            .iter()
                            .map(|i| row.values[*i].clone())
                            .collect()
                    };
                    let mut same = true;
                    if let Some(key) = &key {
                        for (a, b) in key.iter().zip(&next) {
                            if compare_for_sort(a, b)? != Ordering::Equal {
                                same = false;
                                break;
                            }
                        }
                        if !same {
                            more = output_row(group.finish()?)?;
                            if !more {
                                return Ok(false);
                            }
                            group = Group::new(&items);
                        }
                    }
                    key = Some(next);
                    group.push(&row)?;
                    Ok(true)
                })?;
                if more && key.is_some() {
                    output_row(group.finish()?)?;
                }
            }
        }
        if let Some(top) = output_top {
            for row in top.finish()? {
                if !emit(row)? {
                    break;
                }
            }
        } else if let Some(sorter) = output_sort {
            let _sort_finish = phobos_observability::span("aggregate.sort_finish");
            sorter.finish(emit)?;
        }
        sink.finish()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[derive(Default)]
    struct Capture {
        columns: Vec<String>,
        rows: Vec<Row>,
        ended: bool,
        cancel: bool,
    }
    impl ResultSink for Capture {
        fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError> {
            self.columns = columns;
            Ok(())
        }
        fn row(&mut self, row: Row) -> Result<(), PhobosError> {
            self.rows.push(row);
            if self.cancel {
                Err(PhobosError::new(ErrorCode::Io, "aggregate cancelled"))
            } else {
                Ok(())
            }
        }
        fn finish(&mut self) -> Result<(), PhobosError> {
            self.ended = true;
            Ok(())
        }
        fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
            panic!("expected rows")
        }
    }
    #[test]
    fn bounded_group_arithmetic_matches_existing_aggregate_for_types_and_overflow() {
        for values in [
            vec![
                Value::Null,
                Value::Int64(4),
                Value::Int64(-3),
                Value::Int64(8),
            ],
            vec![Value::Int64(i64::MAX), Value::Int64(1)],
            vec![Value::Float64(2.5), Value::Null, Value::Float64(-4.25)],
            vec![
                Value::Decimal {
                    unscaled: -100,
                    scale: 2,
                },
                Value::Decimal {
                    unscaled: 33,
                    scale: 2,
                },
            ],
            vec![
                Value::Decimal {
                    unscaled: i128::MAX,
                    scale: 0,
                },
                Value::Decimal {
                    unscaled: 1,
                    scale: 0,
                },
            ],
            vec![
                Value::Text("z".into()),
                Value::Null,
                Value::Text("a".into()),
            ],
            vec![Value::Null],
            vec![],
        ] {
            let rows: Vec<_> = values.into_iter().map(|v| Row::new(vec![v])).collect();
            for function in [
                AggregateFunction::Count,
                AggregateFunction::Sum,
                AggregateFunction::Avg,
                AggregateFunction::Min,
                AggregateFunction::Max,
            ] {
                let expected = compute_aggregate(function, Some(0), &rows);
                let items = [Item::Aggregate(function, Some(0))];
                let mut group = Group::new(&items);
                let actual = rows
                    .iter()
                    .try_for_each(|row| group.push(row))
                    .and_then(|()| group.finish());
                match (expected, actual) {
                    (Ok(value), Ok(row)) => assert_eq!(row.values, [value]),
                    (Err(a), Err(b)) => assert_eq!(a.code, b.code),
                    (a, b) => panic!("aggregate mismatch: {a:?}, {b:?}"),
                }
            }
        }
    }
    #[test]
    fn streamed_grouping_preserves_signed_zero_hash_semantics() {
        let dir = std::env::temp_dir().join(format!("phobos-group-zero-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (g DOUBLE)").unwrap();
        for value in [0.0, -0.0, 0.0] {
            db.execute_params("INSERT INTO t VALUES ($1)", &[Value::Float64(value)])
                .unwrap();
        }
        for budget in [2, 128] {
            db.query_memory_bytes = budget;
            let sql = "SELECT COUNT(*) AS n FROM t GROUP BY g ORDER BY n";
            let expected = db.execute(sql).unwrap();
            let mut capture = Capture::default();
            db.execute_stream(sql, &[], &mut capture).unwrap();
            assert_eq!(
                QueryResult::Rows {
                    columns: capture.columns,
                    rows: capture.rows
                },
                expected
            );
        }
        for value in [f64::NAN, f64::from_bits(0x7ff8_0000_0000_0001)] {
            db.execute_params("INSERT INTO t VALUES ($1)", &[Value::Float64(value)])
                .unwrap();
        }
        for budget in [2, 128] {
            db.query_memory_bytes = budget;
            let sql = "SELECT COUNT(*) AS n FROM t GROUP BY g ORDER BY n";
            let expected = db.execute(sql);
            let mut capture = Capture::default();
            let actual = db.execute_stream(sql, &[], &mut capture);
            match (expected, actual) {
                (Ok(expected), Ok(())) => assert_eq!(
                    QueryResult::Rows {
                        columns: capture.columns,
                        rows: capture.rows
                    },
                    expected
                ),
                (Err(a), Err(b)) => assert_eq!(a.code, b.code),
                (a, b) => panic!("NaN grouping mismatch: {a:?}, {b:?}"),
            }
        }
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn streamed_grouping_empty_global_having_join_and_cancellation_match() {
        let dir =
            std::env::temp_dir().join(format!("phobos-stream-group-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.query_memory_bytes = 3;
        db.execute("CREATE TABLE t (g BIGINT, v BIGINT)").unwrap();
        db.execute("CREATE TABLE r (g BIGINT)").unwrap();
        db.execute("INSERT INTO r VALUES (1),(2),(3)").unwrap();
        db.execute("INSERT INTO t VALUES (1,4),(1,NULL),(2,-3),(3,8),(NULL,2),(2,7),(1,9)")
            .unwrap();
        for sql in [
            "SELECT COUNT(*) AS n, COUNT(v) AS nn, SUM(v) AS s, AVG(v) AS a, MIN(v) AS lo, MAX(v) AS hi FROM t",
            "SELECT COUNT(*) AS n, SUM(v) AS s FROM t WHERE g>100",
            "SELECT g, COUNT(*) AS n, SUM(v) AS s, AVG(v) AS a FROM t GROUP BY g ORDER BY g",
            "SELECT g, COUNT(v) AS n FROM t GROUP BY g HAVING n>1 ORDER BY n DESC LIMIT 1 OFFSET 1",
            "SELECT g FROM t GROUP BY g ORDER BY g",
            "SELECT g, COUNT(*) AS n FROM t WHERE g>100 GROUP BY g ORDER BY g",
            "SELECT t.g, COUNT(*) AS n, SUM(t.v) AS s FROM t LEFT JOIN r ON t.g=r.g GROUP BY t.g ORDER BY t.g",
        ] {
            let expected = db.execute(sql).unwrap();
            let mut capture = Capture::default();
            db.execute_stream(sql, &[], &mut capture).unwrap();
            assert!(capture.ended);
            assert_eq!(
                QueryResult::Rows {
                    columns: capture.columns,
                    rows: capture.rows
                },
                expected,
                "{sql}"
            );
        }
        for sql in [
            "SELECT COUNT(*) AS n FROM t",
            "SELECT g, SUM(v) AS s FROM t GROUP BY g ORDER BY g",
        ] {
            db.execute("BEGIN").unwrap();
            if let Some(transaction) = db.active_txn.as_mut() {
                transaction.database.query_memory_bytes = 3;
            } else {
                assert!(db.private_txn.is_some());
                db.query_memory_bytes = 3;
            }
            let mut capture = Capture {
                cancel: true,
                ..Capture::default()
            };
            assert!(db.execute_stream(sql, &[], &mut capture).is_err());
            assert!(!capture.ended);
            assert_eq!(
                db.execute("COMMIT").unwrap_err().code,
                ErrorCode::TransactionState
            );
            db.execute("ROLLBACK").unwrap();
        }
        db.execute("INSERT INTO t VALUES (9,9223372036854775807),(9,1)")
            .unwrap();
        let mut capture = Capture::default();
        assert_eq!(
            db.execute_stream("SELECT SUM(v) AS s FROM t WHERE g=9", &[], &mut capture)
                .unwrap_err()
                .code,
            ErrorCode::TypeMismatch
        );
        assert!(!capture.ended);
        assert!(!fs::read_dir(&dir).unwrap().any(|entry| {
            entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill-")
        }));
        drop(db);
        let reopened = Database::open(&dir).unwrap();
        drop(reopened);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn join_count_cardinality_preserves_duplicates_nulls_left_and_projection_fallback() {
        let dir = std::env::temp_dir().join(format!("phobos-join-count-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE l (k BIGINT, v TEXT)").unwrap();
        db.execute("CREATE TABLE r (k BIGINT, v TEXT)").unwrap();
        db.execute("INSERT INTO l VALUES (1,'a'),(1,'b'),(2,'c'),(NULL,'n'),(9,'z')")
            .unwrap();
        db.execute("INSERT INTO r VALUES (1,'x'),(1,NULL),(2,'y'),(NULL,'q')")
            .unwrap();
        db.query_memory_bytes = 1024 * 1024;
        for sql in [
            "SELECT COUNT(*) FROM l INNER JOIN r ON l.k=r.k",
            "SELECT COUNT(*) FROM l LEFT JOIN r ON l.k=r.k",
            "SELECT COUNT(r.v) FROM l INNER JOIN r ON l.k=r.k",
            "SELECT COUNT(r.v) FROM l LEFT JOIN r ON l.k=r.k",
            "SELECT l.v,r.v FROM l INNER JOIN r ON l.k=r.k ORDER BY l.v",
        ] {
            let expected = db.execute(sql).unwrap();
            let mut capture = Capture::default();
            db.execute_stream(sql, &[], &mut capture).unwrap();
            assert_eq!(
                QueryResult::Rows {
                    columns: capture.columns,
                    rows: capture.rows
                },
                expected,
                "{sql}"
            );
        }
        let mut capture = Capture::default();
        db.execute_stream(
            "SELECT COUNT(*) FROM l INNER JOIN r ON l.k=r.k",
            &[],
            &mut capture,
        )
        .unwrap();
        assert_eq!(capture.rows, [Row::new(vec![Value::Int64(5)])]);
        let mut capture = Capture::default();
        db.execute_stream(
            "SELECT COUNT(*) FROM l LEFT JOIN r ON l.k=r.k",
            &[],
            &mut capture,
        )
        .unwrap();
        assert_eq!(capture.rows, [Row::new(vec![Value::Int64(7)])]);
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }
}
