//! 0.1.9-A1: one canonical equality/hash contract for every relational path.
//!
//! These tests force the same logical join and grouping through every
//! execution algorithm PHOBOS has (hash join, bounded nested-loop join, hash
//! aggregation, sort aggregation; collecting and streaming executors) and prove
//! the results are identical. Before A1 the hash paths keyed on a type-tagged
//! string of the raw representation (`I:1` vs `F:3ff0…`, signed-zero and NaN bit
//! patterns) while the loop/sort paths coerced through `f64` and rejected NaN,
//! so the result depended on which algorithm the row-count threshold selected.
use super::*;

/// Row-order-insensitive fingerprint of a result. Rows are compared through
/// their debug rendering because `Value` deliberately has no total `Eq` (NaN).
fn fingerprint(rows: &[Row]) -> Vec<String> {
    let mut out: Vec<String> = rows.iter().map(|row| format!("{:?}", row.values)).collect();
    out.sort();
    out
}

fn result_rows(result: QueryResult) -> Vec<Row> {
    match result {
        QueryResult::Rows { rows, .. } => rows,
        other => panic!("expected rows, got {other:?}"),
    }
}

#[derive(Default)]
struct Capture {
    rows: Vec<Row>,
    ended: bool,
}
impl ResultSink for Capture {
    fn start(&mut self, _: Vec<String>) -> Result<(), PhobosError> {
        Ok(())
    }
    fn row(&mut self, row: Row) -> Result<(), PhobosError> {
        self.rows.push(row);
        Ok(())
    }
    fn finish(&mut self) -> Result<(), PhobosError> {
        self.ended = true;
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
        panic!("expected rows")
    }
}

fn temp_database(name: &str) -> (PathBuf, Database) {
    let dir = std::env::temp_dir().join(format!(
        "phobos-a1-{name}-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ));
    let db = Database::open(&dir).unwrap();
    (dir, db)
}

/// Runs `sql` through the collecting executor and the streaming executor at
/// the given row budget and returns both fingerprints (or both errors).
fn run_both(
    db: &mut Database,
    sql: &str,
    params: &[Value],
    budget: usize,
) -> (
    Result<Vec<String>, ErrorCode>,
    Result<Vec<String>, ErrorCode>,
) {
    db.query_memory_bytes = budget;
    let collected = db
        .execute_params(sql, params)
        .map(|result| fingerprint(&result_rows(result)))
        .map_err(|error| error.code);
    let mut capture = Capture::default();
    let streamed = db
        .execute_stream(sql, params, &mut capture)
        .map(|()| fingerprint(&capture.rows))
        .map_err(|error| error.code);
    (collected, streamed)
}

/// Deterministic value generator covering the numeric corner cases the
/// contract has to get right, plus NULLs and duplicates.
fn tricky_number(seed: u64) -> Value {
    match seed % 16 {
        0 => Value::Null,
        1 => Value::Int64(0),
        2 => Value::Float64(0.0),
        3 => Value::Float64(-0.0),
        4 => Value::Int64(1),
        5 => Value::Float64(1.0),
        6 => Value::Float64(1.5),
        7 => Value::Int64(9_007_199_254_740_993),
        8 => Value::Float64(9_007_199_254_740_992.0),
        9 => Value::Int64(9_007_199_254_740_992),
        10 => Value::Float64(f64::NAN),
        11 => Value::Float64(f64::from_bits(0x7ff8_0000_0000_0001)),
        12 => Value::Int64(-7),
        13 => Value::Float64(-7.0),
        14 => Value::Float64(f64::INFINITY),
        _ => Value::Int64(i64::MAX),
    }
}

fn generated_rows(count: usize, seed: &mut u64, width: usize) -> Vec<Row> {
    (0..count)
        .map(|_| {
            *seed = seed
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(1_442_695_040_888_963_407);
            let key = tricky_number(*seed >> 33);
            let mut values = vec![key];
            values.extend((1..width).map(|i| Value::Int64((*seed >> 40) as i64 + i as i64)));
            Row::new(values)
        })
        .collect()
}

/// Reference join: the canonical contract applied pairwise, NULL never joins.
fn oracle_join(left: &[Row], right: &[Row], kind: JoinKind, right_width: usize) -> Vec<Row> {
    let mut out = Vec::new();
    for l in left {
        let mut matched = false;
        for r in right {
            if !l.values[0].is_null()
                && !r.values[0].is_null()
                && l.values[0].canonical_eq(&r.values[0]) == Some(true)
            {
                matched = true;
                let mut values = l.values.clone();
                values.extend(r.values.iter().cloned());
                out.push(Row::new(values));
            }
        }
        if !matched && kind == JoinKind::Left {
            let mut values = l.values.clone();
            values.extend((0..right_width).map(|_| Value::Null));
            out.push(Row::new(values));
        }
    }
    out
}

#[test]
fn a1_hash_and_nested_loop_joins_agree_with_the_canonical_oracle() {
    let mut seed = 0x5eed_u64;
    for (left_count, right_count) in [(0, 5), (5, 0), (1, 1), (7, 9), (64, 33), (300, 257)] {
        let left = generated_rows(left_count, &mut seed, 2);
        let right = generated_rows(right_count, &mut seed, 3);
        for kind in [JoinKind::Inner, JoinKind::Left] {
            let expected = fingerprint(&oracle_join(&left, &right, kind, 3));
            let hashed = hash_join_rows(&left, &right, 0, 0, kind, 3).unwrap();
            assert_eq!(
                fingerprint(&hashed),
                expected,
                "hash {kind:?} {left_count}x{right_count}"
            );
            for budget in [1, 2, 3, 16, 1024] {
                let looped =
                    bounded_nested_loop_join_rows(&left, &right, 0, 0, kind, 3, budget).unwrap();
                assert_eq!(
                    fingerprint(&looped),
                    expected,
                    "nested loop {kind:?} budget {budget} {left_count}x{right_count}"
                );
            }
        }
    }
}

#[test]
fn p1e_reused_probe_keys_are_the_owned_canonical_keys_for_every_value_class() {
    let values = [
        Value::Int64(-7),
        Value::Float64(-7.5),
        Value::Float64(-0.0),
        Value::Float64(f64::NAN),
        Value::Boolean(true),
        Value::Text("borrowed-text".into()),
        Value::Binary(vec![0, 1, 255]),
        Value::Date(-2),
        Value::Timestamp(17),
        Value::Decimal {
            unscaled: -1234,
            scale: 2,
        },
    ];
    let mut reused = Vec::with_capacity(64);
    let capacity = reused.capacity();
    for value in &values {
        let expected = value.canonical_key();
        assert_eq!(
            join_probe_key(value, &mut reused),
            Some(expected.as_slice())
        );
        assert_eq!(reused.capacity(), capacity);
    }
    assert_eq!(join_probe_key(&Value::Null, &mut reused), None);
    assert_eq!(
        join_probe_key(&Value::Float64(1.0), &mut reused),
        Some(Value::Int64(1).canonical_key().as_slice())
    );
    assert_eq!(
        join_probe_key(&Value::Float64(-0.0), &mut reused),
        Some(Value::Int64(0).canonical_key().as_slice())
    );
    assert_eq!(
        join_probe_key(
            &Value::Float64(f64::from_bits(0x7ff8_0000_0000_0001)),
            &mut reused
        ),
        Some(Value::Float64(f64::NAN).canonical_key().as_slice())
    );
}

#[test]
fn a1_sql_joins_return_identical_rows_for_every_algorithm_and_executor() {
    let (dir, mut db) = temp_database("join");
    db.execute("CREATE TABLE l (k BIGINT, tag TEXT NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE r (k DOUBLE, tag TEXT NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE d (k DOUBLE, tag TEXT NOT NULL)")
        .unwrap();
    let mut seed = 0xa1_u64;
    for (table, count) in [("l", 40usize), ("r", 37), ("d", 23)] {
        for (ordinal, row) in generated_rows(count, &mut seed, 1).into_iter().enumerate() {
            let value = match (&row.values[0], table) {
                // BIGINT columns only take integers; DOUBLE columns take both.
                (Value::Float64(_), "l") => Value::Int64((seed >> 45) as i64 % 3),
                (value, _) => value.clone(),
            };
            // Unique tags make every ORDER BY below a total order, so LIMIT/OFFSET
            // select the same rows whatever the algorithm's tie order was.
            db.execute_params(
                &format!("INSERT INTO {table} VALUES ($1, $2)"),
                &[value, Value::Text(format!("{table}{ordinal:03}"))],
            )
            .unwrap();
        }
    }
    let queries = [
        "SELECT l.k, l.tag, r.k, r.tag FROM l JOIN r ON l.k = r.k",
        "SELECT l.k, l.tag, r.k, r.tag FROM l LEFT JOIN r ON l.k = r.k",
        "SELECT r.k, r.tag, l.k, l.tag FROM r JOIN l ON r.k = l.k",
        "SELECT r.k, d.k FROM r JOIN d ON r.k = d.k",
        "SELECT r.k, d.k FROM r LEFT JOIN d ON r.k = d.k",
        "SELECT l.k, r.k FROM l JOIN r ON l.k = r.k WHERE l.k >= 1",
        "SELECT l.k, r.k, l.tag, r.tag FROM l JOIN r ON l.k = r.k ORDER BY l.k, r.k, l.tag, r.tag LIMIT 25 OFFSET 3",
        "SELECT l.k, r.k, l.tag, r.tag FROM l LEFT JOIN r ON l.k = r.k ORDER BY l.tag DESC, r.tag LIMIT 30",
    ];
    for sql in queries {
        let mut baseline: Option<Vec<String>> = None;
        for budget in [1, 2, 5, 37, 40, 1024, 1 << 20] {
            let (collected, streamed) = run_both(&mut db, sql, &[], budget);
            let collected = collected.unwrap_or_else(|code| panic!("{sql} @ {budget}: {code:?}"));
            let streamed = streamed.unwrap_or_else(|code| panic!("{sql} @ {budget}: {code:?}"));
            assert_eq!(
                collected, streamed,
                "{sql} @ budget {budget}: collecting vs streaming"
            );
            match &baseline {
                None => baseline = Some(collected),
                Some(expected) => {
                    assert_eq!(
                        &collected, expected,
                        "{sql} @ budget {budget}: algorithm changed rows"
                    )
                }
            }
        }
        assert!(
            !baseline.unwrap().is_empty(),
            "{sql} produced no rows; corpus is too thin"
        );
    }
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn a1_group_by_returns_identical_groups_for_hash_and_sort_strategies() {
    let (dir, mut db) = temp_database("group");
    db.execute("CREATE TABLE t (g DOUBLE, h BIGINT, s TEXT, v BIGINT)")
        .unwrap();
    let mut seed = 0x6_u64;
    for i in 0..97i64 {
        seed = seed.wrapping_mul(6_364_136_223_846_793_005).wrapping_add(1);
        let g = tricky_number(seed >> 33);
        let g = match g {
            Value::Int64(v) => Value::Float64(v as f64),
            other => other,
        };
        let h = match (seed >> 20) % 4 {
            0 => Value::Null,
            n => Value::Int64(n as i64),
        };
        let s = match (seed >> 50) % 3 {
            0 => Value::Null,
            1 => Value::Text("x".into()),
            _ => Value::Text("X".into()),
        };
        db.execute_params(
            "INSERT INTO t VALUES ($1, $2, $3, $4)",
            &[g, h, s, Value::Int64(i)],
        )
        .unwrap();
    }
    let queries = [
        "SELECT g, COUNT(*) AS n, SUM(v) AS total, MIN(v) AS lo, MAX(v) AS hi FROM t GROUP BY g",
        "SELECT h, COUNT(*) AS n FROM t GROUP BY h",
        "SELECT s, COUNT(v) AS n FROM t GROUP BY s",
        "SELECT g, h, COUNT(*) AS n FROM t GROUP BY g, h",
        "SELECT g, h, s, COUNT(*) AS n, SUM(v) AS total FROM t GROUP BY g, h, s HAVING n > 1",
        "SELECT h, COUNT(*) AS n FROM t GROUP BY h ORDER BY h",
        "SELECT g, COUNT(*) AS n FROM t GROUP BY g ORDER BY g",
        "SELECT g, COUNT(*) AS n FROM t GROUP BY g ORDER BY n DESC, g LIMIT 3",
    ];
    for sql in queries {
        let mut baseline: Option<Vec<String>> = None;
        for budget in [1, 2, 3, 50, 96, 97, 1024] {
            let (collected, streamed) = run_both(&mut db, sql, &[], budget);
            let collected = collected.unwrap_or_else(|code| panic!("{sql} @ {budget}: {code:?}"));
            let streamed = streamed.unwrap_or_else(|code| panic!("{sql} @ {budget}: {code:?}"));
            assert_eq!(
                collected, streamed,
                "{sql} @ budget {budget}: collecting vs streaming"
            );
            match &baseline {
                None => baseline = Some(collected),
                Some(expected) => {
                    assert_eq!(
                        &collected, expected,
                        "{sql} @ budget {budget}: strategy changed groups"
                    )
                }
            }
        }
    }
    // The canonical groups themselves: 0/-0 is one group, every NaN payload is one
    // group, 1 and 1.0 are one group, and NaN orders last.
    db.query_memory_bytes = 1024;
    let groups = result_rows(
        db.execute("SELECT g, COUNT(*) AS n FROM t GROUP BY g ORDER BY g")
            .unwrap(),
    );
    let keys: Vec<String> = groups
        .iter()
        .map(|row| format!("{:?}", row.values[0]))
        .collect();
    let zero_groups = keys
        .iter()
        .filter(|k| *k == "Float64(0.0)" || *k == "Float64(-0.0)")
        .count();
    assert_eq!(zero_groups, 1, "signed zeros must be one group: {keys:?}");
    assert_eq!(
        keys.iter().filter(|k| *k == "Float64(NaN)").count(),
        1,
        "{keys:?}"
    );
    assert_eq!(keys.first().unwrap(), "Float64(-7.0)", "{keys:?}");
    assert_eq!(
        keys[keys.len() - 2],
        "Float64(NaN)",
        "NaN sorts after every number: {keys:?}"
    );
    assert_eq!(
        keys.last().unwrap(),
        "Null",
        "NULL group sorts last: {keys:?}"
    );
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

/// The architecture-review defect remains covered across the in-memory and
/// byte-budgeted grace-hash strategies. Both apply one canonical contract.
#[test]
fn a1_regression_join_result_is_stable_across_the_strategy_threshold() {
    let (dir, mut db) = temp_database("threshold");
    assert_eq!(db.query_memory_bytes, DEFAULT_QUERY_MEMORY_BYTES);
    db.execute("CREATE TABLE l (k BIGINT NOT NULL, name TEXT NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE r (k DOUBLE, name TEXT NOT NULL)")
        .unwrap();
    // Left keys: the values whose equality used to depend on the algorithm.
    db.execute("INSERT INTO l VALUES (1,'one'),(0,'zero'),(9007199254740993,'big+1'),(9007199254740992,'big'),(-7,'neg'),(5,'five')")
        .unwrap();
    // Right: 1,024 rows (the hash side of the threshold). Filler keys never
    // match a left key; the interesting keys are 1.0, -0.0, 2^53 (as a float),
    // -7.0, NaN, NULL, and a duplicate 1.0.
    let mut values: Vec<String> = (0..1_017)
        .map(|i| format!("({}.5,'filler{i}')", 1_000 + i))
        .collect();
    values.extend([
        "(1.0,'r-one')".to_string(),
        "(-0.0,'r-negzero')".to_string(),
        "(9007199254740992.0,'r-big')".to_string(),
        "(-7.0,'r-neg')".to_string(),
        "(1.0,'r-one-dup')".to_string(),
        "(NULL,'r-null')".to_string(),
        "(0.5,'r-half')".to_string(),
    ]);
    db.execute(&format!("INSERT INTO r VALUES {}", values.join(",")))
        .unwrap();
    assert_eq!(
        result_rows(db.execute("SELECT COUNT(*) AS n FROM r").unwrap())[0].values,
        [Value::Int64(1_024)]
    );
    // ANALYZE makes the plan description and the algorithm choice read the
    // same row count (without statistics the description assumes 1,000 rows
    // while the choice uses the scanned count).
    db.execute("ANALYZE l").unwrap();
    db.execute("ANALYZE r").unwrap();
    let queries = [
        "SELECT l.name, r.name FROM l JOIN r ON l.k = r.k",
        "SELECT l.name, r.name FROM l LEFT JOIN r ON l.k = r.k",
        "SELECT l.k, COUNT(*) AS n FROM l JOIN r ON l.k = r.k GROUP BY l.k",
    ];
    let mut hashed = Vec::new();
    for sql in queries {
        let (collected, streamed) = run_both(&mut db, sql, &[], DEFAULT_QUERY_MEMORY_BYTES);
        assert!(
            db.last_plan().unwrap().contains("Hash Join"),
            "{sql}: {:?}",
            db.last_plan()
        );
        let collected = collected.unwrap();
        assert_eq!(
            collected,
            streamed.unwrap(),
            "{sql}: hash side, collecting vs streaming"
        );
        hashed.push(collected);
    }
    // The expected join rows, spelled out: 1 matches both 1.0 rows, 0 matches -0.0,
    // 2^53 matches 2^53.0, 2^53+1 matches nothing, -7 matches -7.0, 5 matches nothing.
    let expected_inner = fingerprint(&[
        Row::new(vec![Value::Text("one".into()), Value::Text("r-one".into())]),
        Row::new(vec![
            Value::Text("one".into()),
            Value::Text("r-one-dup".into()),
        ]),
        Row::new(vec![
            Value::Text("zero".into()),
            Value::Text("r-negzero".into()),
        ]),
        Row::new(vec![Value::Text("big".into()), Value::Text("r-big".into())]),
        Row::new(vec![Value::Text("neg".into()), Value::Text("r-neg".into())]),
    ]);
    assert_eq!(hashed[0], expected_inner);
    assert_eq!(
        hashed[1].len(),
        7,
        "LEFT JOIN keeps big+1 and five: {:?}",
        hashed[1]
    );

    // Force the byte-budgeted grace path for the same logical join.
    db.execute("INSERT INTO r VALUES (2999.5,'filler-1025')")
        .unwrap();
    db.execute("ANALYZE r").unwrap();
    assert_eq!(
        result_rows(db.execute("SELECT COUNT(*) AS n FROM r").unwrap())[0].values,
        [Value::Int64(1_025)]
    );
    for (index, sql) in queries.iter().enumerate() {
        let (collected, streamed) = run_both(&mut db, sql, &[], 32 * 1024);
        assert!(
            db.last_plan().unwrap().contains("Grace Hash Join"),
            "{sql}: {:?}",
            db.last_plan()
        );
        let collected = collected.unwrap();
        assert_eq!(
            collected,
            streamed.unwrap(),
            "{sql}: loop side, collecting vs streaming"
        );
        assert_eq!(
            collected, hashed[index],
            "{sql}: crossing the threshold changed the result"
        );
    }
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn a1_nan_and_signed_zero_join_identically_on_both_sides_of_the_threshold() {
    let (dir, mut db) = temp_database("nan");
    db.execute("CREATE TABLE a (k DOUBLE, tag TEXT NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE b (k DOUBLE, tag TEXT NOT NULL)")
        .unwrap();
    let nan_a = f64::NAN;
    let nan_b = f64::from_bits(0x7ff8_0000_0000_0001);
    for (table, values) in [
        (
            "a",
            vec![
                (nan_a, "a-nan"),
                (0.0, "a-zero"),
                (2.0, "a-two"),
                (-nan_a, "a-negnan"),
            ],
        ),
        (
            "b",
            vec![
                (nan_b, "b-nan-payload"),
                (-0.0, "b-negzero"),
                (2.0, "b-two"),
                (nan_a, "b-nan"),
            ],
        ),
    ] {
        for (value, tag) in values {
            db.execute_params(
                &format!("INSERT INTO {table} VALUES ($1, $2)"),
                &[Value::Float64(value), Value::Text(tag.into())],
            )
            .unwrap();
        }
    }
    let sql = "SELECT a.tag, b.tag FROM a JOIN b ON a.k = b.k";
    let expected = fingerprint(&[
        Row::new(vec![
            Value::Text("a-nan".into()),
            Value::Text("b-nan-payload".into()),
        ]),
        Row::new(vec![
            Value::Text("a-nan".into()),
            Value::Text("b-nan".into()),
        ]),
        Row::new(vec![
            Value::Text("a-negnan".into()),
            Value::Text("b-nan-payload".into()),
        ]),
        Row::new(vec![
            Value::Text("a-negnan".into()),
            Value::Text("b-nan".into()),
        ]),
        Row::new(vec![
            Value::Text("a-zero".into()),
            Value::Text("b-negzero".into()),
        ]),
        Row::new(vec![
            Value::Text("a-two".into()),
            Value::Text("b-two".into()),
        ]),
    ]);
    for budget in [1, 3, 4, 1024] {
        let (collected, streamed) = run_both(&mut db, sql, &[], budget);
        assert_eq!(collected.as_ref().unwrap(), &expected, "budget {budget}");
        assert_eq!(streamed.unwrap(), expected, "budget {budget}");
    }
    // Comparison predicates and ORDER BY use the same contract: NaN = NaN is
    // true, NaN sorts last, and no algorithm reports "NaN is not orderable".
    let (collected, streamed) = run_both(
        &mut db,
        "SELECT tag FROM a WHERE k = $1 ORDER BY k",
        &[Value::Float64(nan_b)],
        1,
    );
    assert_eq!(
        collected.as_ref().unwrap(),
        &vec![
            "[Text(\"a-nan\")]".to_string(),
            "[Text(\"a-negnan\")]".to_string()
        ]
    );
    assert_eq!(streamed.unwrap(), collected.unwrap());
    let ordered = result_rows(db.execute("SELECT tag FROM a ORDER BY k").unwrap());
    let tags: Vec<_> = ordered
        .iter()
        .map(|row| row.values[0].to_string())
        .collect();
    assert_eq!(tags[..2], ["a-zero", "a-two"]);
    assert!(tags[2..].iter().all(|tag| tag.contains("nan")), "{tags:?}");
    let extremes = result_rows(
        db.execute("SELECT MIN(k) AS lo, MAX(k) AS hi FROM a")
            .unwrap(),
    );
    assert_eq!(extremes[0].values[0], Value::Float64(0.0));
    assert!(matches!(extremes[0].values[1], Value::Float64(v) if v.is_nan()));
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn a1_incomparable_join_columns_fail_identically_for_every_algorithm() {
    let (dir, mut db) = temp_database("incomparable");
    db.execute("CREATE TABLE i (k BIGINT NOT NULL)").unwrap();
    db.execute("CREATE TABLE t (k TEXT NOT NULL)").unwrap();
    db.execute("CREATE TABLE d2 (k DECIMAL(10,2) NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE d1 (k DECIMAL(10,1) NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE d2b (k DECIMAL(12,2) NOT NULL)")
        .unwrap();
    db.execute("CREATE TABLE f (k DOUBLE NOT NULL)").unwrap();
    db.execute("INSERT INTO i VALUES (1),(2)").unwrap();
    db.execute("INSERT INTO t VALUES ('1'),('x')").unwrap();
    db.execute("INSERT INTO d2 VALUES (1.00),(2.50)").unwrap();
    db.execute("INSERT INTO d1 VALUES (1.0),(2.5)").unwrap();
    db.execute("INSERT INTO d2b VALUES (1.00),(2.50)").unwrap();
    db.execute("INSERT INTO f VALUES (1.0),(2.5)").unwrap();
    // Before A1 the hash join returned zero rows here while the nested loop
    // raised TypeMismatch; now the join is rejected before either algorithm runs.
    for sql in [
        "SELECT i.k FROM i JOIN t ON i.k = t.k",
        "SELECT i.k FROM i LEFT JOIN t ON i.k = t.k",
        "SELECT d2.k FROM d2 JOIN d1 ON d2.k = d1.k",
        "SELECT d2.k FROM d2 JOIN i ON d2.k = i.k",
        "SELECT f.k FROM f JOIN d1 ON f.k = d1.k",
    ] {
        for budget in [1, 2, 1024] {
            let (collected, streamed) = run_both(&mut db, sql, &[], budget);
            assert_eq!(collected, Err(ErrorCode::TypeMismatch), "{sql} @ {budget}");
            assert_eq!(streamed, Err(ErrorCode::TypeMismatch), "{sql} @ {budget}");
        }
    }
    // Same class, different precision or representation: joins normally.
    for (sql, expected) in [
        (
            "SELECT d2.k, d2b.k FROM d2 JOIN d2b ON d2.k = d2b.k",
            2usize,
        ),
        ("SELECT i.k, f.k FROM i JOIN f ON i.k = f.k", 1),
        ("SELECT f.k, i.k FROM f LEFT JOIN i ON f.k = i.k", 2),
    ] {
        for budget in [1, 2, 1024] {
            let (collected, streamed) = run_both(&mut db, sql, &[], budget);
            assert_eq!(
                collected.as_ref().unwrap().len(),
                expected,
                "{sql} @ {budget}"
            );
            assert_eq!(streamed.unwrap(), collected.unwrap(), "{sql} @ {budget}");
        }
    }
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn a1_analyze_distinct_counts_use_the_grouping_contract() {
    let (dir, mut db) = temp_database("analyze");
    db.execute("CREATE TABLE t (g DOUBLE)").unwrap();
    for value in [
        0.0,
        -0.0,
        f64::NAN,
        f64::from_bits(0x7ff8_0000_0000_0001),
        1.0,
        1.0,
    ] {
        db.execute_params("INSERT INTO t VALUES ($1)", &[Value::Float64(value)])
            .unwrap();
    }
    db.execute("ANALYZE t").unwrap();
    let distinct = db.stats.values().next().unwrap().columns["g"].distinct_count;
    let groups = result_rows(
        db.execute("SELECT g, COUNT(*) AS n FROM t GROUP BY g")
            .unwrap(),
    );
    assert_eq!(distinct, 3);
    assert_eq!(groups.len() as u64, distinct);
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}
