//! Focused E4 SQL operators kept separate from the storage and DML core.
use super::*;
thread_local! {static CLOCK: std::cell::Cell<Option<i64>> = const {std::cell::Cell::new(None)};}
pub(super) struct StatementClock(Option<i64>);
impl StatementClock {
    pub(super) fn current() -> Option<i64> {
        CLOCK.get()
    }
    pub(super) fn install(value: Option<i64>) -> Self {
        Self(CLOCK.replace(value))
    }
    pub(super) fn enter() -> Self {
        let old = CLOCK.get();
        if old.is_none() {
            CLOCK.set(Some(
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map_or(0, |d| d.as_micros().min(i64::MAX as u128) as i64),
            ));
        }
        Self(old)
    }
}
impl Drop for StatementClock {
    fn drop(&mut self) {
        CLOCK.set(self.0);
    }
}

pub(super) fn distinct_rows(
    rows: Vec<Row>,
    memory_bytes: usize,
    data_dir: &Path,
) -> Result<Vec<Row>, PhobosError> {
    let width = rows.first().map_or(0, |row| row.values.len());
    let indexes: Vec<usize> = (0..width).collect();
    if rows.iter().map(row_bytes).sum::<usize>() <= memory_bytes.max(1) {
        let mut seen = HashSet::new();
        let mut output = Vec::new();
        for row in rows {
            phobos_error::cancellation::checkpoint_at("distinct.hash")?;
            if seen.insert(group_key(&row, &indexes)) {
                output.push(row);
            }
        }
        return Ok(output);
    }
    let order: Vec<(usize, bool)> = indexes.iter().map(|index| (*index, true)).collect();
    let sorted = external_sort_rows(rows, &order, memory_bytes, data_dir)?;
    let mut output: Vec<Row> = Vec::new();
    for row in sorted {
        phobos_error::cancellation::checkpoint_at("distinct.spill")?;
        let duplicate = output.last().is_some_and(|previous| {
            previous
                .values
                .iter()
                .zip(&row.values)
                .all(|(a, b)| grouping_equal(a, b))
        });
        if !duplicate {
            output.push(row);
        }
    }
    Ok(output)
}

pub(super) fn eval_builtin(name: &str, args: Vec<Value>) -> Result<Value, PhobosError> {
    let wrong = || {
        PhobosError::new(
            ErrorCode::TypeMismatch,
            format!("invalid arguments for {name}"),
        )
    };
    match name.to_ascii_uppercase().as_str() {
        "CURRENT_TIMESTAMP" if args.is_empty() => {
            let _clock = StatementClock::enter();
            Ok(Value::Timestamp(CLOCK.get().expect("statement clock")))
        }
        "LOWER" | "UPPER" if args.len() == 1 => match &args[0] {
            Value::Null => Ok(Value::Null),
            Value::Text(value) if name.eq_ignore_ascii_case("LOWER") => {
                Ok(Value::Text(value.to_lowercase()))
            }
            Value::Text(value) => Ok(Value::Text(value.to_uppercase())),
            _ => Err(wrong()),
        },
        "LENGTH" | "CHAR_LENGTH" | "CHARACTER_LENGTH" if args.len() == 1 => match &args[0] {
            Value::Null => Ok(Value::Null),
            Value::Text(value) => Ok(Value::Int64(value.chars().count() as i64)),
            Value::Binary(value) => Ok(Value::Int64(value.len() as i64)),
            _ => Err(wrong()),
        },
        "TRIM" | "LTRIM" | "RTRIM" if args.len() == 1 => match &args[0] {
            Value::Null => Ok(Value::Null),
            Value::Text(s) => Ok(Value::Text(
                match name.to_ascii_uppercase().as_str() {
                    "LTRIM" => s.trim_start_matches(' '),
                    "RTRIM" => s.trim_end_matches(' '),
                    _ => s.trim_matches(' '),
                }
                .to_owned(),
            )),
            _ => Err(wrong()),
        },
        "OCTET_LENGTH" if args.len() == 1 => match &args[0] {
            Value::Null => Ok(Value::Null),
            Value::Text(s) => Ok(Value::Int64(s.len() as i64)),
            Value::Binary(s) => Ok(Value::Int64(s.len() as i64)),
            _ => Err(wrong()),
        },
        "REPLACE" if args.len() == 3 => {
            if args.iter().any(Value::is_null) {
                return Ok(Value::Null);
            }
            let [Value::Text(s), Value::Text(from), Value::Text(to)] = args.as_slice() else {
                return Err(wrong());
            };
            let count = if from.is_empty() {
                0
            } else {
                s.matches(from).count()
            };
            let size = s
                .len()
                .checked_add(
                    count
                        .checked_mul(to.len().saturating_sub(from.len()))
                        .ok_or_else(wrong)?,
                )
                .ok_or_else(wrong)?;
            if size > 16 * 1024 * 1024 {
                return Err(PhobosError::new(
                    ErrorCode::ResourceLimit,
                    "function output exceeds 16 MiB",
                ));
            }
            Ok(Value::Text(if from.is_empty() {
                s.clone()
            } else {
                s.replace(from, to)
            }))
        }
        "SUBSTRING" | "SUBSTR" if args.len() == 2 || args.len() == 3 => {
            if args.iter().any(Value::is_null) {
                return Ok(Value::Null);
            }
            let (Value::Text(s), Value::Int64(start)) = (&args[0], &args[1]) else {
                return Err(wrong());
            };
            let length = match args.get(2) {
                None => None,
                Some(Value::Int64(n)) if *n >= 0 => Some(*n as u64),
                _ => return Err(wrong()),
            };
            // SQL one-based character positions: a start before 1 consumes length.
            let skipped = if *start < 1 {
                1u64.saturating_add(start.unsigned_abs())
            } else {
                0
            };
            let count = length.map_or(usize::MAX, |n| {
                n.saturating_sub(skipped).min(usize::MAX as u64) as usize
            });
            let offset = start.saturating_sub(1).max(0) as usize;
            Ok(Value::Text(s.chars().skip(offset).take(count).collect()))
        }
        "CONCAT" if !args.is_empty() => {
            let mut result = String::new();
            for arg in args {
                match arg {
                    Value::Null => (),
                    Value::Text(s) => {
                        if result.len().saturating_add(s.len()) > 16 * 1024 * 1024 {
                            return Err(PhobosError::new(
                                ErrorCode::ResourceLimit,
                                "function output exceeds 16 MiB",
                            ));
                        }
                        result.push_str(&s);
                    }
                    _ => return Err(wrong()),
                }
            }
            Ok(Value::Text(result))
        }
        "FLOOR" | "CEIL" | "CEILING" | "ROUND" if args.len() == 1 => match args[0] {
            Value::Null => Ok(Value::Null),
            Value::Int64(n) => Ok(Value::Int64(n)),
            Value::Float64(n) => Ok(Value::Float64(match name.to_ascii_uppercase().as_str() {
                "FLOOR" => n.floor(),
                "ROUND" => n.round(),
                _ => n.ceil(),
            })),
            _ => Err(wrong()),
        },
        "ABS" if args.len() == 1 => match args[0] {
            Value::Null => Ok(Value::Null),
            Value::Int64(value) => value.checked_abs().map(Value::Int64).ok_or_else(wrong),
            Value::Float64(value) => Ok(Value::Float64(value.abs())),
            Value::Decimal { unscaled, scale } => unscaled
                .checked_abs()
                .map(|unscaled| Value::Decimal { unscaled, scale })
                .ok_or_else(wrong),
            _ => Err(wrong()),
        },
        "COALESCE" if !args.is_empty() => Ok(args
            .into_iter()
            .find(|value| !value.is_null())
            .unwrap_or(Value::Null)),
        "NULLIF" if args.len() == 2 => {
            if args[0].is_null() {
                return Ok(Value::Null);
            }
            if args[1].is_null() {
                return Ok(args[0].clone());
            }
            Ok(if grouping_equal(&args[0], &args[1]) {
                Value::Null
            } else {
                args[0].clone()
            })
        }
        _ => Err(PhobosError::new(
            ErrorCode::Semantic,
            format!("unknown or invalid scalar function {name}"),
        )),
    }
}

pub(super) fn eval_in(needle: Value, values: Vec<Value>) -> Result<Value, PhobosError> {
    if needle.is_null() {
        return Ok(Value::Null);
    }
    let mut saw_null = false;
    for value in values {
        phobos_error::cancellation::checkpoint_at("in.membership")?;
        if value.is_null() {
            saw_null = true;
            continue;
        }
        if needle.canonical_cmp(&value) == Some(Ordering::Equal) {
            return Ok(Value::Boolean(true));
        }
    }
    Ok(if saw_null {
        Value::Null
    } else {
        Value::Boolean(false)
    })
}

pub(super) fn eval_like(value: Value, pattern: Value) -> Result<Value, PhobosError> {
    let (value, pattern) = match (value, pattern) {
        (Value::Text(value), Value::Text(pattern)) => (value, pattern),
        (Value::Null, _) | (_, Value::Null) => return Ok(Value::Null),
        _ => {
            return Err(PhobosError::new(
                ErrorCode::TypeMismatch,
                "LIKE requires text operands",
            ));
        }
    };
    let text: Vec<char> = value.chars().collect();
    let pattern: Vec<char> = pattern.chars().collect();
    let mut previous = vec![false; text.len() + 1];
    previous[0] = true;
    for token in pattern {
        let mut current = vec![false; text.len() + 1];
        match token {
            '%' => {
                for i in 0..=text.len() {
                    current[i] = previous[i] || (i > 0 && current[i - 1]);
                }
            }
            '_' => {
                current[1..].copy_from_slice(&previous[..text.len()]);
            }
            literal => {
                for i in 1..=text.len() {
                    current[i] = previous[i - 1] && text[i - 1] == literal;
                }
            }
        }
        previous = current;
    }
    Ok(Value::Boolean(previous[text.len()]))
}
