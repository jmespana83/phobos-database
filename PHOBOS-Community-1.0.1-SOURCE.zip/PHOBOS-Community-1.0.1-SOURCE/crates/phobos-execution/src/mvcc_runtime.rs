//! Runtime SQL read adapter and resolved session mutations for capability 4.
//! Server admission/publication must retain the owning database through streams.
use super::*;
use phobos_txn::mvcc::sessions::{Session, SessionManager, Statement as StatementPin};
use phobos_txn::mvcc::{SnapshotPin, StatusFile};
use std::{
    collections::BTreeSet,
    sync::{Arc, Mutex, MutexGuard, RwLock},
};
#[cfg(test)]
mod batch_dml_tests;
mod bulk;
mod commit_admission;
#[cfg(test)]
mod commit_path_tests;
#[cfg(test)]
mod commit_pipeline_tests;
#[cfg(test)]
mod compact_redo_tests;
mod domains;
#[cfg(test)]
mod fast_path_engine_tests;
mod freeze;
#[cfg(test)]
mod hint_tests;
mod housekeeping;
mod lazy_index;
#[cfg(test)]
mod lazy_index_tests;
pub use lazy_index::lazy_index_requested;
mod lifecycle_report;
#[cfg(test)]
mod lifecycle_tests;
pub mod maintenance;
mod online_ops;
mod ownership;
mod publication;
mod read_directory;
mod reclaim;
pub use freeze::FreezeReport;
pub use lifecycle_report::{StorageLifecycleReport, TableLifecycle};
#[cfg(test)]
mod enterprise_tests;
#[cfg(test)]
mod reclaim_tests;
mod schema;
mod spill;
#[cfg(test)]
mod spill_tests;
mod sql_sessions;
#[cfg(test)]
mod tests;
#[cfg(test)]
mod unique_tests;
mod writes;
pub use online_ops::{OnlineBackupReport, OnlineCheckReport};
pub use ownership::{ActiveWait, ConflictDiagnostics, Key as ConflictKey, WaitStats};
pub use phobos_txn::mvcc::sessions::{CommitMetrics, StatusMetrics};
pub use reclaim::{
    CHECKPOINT_RECLAIM_PAGES, ReclaimMetrics, ReclaimPlan, ReclaimReport, WorthPolicy,
};
pub use spill::{DEFAULT_SCRATCH_QUOTA, SpillStats};
pub use writes::{ChangeIter, PendingView, RowChange, SessionWrites, StatementOwn};

/// Default in-memory budget of one transaction's pending writes; beyond it
/// writes spill to transaction-local scratch files (0.1.9-A4).
pub const DEFAULT_WRITE_SPILL_THRESHOLD: usize = 64 * 1024 * 1024;

/// Owns storage/WAL; statement executors borrow this owner for their lifetime.
/// Existing legacy opens never implicitly enable this capability.
pub struct MvccDatabase {
    runtime_config: phobos_config::RuntimeConfig,
    data_dir: PathBuf,
    admission: sql_sessions::Admission,
    queue: commit_admission::Queue,
    connections: Mutex<BTreeMap<u64, Arc<Mutex<sql_sessions::Connection>>>>,
    controls: Mutex<BTreeMap<u64, Arc<ownership::WaitControl>>>,
    ownership: Arc<ownership::Ownership>,
    database: Mutex<Database>,
    readers: RwLock<Arc<read_directory::ReadDirectory>>,
    fenced: std::sync::atomic::AtomicBool,
    sessions: Arc<SessionManager>,
    /// 0.2-C commit order: Stage A (prepare + WAL append) and Stage B
    /// (receipts + publication) of batch N run under this lock; the WAL
    /// force between them does not. `commit_turn` orders Stage B by batch.
    commits: Mutex<publication::CommitOrder>,
    commit_turn: std::sync::Condvar,
    /// Single-flight WAL force: one physical sync serves every commit whose
    /// records were written before it was captured.
    force_gate: Mutex<publication::ForceGate>,
    force_done: std::sync::Condvar,
    /// Stage B publishers whose force completed and who wait for the
    /// commit-order lock; Stage A yields to them between members.
    publishers_waiting: std::sync::atomic::AtomicUsize,
    wal: Mutex<phobos_wal::v2::Wal>,
    /// Memtable spill threshold for SQL session writes (bytes).
    write_spill_threshold: std::sync::atomic::AtomicUsize,
    /// Per-transaction scratch quota for spilled writes (bytes).
    write_scratch_quota: std::sync::atomic::AtomicU64,
    /// C1 candidate-page bookkeeping (in memory; rebuilt lazily after open).
    reclaim_state: Mutex<reclaim::ReclaimState>,
    /// Reclaim passes are serialized: one plan at a time per database.
    reclaim_lock: Mutex<()>,
    /// 0.2-K.1: set once when storage maintenance faulted (a panic inside a
    /// reclaim pass, or poisoned lifecycle bookkeeping). Reclamation then
    /// stays suspended until restart; reads and writes continue.
    maintenance_fault: std::sync::OnceLock<String>,
    /// 0.2-K.4: lazy index sweeper cursor/debt.
    sweep_state: Mutex<lazy_index::SweepState>,
    /// 0.2-K.4: whether reclaim may leave non-unique entries stale (requires
    /// the catalog capability as well). Default from `PHOBOS_LAZY_INDEX`.
    lazy_allowed: std::sync::atomic::AtomicBool,
    /// 0.2-K.4: whether the stale-index sweeper may run (diagnostics/tests).
    sweep_allowed: std::sync::atomic::AtomicBool,
    /// 0.2-K: COMMIT LSN (= publication sequence) and page outcome of the
    /// last published reclaim plan (read back by the serialized pass).
    last_reclaim_publication: std::sync::atomic::AtomicU64,
    last_reclaim_outcome: Mutex<phobos_storage::PageLifecycleOutcome>,
    /// 0.2-K Part K: wake-up channel of the automatic maintenance worker.
    maintenance: Arc<maintenance::Signal>,
    freeze_state: Mutex<freeze::FreezeSweep>,
    /// D3 evidence: admission passes (write statements) and the committed
    /// table views built for them.
    admission_passes: std::sync::atomic::AtomicU64,
    admission_views: std::sync::atomic::AtomicU64,
    bulk_max_index_builders: Arc<std::sync::atomic::AtomicUsize>,
}

/// D3 evidence counters: one committed view per admission pass is the goal.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct AdmissionMetrics {
    /// Write statements staged (each is one admission pass).
    pub passes: u64,
    /// Committed table/index views built for admission (readers created).
    pub views_built: u64,
}

enum ViewScope<'a> {
    All,
    Table(TableId),
    Statements(&'a [Statement]),
}

impl MvccDatabase {
    fn lock_database(&self) -> Result<MutexGuard<'_, Database>, PhobosError> {
        let wait = phobos_observability::span("mvcc.database_directory_acquire");
        let database = self
            .database
            .lock()
            .map_err(|_| PhobosError::new(ErrorCode::TransactionState, "MVCC database poisoned"))?;
        drop(wait);
        database.ensure_available()?;
        self.sessions.ensure_available()?;
        Ok(database)
    }
    pub fn open(path: &Path) -> Result<Self, PhobosError> {
        Self::open_with_config(path, &phobos_config::RuntimeConfig::load(None)?)
    }
    pub fn open_with_config(
        path: &Path,
        config: &phobos_config::RuntimeConfig,
    ) -> Result<Self, PhobosError> {
        config.validate()?;
        if phobos_wal::v2::inspect(path.join("phobos.wal"))?.page_format != 4 {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "explicit MVCC heap migration required",
            ));
        }
        phobos_storage::set_hint_bits_enabled(config.hint_bits_enabled);
        let (mut statuses, wal) = StatusFile::recover_database(path)?;
        statuses.set_growth_extent(config.status_growth_extent_records)?;
        let data_dir = fs::canonicalize(path)?;
        for name in ["catalog.phc", "indexes.phc"] {
            if !data_dir.join(name).is_file() {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "MVCC catalog missing after recovery",
                ));
            }
        }
        let catalog = Catalog::open(&data_dir)?;
        housekeeping::cleanup(&data_dir, &catalog)?;
        let mut flush = phobos_storage::committed_pages::FlushConfig::from_env()?;
        flush.page_cache_bytes = config.page_cache_bytes;
        let store = phobos_storage::committed_pages::CommittedStore::new(&data_dir, flush)?;
        let mut heaps = BTreeMap::new();
        for table in catalog.tables() {
            let mut heap = HeapTable::open_versioned(
                heap_path(&data_dir, table.id),
                table.clone(),
                DEFAULT_BUFFER_PAGES,
            )?;
            heap.attach_committed(&store, phobos_wal::v2::FileId::Heap(table.id))?;
            heaps.insert(table.id, heap);
        }
        let mut indexes = open_indexes(&data_dir, &catalog)?;
        for (id, tree) in &mut indexes {
            tree.attach_committed(&store, phobos_wal::v2::FileId::Index(*id))?;
        }
        let stats = load_statistics(&data_dir)?;
        let sessions = SessionManager::new(statuses, 1024, 1024, 2048)?;
        let database = Database {
            data_dir,
            catalog,
            heaps,
            indexes,
            private_txn: None,
            committed_store: Some(store),
            buffer_pages: DEFAULT_BUFFER_PAGES,
            query_memory_bytes: config.query_memory_bytes,
            last_access_path: None,
            last_plan: None,
            stats,
            wal: None,
            wal_v2: None,
            fenced: false,
            txn_manager: None,
            active_txn: None,
            private_staging: false,
            mvcc_view: false,
        };
        let readers = read_directory::ReadDirectory::new(&database)?;
        let database = Self {
            runtime_config: config.clone(),
            data_dir: database.data_dir.clone(),
            admission: sql_sessions::Admission::default(),
            queue: commit_admission::Queue::default(),
            connections: Mutex::new(BTreeMap::new()),
            controls: Mutex::new(BTreeMap::new()),
            ownership: Arc::new(ownership::Ownership::new(database.data_dir.clone())),
            database: Mutex::new(database),
            readers: RwLock::new(Arc::new(readers)),
            fenced: std::sync::atomic::AtomicBool::new(false),
            sessions,
            commits: Mutex::new(publication::CommitOrder::default()),
            commit_turn: std::sync::Condvar::new(),
            force_gate: Mutex::new(publication::ForceGate::default()),
            force_done: std::sync::Condvar::new(),
            publishers_waiting: std::sync::atomic::AtomicUsize::new(0),
            wal: Mutex::new(wal),
            write_spill_threshold: std::sync::atomic::AtomicUsize::new(
                config.write_spill_threshold_bytes,
            ),
            write_scratch_quota: std::sync::atomic::AtomicU64::new(
                config.write_spill_scratch_quota_bytes,
            ),
            reclaim_state: Mutex::new(reclaim::ReclaimState::default()),
            reclaim_lock: Mutex::new(()),
            maintenance_fault: std::sync::OnceLock::new(),
            sweep_state: Mutex::new(lazy_index::SweepState::default()),
            lazy_allowed: std::sync::atomic::AtomicBool::new(lazy_index::lazy_index_requested()),
            sweep_allowed: std::sync::atomic::AtomicBool::new(true),
            last_reclaim_publication: std::sync::atomic::AtomicU64::new(0),
            last_reclaim_outcome: Mutex::new(phobos_storage::PageLifecycleOutcome::default()),
            maintenance: Arc::new(maintenance::Signal::default()),
            freeze_state: Mutex::new(freeze::FreezeSweep::default()),
            admission_passes: std::sync::atomic::AtomicU64::new(0),
            admission_views: std::sync::atomic::AtomicU64::new(0),
            bulk_max_index_builders: Arc::new(std::sync::atomic::AtomicUsize::new(0)),
        };
        // Open-time compatibility gate sees only currently visible rows.
        // Historical index versions are intentionally not UNIQUE violations.
        {
            let session = database.connect(u64::MAX)?;
            let mut view = database.statement(&session, None)?;
            view.database.validate_canonical_unique()?;
        }
        Ok(database)
    }

    pub fn conflict_diagnostics(&self) -> Result<ConflictDiagnostics, PhobosError> {
        self.ownership.diagnostics()
    }
    /// 0.1.9-B1/B2 evidence counters: status lookups, shared-cache hits,
    /// status-page reads and hint hits for this database.
    #[must_use]
    pub fn status_metrics(&self) -> StatusMetrics {
        self.sessions.status_metrics()
    }
    /// D1 evidence counters: identities allocated, status records written
    /// and status-file forces for this database.
    #[must_use]
    pub fn commit_metrics(&self) -> CommitMetrics {
        self.sessions.commit_metrics()
    }
    /// D3 evidence counters: admission passes and views built for them.
    #[must_use]
    pub fn admission_metrics(&self) -> AdmissionMetrics {
        AdmissionMetrics {
            passes: self
                .admission_passes
                .load(std::sync::atomic::Ordering::Relaxed),
            views_built: self
                .admission_views
                .load(std::sync::atomic::Ordering::Relaxed),
        }
    }
    /// Sets the pending-write memtable threshold and per-transaction scratch
    /// quota used by transactions that begin afterwards (0.1.9-A4).
    pub fn set_write_spill(&self, threshold: usize, scratch_quota: u64) -> Result<(), PhobosError> {
        if threshold == 0 || scratch_quota == 0 {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "write spill threshold and scratch quota must be positive",
            ));
        }
        self.write_spill_threshold
            .store(threshold, std::sync::atomic::Ordering::Relaxed);
        self.write_scratch_quota
            .store(scratch_quota, std::sync::atomic::Ordering::Relaxed);
        Ok(())
    }
    pub fn write_spill(&self) -> (usize, u64) {
        (
            self.write_spill_threshold
                .load(std::sync::atomic::Ordering::Relaxed),
            self.write_scratch_quota
                .load(std::sync::atomic::Ordering::Relaxed),
        )
    }
    /// Session writes for one SQL transaction: bounded memtable, spilling
    /// beyond the threshold into `<data_dir>/.phobos-mvcc-writes-<stable>/`.
    fn session_writes(&self, stable: u64) -> Result<SessionWrites, PhobosError> {
        let (threshold, quota) = self.write_spill();
        let mut writes = SessionWrites::spilling(
            stable,
            DEFAULT_WRITE_SPILL_THRESHOLD,
            threshold,
            &self.data_dir,
            quota,
        )?;
        writes.control = Arc::new(ownership::WaitControl::with_timeout(
            std::time::Duration::from_millis(self.runtime_config.lock_timeout_ms),
        ));
        Ok(writes)
    }
    /// Cancel only the current unsubmitted transaction generation of a session.
    /// Accepted WAL commits remain owned by their worker and cannot roll back.
    pub fn cancel(&self, id: u64) {
        let control = self
            .controls
            .lock()
            .ok()
            .and_then(|controls| controls.get(&id).cloned());
        if let Some(control) = control {
            control.cancel();
            self.ownership.wake();
            phobos_observability::synchronization_boundary("c6_cancel_observed", &self.data_dir);
        }
    }

    pub fn connect(&self, id: u64) -> Result<Session, PhobosError> {
        self.sessions.connect(id)
    }

    pub fn statement<'a>(
        &'a self,
        session: &Session,
        writes: Option<&SessionWrites>,
    ) -> Result<SqlStatement<'a>, PhobosError> {
        self.view(Arc::new(session.statement()?), writes)
    }

    fn statement_for_at<'a>(
        &'a self,
        session: &Session,
        writes: Option<&SessionWrites>,
        sequence: Option<u64>,
        statement: &Statement,
    ) -> Result<SqlStatement<'a>, PhobosError> {
        let statements = std::slice::from_ref(statement);
        self.view_scoped(
            Arc::new(session.statement_at(sequence)?),
            writes,
            ViewScope::Statements(statements),
        )
    }

    fn view<'a>(
        &'a self,
        pin: Arc<StatementPin>,
        writes: Option<&SessionWrites>,
    ) -> Result<SqlStatement<'a>, PhobosError> {
        self.view_schema(
            pin,
            writes,
            writes.and_then(|writes| writes.schema.as_deref()),
            ViewScope::All,
        )
    }
    fn view_scoped<'a>(
        &'a self,
        pin: Arc<StatementPin>,
        writes: Option<&SessionWrites>,
        scope: ViewScope<'_>,
    ) -> Result<SqlStatement<'a>, PhobosError> {
        self.view_schema(
            pin,
            writes,
            writes.and_then(|writes| writes.schema.as_deref()),
            scope,
        )
    }
    fn view_schema<'a>(
        &'a self,
        pin: Arc<StatementPin>,
        writes: Option<&SessionWrites>,
        schema: Option<&schema::Schema>,
        scope: ViewScope<'_>,
    ) -> Result<SqlStatement<'a>, PhobosError> {
        self.view_filtered(pin, writes, schema, scope)
    }
    /// Build readers for the exact statement relation set. `All` is the safe
    /// fallback for callers without a parsed statement; D3 retains its
    /// existing single-table admission view.
    fn view_filtered<'a>(
        &'a self,
        pin: Arc<StatementPin>,
        writes: Option<&SessionWrites>,
        schema: Option<&schema::Schema>,
        scope: ViewScope<'_>,
    ) -> Result<SqlStatement<'a>, PhobosError> {
        let _construct = phobos_observability::span("view.construct");
        self.sessions.ensure_available()?;
        if self.fenced.load(std::sync::atomic::Ordering::Acquire) {
            return Err(write_conflict("MVCC database fenced; recovery required"));
        }
        // Clone an immutable schema generation, then release its directory guard
        // before file opens, page reads, visibility lookup or publication waits.
        let database = self
            .readers
            .read()
            .map_err(|_| write_conflict("read directory poisoned"))?
            .clone();
        pin.check_database(&database.data_dir)?;
        if writes.is_some_and(|writes| pin.snapshot().own_transaction() != Some(writes.stable_id()))
        {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "session write identity mismatch",
            ));
        }
        let catalog = schema.map_or(&database.catalog, |schema| &schema.catalog);
        let only = match scope {
            ViewScope::All => None,
            ViewScope::Table(table) => Some(BTreeSet::from([table])),
            ViewScope::Statements(statements) => {
                let mut tables = BTreeSet::new();
                let mut exact = true;
                for statement in statements {
                    exact &= collect_statement_tables(statement, catalog, &mut tables)?;
                }
                exact.then_some(tables)
            }
        };
        let mut heaps = BTreeMap::new();
        {
            let _heap_readers = phobos_observability::span("view.heap_readers");
            for (id, heap) in &database.heaps {
                if only.as_ref().is_some_and(|tables| !tables.contains(id)) {
                    continue;
                }
                let mut reader = heap.statement_reader(pin.clone())?;
                if let Some(writes) = writes {
                    reader.set_statement_overlay(Arc::new(writes.overlay_cancellable(*id)?))?;
                }
                heaps.insert(*id, reader);
            }
            if let Some(schema) = schema {
                for table in schema.catalog.tables() {
                    if only
                        .as_ref()
                        .is_some_and(|tables| !tables.contains(&table.id))
                    {
                        continue;
                    }
                    if let std::collections::btree_map::Entry::Vacant(entry) = heaps.entry(table.id)
                    {
                        let mut reader = HeapTable::empty_statement_reader(
                            &heap_path(&schema.root, table.id),
                            table.clone(),
                            pin.clone(),
                        )?;
                        if let Some(writes) = writes {
                            reader.set_statement_overlay(Arc::new(
                                writes.overlay_cancellable(table.id)?,
                            ))?;
                        }
                        entry.insert(reader);
                    }
                }
            }
        }
        phobos_observability::event("view.heap_reader_count", heaps.len() as u64);
        let catalog_indexes = |id: IndexId| {
            schema.map_or_else(
                || database.catalog.indexes().find(|index| index.id == id),
                |schema| schema.catalog.indexes().find(|index| index.id == id),
            )
        };
        let indexes = {
            let _index_readers = phobos_observability::span("view.index_readers");
            database
                .indexes
                .iter()
                .filter(|(id, _)| {
                    catalog_indexes(**id).is_some_and(|index| {
                        only.as_ref()
                            .is_none_or(|tables| tables.contains(&index.table_id))
                    })
                })
                .map(|(id, tree)| Ok((*id, tree.statement_reader()?)))
                .collect::<Result<BTreeMap<_, _>, PhobosError>>()?
        };
        phobos_observability::event("view.index_reader_count", indexes.len() as u64);
        let catalog = {
            let _catalog_clone = phobos_observability::span("view.catalog_clone");
            schema.map_or_else(|| database.catalog.clone(), |schema| schema.catalog.clone())
        };
        Ok(SqlStatement {
            database: Database {
                data_dir: database.data_dir.clone(),
                catalog,
                heaps,
                indexes,
                private_txn: None,
                committed_store: database.committed_store.clone(),
                buffer_pages: database.buffer_pages,
                query_memory_bytes: database.query_memory_bytes,
                last_access_path: None,
                last_plan: None,
                stats: schema.map_or_else(|| database.stats.clone(), |schema| schema.stats.clone()),
                wal: None,
                wal_v2: None,
                fenced: false,
                txn_manager: None,
                active_txn: None,
                private_staging: false,
                mvcc_view: true,
            },
            pin,
            _owner: self,
        })
    }

    pub fn stage(
        &self,
        session: &Session,
        writes: &mut SessionWrites,
        sql: &str,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        self.stage_at(session, writes, sql, params, None)
    }

    pub(super) fn stage_at(
        &self,
        session: &Session,
        writes: &mut SessionWrites,
        sql: &str,
        params: &[Value],
        sequence: Option<u64>,
    ) -> Result<QueryResult, PhobosError> {
        self.stage_parsed_at(session, writes, parse(sql)?, params, sequence)
    }

    pub(super) fn stage_parsed_at(
        &self,
        session: &Session,
        writes: &mut SessionWrites,
        statement: Statement,
        params: &[Value],
        sequence: Option<u64>,
    ) -> Result<QueryResult, PhobosError> {
        if writes
            .ownership
            .as_ref()
            .is_some_and(|lease| !Arc::ptr_eq(&lease.owner, &self.ownership))
        {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "foreign session write owner",
            ));
        }
        if writes.ownership.is_none() {
            writes.ownership = Some(self.ownership.lease(writes.stable_id()));
        }
        let mut view = self.statement_for_at(session, Some(writes), sequence, &statement)?;
        if view.database.catalog.has_foreign_keys() {
            // Conservative first release: one FK-database writer transaction at a time.
            // Ownership survives savepoints and is released by the existing commit/abort lease.
            drop(view);
            let acquired = self
                .ownership
                .acquire(
                    writes.stable_id(),
                    ownership::Key::Table(0),
                    &writes.control,
                )
                .and_then(|()| {
                    if sequence.is_some_and(|s| {
                        self.sessions
                            .publication_state()
                            .map_or(true, |state| state.0 != s)
                    }) {
                        return Err(write_conflict(
                            "FK write snapshot is stale; retry transaction",
                        ));
                    }
                    Ok(())
                });
            if let Err(error) = acquired {
                writes.discard();
                session.abort_failed()?;
                return Err(error);
            }
            view = self.statement_for_at(session, Some(writes), sequence, &statement)?;
        }
        let pin = view.pin.clone();
        let stable = writes.stable_id();
        // Changes admitted earlier in this statement; changes of earlier
        // statements are consulted through the bounded `PendingView`.
        let mut own = StatementOwn::default();
        let schema = writes.schema.clone();
        let control = writes.control.clone();
        // D3: one admission pass per statement owns the committed view, the
        // per-table schema/UNIQUE definitions and the ownership control for
        // every change of the statement.
        self.admission_passes
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let mut pass = AdmissionPass {
            database: self,
            stable,
            control,
            pin,
            metadata: schema,
            view: None,
            tables: BTreeMap::new(),
        };
        let result = writes.stage_statement(&mut view, statement, params, |change, pending| {
            pass.admit(change, &mut own, pending)
        });
        drop(pass);
        drop(view);
        if let Err(error) = &result {
            if matches!(
                error.code,
                ErrorCode::TransactionState | ErrorCode::LockTimeout
            ) {
                writes.discard();
                session.abort_failed()?;
            } else {
                session.fail_statement()?;
            }
        }
        result
    }
}

/// D3: single-pass admission state of one write statement.
///
/// Before D3 every change built two full statement views (all heap readers
/// and all index readers of the database): one before its ownership waits
/// and one after. The pass builds one committed view of the written table
/// and its indexes the first time it is needed and reuses it for every
/// change; after each ownership acquisition the heap reader only drops its
/// frame cache (`refresh_committed_view`), which is what the rebuild
/// achieved: no page cached before the wait may validate uniqueness or a
/// row head afterwards. Index readers read the published tree under its
/// epoch on every visit and never cache. The validation snapshot is still
/// pinned per change, after its acquisitions, exactly as before.
struct AdmissionPass<'a> {
    database: &'a MvccDatabase,
    stable: u64,
    control: Arc<ownership::WaitControl>,
    pin: Arc<StatementPin>,
    metadata: Option<Arc<schema::Schema>>,
    view: Option<SqlStatement<'a>>,
    /// Table schema and its UNIQUE index definitions, resolved once
    /// (0.2-H: shared, not cloned per row).
    tables: BTreeMap<TableId, Arc<(TableSchema, Vec<IndexSchema>)>>,
}
impl<'a> AdmissionPass<'a> {
    /// The committed view of `table` (built once per pass), with the heap
    /// reader's frame cache dropped so that it observes the current
    /// committed pages.
    fn fresh_view(&mut self, table: TableId) -> Result<&mut SqlStatement<'a>, PhobosError> {
        if self
            .view
            .as_ref()
            .is_none_or(|view| !view.database.heaps.contains_key(&table))
        {
            let view = self.database.view_filtered(
                self.pin.clone(),
                None,
                self.metadata.as_deref(),
                ViewScope::Table(table),
            )?;
            self.database
                .admission_views
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            phobos_observability::event("mvcc.admission_view_built", 1);
            self.view = Some(view);
        }
        let view = self.view.as_mut().expect("admission view");
        view.database.heap_mut(table)?.refresh_committed_view()?;
        Ok(view)
    }
    fn table(
        &mut self,
        table: TableId,
    ) -> Result<Arc<(TableSchema, Vec<IndexSchema>)>, PhobosError> {
        if let Some(entry) = self.tables.get(&table) {
            return Ok(entry.clone());
        }
        let view = self.fresh_view(table)?;
        let schema = view
            .database
            .catalog
            .tables()
            .find(|candidate| candidate.id == table)
            .cloned()
            .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "write table missing"))?;
        let definitions = view
            .database
            .catalog
            .indexes_for_table(table)
            .filter(|index| index.unique)
            .cloned()
            .collect::<Vec<_>>();
        let entry = Arc::new((schema, definitions));
        self.tables.insert(table, entry.clone());
        Ok(entry)
    }

    fn admit(
        &mut self,
        change: &RowChange,
        own: &mut StatementOwn,
        pending: &PendingView<'_>,
    ) -> Result<(), PhobosError> {
        use ownership::Key;
        let _admission = phobos_observability::span("mvcc.admission");
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let stable = self.stable;
        let control = self.control.clone();
        let table = self.table(change.table)?;
        let (schema, definitions) = (&table.0, &table.1);
        // 0.2-H: every index key of the new row is built once and reused for
        // validation, key ownership and the UNIQUE recheck (was three times).
        let mut new_keys: Vec<(phobos_types::IndexId, IndexKey)> = Vec::new();
        if let Some(row) = &change.row {
            let view = self.fresh_view(change.table)?;
            for definition in view.database.catalog.indexes_for_table(change.table) {
                let key = index_key_for_row(schema, definition, row)?;
                key.validate_columns(definition.columns.len())?;
                new_keys.push((definition.id, key));
            }
        }
        let new_key = |definition: &IndexSchema, row: &Row| -> Result<IndexKey, PhobosError> {
            match new_keys.iter().find(|(id, _)| *id == definition.id) {
                Some((_, key)) => Ok(key.clone()),
                None => index_key_for_row(schema, definition, row),
            }
        };
        let mut own_logical = Vec::new();
        self.database.ownership.acquire(
            stable,
            Key::Row(change.table, change.logical_row),
            &control,
        )?;
        let old = if let Some((rid, expected)) = change.original {
            let view = self.fresh_view(change.table)?;
            let (actual, row) = view
                .database
                .heap_mut(change.table)?
                .get_version(rid)?
                .ok_or_else(|| write_conflict("row disappeared"))?;
            if actual != expected || actual.visibility.deleter.is_some() {
                return Err(write_conflict("stale row version after ownership wait"));
            }
            Some(row)
        } else {
            None
        };
        let mut keys = BTreeMap::new();
        for definition in definitions {
            for row in old.iter() {
                let key = index_key_for_row(schema, definition, row)?;
                if let Some(logical) = key.logical_unique_key() {
                    keys.insert(Key::Unique(definition.id, logical), ());
                }
            }
            if let Some(row) = &change.row {
                if let Some(logical) = new_key(definition, row)?.logical_unique_key() {
                    own_logical.push((definition.id, logical.clone()));
                    keys.insert(Key::Unique(definition.id, logical), ());
                }
            }
        }
        for (key, ()) in keys {
            self.database.ownership.acquire(stable, key, &control)?;
        }
        // After the key waits: the refreshed reader may not serve a page
        // cached before them for the row head or uniqueness checks below.
        let sessions = self.database.sessions.clone();
        let current = self.fresh_view(change.table)?;
        if let Some((rid, expected)) = change.original {
            let actual = current
                .database
                .heap_mut(change.table)?
                .get_version(rid)?
                .ok_or_else(|| write_conflict("row disappeared after key wait"))?
                .0;
            if actual != expected || actual.visibility.deleter.is_some() {
                return Err(write_conflict("stale row version after key wait"));
            }
        }
        let validation = sessions.validation_snapshot(stable)?;
        let _cost = phobos_observability::span("mvcc.unique_recheck");
        if let Some(row) = &change.row {
            for definition in definitions {
                let key = new_key(definition, row)?;
                if key.contains_null() {
                    continue;
                }
                cancellation_poll.checkpoint_at("mvcc.unique_recheck")?;
                if own.unique_conflict(schema, definition, &key, change.logical_row)?
                    || pending.unique_conflict(schema, definition, &key, change.logical_row, own)?
                {
                    return Err(unique_conflict());
                }
                let database = &mut current.database;
                let heap = database
                    .heaps
                    .get_mut(&change.table)
                    .ok_or_else(|| write_conflict("unique heap missing"))?;
                if !database.indexes.contains_key(&definition.id) {
                    heap.scan_versions(|rid, tuple, candidate| {
                        if change.original.is_some_and(|(original, _)| original == rid)
                            || own.owns_original(change.table, rid)
                            || pending.owns_original(change.table, rid)?
                        {
                            return Ok(true);
                        }
                        if validation
                            .snapshot()
                            .visible(tuple.visibility, &mut sessions.as_ref())?
                            && index_key_for_row(schema, definition, &candidate)?
                                .logical_unique_key()
                                == key.logical_unique_key()
                        {
                            return Err(unique_conflict());
                        }
                        Ok(true)
                    })?;
                    continue;
                }
                let tree = database
                    .indexes
                    .get_mut(&definition.id)
                    .ok_or_else(|| write_conflict("unique index missing"))?;
                // A logical unique key may have arbitrarily many retained old
                // versions. Validate bounded index batches rather than collecting
                // the entire historical RID list before applying visibility.
                let probe = key.logical_unique_key();
                tree.typed_unique_visit(&key, |rid| {
                    if change.original.is_some_and(|(original, _)| original == rid)
                        || own.owns_original(change.table, rid)
                        || pending.owns_original(change.table, rid)?
                    {
                        return Ok(true);
                    }
                    let Some((tuple, candidate)) = heap.get_version(rid)? else {
                        // C2: an entry copied before a reclaim publication may
                        // name a retired slot; it held a globally dead version.
                        // 0.2-K: also FREE, or trimmed/reset away.
                        if heap.slot_reclaimed(rid)? {
                            return Ok(true);
                        }
                        return Err(write_conflict("unique index references missing tuple"));
                    };
                    // 0.2-K Part H: a slot reused after this entry was copied
                    // holds another logical key; that is a stale reference,
                    // never a UNIQUE conflict.
                    if index_key_for_row(schema, definition, &candidate)?.logical_unique_key()
                        != probe
                    {
                        stale_rid_skipped();
                        return Ok(true);
                    }
                    if validation
                        .snapshot()
                        .visible(tuple.visibility, &mut sessions.as_ref())?
                    {
                        return Err(unique_conflict());
                    }
                    Ok(true)
                })?;
            }
        }
        own.push(change, own_logical);
        Ok(())
    }
}

fn collect_named_table(
    name: &str,
    catalog: &Catalog,
    tables: &mut BTreeSet<TableId>,
) -> Result<bool, PhobosError> {
    if name.is_empty() {
        return Ok(true);
    }
    // The server owns virtual system relations. If one reaches the execution
    // runtime, retain the established full-view fallback.
    if name.eq_ignore_ascii_case("phobos_metrics") {
        return Ok(false);
    }
    if let Some(view) = catalog.view(name) {
        tables.insert(view.id);
        tables.extend(view.dependencies.iter().copied());
        return Ok(true);
    }
    let table = catalog.table(name).ok_or_else(|| {
        PhobosError::new(
            ErrorCode::NotFound,
            format!("statement relation does not exist: {name}"),
        )
    })?;
    tables.insert(table.id);
    if catalog.partition_key(name).is_some() {
        for partition in catalog.partitions_for_parent(name) {
            let child = catalog.table(&partition.child).ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    format!("partition relation does not exist: {}", partition.child),
                )
            })?;
            tables.insert(child.id);
        }
    }
    Ok(true)
}

fn collect_expr_tables(
    expr: &Expr,
    catalog: &Catalog,
    tables: &mut BTreeSet<TableId>,
) -> Result<bool, PhobosError> {
    match expr {
        Expr::Literal(_) | Expr::Column(_) | Expr::QuotedColumn(_) | Expr::Parameter(_) => Ok(true),
        Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => {
            collect_expr_tables(expr, catalog, tables)
        }
        Expr::Binary { left, right, .. }
        | Expr::Like {
            expr: left,
            pattern: right,
        } => Ok(collect_expr_tables(left, catalog, tables)?
            && collect_expr_tables(right, catalog, tables)?),
        Expr::Function { args, .. } | Expr::InList { values: args, .. } => {
            let mut exact = true;
            if let Expr::InList { expr, .. } = expr {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
            for arg in args {
                exact &= collect_expr_tables(arg, catalog, tables)?;
            }
            Ok(exact)
        }
        Expr::ScalarSubquery(query) | Expr::Exists(query) => {
            collect_statement_tables(query, catalog, tables)
        }
        Expr::InSubquery { expr, query } => Ok(collect_expr_tables(expr, catalog, tables)?
            && collect_statement_tables(query, catalog, tables)?),
        Expr::Case {
            branches,
            else_expr,
        } => {
            let mut exact = true;
            for (condition, value) in branches {
                exact &= collect_expr_tables(condition, catalog, tables)?;
                exact &= collect_expr_tables(value, catalog, tables)?;
            }
            if let Some(expr) = else_expr {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
            Ok(exact)
        }
    }
}

fn collect_statement_tables(
    statement: &Statement,
    catalog: &Catalog,
    tables: &mut BTreeSet<TableId>,
) -> Result<bool, PhobosError> {
    let mut exact = true;
    if catalog.has_foreign_keys()
        && matches!(
            statement,
            Statement::Insert { .. }
                | Statement::InsertColumns { .. }
                | Statement::InsertSelect { .. }
                | Statement::Update { .. }
                | Statement::Delete { .. }
        )
    {
        return Ok(false);
    }
    match statement {
        Statement::CreateView { query, .. } => {
            exact &= collect_statement_tables(query, catalog, tables)?;
        }
        Statement::Select {
            table,
            filter,
            limit,
            offset,
            ..
        } => {
            exact &= collect_named_table(table, catalog, tables)?;
            for expr in [filter.as_ref(), limit.as_ref(), offset.as_ref()]
                .into_iter()
                .flatten()
            {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
        }
        Statement::Union {
            left,
            right,
            limit,
            offset,
            ..
        } => {
            exact &= collect_statement_tables(left, catalog, tables)?;
            exact &= collect_statement_tables(right, catalog, tables)?;
            for expr in [limit.as_ref(), offset.as_ref()].into_iter().flatten() {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
        }
        Statement::InsertSelect { table, query, .. } => {
            exact &= collect_named_table(table, catalog, tables)?;
            if let Some(identity) = catalog
                .table(table)
                .and_then(|t| catalog.definitions(t.id))
                .and_then(|d| d.identity.as_ref())
            {
                tables.insert(identity.sequence_table);
            }
            exact &= collect_statement_tables(query, catalog, tables)?;
        }
        Statement::RelationalSelect(query) => {
            if let Some(source) = &query.source {
                exact &= collect_statement_tables(source, catalog, tables)?;
            } else {
                exact &= collect_named_table(&query.table, catalog, tables)?;
            }
            for join in &query.joins {
                exact &= collect_named_table(&join.table, catalog, tables)?;
                if let Some(predicate) = &join.predicate {
                    exact &= collect_expr_tables(predicate, catalog, tables)?;
                }
            }
            for item in &query.items {
                if let SelectItem::Expression { expr, .. } = item {
                    exact &= collect_expr_tables(expr, catalog, tables)?;
                }
            }
            for expr in [
                query.filter.as_ref(),
                query.having.as_ref(),
                query.limit.as_ref(),
                query.offset.as_ref(),
            ]
            .into_iter()
            .flatten()
            {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
        }
        Statement::InsertReturning { statement, .. } => {
            exact &= collect_statement_tables(statement, catalog, tables)?;
        }
        Statement::InsertColumns { table, rows, .. } | Statement::Insert { table, rows } => {
            exact &= collect_named_table(table, catalog, tables)?;
            if let Some(identity) = catalog
                .table(table)
                .and_then(|t| catalog.definitions(t.id))
                .and_then(|d| d.identity.as_ref())
            {
                tables.insert(identity.sequence_table);
            }
            for expr in rows.iter().flatten() {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
        }
        Statement::Update {
            table,
            assignments,
            filter,
        } => {
            exact &= collect_named_table(table, catalog, tables)?;
            for (_, expr) in assignments {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
            if let Some(expr) = filter {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
        }
        Statement::Delete { table, filter } => {
            exact &= collect_named_table(table, catalog, tables)?;
            if let Some(expr) = filter {
                exact &= collect_expr_tables(expr, catalog, tables)?;
            }
        }
        Statement::Explain { statement, .. } => {
            exact &= collect_statement_tables(statement, catalog, tables)?;
        }
        Statement::AddColumn { table, .. }
        | Statement::AlterNullable { table, .. }
        | Statement::AlterDefault { table, .. }
        | Statement::RenameTable { table, .. }
        | Statement::CreateIndex { table, .. }
        | Statement::Analyze { table } => {
            exact &= collect_named_table(table, catalog, tables)?;
        }
        Statement::CreateRangePartition { parent, .. } => {
            exact &= collect_named_table(parent, catalog, tables)?;
        }
        Statement::ShowCatalog { .. }
        | Statement::CreateDefinedTable { .. }
        | Statement::CreateTable { .. }
        | Statement::CreatePartitionedTable { .. }
        | Statement::DropIndex { .. } => {}
        Statement::Begin
        | Statement::BeginSnapshot
        | Statement::Savepoint { .. }
        | Statement::RollbackTo { .. }
        | Statement::ReleaseSavepoint { .. }
        | Statement::Commit
        | Statement::Rollback
        | Statement::DropView { .. }
        | Statement::Checkpoint => return Ok(false),
    }
    Ok(exact)
}

fn write_conflict(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TransactionState, message)
}
fn unique_conflict() -> PhobosError {
    PhobosError::new(
        ErrorCode::ConstraintViolation,
        "duplicate key violates unique index",
    )
}

/// Uses the ordinary SQL planner, relational operators and streaming executor.
/// The borrowing lifetime retains database/WAL ownership even on cancellation.
pub struct SqlStatement<'a> {
    database: Database,
    pin: Arc<StatementPin>,
    _owner: &'a MvccDatabase,
}
impl SqlStatement<'_> {
    pub fn execute(&mut self, sql: &str, params: &[Value]) -> Result<QueryResult, PhobosError> {
        let parse_site = phobos_observability::span("sql.parse_site.statement_execute");
        let statement = parse(sql)?;
        drop(parse_site);
        read_statement(&statement)?;
        self.execute_partitioned(statement, params)
    }
    pub fn execute_parsed(&mut self, statement: Statement) -> Result<QueryResult, PhobosError> {
        read_statement(&statement)?;
        self.execute_partitioned(statement, &[])
    }
    pub fn stream(
        &mut self,
        sql: &str,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        let parse_site = phobos_observability::span("sql.parse_site.statement_stream");
        let statement = parse(sql)?;
        drop(parse_site);
        self.stream_parsed(statement, sql, params, sink)
    }
    /// 0.2-B: stream an already-parsed statement (the session parsed it once
    /// to classify it; P1-E parsed the same text three or four times).
    /// `sql` is retained only for the collecting fallback of non-SELECTs.
    pub fn stream_parsed(
        &mut self,
        statement: Statement,
        sql: &str,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        read_statement(&statement)?;
        let partitioned = match &statement {
            Statement::Select { table, .. } => self.database.catalog.partition_key(table).is_some(),
            Statement::RelationalSelect(query) => {
                query.source.is_none()
                    && self.database.catalog.partition_key(&query.table).is_some()
            }
            _ => false,
        };
        if !partitioned && !matches!(statement, Statement::Union { .. }) {
            return self
                .database
                .execute_stream_parsed(statement, sql, params, sink);
        }
        match self.execute_partitioned(statement, params)? {
            QueryResult::Rows { columns, rows } => {
                sink.start(columns)?;
                for row in rows {
                    sink.row(row)?;
                }
                sink.finish()
            }
            QueryResult::Command { tag, rows_affected } => sink.command(tag, rows_affected),
        }
    }
    pub fn last_access_path(&self) -> Option<&str> {
        self.database.last_access_path()
    }

    fn execute_partitioned(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let _clock = sql_surface::StatementClock::enter();
        match statement {
            Statement::Select {
                table,
                columns,
                filter,
                order_by,
                limit,
                offset,
            } if self.database.catalog.partition_key(&table).is_some() => {
                let key = self
                    .database
                    .catalog
                    .partition_key(&table)
                    .expect("partition key")
                    .to_string();
                let children = self
                    .database
                    .catalog
                    .partitions_for_parent(&table)
                    .filter(|part| partition_may_match(part, &key, filter.as_ref(), params))
                    .map(|part| part.child.clone())
                    .collect::<Vec<_>>();
                let mut output_columns = None;
                let mut output_rows = Vec::new();
                let child_statement = |child: String| Statement::Select {
                    table: child,
                    columns: columns.clone(),
                    filter: filter.clone(),
                    order_by: Vec::new(),
                    limit: None,
                    offset: None,
                };
                let pages = children
                    .iter()
                    .filter_map(|child| self.database.catalog.table(child))
                    .filter_map(|schema| {
                        fs::metadata(heap_path(&self.database.data_dir, schema.id)).ok()
                    })
                    .map(|metadata| metadata.len().div_ceil(8192) as usize)
                    .sum::<usize>();
                let parallel = self.pin.snapshot().own_transaction().is_none()
                    && self._owner.runtime_config.parallel_scan_workers > 1
                    && pages >= self._owner.runtime_config.parallel_scan_min_pages
                    && children.len() > 1;
                let results =
                    if parallel {
                        let workers = self
                            ._owner
                            .runtime_config
                            .parallel_scan_workers
                            .min(children.len());
                        let chunks = (0..workers)
                            .map(|worker| {
                                children
                                    .iter()
                                    .skip(worker)
                                    .step_by(workers)
                                    .cloned()
                                    .collect::<Vec<_>>()
                            })
                            .collect::<Vec<_>>();
                        std::thread::scope(|scope| {
                            let mut handles = Vec::new();
                            let cancellation = phobos_error::cancellation::current();
                            let statement_clock = sql_surface::StatementClock::current();
                            for chunk in chunks {
                                let owner = self._owner;
                                let pin = self.pin.clone();
                                let statements =
                                    chunk.into_iter().map(&child_statement).collect::<Vec<_>>();
                                let params = params.to_vec();
                                let cancellation = cancellation.clone();
                                handles.push(scope.spawn(
                                    move || -> Result<Vec<QueryResult>, PhobosError> {
                                        let _clock =
                                            sql_surface::StatementClock::install(statement_clock);
                                        let _cancellation_scope =
                                            cancellation.as_ref().map(|context| context.enter());
                                        phobos_error::cancellation::check_now()?;
                                        let mut view = owner.view_scoped(
                                            pin,
                                            None,
                                            ViewScope::Statements(&statements),
                                        )?;
                                        statements
                                            .into_iter()
                                            .map(|statement| {
                                                view.database
                                                    .execute_statement_direct(statement, &params)
                                            })
                                            .collect()
                                    },
                                ));
                            }
                            let mut results = Vec::new();
                            for handle in handles {
                                results.extend(handle.join().map_err(|_| {
                                    write_conflict("parallel scan worker panicked")
                                })??);
                            }
                            Ok::<_, PhobosError>(results)
                        })?
                    } else {
                        let mut results = Vec::new();
                        for child in children {
                            results.push(
                                self.database
                                    .execute_statement_direct(child_statement(child), params)?,
                            );
                        }
                        results
                    };
                for result in results {
                    if let QueryResult::Rows { columns, rows } = result {
                        output_columns.get_or_insert(columns);
                        output_rows.extend(rows);
                    }
                }
                let output_columns = output_columns.unwrap_or_else(|| match &columns {
                    SelectColumns::All => self
                        .database
                        .catalog
                        .table(&table)
                        .map(|s| s.columns.iter().map(|c| c.name.clone()).collect())
                        .unwrap_or_default(),
                    SelectColumns::Named(names) => names.clone(),
                });
                if !order_by.is_empty() {
                    let positions = order_by
                        .iter()
                        .map(|order| {
                            output_columns
                                .iter()
                                .position(|name| name.eq_ignore_ascii_case(&order.column))
                                .map(|position| (position, order.ascending))
                                .ok_or_else(|| {
                                    PhobosError::new(
                                        ErrorCode::Semantic,
                                        "partition ORDER BY column must be selected",
                                    )
                                })
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    output_rows.sort_by(|a, b| {
                        for (position, ascending) in &positions {
                            let order = a.values[*position]
                                .canonical_cmp(&b.values[*position])
                                .unwrap_or(std::cmp::Ordering::Equal);
                            if order != std::cmp::Ordering::Equal {
                                return if *ascending { order } else { order.reverse() };
                            }
                        }
                        std::cmp::Ordering::Equal
                    });
                }
                let integer = |expr: Option<Expr>, default: usize| -> Result<usize, PhobosError> {
                    match expr {
                        None => Ok(default),
                        Some(Expr::Literal(Value::Int64(v))) if v >= 0 => Ok(v as usize),
                        _ => Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "partition LIMIT/OFFSET must be a nonnegative integer",
                        )),
                    }
                };
                let skip = integer(offset, 0)?;
                let take = integer(limit, usize::MAX)?;
                let rows = output_rows.into_iter().skip(skip).take(take).collect();
                Ok(QueryResult::Rows {
                    columns: output_columns,
                    rows,
                })
            }
            Statement::RelationalSelect(query)
                if query.source.is_none()
                    && self.database.catalog.partition_key(&query.table).is_some()
                    && query.items.len() == 1
                    && matches!(
                        query.items[0],
                        SelectItem::Aggregate {
                            function: AggregateFunction::Count,
                            ..
                        }
                    )
                    && query.group_by.is_empty()
                    && query.joins.is_empty()
                    && query.having.is_none() =>
            {
                let key = self
                    .database
                    .catalog
                    .partition_key(&query.table)
                    .expect("partition key")
                    .to_string();
                let children = self
                    .database
                    .catalog
                    .partitions_for_parent(&query.table)
                    .filter(|part| partition_may_match(part, &key, query.filter.as_ref(), params))
                    .map(|part| part.child.clone())
                    .collect::<Vec<_>>();
                let mut total = 0i64;
                let mut columns = Vec::new();
                for child in children {
                    let mut child_query = query.clone();
                    child_query.table = child;
                    if let QueryResult::Rows {
                        columns: names,
                        rows,
                    } = self.database.execute_statement_direct(
                        Statement::RelationalSelect(child_query),
                        params,
                    )? {
                        columns = names;
                        if let Some(Value::Int64(value)) =
                            rows.first().and_then(|row| row.values.first())
                        {
                            total = total.saturating_add(*value);
                        }
                    }
                }
                Ok(QueryResult::Rows {
                    columns,
                    rows: vec![Row::new(vec![Value::Int64(total)])],
                })
            }
            Statement::Explain { analyze, statement } => {
                let table_filter = match statement.as_ref() {
                    Statement::Select { table, filter, .. }
                        if self.database.catalog.partition_key(table).is_some() =>
                    {
                        Some((table.clone(), filter.clone()))
                    }
                    Statement::RelationalSelect(query)
                        if (query.source.is_none()
                            && self.database.catalog.partition_key(&query.table).is_some()) =>
                    {
                        Some((query.table.clone(), query.filter.clone()))
                    }
                    _ => None,
                };
                if let Some((table, filter)) = table_filter {
                    let key = self
                        .database
                        .catalog
                        .partition_key(&table)
                        .expect("partition key");
                    let selected = self
                        .database
                        .catalog
                        .partitions_for_parent(&table)
                        .filter(|part| partition_may_match(part, key, filter.as_ref(), params))
                        .count();
                    let total = self.database.catalog.partitions_for_parent(&table).count();
                    if analyze {
                        let _ = self.execute_partitioned(*statement, params)?;
                    }
                    return Ok(QueryResult::Rows {
                        columns: vec!["plan".into()],
                        rows: vec![Row::new(vec![Value::Text(format!(
                            "Partition Range Scan on {table}  (partitions={selected}/{total}){}",
                            if analyze {
                                " (actual execution complete)"
                            } else {
                                ""
                            }
                        ))])],
                    });
                }
                self.database
                    .execute_statement_direct(Statement::Explain { analyze, statement }, params)
            }
            statement => self.database.execute_statement_direct(statement, params),
        }
    }
}

fn partition_may_match(
    part: &RangePartition,
    key: &str,
    filter: Option<&Expr>,
    params: &[Value],
) -> bool {
    let Some(filter) = filter else {
        return true;
    };
    match filter {
        Expr::Binary {
            left,
            op: BinaryOp::And,
            right,
        } => {
            partition_may_match(part, key, Some(left), params)
                && partition_may_match(part, key, Some(right), params)
        }
        Expr::Binary {
            left,
            op: BinaryOp::Or,
            right,
        } => {
            partition_may_match(part, key, Some(left), params)
                || partition_may_match(part, key, Some(right), params)
        }
        Expr::Binary { left, op, right } => {
            let column = |expr: &Expr| matches!(expr, Expr::Column(name) | Expr::QuotedColumn(name) if name.eq_ignore_ascii_case(key));
            let value = |expr: &Expr| match expr {
                Expr::Literal(value) => Some(value.clone()),
                Expr::Parameter(index) => params.get(index.saturating_sub(1)).cloned(),
                _ => None,
            };
            let (op, value) = if column(left) {
                (*op, value(right))
            } else if column(right) {
                let reversed = match op {
                    BinaryOp::Lt => BinaryOp::Gt,
                    BinaryOp::LtEq => BinaryOp::GtEq,
                    BinaryOp::Gt => BinaryOp::Lt,
                    BinaryOp::GtEq => BinaryOp::LtEq,
                    other => *other,
                };
                (reversed, value(left))
            } else {
                return true;
            };
            let Some(value) = value else {
                return true;
            };
            match op {
                BinaryOp::Eq => {
                    value
                        .canonical_cmp(&part.lower)
                        .is_some_and(|o| o != std::cmp::Ordering::Less)
                        && value.canonical_cmp(&part.upper) == Some(std::cmp::Ordering::Less)
                }
                BinaryOp::Lt => part.lower.canonical_cmp(&value) == Some(std::cmp::Ordering::Less),
                BinaryOp::LtEq => part
                    .lower
                    .canonical_cmp(&value)
                    .is_some_and(|o| o != std::cmp::Ordering::Greater),
                BinaryOp::Gt | BinaryOp::GtEq => {
                    part.upper.canonical_cmp(&value) == Some(std::cmp::Ordering::Greater)
                }
                BinaryOp::NotEq => true,
                _ => true,
            }
        }
        _ => true,
    }
}
fn read_statement(statement: &Statement) -> Result<(), PhobosError> {
    match statement {
        Statement::ShowCatalog { .. }
        | Statement::Select { .. }
        | Statement::RelationalSelect(_)
        | Statement::Union { .. } => Ok(()),
        Statement::Explain { statement, .. } => read_statement(statement),
        _ => Err(PhobosError::new(
            ErrorCode::TransactionState,
            "mutation requires session write admission",
        )),
    }
}

#[cfg(test)]
mod freeze_tests;

#[cfg(test)]
mod foreign_key_tests;
#[cfg(test)]
mod identity_tests;
#[cfg(test)]
mod modern_sql_tests;
#[cfg(test)]
mod schema_v2_tests;
