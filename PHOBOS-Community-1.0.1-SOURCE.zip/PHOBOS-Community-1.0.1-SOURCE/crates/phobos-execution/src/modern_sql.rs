//! Set-query binding and execution, sharing normal row operators and snapshots.
use super::*;
type Shape = Vec<(String, Option<DataType>)>;
type Input = Vec<(String, String, Option<DataType>)>;
fn mismatch(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TypeMismatch, message)
}
fn common(a: Option<DataType>, b: Option<DataType>) -> Result<Option<DataType>, PhobosError> {
    match (a, b) {
        (None, b) | (b, None) => Ok(b),
        (Some(a), Some(b)) if a == b => Ok(Some(a)),
        (Some(DataType::Int64), Some(DataType::Float64))
        | (Some(DataType::Float64), Some(DataType::Int64)) => Ok(Some(DataType::Float64)),
        (
            Some(DataType::Decimal {
                precision: a,
                scale: s,
            }),
            Some(DataType::Decimal {
                precision: b,
                scale: t,
            }),
        ) if s == t => Ok(Some(DataType::Decimal {
            precision: a.max(b),
            scale: s,
        })),
        _ => Err(mismatch("set-query columns have incompatible types")),
    }
}
fn value_type(v: &Value) -> Option<DataType> {
    Some(match v {
        Value::Null => return None,
        Value::Int64(_) => DataType::Int64,
        Value::Float64(_) => DataType::Float64,
        Value::Boolean(_) => DataType::Boolean,
        Value::Text(_) => DataType::Text,
        Value::Binary(_) => DataType::Binary,
        Value::Date(_) => DataType::Date,
        Value::Timestamp(_) => DataType::Timestamp,
        Value::Decimal { scale, .. } => DataType::Decimal {
            precision: 38,
            scale: *scale,
        },
    })
}
fn column_type(input: &Input, name: &str) -> Result<Option<DataType>, PhobosError> {
    let found: Vec<_> = input
        .iter()
        .filter(|(n, q, _)| {
            if name.contains('.') {
                q.eq_ignore_ascii_case(name)
            } else {
                n.eq_ignore_ascii_case(name)
            }
        })
        .collect();
    if found.len() != 1 {
        return Err(PhobosError::new(
            ErrorCode::Semantic,
            format!("unknown or ambiguous column {name}"),
        ));
    }
    Ok(found[0].2.clone())
}
impl Database {
    pub(super) fn query_types(
        &self,
        statement: &Statement,
        params: &[Value],
    ) -> Result<Vec<Option<DataType>>, PhobosError> {
        Ok(self
            .query_shape(statement, params)?
            .into_iter()
            .map(|(_, t)| t)
            .collect())
    }
    pub(super) fn query_shape(
        &self,
        statement: &Statement,
        params: &[Value],
    ) -> Result<Shape, PhobosError> {
        match statement {
            Statement::Select { table, columns, .. } => {
                let t = self.query_relation_schema(table)?;
                match columns {
                    SelectColumns::All => Ok(t
                        .columns
                        .iter()
                        .map(|c| (c.name.clone(), Some(c.data_type.clone())))
                        .collect()),
                    SelectColumns::Named(names) => names
                        .iter()
                        .map(|n| {
                            let i = t
                                .column_index(n)
                                .ok_or_else(|| mismatch("unknown set-query column"))?;
                            Ok((n.clone(), Some(t.columns[i].data_type.clone())))
                        })
                        .collect(),
                }
            }
            Statement::Union { left, right, .. } => {
                let left = self.query_shape(left, params)?;
                let right = self.query_shape(right, params)?;
                if left.len() != right.len() {
                    return Err(mismatch("UNION column count mismatch"));
                }
                left.into_iter()
                    .zip(right)
                    .map(|((n, a), (_, b))| Ok((n, common(a, b)?)))
                    .collect()
            }
            Statement::RelationalSelect(q) => {
                let mut input = Input::new();
                if let Some(source) = &q.source {
                    for (n, t) in self.query_shape(source, params)? {
                        input.push((
                            n.clone(),
                            format!("{}.{}", q.alias.as_deref().unwrap_or(&q.table), n),
                            t,
                        ));
                    }
                } else if !q.table.is_empty() {
                    let t = self.query_relation_schema(&q.table)?;
                    for c in t.columns {
                        input.push((
                            c.name.clone(),
                            format!("{}.{}", q.alias.as_deref().unwrap_or(&q.table), c.name),
                            Some(c.data_type),
                        ));
                    }
                }
                for j in &q.joins {
                    let t = self.query_relation_schema(&j.table)?;
                    for c in t.columns {
                        input.push((
                            c.name.clone(),
                            format!("{}.{}", j.alias.as_deref().unwrap_or(&j.table), c.name),
                            Some(c.data_type),
                        ));
                    }
                }
                let mut result = Vec::new();
                for item in &q.items {
                    let ty = match item {
                        SelectItem::All => {
                            result.extend(input.iter().map(|(n, _, t)| (n.clone(), t.clone())));
                            continue;
                        }
                        SelectItem::Column { name, .. } => column_type(&input, name)?,
                        SelectItem::Expression { expr, .. } => {
                            self.expression_type(expr, &input, params)?
                        }
                        SelectItem::Aggregate {
                            function, column, ..
                        } => match function {
                            AggregateFunction::Count => Some(DataType::Int64),
                            AggregateFunction::Avg => Some(DataType::Float64),
                            _ => column_type(
                                &input,
                                column
                                    .as_deref()
                                    .ok_or_else(|| mismatch("aggregate column required"))?,
                            )?,
                        },
                    };
                    result.push((select_item_name(item), ty));
                }
                Ok(result)
            }
            _ => Err(mismatch("read-only SELECT required")),
        }
    }
    fn expression_type(
        &self,
        e: &Expr,
        input: &Input,
        params: &[Value],
    ) -> Result<Option<DataType>, PhobosError> {
        match e {
            Expr::Literal(v) => Ok(value_type(v)),
            Expr::Parameter(i) => Ok(value_type(
                params
                    .get(*i)
                    .ok_or_else(|| mismatch("missing parameter"))?,
            )),
            Expr::Column(n) | Expr::QuotedColumn(n) => column_type(input, n),
            Expr::Unary {
                op: UnaryOp::Not, ..
            }
            | Expr::IsNull { .. }
            | Expr::Like { .. }
            | Expr::InList { .. }
            | Expr::Exists(_)
            | Expr::InSubquery { .. } => Ok(Some(DataType::Boolean)),
            Expr::Unary { expr, .. } => self.expression_type(expr, input, params),
            Expr::Binary { left, op, right } => match op {
                BinaryOp::Add | BinaryOp::Subtract | BinaryOp::Multiply | BinaryOp::Divide => {
                    common(
                        self.expression_type(left, input, params)?,
                        self.expression_type(right, input, params)?,
                    )
                }
                _ => Ok(Some(DataType::Boolean)),
            },
            Expr::Case {
                branches,
                else_expr,
            } => {
                let mut t = None;
                for (_, e) in branches {
                    t = common(t, self.expression_type(e, input, params)?)?;
                }
                if let Some(e) = else_expr {
                    t = common(t, self.expression_type(e, input, params)?)?;
                }
                Ok(t)
            }
            Expr::ScalarSubquery(q) => {
                let shape = self.query_shape(q, params)?;
                if shape.len() != 1 {
                    return Err(mismatch("scalar subquery needs one column"));
                }
                Ok(shape[0].1.clone())
            }
            Expr::Function { name, args } => match name.to_ascii_uppercase().as_str() {
                "CURRENT_TIMESTAMP" => Ok(Some(DataType::Timestamp)),
                "LOWER" | "UPPER" | "TRIM" | "LTRIM" | "RTRIM" | "REPLACE" | "SUBSTRING"
                | "SUBSTR" | "CONCAT" => Ok(Some(DataType::Text)),
                "LENGTH" | "CHAR_LENGTH" | "CHARACTER_LENGTH" | "OCTET_LENGTH" => {
                    Ok(Some(DataType::Int64))
                }
                "FLOOR" | "CEIL" | "CEILING" | "ROUND" | "ABS" | "NULLIF" => self.expression_type(
                    args.first()
                        .ok_or_else(|| mismatch("function argument required"))?,
                    input,
                    params,
                ),
                "COALESCE" => {
                    let mut t = None;
                    for e in args {
                        t = common(t, self.expression_type(e, input, params)?)?;
                    }
                    Ok(t)
                }
                _ => Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    format!("type binding unavailable for {name}"),
                )),
            },
        }
    }
    pub(super) fn union_select(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let shape = self.query_shape(&statement, params)?;
        let Statement::Union {
            left,
            right,
            all,
            order_by,
            limit,
            offset,
        } = statement
        else {
            unreachable!()
        };
        let QueryResult::Rows { mut rows, .. } = self.execute_subquery(*left, params)? else {
            return Err(mismatch("UNION requires rows"));
        };
        let QueryResult::Rows { rows: right, .. } = self.execute_subquery(*right, params)? else {
            return Err(mismatch("UNION requires rows"));
        };
        if rows.iter().chain(&right).map(row_bytes).sum::<usize>() > self.query_memory_bytes {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "UNION materialization exceeds query memory",
            ));
        }
        rows.extend(right);
        for row in &mut rows {
            phobos_error::cancellation::check_now()?;
            for (v, (_, ty)) in row.values.iter_mut().zip(&shape) {
                if let Some(t) = ty {
                    let c = ColumnSchema {
                        name: String::new(),
                        data_type: t.clone(),
                        nullable: true,
                    };
                    *v = coerce_value(&c, std::mem::replace(v, Value::Null))?;
                }
            }
        }
        if !all {
            rows = distinct_rows(rows, self.query_memory_bytes, &self.data_dir)?;
        }
        let names: Vec<_> = shape.into_iter().map(|(n, _)| n).collect();
        if !order_by.is_empty() {
            let r = Relation {
                names: names.clone(),
                qualified_names: names.clone(),
                rows: Vec::new(),
            };
            let order = bind_relation_order(&r, &order_by)?;
            rows = external_sort_rows(rows, &order, self.query_memory_bytes, &self.data_dir)?;
        }
        let offset = eval_count(offset.as_ref(), params, "OFFSET")?.unwrap_or(0);
        let limit = eval_count(limit.as_ref(), params, "LIMIT")?.unwrap_or(usize::MAX);
        Ok(QueryResult::Rows {
            columns: names,
            rows: rows.into_iter().skip(offset).take(limit).collect(),
        })
    }
}

struct LimitedRows {
    columns: Vec<String>,
    rows: Vec<Row>,
    bytes: usize,
    limit: usize,
}
impl ResultSink for LimitedRows {
    fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError> {
        self.columns = columns;
        Ok(())
    }
    fn row(&mut self, row: Row) -> Result<(), PhobosError> {
        self.bytes = self
            .bytes
            .checked_add(row_bytes(&row))
            .ok_or_else(|| mismatch("source size overflow"))?;
        if self.bytes > self.limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "INSERT SELECT source exceeds statement memory",
            ));
        }
        self.rows.push(row);
        Ok(())
    }
    fn finish(&mut self) -> Result<(), PhobosError> {
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
        Err(mismatch("SELECT source required"))
    }
}
impl Database {
    pub(super) fn collect_query_bounded(
        &mut self,
        query: Statement,
        params: &[Value],
        limit: usize,
    ) -> Result<Vec<Row>, PhobosError> {
        let mut sink = LimitedRows {
            columns: Vec::new(),
            rows: Vec::new(),
            bytes: 0,
            limit,
        };
        if matches!(
            query,
            Statement::Select { .. } | Statement::RelationalSelect(_)
        ) {
            self.execute_stream_parsed(query, "", params, &mut sink)?;
        } else {
            let QueryResult::Rows { columns, rows } = self.execute_subquery(query, params)? else {
                return Err(mismatch("SELECT source required"));
            };
            sink.start(columns)?;
            for row in rows {
                sink.row(row)?;
            }
        }
        Ok(sink.rows)
    }
}
pub(super) fn assignment_type(source: &DataType, target: &DataType) -> bool {
    source == target
        || matches!(
            (source, target),
            (
                DataType::Int64,
                DataType::Float64 | DataType::Timestamp | DataType::Decimal { .. }
            ) | (DataType::Float64, DataType::Decimal { .. })
                | (
                    DataType::Text,
                    DataType::Binary
                        | DataType::Date
                        | DataType::Timestamp
                        | DataType::Decimal { .. }
                )
                | (DataType::Decimal { .. }, DataType::Decimal { .. })
        )
}
