//! Views expand into ordinary read-only derived queries within the same catalog generation.
use super::*;
impl Database {
    pub(super) fn query_relation_schema(&self, name: &str) -> Result<TableSchema, PhobosError> {
        if let Some(v) = self.catalog.view(name) {
            return Ok(TableSchema {
                id: v.id,
                name: v.name.clone(),
                columns: v.columns.clone(),
            });
        }
        self.table_schema(name)
    }
    pub(super) fn expand_views(&self, statement: Statement) -> Result<Statement, PhobosError> {
        match statement {
            Statement::Explain { analyze, statement } => Ok(Statement::Explain {
                analyze,
                statement: Box::new(self.expand_views(*statement)?),
            }),
            Statement::Select {
                table,
                columns,
                filter,
                order_by,
                limit,
                offset,
            } if self.catalog.view(&table).is_some() => {
                let v = self.catalog.view(&table).expect("view");
                let items = match columns {
                    SelectColumns::All => vec![SelectItem::All],
                    SelectColumns::Named(names) => names
                        .into_iter()
                        .map(|name| SelectItem::Column { name, alias: None })
                        .collect(),
                };
                Ok(Statement::RelationalSelect(RelationalSelect {
                    source: Some(Box::new(parse(&v.sql)?)),
                    table,
                    alias: None,
                    items,
                    distinct: false,
                    joins: Vec::new(),
                    filter,
                    group_by: Vec::new(),
                    having: None,
                    order_by,
                    limit,
                    offset,
                }))
            }
            Statement::RelationalSelect(mut q) => {
                if q.joins
                    .iter()
                    .any(|j| self.catalog.view(&j.table).is_some())
                {
                    return Err(PhobosError::new(
                        ErrorCode::Unsupported,
                        "views as JOIN inputs are not supported; define the join inside the view",
                    ));
                }
                if q.source.is_none() {
                    if let Some(v) = self.catalog.view(&q.table) {
                        if !q.joins.is_empty() {
                            return Err(PhobosError::new(
                                ErrorCode::Unsupported,
                                "joins over view inputs are not supported; define the join inside the view",
                            ));
                        }
                        q.source = Some(Box::new(parse(&v.sql)?));
                    }
                }
                Ok(Statement::RelationalSelect(q))
            }
            other => Ok(other),
        }
    }
}
