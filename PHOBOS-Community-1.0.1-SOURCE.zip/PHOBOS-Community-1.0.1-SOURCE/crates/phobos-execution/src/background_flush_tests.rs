use super::*;
use phobos_storage::committed_pages::FlushConfig;
use phobos_wal::v2::FileId;
use std::{
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc,
    },
    time::Duration,
};

fn directory() -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    std::env::temp_dir().join(format!(
        "phobos-c3-engine-{}-{}-{}",
        std::process::id(),
        unique_spill_suffix(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ))
}
fn config() -> FlushConfig {
    FlushConfig {
        wake_interval: Duration::from_secs(3600),
        ..Default::default()
    }
}
fn setup(dir: &Path) {
    let mut db = Database::open_v2_with_flush_config(dir, config()).unwrap();
    db.execute("CREATE TABLE t (id BIGINT NOT NULL, v TEXT)")
        .unwrap();
    db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
    db.shutdown().unwrap();
}
fn count(db: &mut Database) -> i64 {
    let QueryResult::Rows { rows, .. } = db.execute("SELECT COUNT(*) FROM t").unwrap() else {
        panic!("count rows")
    };
    let Value::Int64(count) = rows[0].values[0] else {
        panic!("integer count")
    };
    count
}
#[test]
fn acknowledged_images_are_buffered_rollback_safe_and_shutdown_drains() {
    let dir = directory();
    setup(&dir);
    let heap = dir.join(FileId::Heap(1).name());
    let index = dir.join(FileId::Index(1).name());
    let before = [fs::read(&heap).unwrap(), fs::read(&index).unwrap()];
    let mut db = Database::open_v2_with_flush_config(&dir, config()).unwrap();
    db.execute("INSERT INTO t VALUES (1,'acknowledged')")
        .unwrap();
    assert_eq!(
        [fs::read(&heap).unwrap(), fs::read(&index).unwrap()],
        before
    );
    assert!(db.flush_stats().unwrap().dirty_pages >= 2);
    db.execute("BEGIN").unwrap();
    db.execute("UPDATE t SET id=2 WHERE id=1").unwrap();
    db.execute("ROLLBACK").unwrap();
    assert!(db.execute("INSERT INTO t VALUES (1,'duplicate')").is_err());
    assert_eq!(count(&mut db), 1);
    for tree in db.indexes.values_mut() {
        tree.validate().unwrap();
    }
    db.shutdown().unwrap();
    assert_ne!(fs::read(&heap).unwrap(), before[0]);
    assert_eq!(
        phobos_wal::v2::inspect(dir.join("phobos.wal"))
            .unwrap()
            .committed_transactions,
        0
    );
    drop(db);
    let mut db = Database::open(&dir).unwrap();
    assert_eq!(count(&mut db), 1);
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn bounded_eviction_preserves_large_commit_and_retain_shutdown_recovers() {
    let dir = directory();
    setup(&dir);
    let mut limits = config();
    limits.page_cache_bytes = 2 * 8192;
    limits.batch_pages = 1;
    limits.drain_on_shutdown = false;
    let mut db = Database::open_v2_with_flush_config(&dir, limits).unwrap();
    let rows = (0..150)
        .map(|id| format!("({id},'{}')", "x".repeat(1000)))
        .collect::<Vec<_>>()
        .join(",");
    db.execute(&format!("INSERT INTO t VALUES {rows}")).unwrap();
    let stats = db.flush_stats().unwrap();
    assert!(stats.peak_dirty_pages <= 2);
    assert!(stats.pages_flushed > 0);
    assert!(stats.maximum_page_lsn <= stats.durable_wal_lsn);
    assert_eq!(count(&mut db), 150);
    db.shutdown().unwrap();
    assert!(
        phobos_wal::v2::inspect(dir.join("phobos.wal"))
            .unwrap()
            .committed_transactions
            > 0
    );
    drop(db);
    for _ in 0..2 {
        let mut db = Database::open(&dir).unwrap();
        assert_eq!(count(&mut db), 150);
        for tree in db.indexes.values_mut() {
            tree.validate().unwrap();
        }
    }
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn c3_crash_boundaries_recover_acknowledged_heap_and_index() {
    const NAME: &str =
        "background_flush_tests::c3_crash_boundaries_recover_acknowledged_heap_and_index";
    if let Ok(dir) = std::env::var("PHOBOS_C3_CHILD") {
        let dir = PathBuf::from(dir);
        let point = std::env::var("PHOBOS_C3_POINT").unwrap();
        let mut limits = config();
        if point == "eviction_flush_after_write" {
            limits.page_cache_bytes = 3 * 8192;
            limits.batch_pages = 1;
        }
        let mut db = Database::open_v2_with_flush_config(&dir, limits).unwrap();
        let armed = Arc::new(AtomicBool::new(false));
        let hook_armed = Arc::clone(&armed);
        let hook_point = point.clone();
        let hit = dir.join("c3-hit.txt");
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |at| {
                if hook_point == "eviction_flush_after_write" && at == "background_batch_start" {
                    // Freeze only the worker, before it pins any file. Pressure
                    // must be serviced by synchronous eligible-page eviction.
                    let (_sender, receiver) = mpsc::channel::<()>();
                    let _ = receiver.recv_timeout(Duration::from_secs(10));
                    panic!("eviction crash did not complete");
                }
                if at == hook_point && hook_armed.load(Ordering::Acquire) {
                    fs::write(&hit, at).unwrap();
                    OpenOptions::new()
                        .write(true)
                        .open(&hit)
                        .unwrap()
                        .sync_all()
                        .unwrap();
                    std::process::exit(86);
                }
            }),
        );
        db.execute("INSERT INTO t VALUES (1,'acknowledged')")
            .unwrap();
        assert!(db.flush_stats().unwrap().dirty_pages >= 2);
        let ack = dir.join("c3-ack.txt");
        fs::write(&ack, "1").unwrap();
        OpenOptions::new()
            .write(true)
            .open(&ack)
            .unwrap()
            .sync_all()
            .unwrap();
        armed.store(true, Ordering::Release);
        match point.as_str() {
            "after_ack_before_flush" => {
                assert_eq!(
                    fs::metadata(dir.join(FileId::Heap(1).name()))
                        .unwrap()
                        .len(),
                    0
                );
                fs::write(dir.join("c3-hit.txt"), &point).unwrap();
                std::process::exit(86);
            }
            "background_flush_after_write" => {
                db.committed_store
                    .as_ref()
                    .unwrap()
                    .request_flush()
                    .unwrap();
                let (_sender, receiver) = mpsc::channel::<()>();
                let _ = receiver.recv_timeout(Duration::from_secs(10));
                panic!("background crash boundary not reached");
            }
            "eviction_flush_after_write" => {
                let rows = (2..152)
                    .map(|id| format!("({id},'{}')", "x".repeat(1000)))
                    .collect::<Vec<_>>()
                    .join(",");
                db.execute(&format!("INSERT INTO t VALUES {rows}")).unwrap();
            }
            "checkpoint_drain_after_write" => {
                db.execute("CHECKPOINT").unwrap();
            }
            _ => panic!("unknown crash point"),
        }
        panic!("crash hook missing");
    }
    // Four C3 cases + unchanged 40 C1/C2 campaign cycles + six Fast-suite
    // recovery cases = 50 targeted cycles; no inherited test is skipped.
    for point in [
        "after_ack_before_flush",
        "background_flush_after_write",
        "eviction_flush_after_write",
        "checkpoint_drain_after_write",
    ] {
        let dir = directory();
        setup(&dir);
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", NAME, "--nocapture"])
            .env("PHOBOS_C3_CHILD", &dir)
            .env("PHOBOS_C3_POINT", point)
            .output()
            .unwrap();
        assert_eq!(
            output.status.code(),
            Some(86),
            "{point}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert_eq!(fs::read_to_string(dir.join("c3-ack.txt")).unwrap(), "1");
        assert_eq!(fs::read_to_string(dir.join("c3-hit.txt")).unwrap(), point);
        for _ in 0..2 {
            let mut db = Database::open(&dir).unwrap();
            assert_eq!(
                count(&mut db),
                if point == "eviction_flush_after_write" {
                    151
                } else {
                    1
                }
            );
            let QueryResult::Rows { rows, .. } = db.execute("SELECT v FROM t WHERE id=1").unwrap()
            else {
                panic!("rows")
            };
            assert_eq!(
                rows,
                vec![Row::new(vec![Value::Text("acknowledged".into())])]
            );
            for tree in db.indexes.values_mut() {
                tree.validate().unwrap();
            }
        }
        fs::remove_dir_all(dir).unwrap();
    }
}

#[test]
fn c4_incremental_checkpoint_crash_campaign() {
    const NAME: &str = "background_flush_tests::c4_incremental_checkpoint_crash_campaign";
    if let Ok(dir) = std::env::var("PHOBOS_C4_CHILD") {
        let dir = PathBuf::from(dir);
        let point = std::env::var("PHOBOS_C4_POINT").unwrap();
        let mut db = Database::open_v2_with_flush_config(&dir, config()).unwrap();
        db.execute("INSERT INTO t VALUES (1,'acknowledged')")
            .unwrap();
        assert!(db.flush_stats().unwrap().dirty_pages >= 2);
        fs::write(dir.join("c4-ack.txt"), "1").unwrap();
        OpenOptions::new()
            .write(true)
            .open(dir.join("c4-ack.txt"))
            .unwrap()
            .sync_all()
            .unwrap();
        let hit = dir.join("c4-hit.txt");
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |at| {
                if at == point {
                    fs::write(&hit, at).unwrap();
                    OpenOptions::new()
                        .write(true)
                        .open(&hit)
                        .unwrap()
                        .sync_all()
                        .unwrap();
                    std::process::exit(86);
                }
            }),
        );
        let target = db.wal_v2.as_ref().unwrap().last_commit_lsn();
        db.committed_store
            .as_ref()
            .unwrap()
            .request_checkpoint(target)
            .unwrap();
        let deadline = std::time::Instant::now() + Duration::from_secs(10);
        loop {
            db.committed_store
                .as_ref()
                .unwrap()
                .request_flush()
                .unwrap();
            db.advance_checkpoint().unwrap();
            assert!(
                std::time::Instant::now() < deadline,
                "C4 crash hook missing"
            );
            std::thread::yield_now();
        }
    }
    // 24 new C4 cycles. Inherited C1/C2/C3 and Fast-suite regressions remain
    // enabled and are reported separately from the C4 development campaign.
    for _ in 0..6 {
        for point in [
            "c4_before_target_flush",
            "c4_after_target_flush",
            "c4_checkpoint_prepared",
            "c4_checkpoint_replaced",
        ] {
            let dir = directory();
            setup(&dir);
            let output = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--exact", NAME, "--nocapture"])
                .env("PHOBOS_C4_CHILD", &dir)
                .env("PHOBOS_C4_POINT", point)
                .output()
                .unwrap();
            assert_eq!(
                output.status.code(),
                Some(86),
                "{point}: {} {}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            assert_eq!(fs::read_to_string(dir.join("c4-ack.txt")).unwrap(), "1");
            assert_eq!(fs::read_to_string(dir.join("c4-hit.txt")).unwrap(), point);
            for _ in 0..2 {
                let mut db = Database::open(&dir).unwrap();
                assert_eq!(count(&mut db), 1);
                let QueryResult::Rows { rows, .. } =
                    db.execute("SELECT v FROM t WHERE id=1").unwrap()
                else {
                    panic!("rows")
                };
                assert_eq!(
                    rows,
                    vec![Row::new(vec![Value::Text("acknowledged".into())])]
                );
                assert!(db.execute("INSERT INTO t VALUES (1,'duplicate')").is_err());
                for tree in db.indexes.values_mut() {
                    tree.validate().unwrap();
                }
            }
            fs::remove_dir_all(dir).unwrap();
        }
    }
}
