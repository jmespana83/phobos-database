//! Private-page transactions for fresh and explicitly migrated V2 databases.
//! Legacy databases retain their original transaction path until migration.
use super::*;
use phobos_wal::v2::{Body, FileId, PageAction, Wal as WalV2};
use std::io::{Seek, SeekFrom};

impl Database {
    pub fn flush_stats(&self) -> Result<phobos_storage::committed_pages::FlushStats, PhobosError> {
        self.committed_store
            .as_ref()
            .map_or(Ok(Default::default()), |store| store.stats())
    }

    /// Fallible shutdown. Drain mode preserves the existing checkpoint barrier;
    /// retain mode stops writes and leaves the durable WAL for the next recovery.
    pub fn shutdown(&mut self) -> Result<(), PhobosError> {
        self.ensure_available()?;
        if self.in_transaction() {
            return Err(state("shutdown requires transaction drain"));
        }
        if self
            .committed_store
            .as_ref()
            .is_none_or(|store| store.config().drain_on_shutdown)
        {
            self.execute("CHECKPOINT")?;
        }
        self.fenced = true;
        if let Some(store) = &self.committed_store {
            store.stop()?;
        }
        Ok(())
    }
    /// Open a V2 database, or create one in a fresh directory. Existing legacy
    /// directories require explicit offline migration; this never infers it.
    pub fn open_v2(data_dir: impl AsRef<Path>) -> Result<Self, PhobosError> {
        Self::open_v2_with_buffer_pages(data_dir, DEFAULT_BUFFER_PAGES)
    }
    pub(super) fn open_v2_with_buffer_pages(
        data_dir: impl AsRef<Path>,
        buffer_pages: usize,
    ) -> Result<Self, PhobosError> {
        Self::open_v2_config(
            data_dir,
            buffer_pages,
            phobos_storage::committed_pages::FlushConfig::from_env()?,
        )
    }
    pub fn open_v2_with_flush_config(
        data_dir: impl AsRef<Path>,
        config: phobos_storage::committed_pages::FlushConfig,
    ) -> Result<Self, PhobosError> {
        Self::open_v2_config(data_dir, DEFAULT_BUFFER_PAGES, config)
    }
    pub(super) fn open_v2_config(
        data_dir: impl AsRef<Path>,
        buffer_pages: usize,
        config: phobos_storage::committed_pages::FlushConfig,
    ) -> Result<Self, PhobosError> {
        if buffer_pages == 0 {
            return Err(state("buffer pool size must be non-zero"));
        }
        let path = data_dir.as_ref();
        // 0.2-I.3: an interrupted rotation has V2 history but no complete
        // active WAL; it must recover (repair), never create a fresh WAL.
        let has_wal =
            path.join("phobos.wal").exists() || phobos_wal::v2::interrupted_rotation(path)?;
        if has_wal && phobos_wal::v2::inspect(path.join("phobos.wal"))?.page_format >= 3 {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "MVCC SQL integration is not enabled",
            ));
        }
        let wal = if has_wal {
            WalV2::recover(path)?
        } else {
            WalV2::create_with_page_lsn(path)?
        };
        let data_dir = fs::canonicalize(path)?;
        cleanup_transaction_dirs(&data_dir)?;
        cleanup_spill_dirs(&data_dir)?;
        let catalog = Catalog::open(&data_dir)?;
        let heaps = open_heaps(&data_dir, &catalog, buffer_pages)?;
        let indexes = open_indexes(&data_dir, &catalog)?;
        let stats = load_statistics(&data_dir)?;
        let txn_manager = TransactionManager::open(&data_dir)?;
        let committed_store = if wal.page_format() == 2 {
            Some(phobos_storage::committed_pages::CommittedStore::new(
                &data_dir, config,
            )?)
        } else {
            None
        };
        let mut database = Self {
            mvcc_view: false,
            data_dir,
            catalog,
            heaps,
            indexes,
            stats,
            txn_manager: Some(txn_manager),
            buffer_pages,
            query_memory_bytes: DEFAULT_QUERY_MEMORY_BYTES,
            last_access_path: None,
            last_plan: None,
            wal: None,
            wal_v2: Some(wal),
            committed_store,
            private_txn: None,
            fenced: false,
            active_txn: None,
            private_staging: false,
        };
        database.validate_canonical_unique()?;
        Ok(database)
    }

    pub(super) fn ensure_available(&self) -> Result<(), PhobosError> {
        if let Some(store) = &self.committed_store {
            store.check()?;
        }
        if self.fenced {
            Err(state(
                "database fenced after I/O failure; close and recover",
            ))
        } else {
            Ok(())
        }
    }
    pub(super) fn private_directory(&self) -> &Path {
        self.private_txn
            .as_ref()
            .map_or(&self.data_dir, |tx| &tx.temp_dir)
    }
    pub(super) fn execute_private_statement(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        if self.private_txn.as_ref().is_some_and(|tx| tx.failed) {
            return Err(state(
                "current transaction is aborted; ROLLBACK is required",
            ));
        }
        let read_only = matches!(
            &statement,
            Statement::Select { .. } | Statement::RelationalSelect(_) | Statement::Explain { .. }
        );
        let result = self.execute_statement_direct(statement, params);
        if result
            .as_ref()
            .is_err_and(|error| !(read_only && phobos_error::cancellation::is_interrupted(error)))
        {
            self.private_txn
                .as_mut()
                .expect("active private transaction")
                .failed = true;
        }
        result
    }
    pub(super) fn begin_private_transaction(&mut self) -> Result<QueryResult, PhobosError> {
        let _profile = phobos_observability::span("execution.begin_transaction");
        if self.in_transaction() {
            return Err(state("a transaction is already active"));
        }
        let id = match self.wal_v2.as_mut().expect("V2 WAL").begin() {
            Ok(id) => id,
            Err(error) => {
                self.fenced = self.wal_v2.as_ref().expect("V2 WAL").is_fenced();
                return Err(error);
            }
        };
        self.begin_private_with_id(id)
    }

    pub(super) fn begin_private_with_id(&mut self, id: u64) -> Result<QueryResult, PhobosError> {
        let temp_dir = transaction_dir(&self.data_dir, id);
        let result = (|| {
            fs::create_dir(&temp_dir)?;
            self.private_txn = Some(PrivateTransaction {
                id,
                temp_dir: temp_dir.clone(),
                dropped_indexes: BTreeMap::new(),
                failed: false,
            });
            for (table, heap) in &mut self.heaps {
                if let Some(store) = &self.committed_store {
                    heap.attach_committed(store, FileId::Heap(*table))?;
                }
                heap.begin_private(
                    &temp_dir.join(format!("heap-{table}.private")),
                    id,
                    &self.data_dir,
                )?;
            }
            for (index, tree) in &mut self.indexes {
                if let Some(store) = &self.committed_store {
                    tree.attach_committed(store, FileId::Index(*index))?;
                }
                tree.begin_private(
                    &temp_dir.join(format!("index-{index}.private")),
                    id,
                    &self.data_dir,
                )?;
            }
            self.catalog.redirect_persistence(&temp_dir)?;
            Ok(command("BEGIN"))
        })();
        if result.is_err() {
            self.fenced = true;
        }
        result
    }
    pub(super) fn execute_private_autocommit(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        self.begin_private_transaction()?;
        match self.execute_private_statement(statement, params) {
            Ok(result) => match self.commit_private_transaction() {
                Ok(_) => Ok(result),
                Err(error) => {
                    if !self.fenced {
                        self.rollback_private_transaction()?;
                    }
                    Err(error)
                }
            },
            Err(error) => {
                self.rollback_private_transaction()?;
                Err(error)
            }
        }
    }
    pub(super) fn rollback_private_transaction(&mut self) -> Result<QueryResult, PhobosError> {
        self.ensure_available()?;
        let tx = self
            .private_txn
            .take()
            .ok_or_else(|| state("ROLLBACK without an active transaction"))?;
        let result = (|| {
            let catalog = Catalog::open(&self.data_dir)?;
            let tables: HashSet<_> = catalog.tables().map(|schema| schema.id).collect();
            let indexes: HashSet<_> = catalog.indexes().map(|schema| schema.id).collect();
            self.heaps.retain(|id, _| tables.contains(id));
            self.indexes.extend(tx.dropped_indexes);
            self.indexes.retain(|id, _| indexes.contains(id));
            for heap in self.heaps.values_mut() {
                heap.rollback_private()?;
            }
            for tree in self.indexes.values_mut() {
                tree.rollback_private()?;
            }
            self.catalog = catalog;
            self.stats = load_statistics(&self.data_dir)?;
            self.wal_v2.as_mut().expect("V2 WAL").abort()?;
            fs::remove_dir_all(&tx.temp_dir)?;
            Ok(command("ROLLBACK"))
        })();
        if result.is_err() {
            self.fenced = true;
        }
        result
    }

    pub(super) fn commit_private_transaction(&mut self) -> Result<QueryResult, PhobosError> {
        phobos_error::cancellation::commit()?;
        let _durability = phobos_error::cancellation::suspend();
        let _profile = phobos_observability::span("execution.commit_transaction");
        let tx = self
            .private_txn
            .as_ref()
            .ok_or_else(|| state("COMMIT without an active transaction"))?;
        if tx.failed {
            return Err(state(
                "cannot COMMIT an aborted transaction; ROLLBACK is required",
            ));
        }
        let root = tx.temp_dir.clone();
        let new_heaps: Vec<_> = self
            .heaps
            .iter()
            .filter(|(_, h)| h.path().parent() == Some(root.as_path()))
            .map(|(id, _)| *id)
            .collect();
        let new_indexes: Vec<_> = self
            .indexes
            .iter()
            .filter(|(_, h)| h.path().parent() == Some(root.as_path()))
            .map(|(id, _)| *id)
            .collect();
        let lifecycle = !new_heaps.is_empty()
            || !new_indexes.is_empty()
            || !tx.dropped_indexes.is_empty()
            || [FileId::Tables, FileId::Indexes, FileId::Statistics]
                .into_iter()
                .any(|file| root.join(file.name()).exists());
        let prepared = (|| {
            let wal = self.wal_v2.as_mut().expect("V2 WAL");
            for (id, heap) in &mut self.heaps {
                if new_heaps.contains(id) {
                    log_new_base(wal, FileId::Heap(*id), heap.path())?;
                }
                heap.prepare_private_redo_based(
                    FileId::Heap(*id),
                    |page, bytes, base, allocated, phase| {
                        let action = if allocated {
                            PageAction::Initialize
                        } else {
                            PageAction::HeapUpdate
                        };
                        match phase {
                            phobos_storage::page_io::RedoPhase::Stamp => {
                                wal.stamp_next_page(FileId::Heap(*id), page, bytes)?;
                            }
                            phobos_storage::page_io::RedoPhase::Append => {
                                wal.append_prepared_page_with_base(
                                    action,
                                    FileId::Heap(*id),
                                    page,
                                    bytes,
                                    base,
                                )?;
                            }
                        }
                        Ok(())
                    },
                )?;
            }
            for (id, tree) in &mut self.indexes {
                if new_indexes.contains(id) {
                    log_new_base(wal, FileId::Index(*id), tree.path())?;
                }
                tree.prepare_private_redo_based(
                    FileId::Index(*id),
                    |page, bytes, base, allocated, phase| {
                        let action = if allocated {
                            PageAction::Initialize
                        } else {
                            PageAction::Index
                        };
                        match phase {
                            phobos_storage::page_io::RedoPhase::Stamp => {
                                wal.stamp_next_page(FileId::Index(*id), page, bytes)?;
                            }
                            phobos_storage::page_io::RedoPhase::Append => {
                                wal.append_prepared_page_with_base(
                                    action,
                                    FileId::Index(*id),
                                    page,
                                    bytes,
                                    base,
                                )?;
                            }
                        }
                        Ok(())
                    },
                )?;
            }
            for id in self
                .private_txn
                .as_ref()
                .expect("active private transaction")
                .dropped_indexes
                .keys()
            {
                wal.append(Body::Delete(FileId::Index(*id)))?;
            }
            for file in [FileId::Tables, FileId::Indexes, FileId::Statistics] {
                if root.join(file.name()).exists() {
                    log_metadata(wal, file, &root.join(file.name()))?;
                }
            }
            wal.commit()
        })();
        let receipt = match prepared {
            Ok(receipt) => receipt,
            Err(error) => {
                self.private_txn
                    .as_mut()
                    .expect("active private transaction")
                    .failed = true;
                if self.wal_v2.as_ref().expect("V2 WAL").is_fenced() {
                    self.fenced = true;
                }
                return Err(error);
            }
        };
        if std::env::var("PHOBOS_CRASH_POINT").as_deref() == Ok("after_wal_commit") {
            std::process::abort();
        }
        let tx = self
            .private_txn
            .take()
            .expect("durable private transaction");
        self.fenced = true;
        phobos_observability::certification_crash("before_installation");
        let publication = phobos_observability::span("execution.synchronous_publication");
        // Keep owner admission fenced until every page/metadata/lifecycle effect
        // is forced. A post-COMMIT error must recover, never roll back.
        for heap in self.heaps.values_mut() {
            heap.install_private(&receipt)?;
        }
        for tree in self.indexes.values_mut() {
            tree.install_private(&receipt)?;
        }
        // PERF3: a data-directory force publishes directory entries. Track
        // whether this commit actually changed one; an ordinary DML commit
        // installs pages into existing files and renames nothing.
        let mut directory_changed = false;
        for (id, tree) in tx.dropped_indexes {
            directory_changed = true;
            drop(tree);
            fs::rename(
                index_path(&self.data_dir, id),
                self.data_dir
                    .join(format!(".phobos-retired-{}", FileId::Index(id).name())),
            )?;
        }
        for id in new_heaps {
            directory_changed = true;
            let heap = self.heaps.remove(&id).expect("new heap");
            let schema = heap.schema().clone();
            let old = heap.path().to_path_buf();
            drop(heap);
            let path = heap_path(&self.data_dir, id);
            fs::rename(old, &path)?;
            self.heaps
                .insert(id, HeapTable::open(path, schema, self.buffer_pages)?);
        }
        for id in new_indexes {
            directory_changed = true;
            let tree = self.indexes.remove(&id).expect("new index");
            let old = tree.path().to_path_buf();
            drop(tree);
            let schema = self
                .catalog
                .indexes()
                .find(|schema| schema.id == id)
                .expect("new index catalog");
            let path = index_path(&self.data_dir, id);
            fs::rename(old, &path)?;
            self.indexes.insert(
                id,
                BPlusTree::open(path, schema.unique, schema.columns.len())?,
            );
        }
        for file in [FileId::Tables, FileId::Indexes, FileId::Statistics] {
            let path = root.join(file.name());
            if path.exists() {
                let file_handle = OpenOptions::new().write(true).open(&path)?;
                phobos_observability::measure("commit.metadata_force", || file_handle.sync_all())?;
                drop(file_handle);
                phobos_observability::event("commit.metadata_publications", 1);
                fs::rename(path, self.data_dir.join(file.name()))?;
                directory_changed = true;
            }
        }
        // PERF3: force the data directory only when this commit published a
        // directory entry (catalog/statistics republication, a new heap or
        // index, a dropped index, or any lifecycle statement). A DML commit
        // installs pages into files that already exist, so its durable
        // contract contains no directory-entry change; the private scratch
        // directory it creates and removes is not durable state, and startup
        // housekeeping sweeps a remnant after a crash. The WAL force before
        // this point is unchanged, and so is every page installation.
        if directory_changed || lifecycle {
            phobos_observability::measure("commit.directory_force", || {
                sync_directory(&self.data_dir)
            })?;
        } else {
            phobos_observability::event("commit.directory_force_skipped", 1);
        }
        self.catalog.redirect_persistence(&self.data_dir)?;
        drop(publication);
        // Lifecycle and legacy-page commits retain the complete barrier.
        // Page-LSN DML requests incremental background checkpoint work.
        let wal = self.wal_v2.as_ref().expect("V2 WAL");
        if wal.page_format() == 1 || lifecycle {
            self.force_private_pages()?;
            self.wal_v2
                .as_mut()
                .expect("V2 WAL")
                .checkpoint_all(receipt.lsn())?;
            phobos_observability::certification_crash("during_checkpoint");
        }
        fs::remove_dir_all(root)?;
        if !lifecycle {
            self.advance_checkpoint()?;
        }
        self.fenced = false;
        Ok(command("COMMIT"))
    }
    pub(super) fn checkpoint_private(&mut self) -> Result<QueryResult, PhobosError> {
        phobos_error::cancellation::commit()?;
        let _durability = phobos_error::cancellation::suspend();
        if self.in_transaction() {
            return Err(state("CHECKPOINT is not allowed inside a transaction"));
        }
        self.fenced = true;
        self.force_private_pages()?;
        let wal = self.wal_v2.as_mut().expect("V2 WAL");
        let applied = wal.last_commit_lsn();
        wal.checkpoint_all(applied)?;
        phobos_observability::certification_crash("during_checkpoint");
        self.fenced = false;
        Ok(command("CHECKPOINT"))
    }
    /// Ordinary publication only requests/polls bounded background work.
    pub(super) fn advance_checkpoint(&mut self) -> Result<(), PhobosError> {
        let Some(store) = self.committed_store.as_ref() else {
            if self.wal_v2.as_ref().is_some_and(|wal| wal.checkpoint_due()) {
                self.force_private_pages()?;
                let wal = self.wal_v2.as_mut().expect("V2 WAL");
                wal.checkpoint_all(wal.last_commit_lsn())?;
            }
            return Ok(());
        };
        let wal = self.wal_v2.as_mut().expect("V2 WAL");
        wal.poll_checkpoint()?;
        if !wal.checkpoint_pending() {
            if let Some((_target, safe)) = store.take_checkpoint()? {
                wal.request_checkpoint(safe)?;
            } else if wal.checkpoint_due() {
                store.request_checkpoint(wal.last_commit_lsn())?;
            }
        }
        Ok(())
    }
    pub(super) fn force_private_pages(&mut self) -> Result<(), PhobosError> {
        if let Some(store) = &self.committed_store {
            store.cancel_checkpoint()?;
        }

        for heap in self.heaps.values_mut() {
            heap.force_committed()?;
        }
        for tree in self.indexes.values_mut() {
            tree.force_committed()?;
        }
        sync_directory(&self.data_dir)
    }
}

fn log_new_base(wal: &mut WalV2, file: FileId, path: &Path) -> Result<(), PhobosError> {
    wal.append(Body::Create(file))?;
    // This function handles only new files owned by the transaction directory.
    let mut input = OpenOptions::new().read(true).write(true).open(path)?;
    let len = input.metadata()?.len();
    if len % 8192 != 0 {
        return Err(state("new paged file is not aligned"));
    }
    for page in 0..len / 8192 {
        let mut image = Box::new([0; 8192]);
        input.read_exact(image.as_mut())?;
        wal.append_page(PageAction::Initialize, file, page, &mut image)?;
        if wal.page_format() == 2 {
            input.seek(SeekFrom::Start(page * 8192))?;
            input.write_all(image.as_ref())?;
        }
    }
    Ok(())
}
fn log_metadata(wal: &mut WalV2, file: FileId, path: &Path) -> Result<(), PhobosError> {
    let mut input = File::open(path)?;
    let total_len = input.metadata()?.len();
    let mut offset = 0;
    loop {
        let mut bytes = vec![0; (total_len - offset).min(32768) as usize];
        input.read_exact(&mut bytes)?;
        let count = bytes.len() as u64;
        wal.append(Body::Metadata {
            file,
            offset,
            total_len,
            bytes,
        })?;
        offset += count;
        if offset == total_len {
            break;
        }
    }
    Ok(())
}
fn command(tag: &str) -> QueryResult {
    QueryResult::Command {
        tag: tag.into(),
        rows_affected: 0,
    }
}
fn state(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TransactionState, message)
}
fn sync_directory(directory: &Path) -> Result<(), PhobosError> {
    #[cfg(unix)]
    File::open(directory)?.sync_all()?;
    #[cfg(not(unix))]
    let _ = directory;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn directory() -> PathBuf {
        std::env::temp_dir().join(format!("phobos-v2-engine-{}", unique_spill_suffix()))
    }
    fn rows(db: &mut Database) -> QueryResult {
        db.execute("SELECT id,v FROM t ORDER BY id").unwrap()
    }
    fn setup(path: &Path) {
        let mut db = Database::open_v2(path).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
            .unwrap();
        db.execute("INSERT INTO t VALUES (1,10),(2,20)").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        db.execute("ANALYZE t").unwrap();
    }
    #[test]
    fn private_engine_page_lsn_checkpoint_retention_and_rollback() {
        let dir = directory();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        for id in 0..70 {
            db.execute(&format!("INSERT INTO t VALUES ({id})")).unwrap();
            if id == 63 {
                // C4 requests at the same threshold, but completion is now
                // asynchronous. Drive the idle coordinator to completion;
                // retain all original retirement/page-LSN/recovery assertions.
                let deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
                loop {
                    db.committed_store
                        .as_ref()
                        .unwrap()
                        .request_flush()
                        .unwrap();
                    db.advance_checkpoint().unwrap();
                    if phobos_wal::v2::inspect(dir.join("phobos.wal"))
                        .unwrap()
                        .committed_transactions
                        == 0
                    {
                        break;
                    }
                    assert!(std::time::Instant::now() < deadline);
                    std::thread::yield_now();
                }
            }
            if matches!(id, 62 | 63 | 69) {
                let report = phobos_wal::v2::inspect(dir.join("phobos.wal")).unwrap();
                assert_eq!(report.page_format, 2);
                assert_eq!(
                    report.committed_transactions,
                    match id {
                        62 => 63,
                        63 => 0,
                        _ => 6,
                    }
                );
                if id == 63 {
                    let bytes = fs::read(dir.join(FileId::Heap(1).name()))
                        .unwrap()
                        .try_into()
                        .unwrap();
                    assert!(
                        phobos_wal::v2::page_format::lsn(FileId::Heap(1), 0, &bytes).unwrap()
                            <= report.checkpoint_lsn
                    );
                }
            }
        }
        let expected = db.execute("SELECT id FROM t ORDER BY id").unwrap();
        db.execute("BEGIN").unwrap();
        db.execute("UPDATE t SET id=id+100 WHERE id>=0").unwrap();
        db.execute("ROLLBACK").unwrap();
        assert_eq!(
            db.execute("SELECT id FROM t ORDER BY id").unwrap(),
            expected
        );
        assert_eq!(
            phobos_wal::v2::inspect(dir.join("phobos.wal"))
                .unwrap()
                .committed_transactions,
            6
        );
        db.execute("CHECKPOINT").unwrap();
        let report = phobos_wal::v2::inspect(dir.join("phobos.wal")).unwrap();
        assert_eq!(
            (report.committed_transactions, report.aborted_transactions),
            (0, 0)
        );
        drop(db);
        for _ in 0..2 {
            let mut db = Database::open(&dir).unwrap();
            assert_eq!(
                db.execute("SELECT id FROM t ORDER BY id").unwrap(),
                expected
            );
            for tree in db.indexes.values_mut() {
                tree.validate().unwrap();
            }
        }
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn private_engine_dml_ddl_rollback_and_restart() {
        let dir = directory();
        setup(&dir);
        let mut db = Database::open_v2(&dir).unwrap();
        let original = rows(&mut db);
        let paths = [
            "table-0000000000000001.heap",
            "index-0000000000000001.idx",
            "catalog.phc",
            "indexes.phc",
            "phobos.stats",
        ];
        let before: Vec<_> = paths
            .iter()
            .map(|path| fs::read(dir.join(path)).unwrap())
            .collect();
        db.execute("BEGIN").unwrap();
        db.execute("UPDATE t SET id=id+10 WHERE id>=1 AND id<=2")
            .unwrap();
        db.execute("DELETE FROM t WHERE id=11").unwrap();
        db.execute("INSERT INTO t VALUES (3,30)").unwrap();
        db.execute("DROP INDEX ix").unwrap();
        db.execute("CREATE INDEX replacement ON t (v)").unwrap();
        db.execute("CREATE TABLE scratch (id BIGINT)").unwrap();
        for (path, expected) in paths.iter().zip(&before) {
            assert_eq!(&fs::read(dir.join(path)).unwrap(), expected);
        }
        db.execute("ROLLBACK").unwrap();
        assert_eq!(rows(&mut db), original);
        assert!(db.execute("SELECT * FROM scratch").is_err());
        db.execute("BEGIN").unwrap();
        assert!(db.execute("INSERT INTO t VALUES (1,99)").is_err());
        assert!(db.execute("COMMIT").is_err());
        db.execute("ROLLBACK").unwrap();
        assert_eq!(rows(&mut db), original);

        db.execute("BEGIN").unwrap();
        db.execute("UPDATE t SET id=id+10 WHERE id=1").unwrap();
        db.execute("DROP INDEX ix").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        db.execute("COMMIT").unwrap();
        let expected = rows(&mut db);
        for tree in db.indexes.values_mut() {
            tree.validate().unwrap();
        }
        drop(db);
        for _ in 0..2 {
            let mut db = Database::open_v2(&dir).unwrap();
            assert_eq!(rows(&mut db), expected);
            for tree in db.indexes.values_mut() {
                tree.validate().unwrap();
            }
            db.execute("CHECKPOINT").unwrap();
        }
        assert!(
            phobos_wal::recover(&dir).is_err(),
            "legacy open must reject v2 before changing data"
        );
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn private_engine_crash_redoes_commit_and_discards_uncommitted_pages() {
        if let Ok(path) = std::env::var("PHOBOS_V2_ENGINE_CRASH_DIR") {
            let mut db = Database::open_v2(path).unwrap();
            db.execute("BEGIN").unwrap();
            db.execute("UPDATE t SET id=id+10 WHERE id=1").unwrap();
            db.execute("CREATE TABLE new_table (id BIGINT)").unwrap();
            db.execute("INSERT INTO new_table VALUES (7)").unwrap();
            if std::env::var("PHOBOS_V2_ENGINE_COMMIT").as_deref() == Ok("yes") {
                db.execute("COMMIT").unwrap();
                std::process::exit(74);
            }
            std::process::exit(73);
        }
        for commit in [false, true] {
            let dir = directory();
            setup(&dir);
            let mut child = std::process::Command::new(std::env::current_exe().unwrap());
            child.args(["--exact", "private_transaction::tests::private_engine_crash_redoes_commit_and_discards_uncommitted_pages"])
                .env("PHOBOS_V2_ENGINE_CRASH_DIR", &dir).env_remove("PHOBOS_CRASH_POINT")
                .env("PHOBOS_V2_ENGINE_COMMIT", if commit { "yes" } else { "no" });
            if commit {
                child.env("PHOBOS_CRASH_POINT", "after_wal_commit");
            }
            let status = child.status().unwrap();
            assert!(!status.success());
            assert_ne!(status.code(), Some(74), "commit crash hook missing");
            assert_ne!(status.code(), Some(101), "child panicked");
            if !commit {
                assert_eq!(status.code(), Some(73));
            } else {
                // Force actual FPI repair of torn changed heap and index pages,
                // not just redo over already-correct old pages. The index meta
                // page is unchanged and must remain available.
                OpenOptions::new()
                    .write(true)
                    .open(dir.join(FileId::Heap(1).name()))
                    .unwrap()
                    .set_len(23)
                    .unwrap();
                OpenOptions::new()
                    .write(true)
                    .open(dir.join(FileId::Index(1).name()))
                    .unwrap()
                    .set_len(8192 + 23)
                    .unwrap();
            }
            for _ in 0..2 {
                let mut db = Database::open_v2(&dir).unwrap();
                let actual = db
                    .execute(if commit {
                        "SELECT v FROM t WHERE id=11"
                    } else {
                        "SELECT v FROM t WHERE id=1"
                    })
                    .unwrap();
                assert_eq!(
                    actual,
                    QueryResult::Rows {
                        columns: vec!["v".into()],
                        rows: vec![Row::new(vec![Value::Int64(10)])]
                    }
                );
                assert_eq!(db.execute("SELECT * FROM new_table").is_ok(), commit);
                for tree in db.indexes.values_mut() {
                    tree.validate().unwrap();
                }
            }
            assert!(!fs::read_dir(&dir).unwrap().any(|entry| {
                entry
                    .unwrap()
                    .file_name()
                    .to_string_lossy()
                    .starts_with(".phobos-txn-")
            }));
            fs::remove_dir_all(dir).unwrap();
        }
    }
}
