use super::*;
use phobos_error::cancellation::{StatementContext, test_hooks};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering as AtomicOrdering},
};
use std::time::Duration;

fn temp(name: &str) -> PathBuf {
    std::env::temp_dir().join(format!("phobos-e45-{name}-{}", unique_spill_suffix()))
}

fn rows(result: QueryResult) -> Vec<Row> {
    let QueryResult::Rows { rows, .. } = result else {
        panic!("expected rows")
    };
    rows
}

#[test]
fn e4_sql_surface_and_three_table_plan() {
    let root = temp("surface");
    let mut db = Database::open(&root).unwrap();
    db.execute("CREATE TABLE a (id BIGINT, name TEXT, flag BOOLEAN)")
        .unwrap();
    db.execute("CREATE TABLE b (id BIGINT, a_id BIGINT)")
        .unwrap();
    db.execute("CREATE TABLE c (b_id BIGINT)").unwrap();
    db.execute("CREATE TABLE allowed (owner_id BIGINT)")
        .unwrap();
    db.execute("INSERT INTO a VALUES (1,'alice',TRUE),(2,'bob',FALSE),(3,'al',NULL)")
        .unwrap();
    db.execute("INSERT INTO b VALUES (10,1),(20,2),(30,3)")
        .unwrap();
    db.execute("INSERT INTO c VALUES (10),(20),(30)").unwrap();
    db.execute("INSERT INTO allowed VALUES (1),(3),(NULL)")
        .unwrap();

    let sql = "/* E4 */ SELECT DISTINCT CASE WHEN UPPER(a.name) LIKE 'AL%' THEN UPPER(a.name) ELSE 'OTHER' END AS label FROM a JOIN b ON a.id=b.a_id JOIN c ON b.id=c.b_id WHERE a.id IN (SELECT owner_id FROM allowed) ORDER BY 1 LIMIT 10 -- done";
    let result = db.execute(sql).unwrap();
    assert_eq!(
        rows(result),
        vec![
            Row::new(vec![Value::Text("AL".into())]),
            Row::new(vec![Value::Text("ALICE".into())])
        ]
    );
    let plan = db.execute(&format!("EXPLAIN {sql}")).unwrap().to_text();
    assert_eq!(plan.matches("Join").count(), 2, "{plan}");
    drop(db);
    let mut db = Database::open(&root).unwrap();
    assert_eq!(rows(db.execute(sql).unwrap()).len(), 2);

    assert_eq!(
        rows(db.execute("SELECT id FROM a WHERE id IN (1,NULL)").unwrap()),
        vec![Row::new(vec![Value::Int64(1)])]
    );
    assert_eq!(
        rows(
            db.execute("SELECT id FROM a WHERE name LIKE 'a_' ORDER BY id")
                .unwrap()
        )
        .len(),
        1
    );
    assert_eq!(rows(db.execute("SELECT LOWER(name), LENGTH(name), ABS(-id), COALESCE(NULL,name), NULLIF(id,id) FROM a WHERE id=1").unwrap())[0].values,
        vec![Value::Text("alice".into()), Value::Int64(5), Value::Int64(1), Value::Text("alice".into()), Value::Null]);
    assert_eq!(
        rows(
            db.execute("SELECT \"id\" FROM \"a\" WHERE \"id\"=2")
                .unwrap()
        ),
        vec![Row::new(vec![Value::Int64(2)])]
    );
    assert_eq!(
        db.execute("SELECT \"ID\" FROM a").unwrap_err().code,
        ErrorCode::NotFound
    );
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn e4_distinct_uses_canonical_numeric_and_null_semantics() {
    let root = temp("distinct");
    let mut db = Database::open(&root).unwrap();
    db.query_memory_bytes = 1;
    db.execute("CREATE TABLE t (flag BOOLEAN)").unwrap();
    db.execute("INSERT INTO t VALUES (TRUE),(FALSE),(NULL),(NULL)")
        .unwrap();
    let result = rows(db.execute("SELECT DISTINCT CASE WHEN flag THEN -0.0 WHEN flag IS NULL THEN NULL ELSE 0.0 END AS n FROM t ORDER BY 1").unwrap());
    assert_eq!(result.len(), 2);
    assert!(matches!(result[0].values[0], Value::Float64(value) if value == 0.0));
    assert_eq!(result[1].values[0], Value::Null);
    assert!(
        !fs::read_dir(&root)
            .unwrap()
            .filter_map(Result::ok)
            .any(|entry| entry
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill-"))
    );
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn e4_spilled_distinct_cancels_and_cleans_scratch() {
    let root = temp("cancel");
    let mut db = Database::open(&root).unwrap();
    db.query_memory_bytes = 1;
    db.execute("CREATE TABLE t (id BIGINT)").unwrap();
    for id in 0..600 {
        db.execute(&format!("INSERT INTO t VALUES ({id})")).unwrap();
    }
    let reached = Arc::new(AtomicBool::new(false));
    let hit = reached.clone();
    let context = StatementContext::new("distinct".into(), Some(Duration::from_secs(60)));
    let error = {
        let _context = context.enter();
        let _hook = test_hooks::register(Arc::new(move |point| {
            if point == "distinct.spill" {
                hit.store(true, AtomicOrdering::SeqCst);
                test_hooks::expire_current();
            }
        }));
        db.execute("SELECT DISTINCT id FROM t").unwrap_err()
    };
    assert!(reached.load(AtomicOrdering::SeqCst));
    assert_eq!(error.code, ErrorCode::StatementTimeout);
    assert!(
        !fs::read_dir(&root)
            .unwrap()
            .filter_map(Result::ok)
            .any(|entry| entry
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill-"))
    );
    fs::remove_dir_all(root).unwrap();
}
