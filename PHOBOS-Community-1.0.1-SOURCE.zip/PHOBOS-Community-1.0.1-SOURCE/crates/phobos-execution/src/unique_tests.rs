use super::*;

fn pair(nan: bool) -> (Value, Value) {
    if nan {
        (
            Value::Float64(f64::from_bits(0x7ff8000000000001)),
            Value::Float64(f64::from_bits(0xfff8000000001234)),
        )
    } else {
        (Value::Float64(0.0), Value::Float64(-0.0))
    }
}
fn run_case(nan: bool, mode: u8) {
    let path = std::env::temp_dir().join(format!(
        "phobos-a12-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ));
    let mut db = Database::open(&path).unwrap();
    db.execute("CREATE TABLE t (id BIGINT, k DOUBLE, g BIGINT)")
        .unwrap();
    let (a, b) = pair(nan);
    let index = if mode == 3 {
        "CREATE UNIQUE INDEX u ON t(k,g)"
    } else {
        "CREATE UNIQUE INDEX u ON t(k)"
    };
    if mode != 2 {
        db.execute(index).unwrap();
    }
    db.execute_params("INSERT INTO t VALUES (1,$1,10)", &[a])
        .unwrap();
    let result = match mode {
        1 => {
            db.execute("INSERT INTO t VALUES (2,42.0,10)").unwrap();
            db.execute_params("UPDATE t SET k=$1 WHERE id=2", &[b])
        }
        2 => {
            db.execute_params("INSERT INTO t VALUES (2,$1,10)", &[b])
                .unwrap();
            db.execute(index)
        }
        _ => db.execute_params("INSERT INTO t VALUES (2,$1,10)", &[b]),
    };
    let code = result.as_ref().err().map(|e| e.code);
    drop(db);
    fs::remove_dir_all(path).unwrap();
    assert_eq!(
        code,
        Some(ErrorCode::ConstraintViolation),
        "nan={nan} mode={mode} result={result:?}"
    );
}
#[test]
fn a12_insert_zero() {
    run_case(false, 0);
}
#[test]
fn a12_insert_nan() {
    run_case(true, 0);
}
#[test]
fn a12_update_zero() {
    run_case(false, 1);
}
#[test]
fn a12_update_nan() {
    run_case(true, 1);
}
#[test]
fn a12_create_zero() {
    run_case(false, 2);
}
#[test]
fn a12_create_nan() {
    run_case(true, 2);
}
#[test]
fn a12_composite_zero() {
    run_case(false, 3);
}
#[test]
fn a12_composite_nan() {
    run_case(true, 3);
}

#[test]
fn a12_null_and_distinct_controls() {
    let path = std::env::temp_dir().join(format!("phobos-a12-controls-{}", unique_spill_suffix()));
    let mut db = Database::open(&path).unwrap();
    db.execute("CREATE TABLE t (k DOUBLE, g BIGINT)").unwrap();
    db.execute("CREATE UNIQUE INDEX u ON t(k,g)").unwrap();
    for sql in [
        "INSERT INTO t VALUES (NULL,10)",
        "INSERT INTO t VALUES (NULL,10)",
        "INSERT INTO t VALUES (0.0,10)",
        "INSERT INTO t VALUES (-0.0,11)",
        "INSERT INTO t VALUES (2.5,10)",
    ] {
        db.execute(sql).unwrap();
    }
    drop(db);
    fs::remove_dir_all(path).unwrap();
}

#[test]
fn a12_other_declared_types_and_coercion() {
    for (ty, value, other) in [
        ("BIGINT", Value::Int64(7), Value::Int64(8)),
        ("TEXT", Value::Text("x".into()), Value::Text("y".into())),
        ("BOOLEAN", Value::Boolean(true), Value::Boolean(false)),
        ("DATE", Value::Date(1), Value::Date(2)),
        ("TIMESTAMP", Value::Timestamp(1), Value::Timestamp(2)),
        (
            "DECIMAL(10,2)",
            Value::Decimal {
                unscaled: 123,
                scale: 2,
            },
            Value::Decimal {
                unscaled: 124,
                scale: 2,
            },
        ),
        ("DOUBLE", Value::Int64(7), Value::Float64(7.5)),
    ] {
        let path = std::env::temp_dir().join(format!("phobos-a12-types-{}", unique_spill_suffix()));
        let mut db = Database::open(&path).unwrap();
        db.execute(&format!("CREATE TABLE t (k {ty})")).unwrap();
        db.execute("CREATE UNIQUE INDEX u ON t(k)").unwrap();
        db.execute_params("INSERT INTO t VALUES ($1)", std::slice::from_ref(&value))
            .unwrap();
        assert_eq!(
            db.execute_params("INSERT INTO t VALUES ($1)", &[value])
                .unwrap_err()
                .code,
            ErrorCode::ConstraintViolation
        );
        db.execute_params("INSERT INTO t VALUES ($1)", &[other])
            .unwrap();
        db.execute("INSERT INTO t VALUES (NULL)").unwrap();
        db.execute("INSERT INTO t VALUES (NULL)").unwrap();
        drop(db);
        fs::remove_dir_all(path).unwrap();
    }
}

#[test]
fn a12_existing_violating_heap_is_rejected_without_deleting_rows() {
    for nan in [false, true] {
        let path = std::env::temp_dir().join(format!("phobos-a12-old-{}", unique_spill_suffix()));
        let mut db = Database::open(&path).unwrap();
        db.execute("CREATE TABLE t (k DOUBLE)").unwrap();
        let (a, b) = pair(nan);
        db.execute_params("INSERT INTO t VALUES ($1)", &[a])
            .unwrap();
        db.execute_params("INSERT INTO t VALUES ($1)", &[b])
            .unwrap();
        // Construct a pre-A1.2 catalog claiming uniqueness without applying
        // the new SQL DDL gate. Open must reject even an empty/stale index.
        let table = db.table_schema("t").unwrap();
        let index = db
            .catalog
            .create_index("u".into(), table.id, vec!["k".into()], true)
            .unwrap();
        drop(BPlusTree::open(index_path(&path, index.id), true, 1).unwrap());
        drop(db);
        let error = Database::open(&path)
            .err()
            .expect("invalid existing unique accepted");
        assert_eq!(error.code, ErrorCode::ConstraintViolation);
        assert!(error.message.contains("canonical equality"));
        let mut heap = HeapTable::open(heap_path(&path, table.id), table, 2).unwrap();
        let mut count = 0;
        heap.scan_visit(|_, _| {
            count += 1;
            Ok(true)
        })
        .unwrap();
        assert_eq!(count, 2);
        drop(heap);
        fs::remove_dir_all(path).unwrap();
    }
}
