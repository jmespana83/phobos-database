//! 0.1.9-A1.1: predicate-to-index-bound translation.
//!
//! An index is an optimization only. The SQL meaning of `column op constant`
//! is fixed by `Value::canonical_cmp` (the A1 contract) and is always
//! re-evaluated on every candidate row. This module only decides which index
//! keys *may* satisfy the predicate, and it may only ever widen that set,
//! never narrow it below the rows the predicate accepts.
//!
//! Two facts make the translation non-trivial:
//! - the B+ tree orders `Float64` keys by IEEE `total_cmp` (so `-0.0 < +0.0`,
//!   negative NaNs sort below `-inf`, positive NaNs above `+inf`), while the
//!   predicate treats `-0.0 == +0.0` and every NaN as one value above all
//!   numbers;
//! - a `BIGINT` key column can only hold integers, and an `Int64` constant is
//!   not always representable as `f64`, so mixed-type constants have to be
//!   translated exactly (never rounded into a false match).
//!
//! `translate` therefore answers, per constraint, one of:
//! - `Range`: keys inside this contiguous range (in index order), optionally
//!   together with the negative-NaN region, are the only keys that can satisfy
//!   the predicate;
//! - `Never`: no key can satisfy it (the predicate is FALSE or UNKNOWN for every
//!   row, so the index may return no candidates);
//! - `Skip`: the predicate cannot be represented faithfully (or every key may
//!   satisfy it); the constraint must not drive the index scan.
//!
//! The planner additionally uses an index only when the whole filter is
//! *total* (`filter_is_total`): it cannot raise an error on any row. Otherwise
//! index pruning could hide an error a sequential scan would report.
use super::*;
use phobos_types::KeyClass;

/// Half-open/closed bound on one key column: `None` is unbounded.
pub(super) type ValueBound = Option<(Value, bool)>;

#[derive(Debug, Clone, PartialEq)]
pub(super) enum Translation {
    Range {
        lower: ValueBound,
        upper: ValueBound,
        /// The negative-NaN region of a `Float64` index (keys below `-inf` in
        /// `total_cmp` order) may also satisfy the predicate.
        negative_nan: bool,
    },
    Never,
    Skip,
}

impl Translation {
    fn point(value: Value) -> Self {
        Self::Range {
            lower: Some((value.clone(), true)),
            upper: Some((value, true)),
            negative_nan: false,
        }
    }
    fn lower(value: Value, inclusive: bool, negative_nan: bool) -> Self {
        Self::Range {
            lower: Some((value, inclusive)),
            upper: None,
            negative_nan,
        }
    }
    fn upper(value: Value, inclusive: bool) -> Self {
        Self::Range {
            lower: None,
            upper: Some((value, inclusive)),
            // An unbounded lower end already starts at the bottom of the index.
            negative_nan: true,
        }
    }
    /// The single exact key this range denotes, if it is one key in index
    /// order: usable as one part of a composite key.
    pub(super) fn exact_key(&self) -> Option<&Value> {
        let Self::Range {
            lower: Some((low, true)),
            upper: Some((high, true)),
            negative_nan: false,
        } = self
        else {
            return None;
        };
        if low.canonical_key() != high.canonical_key() {
            return None;
        }
        // A float key is one bit pattern only when it is neither zero nor NaN.
        if let Value::Float64(float) = low {
            if float.is_nan() || *float == 0.0 {
                return None;
            }
        }
        Some(low)
    }
}

const TWO_POW_63: f64 = 9_223_372_036_854_775_808.0;

/// Translates `column op constant` into index-key terms for a column of
/// `column_type`. `op` is one of `=`, `<`, `<=`, `>`, `>=` with the column on
/// the left.
pub(super) fn translate(column_type: &DataType, op: BinaryOp, constant: &Value) -> Translation {
    // NULL: the predicate is UNKNOWN for every row; the filter rejects all
    // candidates, so the constraint must simply not narrow anything.
    if constant.is_null() {
        return Translation::Skip;
    }
    match (column_type, constant) {
        (DataType::Int64, Value::Int64(value)) => with_op(op, Value::Int64(*value)),
        (DataType::Int64, Value::Float64(float)) => int_column_float_constant(op, *float),
        (DataType::Float64, Value::Float64(float)) => float_column_float_constant(op, *float),
        (DataType::Float64, Value::Int64(value)) => float_column_int_constant(op, *value),
        (data_type, value) if value.key_class() == Some(data_type.key_class()) => {
            with_op(op, value.clone())
        }
        // Different classes never compare under the canonical contract; the
        // planner has already refused the index for such filters.
        _ => Translation::Skip,
    }
}

/// A key whose index order agrees with the canonical order (integers and every
/// non-float class): the operator maps directly onto a bound.
fn with_op(op: BinaryOp, key: Value) -> Translation {
    match op {
        BinaryOp::Eq => Translation::point(key),
        BinaryOp::Gt => Translation::lower(key, false, false),
        BinaryOp::GtEq => Translation::lower(key, true, false),
        BinaryOp::Lt => Translation::upper(key, false),
        BinaryOp::LtEq => Translation::upper(key, true),
        _ => Translation::Skip,
    }
}

/// BIGINT column against a float constant: compare exactly against the
/// integer grid. Fractional constants move to the neighbouring integer with
/// the matching inclusivity; out-of-range and non-finite constants are decided
/// outright.
fn int_column_float_constant(op: BinaryOp, float: f64) -> Translation {
    let above_all = float.is_nan() || float >= TWO_POW_63;
    let below_all = float < -TWO_POW_63;
    if above_all {
        return match op {
            BinaryOp::Lt | BinaryOp::LtEq => Translation::Skip,
            _ => Translation::Never,
        };
    }
    if below_all {
        return match op {
            BinaryOp::Gt | BinaryOp::GtEq => Translation::Skip,
            _ => Translation::Never,
        };
    }
    let truncated = float.trunc();
    if truncated == float {
        // `-0.0` and every integral float in range are exact integers.
        return with_op(op, Value::Int64(float as i64));
    }
    // Fractional: no integer equals it; integers above it are >= ceil, below it <= floor.
    match op {
        BinaryOp::Eq => Translation::Never,
        BinaryOp::Gt | BinaryOp::GtEq => {
            Translation::lower(Value::Int64(float.ceil() as i64), true, false)
        }
        BinaryOp::Lt | BinaryOp::LtEq => {
            Translation::upper(Value::Int64(float.floor() as i64), true)
        }
        _ => Translation::Skip,
    }
}

/// FLOAT column against a float constant, expressed in the index's
/// `total_cmp` order while honouring the canonical `-0.0 == +0.0` and
/// NaN-equals-NaN-and-sorts-last rules.
fn float_column_float_constant(op: BinaryOp, float: f64) -> Translation {
    if float.is_nan() {
        return match op {
            // Every NaN, of either sign: the top region plus the bottom region.
            BinaryOp::Eq | BinaryOp::GtEq => {
                Translation::lower(Value::Float64(f64::INFINITY), false, true)
            }
            BinaryOp::Gt => Translation::Never,
            // Every number is below NaN (`<`), and everything is `<=` NaN.
            BinaryOp::Lt | BinaryOp::LtEq => Translation::Skip,
            _ => Translation::Skip,
        };
    }
    if float == 0.0 {
        return match op {
            BinaryOp::Eq => Translation::Range {
                lower: Some((Value::Float64(-0.0), true)),
                upper: Some((Value::Float64(0.0), true)),
                negative_nan: false,
            },
            BinaryOp::GtEq => Translation::lower(Value::Float64(-0.0), true, true),
            BinaryOp::LtEq => Translation::upper(Value::Float64(0.0), true),
            // `> ±0` and `< ±0` exclude both zeros; the remaining candidates
            // of either sign are re-checked by the predicate.
            BinaryOp::Gt => Translation::lower(Value::Float64(0.0), false, true),
            BinaryOp::Lt => Translation::upper(Value::Float64(-0.0), false),
            _ => Translation::Skip,
        };
    }
    match op {
        BinaryOp::Eq => Translation::point(Value::Float64(float)),
        BinaryOp::Gt => Translation::lower(Value::Float64(float), false, true),
        BinaryOp::GtEq => Translation::lower(Value::Float64(float), true, true),
        BinaryOp::Lt => Translation::upper(Value::Float64(float), false),
        BinaryOp::LtEq => Translation::upper(Value::Float64(float), true),
        _ => Translation::Skip,
    }
}

/// FLOAT column against an integer constant. `value as f64` rounds to the
/// nearest float; when that float is not the integer itself, no float lies
/// strictly between the two, so the bound is the rounded float with the
/// inclusivity adjusted for the direction of rounding.
fn float_column_int_constant(op: BinaryOp, value: i64) -> Translation {
    let rounded = value as f64;
    match Value::Int64(value).canonical_cmp(&Value::Float64(rounded)) {
        Some(Ordering::Equal) => float_column_float_constant(op, rounded),
        // rounded > value: floats > value are floats >= rounded; floats < value are floats < rounded.
        Some(Ordering::Less) => match op {
            BinaryOp::Eq => Translation::Never,
            BinaryOp::Gt | BinaryOp::GtEq => {
                Translation::lower(Value::Float64(rounded), true, true)
            }
            BinaryOp::Lt | BinaryOp::LtEq => Translation::upper(Value::Float64(rounded), false),
            _ => Translation::Skip,
        },
        // rounded < value: floats > value are floats > rounded; floats < value are floats <= rounded.
        Some(Ordering::Greater) => match op {
            BinaryOp::Eq => Translation::Never,
            BinaryOp::Gt | BinaryOp::GtEq => {
                Translation::lower(Value::Float64(rounded), false, true)
            }
            BinaryOp::Lt | BinaryOp::LtEq => Translation::upper(Value::Float64(rounded), true),
            _ => Translation::Skip,
        },
        None => Translation::Skip,
    }
}

/// Static class of an expression when it can be determined without a row.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StaticClass {
    Null,
    Class(KeyClass),
}

/// True when evaluating `filter` can never raise an error on any row: every
/// comparison is between values of one class (or NULL), every logical operand
/// is BOOLEAN or NULL, and no arithmetic or negation occurs. Only then may the
/// planner let an index decide which rows the filter is evaluated on, because
/// a sequential scan would evaluate it on every row.
pub(super) fn filter_is_total(filter: &Expr, schema: &TableSchema, params: &[Value]) -> bool {
    matches!(
        static_class(filter, schema, params),
        Some(StaticClass::Null | StaticClass::Class(KeyClass::Boolean))
    )
}

fn static_class(expr: &Expr, schema: &TableSchema, params: &[Value]) -> Option<StaticClass> {
    let value_class = |value: &Value| {
        Some(
            value
                .key_class()
                .map_or(StaticClass::Null, StaticClass::Class),
        )
    };
    let boolean = |class: Option<StaticClass>| {
        matches!(
            class,
            Some(StaticClass::Null | StaticClass::Class(KeyClass::Boolean))
        )
    };
    match expr {
        Expr::Literal(value) => value_class(value),
        Expr::Parameter(index) => params.get(*index).and_then(value_class),
        Expr::Column(name) => schema
            .column_index(name)
            .map(|position| StaticClass::Class(schema.columns[position].data_type.key_class())),
        Expr::QuotedColumn(name) => schema
            .columns
            .iter()
            .position(|column| column.name == *name)
            .map(|position| StaticClass::Class(schema.columns[position].data_type.key_class())),
        Expr::Unary {
            op: UnaryOp::Not,
            expr,
        } => boolean(static_class(expr, schema, params))
            .then_some(StaticClass::Class(KeyClass::Boolean)),
        // Negation can overflow.
        Expr::Unary {
            op: UnaryOp::Negate,
            ..
        } => None,
        Expr::IsNull { expr, .. } => {
            static_class(expr, schema, params).map(|_| StaticClass::Class(KeyClass::Boolean))
        }
        Expr::Binary { left, op, right } => {
            let left = static_class(left, schema, params)?;
            let right = static_class(right, schema, params)?;
            match op {
                BinaryOp::And | BinaryOp::Or => (boolean(Some(left)) && boolean(Some(right)))
                    .then_some(StaticClass::Class(KeyClass::Boolean)),
                BinaryOp::Eq
                | BinaryOp::NotEq
                | BinaryOp::Lt
                | BinaryOp::LtEq
                | BinaryOp::Gt
                | BinaryOp::GtEq => match (left, right) {
                    (StaticClass::Null, _) | (_, StaticClass::Null) => {
                        Some(StaticClass::Class(KeyClass::Boolean))
                    }
                    (StaticClass::Class(a), StaticClass::Class(b)) if a == b => {
                        Some(StaticClass::Class(KeyClass::Boolean))
                    }
                    _ => None,
                },
                // Arithmetic can overflow, divide by zero, or mismatch types.
                BinaryOp::Add | BinaryOp::Subtract | BinaryOp::Multiply | BinaryOp::Divide => None,
            }
        }
        Expr::Function { .. }
        | Expr::Like { .. }
        | Expr::InList { .. }
        | Expr::InSubquery { .. }
        | Expr::ScalarSubquery(_)
        | Expr::Exists(_)
        | Expr::Case { .. } => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Every translation must be a superset of the rows the canonical predicate
    /// accepts, and `Never` must mean no row is accepted. Checked by brute force
    /// over a value corpus, using the index's own key order for membership.
    #[test]
    fn translations_never_lose_a_row_the_predicate_accepts() {
        let ints: Vec<i64> = vec![
            i64::MIN,
            i64::MIN + 1,
            -9_007_199_254_740_993,
            -9_007_199_254_740_992,
            -2,
            -1,
            0,
            1,
            2,
            9_007_199_254_740_991,
            9_007_199_254_740_992,
            9_007_199_254_740_993,
            9_007_199_254_740_994,
            9_007_199_254_740_995,
            i64::MAX - 1,
            i64::MAX,
        ];
        let floats: Vec<f64> = vec![
            -f64::NAN,
            f64::NAN,
            f64::from_bits(0x7ff8_0000_0000_0001),
            f64::NEG_INFINITY,
            -1.0e300,
            -9_223_372_036_854_775_808.0,
            -9_223_372_036_854_777_856.0,
            -9_007_199_254_740_992.0,
            -2.5,
            -2.0,
            -1.5,
            -1.0,
            -0.5,
            -0.0,
            0.0,
            f64::MIN_POSITIVE,
            0.5,
            1.0,
            1.5,
            2.0,
            9_007_199_254_740_992.0,
            9_007_199_254_740_994.0,
            9_007_199_254_740_996.0,
            9_223_372_036_854_775_808.0,
            1.0e19,
            1.0e300,
            f64::INFINITY,
        ];
        let constants: Vec<Value> = ints
            .iter()
            .map(|v| Value::Int64(*v))
            .chain(floats.iter().map(|f| Value::Float64(*f)))
            .chain([Value::Null])
            .collect();
        let ops = [
            BinaryOp::Eq,
            BinaryOp::Lt,
            BinaryOp::LtEq,
            BinaryOp::Gt,
            BinaryOp::GtEq,
        ];
        let mut checked = 0usize;
        for (column_type, keys) in [
            (
                DataType::Int64,
                ints.iter().map(|v| Value::Int64(*v)).collect::<Vec<_>>(),
            ),
            (
                DataType::Float64,
                floats
                    .iter()
                    .map(|f| Value::Float64(*f))
                    .collect::<Vec<_>>(),
            ),
        ] {
            for constant in &constants {
                for op in ops {
                    let translation = translate(&column_type, op, constant);
                    for key in &keys {
                        let accepted = match compare_values(key, op, constant).unwrap() {
                            Value::Boolean(value) => value,
                            _ => false,
                        };
                        let candidate = match &translation {
                            Translation::Skip => true,
                            Translation::Never => false,
                            Translation::Range {
                                lower,
                                upper,
                                negative_nan,
                            } => {
                                let index_key = IndexKey(vec![key.clone()]);
                                let in_range =
                                    lower.as_ref().is_none_or(|(low, inclusive)| {
                                        let low = IndexKey(vec![low.clone()]);
                                        if *inclusive {
                                            index_key >= low
                                        } else {
                                            index_key > low
                                        }
                                    }) && upper.as_ref().is_none_or(|(high, inclusive)| {
                                        let high = IndexKey(vec![high.clone()]);
                                        if *inclusive {
                                            index_key <= high
                                        } else {
                                            index_key < high
                                        }
                                    });
                                let in_negative_nan = *negative_nan
                                    && matches!(key, Value::Float64(f) if f.is_nan() && f.is_sign_negative());
                                in_range || in_negative_nan
                            }
                        };
                        assert!(
                            candidate || !accepted,
                            "{column_type:?} key {key:?} {op:?} {constant:?}: accepted by the predicate but excluded by {translation:?}"
                        );
                        if translation == Translation::Never {
                            assert!(
                                !accepted,
                                "{column_type:?} {op:?} {constant:?} claims Never but {key:?} matches"
                            );
                        }
                        checked += 1;
                    }
                }
            }
        }
        assert!(checked > 5_000, "{checked}");
    }

    #[test]
    fn exact_keys_and_totality_are_classified_as_documented() {
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Eq, &Value::Float64(1.0)).exact_key(),
            Some(&Value::Int64(1))
        );
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Eq, &Value::Float64(-0.0)).exact_key(),
            Some(&Value::Int64(0))
        );
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Eq, &Value::Float64(1.5)),
            Translation::Never
        );
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Lt, &Value::Float64(f64::NAN)),
            Translation::Skip
        );
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Gt, &Value::Float64(f64::NAN)),
            Translation::Never
        );
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Eq, &Value::Null),
            Translation::Skip
        );
        assert_eq!(
            translate(&DataType::Int64, BinaryOp::Eq, &Value::Text("1".into())),
            Translation::Skip
        );
        assert_eq!(
            translate(&DataType::Float64, BinaryOp::Eq, &Value::Float64(0.0)).exact_key(),
            None,
            "signed zero spans two keys"
        );
        assert_eq!(
            translate(&DataType::Float64, BinaryOp::Eq, &Value::Float64(f64::NAN)).exact_key(),
            None
        );
        assert_eq!(
            translate(&DataType::Float64, BinaryOp::Eq, &Value::Int64(3)).exact_key(),
            Some(&Value::Float64(3.0))
        );
        assert_eq!(
            translate(
                &DataType::Float64,
                BinaryOp::Eq,
                &Value::Int64(9_007_199_254_740_993)
            ),
            Translation::Never
        );
        let schema = TableSchema {
            id: 1,
            name: "t".into(),
            columns: vec![
                ColumnSchema {
                    name: "k".into(),
                    data_type: DataType::Int64,
                    nullable: true,
                },
                ColumnSchema {
                    name: "t".into(),
                    data_type: DataType::Text,
                    nullable: true,
                },
                ColumnSchema {
                    name: "b".into(),
                    data_type: DataType::Boolean,
                    nullable: true,
                },
            ],
        };
        let total = |sql: &str, params: &[Value]| {
            let Statement::Select { filter, .. } =
                parse(&format!("SELECT k FROM t WHERE {sql}")).unwrap()
            else {
                panic!("{sql}")
            };
            filter_is_total(&filter.unwrap(), &schema, params)
        };
        assert!(total("k = 1", &[]));
        assert!(total("k = 1.5 AND t = 'x'", &[]));
        assert!(total("k = $1", &[Value::Null]));
        assert!(total("k IS NULL OR NOT (k < 3)", &[]));
        assert!(total("b AND k > 1", &[]));
        assert!(total("k = NULL", &[]));
        assert!(!total("k = 'x'", &[]));
        assert!(!total("t = 1", &[]));
        assert!(!total("k = 1 AND v = 1", &[]), "unknown column");
        assert!(!total("k = 1 AND k + 1 > 0", &[]));
        assert!(!total("k = 1 AND -k < 0", &[]));
        assert!(!total("k = 1 AND 1", &[]));
        assert!(!total("k = $1", &[]), "missing parameter");
        assert!(!total(
            "k = $1",
            &[Value::Decimal {
                unscaled: 1,
                scale: 0
            }]
        ));
    }
}
