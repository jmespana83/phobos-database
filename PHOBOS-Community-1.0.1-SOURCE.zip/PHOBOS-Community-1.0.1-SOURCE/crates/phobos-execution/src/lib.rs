#![forbid(unsafe_code)]
//! Phase 6 execution: durable DML plus joins, aggregates, statistics, cost-aware planning, spill sort, and EXPLAIN.

use phobos_catalog::{Catalog, RangePartition};
use phobos_error::{ErrorCode, PhobosError};
use phobos_index::{BPlusTree, Bound as IndexBound, IndexKey};
use phobos_sql::{
    AggregateFunction, BinaryOp, Expr, JoinKind, OrderBy, RelationalSelect, SelectColumns,
    SelectItem, Statement, UnaryOp, parse,
};
use phobos_storage::HeapTable;
use phobos_txn::{TransactionId, TransactionManager};
use phobos_types::{
    ColumnSchema, DataType, IndexId, IndexSchema, RecordId, Row, TableId, TableSchema, Value,
    ValueRef,
};
use phobos_wal::{Wal, install_snapshot, recover};
use std::{
    cmp::Ordering,
    collections::{BTreeMap, HashMap, HashSet},
    fs::{self, File, OpenOptions},
    hash::{Hash, Hasher},
    io::{BufReader, BufWriter, Read, Write},
    path::{Path, PathBuf},
    time::Instant,
};

const DEFAULT_BUFFER_PAGES: usize = 64;
const DEFAULT_QUERY_MEMORY_BYTES: usize = 64 * 1024 * 1024;
const STATS_FILE: &str = "phobos.stats";

#[cfg(test)]
mod background_flush_tests;
mod bounded_sort;
mod engine_v2;
mod index_bounds;
#[cfg(test)]
mod index_parity_tests;
#[cfg(test)]
mod key_semantics_tests;
#[cfg(test)]
mod phase_e45_tests;
#[cfg(test)]
mod phase_e_tests;
mod planner;
use planner::{estimate_filter_selectivity, estimate_index_selectivity};
mod unique_integrity;
#[cfg(test)]
mod unique_tests;
pub use phobos_storage::committed_pages::FlushStats;
mod correlated;
mod group_commit;
mod independent_prepare;
mod indexed_dml;
mod management;
mod modern_sql;
pub mod mvcc_runtime;
mod private_transaction;
mod sql_surface;
mod streaming;
mod streaming_aggregate;
mod streaming_relational;
mod views;
use sql_surface::{distinct_rows, eval_builtin, eval_in, eval_like};
pub use streaming::ResultSink;

#[derive(Debug, Clone, PartialEq)]
pub enum QueryResult {
    Command {
        tag: String,
        rows_affected: u64,
    },
    Rows {
        columns: Vec<String>,
        rows: Vec<Row>,
    },
}

impl QueryResult {
    #[must_use]
    pub fn to_text(&self) -> String {
        self.render_text(|| Ok(()))
            .expect("infallible compatibility rendering")
    }
    pub fn to_text_cancellable(&self) -> Result<String, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        self.render_text(|| cancellation_poll.checkpoint_at("result.to_text"))
    }
    fn render_text(
        &self,
        mut check: impl FnMut() -> Result<(), PhobosError>,
    ) -> Result<String, PhobosError> {
        let _profile = phobos_observability::span("execution.to_text");
        Ok(match self {
            Self::Command { tag, rows_affected } => format!("{tag} {rows_affected}"),
            Self::Rows { columns, rows } => {
                use std::fmt::Write as _;
                let mut output = String::new();
                output.push_str(&columns.join("\t"));
                output.push('\n');
                for row in rows {
                    check()?;
                    for (index, value) in row.values.iter().enumerate() {
                        if index != 0 {
                            output.push('\t');
                        }
                        // Formatting into String cannot fail; preserve Value's existing Display.
                        write!(&mut output, "{value}").expect("formatting into String");
                    }
                    output.push('\n');
                }
                output
            }
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Truth {
    True,
    False,
    Unknown,
}

#[derive(Debug, Clone)]
struct SelectRequest {
    table: String,
    selection: SelectColumns,
    filter: Option<Expr>,
    order_by: Vec<OrderBy>,
    limit: Option<Expr>,
    offset: Option<Expr>,
}

/// One contiguous key range in index order; `None` is unbounded.
#[derive(Debug, Clone)]
struct KeyRange {
    lower: Option<(IndexKey, bool)>,
    upper: Option<(IndexKey, bool)>,
    prefix: Option<IndexKey>,
}

impl KeyRange {
    fn lower_bound(&self) -> IndexBound<'_> {
        match &self.lower {
            None => IndexBound::Unbounded,
            Some((key, true)) => IndexBound::Included(key),
            Some((key, false)) => IndexBound::Excluded(key),
        }
    }
    fn upper_bound(&self) -> IndexBound<'_> {
        match &self.upper {
            None => IndexBound::Unbounded,
            Some((key, true)) => IndexBound::Included(key),
            Some((key, false)) => IndexBound::Excluded(key),
        }
    }
}

/// Candidate rows for a filter: the union of disjoint key ranges of one
/// index. An empty `ranges` means the filter can match no row. The filter is
/// always re-evaluated on every candidate (see `index_bounds`).
#[derive(Debug, Clone)]
struct IndexSearch {
    index_id: IndexId,
    index_name: String,
    ranges: Vec<KeyRange>,
}

#[derive(Debug, Clone, Default)]
struct ColumnStatistics {
    distinct_count: u64,
    null_count: u64,
    min_text: Option<String>,
    max_text: Option<String>,
}

#[derive(Debug, Clone, Default)]
struct TableStatistics {
    row_count: u64,
    generation: u64,
    changed_rows: u64,
    columns: BTreeMap<String, ColumnStatistics>,
}

impl TableStatistics {
    fn freshness(&self) -> &'static str {
        if self.changed_rows == 0 {
            "fresh"
        } else {
            "stale"
        }
    }
}

#[derive(Debug, Clone)]
struct Relation {
    names: Vec<String>,
    qualified_names: Vec<String>,
    rows: Vec<Row>,
}

fn row_bytes(row: &Row) -> usize {
    std::mem::size_of::<Row>()
        + row.values.len() * std::mem::size_of::<Value>()
        + row
            .values
            .iter()
            .map(|value| match value {
                Value::Text(text) => text.len(),
                Value::Binary(bytes) => bytes.len(),
                _ => 0,
            })
            .sum::<usize>()
}

fn estimated_schema_row_bytes(schema: &TableSchema) -> usize {
    std::mem::size_of::<Row>()
        + schema.columns.len() * std::mem::size_of::<Value>()
        + schema.columns.len() * 16
}

impl Relation {
    fn column_index(&self, name: &str) -> Result<usize, PhobosError> {
        if let Some(index) = self
            .qualified_names
            .iter()
            .position(|candidate| candidate.eq_ignore_ascii_case(name))
        {
            return Ok(index);
        }
        let matches: Vec<usize> = self
            .names
            .iter()
            .enumerate()
            .filter_map(|(index, candidate)| candidate.eq_ignore_ascii_case(name).then_some(index))
            .collect();
        match matches.as_slice() {
            [index] => Ok(*index),
            [] => Err(PhobosError::new(
                ErrorCode::NotFound,
                format!("column {name} does not exist"),
            )),
            _ => Err(PhobosError::new(
                ErrorCode::Semantic,
                format!("column {name} is ambiguous"),
            )),
        }
    }
}

struct ActiveTransaction {
    id: TransactionId,
    temp_dir: PathBuf,
    database: Box<Database>,
    failed: bool,
}

struct PrivateTransaction {
    id: TransactionId,
    temp_dir: PathBuf,
    dropped_indexes: BTreeMap<IndexId, BPlusTree>,
    failed: bool,
}

pub struct Database {
    mvcc_view: bool,
    data_dir: PathBuf,
    catalog: Catalog,
    heaps: BTreeMap<TableId, HeapTable>,
    indexes: BTreeMap<IndexId, BPlusTree>,
    // Rust drops fields in declaration order. Close active/dropped page handles,
    // then stop/join the last committed-store owner, before releasing the WAL.
    private_txn: Option<PrivateTransaction>,
    committed_store: Option<std::sync::Arc<phobos_storage::committed_pages::CommittedStore>>,
    buffer_pages: usize,
    query_memory_bytes: usize,
    last_access_path: Option<String>,
    last_plan: Option<String>,
    stats: BTreeMap<TableId, TableStatistics>,
    wal: Option<Wal>,
    wal_v2: Option<phobos_wal::v2::Wal>,
    fenced: bool,
    txn_manager: Option<TransactionManager>,
    active_txn: Option<ActiveTransaction>,
    private_staging: bool,
}

impl Database {
    /// True only for the quarantined pre-V2 compatibility engine whose writes
    /// use directory snapshots. Production server routing rejects this engine.
    #[must_use]
    pub fn uses_legacy_v1_copy_engine(&self) -> bool {
        self.wal_v2.is_none() && self.wal.is_some()
    }
    /// Apply validated startup knobs without changing the detected storage capability.
    pub fn open_with_config(
        data_dir: impl AsRef<Path>,
        config: &phobos_config::RuntimeConfig,
    ) -> Result<Self, PhobosError> {
        config.validate()?;
        phobos_storage::set_hint_bits_enabled(config.hint_bits_enabled);
        let mut database = Self::open_internal(data_dir, DEFAULT_BUFFER_PAGES, Some(config))?;
        database.query_memory_bytes = config.query_memory_bytes;
        Ok(database)
    }

    pub fn open(data_dir: impl AsRef<Path>) -> Result<Self, PhobosError> {
        Self::open_with_buffer_pages(data_dir, DEFAULT_BUFFER_PAGES)
    }

    pub fn open_with_buffer_pages(
        data_dir: impl AsRef<Path>,
        buffer_pages: usize,
    ) -> Result<Self, PhobosError> {
        Self::open_internal(data_dir, buffer_pages, None)
    }
    fn open_internal(
        data_dir: impl AsRef<Path>,
        buffer_pages: usize,
        config: Option<&phobos_config::RuntimeConfig>,
    ) -> Result<Self, PhobosError> {
        if buffer_pages == 0 {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "buffer pool size must be non-zero",
            ));
        }
        phobos_observability::measure("fs.create_dir_all", || {
            fs::create_dir_all(data_dir.as_ref())
        })?;
        let data_dir = data_dir.as_ref().to_path_buf();
        let wal_path = data_dir.join("phobos.wal");
        let v2 = if wal_path.exists() {
            let mut file = File::open(&wal_path)?;
            let mut prefix = [0; 6];
            (file.metadata()?.len() >= 6 && {
                file.read_exact(&mut prefix)?;
                prefix == *b"PHWL\x02\x00"
            }) || phobos_wal::v2::interrupted_rotation(&data_dir)?
        } else if phobos_wal::v2::interrupted_rotation(&data_dir)? {
            // 0.2-I.3: a V2 segment rotation was interrupted (no active WAL
            // yet). Never the V1 path, which would create a V1 WAL beside the
            // sealed V2 history; V2 recovery repairs the layout.
            true
        } else {
            // Existing legacy data without a WAL still follows legacy recovery.
            // A newly owned, empty directory starts with a durable V2 anchor.
            fs::read_dir(&data_dir)?.try_fold(true, |empty, entry| {
                Ok::<_, std::io::Error>(empty && entry?.file_name() == "phobos.lock")
            })?
        };
        if v2 {
            return match config {
                None => Self::open_v2_with_buffer_pages(&data_dir, buffer_pages),
                Some(config) => {
                    let mut flush = phobos_storage::committed_pages::FlushConfig::from_env()?;
                    flush.page_cache_bytes = config.page_cache_bytes;
                    Self::open_v2_config(&data_dir, buffer_pages, flush)
                }
            };
        }
        let recovery = recover(&data_dir)?;
        cleanup_transaction_dirs(&data_dir)?;
        cleanup_spill_dirs(&data_dir)?;
        let catalog = Catalog::open(&data_dir)?;
        cleanup_orphan_index_files(&data_dir, &catalog)?;
        let heaps = open_heaps(&data_dir, &catalog, buffer_pages)?;
        let indexes = open_indexes(&data_dir, &catalog)?;
        let mut wal = Wal::open(&data_dir)?;
        if recovery.redone_transactions > 0
            || recovery.ignored_incomplete_transactions > 0
            || recovery.truncated_tail
        {
            wal.checkpoint(u64::MAX)?;
            wal.rotate_after_checkpoint()?;
        }
        let txn_manager = TransactionManager::open(&data_dir)?;
        let stats = load_statistics(&data_dir)?;
        let mut database = Self {
            mvcc_view: false,
            data_dir,
            catalog,
            heaps,
            indexes,
            buffer_pages,
            query_memory_bytes: DEFAULT_QUERY_MEMORY_BYTES,
            last_access_path: None,
            last_plan: None,
            stats,
            wal: Some(wal),
            committed_store: None,
            wal_v2: None,
            private_txn: None,
            fenced: false,
            txn_manager: Some(txn_manager),
            active_txn: None,
            private_staging: false,
        };
        database.validate_canonical_unique()?;
        Ok(database)
    }

    // Called only for an owned transaction directory, never inferred from its name.
    fn open_staging(path: &Path, buffer_pages: usize) -> Result<Self, PhobosError> {
        let _profile = phobos_observability::span("execution.open_staging");
        let mut database = Self::open_with_buffer_pages(path, buffer_pages)?;
        database.private_staging = true;
        for heap in database.heaps.values_mut() {
            heap.defer_insert_flushes();
        }
        Ok(database)
    }

    pub fn execute(&mut self, sql: &str) -> Result<QueryResult, PhobosError> {
        self.execute_params(sql, &[])
    }

    /// Execute an already parsed, parameterless read. Session-local prepared
    /// statements use this narrow entry point so mutation admission remains on
    /// the ordinary SQL path.
    pub fn execute_prepared_read(
        &mut self,
        statement: Statement,
    ) -> Result<QueryResult, PhobosError> {
        self.ensure_available()?;
        if !is_read_statement(&statement) {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "prepared statements currently support read-only SQL",
            ));
        }
        phobos_error::cancellation::check_now()?;
        self.execute_statement_direct(statement, &[])
    }

    pub fn execute_params(
        &mut self,
        sql: &str,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        self.ensure_available()?;
        let statement = parse(sql)?;
        if !matches!(statement, Statement::Rollback) {
            phobos_error::cancellation::check_now()?;
        }
        match statement {
            Statement::Begin => self.begin_transaction(),
            Statement::BeginSnapshot
            | Statement::Savepoint { .. }
            | Statement::RollbackTo { .. }
            | Statement::ReleaseSavepoint { .. } => Err(PhobosError::new(
                ErrorCode::Unsupported,
                "Snapshot transactions and savepoints require the MVCC server route",
            )),
            Statement::Commit => self.commit_transaction(),
            Statement::Rollback => self.rollback_transaction(),
            Statement::Checkpoint => self.checkpoint(),
            statement => {
                if self.private_txn.is_some() {
                    return self.execute_private_statement(statement, params);
                }
                if let Some(transaction) = self.active_txn.as_mut() {
                    if transaction.failed {
                        return Err(PhobosError::new(
                            ErrorCode::TransactionState,
                            "current transaction is aborted; ROLLBACK is required",
                        ));
                    }
                    let read_only = matches!(
                        &statement,
                        Statement::Select { .. }
                            | Statement::ShowCatalog { .. }
                            | Statement::RelationalSelect(_)
                            | Statement::Explain { .. }
                    );
                    match transaction
                        .database
                        .execute_statement_direct(statement, params)
                    {
                        Ok(result) => Ok(result),
                        Err(error) => {
                            if !(read_only && phobos_error::cancellation::is_interrupted(&error)) {
                                transaction.failed = true;
                            }
                            Err(error)
                        }
                    }
                } else if matches!(
                    &statement,
                    Statement::Select { .. }
                        | Statement::ShowCatalog { .. }
                        | Statement::RelationalSelect(_)
                        | Statement::Explain { .. }
                ) {
                    self.execute_statement_direct(statement, params)
                } else {
                    self.execute_autocommit(statement, params)
                }
            }
        }
    }

    #[must_use]
    pub fn in_transaction(&self) -> bool {
        self.active_txn.is_some() || self.private_txn.is_some()
    }

    #[must_use]
    pub fn last_access_path(&self) -> Option<&str> {
        self.last_access_path.as_deref()
    }

    #[must_use]
    pub fn last_plan(&self) -> Option<&str> {
        self.last_plan.as_deref()
    }

    fn execute_statement_direct(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let statement = self.expand_views(statement)?;
        let _clock = sql_surface::StatementClock::enter();
        if self.catalog.has_foreign_keys()
            && matches!(
                statement,
                Statement::Insert { .. }
                    | Statement::InsertColumns { .. }
                    | Statement::Update { .. }
                    | Statement::Delete { .. }
            )
        {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "FK writes require MVCC admission",
            ));
        }
        match statement {
            Statement::ShowCatalog { kind, table } => {
                self.management_catalog(kind, table.as_deref())
            }
            Statement::CreateTable { name, columns } => self.create_table(name, columns),
            Statement::InsertReturning { .. }
            | Statement::InsertSelect { .. }
            | Statement::CreateView { .. }
            | Statement::DropView { .. }
            | Statement::CreateDefinedTable { .. }
            | Statement::AddColumn { .. }
            | Statement::AlterNullable { .. }
            | Statement::AlterDefault { .. }
            | Statement::RenameTable { .. }
            | Statement::CreatePartitionedTable { .. }
            | Statement::CreateRangePartition { .. } => Err(PhobosError::new(
                ErrorCode::Unsupported,
                "this DDL requires the MVCC server route",
            )),
            Statement::CreateIndex {
                name,
                table,
                columns,
                unique,
            } => self.create_index(name, &table, columns, unique),
            Statement::DropIndex { name } => self.drop_index(&name),
            Statement::InsertColumns {
                table,
                columns,
                rows,
            } => {
                let statement = expand_insert_columns(&self.catalog, table, columns, rows)?;
                self.execute_statement_direct(statement, params)
            }
            Statement::Insert { table, rows } => self.insert(&table, rows, params),
            Statement::Select {
                table,
                columns,
                filter,
                order_by,
                limit,
                offset,
            } => self.select(
                SelectRequest {
                    table,
                    selection: columns,
                    filter,
                    order_by,
                    limit,
                    offset,
                },
                params,
            ),
            statement @ Statement::Union { .. } => self.union_select(statement, params),
            Statement::RelationalSelect(query) => self.relational_select(query, params),
            Statement::Analyze { table } => self.analyze_table(&table),
            Statement::Explain { analyze, statement } => {
                self.explain_statement(*statement, analyze, params)
            }
            Statement::Update {
                table,
                assignments,
                filter,
            } => self.update(&table, &assignments, filter.as_ref(), params),
            Statement::Delete { table, filter } => self.delete(&table, filter.as_ref(), params),
            Statement::Begin
            | Statement::BeginSnapshot
            | Statement::Savepoint { .. }
            | Statement::RollbackTo { .. }
            | Statement::ReleaseSavepoint { .. }
            | Statement::Commit
            | Statement::Rollback
            | Statement::Checkpoint => Err(PhobosError::new(
                ErrorCode::TransactionState,
                "transaction control cannot execute as a data statement",
            )),
        }
    }

    fn begin_transaction(&mut self) -> Result<QueryResult, PhobosError> {
        if self.wal_v2.is_some() {
            return self.begin_private_transaction();
        }
        let _profile = phobos_observability::span("execution.begin_transaction");
        if self.active_txn.is_some() {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "a transaction is already active",
            ));
        }
        self.flush_storage()?;
        let id = self
            .txn_manager
            .as_mut()
            .expect("legacy transaction manager")
            .allocate()?;
        let temp_dir = transaction_dir(&self.data_dir, id);
        if temp_dir.exists() {
            phobos_observability::measure("fs.remove_dir_all", || fs::remove_dir_all(&temp_dir))?;
        }
        phobos_observability::measure("fs.create_dir_all", || fs::create_dir_all(&temp_dir))?;
        copy_database_files(&self.data_dir, &temp_dir)?;
        let mut database = Box::new(Self::open_staging(&temp_dir, self.buffer_pages)?);
        database.query_memory_bytes = self.query_memory_bytes;
        self.active_txn = Some(ActiveTransaction {
            id,
            temp_dir,
            database,
            failed: false,
        });
        Ok(QueryResult::Command {
            tag: "BEGIN".into(),
            rows_affected: 0,
        })
    }

    fn commit_transaction(&mut self) -> Result<QueryResult, PhobosError> {
        phobos_error::cancellation::commit()?;
        let _durability = phobos_error::cancellation::suspend();
        if self.wal_v2.is_some() {
            return self.commit_private_transaction();
        }
        let _profile = phobos_observability::span("execution.commit_transaction");
        if self
            .active_txn
            .as_ref()
            .is_some_and(|transaction| transaction.failed)
        {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "cannot COMMIT an aborted transaction; ROLLBACK is required",
            ));
        }
        let transaction = self.active_txn.take().ok_or_else(|| {
            PhobosError::new(
                ErrorCode::TransactionState,
                "COMMIT without an active transaction",
            )
        })?;
        let ActiveTransaction {
            id,
            temp_dir,
            mut database,
            ..
        } = transaction;
        database.flush_storage()?;
        drop(database);
        self.commit_snapshot(id, &temp_dir)?;
        let _ =
            phobos_observability::measure("fs.remove_dir_all", || fs::remove_dir_all(&temp_dir));
        Ok(QueryResult::Command {
            tag: "COMMIT".into(),
            rows_affected: 0,
        })
    }

    fn rollback_transaction(&mut self) -> Result<QueryResult, PhobosError> {
        if self.wal_v2.is_some() {
            return self.rollback_private_transaction();
        }
        let transaction = self.active_txn.take().ok_or_else(|| {
            PhobosError::new(
                ErrorCode::TransactionState,
                "ROLLBACK without an active transaction",
            )
        })?;
        let ActiveTransaction {
            temp_dir, database, ..
        } = transaction;
        drop(database);
        phobos_observability::measure("fs.remove_dir_all", || fs::remove_dir_all(temp_dir))?;
        Ok(QueryResult::Command {
            tag: "ROLLBACK".into(),
            rows_affected: 0,
        })
    }

    fn checkpoint(&mut self) -> Result<QueryResult, PhobosError> {
        phobos_error::cancellation::commit()?;
        let _durability = phobos_error::cancellation::suspend();
        if self.wal_v2.is_some() {
            return self.checkpoint_private();
        }
        if self.active_txn.is_some() {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "CHECKPOINT is not allowed inside an active transaction",
            ));
        }
        self.flush_storage()?;
        self.wal
            .as_mut()
            .expect("legacy WAL")
            .checkpoint(u64::MAX)?;
        self.wal
            .as_mut()
            .expect("legacy WAL")
            .rotate_after_checkpoint()?;
        Ok(QueryResult::Command {
            tag: "CHECKPOINT".into(),
            rows_affected: 0,
        })
    }

    fn execute_autocommit(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let _profile = phobos_observability::span("execution.execute_autocommit");
        if self.wal_v2.is_some() {
            return self.execute_private_autocommit(statement, params);
        }
        self.flush_storage()?;
        let id = self
            .txn_manager
            .as_mut()
            .expect("legacy transaction manager")
            .allocate()?;
        let temp_dir = transaction_dir(&self.data_dir, id);
        if temp_dir.exists() {
            phobos_observability::measure("fs.remove_dir_all", || fs::remove_dir_all(&temp_dir))?;
        }
        phobos_observability::measure("fs.create_dir_all", || fs::create_dir_all(&temp_dir))?;
        copy_database_files(&self.data_dir, &temp_dir)?;
        let mut staged = Self::open_staging(&temp_dir, self.buffer_pages)?;
        staged.query_memory_bytes = self.query_memory_bytes;
        let result = match staged.execute_statement_direct(statement, params) {
            Ok(result) => result,
            Err(error) => {
                drop(staged);
                let _ = phobos_observability::measure("fs.remove_dir_all", || {
                    fs::remove_dir_all(&temp_dir)
                });
                return Err(error);
            }
        };
        staged.flush_storage()?;
        drop(staged);
        self.commit_snapshot(id, &temp_dir)?;
        let _ =
            phobos_observability::measure("fs.remove_dir_all", || fs::remove_dir_all(&temp_dir));
        Ok(result)
    }

    fn commit_snapshot(&mut self, id: TransactionId, temp_dir: &Path) -> Result<(), PhobosError> {
        phobos_error::cancellation::commit()?;
        let _durability = phobos_error::cancellation::suspend();
        let _profile = phobos_observability::span("execution.commit_snapshot");
        let commit_lsn = self
            .wal
            .as_mut()
            .expect("legacy WAL")
            .write_transaction_snapshot(id, temp_dir)?;
        if std::env::var("PHOBOS_CRASH_POINT").as_deref() == Ok("after_wal_commit") {
            std::process::abort();
        }
        self.heaps.clear();
        self.indexes.clear();
        phobos_observability::certification_crash("before_installation");
        install_snapshot(temp_dir, &self.data_dir)?;
        self.reload_storage()?;
        self.wal
            .as_mut()
            .expect("legacy WAL")
            .checkpoint(commit_lsn)?;
        self.wal
            .as_mut()
            .expect("legacy WAL")
            .rotate_after_checkpoint()?;
        Ok(())
    }

    fn flush_storage(&mut self) -> Result<(), PhobosError> {
        let _measurement = phobos_observability::span("execution.flush_storage");
        for heap in self.heaps.values_mut() {
            heap.flush()?;
        }
        for index in self.indexes.values_mut() {
            index.sync()?;
        }
        Ok(())
    }

    fn reload_storage(&mut self) -> Result<(), PhobosError> {
        let _profile = phobos_observability::span("execution.reload_storage");
        self.catalog = Catalog::open(&self.data_dir)?;
        cleanup_orphan_index_files(&self.data_dir, &self.catalog)?;
        self.heaps = open_heaps(&self.data_dir, &self.catalog, self.buffer_pages)?;
        self.indexes = open_indexes(&self.data_dir, &self.catalog)?;
        self.stats = load_statistics(&self.data_dir)?;
        Ok(())
    }

    fn create_table(
        &mut self,
        name: String,
        columns: Vec<ColumnSchema>,
    ) -> Result<QueryResult, PhobosError> {
        if columns.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "table must have at least one column",
            ));
        }
        for (i, column) in columns.iter().enumerate() {
            if columns[..i]
                .iter()
                .any(|c| c.name.eq_ignore_ascii_case(&column.name))
            {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    format!("duplicate column {}", column.name),
                ));
            }
        }
        let schema = self.catalog.create_table(name, columns)?;
        let table_id = schema.id;
        let mut heap = HeapTable::open(
            heap_path(self.private_directory(), table_id),
            schema,
            self.buffer_pages,
        )?;
        if self.private_staging {
            heap.defer_insert_flushes();
        }
        if let Some(tx) = &self.private_txn {
            heap.begin_private(
                &tx.temp_dir.join(format!("heap-{table_id}.private")),
                tx.id,
                &self.data_dir,
            )?;
        }
        self.heaps.insert(table_id, heap);
        Ok(QueryResult::Command {
            tag: "CREATE TABLE".into(),
            rows_affected: 0,
        })
    }

    fn create_index(
        &mut self,
        name: String,
        table: &str,
        columns: Vec<String>,
        unique: bool,
    ) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let table_schema = self.table_schema(table)?;
        let index_schema = self
            .catalog
            .create_index(name, table_schema.id, columns, unique)?;
        let path = index_path(self.private_directory(), index_schema.id);
        let build_result = (|| -> Result<BPlusTree, PhobosError> {
            let mut tree = BPlusTree::open(&path, index_schema.unique, index_schema.columns.len())?;
            if let Some(tx) = &self.private_txn {
                tree.begin_private(
                    &tx.temp_dir
                        .join(format!("index-{}.private", index_schema.id)),
                    tx.id,
                    &self.data_dir,
                )?;
            }
            let rows = self.heap_mut(table_schema.id)?.scan()?;
            for (rid, row) in rows {
                cancellation_poll.checkpoint_at("lib.create_index")?;
                tree.insert(index_key_for_row(&table_schema, &index_schema, &row)?, rid)?;
            }
            tree.sync()?;
            let _ = tree.validate()?;
            Ok(tree)
        })();
        let tree = match build_result {
            Ok(tree) => tree,
            Err(error) => {
                let _ = self.catalog.drop_index(&index_schema.name);
                let _ = phobos_observability::measure("fs.remove_file", || fs::remove_file(&path));
                return Err(error);
            }
        };
        self.indexes.insert(index_schema.id, tree);
        Ok(QueryResult::Command {
            tag: "CREATE INDEX".into(),
            rows_affected: 0,
        })
    }

    fn drop_index(&mut self, name: &str) -> Result<QueryResult, PhobosError> {
        let schema = self.catalog.drop_index(name)?;
        let tree = self.indexes.remove(&schema.id);
        if let Some(tx) = &mut self.private_txn {
            if let Some(tree) = tree {
                if tree.path().parent() == Some(tx.temp_dir.as_path()) {
                    let path = tree.path().to_path_buf();
                    drop(tree);
                    fs::remove_file(path)?;
                } else {
                    tx.dropped_indexes.insert(schema.id, tree);
                }
            }
            return Ok(QueryResult::Command {
                tag: "DROP INDEX".into(),
                rows_affected: 0,
            });
        }
        drop(tree);
        let path = index_path(&self.data_dir, schema.id);
        if path.exists() {
            phobos_observability::measure("fs.remove_file", || fs::remove_file(path))?;
        }
        Ok(QueryResult::Command {
            tag: "DROP INDEX".into(),
            rows_affected: 0,
        })
    }

    fn insert(
        &mut self,
        table: &str,
        input_rows: Vec<Vec<Expr>>,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let schema = self.table_schema(table)?;
        if self
            .catalog
            .definitions(schema.id)
            .is_some_and(|d| d.identity.is_some())
        {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "identity writes require MVCC",
            ));
        }
        let mut rows = Vec::with_capacity(input_rows.len());
        for exprs in input_rows {
            cancellation_poll.checkpoint_at("lib.insert")?;
            if exprs.len() != schema.columns.len() {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    format!(
                        "table {} expects {} values, got {}",
                        schema.name,
                        schema.columns.len(),
                        exprs.len()
                    ),
                ));
            }
            let mut values = Vec::with_capacity(exprs.len());
            for (column, expr) in schema.columns.iter().zip(&exprs) {
                cancellation_poll.checkpoint_at("lib.insert")?;
                values.push(coerce_value(
                    column,
                    eval_expr(expr, &schema, None, params)?,
                )?);
            }
            let row = Row::new(values);
            self.catalog.validate_row_definitions(schema.id, &row)?;
            rows.push(row);
        }
        let count = rows.len() as u64;
        for row in &rows {
            cancellation_poll.checkpoint_at("lib.insert")?;
            let rid = {
                let heap = self.heap_mut(schema.id)?;
                heap.insert(row)?
            };
            self.insert_index_entries(&schema, row, rid)?;
        }
        self.mark_statistics_changed(schema.id, count as i64, count)?;
        self.flush_storage()?;
        Ok(QueryResult::Command {
            tag: "INSERT".into(),
            rows_affected: count,
        })
    }

    fn select(
        &mut self,
        request: SelectRequest,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let schema = self.table_schema(&request.table)?;
        let (columns, indexes) = projection(&schema, request.selection)?;
        let order_indexes = bind_order(&schema, &request.order_by)?;
        let limit = eval_count(request.limit.as_ref(), params, "LIMIT")?;
        let offset = eval_count(request.offset.as_ref(), params, "OFFSET")?.unwrap_or(0);
        let planned = self.plan_index_search(&schema, request.filter.as_ref(), params)?;
        let mut rows = Vec::new();
        if let Some(search) = planned {
            self.last_access_path = Some(format!("INDEX {}", search.index_name));
            let key_columns = index_key_columns(&self.catalog, &schema, search.index_id)?;
            let entries = self.run_index_search_entries(&search)?;
            for (key, rid) in entries {
                cancellation_poll.checkpoint_at("lib.select")?;
                let row = {
                    let heap = self.heap_mut(schema.id)?;
                    heap.get(rid)?
                };
                // 0.2-K Part H: identity re-validation (stale RID -> skip).
                let row = match (row, &key) {
                    (Some(row), Some(key)) if !row_matches_key(&row, &key_columns, key) => {
                        stale_rid_skipped();
                        None
                    }
                    (row, _) => row,
                };
                if let Some(row) = row {
                    if matches_filter(request.filter.as_ref(), &schema, &row, params)? {
                        rows.push(row);
                    }
                }
            }
        } else {
            self.last_access_path = Some("TABLE SCAN".into());
            let snapshot = phobos_observability::measure("execution.dml_scan", || {
                self.heap_mut(schema.id)?.scan()
            })?;
            phobos_observability::event("execution.dml_candidates", snapshot.len() as u64);
            for (_, row) in snapshot {
                cancellation_poll.checkpoint_at("lib.select")?;
                if matches_filter(request.filter.as_ref(), &schema, &row, params)? {
                    rows.push(row);
                }
            }
        }
        if !order_indexes.is_empty() {
            rows = if let Some(k) = limit.and_then(|limit| limit.checked_add(offset)) {
                let mut top = bounded_sort::TopK::new(order_indexes.clone(), k);
                for row in rows {
                    top.push(row)?;
                }
                top.finish()?
            } else {
                external_sort_rows(
                    rows,
                    &order_indexes,
                    self.query_memory_bytes,
                    &self.data_dir,
                )?
            };
        }
        let rows = rows
            .into_iter()
            .skip(offset)
            .take(limit.unwrap_or(usize::MAX))
            .map(|row| project_row(&row, &indexes))
            .collect();
        Ok(QueryResult::Rows { columns, rows })
    }

    fn update(
        &mut self,
        table: &str,
        assignments: &[(String, Expr)],
        filter: Option<&Expr>,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let _profile = phobos_observability::span("execution.update");
        let schema = self.table_schema(table)?;
        let mut bound: Vec<(usize, &Expr)> = Vec::with_capacity(assignments.len());
        for (name, expr) in assignments {
            cancellation_poll.checkpoint_at("lib.update")?;
            let index = schema.column_index(name).ok_or_else(|| {
                PhobosError::new(ErrorCode::NotFound, format!("column {name} does not exist"))
            })?;
            if bound.iter().any(|(existing, _)| *existing == index) {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    format!("column {name} assigned more than once"),
                ));
            }
            bound.push((index, expr));
        }
        let snapshot = self.dml_snapshot(&schema, filter, params)?;
        let mut changes: Vec<(RecordId, Row, Row)> = Vec::new();
        for (rid, row) in snapshot {
            cancellation_poll.checkpoint_at("lib.update")?;
            if !matches_filter(filter, &schema, &row, params)? {
                continue;
            }
            let mut next = row.clone();
            for (index, expr) in &bound {
                cancellation_poll.checkpoint_at("lib.update")?;
                next.values[*index] = coerce_value(
                    &schema.columns[*index],
                    eval_expr(expr, &schema, Some(&row), params)?,
                )?;
            }
            self.catalog.validate_row_definitions(schema.id, &next)?;
            changes.push((rid, row, next));
        }
        let count = changes.len() as u64;
        for (rid, old_row, new_row) in changes {
            cancellation_poll.checkpoint_at("lib.update")?;
            self.delete_index_entries(&schema, &old_row, rid)?;
            let new_rid = {
                let heap = self.heap_mut(schema.id)?;
                heap.replace(rid, &new_row)?
            };
            self.insert_index_entries(&schema, &new_row, new_rid)?;
        }
        self.mark_statistics_changed(schema.id, 0, count)?;
        self.flush_storage()?;
        Ok(QueryResult::Command {
            tag: "UPDATE".into(),
            rows_affected: count,
        })
    }

    fn delete(
        &mut self,
        table: &str,
        filter: Option<&Expr>,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let _profile = phobos_observability::span("execution.delete");
        let schema = self.table_schema(table)?;
        let snapshot = self.dml_snapshot(&schema, filter, params)?;
        let mut deleted = Vec::new();
        for (rid, row) in snapshot {
            cancellation_poll.checkpoint_at("lib.delete")?;
            if matches_filter(filter, &schema, &row, params)? {
                deleted.push((rid, row));
            }
        }
        let count = deleted.len() as u64;
        for (rid, row) in deleted {
            cancellation_poll.checkpoint_at("lib.delete")?;
            self.delete_index_entries(&schema, &row, rid)?;
            let heap = self.heap_mut(schema.id)?;
            let _ = heap.delete(rid)?;
        }
        self.mark_statistics_changed(schema.id, -(count as i64), count)?;
        self.flush_storage()?;
        Ok(QueryResult::Command {
            tag: "DELETE".into(),
            rows_affected: count,
        })
    }

    fn insert_index_entries(
        &mut self,
        table: &TableSchema,
        row: &Row,
        rid: RecordId,
    ) -> Result<(), PhobosError> {
        let _measurement = phobos_observability::span("execution.index_maintenance");
        let definitions: Vec<IndexSchema> =
            self.catalog.indexes_for_table(table.id).cloned().collect();
        for definition in definitions {
            let key = index_key_for_row(table, &definition, row)?;
            self.indexes
                .get_mut(&definition.id)
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "catalog index file is missing")
                })?
                .insert(key, rid)?;
        }
        Ok(())
    }

    fn delete_index_entries(
        &mut self,
        table: &TableSchema,
        row: &Row,
        rid: RecordId,
    ) -> Result<(), PhobosError> {
        let definitions: Vec<IndexSchema> =
            self.catalog.indexes_for_table(table.id).cloned().collect();
        for definition in definitions {
            let key = index_key_for_row(table, &definition, row)?;
            let removed = self
                .indexes
                .get_mut(&definition.id)
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "catalog index file is missing")
                })?
                .delete(&key, rid)?;
            if !removed {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "index entry missing for heap record",
                ));
            }
        }
        Ok(())
    }

    fn mark_statistics_changed(
        &mut self,
        table_id: TableId,
        row_delta: i64,
        changed: u64,
    ) -> Result<(), PhobosError> {
        if let Some(stats) = self.stats.get_mut(&table_id) {
            stats.row_count = if row_delta < 0 {
                stats.row_count.saturating_sub(row_delta.unsigned_abs())
            } else {
                stats.row_count.saturating_add(row_delta as u64)
            };
            stats.changed_rows = stats.changed_rows.saturating_add(changed);
            persist_statistics(self.private_directory(), &self.stats)?;
        }
        Ok(())
    }

    fn plan_index_search(
        &self,
        table: &TableSchema,
        filter: Option<&Expr>,
        params: &[Value],
    ) -> Result<Option<IndexSearch>, PhobosError> {
        let Some(filter) = filter else {
            return Ok(None);
        };
        // Index pruning changes which rows the filter is evaluated on. That is
        // only invisible when the filter cannot raise an error on any row.
        if !index_bounds::filter_is_total(filter, table, params) {
            return Ok(None);
        }
        let mut candidate: Option<(f64, IndexSearch)> = None;
        for definition in self.catalog.indexes_for_table(table.id) {
            if self.mvcc_view && !self.indexes.contains_key(&definition.id) {
                continue;
            }
            if let Some(search) = build_index_search(table, definition, filter, params)? {
                let rows = self
                    .stats
                    .get(&table.id)
                    .map_or(1000, |stats| stats.row_count.max(1)) as f64;
                let selectivity =
                    estimate_index_selectivity(self.stats.get(&table.id), definition, filter);
                let cost = index_access_cost(rows * selectivity, search.ranges.len());
                if candidate.as_ref().is_none_or(|(best, _)| cost < *best) {
                    candidate = Some((cost, search));
                }
            }
        }
        let Some((index_cost, search)) = candidate else {
            return Ok(None);
        };

        if let Some(stats) = self.stats.get(&table.id) {
            let rows = stats.row_count.max(1) as f64;
            let sequential_cost = rows;
            if index_cost >= sequential_cost {
                return Ok(None);
            }
        }
        Ok(Some(search))
    }

    fn run_index_search(&mut self, search: &IndexSearch) -> Result<Vec<RecordId>, PhobosError> {
        let mut result = self.run_physical_index_search(search)?;
        if !self.mvcc_view {
            return Ok(result);
        }
        let table = self
            .catalog
            .indexes()
            .find(|index| index.id == search.index_id)
            .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "index definition missing"))?
            .table_id;
        result.extend(self.heap_mut(table)?.overlay_ids()?);
        Ok(result)
    }

    /// 0.2-K Part H: `run_index_search` with each physical entry's key (own
    /// overlay rows carry `None`: they are this transaction's own images).
    fn run_index_search_entries(
        &mut self,
        search: &IndexSearch,
    ) -> Result<Vec<(Option<IndexKey>, RecordId)>, PhobosError> {
        let tree = self.indexes.get_mut(&search.index_id).ok_or_else(|| {
            PhobosError::new(ErrorCode::InvalidCatalog, "catalog index file is missing")
        })?;
        let mut result = Vec::new();
        for range in &search.ranges {
            let mut push = |key: &IndexKey, rid: RecordId| {
                result.push((Some(key.clone()), rid));
                Ok(true)
            };
            match &range.prefix {
                Some(prefix) => tree.prefix_visit_keyed(prefix, &mut push)?,
                None => {
                    tree.range_visit_keyed(range.lower_bound(), range.upper_bound(), &mut push)?
                }
            }
        }
        if self.mvcc_view {
            let table = self
                .catalog
                .indexes()
                .find(|index| index.id == search.index_id)
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "index definition missing")
                })?
                .table_id;
            result.extend(
                self.heap_mut(table)?
                    .overlay_ids()?
                    .into_iter()
                    .map(|rid| (None, rid)),
            );
        }
        Ok(result)
    }

    fn run_physical_index_search(
        &mut self,
        search: &IndexSearch,
    ) -> Result<Vec<RecordId>, PhobosError> {
        let tree = self.indexes.get_mut(&search.index_id).ok_or_else(|| {
            PhobosError::new(ErrorCode::InvalidCatalog, "catalog index file is missing")
        })?;
        let mut result = Vec::new();
        for range in &search.ranges {
            let rids = match (&range.prefix, &range.lower, &range.upper) {
                (Some(prefix), _, _) => {
                    let mut rids = Vec::new();
                    tree.prefix_visit(prefix, |rid| {
                        rids.push(rid);
                        Ok(true)
                    })?;
                    rids
                }
                (None, Some((lower, true)), Some((upper, true))) if lower == upper => {
                    tree.point_lookup(lower)?
                }
                _ => tree.range(range.lower_bound(), range.upper_bound())?,
            };
            result.extend(rids);
        }
        Ok(result)
    }

    fn analyze_table(&mut self, table: &str) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let schema = self.table_schema(table)?;
        let rows = self.heap_mut(schema.id)?.scan()?;
        let mut statistics = TableStatistics {
            row_count: rows.len() as u64,
            generation: self
                .stats
                .get(&schema.id)
                .map_or(1, |stats| stats.generation.saturating_add(1)),
            changed_rows: 0,
            columns: BTreeMap::new(),
        };
        for (column_index, column) in schema.columns.iter().enumerate() {
            cancellation_poll.checkpoint_at("lib.analyze_table")?;
            let mut distinct = HashSet::new();
            let mut null_count = 0u64;
            let mut min: Option<Value> = None;
            let mut max: Option<Value> = None;
            for (_, row) in &rows {
                cancellation_poll.checkpoint_at("lib.analyze_table")?;
                let value = &row.values[column_index];
                if value.is_null() {
                    null_count += 1;
                    continue;
                }
                distinct.insert(value.canonical_key());
                if min.as_ref().is_none_or(|current| {
                    compare_for_sort(value, current).unwrap_or(Ordering::Equal) == Ordering::Less
                }) {
                    min = Some(value.clone());
                }
                if max.as_ref().is_none_or(|current| {
                    compare_for_sort(value, current).unwrap_or(Ordering::Equal) == Ordering::Greater
                }) {
                    max = Some(value.clone());
                }
            }
            statistics.columns.insert(
                column.name.to_ascii_lowercase(),
                ColumnStatistics {
                    distinct_count: distinct.len() as u64,
                    null_count,
                    min_text: min.map(|value| value.to_string()),
                    max_text: max.map(|value| value.to_string()),
                },
            );
        }
        self.stats.insert(schema.id, statistics);
        persist_statistics(self.private_directory(), &self.stats)?;
        Ok(QueryResult::Command {
            tag: "ANALYZE".into(),
            rows_affected: rows.len() as u64,
        })
    }

    fn explain_statement(
        &mut self,
        statement: Statement,
        analyze: bool,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let plan = match &statement {
            Statement::Select {
                table,
                filter,
                order_by,
                limit,
                ..
            } => {
                let schema = self.table_schema(table)?;
                self.describe_simple_plan(
                    &schema,
                    filter.as_ref(),
                    order_by,
                    limit.is_some(),
                    params,
                )?
            }
            Statement::RelationalSelect(query) => self.describe_relational_plan(query)?,
            _ => {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    "EXPLAIN supports SELECT only",
                ));
            }
        };
        let mut lines: Vec<Row> = plan
            .lines()
            .map(|line| Row::new(vec![Value::Text(line.to_string())]))
            .collect();
        if analyze {
            let started = Instant::now();
            let result = self.execute_statement_direct(statement, params)?;
            let rows = match &result {
                QueryResult::Rows { rows, .. } => rows.len() as u64,
                QueryResult::Command { rows_affected, .. } => *rows_affected,
            };
            lines.push(Row::new(vec![Value::Text(format!(
                "actual rows={rows} elapsed_ms={:.3}",
                started.elapsed().as_secs_f64() * 1000.0
            ))]));
        }
        self.last_plan = Some(plan);
        Ok(QueryResult::Rows {
            columns: vec!["plan".into()],
            rows: lines,
        })
    }

    fn describe_simple_plan(
        &self,
        schema: &TableSchema,
        filter: Option<&Expr>,
        order_by: &[OrderBy],
        has_limit: bool,
        params: &[Value],
    ) -> Result<String, PhobosError> {
        let row_count = self
            .stats
            .get(&schema.id)
            .map_or(1000, |stats| stats.row_count.max(1));
        let index = self.plan_index_search(schema, filter, params)?;
        let (access, estimated_rows, cost) = if let Some(search) = index {
            let selectivity =
                estimate_filter_selectivity(self.stats.get(&schema.id), schema, filter);
            let estimated = ((row_count as f64) * selectivity).ceil().max(1.0) as u64;
            (
                format!("Index Scan using {} on {}", search.index_name, schema.name),
                estimated,
                index_access_cost(estimated as f64, 1),
            )
        } else {
            (
                format!("Seq Scan on {}", schema.name),
                row_count,
                row_count as f64,
            )
        };
        let mut plan = format!("{access}  (cost={cost:.2} rows={estimated_rows})");
        let freshness = self
            .stats
            .get(&schema.id)
            .map_or("absent", TableStatistics::freshness);
        plan.push_str(&format!(
            "\n  Query Memory: {} bytes; statistics={freshness}",
            self.query_memory_bytes
        ));
        if filter.is_some() {
            plan.push_str("\n  Filter");
        }
        if !order_by.is_empty() {
            plan.push_str(if has_limit { "\n  Top-K" } else { "\n  Sort" });
        }
        Ok(plan)
    }

    fn relation_schema(
        &self,
        table: &str,
        alias: Option<&str>,
    ) -> Result<TableSchema, PhobosError> {
        let mut schema = self.table_schema(table)?;
        if let Some(alias) = alias {
            schema.name = alias.to_owned();
        }
        Ok(schema)
    }

    fn describe_relational_plan(&self, query: &RelationalSelect) -> Result<String, PhobosError> {
        if query.table.is_empty() {
            return Ok("Constant Row".into());
        }
        if query.source.is_none() && self.catalog.view(&query.table).is_some() {
            let Statement::RelationalSelect(expanded) =
                self.expand_views(Statement::RelationalSelect(query.clone()))?
            else {
                unreachable!()
            };
            return self.describe_relational_plan(&expanded);
        }
        if (query.source.is_none() && self.catalog.partition_key(&query.table).is_some())
            || query
                .joins
                .iter()
                .any(|j| self.catalog.partition_key(&j.table).is_some())
        {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "advanced queries over partition parents are not yet supported",
            ));
        }
        let mut qualifiers = std::collections::BTreeSet::new();
        for qualifier in std::iter::once(query.alias.as_deref().unwrap_or(&query.table)).chain(
            query
                .joins
                .iter()
                .map(|j| j.alias.as_deref().unwrap_or(&j.table)),
        ) {
            if !qualifiers.insert(qualifier.to_ascii_lowercase()) {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "duplicate relation qualifier; use distinct aliases",
                ));
            }
        }
        if let Some(source) = &query.source {
            let inner = match source.as_ref() {
                Statement::Union { .. } => "Union".into(),
                Statement::RelationalSelect(q) => self.describe_relational_plan(q)?,
                Statement::Select { table, .. } => {
                    self.query_relation_schema(table)?;
                    format!("Scan on {table}")
                }
                _ => {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "derived input must be read-only",
                    ));
                }
            };
            return Ok(format!(
                "Derived Scan on {}\n{inner}",
                query.alias.as_deref().unwrap_or(&query.table)
            ));
        }
        let left = self.table_schema(&query.table)?;
        let left_rows = self
            .stats
            .get(&left.id)
            .map_or(1000, |s| s.row_count.max(1));
        let left_freshness = self
            .stats
            .get(&left.id)
            .map_or("absent", TableStatistics::freshness);
        let mut plan = format!(
            "Seq Scan on {}  (rows={left_rows}; statistics={left_freshness})\nQuery Memory: {} bytes",
            left.name, self.query_memory_bytes
        );
        for join in &query.joins {
            let right = self.table_schema(&join.table)?;
            let right_rows = self
                .stats
                .get(&right.id)
                .map_or(1000, |s| s.row_count.max(1));
            let right_bytes = right_rows.saturating_mul(estimated_schema_row_bytes(&right) as u64);
            let method = if join.predicate.is_some() {
                "Nested Loop Join"
            } else if right_bytes <= self.query_memory_bytes as u64 {
                "Hash Join"
            } else {
                "Grace Hash Join (build=right probe=left)"
            };
            plan.push_str(&format!(
                "\n{method} {} {}  (left-deep stage; left_rows={left_rows} right_rows={right_rows})",
                match join.kind {
                    JoinKind::Inner => "INNER",
                    JoinKind::Left => "LEFT",
                },
                right.name
            ));
        }
        if !query.group_by.is_empty()
            || query
                .items
                .iter()
                .any(|item| matches!(item, SelectItem::Aggregate { .. }))
        {
            let estimated_bytes =
                left_rows.saturating_mul(estimated_schema_row_bytes(&left) as u64);
            plan.push_str(if estimated_bytes <= self.query_memory_bytes as u64 {
                "\nHash Aggregate"
            } else {
                "\nSpilled Hash Aggregate"
            });
        }
        if !query.order_by.is_empty() {
            if query.limit.is_some() {
                plan.push_str("\nTop-K");
            } else {
                plan.push_str("\nSort (external spill when byte budget is exceeded)");
            }
        }
        Ok(plan)
    }

    fn relational_select(
        &mut self,
        mut query: RelationalSelect,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        self.resolve_query_subqueries(&mut query, params)?;
        let plan = self.describe_relational_plan(&query)?;
        self.last_plan = Some(plan.clone());
        self.last_access_path = Some("RELATIONAL PLAN".into());

        let materialize = phobos_observability::span("aggregate.materialize");
        let mut relation = if query.table.is_empty() {
            Relation {
                names: Vec::new(),
                qualified_names: Vec::new(),
                rows: vec![Row::new(Vec::new())],
            }
        } else if let Some(source) = query.source.as_ref() {
            let QueryResult::Rows { mut columns, rows } =
                self.execute_subquery((**source).clone(), params)?
            else {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "derived input must return rows",
                ));
            };
            if let Statement::RelationalSelect(inner) = source.as_ref() {
                if inner.items.len() == columns.len() {
                    for (column, item) in columns.iter_mut().zip(&inner.items) {
                        if let SelectItem::Column { name, alias: None } = item {
                            *column = name.rsplit('.').next().unwrap_or(name).to_owned();
                        }
                    }
                }
            }
            let qualifier = query.alias.as_deref().unwrap_or(&query.table);
            Relation {
                qualified_names: columns.iter().map(|c| format!("{qualifier}.{c}")).collect(),
                names: columns,
                rows,
            }
        } else {
            let left_schema = self.relation_schema(&query.table, query.alias.as_deref())?;
            if !query.distinct
                && query.joins.is_empty()
                && query.filter.is_none()
                && query.group_by.is_empty()
                && query.having.is_none()
                && query.order_by.is_empty()
                && query.limit.is_none()
                && query.offset.is_none()
                && matches!(
                    query.items.as_slice(),
                    [SelectItem::Aggregate {
                        function: AggregateFunction::Count,
                        column: None,
                        ..
                    }]
                )
            {
                let count = self.heap_mut(left_schema.id)?.count_visible()?;
                let count = i64::try_from(count).map_err(|_| {
                    PhobosError::new(ErrorCode::ResourceLimit, "COUNT(*) exceeds BIGINT")
                })?;
                return Ok(QueryResult::Rows {
                    columns: vec![select_item_name(&query.items[0])],
                    rows: vec![Row {
                        values: vec![Value::Int64(count)],
                    }],
                });
            }
            let left_rows = self.heap_mut(left_schema.id)?.scan()?;
            Relation {
                names: left_schema
                    .columns
                    .iter()
                    .map(|column| column.name.clone())
                    .collect(),
                qualified_names: left_schema
                    .columns
                    .iter()
                    .map(|column| format!("{}.{}", left_schema.name, column.name))
                    .collect(),
                rows: left_rows.into_iter().map(|(_, row)| row).collect(),
            }
        };

        for join in &query.joins {
            relation = self.join_relation(relation, join, &query, params)?;
        }

        if let Some(filter) = query.filter.as_ref() {
            let names = relation.names.clone();
            let qualified_names = relation.qualified_names.clone();
            let mut filtered = Vec::with_capacity(relation.rows.len());
            for row in relation.rows {
                cancellation_poll.checkpoint_at("lib.relational_select")?;
                let mut resolved = filter.clone();
                self.resolve_exists_for_row(&mut resolved, &qualified_names, &row, params)?;
                if matches_filter_relation(&resolved, &names, &qualified_names, &row, params)? {
                    filtered.push(row);
                }
            }
            relation.rows = filtered;
        }
        drop(materialize);

        let has_aggregate = query
            .items
            .iter()
            .any(|item| matches!(item, SelectItem::Aggregate { .. }));
        validate_grouping(&query.items, &query.group_by, has_aggregate, &relation)?;
        let mut output = if has_aggregate || !query.group_by.is_empty() {
            aggregate_relation(
                relation,
                &query.items,
                &query.group_by,
                self.query_memory_bytes,
                &self.data_dir,
            )?
        } else {
            project_relation(relation, &query.items, params)?
        };

        if query.distinct {
            output.rows = distinct_rows(output.rows, self.query_memory_bytes, &self.data_dir)?;
        }

        if let Some(having) = query.having.as_ref() {
            let names = output.names.clone();
            let qualified_names = output.qualified_names.clone();
            let mut filtered = Vec::with_capacity(output.rows.len());
            for row in output.rows {
                cancellation_poll.checkpoint_at("lib.relational_select")?;
                if matches_filter_relation(having, &names, &qualified_names, &row, params)? {
                    filtered.push(row);
                }
            }
            output.rows = filtered;
        }

        let limit = eval_count(query.limit.as_ref(), params, "LIMIT")?;
        let offset = eval_count(query.offset.as_ref(), params, "OFFSET")?.unwrap_or(0);
        if !query.order_by.is_empty() {
            let order = bind_relation_order(&output, &query.order_by)?;
            output.rows = if let Some(k) = limit.and_then(|limit| limit.checked_add(offset)) {
                let mut top = bounded_sort::TopK::new(order, k);
                for row in output.rows {
                    top.push(row)?;
                }
                top.finish()?
            } else {
                external_sort_rows(output.rows, &order, self.query_memory_bytes, &self.data_dir)?
            };
        }
        let rows = output
            .rows
            .into_iter()
            .skip(offset)
            .take(limit.unwrap_or(usize::MAX))
            .collect();
        Ok(QueryResult::Rows {
            columns: output.names,
            rows,
        })
    }

    fn join_relation(
        &mut self,
        left: Relation,
        join: &phobos_sql::JoinClause,
        query: &RelationalSelect,
        params: &[Value],
    ) -> Result<Relation, PhobosError> {
        let right_schema = self.relation_schema(&join.table, join.alias.as_deref())?;
        let right_rows: Vec<Row> = self
            .heap_mut(right_schema.id)?
            .scan()?
            .into_iter()
            .map(|(_, row)| row)
            .collect();

        let mut names = left.names.clone();
        names.extend(
            right_schema
                .columns
                .iter()
                .map(|column| column.name.clone()),
        );
        let mut qualified_names = left.qualified_names.clone();
        qualified_names.extend(
            right_schema
                .columns
                .iter()
                .map(|column| format!("{}.{}", right_schema.name, column.name)),
        );

        if let Some(predicate) = &join.predicate {
            let mut rows = Vec::new();
            let mut output_bytes = 0usize;
            let mut retain = |row: Row| -> Result<(), PhobosError> {
                output_bytes = output_bytes.saturating_add(row_bytes(&row));
                if output_bytes > self.query_memory_bytes {
                    return Err(PhobosError::new(
                        ErrorCode::ResourceLimit,
                        "predicate join output exceeds query memory budget",
                    ));
                }
                rows.push(row);
                Ok(())
            };
            let mut poller = phobos_error::cancellation::Poller::default();
            for l in &left.rows {
                let mut matched = false;
                for r in &right_rows {
                    poller.checkpoint_at("enterprise.join.predicate")?;
                    let mut values = l.values.clone();
                    values.extend(r.values.iter().cloned());
                    let row = Row::new(values);
                    if matches_filter_relation(predicate, &names, &qualified_names, &row, params)? {
                        retain(row)?;
                        matched = true;
                    }
                }
                if !matched && join.kind == JoinKind::Left {
                    let mut values = l.values.clone();
                    values.extend((0..right_schema.columns.len()).map(|_| Value::Null));
                    retain(Row::new(values))?;
                }
            }
            return Ok(Relation {
                names,
                qualified_names,
                rows,
            });
        }

        let (left_ref, right_ref) =
            if column_belongs_to_table(&join.left_column, &right_schema.name) {
                (&join.right_column, &join.left_column)
            } else {
                (&join.left_column, &join.right_column)
            };
        let left_index = relation_column_index(&left.names, &left.qualified_names, left_ref)?;
        let right_index = qualified_table_column_index(&right_schema, right_ref)?;
        let qualified_left = &left.qualified_names[left_index];
        let (left_table, left_column) = qualified_left.split_once('.').ok_or_else(|| {
            PhobosError::new(
                ErrorCode::InvalidCatalog,
                "joined column lost its table qualification",
            )
        })?;
        let physical = if left_table == query.alias.as_deref().unwrap_or(&query.table) {
            &query.table
        } else {
            &query
                .joins
                .iter()
                .find(|j| left_table == j.alias.as_deref().unwrap_or(&j.table))
                .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "unknown relation qualifier"))?
                .table
        };
        let left_type_schema = self.table_schema(physical)?;
        let left_type_index = left_type_schema.column_index(left_column).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::InvalidCatalog,
                "joined column is missing from its table",
            )
        })?;
        check_join_columns_comparable(
            &left_type_schema.columns[left_type_index],
            &right_schema.columns[right_index],
        )?;
        let right_bytes = right_rows.iter().map(row_bytes).sum::<usize>();
        let rows = if right_bytes <= self.query_memory_bytes {
            hash_join_rows(
                &left.rows,
                &right_rows,
                left_index,
                right_index,
                join.kind,
                right_schema.columns.len(),
            )?
        } else {
            grace_hash_join_rows(
                &left.rows,
                &right_rows,
                left_index,
                right_index,
                join.kind,
                right_schema.columns.len(),
                self.query_memory_bytes,
                &self.data_dir,
            )?
        };

        Ok(Relation {
            names,
            qualified_names,
            rows,
        })
    }

    fn resolve_query_subqueries(
        &mut self,
        query: &mut RelationalSelect,
        params: &[Value],
    ) -> Result<(), PhobosError> {
        for join in &mut query.joins {
            if let Some(predicate) = &mut join.predicate {
                self.resolve_expr_subqueries(predicate, params)?;
            }
        }
        for item in &mut query.items {
            if let SelectItem::Expression { expr, .. } = item {
                self.resolve_expr_subqueries(expr, params)?;
            }
        }
        for expr in [
            query.having.as_mut(),
            query.limit.as_mut(),
            query.offset.as_mut(),
        ]
        .into_iter()
        .flatten()
        {
            self.resolve_expr_subqueries(expr, params)?;
        }
        if let Some(filter) = query.filter.as_mut() {
            self.resolve_filter_constants(filter, params)?;
        }
        Ok(())
    }

    fn execute_subquery(
        &mut self,
        statement: Statement,
        params: &[Value],
    ) -> Result<QueryResult, PhobosError> {
        let unsupported = match &statement {
            Statement::Select { table, .. } => self.catalog.partition_key(table).is_some(),
            Statement::RelationalSelect(q) => {
                (q.source.is_none() && self.catalog.partition_key(&q.table).is_some())
                    || q.joins
                        .iter()
                        .any(|j| self.catalog.partition_key(&j.table).is_some())
            }
            Statement::Union { .. } => false,
            _ => true,
        };
        if unsupported {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "subqueries over partition parents are not yet supported",
            ));
        }
        self.execute_statement_direct(statement, params)
    }

    fn resolve_expr_subqueries(
        &mut self,
        expr: &mut Expr,
        params: &[Value],
    ) -> Result<(), PhobosError> {
        match expr {
            Expr::ScalarSubquery(query) | Expr::Exists(query) => {
                let result = self.execute_subquery((**query).clone(), params)?;
                let QueryResult::Rows { columns, rows } = result else {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "subquery must return rows",
                    ));
                };
                let value = if matches!(expr, Expr::Exists(_)) {
                    Value::Boolean(!rows.is_empty())
                } else {
                    if columns.len() != 1 || rows.len() > 1 {
                        return Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "scalar subquery must return one column and at most one row",
                        ));
                    }
                    rows.into_iter()
                        .next()
                        .and_then(|r| r.values.into_iter().next())
                        .unwrap_or(Value::Null)
                };
                *expr = Expr::Literal(value);
            }
            Expr::InSubquery {
                expr: needle,
                query,
            } => {
                self.resolve_expr_subqueries(needle, params)?;
                let result = self
                    .execute_subquery((**query).clone(), params)
                    .map_err(|error| {
                        if error.code == ErrorCode::NotFound {
                            PhobosError::new(
                                ErrorCode::Semantic,
                                "correlated subqueries are not supported",
                            )
                        } else {
                            error
                        }
                    })?;
                let QueryResult::Rows { columns, rows } = result else {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "IN subquery must be a SELECT",
                    ));
                };
                if columns.len() != 1 || rows.iter().any(|row| row.values.len() != 1) {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "IN subquery must return one column",
                    ));
                }
                let values = rows
                    .into_iter()
                    .map(|row| Expr::Literal(row.values.into_iter().next().unwrap()))
                    .collect();
                let needle = std::mem::replace(needle, Box::new(Expr::Literal(Value::Null)));
                *expr = Expr::InList {
                    expr: needle,
                    values,
                };
            }
            Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => {
                self.resolve_expr_subqueries(expr, params)?
            }
            Expr::Binary { left, right, .. }
            | Expr::Like {
                expr: left,
                pattern: right,
            } => {
                self.resolve_expr_subqueries(left, params)?;
                self.resolve_expr_subqueries(right, params)?;
            }
            Expr::Function { args, .. } => {
                for arg in args {
                    self.resolve_expr_subqueries(arg, params)?;
                }
            }
            Expr::InList { expr, values } => {
                self.resolve_expr_subqueries(expr, params)?;
                for value in values {
                    self.resolve_expr_subqueries(value, params)?;
                }
            }
            Expr::Case {
                branches,
                else_expr,
            } => {
                for (when, then) in branches {
                    self.resolve_expr_subqueries(when, params)?;
                    self.resolve_expr_subqueries(then, params)?;
                }
                if let Some(expr) = else_expr {
                    self.resolve_expr_subqueries(expr, params)?;
                }
            }
            Expr::Literal(_) | Expr::Column(_) | Expr::QuotedColumn(_) | Expr::Parameter(_) => {}
        }
        Ok(())
    }

    fn table_schema(&self, table: &str) -> Result<TableSchema, PhobosError> {
        if table.to_ascii_lowercase().starts_with("__phobos_") {
            return Err(PhobosError::new(
                ErrorCode::Authorization,
                "internal allocator is not a SQL table",
            ));
        }
        self.catalog.table(table).cloned().ok_or_else(|| {
            PhobosError::new(ErrorCode::NotFound, format!("table {table} does not exist"))
        })
    }
    fn heap_mut(&mut self, id: TableId) -> Result<&mut HeapTable, PhobosError> {
        self.heaps
            .get_mut(&id)
            .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "catalog heap is missing"))
    }
}

fn is_read_statement(statement: &Statement) -> bool {
    match statement {
        Statement::Select { .. }
        | Statement::ShowCatalog { .. }
        | Statement::RelationalSelect(_)
        | Statement::Union { .. } => true,
        Statement::Explain { statement, .. } => is_read_statement(statement),
        _ => false,
    }
}

fn persist_statistics(
    data_dir: &Path,
    statistics: &BTreeMap<TableId, TableStatistics>,
) -> Result<(), PhobosError> {
    let path = data_dir.join(STATS_FILE);
    let temporary = data_dir.join("phobos.stats.tmp");
    let mut body = Vec::new();
    for (table_id, table) in statistics {
        writeln!(
            body,
            "T\t{table_id}\t{}\t{}\t{}",
            table.row_count, table.generation, table.changed_rows
        )?;
        for (column, stats) in &table.columns {
            writeln!(
                body,
                "C\t{table_id}\t{}\t{}\t{}\t{}\t{}",
                escape_stat(column),
                stats.distinct_count,
                stats.null_count,
                escape_stat(stats.min_text.as_deref().unwrap_or("")),
                escape_stat(stats.max_text.as_deref().unwrap_or(""))
            )?;
        }
    }
    let mut file = BufWriter::new(
        OpenOptions::new()
            .create(true)
            .truncate(true)
            .write(true)
            .open(&temporary)?,
    );
    writeln!(file, "PHST2\t{:08x}", crc32c::crc32c(&body))?;
    file.write_all(&body)?;
    file.flush()?;
    drop(file);
    if path.exists() {
        phobos_observability::measure("fs.remove_file", || fs::remove_file(&path))?;
    }
    phobos_observability::measure("fs.rename", || fs::rename(temporary, path))?;
    Ok(())
}

fn load_statistics(data_dir: &Path) -> Result<BTreeMap<TableId, TableStatistics>, PhobosError> {
    let path = data_dir.join(STATS_FILE);
    if !path.exists() {
        return Ok(BTreeMap::new());
    }
    let content = fs::read_to_string(path)?;
    let (header, body) = content
        .split_once('\n')
        .map_or((content.as_str(), ""), |(header, body)| {
            (header.trim_end_matches('\r'), body)
        });
    let legacy = header == "PHST1";
    if !legacy && !header.starts_with("PHST2\t") {
        return Err(PhobosError::new(
            ErrorCode::InvalidCatalog,
            "invalid statistics file header",
        ));
    }
    if !legacy {
        let expected =
            u32::from_str_radix(header.trim_start_matches("PHST2\t"), 16).map_err(|_| {
                PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics checksum")
            })?;
        if crc32c::crc32c(body.as_bytes()) != expected {
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "statistics checksum mismatch",
            ));
        }
    }
    let mut result = BTreeMap::<TableId, TableStatistics>::new();
    for line in body.lines() {
        let parts: Vec<&str> = line.split('\t').collect();
        match parts.as_slice() {
            ["T", table_id, row_count] => {
                let table_id = table_id.parse::<u64>().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics table id")
                })?;
                let row_count = row_count.parse::<u64>().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics row count")
                })?;
                result.entry(table_id).or_default().row_count = row_count;
            }
            ["T", table_id, row_count, generation, changed_rows] => {
                let table_id = table_id.parse::<u64>().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics table id")
                })?;
                let table = result.entry(table_id).or_default();
                table.row_count = row_count.parse().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics row count")
                })?;
                table.generation = generation.parse().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics generation")
                })?;
                table.changed_rows = changed_rows.parse().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics changed rows")
                })?;
            }
            ["C", table_id, column, distinct, nulls, min, max] => {
                let table_id = table_id.parse::<u64>().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics table id")
                })?;
                let distinct_count = distinct.parse::<u64>().map_err(|_| {
                    PhobosError::new(
                        ErrorCode::InvalidCatalog,
                        "invalid statistics distinct count",
                    )
                })?;
                let null_count = nulls.parse::<u64>().map_err(|_| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "invalid statistics null count")
                })?;
                result.entry(table_id).or_default().columns.insert(
                    unescape_stat(column),
                    ColumnStatistics {
                        distinct_count,
                        null_count,
                        min_text: (!min.is_empty()).then(|| unescape_stat(min)),
                        max_text: (!max.is_empty()).then(|| unescape_stat(max)),
                    },
                );
            }
            _ => {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "malformed statistics record",
                ));
            }
        }
    }
    Ok(result)
}

fn escape_stat(value: &str) -> String {
    value
        .replace('\\', "\\\\")
        .replace('\t', "\\t")
        .replace('\n', "\\n")
}

fn unescape_stat(value: &str) -> String {
    let mut out = String::new();
    let mut chars = value.chars();
    while let Some(ch) = chars.next() {
        if ch == '\\' {
            match chars.next() {
                Some('t') => out.push('\t'),
                Some('n') => out.push('\n'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(ch);
        }
    }
    out
}

/// 0.2-B cost of an index access path, in units of one sequentially scanned
/// tuple (a sequential scan costs `rows`). Every matching entry costs a heap
/// fetch: on the 1M-row reference table a random committed-page fetch plus
/// CRC validation measured ~9 us versus ~0.15 us per sequentially scanned
/// tuple, and hot small tables still pay ~1-3 us. 20 places the crossover at
/// ~5% selectivity (the previous 0.25 chose an index even for a predicate
/// matching every row).
const INDEX_FETCH_COST: f64 = 20.0;

fn index_access_cost(matched_rows: f64, ranges: usize) -> f64 {
    3.0 + matched_rows * INDEX_FETCH_COST + ranges as f64
}

fn relation_column_index(
    names: &[String],
    qualified_names: &[String],
    name: &str,
) -> Result<usize, PhobosError> {
    if let Some(index) = qualified_names
        .iter()
        .position(|candidate| candidate.eq_ignore_ascii_case(name))
    {
        return Ok(index);
    }
    let base = name.rsplit('.').next().unwrap_or(name);
    let matches: Vec<usize> = names
        .iter()
        .enumerate()
        .filter_map(|(index, candidate)| candidate.eq_ignore_ascii_case(base).then_some(index))
        .collect();
    match matches.as_slice() {
        [index] => Ok(*index),
        [] => Err(PhobosError::new(
            ErrorCode::NotFound,
            format!("column {name} does not exist"),
        )),
        _ => Err(PhobosError::new(
            ErrorCode::Semantic,
            format!("column {name} is ambiguous"),
        )),
    }
}

fn column_belongs_to_table(column: &str, table: &str) -> bool {
    column
        .split_once('.')
        .is_some_and(|(prefix, _)| prefix.eq_ignore_ascii_case(table))
}

fn qualified_table_column_index(schema: &TableSchema, column: &str) -> Result<usize, PhobosError> {
    if let Some((prefix, base)) = column.split_once('.') {
        if !prefix.eq_ignore_ascii_case(&schema.name) {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                format!("column {column} does not belong to table {}", schema.name),
            ));
        }
        return schema.column_index(base).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::NotFound,
                format!("column {column} does not exist"),
            )
        });
    }
    schema.column_index(column).ok_or_else(|| {
        PhobosError::new(
            ErrorCode::NotFound,
            format!("column {column} does not exist"),
        )
    })
}

/// Join key of a value under the canonical contract; NULL never joins.
fn join_key(value: &Value) -> Option<Vec<u8>> {
    (!value.is_null()).then(|| value.canonical_key())
}

/// Writes one probe key into reusable storage. The resulting byte slice is the
/// same canonical representation as `join_key`, so an existing
/// `HashMap<Vec<u8>, _>` can look it up through `Borrow<[u8]>` without a new
/// allocation for every input row.
fn join_probe_key<'a>(value: &Value, key: &'a mut Vec<u8>) -> Option<&'a [u8]> {
    key.clear();
    if value.is_null() {
        return None;
    }
    let capacity = key.capacity();
    value.write_canonical_key(key);
    phobos_observability::event("join.probe_key_bytes", key.len() as u64);
    if key.capacity() != capacity {
        phobos_observability::event("join.probe_key_allocations", 1);
    }
    Some(key)
}

/// Composite GROUP BY key under the canonical contract (NULLs group together).
fn group_key(row: &Row, indexes: &[usize]) -> Vec<u8> {
    let _key_build = phobos_observability::span("aggregate.key_build");
    let mut key = Vec::new();
    for index in indexes {
        let start = key.len();
        key.extend_from_slice(&[0; 8]);
        row.values[*index].write_canonical_key(&mut key);
        let length = (key.len() - start - 8) as u64;
        key[start..start + 8].copy_from_slice(&length.to_le_bytes());
    }
    key
}

/// Grouping equality: NULLs are one group; otherwise canonical equality.
fn grouping_equal(a: &Value, b: &Value) -> bool {
    grouping_equal_ref(a.as_value_ref(), b.as_value_ref())
}
/// Borrowed `grouping_equal`: NULLs are one group; otherwise canonical equality.
fn grouping_equal_ref(a: ValueRef<'_>, b: ValueRef<'_>) -> bool {
    match (a.is_null(), b.is_null()) {
        (true, true) => true,
        (true, false) | (false, true) => false,
        (false, false) => a.canonical_cmp(&b) == Some(Ordering::Equal),
    }
}

/// Rejects a join whose key columns can never be compared under the canonical
/// contract, before either join algorithm runs, so the outcome does not depend
/// on which rows an algorithm happens to compare first.
fn check_join_columns_comparable(
    left: &ColumnSchema,
    right: &ColumnSchema,
) -> Result<(), PhobosError> {
    if left.data_type.key_class() == right.data_type.key_class() {
        Ok(())
    } else {
        Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            format!(
                "join columns {} ({:?}) and {} ({:?}) are not comparable",
                left.name, left.data_type, right.name, right.data_type
            ),
        ))
    }
}

fn hash_join_rows(
    left: &[Row],
    right: &[Row],
    left_index: usize,
    right_index: usize,
    kind: JoinKind,
    right_width: usize,
) -> Result<Vec<Row>, PhobosError> {
    let mut cancellation_poll = phobos_error::cancellation::Poller::default();
    let _profile = phobos_observability::span("execution.hash_join_rows");
    let mut buckets: HashMap<Vec<u8>, Vec<&Row>> = HashMap::new();
    for row in right {
        cancellation_poll.checkpoint_at("lib.hash_join_rows")?;
        if let Some(key) = join_key(&row.values[right_index]) {
            buckets.entry(key).or_default().push(row);
        }
    }
    let mut output = Vec::new();
    let mut probe_key = Vec::new();
    for left_row in left {
        cancellation_poll.checkpoint_at("lib.hash_join_rows")?;
        let matches = join_probe_key(&left_row.values[left_index], &mut probe_key)
            .and_then(|key| buckets.get(key));
        if let Some(matches) = matches {
            for right_row in matches {
                cancellation_poll.checkpoint_at("lib.hash_join_rows")?;
                let mut values = left_row.values.clone();
                values.extend(right_row.values.iter().cloned());
                output.push(Row::new(values));
            }
        } else if kind == JoinKind::Left {
            let mut values = left_row.values.clone();
            values.extend((0..right_width).map(|_| Value::Null));
            output.push(Row::new(values));
        }
    }
    Ok(output)
}

struct QueryScratch(PathBuf);

impl Drop for QueryScratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn partition_number(key: &[u8], seed: u64, partitions: usize) -> usize {
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    seed.hash(&mut hasher);
    key.hash(&mut hasher);
    (hasher.finish() as usize) & (partitions - 1)
}

/// Grace hash join over temporary row files. Partition files and their guard
/// are dropped on every return path, including cancellation and sink errors.
#[allow(clippy::too_many_arguments)]
fn grace_hash_join_rows(
    left: &[Row],
    right: &[Row],
    left_index: usize,
    right_index: usize,
    kind: JoinKind,
    right_width: usize,
    memory_bytes: usize,
    data_dir: &Path,
) -> Result<Vec<Row>, PhobosError> {
    let directory = data_dir.join(format!(
        ".phobos-grace-join-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ));
    fs::create_dir(&directory)?;
    let scratch = QueryScratch(directory);
    grace_join_pass(
        left,
        right,
        left_index,
        right_index,
        kind,
        right_width,
        memory_bytes.max(1),
        &scratch.0,
        0,
    )
}

#[allow(clippy::too_many_arguments)]
fn grace_join_pass(
    left: &[Row],
    right: &[Row],
    left_index: usize,
    right_index: usize,
    kind: JoinKind,
    right_width: usize,
    memory_bytes: usize,
    directory: &Path,
    depth: u8,
) -> Result<Vec<Row>, PhobosError> {
    let right_bytes = right.iter().map(row_bytes).sum::<usize>();
    if right_bytes <= memory_bytes {
        return hash_join_rows(left, right, left_index, right_index, kind, right_width);
    }
    if depth >= 3 {
        return bounded_nested_loop_join_rows(
            left,
            right,
            left_index,
            right_index,
            kind,
            right_width,
            (memory_bytes / 128).max(1),
        );
    }
    let ratio = right_bytes.div_ceil(memory_bytes).max(2);
    let partitions = ratio.next_power_of_two().min(64);
    let pass = directory.join(format!("pass-{depth}-{}", unique_spill_suffix()));
    fs::create_dir(&pass)?;
    let mut left_writers = Vec::with_capacity(partitions);
    let mut right_writers = Vec::with_capacity(partitions);
    for i in 0..partitions {
        left_writers.push(BufWriter::new(File::create(
            pass.join(format!("l-{i}.bin")),
        )?));
        right_writers.push(BufWriter::new(File::create(
            pass.join(format!("r-{i}.bin")),
        )?));
    }
    for row in left {
        phobos_error::cancellation::checkpoint_at("grace_hash_join.partition_left")?;
        let partition = join_key(&row.values[left_index]).map_or(0, |key| {
            partition_number(&key, u64::from(depth), partitions)
        });
        write_spill_row(&mut left_writers[partition], row)?;
    }
    for row in right {
        phobos_error::cancellation::checkpoint_at("grace_hash_join.partition_right")?;
        if let Some(key) = join_key(&row.values[right_index]) {
            let partition = partition_number(&key, u64::from(depth), partitions);
            write_spill_row(&mut right_writers[partition], row)?;
        }
    }
    for writer in &mut left_writers {
        writer.flush()?;
    }
    for writer in &mut right_writers {
        writer.flush()?;
    }
    drop(left_writers);
    drop(right_writers);
    let mut output = Vec::new();
    for i in 0..partitions {
        phobos_error::cancellation::checkpoint_at("grace_hash_join.partition")?;
        let left_rows = read_spill_rows(&pass.join(format!("l-{i}.bin")))?;
        let right_rows = read_spill_rows(&pass.join(format!("r-{i}.bin")))?;
        output.extend(grace_join_pass(
            &left_rows,
            &right_rows,
            left_index,
            right_index,
            kind,
            right_width,
            memory_bytes,
            directory,
            depth + 1,
        )?);
    }
    fs::remove_dir_all(pass)?;
    Ok(output)
}

fn read_spill_rows(path: &Path) -> Result<Vec<Row>, PhobosError> {
    let mut rows = Vec::new();
    let mut reader = BufReader::new(File::open(path)?);
    while let Some(row) = bounded_sort::read_row(&mut reader)? {
        rows.push(row);
    }
    Ok(rows)
}

fn bounded_nested_loop_join_rows(
    left: &[Row],
    right: &[Row],
    left_index: usize,
    right_index: usize,
    kind: JoinKind,
    right_width: usize,
    memory_rows: usize,
) -> Result<Vec<Row>, PhobosError> {
    let mut cancellation_poll = phobos_error::cancellation::Poller::default();
    let _profile = phobos_observability::span("execution.bounded_nested_loop_join_rows");
    let block = memory_rows.max(1);
    let mut output = Vec::new();
    for left_chunk in left.chunks(block) {
        cancellation_poll.checkpoint_at("lib.bounded_nested_loop_join_rows")?;
        let mut matched = vec![false; left_chunk.len()];
        for right_row in right {
            cancellation_poll.checkpoint_at("lib.bounded_nested_loop_join_rows")?;
            if right_row.values[right_index].is_null() {
                continue;
            }
            for (position, left_row) in left_chunk.iter().enumerate() {
                cancellation_poll.checkpoint_at("lib.bounded_nested_loop_join_rows")?;
                if left_row.values[left_index].is_null() {
                    continue;
                }
                if compare_non_null(&left_row.values[left_index], &right_row.values[right_index])?
                    == Ordering::Equal
                {
                    matched[position] = true;
                    let mut values = left_row.values.clone();
                    values.extend(right_row.values.iter().cloned());
                    output.push(Row::new(values));
                }
            }
        }
        if kind == JoinKind::Left {
            for (position, left_row) in left_chunk.iter().enumerate() {
                cancellation_poll.checkpoint_at("lib.bounded_nested_loop_join_rows")?;
                if !matched[position] {
                    let mut values = left_row.values.clone();
                    values.extend((0..right_width).map(|_| Value::Null));
                    output.push(Row::new(values));
                }
            }
        }
    }
    Ok(output)
}

fn matches_filter_relation(
    filter: &Expr,
    names: &[String],
    qualified_names: &[String],
    row: &Row,
    params: &[Value],
) -> Result<bool, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.matches_filter_relation")?;
    Ok(to_truth(eval_expr_relation(
        filter,
        names,
        qualified_names,
        row,
        params,
    )?)? == Truth::True)
}

fn eval_expr_relation(
    expr: &Expr,
    names: &[String],
    qualified_names: &[String],
    row: &Row,
    params: &[Value],
) -> Result<Value, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.eval_expr_relation")?;
    match expr {
        Expr::Literal(value) => {
            let _clone = phobos_observability::span("predicate.literal_clone");
            Ok(value.clone())
        }
        Expr::Parameter(index) => params.get(*index).cloned().ok_or_else(|| {
            PhobosError::new(
                ErrorCode::Semantic,
                format!("missing parameter ${}", index + 1),
            )
        }),
        Expr::Column(name) => {
            let index = relation_column_index(names, qualified_names, name)?;
            let _clone = phobos_observability::span("predicate.column_value_clone");
            Ok(row.values[index].clone())
        }
        Expr::QuotedColumn(name) => {
            let matches: Vec<usize> = qualified_names
                .iter()
                .enumerate()
                .filter_map(|(index, candidate)| {
                    (candidate == name || names[index] == *name).then_some(index)
                })
                .collect();
            match matches.as_slice() {
                [index] => Ok(row.values[*index].clone()),
                [] => Err(PhobosError::new(
                    ErrorCode::NotFound,
                    format!("column {name} does not exist"),
                )),
                _ => Err(PhobosError::new(
                    ErrorCode::Semantic,
                    format!("column {name} is ambiguous"),
                )),
            }
        }
        Expr::Unary {
            op: UnaryOp::Not,
            expr,
        } => Ok(truth_value(
            match to_truth(eval_expr_relation(
                expr,
                names,
                qualified_names,
                row,
                params,
            )?)? {
                Truth::True => Truth::False,
                Truth::False => Truth::True,
                Truth::Unknown => Truth::Unknown,
            },
        )),
        Expr::Unary {
            op: UnaryOp::Negate,
            expr,
        } => negate(eval_expr_relation(
            expr,
            names,
            qualified_names,
            row,
            params,
        )?),
        Expr::IsNull { expr, negated } => {
            let is_null = eval_expr_relation(expr, names, qualified_names, row, params)?.is_null();
            Ok(Value::Boolean(if *negated { !is_null } else { is_null }))
        }
        Expr::Binary { left, op, right } => {
            if *op == BinaryOp::And || *op == BinaryOp::Or {
                let left = to_truth(eval_expr_relation(
                    left,
                    names,
                    qualified_names,
                    row,
                    params,
                )?)?;
                let right = to_truth(eval_expr_relation(
                    right,
                    names,
                    qualified_names,
                    row,
                    params,
                )?)?;
                return Ok(truth_value(if *op == BinaryOp::And {
                    truth_and(left, right)
                } else {
                    truth_or(left, right)
                }));
            }
            let left = eval_expr_relation(left, names, qualified_names, row, params)?;
            let right = eval_expr_relation(right, names, qualified_names, row, params)?;
            match op {
                BinaryOp::Eq
                | BinaryOp::NotEq
                | BinaryOp::Lt
                | BinaryOp::LtEq
                | BinaryOp::Gt
                | BinaryOp::GtEq => compare_values(&left, *op, &right),
                BinaryOp::Add | BinaryOp::Subtract | BinaryOp::Multiply | BinaryOp::Divide => {
                    arithmetic(&left, *op, &right)
                }
                BinaryOp::And | BinaryOp::Or => unreachable!(),
            }
        }
        Expr::Function { name, args } => {
            let values = args
                .iter()
                .map(|arg| eval_expr_relation(arg, names, qualified_names, row, params))
                .collect::<Result<Vec<_>, _>>()?;
            eval_builtin(name, values)
        }
        Expr::Like { expr, pattern } => eval_like(
            eval_expr_relation(expr, names, qualified_names, row, params)?,
            eval_expr_relation(pattern, names, qualified_names, row, params)?,
        ),
        Expr::InList { expr, values } => {
            let needle = eval_expr_relation(expr, names, qualified_names, row, params)?;
            let values = values
                .iter()
                .map(|value| eval_expr_relation(value, names, qualified_names, row, params))
                .collect::<Result<Vec<_>, _>>()?;
            eval_in(needle, values)
        }
        Expr::InSubquery { .. } | Expr::ScalarSubquery(_) | Expr::Exists(_) => Err(
            PhobosError::new(ErrorCode::Semantic, "unresolved IN subquery"),
        ),
        Expr::Case {
            branches,
            else_expr,
        } => {
            for (when, then) in branches {
                if to_truth(eval_expr_relation(
                    when,
                    names,
                    qualified_names,
                    row,
                    params,
                )?)? == Truth::True
                {
                    return eval_expr_relation(then, names, qualified_names, row, params);
                }
            }
            else_expr.as_ref().map_or(Ok(Value::Null), |expr| {
                eval_expr_relation(expr, names, qualified_names, row, params)
            })
        }
    }
}

fn select_item_name(item: &SelectItem) -> String {
    match item {
        SelectItem::All => "*".into(),
        SelectItem::Column { name, alias } => alias.clone().unwrap_or_else(|| name.clone()),
        SelectItem::Aggregate {
            function,
            column,
            alias,
        } => alias.clone().unwrap_or_else(|| {
            let function = match function {
                AggregateFunction::Count => "count",
                AggregateFunction::Sum => "sum",
                AggregateFunction::Avg => "avg",
                AggregateFunction::Min => "min",
                AggregateFunction::Max => "max",
            };
            format!("{function}({})", column.as_deref().unwrap_or("*"))
        }),
        SelectItem::Expression { expr, alias } => alias.clone().unwrap_or_else(|| match expr {
            Expr::Function { name, .. } => name.to_ascii_lowercase(),
            Expr::Case { .. } => "case".into(),
            _ => "expression".into(),
        }),
    }
}

fn validate_grouping(
    items: &[SelectItem],
    group_by: &[String],
    has_aggregate: bool,
    relation: &Relation,
) -> Result<(), PhobosError> {
    if !has_aggregate && group_by.is_empty() {
        return Ok(());
    }
    for item in items {
        if let SelectItem::Column { name, .. } = item {
            let column = relation.column_index(name)?;
            let grouped = group_by
                .iter()
                .map(|g| relation.column_index(g))
                .collect::<Result<Vec<_>, _>>()?
                .contains(&column);
            if !grouped {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    format!("column {name} must appear in GROUP BY or be aggregated"),
                ));
            }
        }
    }
    Ok(())
}

fn project_relation(
    relation: Relation,
    items: &[SelectItem],
    params: &[Value],
) -> Result<Relation, PhobosError> {
    if items.len() == 1 && matches!(items[0], SelectItem::All) {
        return Ok(relation);
    }
    let mut names = Vec::new();
    for item in items {
        match item {
            SelectItem::Column { name, .. } => {
                relation.column_index(name)?;
                names.push(select_item_name(item));
            }
            SelectItem::Expression { .. } => names.push(select_item_name(item)),
            SelectItem::Aggregate { .. } => {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "aggregate item requires GROUP BY/aggregate execution",
                ));
            }
            SelectItem::All => {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "* cannot be mixed with other Phase 6 select items",
                ));
            }
        }
    }
    let input_names = relation.names.clone();
    let input_qualified_names = relation.qualified_names.clone();
    let rows = relation
        .rows
        .into_iter()
        .map(|row| {
            let mut values = Vec::with_capacity(items.len());
            for item in items {
                match item {
                    SelectItem::Column { name, .. } => {
                        let index =
                            relation_column_index(&input_names, &input_qualified_names, name)?;
                        values.push(row.values[index].clone());
                    }
                    SelectItem::Expression { expr, .. } => values.push(eval_expr_relation(
                        expr,
                        &input_names,
                        &input_qualified_names,
                        &row,
                        params,
                    )?),
                    _ => unreachable!(),
                }
            }
            Ok(Row::new(values))
        })
        .collect::<Result<Vec<_>, PhobosError>>()?;
    Ok(Relation {
        qualified_names: names.clone(),
        names,
        rows,
    })
}

fn aggregate_relation(
    mut relation: Relation,
    items: &[SelectItem],
    group_by: &[String],
    memory_bytes: usize,
    data_dir: &Path,
) -> Result<Relation, PhobosError> {
    let mut cancellation_poll = phobos_error::cancellation::Poller::default();
    let _profile = phobos_observability::span("execution.aggregate_relation");
    let group_indexes: Vec<usize> = group_by
        .iter()
        .map(|column| relation.column_index(column))
        .collect::<Result<_, _>>()?;
    let output_names: Vec<String> = items.iter().map(select_item_name).collect();
    let aggregate_items = items
        .iter()
        .map(|item| match item {
            SelectItem::Column { name, .. } => Ok(streaming_aggregate::Item::Column(
                relation.column_index(name)?,
                name.clone(),
            )),
            SelectItem::Aggregate {
                function, column, ..
            } => Ok(streaming_aggregate::Item::Aggregate(
                *function,
                column
                    .as_ref()
                    .map(|name| relation.column_index(name))
                    .transpose()?,
            )),
            SelectItem::All => Err(PhobosError::new(
                ErrorCode::Semantic,
                "* is not valid with aggregate items",
            )),
            SelectItem::Expression { .. } => Err(PhobosError::new(
                ErrorCode::Semantic,
                "expressions mixed with aggregate output are not supported",
            )),
        })
        .collect::<Result<Vec<_>, _>>()?;
    let mut output_rows = Vec::new();

    if group_indexes.is_empty() {
        let mut group = streaming_aggregate::Group::new(&aggregate_items);
        for row in &relation.rows {
            cancellation_poll.checkpoint_at("lib.aggregate_relation")?;
            group.push(row)?;
        }
        output_rows.push(group.finish()?);
    } else if relation.rows.iter().map(row_bytes).sum::<usize>() <= memory_bytes.max(1) {
        // Retain one aggregate state per key. If state cardinality crosses the
        // budget, drop it and reuse the existing bounded spill fallback.
        let mut groups: HashMap<Vec<u8>, streaming_aggregate::Group<'_>> = HashMap::new();
        let mut state_bytes = 0usize;
        let mut exceeded = false;
        {
            let _hash_build = phobos_observability::span("aggregate.hash_build");
            for row in &relation.rows {
                cancellation_poll.checkpoint_at("lib.aggregate_relation")?;
                let key = group_key(row, &group_indexes);
                let group = groups.entry(key).or_insert_with_key(|key| {
                    let group = streaming_aggregate::Group::new(&aggregate_items);
                    state_bytes = state_bytes.saturating_add(
                        std::mem::size_of::<(Vec<u8>, streaming_aggregate::Group<'_>)>()
                            + key.capacity()
                            + 16
                            + group.memory_bytes(),
                    );
                    group
                });
                let before = group.memory_bytes();
                group.push(row)?;
                let after = group.memory_bytes();
                if after >= before {
                    state_bytes = state_bytes.saturating_add(after - before);
                } else {
                    state_bytes = state_bytes.saturating_sub(before - after);
                }
                if state_bytes > memory_bytes.max(1) {
                    exceeded = true;
                    break;
                }
            }
        }
        if exceeded {
            drop(groups);
            let rows = std::mem::take(&mut relation.rows);
            output_rows.extend(spilled_hash_aggregate(
                &relation,
                rows,
                items,
                &group_indexes,
                memory_bytes.max(1),
                data_dir,
            )?);
        } else {
            phobos_observability::event("aggregate.group_count", groups.len() as u64);
            for group in groups.values() {
                cancellation_poll.checkpoint_at("lib.aggregate_relation")?;
                output_rows.push(group.finish()?);
            }
        }
    } else {
        let rows = std::mem::take(&mut relation.rows);
        output_rows.extend(spilled_hash_aggregate(
            &relation,
            rows,
            items,
            &group_indexes,
            memory_bytes.max(1),
            data_dir,
        )?);
    }

    Ok(Relation {
        qualified_names: output_names.clone(),
        names: output_names,
        rows: output_rows,
    })
}

fn spilled_hash_aggregate(
    relation: &Relation,
    rows: Vec<Row>,
    items: &[SelectItem],
    group_indexes: &[usize],
    memory_bytes: usize,
    data_dir: &Path,
) -> Result<Vec<Row>, PhobosError> {
    let total = rows.iter().map(row_bytes).sum::<usize>();
    let partitions = total
        .div_ceil(memory_bytes)
        .max(2)
        .next_power_of_two()
        .min(64);
    phobos_observability::event("aggregate.spill_partitions", partitions as u64);
    phobos_observability::event("aggregate.spill_bytes", total as u64);
    phobos_observability::event("aggregate.spill_rows", rows.len() as u64);
    let directory = data_dir.join(format!(
        ".phobos-spill-aggregate-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ));
    fs::create_dir(&directory)?;
    let scratch = QueryScratch(directory);
    let mut writers = Vec::with_capacity(partitions);
    for i in 0..partitions {
        writers.push(BufWriter::new(File::create(
            scratch.0.join(format!("p-{i}.bin")),
        )?));
    }
    for row in rows {
        phobos_error::cancellation::checkpoint_at("hash_aggregate.partition")?;
        let key = group_key(&row, group_indexes);
        let partition = partition_number(&key, 0, partitions);
        write_spill_row(&mut writers[partition], &row)?;
    }
    for writer in &mut writers {
        writer.flush()?;
    }
    drop(writers);
    let mut output = Vec::new();
    for i in 0..partitions {
        let rows = read_spill_rows(&scratch.0.join(format!("p-{i}.bin")))?;
        let mut groups: HashMap<Vec<u8>, Vec<Row>> = HashMap::new();
        for row in rows {
            phobos_error::cancellation::checkpoint_at("hash_aggregate.partition_read")?;
            groups
                .entry(group_key(&row, group_indexes))
                .or_default()
                .push(row);
        }
        phobos_observability::event("aggregate.group_count", groups.len() as u64);
        for rows in groups.values() {
            output.push(aggregate_group(relation, rows, items)?);
        }
    }
    Ok(output)
}

fn aggregate_group(
    relation: &Relation,
    rows: &[Row],
    items: &[SelectItem],
) -> Result<Row, PhobosError> {
    let mut values = Vec::with_capacity(items.len());
    for item in items {
        match item {
            SelectItem::Column { name, .. } => {
                let index = relation.column_index(name)?;
                let value = rows
                    .first()
                    .map_or(Value::Null, |row| row.values[index].clone());
                if rows
                    .iter()
                    .skip(1)
                    .any(|row| !grouping_equal(&row.values[index], &value))
                {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        format!("column {name} must appear in GROUP BY or be aggregated"),
                    ));
                }
                values.push(value);
            }
            SelectItem::Aggregate {
                function, column, ..
            } => {
                let index = column
                    .as_ref()
                    .map(|name| relation.column_index(name))
                    .transpose()?;
                values.push(compute_aggregate(*function, index, rows)?);
            }
            SelectItem::All => {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "* is not valid with aggregate items",
                ));
            }
            SelectItem::Expression { .. } => {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "expressions mixed with aggregate output are not supported",
                ));
            }
        }
    }
    Ok(Row::new(values))
}

fn compute_aggregate(
    function: AggregateFunction,
    index: Option<usize>,
    rows: &[Row],
) -> Result<Value, PhobosError> {
    let mut cancellation_poll = phobos_error::cancellation::Poller::default();
    match function {
        AggregateFunction::Count => {
            let count = match index {
                None => rows.len(),
                Some(index) => {
                    let mut count = 0;
                    for row in rows {
                        cancellation_poll.checkpoint_at("lib.compute_aggregate")?;
                        count += usize::from(!row.values[index].is_null());
                    }
                    count
                }
            };
            Ok(Value::Int64(i64::try_from(count).map_err(|_| {
                PhobosError::new(ErrorCode::TypeMismatch, "COUNT overflow")
            })?))
        }
        AggregateFunction::Sum | AggregateFunction::Avg => {
            let index = index
                .ok_or_else(|| PhobosError::new(ErrorCode::Semantic, "SUM/AVG require a column"))?;
            let mut non_null = Vec::new();
            for row in rows {
                cancellation_poll.checkpoint_at("lib.compute_aggregate")?;
                if !row.values[index].is_null() {
                    non_null.push(&row.values[index]);
                }
            }
            let non_null_count = non_null.len();
            if non_null.is_empty() {
                return Ok(Value::Null);
            }
            match non_null[0] {
                Value::Int64(_) => {
                    let mut sum: i128 = 0;
                    for value in non_null {
                        cancellation_poll.checkpoint_at("lib.compute_aggregate")?;
                        let Value::Int64(value) = value else {
                            return Err(PhobosError::new(
                                ErrorCode::TypeMismatch,
                                "aggregate input types are inconsistent",
                            ));
                        };
                        sum = sum.checked_add(i128::from(*value)).ok_or_else(|| {
                            PhobosError::new(ErrorCode::TypeMismatch, "SUM overflow")
                        })?;
                    }
                    if function == AggregateFunction::Avg {
                        Ok(Value::Float64(sum as f64 / non_null_count as f64))
                    } else {
                        Ok(Value::Int64(i64::try_from(sum).map_err(|_| {
                            PhobosError::new(ErrorCode::TypeMismatch, "SUM overflow")
                        })?))
                    }
                }
                Value::Float64(_) => {
                    let mut sum = 0.0f64;
                    let mut count = 0usize;
                    for value in non_null {
                        cancellation_poll.checkpoint_at("lib.compute_aggregate")?;
                        let Value::Float64(value) = value else {
                            return Err(PhobosError::new(
                                ErrorCode::TypeMismatch,
                                "aggregate input types are inconsistent",
                            ));
                        };
                        sum += *value;
                        count += 1;
                    }
                    Ok(Value::Float64(if function == AggregateFunction::Avg {
                        sum / count as f64
                    } else {
                        sum
                    }))
                }
                Value::Decimal { scale, .. } => {
                    let scale = *scale;
                    let mut sum = 0i128;
                    let mut count = 0i128;
                    for value in non_null {
                        cancellation_poll.checkpoint_at("lib.compute_aggregate")?;
                        let Value::Decimal {
                            unscaled,
                            scale: value_scale,
                        } = value
                        else {
                            return Err(PhobosError::new(
                                ErrorCode::TypeMismatch,
                                "aggregate input types are inconsistent",
                            ));
                        };
                        if *value_scale != scale {
                            return Err(PhobosError::new(
                                ErrorCode::TypeMismatch,
                                "DECIMAL scales differ in aggregate",
                            ));
                        }
                        sum = sum.checked_add(*unscaled).ok_or_else(|| {
                            PhobosError::new(ErrorCode::TypeMismatch, "SUM overflow")
                        })?;
                        count += 1;
                    }
                    if function == AggregateFunction::Avg {
                        Ok(Value::Decimal {
                            unscaled: sum / count,
                            scale,
                        })
                    } else {
                        Ok(Value::Decimal {
                            unscaled: sum,
                            scale,
                        })
                    }
                }
                _ => Err(PhobosError::new(
                    ErrorCode::TypeMismatch,
                    "SUM/AVG require numeric input",
                )),
            }
        }
        AggregateFunction::Min | AggregateFunction::Max => {
            let index = index
                .ok_or_else(|| PhobosError::new(ErrorCode::Semantic, "MIN/MAX require a column"))?;
            let mut best: Option<Value> = None;
            for row in rows {
                cancellation_poll.checkpoint_at("lib.compute_aggregate")?;
                let value = &row.values[index];
                if value.is_null() {
                    continue;
                }
                let replace = match &best {
                    None => true,
                    Some(current) => {
                        let ordering = compare_for_sort(value, current)?;
                        if function == AggregateFunction::Min {
                            ordering == Ordering::Less
                        } else {
                            ordering == Ordering::Greater
                        }
                    }
                };
                if replace {
                    best = Some(value.clone());
                }
            }
            Ok(best.unwrap_or(Value::Null))
        }
    }
}

fn bind_relation_order(
    relation: &Relation,
    order_by: &[OrderBy],
) -> Result<Vec<(usize, bool)>, PhobosError> {
    order_by
        .iter()
        .map(|item| {
            if let Ok(position) = item.column.parse::<usize>() {
                if position == 0 || position > relation.names.len() {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "ORDER BY position is out of range",
                    ));
                }
                return Ok((position - 1, item.ascending));
            }
            relation
                .column_index(&item.column)
                .or_else(|error| {
                    if error.code != ErrorCode::NotFound || item.column.contains('.') {
                        return Err(error);
                    }
                    let mut matches = relation.names.iter().enumerate().filter(|(_, n)| {
                        n.rsplit('.')
                            .next()
                            .is_some_and(|n| n.eq_ignore_ascii_case(&item.column))
                    });
                    let Some((index, _)) = matches.next() else {
                        return Err(error);
                    };
                    if matches.next().is_some() {
                        return Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "ambiguous ORDER BY column",
                        ));
                    }
                    Ok(index)
                })
                .map(|index| (index, item.ascending))
        })
        .collect()
}

fn external_sort_rows(
    rows: Vec<Row>,
    order: &[(usize, bool)],
    memory_bytes: usize,
    data_dir: &Path,
) -> Result<Vec<Row>, PhobosError> {
    let mut cancellation_poll = phobos_error::cancellation::Poller::default();
    let _profile = phobos_observability::span("execution.external_sort_rows");
    let total_bytes = rows.iter().map(row_bytes).sum::<usize>();
    if total_bytes <= memory_bytes.max(1) {
        return sort_rows_in_memory(rows, order);
    }
    let spill_dir = data_dir.join(format!(
        ".phobos-spill-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ));
    phobos_observability::measure("fs.create_dir_all", || fs::create_dir_all(&spill_dir))?;
    let result = (|| -> Result<Vec<Row>, PhobosError> {
        let mut runs = Vec::new();
        // The sort owns its input. Move rows into each run instead of cloning
        // every payload and retaining a second complete input during the merge.
        let mut input = rows.into_iter();
        while input.len() != 0 {
            cancellation_poll.checkpoint_at("lib.external_sort_rows")?;
            let mut chunk = Vec::new();
            let mut bytes = 0usize;
            for row in input.by_ref() {
                let size = row_bytes(&row);
                if !chunk.is_empty() && bytes.saturating_add(size) > memory_bytes.max(1) {
                    chunk.push(row);
                    break;
                }
                bytes = bytes.saturating_add(size);
                chunk.push(row);
                if bytes >= memory_bytes.max(1) {
                    break;
                }
            }
            let sorted = sort_rows_in_memory(chunk, order)?;
            let path = spill_dir.join(format!("run-{:06}.bin", runs.len()));
            let mut writer = BufWriter::new(File::create(&path)?);
            for row in &sorted {
                cancellation_poll.checkpoint_at("lib.external_sort_rows")?;
                write_spill_row(&mut writer, row)?;
            }
            writer.flush()?;
            runs.push(path);
        }
        drop(input);
        merge_spill_runs(&runs, order)
    })();
    let _ = phobos_observability::measure("fs.remove_dir_all", || fs::remove_dir_all(&spill_dir));
    result
}

fn sort_rows_in_memory(
    mut rows: Vec<Row>,
    order: &[(usize, bool)],
) -> Result<Vec<Row>, PhobosError> {
    let mut sort_error = None;
    rows.sort_by(|a, b| match compare_rows(a, b, order) {
        Ok(ordering) => ordering,
        Err(error) => {
            sort_error = Some(error);
            Ordering::Equal
        }
    });
    if let Some(error) = sort_error {
        return Err(error);
    }
    Ok(rows)
}

fn unique_spill_suffix() -> u128 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos())
}

fn write_spill_row(writer: &mut impl Write, row: &Row) -> Result<(), PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.write_spill_row")?;
    let bytes = encode_spill_row(row)?;
    let len = u32::try_from(bytes.len())
        .map_err(|_| PhobosError::new(ErrorCode::Io, "spill row too large"))?;
    writer.write_all(&len.to_le_bytes())?;
    writer.write_all(&bytes)?;
    Ok(())
}

fn read_spill_row(reader: &mut impl Read) -> Result<Option<Row>, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.read_spill_row")?;
    let mut len = [0u8; 4];
    match reader.read_exact(&mut len) {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::UnexpectedEof => return Ok(None),
        Err(error) => return Err(error.into()),
    }
    let len = u32::from_le_bytes(len) as usize;
    let mut bytes = vec![0u8; len];
    reader.read_exact(&mut bytes)?;
    Ok(Some(decode_spill_row(&bytes)?))
}

fn merge_spill_runs(paths: &[PathBuf], order: &[(usize, bool)]) -> Result<Vec<Row>, PhobosError> {
    let mut cancellation_poll = phobos_error::cancellation::Poller::default();
    let mut readers: Vec<BufReader<File>> = paths
        .iter()
        .map(File::open)
        .collect::<Result<Vec<_>, _>>()?
        .into_iter()
        .map(BufReader::new)
        .collect();
    let mut heads: Vec<Option<Row>> = readers
        .iter_mut()
        .map(read_spill_row)
        .collect::<Result<_, _>>()?;
    // A tournament retains the winning run in each subtree. Updating one run
    // needs only its path to the root, instead of rescanning every open run.
    // Leaves retain run order, so equal keys still prefer the earlier run.
    let leaves = heads.len().max(1).next_power_of_two();
    let mut winners = vec![None; 2 * leaves];
    for (index, head) in heads.iter().enumerate() {
        cancellation_poll.checkpoint_at("lib.merge_spill_runs")?;
        winners[leaves + index] = head.as_ref().map(|_| index);
    }
    for node in (1..leaves).rev() {
        cancellation_poll.checkpoint_at("lib.merge_spill_runs")?;
        winners[node] = choose_spill_head(&heads, winners[2 * node], winners[2 * node + 1], order)?;
    }
    let mut output = Vec::new();
    while let Some(best) = winners[1] {
        cancellation_poll.checkpoint_at("lib.merge_spill_runs")?;
        output.push(heads[best].take().expect("selected run head"));
        heads[best] = read_spill_row(&mut readers[best])?;
        let mut node = leaves + best;
        winners[node] = heads[best].as_ref().map(|_| best);
        while node > 1 {
            cancellation_poll.checkpoint_at("lib.merge_spill_runs")?;
            node /= 2;
            winners[node] =
                choose_spill_head(&heads, winners[2 * node], winners[2 * node + 1], order)?;
        }
    }
    Ok(output)
}

fn choose_spill_head(
    heads: &[Option<Row>],
    left: Option<usize>,
    right: Option<usize>,
    order: &[(usize, bool)],
) -> Result<Option<usize>, PhobosError> {
    match (left, right) {
        (Some(left), Some(right)) => {
            phobos_observability::event("spill.head_comparisons", 1);
            let ordering = compare_rows(
                heads[right].as_ref().expect("right run head"),
                heads[left].as_ref().expect("left run head"),
                order,
            )?;
            Ok(Some(if ordering == Ordering::Less {
                right
            } else {
                left
            }))
        }
        (head, None) | (None, head) => Ok(head),
    }
}

fn encode_spill_row(row: &Row) -> Result<Vec<u8>, PhobosError> {
    let count = u32::try_from(row.values.len())
        .map_err(|_| PhobosError::new(ErrorCode::Io, "too many spill values"))?;
    let mut out = Vec::new();
    out.extend_from_slice(&count.to_le_bytes());
    for value in &row.values {
        match value {
            Value::Null => out.push(0),
            Value::Int64(value) => {
                out.push(1);
                out.extend_from_slice(&value.to_le_bytes());
            }
            Value::Boolean(value) => {
                out.push(2);
                out.push(u8::from(*value));
            }
            Value::Float64(value) => {
                out.push(3);
                out.extend_from_slice(&value.to_bits().to_le_bytes());
            }
            Value::Text(value) => {
                out.push(4);
                put_spill_bytes(&mut out, value.as_bytes())?;
            }
            Value::Binary(value) => {
                out.push(5);
                put_spill_bytes(&mut out, value)?;
            }
            Value::Date(value) => {
                out.push(6);
                out.extend_from_slice(&value.to_le_bytes());
            }
            Value::Timestamp(value) => {
                out.push(7);
                out.extend_from_slice(&value.to_le_bytes());
            }
            Value::Decimal { unscaled, scale } => {
                out.push(8);
                out.extend_from_slice(&unscaled.to_le_bytes());
                out.push(*scale);
            }
        }
    }
    Ok(out)
}

fn put_spill_bytes(out: &mut Vec<u8>, bytes: &[u8]) -> Result<(), PhobosError> {
    let len = u32::try_from(bytes.len())
        .map_err(|_| PhobosError::new(ErrorCode::Io, "spill value too large"))?;
    out.extend_from_slice(&len.to_le_bytes());
    out.extend_from_slice(bytes);
    Ok(())
}

fn decode_spill_row(bytes: &[u8]) -> Result<Row, PhobosError> {
    let mut cursor = 0usize;
    let count = take_spill_u32(bytes, &mut cursor)? as usize;
    let mut values = Vec::with_capacity(count);
    for _ in 0..count {
        let tag = *bytes
            .get(cursor)
            .ok_or_else(|| PhobosError::new(ErrorCode::Io, "truncated spill row"))?;
        cursor += 1;
        let value = match tag {
            0 => Value::Null,
            1 => Value::Int64(i64::from_le_bytes(take_spill_array::<8>(
                bytes,
                &mut cursor,
            )?)),
            2 => {
                let value = *bytes
                    .get(cursor)
                    .ok_or_else(|| PhobosError::new(ErrorCode::Io, "truncated spill boolean"))?;
                cursor += 1;
                Value::Boolean(value != 0)
            }
            3 => Value::Float64(f64::from_bits(u64::from_le_bytes(take_spill_array::<8>(
                bytes,
                &mut cursor,
            )?))),
            4 => Value::Text(
                String::from_utf8(take_spill_bytes(bytes, &mut cursor)?.to_vec())
                    .map_err(|_| PhobosError::new(ErrorCode::Io, "spill text is not UTF-8"))?,
            ),
            5 => Value::Binary(take_spill_bytes(bytes, &mut cursor)?.to_vec()),
            6 => Value::Date(i32::from_le_bytes(take_spill_array::<4>(
                bytes,
                &mut cursor,
            )?)),
            7 => Value::Timestamp(i64::from_le_bytes(take_spill_array::<8>(
                bytes,
                &mut cursor,
            )?)),
            8 => {
                let unscaled = i128::from_le_bytes(take_spill_array::<16>(bytes, &mut cursor)?);
                let scale = *bytes
                    .get(cursor)
                    .ok_or_else(|| PhobosError::new(ErrorCode::Io, "truncated spill decimal"))?;
                cursor += 1;
                Value::Decimal { unscaled, scale }
            }
            _ => {
                return Err(PhobosError::new(ErrorCode::Io, "unknown spill value tag"));
            }
        };
        values.push(value);
    }
    if cursor != bytes.len() {
        return Err(PhobosError::new(
            ErrorCode::Io,
            "spill row contains trailing bytes",
        ));
    }
    Ok(Row::new(values))
}

fn take_spill_u32(bytes: &[u8], cursor: &mut usize) -> Result<u32, PhobosError> {
    Ok(u32::from_le_bytes(take_spill_array::<4>(bytes, cursor)?))
}

fn take_spill_array<const N: usize>(
    bytes: &[u8],
    cursor: &mut usize,
) -> Result<[u8; N], PhobosError> {
    let end = cursor
        .checked_add(N)
        .ok_or_else(|| PhobosError::new(ErrorCode::Io, "spill offset overflow"))?;
    if end > bytes.len() {
        return Err(PhobosError::new(ErrorCode::Io, "truncated spill row"));
    }
    let value = bytes[*cursor..end]
        .try_into()
        .map_err(|_| PhobosError::new(ErrorCode::Io, "truncated spill row"))?;
    *cursor = end;
    Ok(value)
}

fn take_spill_bytes<'a>(bytes: &'a [u8], cursor: &mut usize) -> Result<&'a [u8], PhobosError> {
    let len = take_spill_u32(bytes, cursor)? as usize;
    let end = cursor
        .checked_add(len)
        .ok_or_else(|| PhobosError::new(ErrorCode::Io, "spill offset overflow"))?;
    if end > bytes.len() {
        return Err(PhobosError::new(ErrorCode::Io, "truncated spill row"));
    }
    let value = &bytes[*cursor..end];
    *cursor = end;
    Ok(value)
}

fn open_heaps(
    data_dir: &Path,
    catalog: &Catalog,
    buffer_pages: usize,
) -> Result<BTreeMap<TableId, HeapTable>, PhobosError> {
    let mut heaps = BTreeMap::new();
    for schema in catalog.tables() {
        heaps.insert(
            schema.id,
            HeapTable::open(heap_path(data_dir, schema.id), schema.clone(), buffer_pages)?,
        );
    }
    Ok(heaps)
}

fn open_indexes(
    data_dir: &Path,
    catalog: &Catalog,
) -> Result<BTreeMap<IndexId, BPlusTree>, PhobosError> {
    let mut indexes = BTreeMap::new();
    for definition in catalog.indexes() {
        let path = index_path(data_dir, definition.id);
        if !path.exists() {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                format!("index file for {} is missing", definition.name),
            ));
        }
        let mut tree = BPlusTree::open(&path, definition.unique, definition.columns.len())?;
        let _ = tree.validate()?;
        indexes.insert(definition.id, tree);
    }
    Ok(indexes)
}

fn cleanup_orphan_index_files(data_dir: &Path, catalog: &Catalog) -> Result<(), PhobosError> {
    let live: std::collections::BTreeSet<PathBuf> = catalog
        .indexes()
        .map(|index| index_path(data_dir, index.id))
        .collect();
    for entry in phobos_observability::measure("fs.read_dir", || fs::read_dir(data_dir))? {
        let entry = entry?;
        let path = entry.path();
        if path.extension().and_then(|value| value.to_str()) == Some("idx") && !live.contains(&path)
        {
            phobos_observability::measure("fs.remove_file", || fs::remove_file(path))?;
        }
    }
    Ok(())
}

fn index_path(data_dir: &Path, index_id: IndexId) -> PathBuf {
    data_dir.join(format!("index-{index_id:016x}.idx"))
}

fn transaction_dir(data_dir: &Path, id: TransactionId) -> PathBuf {
    data_dir.join(format!(".phobos-txn-{id:016x}"))
}

fn copy_database_files(source: &Path, destination: &Path) -> Result<(), PhobosError> {
    let _measurement = phobos_observability::span("fs.copy_database");
    for entry in phobos_observability::measure("fs.read_dir", || fs::read_dir(source))? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file()
            && matches!(
                path.extension().and_then(|value| value.to_str()),
                Some("phc" | "heap" | "idx" | "stats")
            )
        {
            phobos_observability::measure("fs.copy", || {
                fs::copy(&path, destination.join(entry.file_name()))
            })?;
        }
    }
    Ok(())
}

fn cleanup_spill_dirs(data_dir: &Path) -> Result<(), PhobosError> {
    for entry in phobos_observability::measure("fs.read_dir", || fs::read_dir(data_dir))? {
        let entry = entry?;
        if entry.file_type()?.is_dir()
            && entry
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill-")
        {
            phobos_observability::measure("fs.remove_dir_all", || {
                fs::remove_dir_all(entry.path())
            })?;
        }
    }
    Ok(())
}

fn cleanup_transaction_dirs(data_dir: &Path) -> Result<(), PhobosError> {
    for entry in phobos_observability::measure("fs.read_dir", || fs::read_dir(data_dir))? {
        let entry = entry?;
        if entry.file_type()?.is_dir()
            && entry
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-txn-")
        {
            phobos_observability::measure("fs.remove_dir_all", || {
                fs::remove_dir_all(entry.path())
            })?;
        }
    }
    Ok(())
}

fn heap_path(data_dir: &Path, table_id: TableId) -> PathBuf {
    data_dir.join(format!("table-{table_id:016x}.heap"))
}

/// 0.2-K Part H: table column positions of an index's key, in key order.
fn index_key_columns(
    catalog: &Catalog,
    table: &TableSchema,
    index: IndexId,
) -> Result<Vec<usize>, PhobosError> {
    let definition = catalog
        .indexes()
        .find(|candidate| candidate.id == index)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "index definition missing"))?;
    definition
        .columns
        .iter()
        .map(|column| {
            table.column_index(column).ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "index references a missing table column",
                )
            })
        })
        .collect()
}

/// 0.2-K Part H: whether a fetched row still carries the key of the index
/// entry whose RID named it. A RID copied from an index before the slot was
/// reclaimed and reused names a row with another key: such a reference is
/// stale and is skipped, never returned as the old row.
fn row_matches_key(row: &Row, columns: &[usize], key: &IndexKey) -> bool {
    columns.len() == key.0.len()
        && IndexKey(
            columns
                .iter()
                .map(|column| row.values[*column].clone())
                .collect(),
        ) == *key
}

/// 0.2-K Part H: `row_matches_key` for borrowed values (the key columns
/// must have been decoded).
fn values_match_key(values: &[ValueRef<'_>], columns: &[usize], key: &IndexKey) -> bool {
    let mut owned = Vec::with_capacity(columns.len());
    for column in columns {
        match values.get(*column).and_then(ValueRef::to_value) {
            Some(value) => owned.push(value),
            None => return false,
        }
    }
    owned.len() == key.0.len() && IndexKey(owned) == *key
}

/// 0.2-K Part H: one stale index reference was skipped.
fn stale_rid_skipped() {
    phobos_observability::event("mvcc.stale_rid_skipped", 1);
}

fn index_key_for_row(
    table: &TableSchema,
    index: &IndexSchema,
    row: &Row,
) -> Result<IndexKey, PhobosError> {
    let mut values = Vec::with_capacity(index.columns.len());
    for column in &index.columns {
        let position = table.column_index(column).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::InvalidCatalog,
                "index references a missing table column",
            )
        })?;
        values.push(row.values[position].clone());
    }
    Ok(IndexKey(values))
}

fn build_index_search(
    table: &TableSchema,
    index: &IndexSchema,
    filter: &Expr,
    params: &[Value],
) -> Result<Option<IndexSearch>, PhobosError> {
    use index_bounds::{Translation, translate};
    let mut constraints = Vec::new();
    collect_constraints(filter, params, &mut constraints)?;
    let never = || IndexSearch {
        index_id: index.id,
        index_name: index.name.clone(),
        ranges: Vec::new(),
    };
    let column_position = |column_name: &str| {
        table.column_index(column_name).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::InvalidCatalog,
                "index references a missing table column",
            )
        })
    };
    if index.columns.len() > 1 {
        // Composite probes consume the longest exact leading equality prefix.
        // A complete key remains a point probe; a shorter prefix is traversed
        // directly by the B+ tree and every candidate is still rechecked.
        let mut values = Vec::with_capacity(index.columns.len());
        for column_name in &index.columns {
            let column = &table.columns[column_position(column_name)?];
            let mut key: Option<Value> = None;
            for (_, _, value) in constraints.iter().filter(|(column, op, _)| {
                column.eq_ignore_ascii_case(column_name) && *op == BinaryOp::Eq
            }) {
                let translation = translate(&column.data_type, BinaryOp::Eq, value);
                if translation == Translation::Never {
                    return Ok(Some(never()));
                }
                let Some(exact) = translation.exact_key() else {
                    continue;
                };
                match &key {
                    None => key = Some(exact.clone()),
                    Some(existing) if existing.canonical_key() == exact.canonical_key() => {}
                    Some(_) => return Ok(Some(never())),
                }
            }
            let Some(key) = key else {
                break;
            };
            values.push(key);
        }
        if values.is_empty() {
            return Ok(None);
        }
        let key = IndexKey(values);
        if key.0.len() < index.columns.len() {
            return Ok(Some(IndexSearch {
                index_id: index.id,
                index_name: index.name.clone(),
                ranges: vec![KeyRange {
                    lower: None,
                    upper: None,
                    prefix: Some(key),
                }],
            }));
        }
        return Ok(Some(IndexSearch {
            index_id: index.id,
            index_name: index.name.clone(),
            ranges: vec![KeyRange {
                lower: Some((key.clone(), true)),
                upper: Some((key, true)),
                prefix: None,
            }],
        }));
    }
    let column_name = &index.columns[0];
    let column = &table.columns[column_position(column_name)?];
    let mut lower: index_bounds::ValueBound = None;
    let mut upper: index_bounds::ValueBound = None;
    // The negative-NaN region stays a candidate only while every constraint
    // that narrows the range allows it (or the range is unbounded below).
    let mut negative_nan = true;
    let mut used = false;
    for (name, op, value) in &constraints {
        if !name.eq_ignore_ascii_case(column_name) {
            continue;
        }
        match translate(&column.data_type, *op, value) {
            Translation::Skip => {}
            Translation::Never => return Ok(Some(never())),
            Translation::Range {
                lower: low,
                upper: high,
                negative_nan: nan,
            } => {
                used = true;
                lower = tighter_bound(lower, low, Ordering::Greater);
                upper = tighter_bound(upper, high, Ordering::Less);
                negative_nan &= nan;
            }
        }
    }
    if !used {
        return Ok(None);
    }
    let key = |bound: index_bounds::ValueBound| {
        bound.map(|(value, inclusive)| (IndexKey(vec![value]), inclusive))
    };
    let mut ranges = vec![KeyRange {
        lower: key(lower.clone()),
        upper: key(upper),
        prefix: None,
    }];
    if matches!(column.data_type, DataType::Float64) && negative_nan && lower.is_some() {
        // Negative NaNs sort below -inf in the index but above every number
        // for the predicate: scan that region too.
        ranges.push(KeyRange {
            lower: None,
            upper: Some((IndexKey(vec![Value::Float64(f64::NEG_INFINITY)]), false)),
            prefix: None,
        });
    }
    Ok(Some(IndexSearch {
        index_id: index.id,
        index_name: index.name.clone(),
        ranges,
    }))
}

/// Intersects two bounds on one key column in index order: `keep` says which
/// side wins (`Greater` for lower bounds, `Less` for upper bounds); an
/// exclusive bound wins over an inclusive one at the same key.
fn tighter_bound(
    current: index_bounds::ValueBound,
    next: index_bounds::ValueBound,
    keep: Ordering,
) -> index_bounds::ValueBound {
    match (current, next) {
        (None, next) => next,
        (current, None) => current,
        (Some((a, a_inclusive)), Some((b, b_inclusive))) => {
            let ordering = IndexKey(vec![a.clone()]).cmp(&IndexKey(vec![b.clone()]));
            if ordering == keep || (ordering == Ordering::Equal && !a_inclusive) {
                Some((a, a_inclusive))
            } else {
                Some((b, b_inclusive))
            }
        }
    }
}

fn collect_constraints(
    expr: &Expr,
    params: &[Value],
    out: &mut Vec<(String, BinaryOp, Value)>,
) -> Result<(), PhobosError> {
    if let Expr::Binary {
        left,
        op: BinaryOp::And,
        right,
    } = expr
    {
        collect_constraints(left, params, out)?;
        collect_constraints(right, params, out)?;
        return Ok(());
    }
    let Expr::Binary { left, op, right } = expr else {
        return Ok(());
    };
    if !matches!(
        op,
        BinaryOp::Eq | BinaryOp::Lt | BinaryOp::LtEq | BinaryOp::Gt | BinaryOp::GtEq
    ) {
        return Ok(());
    }
    if let Expr::Column(column) = left.as_ref() {
        if let Some(value) = constant_expr_value(right, params)? {
            out.push((column.clone(), *op, value));
        }
    } else if let Expr::Column(column) = right.as_ref() {
        if let Some(value) = constant_expr_value(left, params)? {
            out.push((column.clone(), reverse_comparison(*op), value));
        }
    }
    Ok(())
}

fn constant_expr_value(expr: &Expr, params: &[Value]) -> Result<Option<Value>, PhobosError> {
    match expr {
        Expr::Literal(value) => Ok(Some(value.clone())),
        Expr::Parameter(index) => params.get(*index).cloned().map(Some).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::Semantic,
                format!("missing parameter ${}", index + 1),
            )
        }),
        _ => Ok(None),
    }
}

fn reverse_comparison(op: BinaryOp) -> BinaryOp {
    match op {
        BinaryOp::Lt => BinaryOp::Gt,
        BinaryOp::LtEq => BinaryOp::GtEq,
        BinaryOp::Gt => BinaryOp::Lt,
        BinaryOp::GtEq => BinaryOp::LtEq,
        other => other,
    }
}

fn projection(
    schema: &TableSchema,
    selection: SelectColumns,
) -> Result<(Vec<String>, Vec<usize>), PhobosError> {
    match selection {
        SelectColumns::All => Ok((
            schema.columns.iter().map(|c| c.name.clone()).collect(),
            (0..schema.columns.len()).collect(),
        )),
        SelectColumns::Named(names) => {
            let mut indexes = Vec::with_capacity(names.len());
            let mut output = Vec::with_capacity(names.len());
            for name in names {
                let index = schema.column_index(&name).ok_or_else(|| {
                    PhobosError::new(ErrorCode::NotFound, format!("column {name} does not exist"))
                })?;
                indexes.push(index);
                output.push(schema.columns[index].name.clone());
            }
            Ok((output, indexes))
        }
    }
}
fn project_row(row: &Row, indexes: &[usize]) -> Row {
    Row::new(indexes.iter().map(|i| row.values[*i].clone()).collect())
}
fn bind_order(schema: &TableSchema, order: &[OrderBy]) -> Result<Vec<(usize, bool)>, PhobosError> {
    order
        .iter()
        .map(|item| {
            schema
                .column_index(&item.column)
                .map(|i| (i, item.ascending))
                .ok_or_else(|| {
                    PhobosError::new(
                        ErrorCode::NotFound,
                        format!("column {} does not exist", item.column),
                    )
                })
        })
        .collect()
}
fn compare_rows(a: &Row, b: &Row, order: &[(usize, bool)]) -> Result<Ordering, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.compare_rows")?;
    for (index, ascending) in order {
        let ord = compare_for_sort(&a.values[*index], &b.values[*index])?;
        if ord != Ordering::Equal {
            return Ok(if *ascending { ord } else { ord.reverse() });
        }
    }
    Ok(Ordering::Equal)
}
fn compare_for_sort(a: &Value, b: &Value) -> Result<Ordering, PhobosError> {
    compare_for_sort_ref(a.as_value_ref(), b.as_value_ref())
}
/// `compare_rows` with a borrowed left side; identical ordering.
fn compare_values_to_row(
    a: &[ValueRef<'_>],
    b: &Row,
    order: &[(usize, bool)],
) -> Result<Ordering, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.compare_rows")?;
    for (index, ascending) in order {
        let ord = compare_for_sort_ref(a[*index], b.values[*index].as_value_ref())?;
        if ord != Ordering::Equal {
            return Ok(if *ascending { ord } else { ord.reverse() });
        }
    }
    Ok(Ordering::Equal)
}
fn matches_filter(
    filter: Option<&Expr>,
    schema: &TableSchema,
    row: &Row,
    params: &[Value],
) -> Result<bool, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.matches_filter")?;
    match filter {
        None => Ok(true),
        Some(expr) => {
            if let Expr::Binary { left, op, right } = expr {
                if matches!(
                    op,
                    BinaryOp::Eq
                        | BinaryOp::NotEq
                        | BinaryOp::Lt
                        | BinaryOp::LtEq
                        | BinaryOp::Gt
                        | BinaryOp::GtEq
                ) {
                    let left = borrowed_filter_operand(left, schema, row, params)?;
                    let right = borrowed_filter_operand(right, schema, row, params)?;
                    if let (Some(left), Some(right)) = (left, right) {
                        let _fast = phobos_observability::span("predicate.borrowed_compare");
                        return Ok(to_truth(compare_values(left, *op, right)?)? == Truth::True);
                    }
                }
            }
            Ok(to_truth(eval_expr(expr, schema, Some(row), params)?)? == Truth::True)
        }
    }
}

fn borrowed_filter_operand<'a>(
    expr: &'a Expr,
    schema: &TableSchema,
    row: &'a Row,
    params: &'a [Value],
) -> Result<Option<&'a Value>, PhobosError> {
    match expr {
        Expr::Literal(value) => Ok(Some(value)),
        Expr::Parameter(index) => params.get(*index).map(Some).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::Semantic,
                format!("missing parameter ${}", index + 1),
            )
        }),
        Expr::Column(name) => schema
            .column_index(name)
            .map(|index| Some(&row.values[index]))
            .ok_or_else(|| {
                PhobosError::new(ErrorCode::NotFound, format!("column {name} does not exist"))
            }),
        Expr::QuotedColumn(name) => schema
            .columns
            .iter()
            .position(|column| column.name == *name)
            .map(|index| Some(&row.values[index]))
            .ok_or_else(|| {
                PhobosError::new(ErrorCode::NotFound, format!("column {name} does not exist"))
            }),
        _ => Ok(None),
    }
}

fn eval_expr(
    expr: &Expr,
    schema: &TableSchema,
    row: Option<&Row>,
    params: &[Value],
) -> Result<Value, PhobosError> {
    phobos_error::cancellation::checkpoint_at("lib.eval_expr")?;
    match expr {
        Expr::Literal(value) => Ok(value.clone()),
        Expr::Parameter(index) => params.get(*index).cloned().ok_or_else(|| {
            PhobosError::new(
                ErrorCode::Semantic,
                format!("missing parameter ${}", index + 1),
            )
        }),
        Expr::Column(name) => {
            let row = row.ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Semantic,
                    format!("column {name} is not valid in this context"),
                )
            })?;
            let index = schema.column_index(name).ok_or_else(|| {
                PhobosError::new(ErrorCode::NotFound, format!("column {name} does not exist"))
            })?;
            let _clone = phobos_observability::span("predicate.column_value_clone");
            Ok(row.values[index].clone())
        }
        Expr::QuotedColumn(name) => {
            let row = row.ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Semantic,
                    format!("column {name} is not valid in this context"),
                )
            })?;
            let index = schema
                .columns
                .iter()
                .position(|column| column.name == *name)
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::NotFound, format!("column {name} does not exist"))
                })?;
            Ok(row.values[index].clone())
        }
        Expr::Unary {
            op: UnaryOp::Not,
            expr,
        } => Ok(truth_value(
            match to_truth(eval_expr(expr, schema, row, params)?)? {
                Truth::True => Truth::False,
                Truth::False => Truth::True,
                Truth::Unknown => Truth::Unknown,
            },
        )),
        Expr::Unary {
            op: UnaryOp::Negate,
            expr,
        } => negate(eval_expr(expr, schema, row, params)?),
        Expr::IsNull { expr, negated } => {
            let is_null = eval_expr(expr, schema, row, params)?.is_null();
            Ok(Value::Boolean(if *negated { !is_null } else { is_null }))
        }
        Expr::Binary { left, op, right } => {
            if *op == BinaryOp::And || *op == BinaryOp::Or {
                let left = to_truth(eval_expr(left, schema, row, params)?)?;
                let right = to_truth(eval_expr(right, schema, row, params)?)?;
                return Ok(truth_value(if *op == BinaryOp::And {
                    truth_and(left, right)
                } else {
                    truth_or(left, right)
                }));
            }
            let left = eval_expr(left, schema, row, params)?;
            let right = eval_expr(right, schema, row, params)?;
            match op {
                BinaryOp::Eq
                | BinaryOp::NotEq
                | BinaryOp::Lt
                | BinaryOp::LtEq
                | BinaryOp::Gt
                | BinaryOp::GtEq => {
                    let _compare = phobos_observability::span("predicate.compare");
                    compare_values(&left, *op, &right)
                }
                BinaryOp::Add | BinaryOp::Subtract | BinaryOp::Multiply | BinaryOp::Divide => {
                    arithmetic(&left, *op, &right)
                }
                BinaryOp::And | BinaryOp::Or => unreachable!(),
            }
        }
        Expr::Function { name, args } => {
            let values = args
                .iter()
                .map(|arg| eval_expr(arg, schema, row, params))
                .collect::<Result<Vec<_>, _>>()?;
            eval_builtin(name, values)
        }
        Expr::Like { expr, pattern } => eval_like(
            eval_expr(expr, schema, row, params)?,
            eval_expr(pattern, schema, row, params)?,
        ),
        Expr::InList { expr, values } => {
            let needle = eval_expr(expr, schema, row, params)?;
            let values = values
                .iter()
                .map(|value| eval_expr(value, schema, row, params))
                .collect::<Result<Vec<_>, _>>()?;
            eval_in(needle, values)
        }
        Expr::InSubquery { .. } | Expr::ScalarSubquery(_) | Expr::Exists(_) => {
            Err(PhobosError::new(
                ErrorCode::Semantic,
                "IN subqueries require relational execution",
            ))
        }
        Expr::Case {
            branches,
            else_expr,
        } => {
            for (when, then) in branches {
                if to_truth(eval_expr(when, schema, row, params)?)? == Truth::True {
                    return eval_expr(then, schema, row, params);
                }
            }
            else_expr
                .as_ref()
                .map_or(Ok(Value::Null), |expr| eval_expr(expr, schema, row, params))
        }
    }
}

fn truth_value(value: Truth) -> Value {
    match value {
        Truth::True => Value::Boolean(true),
        Truth::False => Value::Boolean(false),
        Truth::Unknown => Value::Null,
    }
}
fn to_truth(value: Value) -> Result<Truth, PhobosError> {
    match value {
        Value::Boolean(true) => Ok(Truth::True),
        Value::Boolean(false) => Ok(Truth::False),
        Value::Null => Ok(Truth::Unknown),
        _ => Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "predicate requires BOOLEAN",
        )),
    }
}
fn truth_and(a: Truth, b: Truth) -> Truth {
    match (a, b) {
        (Truth::False, _) | (_, Truth::False) => Truth::False,
        (Truth::True, Truth::True) => Truth::True,
        _ => Truth::Unknown,
    }
}
fn truth_or(a: Truth, b: Truth) -> Truth {
    match (a, b) {
        (Truth::True, _) | (_, Truth::True) => Truth::True,
        (Truth::False, Truth::False) => Truth::False,
        _ => Truth::Unknown,
    }
}

fn compare_values(a: &Value, op: BinaryOp, b: &Value) -> Result<Value, PhobosError> {
    if a.is_null() || b.is_null() {
        return Ok(Value::Null);
    }
    let ordering = compare_non_null(a, b)?;
    Ok(Value::Boolean(match op {
        BinaryOp::Eq => ordering == Ordering::Equal,
        BinaryOp::NotEq => ordering != Ordering::Equal,
        BinaryOp::Lt => ordering == Ordering::Less,
        BinaryOp::LtEq => ordering != Ordering::Greater,
        BinaryOp::Gt => ordering == Ordering::Greater,
        BinaryOp::GtEq => ordering != Ordering::Less,
        _ => unreachable!(),
    }))
}
/// The single ordering/equality used by predicates, joins, grouping, ORDER BY
/// and MIN/MAX: `Value::canonical_cmp` (see phobos-types for the contract).
fn compare_non_null(a: &Value, b: &Value) -> Result<Ordering, PhobosError> {
    compare_non_null_ref(a.as_value_ref(), b.as_value_ref())
}
/// 0.2-B: the borrowed form of `compare_non_null`, shared by both paths.
fn compare_non_null_ref(a: ValueRef<'_>, b: ValueRef<'_>) -> Result<Ordering, PhobosError> {
    if a.is_absent() || b.is_absent() {
        return Err(unprojected());
    }
    a.canonical_cmp(&b)
        .ok_or_else(|| PhobosError::new(ErrorCode::TypeMismatch, "values are not comparable"))
}
/// 0.2-B: an operator read a column its producer was told not to decode.
/// Always an engine defect; surfaced loudly instead of as a NULL.
fn unprojected() -> PhobosError {
    PhobosError::new(
        ErrorCode::InvalidPage,
        "internal error: column was not projected for this operator",
    )
}
/// Borrowed `compare_for_sort` (NULLs last), identical ordering.
fn compare_for_sort_ref(a: ValueRef<'_>, b: ValueRef<'_>) -> Result<Ordering, PhobosError> {
    match (a, b) {
        (ValueRef::Null, ValueRef::Null) => Ok(Ordering::Equal),
        (ValueRef::Null, _) if !b.is_absent() => Ok(Ordering::Greater),
        (_, ValueRef::Null) if !a.is_absent() => Ok(Ordering::Less),
        _ => compare_non_null_ref(a, b),
    }
}
fn negate(value: Value) -> Result<Value, PhobosError> {
    match value {
        Value::Null => Ok(Value::Null),
        Value::Int64(value) => value
            .checked_neg()
            .map(Value::Int64)
            .ok_or_else(|| PhobosError::new(ErrorCode::TypeMismatch, "integer overflow")),
        Value::Float64(value) => Ok(Value::Float64(-value)),
        Value::Decimal { unscaled, scale } => unscaled
            .checked_neg()
            .map(|v| Value::Decimal { unscaled: v, scale })
            .ok_or_else(|| PhobosError::new(ErrorCode::TypeMismatch, "decimal overflow")),
        _ => Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "unary minus requires numeric value",
        )),
    }
}
fn arithmetic(a: &Value, op: BinaryOp, b: &Value) -> Result<Value, PhobosError> {
    if a.is_null() || b.is_null() {
        return Ok(Value::Null);
    }
    match (a, b) {
        (Value::Int64(a), Value::Int64(b)) => {
            let value = match op {
                BinaryOp::Add => a.checked_add(*b),
                BinaryOp::Subtract => a.checked_sub(*b),
                BinaryOp::Multiply => a.checked_mul(*b),
                BinaryOp::Divide if *b != 0 => a.checked_div(*b),
                BinaryOp::Divide => {
                    return Err(PhobosError::new(ErrorCode::Semantic, "division by zero"));
                }
                _ => unreachable!(),
            };
            value
                .map(Value::Int64)
                .ok_or_else(|| PhobosError::new(ErrorCode::TypeMismatch, "integer overflow"))
        }
        (Value::Float64(a), Value::Float64(b)) => numeric_float(*a, op, *b),
        (Value::Int64(a), Value::Float64(b)) => numeric_float(*a as f64, op, *b),
        (Value::Float64(a), Value::Int64(b)) => numeric_float(*a, op, *b as f64),
        (
            Value::Decimal {
                unscaled: a,
                scale: sa,
            },
            Value::Decimal {
                unscaled: b,
                scale: sb,
            },
        ) if sa == sb && matches!(op, BinaryOp::Add | BinaryOp::Subtract) => {
            let value = if op == BinaryOp::Add {
                a.checked_add(*b)
            } else {
                a.checked_sub(*b)
            };
            value
                .map(|unscaled| Value::Decimal {
                    unscaled,
                    scale: *sa,
                })
                .ok_or_else(|| PhobosError::new(ErrorCode::TypeMismatch, "decimal overflow"))
        }
        _ => Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "arithmetic operands are incompatible",
        )),
    }
}
fn numeric_float(a: f64, op: BinaryOp, b: f64) -> Result<Value, PhobosError> {
    if op == BinaryOp::Divide && b == 0.0 {
        return Err(PhobosError::new(ErrorCode::Semantic, "division by zero"));
    }
    Ok(Value::Float64(match op {
        BinaryOp::Add => a + b,
        BinaryOp::Subtract => a - b,
        BinaryOp::Multiply => a * b,
        BinaryOp::Divide => a / b,
        _ => unreachable!(),
    }))
}
fn eval_count(
    expr: Option<&Expr>,
    params: &[Value],
    label: &str,
) -> Result<Option<usize>, PhobosError> {
    let Some(expr) = expr else {
        return Ok(None);
    };
    let value = match expr {
        Expr::Literal(value) => value.clone(),
        Expr::Parameter(index) => params.get(*index).cloned().ok_or_else(|| {
            PhobosError::new(
                ErrorCode::Semantic,
                format!("missing parameter ${}", index + 1),
            )
        })?,
        _ => {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                format!("{label} must be an integer literal or parameter"),
            ));
        }
    };
    match value {
        Value::Int64(value) if value >= 0 => usize::try_from(value)
            .map(Some)
            .map_err(|_| PhobosError::new(ErrorCode::Semantic, format!("{label} is too large"))),
        _ => Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            format!("{label} must be a non-negative integer"),
        )),
    }
}

fn coerce_value(column: &ColumnSchema, value: Value) -> Result<Value, PhobosError> {
    if value == Value::Null {
        if column.nullable {
            return Ok(Value::Null);
        }
        return Err(PhobosError::new(
            ErrorCode::ConstraintViolation,
            format!("column {} does not allow NULL", column.name),
        ));
    }
    Ok(match (&column.data_type, value) {
        (DataType::Int64, value @ Value::Int64(_)) => value,
        (DataType::Boolean, value @ Value::Boolean(_)) => value,
        (DataType::Float64, value @ Value::Float64(_)) => value,
        (DataType::Float64, Value::Int64(value)) => Value::Float64(value as f64),
        (DataType::Text, value @ Value::Text(_)) => value,
        (DataType::Binary, value @ Value::Binary(_)) => value,
        (DataType::Binary, Value::Text(value)) => Value::Binary(value.into_bytes()),
        (DataType::Date, value @ Value::Date(_)) => value,
        (DataType::Date, Value::Text(value)) => Value::Date(parse_date(&value)?),
        (DataType::Timestamp, value @ Value::Timestamp(_)) => value,
        (DataType::Timestamp, Value::Int64(value)) => Value::Timestamp(value),
        (DataType::Timestamp, Value::Text(value)) => Value::Timestamp(parse_timestamp(&value)?),
        (DataType::Decimal { precision, scale }, Value::Int64(value)) => {
            decimal_from_text(&value.to_string(), *precision, *scale)?
        }
        (DataType::Decimal { precision, scale }, Value::Float64(value)) => {
            decimal_from_text(&value.to_string(), *precision, *scale)?
        }
        (DataType::Decimal { precision, scale }, Value::Text(value)) => {
            decimal_from_text(&value, *precision, *scale)?
        }
        (
            DataType::Decimal { precision, scale },
            Value::Decimal {
                unscaled,
                scale: value_scale,
            },
        ) if *scale == value_scale => {
            validate_decimal_precision(unscaled, *precision)?;
            Value::Decimal {
                unscaled,
                scale: value_scale,
            }
        }
        _ => {
            return Err(PhobosError::new(
                ErrorCode::TypeMismatch,
                format!("value does not match type of column {}", column.name),
            ));
        }
    })
}
fn decimal_from_text(value: &str, precision: u8, scale: u8) -> Result<Value, PhobosError> {
    let value = value.trim();
    let negative = value.starts_with('-');
    let unsigned = value
        .strip_prefix('-')
        .or_else(|| value.strip_prefix('+'))
        .unwrap_or(value);
    let mut parts = unsigned.split('.');
    let whole = parts.next().unwrap_or("");
    let fraction = parts.next().unwrap_or("");
    if parts.next().is_some()
        || whole.is_empty()
        || !whole.chars().all(|c| c.is_ascii_digit())
        || !fraction.chars().all(|c| c.is_ascii_digit())
        || fraction.len() > usize::from(scale)
    {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "invalid DECIMAL literal",
        ));
    }
    let mut digits = String::from(whole);
    digits.push_str(fraction);
    for _ in fraction.len()..usize::from(scale) {
        digits.push('0');
    }
    let mut unscaled = digits.parse::<i128>().map_err(|_| {
        PhobosError::new(ErrorCode::TypeMismatch, "DECIMAL literal is out of range")
    })?;
    if negative {
        unscaled = -unscaled;
    }
    validate_decimal_precision(unscaled, precision)?;
    Ok(Value::Decimal { unscaled, scale })
}
fn validate_decimal_precision(unscaled: i128, precision: u8) -> Result<(), PhobosError> {
    if unscaled.unsigned_abs().to_string().len() > usize::from(precision) {
        Err(PhobosError::new(
            ErrorCode::ConstraintViolation,
            "DECIMAL precision exceeded",
        ))
    } else {
        Ok(())
    }
}
fn parse_date(value: &str) -> Result<i32, PhobosError> {
    let mut parts = value.split('-');
    let year = parts.next().and_then(|v| v.parse::<i32>().ok());
    let month = parts.next().and_then(|v| v.parse::<u32>().ok());
    let day = parts.next().and_then(|v| v.parse::<u32>().ok());
    if parts.next().is_some() {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "DATE must use YYYY-MM-DD",
        ));
    }
    let (Some(year), Some(month), Some(day)) = (year, month, day) else {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "DATE must use YYYY-MM-DD",
        ));
    };
    if !(1..=12).contains(&month) || day == 0 || day > days_in_month(year, month) {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "invalid calendar date",
        ));
    }
    let adjusted_year = year - if month <= 2 { 1 } else { 0 };
    let era = if adjusted_year >= 0 {
        adjusted_year
    } else {
        adjusted_year - 399
    } / 400;
    let yoe = adjusted_year - era * 400;
    let mp = i32::try_from(month).expect("month") + if month > 2 { -3 } else { 9 };
    let doy = (153 * mp + 2) / 5 + i32::try_from(day).expect("day") - 1;
    Ok(era * 146_097 + yoe * 365 + yoe / 4 - yoe / 100 + doy - 719_468)
}
fn parse_timestamp(value: &str) -> Result<i64, PhobosError> {
    let Some((date, time)) = value.split_once(' ') else {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "TIMESTAMP must use YYYY-MM-DD HH:MM:SS",
        ));
    };
    let days = i64::from(parse_date(date)?);
    let mut parts = time.split(':');
    let h = parts.next().and_then(|v| v.parse::<u32>().ok());
    let m = parts.next().and_then(|v| v.parse::<u32>().ok());
    let s = parts.next().and_then(|v| v.parse::<u32>().ok());
    if parts.next().is_some() {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "TIMESTAMP must use YYYY-MM-DD HH:MM:SS",
        ));
    }
    let (Some(h), Some(m), Some(s)) = (h, m, s) else {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "TIMESTAMP must use YYYY-MM-DD HH:MM:SS",
        ));
    };
    if h > 23 || m > 59 || s > 59 {
        return Err(PhobosError::new(
            ErrorCode::TypeMismatch,
            "invalid timestamp clock time",
        ));
    }
    (days * 86_400 + i64::from(h) * 3_600 + i64::from(m) * 60 + i64::from(s))
        .checked_mul(1_000_000)
        .ok_or_else(|| PhobosError::new(ErrorCode::TypeMismatch, "timestamp out of range"))
}
fn days_in_month(year: i32, month: u32) -> u32 {
    match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 if year % 400 == 0 || (year % 4 == 0 && year % 100 != 0) => 29,
        2 => 28,
        _ => 0,
    }
}

fn is_default_expr(expr: &Expr) -> bool {
    matches!(expr, Expr::Function {name, args} if name == "__phobos_default" && args.is_empty())
}

/// Resolve column lists against one catalog generation, retaining positional DML
/// as the only write operator. Omitted columns receive SQL NULL.
fn expand_insert_columns(
    catalog: &Catalog,
    table: String,
    columns: Vec<String>,
    rows: Vec<Vec<Expr>>,
) -> Result<Statement, PhobosError> {
    let schema = catalog
        .table(&table)
        .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "INSERT table does not exist"))?;
    let mut positions = Vec::new();
    for column in columns {
        let position = schema.column_index(&column).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::NotFound,
                format!("INSERT column {column} does not exist"),
            )
        })?;
        if positions.contains(&position) {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "duplicate INSERT column",
            ));
        }
        positions.push(position);
    }
    let mut expanded = Vec::with_capacity(rows.len());
    for row in rows {
        if row.len() != positions.len() {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "INSERT column count mismatch",
            ));
        }
        let mut values = vec![
            Expr::Function {
                name: "__phobos_default".into(),
                args: Vec::new()
            };
            schema.columns.len()
        ];
        if let Some(definition) = catalog.definitions(schema.id) {
            for (ordinal, value) in &definition.defaults {
                values[*ordinal] = Expr::Literal(value.clone());
            }
        }
        if catalog
            .definitions(schema.id)
            .is_none_or(|d| d.identity.is_none())
        {
            for value in &mut values {
                if is_default_expr(value) {
                    *value = Expr::Literal(Value::Null);
                }
            }
        }
        for (position, value) in positions.iter().zip(row) {
            values[*position] = value;
        }
        expanded.push(values);
    }
    Ok(Statement::Insert {
        table,
        rows: expanded,
    })
}

#[cfg(test)]
mod tests {
    #[test]
    fn result_text_preserves_wire_bytes_for_all_value_types() {
        let result = super::QueryResult::Rows {
            columns: vec!["values".into()],
            rows: vec![
                super::Row::new(vec![
                    super::Value::Null,
                    super::Value::Int64(-9223372036854775808),
                    super::Value::Boolean(true),
                    super::Value::Float64(1.5),
                    super::Value::Text("utf8-λ\tline\nend".into()),
                    super::Value::Binary(vec![0, 255]),
                    super::Value::Date(-1),
                    super::Value::Timestamp(123),
                    super::Value::Decimal {
                        unscaled: -7,
                        scale: 3,
                    },
                ]),
                super::Row::new(vec![]),
            ],
        };
        assert_eq!(
            result.to_text(),
            "values\nNULL\t-9223372036854775808\ttrue\t1.5\tutf8-λ\tline\nend\t0x00ff\tDATE(-1)\tTIMESTAMP(123)\t-0.007\n\n"
        );
        assert_eq!(
            super::QueryResult::Rows {
                columns: vec![],
                rows: vec![]
            }
            .to_text(),
            "\n"
        );
        assert_eq!(
            super::QueryResult::Command {
                tag: "INSERT".into(),
                rows_affected: 2
            }
            .to_text(),
            "INSERT 2"
        );
    }
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};
    fn temp_dir() -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-phase3-{n}"))
    }

    #[test]
    fn filters_orders_limits_updates_and_deletes() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE people (id BIGINT NOT NULL, name TEXT, score BIGINT)")
            .unwrap();
        db.execute(
            "INSERT INTO people VALUES (1,'Ada',10),(2,'Grace',NULL),(3,'Linus',30),(4,'Ken',20)",
        )
        .unwrap();
        let result = db.execute_params("SELECT id,name FROM people WHERE score >= $1 OR score IS NULL ORDER BY id DESC LIMIT $2 OFFSET 1", &[Value::Int64(10), Value::Int64(2)]).unwrap();
        let QueryResult::Rows { rows, .. } = result else {
            panic!("rows")
        };
        assert_eq!(
            rows.iter().map(|r| r.values[0].clone()).collect::<Vec<_>>(),
            vec![Value::Int64(3), Value::Int64(2)]
        );
        assert_eq!(
            db.execute_params(
                "UPDATE people SET score=score+$1 WHERE id=$2",
                &[Value::Int64(5), Value::Int64(1)]
            )
            .unwrap(),
            QueryResult::Command {
                tag: "UPDATE".into(),
                rows_affected: 1
            }
        );
        assert_eq!(
            db.execute("DELETE FROM people WHERE score IS NULL")
                .unwrap(),
            QueryResult::Command {
                tag: "DELETE".into(),
                rows_affected: 1
            }
        );
        let QueryResult::Rows { rows, .. } =
            db.execute("SELECT id FROM people ORDER BY id").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 3);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn three_valued_logic_handles_null() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT, v BIGINT)").unwrap();
        db.execute("INSERT INTO t VALUES (1,NULL),(2,2)").unwrap();
        let QueryResult::Rows { rows, .. } = db.execute("SELECT id FROM t WHERE v=NULL").unwrap()
        else {
            panic!("rows")
        };
        assert!(rows.is_empty());
        let QueryResult::Rows { rows, .. } =
            db.execute("SELECT id FROM t WHERE v IS NULL").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 1);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn bounded_streaming_keeps_batches_bounded() {
        let dir = temp_dir();
        let mut db = Database::open_with_buffer_pages(&dir, 2).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, payload TEXT NOT NULL)")
            .unwrap();
        for i in 0..300 {
            db.execute(&format!("INSERT INTO t VALUES ({i},'{}')", "x".repeat(80)))
                .unwrap();
        }
        let mut total = 0usize;
        let mut max = 0usize;
        let columns = db
            .stream_select(
                "SELECT id FROM t WHERE id>=10 LIMIT 101",
                &[],
                17,
                |batch| {
                    total += batch.len();
                    max = max.max(batch.len());
                    Ok(())
                },
            )
            .unwrap();
        assert_eq!(columns, vec!["id".to_string()]);
        assert_eq!(total, 101);
        assert!(max <= 17);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn not_null_remains_enforced() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        assert_eq!(
            db.execute("INSERT INTO t VALUES (NULL)").unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn restart_after_phase2_mutations() {
        let dir = temp_dir();
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL, n BIGINT)")
                .unwrap();
            db.execute("INSERT INTO t VALUES (1,10),(2,20)").unwrap();
            db.execute("UPDATE t SET n=n+1 WHERE id=2").unwrap();
            db.execute("DELETE FROM t WHERE id=1").unwrap();
        }
        {
            let mut db = Database::open(&dir).unwrap();
            let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t").unwrap() else {
                panic!("rows")
            };
            assert_eq!(
                rows,
                vec![Row::new(vec![Value::Int64(2), Value::Int64(21)])]
            );
        }
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn explicit_commit_and_rollback_are_atomic() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, n BIGINT)")
            .unwrap();
        db.execute("BEGIN").unwrap();
        db.execute("INSERT INTO t VALUES (1,10),(2,20)").unwrap();
        let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t ORDER BY id").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 2);
        db.execute("ROLLBACK").unwrap();
        let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t").unwrap() else {
            panic!("rows")
        };
        assert!(rows.is_empty());

        db.execute("BEGIN").unwrap();
        db.execute("INSERT INTO t VALUES (3,30)").unwrap();
        db.execute("COMMIT").unwrap();
        drop(db);
        let mut db = Database::open(&dir).unwrap();
        let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t").unwrap() else {
            panic!("rows")
        };
        assert_eq!(
            rows,
            vec![Row::new(vec![Value::Int64(3), Value::Int64(30)])]
        );
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn transaction_error_requires_rollback_and_cannot_commit() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        db.execute("BEGIN").unwrap();
        assert_eq!(
            db.execute("INSERT INTO t VALUES (NULL)").unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        assert_eq!(
            db.execute("COMMIT").unwrap_err().code,
            ErrorCode::TransactionState
        );
        assert_eq!(
            db.execute("SELECT * FROM t").unwrap_err().code,
            ErrorCode::TransactionState
        );
        db.execute("ROLLBACK").unwrap();
        let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t").unwrap() else {
            panic!("rows")
        };
        assert!(rows.is_empty());
        drop(db);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn crash_child_after_wal_commit() {
        if std::env::var("PHOBOS_CRASH_CHILD").as_deref() != Ok("after_wal_commit") {
            return;
        }
        let dir = PathBuf::from(std::env::var("PHOBOS_CRASH_DIR").unwrap());
        let mut db = Database::open(&dir).unwrap();
        db.execute("INSERT INTO t VALUES (2,200)").unwrap();
        panic!("crash failpoint did not terminate process");
    }

    #[test]
    fn crash_child_with_uncommitted_transaction() {
        if std::env::var("PHOBOS_CRASH_CHILD").as_deref() != Ok("uncommitted") {
            return;
        }
        let dir = PathBuf::from(std::env::var("PHOBOS_CRASH_DIR").unwrap());
        let mut db = Database::open(&dir).unwrap();
        db.execute("BEGIN").unwrap();
        db.execute("INSERT INTO t VALUES (9,900)").unwrap();
        std::process::abort();
    }

    #[test]
    fn subprocess_crash_recovery_preserves_commit_and_hides_uncommitted() {
        let dir = temp_dir();
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL, n BIGINT)")
                .unwrap();
            db.execute("CREATE INDEX ix_t_id ON t (id)").unwrap();
            db.execute("INSERT INTO t VALUES (1,100)").unwrap();
        }
        let test_binary = std::env::current_exe().unwrap();
        let status = std::process::Command::new(&test_binary)
            .arg("--exact")
            .arg("tests::crash_child_after_wal_commit")
            .arg("--nocapture")
            .env("PHOBOS_CRASH_CHILD", "after_wal_commit")
            .env("PHOBOS_CRASH_POINT", "after_wal_commit")
            .env("PHOBOS_CRASH_DIR", &dir)
            .status()
            .unwrap();
        assert!(!status.success());
        {
            let mut db = Database::open(&dir).unwrap();
            let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t ORDER BY id").unwrap()
            else {
                panic!("rows")
            };
            assert_eq!(rows.len(), 2);
            assert_eq!(rows[1].values[0], Value::Int64(2));
            let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t WHERE id=2").unwrap()
            else {
                panic!("rows")
            };
            assert_eq!(rows.len(), 1);
            assert_eq!(db.last_access_path(), Some("INDEX ix_t_id"));
        }

        let status = std::process::Command::new(&test_binary)
            .arg("--exact")
            .arg("tests::crash_child_with_uncommitted_transaction")
            .arg("--nocapture")
            .env("PHOBOS_CRASH_CHILD", "uncommitted")
            .env("PHOBOS_CRASH_DIR", &dir)
            .status()
            .unwrap();
        assert!(!status.success());
        let mut db = Database::open(&dir).unwrap();
        let QueryResult::Rows { rows, .. } = db.execute("SELECT * FROM t ORDER BY id").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 2);
        assert!(rows.iter().all(|row| row.values[0] != Value::Int64(9)));
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn phase4_index_range_planner_and_restart() {
        let dir = temp_dir();
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL, payload TEXT)")
                .unwrap();
            for i in 0..600 {
                db.execute(&format!("INSERT INTO t VALUES ({i},'v{i}')"))
                    .unwrap();
            }
            db.execute("CREATE INDEX ix_t_id ON t (id)").unwrap();
            let QueryResult::Rows { rows, .. } = db
                .execute("SELECT id FROM t WHERE id>=100 AND id<110 ORDER BY id")
                .unwrap()
            else {
                panic!("rows")
            };
            assert_eq!(rows.len(), 10);
            assert_eq!(db.last_access_path(), Some("INDEX ix_t_id"));
        }
        {
            let mut db = Database::open(&dir).unwrap();
            let QueryResult::Rows { rows, .. } =
                db.execute("SELECT * FROM t WHERE id=321").unwrap()
            else {
                panic!("rows")
            };
            assert_eq!(rows.len(), 1);
            assert_eq!(db.last_access_path(), Some("INDEX ix_t_id"));
        }
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn phase4_unique_composite_index_tracks_update_delete_and_drop() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (a TEXT NOT NULL, b BIGINT NOT NULL, n BIGINT)")
            .unwrap();
        db.execute("INSERT INTO t VALUES ('x',1,10),('x',2,20),('y',1,30)")
            .unwrap();
        db.execute("CREATE UNIQUE INDEX ux_t_ab ON t (a,b)")
            .unwrap();
        assert_eq!(
            db.execute("INSERT INTO t VALUES ('x',1,99)")
                .unwrap_err()
                .code,
            ErrorCode::ConstraintViolation
        );
        let QueryResult::Rows { rows, .. } =
            db.execute("SELECT n FROM t WHERE a='x' AND b=2").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows, vec![Row::new(vec![Value::Int64(20)])]);
        assert_eq!(db.last_access_path(), Some("INDEX ux_t_ab"));
        db.execute("UPDATE t SET b=3 WHERE a='x' AND b=2").unwrap();
        let QueryResult::Rows { rows, .. } =
            db.execute("SELECT n FROM t WHERE a='x' AND b=3").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 1);
        db.execute("DELETE FROM t WHERE a='x' AND b=1").unwrap();
        let QueryResult::Rows { rows, .. } =
            db.execute("SELECT * FROM t WHERE a='x' AND b=1").unwrap()
        else {
            panic!("rows")
        };
        assert!(rows.is_empty());
        db.execute("DROP INDEX ux_t_ab").unwrap();
        let QueryResult::Rows { rows, .. } =
            db.execute("SELECT * FROM t WHERE a='x' AND b=3").unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 1);
        assert_eq!(db.last_access_path(), Some("TABLE SCAN"));
        let _ = fs::remove_dir_all(dir);
    }
    #[test]
    fn phase6_join_group_analyze_and_explain() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE customers (id BIGINT NOT NULL, name TEXT NOT NULL)")
            .unwrap();
        db.execute("CREATE TABLE orders (id BIGINT NOT NULL, customer_id BIGINT NOT NULL, amount BIGINT NOT NULL)")
            .unwrap();
        db.execute("INSERT INTO customers VALUES (1,'Ada'),(2,'Grace'),(3,'Linus')")
            .unwrap();
        db.execute("INSERT INTO orders VALUES (10,1,40),(11,1,60),(12,2,25)")
            .unwrap();
        db.execute("ANALYZE customers").unwrap();
        db.execute("ANALYZE orders").unwrap();

        let QueryResult::Rows { columns, rows } = db
            .execute("SELECT customers.name AS name, COUNT(*) AS n, SUM(orders.amount) AS total FROM customers LEFT JOIN orders ON customers.id=orders.customer_id GROUP BY customers.name ORDER BY name")
            .unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(columns, vec!["name", "n", "total"]);
        assert_eq!(rows.len(), 3);
        assert_eq!(rows[0].values[0], Value::Text("Ada".into()));
        assert_eq!(rows[0].values[1], Value::Int64(2));
        assert_eq!(rows[0].values[2], Value::Int64(100));
        assert_eq!(rows[2].values[0], Value::Text("Linus".into()));
        assert_eq!(rows[2].values[1], Value::Int64(1));
        assert_eq!(rows[2].values[2], Value::Null);

        let QueryResult::Rows { rows, .. } = db
            .execute("EXPLAIN ANALYZE SELECT customers.name AS name, COUNT(*) AS n FROM customers LEFT JOIN orders ON customers.id=orders.customer_id GROUP BY customers.name")
            .unwrap()
        else {
            panic!("explain rows")
        };
        assert!(rows.iter().any(|row| matches!(
            row.values.first(),
            Some(Value::Text(text)) if text.contains("Join")
        )));
        assert!(rows.iter().any(|row| matches!(
            row.values.first(),
            Some(Value::Text(text)) if text.contains("actual rows=")
        )));
        drop(db);

        let mut db = Database::open(&dir).unwrap();
        let QueryResult::Rows { rows, .. } = db
            .execute("EXPLAIN SELECT * FROM orders WHERE customer_id=1")
            .unwrap()
        else {
            panic!("explain rows")
        };
        assert!(!rows.is_empty());
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn spill_merge_matches_stable_sort_and_cleans_up_after_errors() {
        let dir = temp_dir();
        fs::create_dir(&dir).unwrap();
        let input: Vec<_> = (0..257)
            .map(|id| {
                Row::new(vec![
                    if id % 11 == 0 {
                        Value::Null
                    } else {
                        Value::Int64(id % 7)
                    },
                    Value::Text(format!("v{}", id % 5)),
                    Value::Int64(id),
                ])
            })
            .collect();
        for order in [
            vec![(0, true)],
            vec![(0, false), (1, true)],
            vec![(1, false), (0, true)],
        ] {
            let expected = sort_rows_in_memory(input.clone(), &order).unwrap();
            for budget in [1, 7, 31] {
                let actual = external_sort_rows(input.clone(), &order, budget, &dir).unwrap();
                assert_eq!(actual, expected);
                assert_eq!(fs::read_dir(&dir).unwrap().count(), 0);
            }
        }
        let invalid = vec![
            Row::new(vec![Value::Int64(1)]),
            Row::new(vec![Value::Text("x".into())]),
        ];
        assert!(external_sort_rows(invalid, &[(0, true)], 1, &dir).is_err());
        assert_eq!(fs::read_dir(&dir).unwrap().count(), 0);
        assert!(merge_spill_runs(&[], &[(0, true)]).unwrap().is_empty());
        fs::remove_dir(&dir).unwrap();
    }

    #[test]
    fn phase6_external_sort_path_handles_rows_above_memory_budget() {
        let dir = temp_dir();
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, payload TEXT NOT NULL)")
            .unwrap();
        db.execute("BEGIN").unwrap();
        for i in 0..1400 {
            db.execute(&format!("INSERT INTO t VALUES ({i},'v{i}')"))
                .unwrap();
        }
        db.execute("COMMIT").unwrap();
        let QueryResult::Rows { rows, .. } = db
            .execute("SELECT id AS id FROM t ORDER BY id DESC LIMIT 5")
            .unwrap()
        else {
            panic!("rows")
        };
        assert_eq!(rows.len(), 5);
        assert_eq!(rows[0].values[0], Value::Int64(1399));
        assert_eq!(rows[4].values[0], Value::Int64(1395));
        let spills = fs::read_dir(&dir)
            .unwrap()
            .filter_map(Result::ok)
            .filter(|entry| {
                entry
                    .file_name()
                    .to_string_lossy()
                    .starts_with(".phobos-spill-")
            })
            .count();
        assert_eq!(spills, 0);
        let _ = fs::remove_dir_all(dir);
    }
}
