//! Bounded inputs and incremental output for relational projection and joins.
use super::*;

struct RightInput {
    rows: Vec<Row>,
    directory: PathBuf,
    writer: Option<BufWriter<File>>,
    spilled: bool,
    count: u64,
}
impl Drop for RightInput {
    fn drop(&mut self) {
        // Windows must see the writer closed before its directory is removed.
        drop(self.writer.take());
        let _ = fs::remove_dir_all(&self.directory);
    }
}
impl RightInput {
    fn build(
        heap: &mut HeapTable,
        directory: PathBuf,
        memory_bytes: usize,
    ) -> Result<Self, PhobosError> {
        fs::create_dir(&directory)?;
        let mut input = Self {
            rows: Vec::new(),
            directory,
            writer: None,
            spilled: false,
            count: 0,
        };
        let mut bytes = 0usize;
        heap.scan_visit(|_, row| {
            let size = row_bytes(&row);
            if !input.spilled && bytes.saturating_add(size) > memory_bytes.max(1) {
                let mut writer = BufWriter::new(File::create(input.directory.join("right.bin"))?);
                for retained in input.rows.drain(..) {
                    write_spill_row(&mut writer, &retained)?;
                }
                input.writer = Some(writer);
                input.spilled = true;
            }
            if let Some(writer) = &mut input.writer {
                write_spill_row(writer, &row)?;
            } else {
                bytes += size;
                input.rows.push(row);
            }
            input.count += 1;
            Ok(true)
        })?;
        if let Some(mut writer) = input.writer.take() {
            writer.flush()?;
        }
        Ok(input)
    }
    fn visit(
        &self,
        mut visitor: impl FnMut(&Row) -> Result<bool, PhobosError>,
    ) -> Result<bool, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        if self.spilled {
            let mut reader = BufReader::new(File::open(self.directory.join("right.bin"))?);
            while let Some(row) = bounded_sort::read_row(&mut reader)? {
                cancellation_poll.checkpoint_at("streaming_relational.visit")?;
                if !visitor(&row)? {
                    return Ok(false);
                }
            }
        } else {
            for row in &self.rows {
                cancellation_poll.checkpoint_at("streaming_relational.visit")?;
                if !visitor(row)? {
                    return Ok(false);
                }
            }
        }
        Ok(true)
    }
}

impl Database {
    pub(super) fn count_joined_rows(
        &mut self,
        left: &TableSchema,
        join: &phobos_sql::JoinClause,
    ) -> Result<Option<u64>, PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let right = self.relation_schema(&join.table, join.alias.as_deref())?;
        let (left_ref, right_ref) = if column_belongs_to_table(&join.left_column, &right.name) {
            (&join.right_column, &join.left_column)
        } else {
            (&join.left_column, &join.right_column)
        };
        let left_index = qualified_table_column_index(left, left_ref)?;
        let right_index = qualified_table_column_index(&right, right_ref)?;
        check_join_columns_comparable(&left.columns[left_index], &right.columns[right_index])?;
        let budget = self.query_memory_bytes.max(1);
        let directory = self.data_dir.join(format!(
            ".phobos-spill-join-count-{}-{}",
            std::process::id(),
            unique_spill_suffix()
        ));
        let input = RightInput::build(self.heap_mut(right.id)?, directory, budget)?;
        let estimate = self
            .stats
            .get(&right.id)
            .map_or(input.count, |s| s.row_count);
        let estimated_bytes = estimate.saturating_mul(estimated_schema_row_bytes(&right) as u64);
        if input.spilled || estimated_bytes > budget as u64 {
            return Ok(None);
        }
        let mut buckets: HashMap<Vec<u8>, u64> = HashMap::new();
        for row in &input.rows {
            cancellation_poll.checkpoint_at("streaming_relational.count_joined_rows")?;
            if let Some(key) = join_key(&row.values[right_index]) {
                let count = buckets.entry(key).or_default();
                *count = count.checked_add(1).ok_or_else(|| {
                    PhobosError::new(ErrorCode::ResourceLimit, "join match count exceeds BIGINT")
                })?;
            }
        }
        let mut total = 0u64;
        let mut probe_key = Vec::new();
        // 0.2-B: only the join key column of the probe side is decoded, as a
        // borrowed value; no probe row is materialized.
        let mut required = vec![false; left.columns.len()];
        required[left_index] = true;
        self.heap_mut(left.id)?
            .scan_visit_projected(&required, |_, values| {
                let key = {
                    let _key = phobos_observability::span("join.key_build");
                    engine_v2::join_probe_key_ref(values[left_index], &mut probe_key)?
                };
                let matches = {
                    let _lookup = phobos_observability::span("join.hash_lookup");
                    key.and_then(|key| buckets.get(key).copied())
                };
                let matches = match (matches, join.kind) {
                    (Some(count), _) => count,
                    (None, JoinKind::Left) => 1,
                    (None, JoinKind::Inner) => 0,
                };
                total = total.checked_add(matches).ok_or_else(|| {
                    PhobosError::new(ErrorCode::ResourceLimit, "join match count exceeds BIGINT")
                })?;
                phobos_observability::event("join.cardinality_matches", matches);
                Ok(true)
            })?;
        Ok(Some(total))
    }

    pub(super) fn relational_into_sink(
        &mut self,
        query: RelationalSelect,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        if query.table.is_empty()
            || query.source.is_some()
            || query.distinct
            || query.joins.len() > 1
            || query.joins.iter().any(|j| j.predicate.is_some())
            || query
                .items
                .iter()
                .any(|item| matches!(item, SelectItem::Expression { .. }))
            || query.filter.as_ref().is_some_and(expr_has_subquery)
            || query.having.as_ref().is_some_and(expr_has_subquery)
            || query.limit.as_ref().is_some_and(expr_has_subquery)
            || query.offset.as_ref().is_some_and(expr_has_subquery)
        {
            return match self.relational_select(query, params)? {
                QueryResult::Rows { columns, rows } => {
                    sink.start(columns)?;
                    for row in rows {
                        sink.row(row)?;
                    }
                    sink.finish()
                }
                QueryResult::Command { .. } => unreachable!(),
            };
        }
        self.last_plan = Some(self.describe_relational_plan(&query)?);
        self.last_access_path = Some("RELATIONAL PLAN".into());
        let left = self.relation_schema(&query.table, query.alias.as_deref())?;
        let mut metadata = Relation {
            names: left.columns.iter().map(|c| c.name.clone()).collect(),
            qualified_names: left
                .columns
                .iter()
                .map(|c| format!("{}.{}", left.name, c.name))
                .collect(),
            rows: Vec::new(),
        };
        if let Some(join) = query.joins.first() {
            let right = self.relation_schema(&join.table, join.alias.as_deref())?;
            metadata
                .names
                .extend(right.columns.iter().map(|c| c.name.clone()));
            metadata.qualified_names.extend(
                right
                    .columns
                    .iter()
                    .map(|c| format!("{}.{}", right.name, c.name)),
            );
        }
        if !query.group_by.is_empty()
            || query
                .items
                .iter()
                .any(|item| matches!(item, SelectItem::Aggregate { .. }))
        {
            return self.aggregate_into_sink(query, params, sink, metadata, left);
        }
        let indexes = if query.items == [SelectItem::All] {
            None
        } else {
            Some(
                query
                    .items
                    .iter()
                    .map(|item| match item {
                        SelectItem::Column { name, .. } => metadata.column_index(name),
                        _ => Err(PhobosError::new(
                            ErrorCode::Semantic,
                            "aggregate or mixed star requires its own operator",
                        )),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )
        };
        let output = project_relation(metadata.clone(), &query.items, params)?;
        let order = bind_relation_order(&output, &query.order_by)?;
        let limit = eval_count(query.limit.as_ref(), params, "LIMIT")?;
        let offset = eval_count(query.offset.as_ref(), params, "OFFSET")?.unwrap_or(0);
        sink.start(output.names.clone())?;
        let mut skipped = 0;
        let mut emitted = 0;
        let mut emit = |row: Row| -> Result<bool, PhobosError> {
            if limit.is_some_and(|max| emitted >= max) {
                return Ok(false);
            }
            if skipped < offset {
                skipped += 1;
                return Ok(true);
            }
            sink.row(row)?;
            emitted += 1;
            Ok(limit.is_none_or(|max| emitted < max))
        };
        let top_k = limit.and_then(|limit| limit.checked_add(offset));
        let mut top = (!order.is_empty())
            .then(|| top_k.map(|k| bounded_sort::TopK::new(order.clone(), k)))
            .flatten();
        let mut sorter = if order.is_empty() || top_k.is_some() {
            None
        } else {
            Some(bounded_sort::Sorter::new(
                &self.data_dir,
                order,
                self.query_memory_bytes,
            )?)
        };
        let mut process = |row: Row| -> Result<bool, PhobosError> {
            if let Some(filter) = &query.filter {
                if !matches_filter_relation(
                    filter,
                    &metadata.names,
                    &metadata.qualified_names,
                    &row,
                    params,
                )? {
                    return Ok(true);
                }
            }
            let row = match &indexes {
                Some(indexes) => project_row(&row, indexes),
                None => row,
            };
            if let Some(having) = &query.having {
                if !matches_filter_relation(
                    having,
                    &output.names,
                    &output.qualified_names,
                    &row,
                    params,
                )? {
                    return Ok(true);
                }
            }
            if let Some(top) = &mut top {
                top.push(row)?;
                return Ok(true);
            }
            match &mut sorter {
                Some(sorter) => {
                    sorter.push(row)?;
                    Ok(true)
                }
                None => emit(row),
            }
        };
        self.visit_joined_rows(&left, query.joins.first(), &mut process)?;
        if let Some(top) = top {
            for row in top.finish()? {
                if !emit(row)? {
                    break;
                }
            }
        } else if let Some(sorter) = sorter {
            sorter.finish(emit)?;
        }
        sink.finish()
    }

    pub(super) fn visit_joined_rows(
        &mut self,
        left: &TableSchema,
        join: Option<&phobos_sql::JoinClause>,
        visitor: &mut dyn FnMut(Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        let Some(join) = join else {
            return self.heap_mut(left.id)?.scan_visit(|_, row| visitor(row));
        };
        let right = self.relation_schema(&join.table, join.alias.as_deref())?;
        let (left_ref, right_ref) = if column_belongs_to_table(&join.left_column, &right.name) {
            (&join.right_column, &join.left_column)
        } else {
            (&join.left_column, &join.right_column)
        };
        let left_index = qualified_table_column_index(left, left_ref)?;
        let right_index = qualified_table_column_index(&right, right_ref)?;
        check_join_columns_comparable(&left.columns[left_index], &right.columns[right_index])?;
        let budget = self.query_memory_bytes.max(1);
        let directory = self.data_dir.join(format!(
            ".phobos-spill-join-{}-{}",
            std::process::id(),
            unique_spill_suffix()
        ));
        let input = RightInput::build(self.heap_mut(right.id)?, directory, budget)?;
        let estimate = self
            .stats
            .get(&right.id)
            .map_or(input.count, |s| s.row_count);
        let estimated_bytes = estimate.saturating_mul(estimated_schema_row_bytes(&right) as u64);
        if !input.spilled && estimated_bytes <= budget as u64 {
            let mut buckets: HashMap<Vec<u8>, Vec<&Row>> = HashMap::new();
            for row in &input.rows {
                cancellation_poll.checkpoint_at("streaming_relational.visit_joined_rows")?;
                if let Some(key) = join_key(&row.values[right_index]) {
                    buckets.entry(key).or_default().push(row);
                }
            }
            let mut probe_key = Vec::new();
            self.heap_mut(left.id)?.scan_visit(|_, row| {
                let key = {
                    let _key = phobos_observability::span("join.key_build");
                    join_probe_key(&row.values[left_index], &mut probe_key)
                };
                let matches = {
                    let _lookup = phobos_observability::span("join.hash_lookup");
                    key.and_then(|key| buckets.get(key))
                };
                if let Some(matches) = matches {
                    for right_row in matches {
                        cancellation_poll
                            .checkpoint_at("streaming_relational.visit_joined_rows")?;
                        let joined = {
                            let _materialize = phobos_observability::span("join.row_materialize");
                            let mut values = row.values.clone();
                            values.extend(right_row.values.iter().cloned());
                            Row::new(values)
                        };
                        let more = {
                            let _handoff = phobos_observability::span("join.operator_handoff");
                            visitor(joined)?
                        };
                        if !more {
                            return Ok(false);
                        }
                    }
                } else if join.kind == JoinKind::Left {
                    let mut values = row.values;
                    values.extend((0..right.columns.len()).map(|_| Value::Null));
                    return visitor(Row::new(values));
                }
                Ok(true)
            })?;
        } else {
            let left_rows: Vec<Row> = self
                .heap_mut(left.id)?
                .scan()?
                .into_iter()
                .map(|(_, row)| row)
                .collect();
            let mut right_rows = Vec::new();
            input.visit(|row| {
                right_rows.push(row.clone());
                Ok(true)
            })?;
            for row in grace_hash_join_rows(
                &left_rows,
                &right_rows,
                left_index,
                right_index,
                join.kind,
                right.columns.len(),
                budget,
                &self.data_dir,
            )? {
                cancellation_poll.checkpoint_at("streaming_relational.grace_hash_join")?;
                if !visitor(row)? {
                    break;
                }
            }
        }
        Ok(())
    }
}

fn expr_has_subquery(expr: &Expr) -> bool {
    match expr {
        Expr::InSubquery { .. } | Expr::ScalarSubquery(_) | Expr::Exists(_) => true,
        Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => expr_has_subquery(expr),
        Expr::Binary { left, right, .. }
        | Expr::Like {
            expr: left,
            pattern: right,
        } => expr_has_subquery(left) || expr_has_subquery(right),
        Expr::Function { args, .. } => args.iter().any(expr_has_subquery),
        Expr::InList { expr, values } => {
            expr_has_subquery(expr) || values.iter().any(expr_has_subquery)
        }
        Expr::Case {
            branches,
            else_expr,
        } => {
            branches
                .iter()
                .any(|(a, b)| expr_has_subquery(a) || expr_has_subquery(b))
                || else_expr.as_deref().is_some_and(expr_has_subquery)
        }
        Expr::Literal(_) | Expr::Column(_) | Expr::QuotedColumn(_) | Expr::Parameter(_) => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[derive(Default)]
    struct Capture {
        columns: Vec<String>,
        rows: Vec<Row>,
        ended: bool,
        cancel: bool,
    }
    impl ResultSink for Capture {
        fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError> {
            self.columns = columns;
            Ok(())
        }
        fn row(&mut self, row: Row) -> Result<(), PhobosError> {
            self.rows.push(row);
            if self.cancel {
                Err(PhobosError::new(ErrorCode::Io, "join consumer cancelled"))
            } else {
                Ok(())
            }
        }
        fn finish(&mut self) -> Result<(), PhobosError> {
            self.ended = true;
            Ok(())
        }
        fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
            panic!("expected rows")
        }
    }
    #[test]
    fn streamed_hash_and_spilled_join_match_collecting_and_cleanup() {
        let dir =
            std::env::temp_dir().join(format!("phobos-stream-join-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE a (id BIGINT, v TEXT)").unwrap();
        db.execute("CREATE TABLE b (id BIGINT, n BIGINT)").unwrap();
        db.execute("INSERT INTO a VALUES (2,'two'),(1,'one'),(NULL,'nil'),(3,'three'),(9,'nine')")
            .unwrap();
        db.execute("INSERT INTO b VALUES (1,11),(2,22),(1,12),(NULL,0),(3,33),(8,88)")
            .unwrap();
        for budget in [2, 128] {
            db.query_memory_bytes = budget;
            for sql in [
                "SELECT a.id, a.v, b.n FROM a INNER JOIN b ON a.id=b.id",
                "SELECT a.id, a.v, b.n FROM a LEFT JOIN b ON a.id=b.id",
                "SELECT a.id, b.n FROM a LEFT JOIN b ON a.id=b.id ORDER BY a.id DESC LIMIT 4 OFFSET 1",
                "SELECT a.v AS text, b.n AS number FROM a INNER JOIN b ON b.id=a.id WHERE b.n>11 ORDER BY number",
                "SELECT * FROM a LEFT JOIN b ON a.id=b.id WHERE b.n IS NULL",
                "SELECT id AS number FROM a ORDER BY number DESC",
            ] {
                let expected = db.execute(sql).unwrap();
                let mut capture = Capture::default();
                db.execute_stream(sql, &[], &mut capture).unwrap();
                assert!(capture.ended);
                assert_eq!(
                    QueryResult::Rows {
                        columns: capture.columns,
                        rows: capture.rows
                    },
                    expected,
                    "{sql}; budget={budget}"
                );
                assert!(!fs::read_dir(&dir).unwrap().any(|entry| {
                    entry
                        .unwrap()
                        .file_name()
                        .to_string_lossy()
                        .starts_with(".phobos-spill-")
                }));
            }
            for ordered in [false, true] {
                let sql = format!(
                    "SELECT a.id, b.n FROM a INNER JOIN b ON a.id=b.id{}",
                    if ordered { " ORDER BY a.id" } else { "" }
                );
                db.execute("BEGIN").unwrap();
                // Set the budget on the active executor for either WAL format.
                if let Some(transaction) = db.active_txn.as_mut() {
                    transaction.database.query_memory_bytes = budget;
                } else {
                    assert!(db.private_txn.is_some());
                    db.query_memory_bytes = budget;
                }
                let mut capture = Capture {
                    cancel: true,
                    ..Capture::default()
                };
                assert!(db.execute_stream(&sql, &[], &mut capture).is_err());
                assert!(!capture.ended);
                assert_eq!(capture.rows.len(), 1);
                assert_eq!(
                    db.execute("COMMIT").unwrap_err().code,
                    ErrorCode::TransactionState
                );
                db.execute("ROLLBACK").unwrap();
            }
        }
        drop(db);
        let mut reopened = Database::open(&dir).unwrap();
        assert_eq!(
            reopened
                .execute("SELECT COUNT(*) AS n FROM a")
                .unwrap()
                .to_text(),
            "n\n5\n"
        );
        drop(reopened);
        fs::remove_dir_all(dir).unwrap();
    }
}
