use super::*;

fn temp(label: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "phobos-e-{label}-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ))
}

#[test]
fn e1_grace_join_spilled_group_and_top_k_match_in_memory() {
    let root = temp("operators");
    let mut db = Database::open(&root).unwrap();
    db.execute("CREATE TABLE a (id BIGINT, v BIGINT)").unwrap();
    db.execute("CREATE TABLE b (id BIGINT, v BIGINT)").unwrap();
    for i in 0..80 {
        db.execute(&format!("INSERT INTO a VALUES ({i},{})", i % 7))
            .unwrap();
        db.execute(&format!("INSERT INTO b VALUES ({i},{})", i % 5))
            .unwrap();
    }
    db.execute("ANALYZE a").unwrap();
    db.execute("ANALYZE b").unwrap();
    let queries = [
        "SELECT a.id,b.v FROM a JOIN b ON a.id=b.id ORDER BY a.id",
        "SELECT v,COUNT(*) AS n FROM a GROUP BY v ORDER BY v",
        "SELECT id FROM a ORDER BY v DESC,id LIMIT 10 OFFSET 3",
    ];
    db.query_memory_bytes = 1024 * 1024;
    let expected: Vec<_> = queries.iter().map(|sql| db.execute(sql).unwrap()).collect();
    db.query_memory_bytes = 512;
    for (sql, expected) in queries.iter().zip(expected) {
        assert_eq!(db.execute(sql).unwrap(), expected, "{sql}");
    }
    assert!(!fs::read_dir(&root).unwrap().any(|entry| {
        entry
            .unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with(".phobos-")
    }));
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn e3_stats_stale_selective_index_and_explain_share_choice() {
    let root = temp("planner");
    let mut db = Database::open(&root).unwrap();
    db.execute("CREATE TABLE t (a BIGINT, b BIGINT)").unwrap();
    db.execute("CREATE INDEX first_a ON t(a)").unwrap();
    db.execute("CREATE INDEX selective_b ON t(b)").unwrap();
    for i in 0..100 {
        db.execute(&format!("INSERT INTO t VALUES ({},{i})", i % 2))
            .unwrap();
    }
    db.execute("ANALYZE t").unwrap();
    db.execute("INSERT INTO t VALUES (1,1000)").unwrap();
    let plan = db
        .execute("EXPLAIN SELECT * FROM t WHERE a=1 AND b=42")
        .unwrap()
        .to_text();
    assert!(plan.contains("Index Scan using selective_b"), "{plan}");
    assert!(plan.contains("statistics=stale"), "{plan}");
    db.execute("SELECT * FROM t WHERE a=1 AND b=42").unwrap();
    assert_eq!(db.last_access_path(), Some("INDEX selective_b"));
    db.execute("ANALYZE t").unwrap();
    let fresh = db
        .execute("EXPLAIN SELECT * FROM t WHERE a=1 AND b=42")
        .unwrap()
        .to_text();
    assert!(fresh.contains("statistics=fresh"), "{fresh}");
    fs::remove_dir_all(root).unwrap();
}

#[test]
fn e_acceptance_smoke_reports_modest_operator_deltas() {
    let root = temp("smoke");
    fs::create_dir_all(&root).unwrap();
    let left: Vec<_> = (0..300).map(|i| Row::new(vec![Value::Int64(i)])).collect();
    let right = left.clone();
    let started = Instant::now();
    let old_join =
        bounded_nested_loop_join_rows(&left, &right, 0, 0, JoinKind::Inner, 1, 8).unwrap();
    let old_join_ms = started.elapsed().as_secs_f64() * 1000.0;
    let started = Instant::now();
    let new_join =
        grace_hash_join_rows(&left, &right, 0, 0, JoinKind::Inner, 1, 512, &root).unwrap();
    let new_join_ms = started.elapsed().as_secs_f64() * 1000.0;
    assert_eq!(old_join.len(), new_join.len());

    let rows: Vec<_> = (0..2000)
        .rev()
        .map(|i| Row::new(vec![Value::Int64(i)]))
        .collect();
    let started = Instant::now();
    let full = external_sort_rows(rows.clone(), &[(0, true)], usize::MAX, &root).unwrap();
    let full_ms = started.elapsed().as_secs_f64() * 1000.0;
    let started = Instant::now();
    let mut top = bounded_sort::TopK::new(vec![(0, true)], 10);
    for row in rows {
        top.push(row).unwrap();
    }
    let selected = top.finish().unwrap();
    let top_ms = started.elapsed().as_secs_f64() * 1000.0;
    assert_eq!(selected, full[..10]);
    eprintln!(
        "E_SMOKE join_rows=300 old_bounded_nested_loop_ms={old_join_ms:.3} new_grace_hash_ms={new_join_ms:.3} sort_rows=2000 old_full_sort_ms={full_ms:.3} new_top_k_10_ms={top_ms:.3}"
    );
    fs::remove_dir_all(root).unwrap();
}
