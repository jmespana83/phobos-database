//! Incremental stable external sort with two-reader merges and bounded run metadata.
use super::*;

const LEVELS: usize = 64;
// Query spill rows are bounded separately from the legacy collecting interface.
const MAX_ROW_BYTES: usize = 1024 * 1024;

struct Scratch(PathBuf);
impl Drop for Scratch {
    fn drop(&mut self) {
        // All file handles are local to completed producer/merge calls, never this guard.
        let _ = fs::remove_dir_all(&self.0);
    }
}

pub(super) struct Sorter {
    scratch: Scratch,
    order: Vec<(usize, bool)>,
    rows: Vec<Row>,
    bytes: usize,
    memory_bytes: usize,
    levels: [Option<PathBuf>; LEVELS],
    next_run: u64,
}

/// Bounded selection for ORDER BY ... LIMIT/OFFSET. The retained set is at
/// most `k`; ordinal tie-breaking preserves the stable ORDER BY contract.
pub(super) struct TopK {
    order: Vec<(usize, bool)>,
    k: usize,
    next: u64,
    rows: Vec<(u64, Row)>,
    /// 0.2-B: index of the current worst retained row once full. Retained
    /// rows only change on replacement, so the worst is recomputed then, not
    /// on every input row (P1-E rescanned all k rows per input).
    worst: Option<usize>,
}

impl TopK {
    pub(super) fn new(order: Vec<(usize, bool)>, k: usize) -> Self {
        Self {
            order,
            k,
            next: 0,
            rows: Vec::with_capacity(k.min(4096)),
            worst: None,
        }
    }

    fn find_worst(&self) -> Result<usize, PhobosError> {
        let mut worst = 0;
        for i in 1..self.rows.len() {
            let ordering = compare_rows(&self.rows[i].1, &self.rows[worst].1, &self.order)?
                .then_with(|| self.rows[i].0.cmp(&self.rows[worst].0));
            if ordering == Ordering::Greater {
                worst = i;
            }
        }
        Ok(worst)
    }

    pub(super) fn push(&mut self, row: Row) -> Result<(), PhobosError> {
        phobos_error::cancellation::checkpoint_at("top_k.push")?;
        if self.k == 0 {
            return Ok(());
        }
        let ordinal = self.next;
        self.next = self.next.saturating_add(1);
        if self.rows.len() < self.k {
            self.rows.push((ordinal, row));
            return Ok(());
        }
        let worst = match self.worst {
            Some(worst) => worst,
            None => self.find_worst()?,
        };
        let ordering = compare_rows(&row, &self.rows[worst].1, &self.order)?
            .then_with(|| ordinal.cmp(&self.rows[worst].0));
        if ordering == Ordering::Less {
            self.rows[worst] = (ordinal, row);
            self.worst = Some(self.find_worst()?);
        } else {
            self.worst = Some(worst);
        }
        Ok(())
    }

    /// 0.2-B: offer a borrowed candidate; `materialize` runs only if the row
    /// is retained. Ordinal and ordering semantics are identical to `push`
    /// (a later row never displaces an equal earlier one).
    pub(super) fn offer(
        &mut self,
        values: &[ValueRef<'_>],
        materialize: impl FnOnce() -> Result<Row, PhobosError>,
    ) -> Result<(), PhobosError> {
        phobos_error::cancellation::checkpoint_at("top_k.push")?;
        if self.k == 0 {
            return Ok(());
        }
        if self.rows.len() < self.k {
            return self.push(materialize()?);
        }
        let worst = match self.worst {
            Some(worst) => worst,
            None => self.find_worst()?,
        };
        self.worst = Some(worst);
        // The candidate's ordinal exceeds every retained ordinal, so a tie
        // with the worst row never displaces it.
        if compare_values_to_row(values, &self.rows[worst].1, &self.order)? == Ordering::Less {
            self.push(materialize()?)?;
        } else {
            self.next = self.next.saturating_add(1);
        }
        Ok(())
    }

    pub(super) fn finish(mut self) -> Result<Vec<Row>, PhobosError> {
        let mut error = None;
        self.rows.sort_by(|a, b| {
            compare_rows(&a.1, &b.1, &self.order)
                .map(|ordering| ordering.then_with(|| a.0.cmp(&b.0)))
                .unwrap_or_else(|failure| {
                    error = Some(failure);
                    Ordering::Equal
                })
        });
        if let Some(error) = error {
            return Err(error);
        }
        Ok(self.rows.into_iter().map(|(_, row)| row).collect())
    }
}

impl Sorter {
    pub(super) fn new(
        data_dir: &Path,
        order: Vec<(usize, bool)>,
        memory_bytes: usize,
    ) -> Result<Self, PhobosError> {
        let path = data_dir.join(format!(
            ".phobos-spill-stream-{}-{}",
            std::process::id(),
            unique_spill_suffix()
        ));
        fs::create_dir(&path)?;
        Ok(Self {
            scratch: Scratch(path),
            order,
            rows: Vec::new(),
            bytes: 0,
            memory_bytes: memory_bytes.max(1),
            levels: std::array::from_fn(|_| None),
            next_run: 0,
        })
    }

    pub(super) fn push(&mut self, row: Row) -> Result<(), PhobosError> {
        phobos_error::cancellation::checkpoint_at("bounded_sort.push")?;
        let encoded = encode_spill_row(&row)?;
        if encoded.len() > MAX_ROW_BYTES {
            return Err(PhobosError::new(
                ErrorCode::FrameTooLarge,
                "individual streaming sort row exceeds maximum",
            ));
        }
        let bytes = row_bytes(&row);
        if !self.rows.is_empty() && self.bytes.saturating_add(bytes) > self.memory_bytes {
            self.flush_run()?;
        }
        self.bytes += bytes;
        self.rows.push(row);
        Ok(())
    }

    fn path(&mut self) -> Result<PathBuf, PhobosError> {
        let number = self.next_run;
        self.next_run = self
            .next_run
            .checked_add(1)
            .ok_or_else(|| PhobosError::new(ErrorCode::Io, "spill run counter overflow"))?;
        Ok(self.scratch.0.join(format!("run-{number:016x}.bin")))
    }

    fn merge(&mut self, older: &Path, newer: &Path) -> Result<PathBuf, PhobosError> {
        let _profile = phobos_observability::span("stream_sort.merge");
        let path = self.path()?;
        {
            let mut output = BufWriter::new(File::create(&path)?);
            merge_visit(older, newer, &self.order, |row| {
                write_spill_row(&mut output, &row)?;
                Ok(true)
            })?;
            output.flush()?;
        }
        // Readers in merge_visit and the writer above are closed before replacement/deletion.
        fs::remove_file(older)?;
        fs::remove_file(newer)?;
        Ok(path)
    }

    fn flush_run(&mut self) -> Result<(), PhobosError> {
        let _profile = phobos_observability::span("stream_sort.flush_run");
        if self.rows.is_empty() {
            return Ok(());
        }
        let rows = sort_rows_in_memory(std::mem::take(&mut self.rows), &self.order)?;
        self.bytes = 0;
        let mut path = self.path()?;
        {
            let mut writer = BufWriter::new(File::create(&path)?);
            for row in rows {
                write_spill_row(&mut writer, &row)?;
            }
            writer.flush()?;
        }
        for level in 0..LEVELS {
            match self.levels[level].take() {
                None => {
                    self.levels[level] = Some(path);
                    return Ok(());
                }
                Some(older) => {
                    path = self.merge(&older, &path)?;
                }
            }
        }
        Err(PhobosError::new(
            ErrorCode::Io,
            "spill level counter overflow",
        ))
    }

    pub(super) fn finish(
        mut self,
        mut visit: impl FnMut(Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut cancellation_poll = phobos_error::cancellation::Poller::default();
        if self.levels.iter().all(Option::is_none) {
            for row in sort_rows_in_memory(std::mem::take(&mut self.rows), &self.order)? {
                cancellation_poll.checkpoint_at("bounded_sort.finish")?;
                if !visit(row)? {
                    break;
                }
            }
        } else {
            self.flush_run()?;
            // Higher levels are chronologically older. Equal keys retain input order.
            let mut final_run: Option<PathBuf> = None;
            for level in (0..LEVELS).rev() {
                cancellation_poll.checkpoint_at("bounded_sort.finish")?;
                if let Some(path) = self.levels[level].take() {
                    final_run = Some(match final_run {
                        None => path,
                        Some(older) => self.merge(&older, &path)?,
                    });
                }
            }
            if let Some(path) = final_run {
                let mut reader = BufReader::new(File::open(path)?);
                while let Some(row) = read_row(&mut reader)? {
                    cancellation_poll.checkpoint_at("bounded_sort.finish")?;
                    if !visit(row)? {
                        break;
                    }
                }
            }
        }
        fs::remove_dir_all(&self.scratch.0)?;
        Ok(())
    }
}

pub(super) fn read_row(reader: &mut impl Read) -> Result<Option<Row>, PhobosError> {
    phobos_error::cancellation::checkpoint_at("bounded_sort.read_row")?;
    let mut length = [0u8; 4];
    if reader.read(&mut length[..1])? == 0 {
        return Ok(None);
    }
    reader.read_exact(&mut length[1..])?;
    let length = u32::from_le_bytes(length) as usize;
    if !(4..=MAX_ROW_BYTES).contains(&length) {
        return Err(PhobosError::new(
            ErrorCode::Io,
            "invalid bounded spill row length",
        ));
    }
    let mut bytes = vec![0; length];
    reader.read_exact(&mut bytes)?;
    let count = u32::from_le_bytes(bytes[..4].try_into().expect("validated length")) as usize;
    if count > bytes.len() - 4 {
        return Err(PhobosError::new(
            ErrorCode::Io,
            "invalid bounded spill value count",
        ));
    }
    Ok(Some(decode_spill_row(&bytes)?))
}

fn merge_visit(
    older: &Path,
    newer: &Path,
    order: &[(usize, bool)],
    mut visit: impl FnMut(Row) -> Result<bool, PhobosError>,
) -> Result<(), PhobosError> {
    let mut readers = [
        BufReader::new(File::open(older)?),
        BufReader::new(File::open(newer)?),
    ];
    let mut heads = [read_row(&mut readers[0])?, read_row(&mut readers[1])?];
    loop {
        let best = choose_spill_head(
            &heads,
            heads[0].as_ref().map(|_| 0),
            heads[1].as_ref().map(|_| 1),
            order,
        )?;
        let Some(best) = best else {
            return Ok(());
        };
        if !visit(heads[best].take().expect("selected run head"))? {
            return Ok(());
        }
        heads[best] = read_row(&mut readers[best])?;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bounded_sort_stable_multilevel_merge_cancellation_and_byte_budget() {
        let dir =
            std::env::temp_dir().join(format!("phobos-sort-bounded-{}", unique_spill_suffix()));
        fs::create_dir(&dir).unwrap();
        let input: Vec<_> = (0..129)
            .map(|i| {
                Row::new(vec![
                    if i % 11 == 0 {
                        Value::Null
                    } else {
                        Value::Int64(i % 5)
                    },
                    Value::Int64(i),
                ])
            })
            .collect();
        let order = vec![(0, false)];
        let expected = sort_rows_in_memory(input.clone(), &order).unwrap();
        for budget in [1, 3, 256] {
            let mut sorter = Sorter::new(&dir, order.clone(), budget).unwrap();
            let scratch = sorter.scratch.0.clone();
            for row in &input {
                sorter.push(row.clone()).unwrap();
                assert!(sorter.rows.len() <= budget);
            }
            let mut actual = Vec::new();
            sorter
                .finish(|row| {
                    actual.push(row);
                    Ok(true)
                })
                .unwrap();
            assert_eq!(actual, expected);
            assert!(!scratch.exists());
        }
        for fail in [false, true] {
            let mut sorter = Sorter::new(&dir, order.clone(), 3).unwrap();
            let scratch = sorter.scratch.0.clone();
            for row in &input {
                sorter.push(row.clone()).unwrap();
            }
            let mut count = 0;
            let outcome = sorter.finish(|_| {
                count += 1;
                if fail {
                    Err(PhobosError::new(ErrorCode::Io, "cancelled merge"))
                } else {
                    Ok(false)
                }
            });
            assert_eq!(outcome.is_err(), fail);
            assert_eq!(count, 1);
            assert!(!scratch.exists());
        }
        let mut sorter = Sorter::new(&dir, vec![(0, true)], usize::MAX).unwrap();
        for i in (0..20).rev() {
            sorter
                .push(Row::new(vec![
                    Value::Int64(i),
                    Value::Text("x".repeat(700_000)),
                ]))
                .unwrap();
            assert!(sorter.bytes <= sorter.memory_bytes || sorter.rows.len() == 1);
        }
        let mut count = 0;
        sorter
            .finish(|row| {
                assert_eq!(row.values[0], Value::Int64(count));
                count += 1;
                Ok(true)
            })
            .unwrap();
        assert_eq!(count, 20);
        assert_eq!(fs::read_dir(&dir).unwrap().count(), 0);
        fs::remove_dir(dir).unwrap();
    }

    #[test]
    fn bounded_sort_abrupt_exit_reopens_and_cleans_scratch() {
        const ENV: &str = "PHOBOS_BOUNDED_SORT_CRASH_TEST_DIR";
        if let Some(dir) = std::env::var_os(ENV) {
            let dir = PathBuf::from(dir);
            let _db = Database::open(&dir).unwrap();
            let mut sorter = Sorter::new(&dir, vec![(0, true)], 2).unwrap();
            for i in (0..65).rev() {
                sorter.push(Row::new(vec![Value::Int64(i)])).unwrap();
            }
            let mut writer =
                BufWriter::new(File::create(sorter.scratch.0.join("unfinished.bin")).unwrap());
            writer.write_all(b"unfinished").unwrap();
            // No Rust drops run; Windows releases the open handles when the process exits.
            std::process::exit(73);
        }
        let dir = std::env::temp_dir().join(format!("phobos-sort-crash-{}", unique_spill_suffix()));
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE t (id BIGINT)").unwrap();
            db.execute("INSERT INTO t VALUES (1)").unwrap();
            db.execute("CREATE INDEX t_id ON t (id)").unwrap();
        }
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "bounded_sort::tests::bounded_sort_abrupt_exit_reopens_and_cleans_scratch",
                "--nocapture",
            ])
            .env(ENV, &dir)
            .status()
            .unwrap();
        assert_eq!(status.code(), Some(73));
        assert!(fs::read_dir(&dir).unwrap().any(|entry| {
            entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .starts_with(".phobos-spill-")
        }));
        for _ in 0..2 {
            let mut db = Database::open(&dir).unwrap();
            assert_eq!(
                db.execute("SELECT id FROM t WHERE id=1").unwrap().to_text(),
                "id\n1\n"
            );
            assert_eq!(db.last_access_path(), Some("INDEX t_id"));
            assert!(!fs::read_dir(&dir).unwrap().any(|entry| {
                entry
                    .unwrap()
                    .file_name()
                    .to_string_lossy()
                    .starts_with(".phobos-spill-")
            }));
        }
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn bounded_spill_rejects_partial_lengths_absurd_sizes_and_counts() {
        assert!(read_row(&mut &[][..]).unwrap().is_none());
        for n in 1..4 {
            assert!(read_row(&mut &[4, 0, 0][..n]).is_err());
        }
        for bytes in [
            vec![255; 4],
            vec![0; 4],
            vec![4, 0, 0, 0, 255, 255, 255, 255],
            vec![8, 0, 0, 0, 0],
        ] {
            assert!(read_row(&mut bytes.as_slice()).is_err());
        }
    }
}
