//! Incremental execution boundary. Complex operators retain the collecting
//! compatibility path until their separate bounded-operator checkpoint.
use super::*;

/// Synchronous delivery: the caller must retain execution ownership until return.
pub trait ResultSink {
    fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError>;
    fn row(&mut self, row: Row) -> Result<(), PhobosError>;
    fn finish(&mut self) -> Result<(), PhobosError>;
    fn command(&mut self, tag: String, rows_affected: u64) -> Result<(), PhobosError>;
}

impl Database {
    /// Streams simple SELECTs, using bounded external sorting when ordered from their chosen heap/index access path.
    /// Other statements currently use the collecting compatibility executor.
    pub fn execute_stream(
        &mut self,
        sql: &str,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        let statement = parse(sql)?;
        self.execute_stream_parsed(statement, sql, params, sink)
    }

    /// 0.2-B: one parse per statement. `sql` must be the text `statement`
    /// was parsed from; it is used only by the collecting fallback.
    pub fn execute_stream_parsed(
        &mut self,
        statement: Statement,
        sql: &str,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        let statement = self.expand_views(statement)?;
        let _clock = sql_surface::StatementClock::enter();
        phobos_error::cancellation::check_now()?;
        self.ensure_available()?;
        let private_failed = self.private_txn.as_ref().is_some_and(|tx| tx.failed);
        let statement = match statement {
            Statement::Select {
                table,
                columns,
                filter,
                order_by,
                limit,
                offset,
            } => {
                return self.stream_simple_select(
                    SelectRequest {
                        table,
                        selection: columns,
                        filter,
                        order_by,
                        limit,
                        offset,
                    },
                    private_failed,
                    params,
                    sink,
                );
            }
            other => other,
        };
        if let Statement::RelationalSelect(query) = statement {
            if private_failed {
                return Err(PhobosError::new(
                    ErrorCode::TransactionState,
                    "current transaction is aborted; ROLLBACK is required",
                ));
            }
            if self.private_txn.is_some() {
                let result = self.relational_into_sink(query, params, sink);
                if result
                    .as_ref()
                    .is_err_and(|error| !phobos_error::cancellation::is_interrupted(error))
                {
                    self.private_txn
                        .as_mut()
                        .expect("private transaction")
                        .failed = true;
                }
                return result;
            }
            return if let Some(transaction) = self.active_txn.as_mut() {
                if transaction.failed {
                    return Err(PhobosError::new(
                        ErrorCode::TransactionState,
                        "current transaction is aborted; ROLLBACK is required",
                    ));
                }
                let result = transaction
                    .database
                    .relational_into_sink(query, params, sink);
                if result
                    .as_ref()
                    .is_err_and(|error| !phobos_error::cancellation::is_interrupted(error))
                {
                    transaction.failed = true;
                }
                result
            } else {
                self.relational_into_sink(query, params, sink)
            };
        }
        match self.execute_params(sql, params)? {
            QueryResult::Command { tag, rows_affected } => sink.command(tag, rows_affected),
            QueryResult::Rows { columns, rows } => {
                sink.start(columns)?;
                for row in rows {
                    sink.row(row)?;
                }
                sink.finish()
            }
        }
    }

    fn stream_simple_select(
        &mut self,
        request: SelectRequest,
        private_failed: bool,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        if private_failed {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "current transaction is aborted; ROLLBACK is required",
            ));
        }
        if self.private_txn.is_some() {
            let result = self.select_into_sink(request, params, sink);
            if result
                .as_ref()
                .is_err_and(|error| !phobos_error::cancellation::is_interrupted(error))
            {
                self.private_txn
                    .as_mut()
                    .expect("private transaction")
                    .failed = true;
            }
            return result;
        }
        if let Some(transaction) = self.active_txn.as_mut() {
            if transaction.failed {
                return Err(PhobosError::new(
                    ErrorCode::TransactionState,
                    "current transaction is aborted; ROLLBACK is required",
                ));
            }
            let result = transaction.database.select_into_sink(request, params, sink);
            if result
                .as_ref()
                .is_err_and(|error| !phobos_error::cancellation::is_interrupted(error))
            {
                transaction.failed = true;
            }
            result
        } else {
            self.select_into_sink(request, params, sink)
        }
    }

    fn select_into_sink(
        &mut self,
        request: SelectRequest,
        params: &[Value],
        sink: &mut dyn ResultSink,
    ) -> Result<(), PhobosError> {
        let schema = self.table_schema(&request.table)?;
        let (columns, projection_indexes) = projection(&schema, request.selection)?;
        let order = bind_order(&schema, &request.order_by)?;
        let limit = eval_count(request.limit.as_ref(), params, "LIMIT")?;
        let offset = eval_count(request.offset.as_ref(), params, "OFFSET")?.unwrap_or(0);
        sink.start(columns)?;
        let mut skipped = 0usize;
        let mut emitted = 0usize;
        // `emit` receives rows already projected to the output columns.
        let mut emit = |row: Row| -> Result<bool, PhobosError> {
            if limit.is_some_and(|max| emitted >= max) {
                return Ok(false);
            }
            if skipped < offset {
                skipped += 1;
                return Ok(true);
            }
            sink.row(row)?;
            emitted += 1;
            Ok(limit.is_none_or(|max| emitted < max))
        };
        // 0.2-B: when the filter binds to borrowed values, heap and index
        // access decode only the filter/projection/ORDER BY columns and an
        // output row is built only for a row that is actually delivered.
        let bound = engine_v2::RowFilter::bind(
            request.filter.as_ref(),
            &engine_v2::Scope::Table(&schema),
            params,
        );
        if let Some(bound) = bound {
            let mut required = vec![false; schema.columns.len()];
            bound.require(&mut required);
            for index in &projection_indexes {
                required[*index] = true;
            }
            for (index, _) in &order {
                required[*index] = true;
            }
            phobos_observability::event("engine_v2.projected_select", 1);
            let project = |values: &[ValueRef<'_>]| -> Result<Row, PhobosError> {
                Ok(Row::new(
                    projection_indexes
                        .iter()
                        .map(|index| values[*index].to_value().ok_or_else(unprojected))
                        .collect::<Result<Vec<_>, _>>()?,
                ))
            };
            if order.is_empty() {
                self.visit_selected_values(
                    &schema,
                    request.filter.as_ref(),
                    &bound,
                    &required,
                    params,
                    &mut |values| emit(project(values)?),
                )?;
            } else if let Some(k) = limit.and_then(|limit| limit.checked_add(offset)) {
                let mut top = bounded_sort::TopK::new(order, k);
                self.visit_selected_values(
                    &schema,
                    request.filter.as_ref(),
                    &bound,
                    &required,
                    params,
                    &mut |values| {
                        top.offer(values, || engine_v2::materialize(values, &required))?;
                        Ok(true)
                    },
                )?;
                for row in top.finish()? {
                    if !emit(project_row(&row, &projection_indexes))? {
                        break;
                    }
                }
            } else {
                let mut sorter =
                    bounded_sort::Sorter::new(&self.data_dir, order, self.query_memory_bytes)?;
                self.visit_selected_values(
                    &schema,
                    request.filter.as_ref(),
                    &bound,
                    &required,
                    params,
                    &mut |values| {
                        sorter.push(engine_v2::materialize(values, &required)?)?;
                        Ok(true)
                    },
                )?;
                sorter.finish(|row| emit(project_row(&row, &projection_indexes)))?;
            }
            return sink.finish();
        }
        let mut emit = |row: Row| emit(project_row(&row, &projection_indexes));
        if order.is_empty() {
            self.visit_selected_rows(&schema, request.filter.as_ref(), params, &mut emit)?;
        } else if let Some(k) = limit.and_then(|limit| limit.checked_add(offset)) {
            let mut top = bounded_sort::TopK::new(order, k);
            self.visit_selected_rows(&schema, request.filter.as_ref(), params, &mut |row| {
                top.push(row)?;
                Ok(true)
            })?;
            for row in top.finish()? {
                if !emit(row)? {
                    break;
                }
            }
        } else {
            let mut sorter =
                bounded_sort::Sorter::new(&self.data_dir, order, self.query_memory_bytes)?;
            self.visit_selected_rows(&schema, request.filter.as_ref(), params, &mut |row| {
                sorter.push(row)?;
                Ok(true)
            })?;
            sorter.finish(emit)?;
        }
        sink.finish()
    }

    /// 0.2-B projected counterpart of `visit_selected_rows`: same access-path
    /// choice, same own-write handling, borrowed values instead of rows.
    pub(super) fn visit_selected_values(
        &mut self,
        schema: &TableSchema,
        filter: Option<&Expr>,
        bound: &engine_v2::RowFilter,
        required: &[bool],
        params: &[Value],
        visitor: &mut dyn FnMut(&[ValueRef<'_>]) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let planned = self.plan_index_search(schema, filter, params)?;
        let mut visit = |values: &[ValueRef<'_>]| -> Result<bool, PhobosError> {
            if bound.passes(values)? {
                visitor(values)
            } else {
                Ok(true)
            }
        };
        let Some(search) = planned else {
            self.last_access_path = Some("TABLE SCAN".into());
            return self
                .heap_mut(schema.id)?
                .scan_visit_projected(required, |_, values| visit(values));
        };
        self.last_access_path = Some(format!("INDEX {}", search.index_name));
        // 0.2-K Part H: the index key columns are decoded too, so every
        // fetched row is checked against the key of the entry that named it.
        let key_columns = index_key_columns(&self.catalog, schema, search.index_id)?;
        let mut keyed_required = required.to_vec();
        for column in &key_columns {
            keyed_required[*column] = true;
        }
        let widened = keyed_required.as_slice() != required;
        let tree = self.indexes.get_mut(&search.index_id).ok_or_else(|| {
            PhobosError::new(ErrorCode::InvalidCatalog, "catalog index file is missing")
        })?;
        let heap = self.heaps.get_mut(&schema.id).ok_or_else(|| {
            PhobosError::new(ErrorCode::InvalidCatalog, "catalog heap is missing")
        })?;
        let mut stopped = false;
        for range in &search.ranges {
            let mut consume = |key: &IndexKey, rid: RecordId| {
                phobos_observability::event("index.range_rids_produced", 1);
                let mut more = true;
                let _fetch = phobos_observability::span("index.range_heap_fetch");
                heap.get_projected(rid, &keyed_required, &mut |values| {
                    if !values_match_key(values, &key_columns, key) {
                        stale_rid_skipped();
                        return Ok(());
                    }
                    more = if widened {
                        let masked = values
                            .iter()
                            .zip(required)
                            .map(|(value, wanted)| if *wanted { *value } else { ValueRef::Absent })
                            .collect::<Vec<_>>();
                        visit(&masked)?
                    } else {
                        visit(values)?
                    };
                    Ok(())
                })?;
                stopped = !more;
                Ok(more)
            };
            if let Some(prefix) = &range.prefix {
                tree.prefix_visit_keyed(prefix, &mut consume)?;
            } else {
                tree.range_visit_keyed(range.lower_bound(), range.upper_bound(), &mut consume)?;
            }
            if stopped {
                break;
            }
        }
        if !stopped {
            heap.visit_overlay(|_, row| visit(&phobos_storage::project_owned_row(&row, required)))?;
        }
        Ok(())
    }

    fn visit_selected_rows(
        &mut self,
        schema: &TableSchema,
        filter: Option<&Expr>,
        params: &[Value],
        visitor: &mut dyn FnMut(Row) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let planned = self.plan_index_search(schema, filter, params)?;
        let mut visit = |row: Row| -> Result<bool, PhobosError> {
            let passes = {
                let _predicate = phobos_observability::span("scan.predicate");
                matches_filter(filter, schema, &row, params)?
            };
            if passes {
                let _handoff = phobos_observability::span("scan.operator_handoff");
                visitor(row)
            } else {
                Ok(true)
            }
        };
        if let Some(search) = planned {
            self.last_access_path = Some(format!("INDEX {}", search.index_name));
            let key_columns = index_key_columns(&self.catalog, schema, search.index_id)?;
            let tree = self.indexes.get_mut(&search.index_id).ok_or_else(|| {
                PhobosError::new(ErrorCode::InvalidCatalog, "catalog index file is missing")
            })?;
            let heap = self.heaps.get_mut(&schema.id).ok_or_else(|| {
                PhobosError::new(ErrorCode::InvalidCatalog, "catalog heap is missing")
            })?;
            let mut stopped = false;
            let mut heap_fetches = 0u64;
            let mut heap_pages = HashSet::new();
            for range in &search.ranges {
                let mut consume = |key: &IndexKey, rid: RecordId| {
                    phobos_observability::event("index.range_rids_produced", 1);
                    heap_fetches = heap_fetches.saturating_add(1);
                    heap_pages.insert(rid.page_id);
                    let row = {
                        let _fetch = phobos_observability::span("index.range_heap_fetch");
                        heap.get(rid)?
                    };
                    // 0.2-K Part H: identity re-validation (stale RID -> skip).
                    let row = match row {
                        Some(row) if !row_matches_key(&row, &key_columns, key) => {
                            stale_rid_skipped();
                            None
                        }
                        row => row,
                    };
                    match row {
                        Some(row) => {
                            phobos_observability::event("index.range_heap_rows", 1);
                            let more = {
                                let _handoff =
                                    phobos_observability::span("index.range_output_handoff");
                                visit(row)?
                            };
                            stopped = !more;
                            Ok(more)
                        }
                        None => Ok(true),
                    }
                };
                if let Some(prefix) = &range.prefix {
                    tree.prefix_visit_keyed(prefix, &mut consume)?;
                } else {
                    tree.range_visit_keyed(range.lower_bound(), range.upper_bound(), &mut consume)?;
                }
                if stopped {
                    break;
                }
            }
            phobos_observability::event("index.range_heap_fetches", heap_fetches);
            phobos_observability::event("index.range_distinct_heap_pages", heap_pages.len() as u64);
            phobos_observability::event(
                "index.range_repeated_heap_pages",
                heap_fetches.saturating_sub(heap_pages.len() as u64),
            );
            if !stopped {
                heap.visit_overlay(|_, row| visit(row))?;
            }
            Ok(())
        } else {
            self.last_access_path = Some("TABLE SCAN".into());
            self.heap_mut(schema.id)?.scan_visit(|_, row| visit(row))
        }
    }
}

struct BatchSink<F> {
    columns: Vec<String>,
    rows: Vec<Row>,
    batch_rows: usize,
    consume: F,
}

impl<F: FnMut(&[Row]) -> Result<(), PhobosError>> ResultSink for BatchSink<F> {
    fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError> {
        self.columns = columns;
        Ok(())
    }
    fn row(&mut self, row: Row) -> Result<(), PhobosError> {
        self.rows.push(row);
        if self.rows.len() == self.batch_rows {
            (self.consume)(&self.rows)?;
            self.rows.clear();
        }
        Ok(())
    }
    fn finish(&mut self) -> Result<(), PhobosError> {
        if !self.rows.is_empty() {
            (self.consume)(&self.rows)?;
            self.rows.clear();
        }
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
        Err(PhobosError::new(
            ErrorCode::Semantic,
            "stream_select accepts SELECT only",
        ))
    }
}

impl Database {
    /// Compatibility batch callback for a simple SELECT without ORDER BY.
    /// Uses the same transaction checks and index selection as execute_stream.
    pub fn stream_select<F>(
        &mut self,
        sql: &str,
        params: &[Value],
        batch_rows: usize,
        on_batch: F,
    ) -> Result<Vec<String>, PhobosError>
    where
        F: FnMut(&[Row]) -> Result<(), PhobosError>,
    {
        if batch_rows == 0 {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "batch_rows must be non-zero",
            ));
        }
        let Statement::Select { order_by, .. } = parse(sql)? else {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "stream_select accepts SELECT only",
            ));
        };
        if !order_by.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "stream_select does not accept ORDER BY",
            ));
        }
        let mut sink = BatchSink {
            columns: Vec::new(),
            rows: Vec::new(),
            batch_rows,
            consume: on_batch,
        };
        self.execute_stream(sql, params, &mut sink)?;
        Ok(sink.columns)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Default)]
    struct Capture {
        columns: Vec<String>,
        rows: Vec<Row>,
        ended: bool,
        cancel: bool,
    }
    impl ResultSink for Capture {
        fn start(&mut self, columns: Vec<String>) -> Result<(), PhobosError> {
            self.columns = columns;
            Ok(())
        }
        fn row(&mut self, row: Row) -> Result<(), PhobosError> {
            assert!(!self.columns.is_empty());
            self.rows.push(row);
            if self.cancel {
                Err(PhobosError::new(ErrorCode::Io, "test cancellation"))
            } else {
                Ok(())
            }
        }
        fn finish(&mut self) -> Result<(), PhobosError> {
            self.ended = true;
            Ok(())
        }
        fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
            panic!("expected rows")
        }
    }

    #[test]
    fn streaming_preserves_index_projection_limits_and_failed_transaction() {
        let dir =
            std::env::temp_dir().join(format!("phobos-stream-sink-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT, v TEXT)").unwrap();
        db.execute("INSERT INTO t VALUES (3,'three'),(1,'one'),(2,'two'),(4,NULL)")
            .unwrap();
        for indexed in [false, true] {
            if indexed {
                db.execute("CREATE INDEX t_id ON t (id)").unwrap();
            }
            for sql in [
                "SELECT v, id FROM t WHERE id>=2 LIMIT 2 OFFSET 1",
                "SELECT id FROM t WHERE id=2",
                "SELECT id FROM t LIMIT 0",
                "SELECT id FROM t WHERE id>10",
                "SELECT v FROM t WHERE id>=1 ORDER BY id DESC LIMIT 2 OFFSET 1",
            ] {
                let expected = db.execute(sql).unwrap();
                let mut capture = Capture::default();
                db.execute_stream(sql, &[], &mut capture).unwrap();
                assert!(capture.ended);
                assert_eq!(
                    QueryResult::Rows {
                        columns: capture.columns,
                        rows: capture.rows
                    },
                    expected
                );
                if indexed && sql.contains("WHERE") {
                    assert_eq!(db.last_access_path(), Some("INDEX t_id"));
                }
            }
        }
        db.execute("BEGIN").unwrap();
        let mut capture = Capture {
            cancel: true,
            ..Capture::default()
        };
        assert_eq!(
            db.execute_stream("SELECT * FROM t", &[], &mut capture)
                .unwrap_err()
                .code,
            ErrorCode::Io
        );
        assert_eq!(capture.rows.len(), 1);
        assert!(!capture.ended);
        assert_eq!(
            db.execute("COMMIT").unwrap_err().code,
            ErrorCode::TransactionState
        );
        assert_eq!(
            db.stream_select("SELECT * FROM t", &[], 1, |_| Ok(()))
                .unwrap_err()
                .code,
            ErrorCode::TransactionState
        );
        db.execute("ROLLBACK").unwrap();
        let mut count = 0;
        db.stream_select("SELECT id FROM t WHERE id>=2", &[], 1, |rows| {
            count += rows.len();
            Ok(())
        })
        .unwrap();
        assert_eq!(count, 3);
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }
}
