//! Conservative index candidate selection for mutations. Freeze physical record
//! identities before changing any index key, and preserve heap mutation order.
use super::*;

impl Database {
    /// C5 resolves at most a configured byte budget before publishing any
    /// session changes. Historical invisible index entries are never collected.
    pub(super) fn mvcc_dml_snapshot(
        &mut self,
        schema: &TableSchema,
        filter: Option<&Expr>,
        params: &[Value],
        budget: usize,
    ) -> Result<Vec<(RecordId, Row)>, PhobosError> {
        let search = if filter.is_some_and(|expr| safe_filter(expr, schema, params)) {
            self.plan_index_search(schema, filter, params)?
        } else {
            None
        };
        let mut rows = Vec::new();
        let mut bytes = 0usize;
        let mut collect = |rid, row: Row| {
            if matches_filter(filter, schema, &row, params)? {
                bytes = bytes
                    .checked_add(128 + phobos_storage::RowCodec::encode(schema, &row)?.len())
                    .ok_or_else(|| {
                        PhobosError::new(ErrorCode::ResourceLimit, "candidate accounting overflow")
                    })?;
                if bytes > budget {
                    return Err(PhobosError::new(
                        ErrorCode::ResourceLimit,
                        "MVCC candidate memory limit exceeded",
                    ));
                }
                rows.push((rid, row));
            }
            Ok(true)
        };
        if let Some(search) = search {
            self.last_access_path = Some(format!("INDEX {}", search.index_name));
            let key_columns = index_key_columns(&self.catalog, schema, search.index_id)?;
            let heap = self
                .heaps
                .get_mut(&schema.id)
                .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "heap missing"))?;
            let tree = self
                .indexes
                .get_mut(&search.index_id)
                .expect("planned index");
            for range in &search.ranges {
                tree.range_visit_keyed(range.lower_bound(), range.upper_bound(), |key, rid| {
                    if let Some(row) = heap.get(rid)? {
                        if !row_matches_key(&row, &key_columns, key) {
                            // 0.2-K Part H: the slot was reclaimed and reused
                            // after this entry was copied: a stale reference,
                            // never the old row.
                            stale_rid_skipped();
                            return Ok(true);
                        }
                        collect(rid, row)
                    } else if heap.get_version(rid)?.is_some() || heap.slot_reclaimed(rid)? {
                        // An invisible version, or a RETIRED / FREE / trimmed
                        // slot that held a globally dead version: an entry
                        // copied before that publication is simply skipped.
                        Ok(true)
                    } else {
                        Err(PhobosError::new(
                            ErrorCode::InvalidCatalog,
                            "index references missing tuple",
                        ))
                    }
                })?;
            }
            heap.visit_overlay(&mut collect)?;
        } else {
            self.last_access_path = Some("TABLE SCAN".into());
            self.heap_mut(schema.id)?.scan_visit(&mut collect)?;
        }
        rows.sort_unstable_by_key(|(rid, _)| *rid);
        if rows.windows(2).any(|pair| pair[0].0 == pair[1].0) {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "duplicate tuple reference",
            ));
        }
        phobos_observability::event("mvcc.candidate_bytes", bytes as u64);
        Ok(rows)
    }
    pub(super) fn dml_snapshot(
        &mut self,
        schema: &TableSchema,
        filter: Option<&Expr>,
        params: &[Value],
    ) -> Result<Vec<(RecordId, Row)>, PhobosError> {
        let search = if filter.is_some_and(|expr| safe_filter(expr, schema, params)) {
            self.plan_index_search(schema, filter, params)?
        } else {
            None
        };
        let rows = if let Some(search) = search {
            let _profile = phobos_observability::span("execution.dml_index_candidates");
            self.last_access_path = Some(format!("INDEX {}", search.index_name));
            let mut ids = self.run_index_search(&search)?;
            // Existing uniqueness checks run in physical heap order. Index order
            // could change which intermediate key conflicts are rejected.
            ids.sort_unstable();
            if ids.windows(2).any(|pair| pair[0] == pair[1]) {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "index contains duplicate references to a heap record",
                ));
            }
            let heap = self.heap_mut(schema.id)?;
            let mut rows = Vec::with_capacity(ids.len());
            for rid in ids {
                let Some(row) = heap.get(rid)? else {
                    if heap.has_visibility_context() && heap.get_version(rid)?.is_some() {
                        continue;
                    }
                    return Err(PhobosError::new(
                        ErrorCode::InvalidCatalog,
                        "index references a missing heap record",
                    ));
                };
                rows.push((rid, row));
            }
            rows
        } else {
            self.last_access_path = Some("TABLE SCAN".into());
            phobos_observability::measure("execution.dml_scan", || {
                self.heap_mut(schema.id)?.scan()
            })?
        };
        phobos_observability::event("execution.dml_candidates", rows.len() as u64);
        Ok(rows)
    }
}

// The existing evaluator evaluates both AND operands eagerly. Restrict pruning
// to total, same-type comparisons so it cannot hide errors on excluded rows.
// Mixed numeric coercion, floating-point ordering, NULL constants, arithmetic,
// missing parameters and other expressions retain their existing scan behavior.
fn safe_filter(expr: &Expr, schema: &TableSchema, params: &[Value]) -> bool {
    let Expr::Binary { left, op, right } = expr else {
        return false;
    };
    if *op == BinaryOp::And {
        return safe_filter(left, schema, params) && safe_filter(right, schema, params);
    }
    if !matches!(
        op,
        BinaryOp::Eq
            | BinaryOp::NotEq
            | BinaryOp::Lt
            | BinaryOp::LtEq
            | BinaryOp::Gt
            | BinaryOp::GtEq
    ) {
        return false;
    }
    let (name, value) = match (left.as_ref(), right.as_ref()) {
        (Expr::Column(name), value) | (value, Expr::Column(name)) => (name, value),
        _ => return false,
    };
    let Some(position) = schema.column_index(name) else {
        return false;
    };
    let value = match value {
        Expr::Literal(value) => Some(value),
        Expr::Parameter(index) => params.get(*index),
        _ => None,
    };
    matches!(
        (&schema.columns[position].data_type, value),
        (DataType::Int64, Some(Value::Int64(_)))
            | (DataType::Text, Some(Value::Text(_)))
            | (DataType::Boolean, Some(Value::Boolean(_)))
            | (DataType::Binary, Some(Value::Binary(_)))
            | (DataType::Date, Some(Value::Date(_)))
            | (DataType::Timestamp, Some(Value::Timestamp(_)))
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rows(db: &mut Database) -> QueryResult {
        db.execute("SELECT * FROM t ORDER BY id, v").unwrap()
    }

    #[test]
    fn indexed_dml_matches_scan_and_freezes_candidates_before_key_changes() {
        let root = std::env::temp_dir().join(format!("phobos-dml-{}", unique_spill_suffix()));
        let mut indexed = Database::open(root.join("indexed")).unwrap();
        let mut scanned = Database::open(root.join("scanned")).unwrap();
        for db in [&mut indexed, &mut scanned] {
            db.execute("CREATE TABLE t (id BIGINT, v BIGINT)").unwrap();
            db.execute("INSERT INTO t VALUES (4,40),(1,10),(3,30),(2,20),(2,21),(NULL,9)")
                .unwrap();
        }
        indexed.execute("CREATE INDEX ix ON t (id)").unwrap();
        let schema = indexed.table_schema("t").unwrap();
        let Statement::Update { filter, .. } =
            parse("UPDATE t SET v=99 WHERE id=$1 AND v=20").unwrap()
        else {
            panic!("update");
        };
        let candidates = indexed
            .dml_snapshot(&schema, filter.as_ref(), &[Value::Int64(2)])
            .unwrap();
        assert_eq!(candidates.len(), 2); // residual is deliberately checked by UPDATE
        assert_eq!(indexed.last_access_path(), Some("INDEX ix"));
        assert!(candidates.windows(2).all(|pair| pair[0].0 < pair[1].0));
        for sql in [
            "UPDATE t SET id=id+1 WHERE id>=1 AND id<4",
            "UPDATE t SET v=99 WHERE id=3 AND v=20",
            "DELETE FROM t WHERE id>=3 AND id<4 AND v=21",
            "UPDATE t SET v=7 WHERE id IS NULL OR id=4",
            "DELETE FROM t WHERE id=NULL",
        ] {
            assert_eq!(indexed.execute(sql).unwrap(), scanned.execute(sql).unwrap());
            assert_eq!(rows(&mut indexed), rows(&mut scanned));
        }
        indexed
            .execute("CREATE INDEX composite ON t (id,v)")
            .unwrap();
        indexed.execute("DROP INDEX ix").unwrap();
        let Statement::Update { filter, .. } =
            parse("UPDATE t SET v=88 WHERE id=4 AND v=7").unwrap()
        else {
            panic!("update");
        };
        let candidates = indexed.dml_snapshot(&schema, filter.as_ref(), &[]).unwrap();
        assert_eq!(candidates.len(), 2);
        assert_eq!(indexed.last_access_path(), Some("INDEX composite"));
        for db in [&mut indexed, &mut scanned] {
            db.execute("BEGIN").unwrap();
            db.execute("UPDATE t SET v=88 WHERE id=4 AND v=7").unwrap();
            db.execute("DELETE FROM t WHERE id=2").unwrap();
            db.execute("ROLLBACK").unwrap();
        }
        assert_eq!(rows(&mut indexed), rows(&mut scanned));
        drop(indexed);
        drop(scanned);
        let mut indexed = Database::open(root.join("indexed")).unwrap();
        let mut scanned = Database::open(root.join("scanned")).unwrap();
        assert_eq!(rows(&mut indexed), rows(&mut scanned));
        for tree in indexed.indexes.values_mut() {
            tree.validate().unwrap();
        }
        drop(indexed);
        drop(scanned);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn indexed_dml_preserves_eager_errors_uniqueness_order_and_abort_state() {
        let root =
            std::env::temp_dir().join(format!("phobos-dml-errors-{}", unique_spill_suffix()));
        let mut db = Database::open(&root).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
            .unwrap();
        db.execute("INSERT INTO t VALUES (2,20),(1,10)").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        let original = rows(&mut db);
        // Index-key order would update 1 first, incorrectly avoiding the original
        // physical-order uniqueness conflict on 2 -> 1.
        assert!(db.execute("UPDATE t SET id=id-1 WHERE id>=1").is_err());
        assert_eq!(rows(&mut db), original);
        for sql in [
            "UPDATE t SET v=0 WHERE id=999 AND 1/0=1",
            "DELETE FROM t WHERE id=999 AND missing=1",
            "DELETE FROM t WHERE id=999 AND v=$1",
            "DELETE FROM t WHERE id=999 AND v='wrong type'",
        ] {
            db.execute("BEGIN").unwrap();
            assert!(db.execute(sql).is_err(), "{sql}");
            assert!(db.execute("DELETE FROM t WHERE id=1").is_err());
            assert!(db.execute("COMMIT").is_err());
            db.execute("ROLLBACK").unwrap();
            assert_eq!(rows(&mut db), original);
        }
        drop(db);
        let mut db = Database::open(&root).unwrap();
        assert_eq!(rows(&mut db), original);
        for tree in db.indexes.values_mut() {
            tree.validate().unwrap();
        }
        drop(db);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn indexed_key_update_crash_recovery_is_atomic_and_repeatable() {
        if let Ok(path) = std::env::var("PHOBOS_DML_CRASH_DIR") {
            let mut db = Database::open(path).unwrap();
            if std::env::var("PHOBOS_DML_CRASH_MODE").as_deref() == Ok("uncommitted") {
                db.execute("BEGIN").unwrap();
                db.execute("UPDATE t SET id=id+10 WHERE id>=1 AND id<=2")
                    .unwrap();
                std::process::exit(73);
            }
            db.execute("UPDATE t SET id=id+10 WHERE id>=1 AND id<=2")
                .unwrap();
            std::process::exit(74); // Parent rejects a missing hook even if commit succeeded.
        }
        for mode in ["uncommitted", "committed"] {
            let root =
                std::env::temp_dir().join(format!("phobos-dml-crash-{}", unique_spill_suffix()));
            {
                let mut db = Database::open(&root).unwrap();
                db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
                    .unwrap();
                db.execute("INSERT INTO t VALUES (2,20),(1,10)").unwrap();
                db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
            }
            let mut child = std::process::Command::new(std::env::current_exe().unwrap());
            child.arg("--exact").arg("indexed_dml::tests::indexed_key_update_crash_recovery_is_atomic_and_repeatable")
                .env("PHOBOS_DML_CRASH_DIR", &root)
                .env("PHOBOS_DML_CRASH_MODE", mode)
                .env_remove("PHOBOS_CRASH_POINT");
            if mode == "committed" {
                child.env("PHOBOS_CRASH_POINT", "after_wal_commit");
            }
            let status = child.status().unwrap();
            assert!(!status.success());
            assert_ne!(status.code(), Some(74), "WAL crash hook did not fire");
            assert_ne!(
                status.code(),
                Some(101),
                "child panicked instead of reaching crash boundary"
            );
            if mode == "uncommitted" {
                assert_eq!(status.code(), Some(73));
            }
            for _ in 0..2 {
                let mut db = Database::open(&root).unwrap();
                let offset = if mode == "committed" { 10 } else { 0 };
                assert_eq!(
                    rows(&mut db),
                    QueryResult::Rows {
                        columns: vec!["id".into(), "v".into()],
                        rows: vec![
                            Row::new(vec![Value::Int64(1 + offset), Value::Int64(10)]),
                            Row::new(vec![Value::Int64(2 + offset), Value::Int64(20)])
                        ],
                    }
                );
                for tree in db.indexes.values_mut() {
                    tree.validate().unwrap();
                }
                assert!(!fs::read_dir(&root).unwrap().any(|entry| {
                    entry
                        .unwrap()
                        .file_name()
                        .to_string_lossy()
                        .starts_with(".phobos-txn-")
                }));
            }
            fs::remove_dir_all(root).unwrap();
        }
    }
}
