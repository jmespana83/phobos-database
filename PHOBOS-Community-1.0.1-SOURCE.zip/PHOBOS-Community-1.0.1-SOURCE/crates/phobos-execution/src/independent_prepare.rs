//! Disjoint table domains own their heap/index handles during preparation.
//! A single writer preserves request order when binding frozen images to WAL.
use super::*;
use phobos_wal::v2::{FileId, PageAction, PendingCommit};

struct Job {
    context: Option<phobos_error::cancellation::StatementContext>,
    id: u64,
    statement: Statement,
}
struct Prepared {
    result: Result<QueryResult, PhobosError>,
    root: Option<PathBuf>,
    bound: u64,
}
struct Domain {
    database: Database,
    jobs: Vec<Job>,
    prepared: BTreeMap<u64, Prepared>,
}
struct Plan {
    jobs: BTreeMap<TableId, Vec<Job>>,
    order: Vec<(TableId, u64)>,
}

impl Database {
    /// Fence a detached execution owner after an unwinding caller. Only reopen
    /// and recovery can make its potentially partial state usable again.
    pub fn fence_for_recovery(&mut self) {
        self.fenced = true;
    }
    /// C1 remains the exact path for conflicting/single-table groups and for
    /// lifecycle/explicit transactions. Up to eight disjoint domains prepare
    /// concurrently without sharing mutable heap, index or catalog handles.
    pub fn execute_independent_group(
        &mut self,
        sql: &[&str],
    ) -> Vec<Result<QueryResult, PhobosError>> {
        self.execute_independent_group_with_contexts(
            sql,
            &vec![phobos_error::cancellation::current(); sql.len()],
        )
    }
    pub fn execute_independent_group_with_contexts(
        &mut self,
        sql: &[&str],
        contexts: &[Option<phobos_error::cancellation::StatementContext>],
    ) -> Vec<Result<QueryResult, PhobosError>> {
        if contexts.len() != sql.len() {
            return vec![Err(state("statement context count mismatch")); sql.len()];
        }
        let _leader = phobos_error::cancellation::suspend();
        let plan = self.independent_plan(sql, contexts);
        let Some(Plan { jobs, order }) = plan else {
            return self.execute_group_with_contexts(sql, contexts);
        };
        if let Err(error) = self.ensure_available() {
            return vec![Err(error); sql.len()];
        }
        self.fenced = true;
        let result = self.run_independent(jobs, &order);
        match result {
            Ok(results) => {
                self.fenced = false;
                results
            }
            Err(error) => vec![Err(error); sql.len()],
        }
    }

    fn independent_plan(
        &self,
        sql: &[&str],
        contexts: &[Option<phobos_error::cancellation::StatementContext>],
    ) -> Option<Plan> {
        if self.in_transaction() || !self.stats.is_empty() || sql.len() > 64 {
            return None;
        }
        let wal = self.wal_v2.as_ref().filter(|wal| wal.page_format() == 2)?;
        let first = wal.next_transaction_id();
        let mut jobs = BTreeMap::<TableId, Vec<Job>>::new();
        let mut order = Vec::new();
        for (position, sql) in sql.iter().enumerate() {
            let statement = parse(sql).ok()?;
            let table = match &statement {
                Statement::Insert { table, .. }
                | Statement::Update { table, .. }
                | Statement::Delete { table, .. } => table,
                _ => return None,
            };
            let table = self.catalog.table(table)?.id;
            let id = first.checked_add(position as u64)?;
            jobs.entry(table).or_default().push(Job {
                id,
                statement,
                context: contexts[position].clone(),
            });
            order.push((table, id));
        }
        (2..=8)
            .contains(&jobs.len())
            .then_some(Plan { jobs, order })
    }

    fn run_independent(
        &mut self,
        jobs: BTreeMap<TableId, Vec<Job>>,
        order: &[(TableId, u64)],
    ) -> Result<Vec<Result<QueryResult, PhobosError>>, PhobosError> {
        let mut domains = BTreeMap::new();
        for (table, jobs) in jobs {
            let heap = self.heaps.remove(&table).expect("planned heap");
            let index_ids: Vec<_> = self
                .catalog
                .indexes_for_table(table)
                .map(|index| index.id)
                .collect();
            let indexes = index_ids
                .into_iter()
                .map(|id| (id, self.indexes.remove(&id).expect("planned index")))
                .collect();
            domains.insert(
                table,
                Domain {
                    database: Database {
                        data_dir: self.data_dir.clone(),
                        catalog: self.catalog.clone(),
                        heaps: BTreeMap::from([(table, heap)]),
                        indexes,
                        buffer_pages: self.buffer_pages,
                        query_memory_bytes: self.query_memory_bytes,
                        last_access_path: None,
                        last_plan: None,
                        stats: BTreeMap::new(),
                        wal: None,
                        committed_store: self.committed_store.clone(),
                        wal_v2: None,
                        private_txn: None,
                        fenced: false,
                        txn_manager: None,
                        active_txn: None,
                        private_staging: false,
                        mvcc_view: false,
                    },
                    jobs,
                    prepared: BTreeMap::new(),
                },
            );
        }
        let domains = std::thread::scope(|scope| {
            let mut workers: BTreeMap<_, _> = domains
                .into_iter()
                .map(|(table, domain)| (table, scope.spawn(move || domain.prepare())))
                .collect();
            let mut domains = BTreeMap::new();
            let result: Result<_, PhobosError> = (|| {
                let wal = self.wal_v2.as_mut().expect("planned WAL");
                let mut pending = Vec::<(TableId, PendingCommit, PathBuf)>::new();
                let mut bytes = 0_u64;
                let mut results = Vec::new();
                for (table, id) in order {
                    if let Some(worker) = workers.remove(table) {
                        let wait = phobos_observability::span("execution.preparation_wait");
                        let domain = worker.join().map_err(|_| {
                            state("preparation worker panicked; recovery required")
                        })??;
                        drop(wait);
                        domains.insert(*table, domain);
                    }
                    let prepared = domains
                        .get_mut(table)
                        .expect("prepared domain")
                        .prepared
                        .remove(id)
                        .expect("prepared transaction");
                    if !pending.is_empty() && bytes.saturating_add(prepared.bound) > 1024 * 1024 {
                        publish(wal, &mut domains, &mut pending)?;
                        bytes = 0;
                    }
                    boundary("before_append", &self.data_dir, *table)?;
                    let append = phobos_observability::span("wal.writer_append_hold");
                    wal.begin_with_id(*id)?;
                    if let Some(root) = prepared.root {
                        let domain = domains.get_mut(table).expect("prepared domain");
                        for (heap_id, heap) in &mut domain.database.heaps {
                            heap.prepare_pending_redo_based(
                                *id,
                                FileId::Heap(*heap_id),
                                |page, image, base, allocated, phase| {
                                    let action = if allocated {
                                        PageAction::Initialize
                                    } else {
                                        PageAction::HeapUpdate
                                    };
                                    match phase {
                                        phobos_storage::page_io::RedoPhase::Stamp => {
                                            wal.stamp_next_page(
                                                FileId::Heap(*heap_id),
                                                page,
                                                image,
                                            )?;
                                        }
                                        phobos_storage::page_io::RedoPhase::Append => {
                                            wal.append_prepared_page_with_base(
                                                action,
                                                FileId::Heap(*heap_id),
                                                page,
                                                image,
                                                base,
                                            )?;
                                        }
                                    }
                                    Ok(())
                                },
                            )?;
                        }
                        for (index_id, index) in &mut domain.database.indexes {
                            index.prepare_pending_redo_based(
                                *id,
                                FileId::Index(*index_id),
                                |page, image, base, allocated, phase| {
                                    let action = if allocated {
                                        PageAction::Initialize
                                    } else {
                                        PageAction::Index
                                    };
                                    match phase {
                                        phobos_storage::page_io::RedoPhase::Stamp => {
                                            wal.stamp_next_page(
                                                FileId::Index(*index_id),
                                                page,
                                                image,
                                            )?;
                                        }
                                        phobos_storage::page_io::RedoPhase::Append => {
                                            wal.append_prepared_page_with_base(
                                                action,
                                                FileId::Index(*index_id),
                                                page,
                                                image,
                                                base,
                                            )?;
                                        }
                                    }
                                    Ok(())
                                },
                            )?;
                        }
                        pending.push((*table, wal.append_commit()?, root));
                        bytes = bytes.saturating_add(prepared.bound);
                    } else {
                        wal.abort()?;
                    }
                    drop(append);
                    results.push(prepared.result);
                    if bytes >= 1024 * 1024 {
                        publish(wal, &mut domains, &mut pending)?;
                        bytes = 0;
                    }
                }
                publish(wal, &mut domains, &mut pending)?;
                Ok(results)
            })();
            // Always join accepted workers, including after append/force/install
            // failure. No detached writer can mutate state after fencing returns.
            for (_, worker) in workers {
                let _ = worker.join();
            }
            result.map(|results| (domains, results))
        })?;
        let (domains, results) = domains;
        for (_, domain) in domains {
            self.heaps.extend(domain.database.heaps);
            self.indexes.extend(domain.database.indexes);
        }
        self.advance_checkpoint()?;
        Ok(results)
    }
}

impl Domain {
    fn prepare(mut self) -> Result<Self, PhobosError> {
        let _prepare = phobos_observability::span("execution.independent_prepare");
        phobos_observability::event("execution.preparation_domains", 1);
        let table = *self.database.heaps.keys().next().expect("domain table");
        boundary("prepare_start", &self.database.data_dir, table)?;
        for job in std::mem::take(&mut self.jobs) {
            let _statement = job.context.as_ref().map(|context| context.enter());
            self.database.begin_private_with_id(job.id)?;
            let result = phobos_error::cancellation::check_now()
                .and_then(|()| self.database.execute_private_statement(job.statement, &[]))
                .and_then(|result| phobos_error::cancellation::commit().map(|()| result));
            let _durability = phobos_error::cancellation::suspend();
            let prepared = if result.is_err() {
                for heap in self.database.heaps.values_mut() {
                    heap.rollback_private()?;
                }
                for index in self.database.indexes.values_mut() {
                    index.rollback_private()?;
                }
                let transaction = self
                    .database
                    .private_txn
                    .take()
                    .expect("active private transaction");
                fs::remove_dir_all(transaction.temp_dir)?;
                Prepared {
                    result,
                    root: None,
                    bound: 88,
                }
            } else {
                let mut count = 0_u64;
                for heap in self.database.heaps.values_mut() {
                    count = count.saturating_add(heap.private_page_count()?);
                    heap.prepare_private_deferred(|_, _, _| Ok(()))?;
                    heap.stage_private()?;
                }
                for index in self.database.indexes.values_mut() {
                    count = count.saturating_add(index.private_page_count()?);
                    index.prepare_private_deferred(|_, _, _| Ok(()))?;
                    index.stage_private()?;
                }
                let transaction = self
                    .database
                    .private_txn
                    .take()
                    .expect("prepared private transaction");
                Prepared {
                    result,
                    root: Some(transaction.temp_dir),
                    bound: count.saturating_mul(8320).saturating_add(128),
                }
            };
            self.database
                .catalog
                .redirect_persistence(&self.database.data_dir)?;
            self.prepared.insert(job.id, prepared);
        }
        boundary("prepare_done", &self.database.data_dir, table)?;
        Ok(self)
    }
}

fn publish(
    wal: &mut phobos_wal::v2::Wal,
    domains: &mut BTreeMap<TableId, Domain>,
    pending: &mut Vec<(TableId, PendingCommit, PathBuf)>,
) -> Result<(), PhobosError> {
    if pending.is_empty() {
        return Ok(());
    }
    let (tables, tickets, roots) = std::mem::take(pending).into_iter().fold(
        (Vec::new(), Vec::new(), Vec::new()),
        |(mut tables, mut tickets, mut roots), (table, ticket, root)| {
            tables.push(table);
            tickets.push(ticket);
            roots.push(root);
            (tables, tickets, roots)
        },
    );
    let directory = domains
        .values()
        .next()
        .expect("publication domain")
        .database
        .data_dir
        .clone();
    boundary("before_force", &directory, 0)?;
    let force = phobos_observability::span("wal.writer_force_hold");
    let receipts = wal.force_commits(&tickets)?;
    drop(force);
    boundary("after_force", &directory, 0)?;
    let _publication = phobos_observability::span("execution.independent_publication");
    for ((table, receipt), root) in tables.into_iter().zip(receipts).zip(roots) {
        let domain = domains.get_mut(&table).expect("publication domain");
        for heap in domain.database.heaps.values_mut() {
            heap.install_pending(&receipt)?;
        }
        boundary("after_heap_install", &directory, table)?;
        for index in domain.database.indexes.values_mut() {
            index.install_pending(&receipt)?;
        }
        fs::remove_dir_all(root)?;
    }
    boundary("after_install", &directory, 0)?;
    Ok(())
}
#[inline]
fn boundary(point: &str, directory: &Path, table: TableId) -> Result<(), PhobosError> {
    #[cfg(test)]
    {
        if std::env::var("PHOBOS_C2_CRASH_POINT").as_deref() == Ok(point) {
            std::process::exit(86);
        }
        let callback = tests::hooks()
            .lock()
            .expect("test hooks")
            .get(directory)
            .cloned();
        if let Some(callback) = callback {
            callback(point, table)?;
        }
    }
    #[cfg(not(test))]
    let _ = (point, directory, table);
    Ok(())
}
fn state(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TransactionState, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, Mutex, OnceLock, mpsc};
    type Hook = Arc<dyn Fn(&str, TableId) -> Result<(), PhobosError> + Send + Sync>;
    pub(super) fn hooks() -> &'static Mutex<BTreeMap<PathBuf, Hook>> {
        static HOOKS: OnceLock<Mutex<BTreeMap<PathBuf, Hook>>> = OnceLock::new();
        HOOKS.get_or_init(Mutex::default)
    }
    struct Fixture {
        db: Option<Database>,
        path: PathBuf,
    }
    impl Fixture {
        fn new() -> Self {
            let path = std::env::temp_dir().join(format!("phobos-c2-{}", unique_spill_suffix()));
            let mut db = Database::open(&path).unwrap();
            for table in ["a", "b"] {
                db.execute(&format!(
                    "CREATE TABLE {table} (id BIGINT NOT NULL, v BIGINT)"
                ))
                .unwrap();
                db.execute(&format!("CREATE UNIQUE INDEX ix_{table} ON {table} (id)"))
                    .unwrap();
            }
            Self {
                path: fs::canonicalize(path).unwrap(),
                db: Some(db),
            }
        }
        fn hook(&self, callback: Hook) {
            hooks().lock().unwrap().insert(self.path.clone(), callback);
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            hooks().lock().unwrap().remove(&self.path);
            drop(self.db.take());
            fs::remove_dir_all(&self.path).unwrap();
        }
    }
    const QUERIES: [&str; 4] = [
        "INSERT INTO a VALUES (1,10)",
        "INSERT INTO b VALUES (1,20)",
        "UPDATE a SET v=v+1 WHERE id=1",
        "UPDATE b SET v=v+1 WHERE id=1",
    ];
    fn verify(db: &mut Database, committed: bool) {
        for (table, value) in [("a", 11), ("b", 21)] {
            let expected = if committed {
                vec![Row::new(vec![Value::Int64(1), Value::Int64(value)])]
            } else {
                vec![]
            };
            assert_eq!(
                db.execute(&format!("SELECT id,v FROM {table} ORDER BY id"))
                    .unwrap(),
                QueryResult::Rows {
                    columns: vec!["id".into(), "v".into()],
                    rows: expected
                }
            );
        }
        for index in db.indexes.values_mut() {
            index.validate().unwrap();
        }
    }
    #[test]
    fn disjoint_preparation_overlaps_and_never_writes_base_before_force() {
        let mut fixture = Fixture::new();
        let (done, wait) = mpsc::channel();
        let wait = Mutex::new(wait);
        let paths: Vec<_> = [
            FileId::Heap(1),
            FileId::Heap(2),
            FileId::Index(1),
            FileId::Index(2),
        ]
        .into_iter()
        .map(|file| fixture.path.join(file.name()))
        .collect();
        let baseline: Vec<_> = paths.iter().map(|path| fs::read(path).unwrap()).collect();
        fixture.hook(Arc::new(move |point, table| {
            if point == "prepare_start" && table == 1 {
                wait.lock()
                    .unwrap()
                    .recv_timeout(std::time::Duration::from_secs(5))
                    .unwrap();
            }
            if point == "prepare_done" && table == 2 {
                done.send(()).unwrap();
            }
            if point == "before_force" {
                for (path, bytes) in paths.iter().zip(&baseline) {
                    assert_eq!(&fs::read(path).unwrap(), bytes);
                }
            }
            Ok(())
        }));
        let results = fixture
            .db
            .as_mut()
            .unwrap()
            .execute_independent_group(&QUERIES);
        assert!(results.iter().all(Result::is_ok), "{results:?}");
        verify(fixture.db.as_mut().unwrap(), true);
        drop(fixture.db.take());
        let mut db = Database::open(&fixture.path).unwrap();
        verify(&mut db, true);
    }
    #[test]
    fn wal_force_progresses_while_an_independent_domain_is_still_preparing() {
        let mut fixture = Fixture::new();
        fixture
            .db
            .as_mut()
            .unwrap()
            .execute("CREATE TABLE wide (id BIGINT NOT NULL, v TEXT)")
            .unwrap();
        let (forced, waiting) = mpsc::channel();
        let waiting = Mutex::new(waiting);
        fixture.hook(Arc::new(move |point, table| {
            if point == "prepare_start" && table == 2 {
                waiting
                    .lock()
                    .unwrap()
                    .recv_timeout(std::time::Duration::from_secs(10))
                    .unwrap();
            }
            if point == "after_force" {
                let _ = forced.send(());
            }
            Ok(())
        }));
        let value = "x".repeat(1000);
        let sql = format!(
            "INSERT INTO wide VALUES {}",
            (0..1500)
                .map(|id| format!("({id},'{value}')"))
                .collect::<Vec<_>>()
                .join(",")
        );
        let results = fixture
            .db
            .as_mut()
            .unwrap()
            .execute_independent_group(&[&sql, "INSERT INTO b VALUES (1,20)"]);
        assert!(results.iter().all(Result::is_ok), "{results:?}");
        drop(fixture.db.take());
        for _ in 0..2 {
            let mut db = Database::open(&fixture.path).unwrap();
            assert_eq!(
                db.execute("SELECT COUNT(*) FROM wide").unwrap().to_text(),
                "count(*)\n1500\n"
            );
            assert_eq!(
                db.execute("SELECT COUNT(*) FROM b").unwrap().to_text(),
                "count(*)\n1\n"
            );
        }
    }

    #[test]
    fn post_durability_install_failure_fences_all_access_and_recovers() {
        let mut fixture = Fixture::new();
        fixture.hook(Arc::new(|point, _| {
            if point == "after_heap_install" {
                Err(state("injected install failure"))
            } else {
                Ok(())
            }
        }));
        let db = fixture.db.as_mut().unwrap();
        assert!(
            db.execute_independent_group(&QUERIES)
                .iter()
                .all(Result::is_err)
        );
        for sql in [
            "SELECT * FROM a",
            "ROLLBACK",
            "CHECKPOINT",
            "INSERT INTO b VALUES (2,0)",
        ] {
            assert!(db.execute(sql).is_err());
        }
        drop(fixture.db.take());
        for _ in 0..2 {
            let mut db = Database::open(&fixture.path).unwrap();
            verify(&mut db, true);
        }
    }
    #[test]
    fn duplicate_key_failure_rolls_back_only_its_domain_generation() {
        let mut fixture = Fixture::new();
        let db = fixture.db.as_mut().unwrap();
        let results = db.execute_independent_group(&[
            "INSERT INTO a VALUES (1,10)",
            "INSERT INTO b VALUES (1,20)",
            "INSERT INTO a VALUES (2,99),(1,99)",
            "UPDATE b SET v=v+1 WHERE id=1",
            "INSERT INTO a VALUES (2,30)",
            "DELETE FROM a WHERE id=2",
            "UPDATE a SET v=v+1 WHERE id=1",
        ]);
        assert_eq!(
            results.iter().filter(|r| r.is_ok()).count(),
            6,
            "{results:?}"
        );
        assert_eq!(
            results[2].as_ref().unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        verify(db, true);
        drop(fixture.db.take());
        for _ in 0..2 {
            let mut db = Database::open(&fixture.path).unwrap();
            verify(&mut db, true);
        }
    }
    #[test]
    fn large_generations_cross_wal_budget_splits_and_checkpoint_without_loss() {
        let mut fixture = Fixture::new();
        let db = fixture.db.as_mut().unwrap();
        for round in 0..2 {
            let statements: Vec<_> = (0..64)
                .map(|batch| {
                    let table = if batch % 2 == 0 { "a" } else { "b" };
                    let start = round * 3200 + (batch / 2) * 100;
                    format!(
                        "INSERT INTO {table} VALUES {}",
                        (start..start + 100)
                            .map(|id| format!("({id},{id})"))
                            .collect::<Vec<_>>()
                            .join(",")
                    )
                })
                .collect();
            let results = db.execute_independent_group(
                &statements.iter().map(String::as_str).collect::<Vec<_>>(),
            );
            assert!(results.iter().all(Result::is_ok), "{results:?}");
        }
        let expected: Vec<_> = ["a", "b"]
            .into_iter()
            .map(|table| {
                db.execute(&format!("SELECT id,v FROM {table} ORDER BY id"))
                    .unwrap()
            })
            .collect();
        for rows in &expected {
            let QueryResult::Rows { rows, .. } = rows else {
                panic!("missing rows")
            };
            assert_eq!(rows.len(), 6400);
        }
        db.execute("CHECKPOINT").unwrap();
        drop(fixture.db.take());
        for _ in 0..2 {
            let mut db = Database::open(&fixture.path).unwrap();
            for (table, expected) in ["a", "b"].into_iter().zip(&expected) {
                assert_eq!(
                    &db.execute(&format!("SELECT id,v FROM {table} ORDER BY id"))
                        .unwrap(),
                    expected
                );
            }
            for index in db.indexes.values_mut() {
                index.validate().unwrap();
            }
        }
    }

    #[test]
    fn c2_crash_campaign_twenty_cycles() {
        if let Ok(path) = std::env::var("PHOBOS_C2_CRASH_DIR") {
            let mut db = Database::open(path).unwrap();
            let results = db.execute_independent_group(&QUERIES);
            panic!("crash point not reached: {results:?}");
        }
        for cycle in 0..20 {
            let point = [
                "before_append",
                "before_force",
                "after_force",
                "after_heap_install",
                "after_install",
            ][cycle % 5];
            let mut fixture = Fixture::new();
            drop(fixture.db.take());
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "independent_prepare::tests::c2_crash_campaign_twenty_cycles",
                    "--nocapture",
                ])
                .env("PHOBOS_C2_CRASH_DIR", &fixture.path)
                .env("PHOBOS_C2_CRASH_POINT", point)
                .status()
                .unwrap();
            assert_eq!(status.code(), Some(86), "cycle {cycle} at {point}");
            for _ in 0..2 {
                let mut db = Database::open(&fixture.path).unwrap();
                // 0.2-E Mode E: an unforced batch is still in the writer's
                // memory at "before_force" (never acknowledged): all-or-none.
                let unforced_lost = point == "before_force"
                    && phobos_wal::v2::DurabilityMode::configured()
                        == phobos_wal::v2::DurabilityMode::WriteThrough;
                verify(&mut db, point != "before_append" && !unforced_lost);
            }
        }
    }
}
