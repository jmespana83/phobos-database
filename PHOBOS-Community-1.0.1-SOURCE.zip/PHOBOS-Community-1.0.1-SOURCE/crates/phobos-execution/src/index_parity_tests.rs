//! 0.1.9-A1.1: index-probe versus sequential-scan predicate parity.
//!
//! An index is an optimization only. For every comparison predicate these
//! tests run identical SQL against (a) a table without an index, (b) the same
//! table with an applicable index and no statistics (index scan is always
//! chosen when a constraint exists) and (c) with ANALYZE statistics, through
//! the collecting and the streaming executor, and through UPDATE/DELETE, and
//! require the same rows and the same error code from every access path. The
//! semantic authority is `Value::canonical_cmp` (A1); index bounds may only
//! narrow the candidate set, never change what the predicate returns.
use super::*;

fn fingerprint(rows: &[Row]) -> Vec<String> {
    let mut out: Vec<String> = rows.iter().map(|row| format!("{:?}", row.values)).collect();
    out.sort();
    out
}

#[derive(Default)]
struct Capture {
    rows: Vec<Row>,
}
impl ResultSink for Capture {
    fn start(&mut self, _: Vec<String>) -> Result<(), PhobosError> {
        Ok(())
    }
    fn row(&mut self, row: Row) -> Result<(), PhobosError> {
        self.rows.push(row);
        Ok(())
    }
    fn finish(&mut self) -> Result<(), PhobosError> {
        Ok(())
    }
    fn command(&mut self, _: String, _: u64) -> Result<(), PhobosError> {
        panic!("expected rows")
    }
}

fn temp_database(name: &str) -> (PathBuf, Database) {
    let dir = std::env::temp_dir().join(format!(
        "phobos-a11-{name}-{}-{}",
        std::process::id(),
        unique_spill_suffix()
    ));
    let db = Database::open(&dir).unwrap();
    (dir, db)
}

const OPERATORS: [&str; 6] = ["=", "<>", "<", "<=", ">", ">="];

fn bigint_rows() -> Vec<Value> {
    vec![
        Value::Int64(i64::MIN),
        Value::Int64(-9_007_199_254_740_993),
        Value::Int64(-1),
        Value::Int64(0),
        Value::Int64(1),
        Value::Int64(2),
        Value::Int64(9_007_199_254_740_992),
        Value::Int64(9_007_199_254_740_993),
        Value::Int64(9_007_199_254_740_994),
        Value::Int64(i64::MAX),
        Value::Null,
        Value::Int64(1),
    ]
}

fn bigint_constants() -> Vec<Value> {
    vec![
        Value::Int64(1),
        Value::Int64(0),
        Value::Int64(9_007_199_254_740_993),
        Value::Int64(i64::MIN),
        Value::Int64(i64::MAX),
        Value::Float64(1.0),
        Value::Float64(1.5),
        Value::Float64(0.5),
        Value::Float64(-0.5),
        Value::Float64(0.0),
        Value::Float64(-0.0),
        Value::Float64(9_007_199_254_740_992.0),
        Value::Float64(9_007_199_254_740_994.0),
        Value::Float64(-9_223_372_036_854_775_808.0),
        Value::Float64(9_223_372_036_854_775_808.0),
        Value::Float64(-1.0e19),
        Value::Float64(1.0e19),
        Value::Float64(f64::INFINITY),
        Value::Float64(f64::NEG_INFINITY),
        Value::Float64(f64::NAN),
        Value::Float64(-f64::NAN),
        Value::Null,
    ]
}

fn float_rows() -> Vec<Value> {
    vec![
        Value::Float64(-f64::NAN),
        Value::Float64(f64::NAN),
        Value::Float64(f64::from_bits(0x7ff8_0000_0000_0001)),
        Value::Float64(f64::NEG_INFINITY),
        Value::Float64(-1.0e300),
        Value::Float64(-9_223_372_036_854_775_808.0),
        Value::Float64(-1.5),
        Value::Float64(-0.0),
        Value::Float64(0.0),
        Value::Float64(0.5),
        Value::Float64(1.0),
        Value::Float64(9_007_199_254_740_992.0),
        Value::Float64(9_007_199_254_740_994.0),
        Value::Float64(9_007_199_254_740_996.0),
        Value::Float64(9_223_372_036_854_775_808.0),
        Value::Float64(1.0e300),
        Value::Float64(f64::INFINITY),
        Value::Null,
        Value::Float64(1.0),
    ]
}

fn float_constants() -> Vec<Value> {
    vec![
        Value::Int64(1),
        Value::Int64(0),
        Value::Int64(-2),
        Value::Int64(9_007_199_254_740_992),
        Value::Int64(9_007_199_254_740_993),
        Value::Int64(9_007_199_254_740_995),
        Value::Int64(i64::MIN),
        Value::Int64(i64::MAX),
        Value::Float64(0.0),
        Value::Float64(-0.0),
        Value::Float64(1.0),
        Value::Float64(1.5),
        Value::Float64(-1.5),
        Value::Float64(f64::INFINITY),
        Value::Float64(f64::NEG_INFINITY),
        Value::Float64(f64::NAN),
        Value::Float64(-f64::NAN),
        Value::Null,
    ]
}

/// One SELECT outcome: sorted rows or the error code, plus the access path taken.
type Outcome = Result<Vec<String>, ErrorCode>;

fn run_select(db: &mut Database, sql: &str, params: &[Value]) -> (Outcome, Outcome, String) {
    let collected = db
        .execute_params(sql, params)
        .map(|result| match result {
            QueryResult::Rows { rows, .. } => fingerprint(&rows),
            other => panic!("expected rows, got {other:?}"),
        })
        .map_err(|error| error.code);
    let path = db.last_access_path().unwrap_or("").to_string();
    let mut capture = Capture::default();
    let streamed = db
        .execute_stream(sql, params, &mut capture)
        .map(|()| fingerprint(&capture.rows))
        .map_err(|error| error.code);
    (collected, streamed, path)
}

struct Fixture {
    dir: PathBuf,
    db: Database,
}

impl Fixture {
    /// Three tables with identical rows: `plain` (no index), `idx` (index on k,
    /// no statistics) and `stats` (index on k, ANALYZE run).
    fn new(name: &str, column_type: &str, rows: &[Value]) -> Self {
        let (dir, mut db) = temp_database(name);
        for table in ["plain", "idx", "stats"] {
            db.execute(&format!(
                "CREATE TABLE {table} (id BIGINT NOT NULL, k {column_type}, v BIGINT NOT NULL)"
            ))
            .unwrap();
            for (id, value) in rows.iter().enumerate() {
                db.execute_params(
                    &format!("INSERT INTO {table} VALUES ($1, $2, $3)"),
                    &[Value::Int64(id as i64), value.clone(), Value::Int64(100)],
                )
                .unwrap();
            }
        }
        db.execute("CREATE INDEX idx_k ON idx(k)").unwrap();
        db.execute("CREATE INDEX stats_k ON stats(k)").unwrap();
        db.execute("ANALYZE stats").unwrap();
        Self { dir, db }
    }
    fn close(self) {
        drop(self.db);
        fs::remove_dir_all(self.dir).unwrap();
    }
}

fn check_select_parity(name: &str, column_type: &str, rows: &[Value], constants: &[Value]) {
    let mut fixture = Fixture::new(name, column_type, rows);
    let mut index_paths = 0usize;
    let mut scan_paths = 0usize;
    let mut cases = 0usize;
    for constant in constants {
        for op in OPERATORS {
            for (label, predicate) in [
                ("column-first", format!("k {op} $1")),
                ("constant-first", format!("$1 {op} k")),
                ("conjunction", format!("k {op} $1 AND v = 100")),
            ] {
                let params = [constant.clone()];
                let mut outcomes = Vec::new();
                for table in ["plain", "idx", "stats"] {
                    let sql = format!("SELECT id, k FROM {table} WHERE {predicate}");
                    let (collected, streamed, path) = run_select(&mut fixture.db, &sql, &params);
                    assert_eq!(
                        collected, streamed,
                        "{column_type} {label} {predicate} {constant:?} on {table}: collecting vs streaming"
                    );
                    if path.starts_with("INDEX") {
                        index_paths += 1;
                    } else {
                        scan_paths += 1;
                    }
                    outcomes.push((table, path, collected));
                }
                let (_, _, expected) = &outcomes[0];
                for (table, path, actual) in &outcomes[1..] {
                    assert_eq!(
                        actual, expected,
                        "{column_type} {label} {predicate} {constant:?}: {table} ({path}) differs from plain (TABLE SCAN)"
                    );
                }
                cases += 1;
            }
        }
    }
    assert!(index_paths > 0, "no index path was exercised");
    assert!(scan_paths > 0, "no scan path was exercised");
    eprintln!(
        "{column_type}: {cases} predicates, index paths {index_paths}, scan paths {scan_paths}"
    );
    fixture.close();
}

#[test]
fn a11_bigint_column_predicates_are_access_path_independent() {
    check_select_parity("bigint", "BIGINT", &bigint_rows(), &bigint_constants());
}

#[test]
fn a11_float_column_predicates_are_access_path_independent() {
    check_select_parity("float", "DOUBLE", &float_rows(), &float_constants());
}

/// The specific divergences the A1 report and this round identified, spelled
/// out with the rows the canonical contract requires.
#[test]
fn a11_named_divergences_return_canonical_rows_through_the_index() {
    let mut fixture = Fixture::new("named", "BIGINT", &bigint_rows());
    let ids = |db: &mut Database, sql: &str, params: &[Value]| -> (Vec<i64>, String) {
        let rows = match db.execute_params(sql, params).unwrap() {
            QueryResult::Rows { rows, .. } => rows,
            other => panic!("{other:?}"),
        };
        let mut ids: Vec<i64> = rows
            .iter()
            .map(|row| match row.values[0] {
                Value::Int64(id) => id,
                ref other => panic!("{other:?}"),
            })
            .collect();
        ids.sort_unstable();
        (ids, db.last_access_path().unwrap().to_string())
    };
    // BIGINT = 1.5 used to raise TypeMismatch from index-key construction only.
    let (rows, path) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Float64(1.5)],
    );
    assert!(rows.is_empty(), "{rows:?} via {path}");
    // BIGINT = 1.0 probes BIGINT 1 (rows 4 and 11 hold the value 1).
    let (rows, path) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Float64(1.0)],
    );
    assert_eq!(rows, [4, 11], "via {path}");
    assert!(path.starts_with("INDEX"), "{path}");
    // 2^53 as a float must not match 2^53+1 (row 7), only 2^53 (row 6).
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Float64(9_007_199_254_740_992.0)],
    );
    assert_eq!(rows, [6]);
    // Range bounds with fractional constants: k > 1.5 is k >= 2; k < 1.5 is k <= 1.
    let (rows, path) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k > $1",
        &[Value::Float64(1.5)],
    );
    assert_eq!(rows, [5, 6, 7, 8, 9], "via {path}");
    assert!(path.starts_with("INDEX"), "{path}");
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k < $1",
        &[Value::Float64(1.5)],
    );
    assert_eq!(rows, [0, 1, 2, 3, 4, 11]);
    // Out-of-range and non-finite constants keep the sequential-scan answer.
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k < $1",
        &[Value::Float64(1.0e19)],
    );
    assert_eq!(rows, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11]);
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k > $1",
        &[Value::Float64(1.0e19)],
    );
    assert!(rows.is_empty());
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k <= $1",
        &[Value::Float64(f64::NAN)],
    );
    assert_eq!(
        rows,
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11],
        "every number is below NaN"
    );
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Float64(f64::NAN)],
    );
    assert!(rows.is_empty());
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k >= $1",
        &[Value::Float64(f64::NEG_INFINITY)],
    );
    assert_eq!(rows, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11]);
    // NULL constants: no row matches, no error, even on a NOT NULL indexed column.
    fixture
        .db
        .execute("CREATE TABLE strict (id BIGINT NOT NULL, k BIGINT NOT NULL)")
        .unwrap();
    fixture
        .db
        .execute("INSERT INTO strict VALUES (1, 1)")
        .unwrap();
    fixture
        .db
        .execute("CREATE INDEX strict_k ON strict(k)")
        .unwrap();
    for op in OPERATORS {
        let (rows, _) = ids(
            &mut fixture.db,
            &format!("SELECT id FROM strict WHERE k {op} $1"),
            &[Value::Null],
        );
        assert!(rows.is_empty(), "k {op} NULL");
    }
    fixture.close();

    // FLOAT column: the index orders floats by bit pattern (total order), the
    // predicate by canonical value. Signed zero and NaN must not be lost.
    let mut fixture = Fixture::new("named-float", "DOUBLE", &float_rows());
    let (rows, path) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Float64(0.0)],
    );
    assert_eq!(rows, [7, 8], "both signed zeros, via {path}");
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Int64(0)],
    );
    assert_eq!(rows, [7, 8]);
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Float64(f64::NAN)],
    );
    assert_eq!(rows, [0, 1, 2], "every NaN payload and sign");
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k > $1",
        &[Value::Float64(1.0e300)],
    );
    assert_eq!(
        rows,
        [0, 1, 2, 16],
        "NaN sorts above every number, whatever its sign bit"
    );
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k >= $1",
        &[Value::Int64(9_007_199_254_740_993)],
    );
    assert_eq!(
        rows,
        [0, 1, 2, 12, 13, 14, 15, 16],
        "2^53+1 rounds to 2^53 as a float; 2^53 itself must not match"
    );
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k > $1",
        &[Value::Int64(9_007_199_254_740_995)],
    );
    assert_eq!(
        rows,
        [0, 1, 2, 13, 14, 15, 16],
        "2^53+3 rounds up to 2^53+4, which is still > 2^53+3"
    );
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k = $1",
        &[Value::Int64(9_007_199_254_740_993)],
    );
    assert!(rows.is_empty());
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k < $1",
        &[Value::Int64(i64::MIN)],
    );
    assert_eq!(rows, [3, 4]);
    let (rows, _) = ids(
        &mut fixture.db,
        "SELECT id FROM idx WHERE k >= $1",
        &[Value::Int64(i64::MAX)],
    );
    assert_eq!(
        rows,
        [0, 1, 2, 14, 15, 16],
        "i64::MAX rounds up to 2^63, which is greater than i64::MAX"
    );
    fixture.close();
}

/// UPDATE and DELETE reuse `plan_index_search`; affected rows and the table
/// afterwards must not depend on the index.
#[test]
fn a11_indexed_update_and_delete_affect_the_same_rows_as_a_table_scan() {
    let bigint = bigint_rows();
    let float = float_rows();
    let scenarios: [(&str, &[Value], Vec<Value>); 2] = [
        (
            "BIGINT",
            &bigint,
            vec![
                Value::Int64(1),
                Value::Float64(1.0),
                Value::Float64(1.5),
                Value::Float64(-0.0),
                Value::Float64(9_007_199_254_740_992.0),
                Value::Float64(f64::INFINITY),
                Value::Float64(f64::NAN),
                Value::Float64(1.0e19),
                Value::Null,
            ],
        ),
        (
            "DOUBLE",
            &float,
            vec![
                Value::Int64(1),
                Value::Int64(0),
                Value::Int64(9_007_199_254_740_993),
                Value::Int64(i64::MAX),
                Value::Float64(0.0),
                Value::Float64(1.5),
                Value::Float64(f64::NAN),
                Value::Float64(f64::NEG_INFINITY),
                Value::Null,
            ],
        ),
    ];
    let (dir, mut db) = temp_database("dml");
    let mut index_paths = 0usize;
    for (column_type, rows, constants) in scenarios {
        let mut params = Vec::new();
        let mut tuples = Vec::new();
        for (id, value) in rows.iter().enumerate() {
            let base = params.len();
            params.extend([Value::Int64(id as i64), value.clone(), Value::Int64(100)]);
            tuples.push(format!("(${}, ${}, ${})", base + 1, base + 2, base + 3));
        }
        let tables = [
            (format!("plain_{}", column_type.to_ascii_lowercase()), false),
            (format!("idx_{}", column_type.to_ascii_lowercase()), true),
        ];
        let reload = |db: &mut Database, name: &str| {
            db.execute(&format!("DELETE FROM {name}")).unwrap();
            db.execute_params(
                &format!("INSERT INTO {name} VALUES {}", tuples.join(",")),
                &params,
            )
            .unwrap();
        };
        for (name, indexed) in &tables {
            db.execute(&format!(
                "CREATE TABLE {name} (id BIGINT NOT NULL, k {column_type}, v BIGINT NOT NULL)"
            ))
            .unwrap();
            if *indexed {
                db.execute(&format!("CREATE INDEX {name}_k ON {name}(k)"))
                    .unwrap();
            }
            reload(&mut db, name);
        }
        for constant in constants {
            for op in OPERATORS {
                for statement in [
                    "UPDATE {t} SET v = v + 1 WHERE k {op} $1",
                    "DELETE FROM {t} WHERE k {op} $1",
                ] {
                    let mut results = Vec::new();
                    for (name, indexed) in &tables {
                        let sql = statement.replace("{t}", name).replace("{op}", op);
                        let outcome = db
                            .execute_params(&sql, std::slice::from_ref(&constant))
                            .map(|result| match result {
                                QueryResult::Command { rows_affected, .. } => rows_affected,
                                other => panic!("{other:?}"),
                            })
                            .map_err(|error| error.code);
                        if *indexed
                            && db
                                .last_access_path()
                                .is_some_and(|path| path.starts_with("INDEX"))
                        {
                            index_paths += 1;
                        }
                        let after = match db
                            .execute(&format!("SELECT id, k, v FROM {name} ORDER BY id"))
                            .unwrap()
                        {
                            QueryResult::Rows { rows, .. } => fingerprint(&rows),
                            other => panic!("{other:?}"),
                        };
                        results.push((name.clone(), outcome, after));
                        reload(&mut db, name);
                    }
                    assert_eq!(
                        results[0].1, results[1].1,
                        "{column_type} {statement} {op} {constant:?}: rows affected differ"
                    );
                    assert_eq!(
                        results[0].2, results[1].2,
                        "{column_type} {statement} {op} {constant:?}: table contents differ"
                    );
                }
            }
        }
    }
    assert!(index_paths > 0, "no indexed DML path was exercised");
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

/// Composite (multi-column) index probes follow the same rules.
#[test]
fn a11_composite_index_equality_probes_follow_the_canonical_contract() {
    let (dir, mut db) = temp_database("composite");
    for table in ["plain", "idx"] {
        db.execute(&format!(
            "CREATE TABLE {table} (a BIGINT, b DOUBLE, id BIGINT NOT NULL)"
        ))
        .unwrap();
        let rows = [
            (Value::Int64(1), Value::Float64(0.0)),
            (Value::Int64(1), Value::Float64(-0.0)),
            (Value::Int64(1), Value::Float64(2.5)),
            (Value::Int64(2), Value::Float64(f64::NAN)),
            (Value::Int64(9_007_199_254_740_993), Value::Float64(1.0)),
            (Value::Null, Value::Float64(1.0)),
            (Value::Int64(3), Value::Null),
        ];
        for (id, (a, b)) in rows.iter().enumerate() {
            db.execute_params(
                &format!("INSERT INTO {table} VALUES ($1, $2, $3)"),
                &[a.clone(), b.clone(), Value::Int64(id as i64)],
            )
            .unwrap();
        }
    }
    db.execute("CREATE INDEX idx_ab ON idx(a, b)").unwrap();
    let constants = [
        (Value::Int64(1), Value::Float64(0.0)),
        (Value::Float64(1.0), Value::Int64(0)),
        (Value::Float64(1.0), Value::Float64(-0.0)),
        (Value::Float64(1.5), Value::Float64(2.5)),
        (Value::Int64(1), Value::Float64(2.5)),
        (Value::Int64(2), Value::Float64(f64::NAN)),
        (Value::Float64(9_007_199_254_740_992.0), Value::Int64(1)),
        (Value::Int64(9_007_199_254_740_993), Value::Int64(1)),
        (Value::Null, Value::Float64(1.0)),
        (Value::Int64(3), Value::Null),
        (Value::Float64(f64::INFINITY), Value::Float64(1.0)),
    ];
    let mut index_paths = 0;
    for (a, b) in constants {
        let params = [a.clone(), b.clone()];
        let mut outcomes = Vec::new();
        for table in ["plain", "idx"] {
            let sql = format!("SELECT id FROM {table} WHERE a = $1 AND b = $2");
            let (collected, streamed, path) = run_select(&mut db, &sql, &params);
            assert_eq!(collected, streamed, "{sql} {params:?}");
            if path.starts_with("INDEX") {
                index_paths += 1;
            }
            outcomes.push(collected);
        }
        assert_eq!(outcomes[0], outcomes[1], "composite probe {params:?}");
    }
    assert!(index_paths > 0);
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn composite_leading_prefix_matches_scan_and_suffix_only_stays_a_scan() {
    let (dir, mut db) = temp_database("composite-prefix");
    for table in ["plain", "idx"] {
        db.execute(&format!(
            "CREATE TABLE {table} (a BIGINT, b TEXT, id BIGINT NOT NULL)"
        ))
        .unwrap();
        db.execute(&format!(
            "INSERT INTO {table} VALUES (1,'a',1),(1,'x',2),(1,'z',3),(2,'x',4),(NULL,'x',5)"
        ))
        .unwrap();
        // 0.2-B: enough other keys that the a=1 prefix is selective; the
        // realistic heap-fetch cost would (correctly) scan a 5-row table.
        let filler = (0..200)
            .map(|i| format!("({},'q',{})", 100 + i, 100 + i))
            .collect::<Vec<_>>()
            .join(",");
        db.execute(&format!("INSERT INTO {table} VALUES {filler}"))
            .unwrap();
    }
    db.execute("CREATE INDEX idx_ab ON idx(a,b)").unwrap();
    db.execute("ANALYZE idx").unwrap();

    for predicate in ["a=1", "a=1 AND b='x'", "a=1 AND b>='b' AND b<'z'"] {
        let mut results = Vec::new();
        for table in ["plain", "idx"] {
            let sql = format!("SELECT id FROM {table} WHERE {predicate} ORDER BY id");
            let (collected, streamed, path) = run_select(&mut db, &sql, &[]);
            assert_eq!(collected, streamed, "{sql}");
            if table == "idx" {
                assert_eq!(path, "INDEX idx_ab", "{sql}");
            }
            results.push(collected);
        }
        assert_eq!(results[0], results[1], "{predicate}");
    }

    let (plain, _, _) = run_select(&mut db, "SELECT id FROM plain WHERE b='x' ORDER BY id", &[]);
    let (indexed, streamed, path) =
        run_select(&mut db, "SELECT id FROM idx WHERE b='x' ORDER BY id", &[]);
    assert_eq!(indexed, streamed);
    assert_eq!(plain, indexed);
    assert_eq!(path, "TABLE SCAN");

    drop(db);
    fs::remove_dir_all(dir).unwrap();
}

/// Statically incomparable predicates (class mismatch) raise the same
/// TypeMismatch with and without an index, and a filter that can raise a
/// row-dependent error never has that error hidden by index pruning.
#[test]
fn a11_index_never_hides_predicate_errors() {
    let (dir, mut db) = temp_database("errors");
    for table in ["plain", "idx"] {
        db.execute(&format!(
            "CREATE TABLE {table} (k BIGINT, t TEXT, d DECIMAL(10,2), v BIGINT)"
        ))
        .unwrap();
        db.execute_params(
            &format!("INSERT INTO {table} VALUES (1, 'a', $1, 1), (2, 'b', $2, 9223372036854775807), (3, NULL, NULL, 3)"),
            &[
                Value::Decimal { unscaled: 100, scale: 2 },
                Value::Decimal { unscaled: 250, scale: 2 },
            ],
        )
        .unwrap();
    }
    db.execute("CREATE INDEX idx_k ON idx(k)").unwrap();
    db.execute("CREATE INDEX idx_t ON idx(t)").unwrap();
    db.execute("CREATE INDEX idx_d ON idx(d)").unwrap();
    let cases: Vec<(&str, Vec<Value>)> = vec![
        ("k = 'x'", vec![]),
        ("t = 1", vec![]),
        ("d = 1.0", vec![]),
        ("d = 1", vec![]),
        (
            "d = $1",
            vec![Value::Decimal {
                unscaled: 10,
                scale: 1,
            }],
        ),
        ("k = 1 AND t = 1", vec![]),
        ("k = 99 AND t = 1", vec![]),
        ("k = 99 AND (t = 'a' OR t = 1)", vec![]),
        ("k = 1 AND v + 1 > 0", vec![]),
        ("k = 99 AND v + 1 > 0", vec![]),
        ("k = 99 AND 1", vec![]),
        ("k = 1 AND -v < 0", vec![]),
        (
            "d = $1",
            vec![Value::Decimal {
                unscaled: 100,
                scale: 2,
            }],
        ),
        ("t = 'a' AND k >= 1", vec![]),
        ("t IS NULL AND k > 0", vec![]),
        ("NOT (k = 1) AND k < 3", vec![]),
    ];
    for (predicate, params) in cases {
        let mut outcomes = Vec::new();
        for table in ["plain", "idx"] {
            let sql = format!("SELECT k FROM {table} WHERE {predicate}");
            let (collected, streamed, path) = run_select(&mut db, &sql, &params);
            assert_eq!(collected, streamed, "{sql}: collecting vs streaming");
            outcomes.push((path, collected));
        }
        assert_eq!(
            outcomes[0].1, outcomes[1].1,
            "{predicate}: plain ({}) vs idx ({})",
            outcomes[0].0, outcomes[1].0
        );
    }
    drop(db);
    fs::remove_dir_all(dir).unwrap();
}
