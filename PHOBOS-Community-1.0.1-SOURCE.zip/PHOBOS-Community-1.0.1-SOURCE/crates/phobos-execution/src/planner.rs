//! Compact selectivity helpers for the deliberately small E3 planner.
use super::*;

pub(super) fn estimate_filter_selectivity(
    statistics: Option<&TableStatistics>,
    schema: &TableSchema,
    filter: Option<&Expr>,
) -> f64 {
    let Some(filter) = filter else {
        return 1.0;
    };
    if let Expr::Binary {
        left,
        op: BinaryOp::And,
        right,
    } = filter
    {
        return (estimate_filter_selectivity(statistics, schema, Some(left))
            * estimate_filter_selectivity(statistics, schema, Some(right)))
        .clamp(0.0001, 1.0);
    }
    let Expr::Binary { left, op, right: _ } = filter else {
        return 0.5;
    };
    let Expr::Column(column) = left.as_ref() else {
        return 0.5;
    };
    let column_name = column.rsplit('.').next().unwrap_or(column);
    if schema.column_index(column_name).is_none() {
        return 0.5;
    }
    let Some(column_stats) =
        statistics.and_then(|table| table.columns.get(&column_name.to_ascii_lowercase()))
    else {
        return match op {
            BinaryOp::Eq => 0.1,
            BinaryOp::Lt | BinaryOp::LtEq | BinaryOp::Gt | BinaryOp::GtEq => 0.33,
            _ => 0.5,
        };
    };
    match op {
        BinaryOp::Eq => {
            if column_stats.distinct_count == 0 {
                0.1
            } else {
                (1.0 / column_stats.distinct_count as f64).clamp(0.0001, 1.0)
            }
        }
        BinaryOp::Lt | BinaryOp::LtEq | BinaryOp::Gt | BinaryOp::GtEq => 0.33,
        _ => 0.5,
    }
}

pub(super) fn estimate_index_selectivity(
    statistics: Option<&TableStatistics>,
    index: &IndexSchema,
    filter: &Expr,
) -> f64 {
    let Some(leading) = index.columns.first() else {
        return 1.0;
    };
    let distinct = statistics
        .and_then(|table| table.columns.get(&leading.to_ascii_lowercase()))
        .map_or(10, |column| column.distinct_count.max(1));
    fn predicate(expr: &Expr, column: &str) -> Option<BinaryOp> {
        match expr {
            Expr::Binary {
                left,
                op: BinaryOp::And,
                right,
            } => predicate(left, column).or_else(|| predicate(right, column)),
            Expr::Binary { left, op, right } => {
                let matches = |expr: &Expr| match expr {
                    Expr::Column(name) => name
                        .rsplit('.')
                        .next()
                        .is_some_and(|name| name.eq_ignore_ascii_case(column)),
                    _ => false,
                };
                (matches(left) || matches(right)).then_some(*op)
            }
            _ => None,
        }
    }
    match predicate(filter, leading) {
        Some(BinaryOp::Eq) => (1.0 / distinct as f64).clamp(0.0001, 1.0),
        Some(BinaryOp::Lt | BinaryOp::LtEq | BinaryOp::Gt | BinaryOp::GtEq) => 0.33,
        _ => 0.5,
    }
}
