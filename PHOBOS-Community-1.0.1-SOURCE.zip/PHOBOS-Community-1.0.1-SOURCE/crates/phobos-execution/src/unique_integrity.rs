//! Fail closed when a pre-A1.2 UNIQUE FLOAT index describes duplicate live rows.
use super::*;
impl Database {
    pub(super) fn validate_canonical_unique(&mut self) -> Result<(), PhobosError> {
        let definitions = self
            .catalog
            .indexes()
            .filter(|i| i.unique)
            .cloned()
            .collect::<Vec<_>>();
        for index in definitions {
            let schema = self
                .catalog
                .tables()
                .find(|t| t.id == index.table_id)
                .cloned()
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "unique table missing")
                })?;
            if !index.columns.iter().any(|c| {
                schema
                    .column_index(c)
                    .is_some_and(|p| schema.columns[p].data_type == DataType::Float64)
            }) {
                continue;
            }
            let mut seen = HashSet::new();
            self.heap_mut(schema.id)?.scan_visit(|_,row|{
                if let Some(key)=index_key_for_row(&schema,&index,&row)?.logical_unique_key(){
                    if !seen.insert(key){
                        return Err(PhobosError::new(ErrorCode::ConstraintViolation,
                            format!("existing UNIQUE index {} violates canonical equality; repair duplicate rows using the prior version before reopening",index.name)));
                    }
                }
                Ok(true)
            })?;
        }
        Ok(())
    }
}
