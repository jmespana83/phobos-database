//! Bounded, ordered autocommit generations. Exclusive Database ownership keeps
//! public readers behind publication; only successor DML reads pending pages.
use super::*;
use phobos_wal::v2::{FileId, PageAction, PendingCommit};

struct PreparedCommit {
    ticket: PendingCommit,
    root: PathBuf,
}

impl Database {
    /// Execute at most 64 already-admitted requests. Each statement remains its
    /// own transaction. DDL, statistics, legacy formats and explicit transactions
    /// retain the synchronous path. No success is returned before publication.
    pub fn execute_group(&mut self, sql: &[&str]) -> Vec<Result<QueryResult, PhobosError>> {
        self.execute_group_with_contexts(
            sql,
            &vec![phobos_error::cancellation::current(); sql.len()],
        )
    }
    pub(super) fn execute_group_with_contexts(
        &mut self,
        sql: &[&str],
        contexts: &[Option<phobos_error::cancellation::StatementContext>],
    ) -> Vec<Result<QueryResult, PhobosError>> {
        let _leader = phobos_error::cancellation::suspend();
        if sql.len() > 64 {
            return vec![
                Err(PhobosError::new(
                    ErrorCode::ResourceLimit,
                    "commit group exceeds 64 requests"
                ));
                sql.len()
            ];
        }
        let mut results = Vec::with_capacity(sql.len());
        let mut pending = Vec::new();
        let mut published = 0;
        let mut batch_start = self.wal_v2.as_ref().map_or(0, |wal| wal.written_len());
        for (statement_sql, context) in sql.iter().zip(contexts) {
            let _statement = context.as_ref().map(|context| context.enter());
            let parsed = parse(statement_sql);
            let eligible = !self.in_transaction()
                && self.stats.is_empty()
                && self
                    .wal_v2
                    .as_ref()
                    .is_some_and(|wal| wal.page_format() == 2)
                && matches!(
                    &parsed,
                    Ok(Statement::Insert { .. }
                        | Statement::Update { .. }
                        | Statement::Delete { .. })
                );
            if !eligible {
                if let Err(error) = self.publish_group(&mut pending) {
                    fail_pending_results(&mut results[published..], error.clone());
                    results.resize(sql.len(), Err(error));
                    return results;
                }
                results.push(self.execute(statement_sql));
                published = results.len();
                batch_start = self.wal_v2.as_ref().map_or(0, |wal| wal.written_len());
                continue;
            }
            let mut oversized = false;
            let result = (|| {
                let value = self.begin_group_statement(parsed.expect("eligible statement"))?;
                self.fenced = true;
                let bound = self.group_redo_bound()?;
                self.fenced = false;
                oversized = bound > 1024 * 1024;
                let queued = self
                    .wal_v2
                    .as_ref()
                    .expect("V2 WAL")
                    .written_len()
                    .saturating_sub(batch_start);
                if !pending.is_empty() && queued.saturating_add(bound) > 1024 * 1024 {
                    self.publish_group(&mut pending)?;
                    published = results.len();
                    batch_start = self.wal_v2.as_ref().expect("V2 WAL").written_len();
                }
                if let Err(error) = phobos_error::cancellation::commit() {
                    let _cleanup = phobos_error::cancellation::suspend();
                    self.rollback_private_transaction()?;
                    return Err(error);
                }
                self.stage_group_statement(value)
            })();
            match result {
                Ok((prepared, value)) => {
                    pending.push(prepared);
                    results.push(Ok(value));
                }
                Err(error) => {
                    results.push(Err(error.clone()));
                    if self.fenced {
                        fail_pending_results(&mut results[published..], error.clone());
                        results.resize(sql.len(), Err(error));
                        return results;
                    }
                }
            }
            if oversized
                || self
                    .wal_v2
                    .as_ref()
                    .expect("V2 WAL")
                    .written_len()
                    .saturating_sub(batch_start)
                    >= 1024 * 1024
            {
                if let Err(error) = self.publish_group(&mut pending) {
                    fail_pending_results(&mut results[published..], error.clone());
                    results.resize(sql.len(), Err(error));
                    return results;
                }
                batch_start = self.wal_v2.as_ref().expect("V2 WAL").written_len();
                published = results.len();
            }
        }
        if let Err(error) = self.publish_group(&mut pending) {
            fail_pending_results(&mut results[published..], error);
        }
        results
    }

    fn begin_group_statement(&mut self, statement: Statement) -> Result<QueryResult, PhobosError> {
        self.ensure_available()?;
        phobos_error::cancellation::check_now()?;
        self.begin_private_transaction()?;
        match self.execute_private_statement(statement, &[]) {
            Ok(value) => Ok(value),
            Err(error) => {
                self.rollback_private_transaction()?;
                Err(error)
            }
        }
    }

    fn group_redo_bound(&mut self) -> Result<u64, PhobosError> {
        let mut pages = 0_u64;
        for heap in self.heaps.values_mut() {
            pages = pages.saturating_add(heap.private_page_count()?);
        }
        for tree in self.indexes.values() {
            pages = pages.saturating_add(tree.private_page_count()?);
        }
        // V2 uses 61 bytes of header/identity per 8192-byte FPI and 44
        // per control record. Round upward, retaining the codec as authority.
        Ok(pages.saturating_mul(8192 + 128).saturating_add(128))
    }

    #[cfg(test)]
    fn prepare_group_statement(
        &mut self,
        statement: Statement,
    ) -> Result<(PreparedCommit, QueryResult), PhobosError> {
        let value = self.begin_group_statement(statement)?;
        self.stage_group_statement(value)
    }

    fn stage_group_statement(
        &mut self,
        value: QueryResult,
    ) -> Result<(PreparedCommit, QueryResult), PhobosError> {
        let _durability = phobos_error::cancellation::suspend();
        let _prepare = phobos_observability::span("execution.group_prepare");
        // From here any error fences the domain. Some handles may already be
        // frozen or transferred; rollback cannot undo an appended COMMIT.
        self.fenced = true;
        let wal = self.wal_v2.as_mut().expect("V2 WAL");
        for (id, heap) in &mut self.heaps {
            heap.prepare_private_redo_based(
                FileId::Heap(*id),
                |page, bytes, base, allocated, phase| {
                    let action = if allocated {
                        PageAction::Initialize
                    } else {
                        PageAction::HeapUpdate
                    };
                    match phase {
                        phobos_storage::page_io::RedoPhase::Stamp => {
                            wal.stamp_next_page(FileId::Heap(*id), page, bytes)?;
                        }
                        phobos_storage::page_io::RedoPhase::Append => {
                            wal.append_prepared_page_with_base(
                                action,
                                FileId::Heap(*id),
                                page,
                                bytes,
                                base,
                            )?;
                        }
                    }
                    Ok(())
                },
            )?;
        }
        for (id, tree) in &mut self.indexes {
            tree.prepare_private_redo_based(
                FileId::Index(*id),
                |page, bytes, base, allocated, phase| {
                    let action = if allocated {
                        PageAction::Initialize
                    } else {
                        PageAction::Index
                    };
                    match phase {
                        phobos_storage::page_io::RedoPhase::Stamp => {
                            wal.stamp_next_page(FileId::Index(*id), page, bytes)?;
                        }
                        phobos_storage::page_io::RedoPhase::Append => {
                            wal.append_prepared_page_with_base(
                                action,
                                FileId::Index(*id),
                                page,
                                bytes,
                                base,
                            )?;
                        }
                    }
                    Ok(())
                },
            )?;
        }
        let ticket = wal.append_commit()?;
        for heap in self.heaps.values_mut() {
            heap.stage_private()?;
        }
        for tree in self.indexes.values_mut() {
            tree.stage_private()?;
        }
        let tx = self.private_txn.take().expect("prepared transaction");
        self.catalog.redirect_persistence(&self.data_dir)?;
        self.fenced = false;
        Ok((
            PreparedCommit {
                ticket,
                root: tx.temp_dir,
            },
            value,
        ))
    }

    fn publish_group(&mut self, pending: &mut Vec<PreparedCommit>) -> Result<(), PhobosError> {
        let _durability = phobos_error::cancellation::suspend();
        if pending.is_empty() {
            return Ok(());
        }
        self.ensure_available()?;
        let _publish = phobos_observability::span("execution.group_publish");
        self.fenced = true;
        let batch = std::mem::take(pending);
        let (tickets, roots): (Vec<_>, Vec<_>) = batch
            .into_iter()
            .map(|commit| (commit.ticket, commit.root))
            .unzip();
        group_crash("before_force");
        let receipts = self
            .wal_v2
            .as_mut()
            .expect("V2 WAL")
            .force_commits(&tickets)?;
        group_crash("after_force");
        if std::env::var("PHOBOS_CRASH_POINT").as_deref() == Ok("after_wal_commit") {
            std::process::abort();
        }
        phobos_observability::certification_crash("before_installation");
        let publication = phobos_observability::span("execution.synchronous_publication");
        for (receipt, root) in receipts.iter().zip(roots) {
            for heap in self.heaps.values_mut() {
                heap.install_pending(receipt)?;
            }
            group_crash("after_heap_install");
            for tree in self.indexes.values_mut() {
                tree.install_pending(receipt)?;
            }
            fs::remove_dir_all(root)?;
        }
        group_crash("after_install");
        drop(publication);
        if !self.in_transaction() {
            self.advance_checkpoint()?;
        }
        self.fenced = false;
        Ok(())
    }
}

fn group_crash(point: &str) {
    #[cfg(test)]
    if std::env::var("PHOBOS_GROUP_CRASH_POINT").as_deref() == Ok(point) {
        std::process::exit(86);
    }
    #[cfg(not(test))]
    let _ = point;
}

fn fail_pending_results(results: &mut [Result<QueryResult, PhobosError>], error: PhobosError) {
    for result in results.iter_mut().filter(|result| result.is_ok()) {
        *result = Err(error.clone());
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn oversized_successor_retains_its_private_state_across_predecessor_force() {
        let dir =
            std::env::temp_dir().join(format!("phobos-group-large-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, v TEXT)")
            .unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        let payload = "x".repeat(1000);
        let large = format!(
            "INSERT INTO t VALUES {}",
            (2..1502)
                .map(|id| format!("({id},'{payload}')"))
                .collect::<Vec<_>>()
                .join(",")
        );
        let result = db.execute_group(&[
            "INSERT INTO t VALUES (1,'first')",
            &large,
            "UPDATE t SET v='last' WHERE id=1501",
        ]);
        assert!(result.iter().all(Result::is_ok), "{result:?}");
        let expected = db.execute("SELECT id,v FROM t ORDER BY id").unwrap();
        if let QueryResult::Rows { rows, .. } = &expected {
            assert_eq!(rows.len(), 1501);
        } else {
            panic!("missing rows");
        }
        for tree in db.indexes.values_mut() {
            tree.validate().unwrap();
        }
        drop(db);
        let mut db = Database::open(&dir).unwrap();
        assert_eq!(
            db.execute("SELECT id,v FROM t ORDER BY id").unwrap(),
            expected
        );
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn pending_pages_stay_off_disk_and_failed_force_fences_domain() {
        let dir =
            std::env::temp_dir().join(format!("phobos-group-failure-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        let paths = [
            dir.join(FileId::Heap(1).name()),
            dir.join(FileId::Index(1).name()),
        ];
        let before: Vec<_> = paths.iter().map(|path| fs::read(path).unwrap()).collect();
        let mut pending = Vec::new();
        for id in [1, 2] {
            let (prepared, _) = db
                .prepare_group_statement(parse(&format!("INSERT INTO t VALUES ({id})")).unwrap())
                .unwrap();
            pending.push(prepared);
        }
        for (path, bytes) in paths.iter().zip(&before) {
            assert_eq!(fs::read(path).unwrap(), *bytes);
        }
        // Corrupt the physical suffix after all appends; forcing must detect it,
        // return no success, and prohibit reads/rollback/checkpoint on this owner.
        OpenOptions::new()
            .append(true)
            .open(dir.join("phobos.wal"))
            .unwrap()
            .write_all(b"x")
            .unwrap();
        assert!(db.publish_group(&mut pending).is_err());
        assert!(db.execute("SELECT * FROM t").is_err());
        assert!(db.execute("ROLLBACK").is_err());
        assert!(db.execute("CHECKPOINT").is_err());
        for (path, bytes) in paths.iter().zip(&before) {
            assert_eq!(fs::read(path).unwrap(), *bytes);
        }
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn group_crash_campaign_twenty_cycles() {
        if let Ok(dir) = std::env::var("PHOBOS_GROUP_CRASH_DIR") {
            let mut db = Database::open(dir).unwrap();
            let results = db.execute_group(&[
                "INSERT INTO t VALUES (1,10)",
                "UPDATE t SET v=11 WHERE id=1",
                "INSERT INTO t VALUES (2,20)",
            ]);
            assert!(results.iter().all(Result::is_ok));
            panic!("group crash hook was not reached");
        }
        for cycle in 0..20 {
            let point = [
                "before_force",
                "after_force",
                "after_heap_install",
                "after_install",
            ][cycle % 4];
            let dir =
                std::env::temp_dir().join(format!("phobos-group-crash-{}", unique_spill_suffix()));
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
                .unwrap();
            db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
            drop(db);
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "group_commit::tests::group_crash_campaign_twenty_cycles",
                    "--nocapture",
                ])
                .env("PHOBOS_GROUP_CRASH_DIR", &dir)
                .env("PHOBOS_GROUP_CRASH_POINT", point)
                .status()
                .unwrap();
            assert_eq!(status.code(), Some(86), "cycle {cycle} at {point}");
            for _ in 0..2 {
                let mut db = Database::open(&dir).unwrap();
                // Mode A: all complete records remain available in this
                // process-crash test, even before force. 0.2-E Mode E: the
                // unforced (never acknowledged) group is still in the writer's
                // memory at "before_force" and is lost as a whole.
                if point == "before_force"
                    && phobos_wal::v2::DurabilityMode::configured()
                        == phobos_wal::v2::DurabilityMode::WriteThrough
                {
                    assert_eq!(
                        db.execute("SELECT id,v FROM t ORDER BY id").unwrap(),
                        QueryResult::Rows {
                            columns: vec!["id".into(), "v".into()],
                            rows: vec![]
                        }
                    );
                    for tree in db.indexes.values_mut() {
                        tree.validate().unwrap();
                    }
                    continue;
                }
                assert_eq!(
                    db.execute("SELECT id,v FROM t ORDER BY id").unwrap(),
                    QueryResult::Rows {
                        columns: vec!["id".into(), "v".into()],
                        rows: vec![
                            Row::new(vec![Value::Int64(1), Value::Int64(11)]),
                            Row::new(vec![Value::Int64(2), Value::Int64(20)])
                        ]
                    }
                );
                for tree in db.indexes.values_mut() {
                    tree.validate().unwrap();
                }
            }
            fs::remove_dir_all(dir).unwrap();
        }
    }
    #[test]
    fn successors_use_pending_heap_index_and_rollback_to_predecessor() {
        let dir = std::env::temp_dir().join(format!("phobos-group-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
            .unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        let result = db.execute_group(&[
            "INSERT INTO t VALUES (1,10)",
            "INSERT INTO t VALUES (2,20),(1,99)",
            "INSERT INTO t VALUES (2,20)",
            "UPDATE t SET v=v+1 WHERE id=1",
            "DELETE FROM t WHERE id=2",
            "INSERT INTO t VALUES (2,30)",
        ]);
        assert_eq!(
            result.iter().filter(|result| result.is_ok()).count(),
            5,
            "{result:?}"
        );
        assert_eq!(
            result[1].as_ref().unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        let expected = db.execute("SELECT id,v FROM t ORDER BY id").unwrap();
        assert_eq!(
            expected,
            QueryResult::Rows {
                columns: vec!["id".into(), "v".into()],
                rows: vec![
                    Row::new(vec![Value::Int64(1), Value::Int64(11)]),
                    Row::new(vec![Value::Int64(2), Value::Int64(30)])
                ]
            }
        );
        for tree in db.indexes.values_mut() {
            tree.validate().unwrap();
        }
        drop(db);
        for _ in 0..2 {
            let mut db = Database::open(&dir).unwrap();
            assert_eq!(
                db.execute("SELECT id,v FROM t ORDER BY id").unwrap(),
                expected
            );
            for tree in db.indexes.values_mut() {
                tree.validate().unwrap();
            }
        }
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn group_crosses_heap_allocation_index_split_and_checkpoint_boundaries() {
        let dir =
            std::env::temp_dir().join(format!("phobos-group-split-{}", unique_spill_suffix()));
        let mut db = Database::open(&dir).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        for start in [0, 6400] {
            let queries: Vec<_> = (0..64)
                .map(|batch| {
                    format!(
                        "INSERT INTO t VALUES {}",
                        (0..100)
                            .map(|row| format!("({})", start + batch * 100 + row))
                            .collect::<Vec<_>>()
                            .join(",")
                    )
                })
                .collect();
            let result = db.execute_group(&queries.iter().map(String::as_str).collect::<Vec<_>>());
            assert!(result.iter().all(Result::is_ok), "{result:?}");
        }
        let expected = db.execute("SELECT id FROM t ORDER BY id").unwrap();
        if let QueryResult::Rows { rows, .. } = &expected {
            assert_eq!(rows.len(), 12800);
        } else {
            panic!("missing rows");
        }
        for tree in db.indexes.values_mut() {
            tree.validate().unwrap();
        }
        db.execute("CHECKPOINT").unwrap();
        drop(db);
        let mut db = Database::open(&dir).unwrap();
        assert_eq!(
            db.execute("SELECT id FROM t ORDER BY id").unwrap(),
            expected
        );
        drop(db);
        fs::remove_dir_all(dir).unwrap();
    }
}
