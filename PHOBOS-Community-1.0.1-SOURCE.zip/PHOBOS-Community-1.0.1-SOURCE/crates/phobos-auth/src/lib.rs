#![forbid(unsafe_code)]
//! Phase 7 authentication and coarse role authorization.
//!
//! Passwords are hashed with Argon2 through the maintained `argon2` crate. The file format is
//! intentionally simple and versioned; it is an alpha control-plane format, not a SQL catalog.

use argon2::{Argon2, PasswordHash, PasswordHasher, PasswordVerifier, password_hash::SaltString};
use phobos_error::{ErrorCode, PhobosError};
use rand_core::OsRng;
use std::{
    collections::BTreeMap,
    fs::{self, OpenOptions},
    io::Write,
    path::{Path, PathBuf},
};

const HEADER: &str = "PHOBOS-AUTH-1";

/// Coarse Phase 7 roles. Finer database/schema/table grants remain future hardening work.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Role {
    Reader,
    Writer,
    Admin,
}

impl Role {
    #[must_use]
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Reader => "reader",
            Self::Writer => "writer",
            Self::Admin => "admin",
        }
    }

    pub fn parse(value: &str) -> Result<Self, PhobosError> {
        match value.to_ascii_lowercase().as_str() {
            "reader" => Ok(Self::Reader),
            "writer" => Ok(Self::Writer),
            "admin" => Ok(Self::Admin),
            _ => Err(PhobosError::new(ErrorCode::Semantic, "unknown role")),
        }
    }

    #[must_use]
    pub fn allows(self, action: Action) -> bool {
        match self {
            Self::Admin => true,
            Self::Writer => matches!(action, Action::Read | Action::Write),
            Self::Reader => action == Action::Read,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    Read,
    Write,
    Ddl,
    Admin,
}

#[derive(Debug, Clone)]
struct UserRecord {
    username: String,
    role: Role,
    password_hash: String,
}

/// Persistent password/role store.
#[derive(Debug)]
pub struct AuthStore {
    path: PathBuf,
    users: BTreeMap<String, UserRecord>,
}

impl AuthStore {
    pub fn open(path: impl AsRef<Path>) -> Result<Self, PhobosError> {
        let path = path.as_ref().to_path_buf();
        if !path.exists() {
            return Ok(Self {
                path,
                users: BTreeMap::new(),
            });
        }
        let text = fs::read_to_string(&path)?;
        let mut lines = text.lines();
        if lines.next() != Some(HEADER) {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "invalid auth file header",
            ));
        }
        let mut users = BTreeMap::new();
        for line in lines {
            if line.trim().is_empty() {
                continue;
            }
            let mut parts = line.splitn(3, '\t');
            let username = parts.next().unwrap_or_default();
            let role = parts.next().unwrap_or_default();
            let password_hash = parts.next().unwrap_or_default();
            validate_username(username)?;
            let role = Role::parse(role)?;
            PasswordHash::new(password_hash).map_err(|_| {
                PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "invalid password hash in auth file",
                )
            })?;
            let key = username.to_ascii_lowercase();
            if users.contains_key(&key) {
                return Err(PhobosError::new(
                    ErrorCode::InvalidCatalog,
                    "duplicate auth user",
                ));
            }
            users.insert(
                key,
                UserRecord {
                    username: username.to_string(),
                    role,
                    password_hash: password_hash.to_string(),
                },
            );
        }
        Ok(Self { path, users })
    }

    pub fn upsert_user(
        &mut self,
        username: &str,
        password: &str,
        role: Role,
    ) -> Result<(), PhobosError> {
        validate_username(username)?;
        if password.len() < 10 {
            return Err(PhobosError::new(
                ErrorCode::ConstraintViolation,
                "password must contain at least 10 characters",
            ));
        }
        let salt = SaltString::generate(&mut OsRng);
        let password_hash = Argon2::default()
            .hash_password(password.as_bytes(), &salt)
            .map_err(|_| PhobosError::new(ErrorCode::Authentication, "password hashing failed"))?
            .to_string();
        self.users.insert(
            username.to_ascii_lowercase(),
            UserRecord {
                username: username.to_string(),
                role,
                password_hash,
            },
        );
        self.persist()
    }

    pub fn remove_user(&mut self, username: &str) -> Result<bool, PhobosError> {
        let removed = self.users.remove(&username.to_ascii_lowercase()).is_some();
        if removed {
            self.persist()?;
        }
        Ok(removed)
    }

    pub fn authenticate(&self, username: &str, password: &str) -> Result<Role, PhobosError> {
        let Some(record) = self.users.get(&username.to_ascii_lowercase()) else {
            return Err(authentication_failed());
        };
        let parsed =
            PasswordHash::new(&record.password_hash).map_err(|_| authentication_failed())?;
        Argon2::default()
            .verify_password(password.as_bytes(), &parsed)
            .map_err(|_| authentication_failed())?;
        Ok(record.role)
    }

    /// Trusted external authentication (currently mTLS) resolves only an
    /// existing principal; it cannot create users or bypass role metadata.
    pub fn role_for_user(&self, username: &str) -> Result<Role, PhobosError> {
        self.users
            .get(&username.to_ascii_lowercase())
            .map(|record| record.role)
            .ok_or_else(authentication_failed)
    }

    #[must_use]
    pub fn user_count(&self) -> usize {
        self.users.len()
    }

    #[must_use]
    pub fn list_users(&self) -> Vec<(String, Role)> {
        self.users
            .values()
            .map(|u| (u.username.clone(), u.role))
            .collect()
    }

    fn persist(&self) -> Result<(), PhobosError> {
        if let Some(parent) = self.path.parent() {
            fs::create_dir_all(parent)?;
        }
        let temp = self.path.with_extension("tmp");
        let mut file = OpenOptions::new()
            .create(true)
            .truncate(true)
            .write(true)
            .open(&temp)?;
        writeln!(file, "{HEADER}")?;
        for record in self.users.values() {
            writeln!(
                file,
                "{}\t{}\t{}",
                record.username,
                record.role.as_str(),
                record.password_hash
            )?;
        }
        file.sync_all()?;
        drop(file);
        if self.path.exists() {
            fs::remove_file(&self.path)?;
        }
        fs::rename(temp, &self.path)?;
        Ok(())
    }
}

/// Coarse SQL authorization classification for the Phase 7 server boundary.
#[must_use]
pub fn classify_sql(sql: &str) -> Action {
    let keyword = sql
        .split_whitespace()
        .next()
        .unwrap_or("")
        .to_ascii_uppercase();
    match keyword.as_str() {
        "SELECT" | "EXPLAIN" | "SHOW" | "WITH" => Action::Read,
        "INSERT" | "UPDATE" | "DELETE" | "BEGIN" | "COMMIT" | "ROLLBACK" => Action::Write,
        "CREATE" | "DROP" | "ALTER" => Action::Ddl,
        "ANALYZE" | "CHECKPOINT" => Action::Admin,
        _ => Action::Admin,
    }
}

fn validate_username(username: &str) -> Result<(), PhobosError> {
    if username.is_empty()
        || username.len() > 63
        || !username
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
    {
        return Err(PhobosError::new(ErrorCode::Semantic, "invalid username"));
    }
    Ok(())
}

fn authentication_failed() -> PhobosError {
    PhobosError::new(ErrorCode::Authentication, "authentication failed")
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp() -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-auth-{n}.txt"))
    }

    #[test]
    fn password_hashes_roles_and_restart() {
        let path = temp();
        let mut store = AuthStore::open(&path).unwrap();
        store
            .upsert_user("alice", "correct horse battery", Role::Writer)
            .unwrap();
        assert_eq!(
            store
                .authenticate("alice", "correct horse battery")
                .unwrap(),
            Role::Writer
        );
        assert_eq!(
            store.authenticate("alice", "wrong").unwrap_err().code,
            ErrorCode::Authentication
        );
        drop(store);
        let store = AuthStore::open(&path).unwrap();
        assert_eq!(
            store
                .authenticate("ALICE", "correct horse battery")
                .unwrap(),
            Role::Writer
        );
        let _ = fs::remove_file(path);
    }

    #[test]
    fn reader_writer_admin_capabilities_are_explicit() {
        assert!(Role::Reader.allows(Action::Read));
        assert!(!Role::Reader.allows(Action::Write));
        assert!(Role::Writer.allows(Action::Read));
        assert!(Role::Writer.allows(Action::Write));
        assert!(!Role::Writer.allows(Action::Ddl));
        assert!(Role::Admin.allows(Action::Read));
        assert!(Role::Admin.allows(Action::Write));
        assert!(Role::Admin.allows(Action::Ddl));
        assert!(Role::Admin.allows(Action::Admin));
    }
}
