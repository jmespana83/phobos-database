//! Startup-only runtime settings. JSON numbers use the units in their field names.
use phobos_error::{ErrorCode, PhobosError};
use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeMap,
    path::{Path, PathBuf},
    time::{Duration, Instant},
};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LogFormat {
    #[default]
    Text,
    Json,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct RuntimeConfig {
    pub max_connections: u64,
    pub worker_threads: usize,
    /// Maximum query-local workers for eligible read-only sequential scans.
    pub parallel_scan_workers: usize,
    /// Minimum aggregate heap pages before parallel partition scan fan-out.
    pub parallel_scan_min_pages: usize,
    /// Additional caps by coarse role name (`reader`, `writer`, `admin`).
    pub role_connection_limits: BTreeMap<String, u64>,
    pub slow_query_ms: u64,
    pub log_format: LogFormat,
    pub mtls_required: bool,
    pub client_ca_path: Option<PathBuf>,
    /// Lowercase trusted-certificate FNV-1a fingerprint to existing username.
    pub mtls_identities: BTreeMap<String, String>,
    pub audit_enabled: bool,
    pub audit_log_path: Option<PathBuf>,
    pub max_result_bytes: usize,
    pub statement_timeout_ms: u64,
    pub idle_timeout_ms: u64,
    pub lock_timeout_ms: u64,
    pub status_growth_extent_records: u64,
    pub write_spill_threshold_bytes: usize,
    pub write_spill_scratch_quota_bytes: u64,
    /// Approximate per-query operator memory budget. Operators account owned
    /// row/key bytes and spill before retaining more than this amount.
    pub query_memory_bytes: usize,
    pub bulk_scratch_quota_bytes: u64,
    pub bulk_scratch_directories: Vec<PathBuf>,
    pub bulk_index_build_workers: usize,
    pub merge_fan_in: usize,
    pub page_cache_bytes: usize,
    /// 0.1.9-B1: cache-resident settled-visibility hints (optimization only).
    pub hint_bits_enabled: bool,
}

impl Default for RuntimeConfig {
    fn default() -> Self {
        Self {
            max_connections: 64,
            worker_threads: std::thread::available_parallelism()
                .map_or(4, usize::from)
                .clamp(1, 16),
            parallel_scan_workers: 4,
            parallel_scan_min_pages: 256,
            role_connection_limits: BTreeMap::new(),
            slow_query_ms: 1000,
            log_format: LogFormat::Text,
            mtls_required: false,
            client_ca_path: None,
            mtls_identities: BTreeMap::new(),
            audit_enabled: false,
            audit_log_path: None,
            max_result_bytes: 1024 * 1024,
            statement_timeout_ms: 30 * 60 * 1000,
            idle_timeout_ms: 15 * 60 * 1000,
            lock_timeout_ms: 2000,
            status_growth_extent_records: 1 << 20,
            write_spill_threshold_bytes: 64 * 1024 * 1024,
            write_spill_scratch_quota_bytes: 2 * 1024 * 1024 * 1024,
            query_memory_bytes: 64 * 1024 * 1024,
            bulk_scratch_quota_bytes: 8 * 1024 * 1024 * 1024,
            bulk_scratch_directories: Vec::new(),
            bulk_index_build_workers: 4,
            merge_fan_in: 512,
            page_cache_bytes: 256 * 1024 * 1024,
            hint_bits_enabled: true,
        }
    }
}

fn invalid(message: impl Into<String>) -> PhobosError {
    PhobosError::new(
        ErrorCode::ResourceLimit,
        format!("configuration: {}", message.into()),
    )
}

impl RuntimeConfig {
    /// No implicit search path. An explicitly named missing file is an error.
    pub fn load(path: Option<&Path>) -> Result<Self, PhobosError> {
        let mut defaults = Self::default();
        // An explicitly supplied JSON value wins over the startup environment.
        if let Some(value) = std::env::var_os("PHOBOS_PAGE_CACHE_BYTES") {
            defaults.page_cache_bytes = value
                .to_str()
                .and_then(|v| v.parse().ok())
                .ok_or_else(|| invalid("PHOBOS_PAGE_CACHE_BYTES must be a positive byte count"))?;
        } else if let Some(value) = std::env::var_os("PHOBOS_DIRTY_HIGH_WATER_PAGES") {
            let pages: usize = value.to_str().and_then(|v| v.parse().ok()).ok_or_else(|| {
                invalid("PHOBOS_DIRTY_HIGH_WATER_PAGES must be a positive page count")
            })?;
            defaults.page_cache_bytes = pages
                .checked_mul(8192)
                .ok_or_else(|| invalid("legacy cache page count is too large"))?;
        }
        let config = match path {
            None => defaults,
            Some(path) => {
                let text = std::fs::read_to_string(path)
                    .map_err(|error| invalid(format!("{}: {error}", path.display())))?;
                Self::parse_with_defaults(&text, defaults)
                    .map_err(|error| invalid(format!("{}: {error}", path.display())))?
            }
        };
        config.validate()?;
        Ok(config)
    }

    pub fn from_json(text: &str) -> Result<Self, PhobosError> {
        Self::parse_with_defaults(text, Self::default())
    }

    fn parse_with_defaults(text: &str, defaults: Self) -> Result<Self, PhobosError> {
        // Deserialize first: rejects duplicates, unknown fields and wrong numeric types.
        let mut config: Self = serde_json::from_str(text).map_err(|e| invalid(e.to_string()))?;
        let fields: serde_json::Map<String, serde_json::Value> =
            serde_json::from_str(text).map_err(|e| invalid(e.to_string()))?;
        if !fields.contains_key("page_cache_bytes") {
            config.page_cache_bytes = defaults.page_cache_bytes;
        }
        config.validate()?;
        Ok(config)
    }

    pub fn validate(&self) -> Result<(), PhobosError> {
        if !(1..=1024).contains(&self.max_connections) {
            return Err(invalid(
                "max_connections must be 1..=1024 (session capacity)",
            ));
        }
        if !(1..=64).contains(&self.worker_threads) {
            return Err(invalid("worker_threads must be 1..=64"));
        }
        if !(1..=64).contains(&self.parallel_scan_workers) {
            return Err(invalid("parallel_scan_workers must be 1..=64"));
        }
        if self.parallel_scan_min_pages == 0 {
            return Err(invalid("parallel_scan_min_pages must be positive"));
        }
        for (role, limit) in &self.role_connection_limits {
            if !matches!(role.as_str(), "reader" | "writer" | "admin") {
                return Err(invalid(format!(
                    "unknown role_connection_limits role: {role}"
                )));
            }
            if *limit == 0 || *limit > self.max_connections {
                return Err(invalid(format!(
                    "role_connection_limits.{role} must be 1..=max_connections"
                )));
            }
        }
        if self.mtls_required && self.client_ca_path.is_none() {
            return Err(invalid("mtls_required requires client_ca_path"));
        }
        if self.client_ca_path.is_none() && !self.mtls_identities.is_empty() {
            return Err(invalid("mtls_identities requires client_ca_path"));
        }
        for (fingerprint, username) in &self.mtls_identities {
            if fingerprint.len() != 16 || !fingerprint.bytes().all(|byte| byte.is_ascii_hexdigit())
            {
                return Err(invalid(
                    "mtls_identities keys must be 16 hexadecimal FNV-1a fingerprints",
                ));
            }
            if username.is_empty() || username.len() > 63 {
                return Err(invalid("mtls_identities usernames must be 1..=63 bytes"));
            }
        }
        if self.audit_enabled && self.audit_log_path.is_none() {
            return Err(invalid("audit_enabled requires audit_log_path"));
        }
        for (name, ms) in [
            ("statement_timeout_ms", self.statement_timeout_ms),
            ("idle_timeout_ms", self.idle_timeout_ms),
            ("lock_timeout_ms", self.lock_timeout_ms),
        ] {
            if ms == 0
                || Instant::now()
                    .checked_add(Duration::from_millis(ms))
                    .is_none()
            {
                return Err(invalid(format!(
                    "{name} must be positive and fit a monotonic deadline"
                )));
            }
        }
        for (name, count, width) in [
            ("max_result_bytes", self.max_result_bytes, 1usize),
            (
                "write_spill_threshold_bytes",
                self.write_spill_threshold_bytes,
                1,
            ),
            ("query_memory_bytes", self.query_memory_bytes, 1),
            ("page_cache_bytes", self.page_cache_bytes, 1),
        ] {
            if count == 0
                || count
                    .checked_mul(width)
                    .is_none_or(|size| size > isize::MAX as usize)
            {
                return Err(invalid(format!(
                    "{name} must be positive with a representable byte size"
                )));
            }
        }
        if self.page_cache_bytes < 8192 {
            return Err(invalid(
                "page_cache_bytes must be at least one 8192-byte page",
            ));
        }
        for (name, bytes) in [
            (
                "write_spill_scratch_quota_bytes",
                self.write_spill_scratch_quota_bytes,
            ),
            ("bulk_scratch_quota_bytes", self.bulk_scratch_quota_bytes),
        ] {
            if bytes == 0 || bytes > i64::MAX as u64 {
                return Err(invalid(format!("{name} must be 1..=i64::MAX bytes")));
            }
        }
        if self.status_growth_extent_records == 0
            || self
                .status_growth_extent_records
                .checked_mul(32)
                .and_then(|n| n.checked_add(32))
                .is_none_or(|n| n > i64::MAX as u64)
        {
            return Err(invalid(
                "status_growth_extent_records must fit positive status-file offsets",
            ));
        }
        if !(2..=512).contains(&self.merge_fan_in) {
            return Err(invalid(
                "merge_fan_in must be 2..=512 (8 MiB read-buffer budget)",
            ));
        }
        if !(1..=16).contains(&self.bulk_index_build_workers) {
            return Err(invalid("bulk_index_build_workers must be 1..=16"));
        }
        if self
            .bulk_scratch_directories
            .iter()
            .any(|path| path.as_os_str().is_empty())
        {
            return Err(invalid(
                "bulk_scratch_directories must not contain empty paths",
            ));
        }
        Ok(())
    }

    pub fn banner(&self) -> String {
        // Scratch paths may be shown; configuration contains no credentials.
        let json = serde_json::to_string_pretty(self).expect("numeric configuration serializes");
        format!("PHOBOS effective settings (ms, bytes, rows, records or flags as named):\n{json}")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn defaults_and_partial_config() {
        assert_eq!(
            RuntimeConfig::from_json("{}").unwrap(),
            RuntimeConfig::default()
        );
        let config =
            RuntimeConfig::from_json(r#"{"max_connections":17,"query_memory_bytes":43000}"#)
                .unwrap();
        assert_eq!(
            config,
            RuntimeConfig {
                max_connections: 17,
                query_memory_bytes: 43000,
                ..Default::default()
            }
        );
        let loaded = RuntimeConfig::load(None).unwrap();
        assert_eq!(loaded.statement_timeout_ms, 1_800_000);
        assert_eq!(loaded.write_spill_threshold_bytes, 64 * 1024 * 1024);
    }
    #[test]
    fn invalid_json_fields_sizes_and_timeouts() {
        for input in [
            "{",
            "[]",
            "null",
            r#"{"unknown":1}"#,
            r#"{"max_connections":0}"#,
            r#"{"max_connections":1025}"#,
            r#"{"idle_timeout_ms":-1}"#,
            r#"{"statement_timeout_ms":0}"#,
            r#"{"query_memory_bytes":1.5}"#,
            r#"{"merge_fan_in":513}"#,
            r#"{"merge_fan_in":1}"#,
            r#"{"page_cache_bytes":18446744073709551615}"#,
            r#"{"page_cache_bytes":8191}"#,
            r#"{"bulk_index_build_workers":0}"#,
            r#"{"worker_threads":0}"#,
            r#"{"worker_threads":65}"#,
            r#"{"log_format":"xml"}"#,
            r#"{"max_connections":4,"role_connection_limits":{"reader":5}}"#,
            r#"{"role_connection_limits":{"unknown":1}}"#,
            r#"{"mtls_required":true}"#,
            r#"{"mtls_identities":{"not-a-fingerprint":"alice"}}"#,
            r#"{"client_ca_path":"ca.pem","mtls_identities":{"1234":"alice"}}"#,
            r#"{"audit_enabled":true}"#,
            r#"{"write_spill_scratch_quota_bytes":0}"#,
            r#"{"status_growth_extent_records":18446744073709551615}"#,
            r#"{"max_connections":1,"max_connections":2}"#,
        ] {
            assert!(RuntimeConfig::from_json(input).is_err(), "{input}");
        }
        assert!(
            RuntimeConfig::load(Some(Path::new("/missing-phobos-a5-config/config.json"))).is_err()
        );
    }
    #[test]
    fn resolved_banner_and_complete_round_trip() {
        let config = RuntimeConfig {
            max_connections: 7,
            worker_threads: 3,
            slow_query_ms: 0,
            log_format: LogFormat::Json,
            idle_timeout_ms: 1234,
            ..Default::default()
        };
        let text = serde_json::to_string(&config).unwrap();
        assert_eq!(RuntimeConfig::from_json(&text).unwrap(), config);
        let banner = config.banner();
        assert!(banner.contains("\"max_connections\": 7"));
        assert!(banner.contains("\"worker_threads\": 3"));
        assert!(banner.contains("\"log_format\": \"json\""));
        assert!(banner.contains("\"idle_timeout_ms\": 1234"));
        assert!(banner.contains("\"merge_fan_in\": 512"));
    }
}
