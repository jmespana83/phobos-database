#![forbid(unsafe_code)]
//! Phase 7 operational counters exposed through a small snapshot API.

use std::sync::atomic::{AtomicU64, Ordering};

#[cfg(debug_assertions)]
thread_local! {
    static STRUCTURAL_DEPTH: std::cell::Cell<u32> = const { std::cell::Cell::new(0) };
}
/// Debug-only ordering proof for index publication/fair traversal protection.
/// The scope is thread-bound and must end before status lookup or result delivery.
pub struct StructuralScope {
    _thread: std::marker::PhantomData<std::rc::Rc<()>>,
}
pub fn structural_scope() -> StructuralScope {
    #[cfg(debug_assertions)]
    STRUCTURAL_DEPTH.with(|depth| depth.set(depth.get().checked_add(1).expect("structural depth")));
    StructuralScope {
        _thread: std::marker::PhantomData,
    }
}
impl Drop for StructuralScope {
    fn drop(&mut self) {
        #[cfg(debug_assertions)]
        STRUCTURAL_DEPTH
            .with(|depth| depth.set(depth.get().checked_sub(1).expect("structural scope")));
    }
}
pub fn assert_no_structural_scope() {
    #[cfg(debug_assertions)]
    STRUCTURAL_DEPTH.with(|depth| {
        assert_eq!(
            depth.get(),
            0,
            "transaction status lookup under structural protection"
        )
    });
}

#[cfg(feature = "certification")]
static CRASH_ARMED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// Arm an isolated certification child after it has reported earlier commits.
/// Only used when PHOBOS_BETA_ARMED_ONLY=1; ordinary builds contain no state.
pub fn arm_certification_crashes() {
    #[cfg(feature = "certification")]
    CRASH_ARMED.store(true, Ordering::Release);
}

/// Process-crash injection compiled out of ordinary release binaries.
#[inline]
pub fn certification_crash(point: &str) {
    #[cfg(feature = "certification")]
    if certification_requested(point) {
        eprintln!("BETA_CRASH_REACHED {point}");
        std::process::abort();
    }
    #[cfg(not(feature = "certification"))]
    let _ = point;
}

/// Select a diagnostic-only physical write boundary. Constant false in normal
/// builds, so partial writes and extra synchronization cannot enter production.
#[inline]
#[must_use]
pub fn certification_requested(point: &str) -> bool {
    #[cfg(feature = "certification")]
    {
        (std::env::var("PHOBOS_BETA_ARMED_ONLY").as_deref() != Ok("1")
            || CRASH_ARMED.load(Ordering::Acquire))
            && std::env::var("PHOBOS_BETA_CRASH_POINT").as_deref() == Ok(point)
    }
    #[cfg(not(feature = "certification"))]
    {
        let _ = point;
        false
    }
}

/// Inclusive wall-time instrumentation, compiled away unless `profiling` is enabled.
/// Instrumented results must never be mixed with uninstrumented benchmark timings.
///
/// 0.2-H: in every build, a span whose name is one of the slow-request trace
/// phases also feeds the per-thread request trace — only while
/// `PHOBOS_SLOW_REQUEST_US` is set (otherwise one cached flag check).
#[inline]
pub fn span(name: &'static str) -> Span {
    let trace = if trace::enabled() {
        trace::phase(name).map(|phase| (phase, std::time::Instant::now()))
    } else {
        None
    };
    #[cfg(feature = "profiling")]
    {
        Span {
            name,
            start: std::time::Instant::now(),
            trace,
        }
    }
    #[cfg(not(feature = "profiling"))]
    {
        let _ = name;
        Span { trace }
    }
}

pub struct Span {
    #[cfg(feature = "profiling")]
    name: &'static str,
    #[cfg(feature = "profiling")]
    start: std::time::Instant,
    trace: Option<(usize, std::time::Instant)>,
}

#[cfg(feature = "profiling")]
type ProfileMap = std::collections::BTreeMap<&'static str, ProfileValue>;
#[cfg(feature = "profiling")]
#[derive(Default)]
struct ProfileValue {
    calls: u64,
    ns: u128,
    maximum_ns: u128,
    histogram: [u64; 32],
}
#[cfg(feature = "profiling")]
static PROFILE: std::sync::Mutex<ProfileMap> =
    std::sync::Mutex::new(std::collections::BTreeMap::new());

impl Drop for Span {
    fn drop(&mut self) {
        if let Some((phase, start)) = self.trace {
            trace::add(phase, start.elapsed().as_nanos() as u64);
        }
        #[cfg(feature = "profiling")]
        {
            let elapsed = self.start.elapsed().as_nanos();
            if let Ok(mut profile) = PROFILE.lock() {
                if profile.len() < 512 || profile.contains_key(self.name) {
                    let value = profile.entry(self.name).or_default();
                    value.calls += 1;
                    value.ns += elapsed;
                    value.maximum_ns = value.maximum_ns.max(elapsed);
                    let bucket = (128 - elapsed.saturating_sub(1).leading_zeros()).min(31) as usize;
                    value.histogram[bucket] += 1;
                }
            }
        }
    }
}

/// Record an event count, e.g. cache hits/misses or actual WAL bytes written.
#[inline]
pub fn event(name: &'static str, count: u64) {
    #[cfg(feature = "profiling")]
    if let Ok(mut profile) = PROFILE.lock() {
        if profile.len() < 512 || profile.contains_key(name) {
            profile.entry(name).or_default().calls += count;
            if LIFECYCLE_PROFILE.with(std::cell::Cell::get) {
                let lifecycle = match name {
                    "wal.bytes" => Some("reclaim.lifecycle_wal_bytes"),
                    "page.checksums" => Some("reclaim.checksums"),
                    "private.installed_pages" => Some("reclaim.heap_pages_installed"),
                    "page_cache.dirty_hits" => Some("reclaim.cache_dirty_hits"),
                    "page_cache.clean_hits" => Some("reclaim.cache_clean_hits"),
                    "page_cache.misses" => Some("reclaim.cache_misses"),
                    _ => None,
                };
                if let Some(name) = lifecycle {
                    profile.entry(name).or_default().calls += count;
                }
            }
        }
    }
    #[cfg(not(feature = "profiling"))]
    let _ = (name, count);
}

/// Avoid diagnostic page copies in ordinary builds.
pub const fn profiling_enabled() -> bool {
    cfg!(feature = "profiling")
}

#[cfg(feature = "profiling")]
thread_local! {
    static LIFECYCLE_PROFILE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
pub struct LifecycleProfile {
    #[cfg(feature = "profiling")]
    previous: bool,
    _thread: std::marker::PhantomData<std::rc::Rc<()>>,
}
pub fn lifecycle_profile() -> LifecycleProfile {
    LifecycleProfile {
        #[cfg(feature = "profiling")]
        previous: LIFECYCLE_PROFILE.with(|active| active.replace(true)),
        _thread: std::marker::PhantomData,
    }
}
impl Drop for LifecycleProfile {
    fn drop(&mut self) {
        #[cfg(feature = "profiling")]
        LIFECYCLE_PROFILE.with(|active| active.set(self.previous));
    }
}

pub fn write_profile(path: &std::path::Path) -> std::io::Result<()> {
    use std::io::Write;
    let mut file = std::fs::File::create_new(path)?;
    writeln!(
        file,
        "span,calls_or_units,inclusive_wall_ns,maximum_ns,histogram_pow2_ns"
    )?;
    #[cfg(feature = "profiling")]
    {
        let profile = PROFILE
            .lock()
            .map_err(|_| std::io::Error::other("profile poisoned"))?;
        for (name, value) in profile.iter() {
            let histogram = value
                .histogram
                .iter()
                .map(u64::to_string)
                .collect::<Vec<_>>()
                .join(";");
            writeln!(
                file,
                "{name},{},{},{},{histogram}",
                value.calls, value.ns, value.maximum_ns
            )?;
        }
    }
    Ok(())
}

#[derive(Debug, Default)]
pub struct Metrics {
    sessions_opened: AtomicU64,
    active_sessions: AtomicU64,
    active_connections: AtomicU64,
    queries_total: AtomicU64,
    query_errors: AtomicU64,
    auth_failures: AtomicU64,
    lock_timeouts: AtomicU64,
    bytes_out: AtomicU64,
    active_workers: AtomicU64,
    peak_active_workers: AtomicU64,
    committed_transactions: AtomicU64,
    aborted_transactions: AtomicU64,
    cancelled_statements: AtomicU64,
    slow_queries: AtomicU64,
    prepared_statements: AtomicU64,
    prepared_executions: AtomicU64,
    prepared_replans: AtomicU64,
    rejected_global_connections: AtomicU64,
    rejected_role_connections: AtomicU64,
}

impl Metrics {
    pub fn session_opened(&self) {
        self.sessions_opened.fetch_add(1, Ordering::Relaxed);
        self.active_sessions.fetch_add(1, Ordering::Relaxed);
    }
    pub fn session_closed(&self) {
        self.active_sessions.fetch_sub(1, Ordering::Relaxed);
    }
    pub fn connection_accepted(&self) {
        self.active_connections.fetch_add(1, Ordering::Relaxed);
    }
    pub fn connection_closed(&self) {
        self.active_connections.fetch_sub(1, Ordering::Relaxed);
    }
    pub fn query_started(&self) {
        self.queries_total.fetch_add(1, Ordering::Relaxed);
    }
    pub fn query_error(&self) {
        self.query_errors.fetch_add(1, Ordering::Relaxed);
    }
    pub fn auth_failure(&self) {
        self.auth_failures.fetch_add(1, Ordering::Relaxed);
    }
    pub fn lock_timeout(&self) {
        self.lock_timeouts.fetch_add(1, Ordering::Relaxed);
    }
    pub fn add_bytes_out(&self, bytes: usize) {
        self.bytes_out.fetch_add(bytes as u64, Ordering::Relaxed);
    }
    pub fn worker_started(&self) {
        let active = self.active_workers.fetch_add(1, Ordering::Relaxed) + 1;
        self.peak_active_workers
            .fetch_max(active, Ordering::Relaxed);
    }
    pub fn worker_stopped(&self) {
        self.active_workers.fetch_sub(1, Ordering::Relaxed);
    }
    pub fn transaction_committed(&self) {
        self.committed_transactions.fetch_add(1, Ordering::Relaxed);
    }
    pub fn transaction_aborted(&self) {
        self.aborted_transactions.fetch_add(1, Ordering::Relaxed);
    }
    pub fn statement_cancelled(&self) {
        self.cancelled_statements.fetch_add(1, Ordering::Relaxed);
    }
    pub fn slow_query(&self) {
        self.slow_queries.fetch_add(1, Ordering::Relaxed);
    }
    pub fn prepared(&self) {
        self.prepared_statements.fetch_add(1, Ordering::Relaxed);
    }
    pub fn prepared_executed(&self) {
        self.prepared_executions.fetch_add(1, Ordering::Relaxed);
    }
    pub fn prepared_replanned(&self) {
        self.prepared_replans.fetch_add(1, Ordering::Relaxed);
    }
    pub fn global_connection_rejected(&self) {
        self.rejected_global_connections
            .fetch_add(1, Ordering::Relaxed);
    }
    pub fn role_connection_rejected(&self) {
        self.rejected_role_connections
            .fetch_add(1, Ordering::Relaxed);
    }

    #[must_use]
    pub fn snapshot(&self) -> MetricsSnapshot {
        MetricsSnapshot {
            sessions_opened: self.sessions_opened.load(Ordering::Relaxed),
            active_sessions: self.active_sessions.load(Ordering::Relaxed),
            active_connections: self.active_connections.load(Ordering::Relaxed),
            queries_total: self.queries_total.load(Ordering::Relaxed),
            query_errors: self.query_errors.load(Ordering::Relaxed),
            auth_failures: self.auth_failures.load(Ordering::Relaxed),
            lock_timeouts: self.lock_timeouts.load(Ordering::Relaxed),
            bytes_out: self.bytes_out.load(Ordering::Relaxed),
            active_workers: self.active_workers.load(Ordering::Relaxed),
            peak_active_workers: self.peak_active_workers.load(Ordering::Relaxed),
            committed_transactions: self.committed_transactions.load(Ordering::Relaxed),
            aborted_transactions: self.aborted_transactions.load(Ordering::Relaxed),
            cancelled_statements: self.cancelled_statements.load(Ordering::Relaxed),
            slow_queries: self.slow_queries.load(Ordering::Relaxed),
            prepared_statements: self.prepared_statements.load(Ordering::Relaxed),
            prepared_executions: self.prepared_executions.load(Ordering::Relaxed),
            prepared_replans: self.prepared_replans.load(Ordering::Relaxed),
            rejected_global_connections: self.rejected_global_connections.load(Ordering::Relaxed),
            rejected_role_connections: self.rejected_role_connections.load(Ordering::Relaxed),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MetricsSnapshot {
    pub sessions_opened: u64,
    pub active_sessions: u64,
    pub active_connections: u64,
    pub queries_total: u64,
    pub query_errors: u64,
    pub auth_failures: u64,
    pub lock_timeouts: u64,
    pub bytes_out: u64,
    pub active_workers: u64,
    pub peak_active_workers: u64,
    pub committed_transactions: u64,
    pub aborted_transactions: u64,
    pub cancelled_statements: u64,
    pub slow_queries: u64,
    pub prepared_statements: u64,
    pub prepared_executions: u64,
    pub prepared_replans: u64,
    pub rejected_global_connections: u64,
    pub rejected_role_connections: u64,
}

impl MetricsSnapshot {
    #[must_use]
    pub fn to_text(self) -> String {
        format!(
            "sessions_opened\t{}\nactive_sessions\t{}\nactive_connections\t{}\nqueries_total\t{}\nquery_errors\t{}\nauth_failures\t{}\nlock_timeouts\t{}\nbytes_out\t{}\nactive_workers\t{}\npeak_active_workers\t{}\ncommitted_transactions\t{}\naborted_transactions\t{}\ncancelled_statements\t{}\nslow_queries\t{}\nprepared_statements\t{}\nprepared_executions\t{}\nprepared_replans\t{}\nrejected_global_connections\t{}\nrejected_role_connections\t{}\n",
            self.sessions_opened,
            self.active_sessions,
            self.active_connections,
            self.queries_total,
            self.query_errors,
            self.auth_failures,
            self.lock_timeouts,
            self.bytes_out,
            self.active_workers,
            self.peak_active_workers,
            self.committed_transactions,
            self.aborted_transactions,
            self.cancelled_statements,
            self.slow_queries,
            self.prepared_statements,
            self.prepared_executions,
            self.prepared_replans,
            self.rejected_global_connections,
            self.rejected_role_connections,
        )
    }

    #[must_use]
    pub fn rows(self) -> Vec<(&'static str, u64, &'static str)> {
        vec![
            ("sessions_opened", self.sessions_opened, "counter"),
            ("active_connections", self.active_connections, "gauge"),
            ("queries_total", self.queries_total, "counter"),
            ("query_errors", self.query_errors, "counter"),
            ("auth_failures", self.auth_failures, "counter"),
            ("lock_timeouts", self.lock_timeouts, "counter"),
            ("bytes_out", self.bytes_out, "counter"),
            ("active_workers", self.active_workers, "gauge"),
            ("peak_active_workers", self.peak_active_workers, "gauge"),
            ("explicit_commits", self.committed_transactions, "counter"),
            ("explicit_rollbacks", self.aborted_transactions, "counter"),
            ("cancelled_statements", self.cancelled_statements, "counter"),
            ("slow_query_count", self.slow_queries, "counter"),
            ("prepared_statements", self.prepared_statements, "counter"),
            ("prepared_executions", self.prepared_executions, "counter"),
            ("prepared_replans", self.prepared_replans, "counter"),
            (
                "rejected_global_connections",
                self.rejected_global_connections,
                "counter",
            ),
            (
                "rejected_role_connections",
                self.rejected_role_connections,
                "counter",
            ),
        ]
    }
}

/// Measure a fallible or infallible operation without altering its result.
#[inline]
pub fn measure<T>(name: &'static str, operation: impl FnOnce() -> T) -> T {
    let _span = span(name);
    operation()
}

thread_local! {
    static MAINTENANCE_THREAD: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
/// 0.2-K: marks the calling thread as an internal background maintenance
/// thread (automatic reclamation). Its synchronization boundaries are not
/// delivered to test hooks, which orchestrate the interleavings of the
/// statements a test runs itself. Without the `test-hooks` feature this has
/// no observable effect.
pub fn mark_maintenance_thread() {
    MAINTENANCE_THREAD.with(|flag| flag.set(true));
}
#[must_use]
pub fn is_maintenance_thread() -> bool {
    MAINTENANCE_THREAD.with(std::cell::Cell::get)
}

/// Diagnostic synchronization points have no state or work in normal builds.
#[inline]
pub fn synchronization_boundary(point: &str, directory: &std::path::Path) {
    #[cfg(feature = "test-hooks")]
    if !is_maintenance_thread() {
        test_hooks::run(point, directory);
    }
    #[cfg(not(feature = "test-hooks"))]
    let _ = (point, directory);
}

#[cfg(feature = "test-hooks")]
pub mod test_hooks {
    use std::{
        collections::BTreeMap,
        path::{Path, PathBuf},
        sync::{Arc, Mutex, OnceLock},
    };
    pub type Callback = Arc<dyn Fn(&str) + Send + Sync>;
    fn hooks() -> &'static Mutex<BTreeMap<PathBuf, Callback>> {
        static HOOKS: OnceLock<Mutex<BTreeMap<PathBuf, Callback>>> = OnceLock::new();
        HOOKS.get_or_init(Mutex::default)
    }
    /// Scoped and directory-specific: unrelated parallel tests cannot pause.
    pub struct Registration(PathBuf);
    pub fn register(directory: &Path, callback: Callback) -> Registration {
        let path = std::fs::canonicalize(directory).expect("test database");
        assert!(
            hooks()
                .lock()
                .expect("test hooks")
                .insert(path.clone(), callback)
                .is_none()
        );
        Registration(path)
    }
    impl Drop for Registration {
        fn drop(&mut self) {
            hooks().lock().expect("test hooks").remove(&self.0);
        }
    }
    pub(super) fn run(point: &str, directory: &Path) {
        let callback = hooks().lock().expect("test hooks").get(directory).cloned();
        if let Some(callback) = callback {
            callback(point);
        }
    }
}

/// 0.2-H slow-request trace. Inert unless `PHOBOS_SLOW_REQUEST_US=<n>` is set
/// (n > 0); then every request whose total time is at least n microseconds
/// appends one CSV line to `PHOBOS_SLOW_REQUEST_LOG` (default
/// `phobos-slow-requests.csv` in the server's working directory). Normal
/// requests are only counted. Phase times come from the existing spans of
/// the thread that served the request; `unaccounted` is the remainder
/// (execution not covered by a phase, and scheduling delay).
pub mod trace {
    use std::cell::RefCell;
    use std::io::Write;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};
    use std::time::Instant;

    /// Phase names (= span names) and their CSV column names.
    pub const PHASES: [(&str, &str); 14] = [
        ("view.construct", "statement_view_us"),
        ("mvcc.unique_recheck", "unique_probe_us"),
        ("mvcc.commit_queue_wait", "commit_total_us"),
        ("mvcc.commit_order_acquire", "commit_order_wait_us"),
        ("mvcc.commit_order_hold", "stage_a_us"),
        ("mvcc.wal_append", "wal_append_us"),
        ("mvcc.wal_force_wait", "wal_force_wait_us"),
        ("wal.fsync", "wal_write_through_us"),
        ("mvcc.publication_turn_wait", "publication_turn_wait_us"),
        ("mvcc.publication_hold", "publication_us"),
        ("wal.extend_wait", "extent_wait_us"),
        ("checkpoint.foreground_drain", "checkpoint_drain_us"),
        ("mvcc.advance_checkpoint", "advance_checkpoint_us"),
        ("request.socket_write", "socket_write_us"),
    ];
    /// Background activity generations: odd while the activity runs.
    pub static EXTENT_ACTIVITY: AtomicU64 = AtomicU64::new(0);
    pub static CHECKPOINT_ACTIVITY: AtomicU64 = AtomicU64::new(0);
    static REQUESTS: AtomicU64 = AtomicU64::new(0);
    static SLOW: AtomicU64 = AtomicU64::new(0);

    struct Config {
        threshold_ns: u64,
        schedstat: bool,
        out: Mutex<Option<std::io::BufWriter<std::fs::File>>>,
    }
    fn config() -> Option<&'static Config> {
        static CONFIG: OnceLock<Option<Config>> = OnceLock::new();
        CONFIG
            .get_or_init(|| {
                let us = std::env::var("PHOBOS_SLOW_REQUEST_US")
                    .ok()
                    .and_then(|value| value.trim().parse::<u64>().ok())
                    .filter(|value| *value > 0)?;
                Some(Config {
                    threshold_ns: us.saturating_mul(1000),
                    schedstat: std::env::var("PHOBOS_SLOW_REQUEST_SCHED").is_ok_and(|v| v == "1"),
                    out: Mutex::new(None),
                })
            })
            .as_ref()
    }
    #[inline]
    pub fn enabled() -> bool {
        config().is_some()
    }
    #[inline]
    pub fn phase(name: &str) -> Option<usize> {
        PHASES.iter().position(|(phase, _)| *phase == name)
    }

    #[derive(Default)]
    struct Current {
        start: Option<Instant>,
        handoff_ns: u64,
        phases: [u64; PHASES.len()],
        extent: u64,
        checkpoint: u64,
        run_delay_ns: Option<u64>,
    }
    thread_local! {
        static CURRENT: RefCell<Current> = RefCell::new(Current::default());
    }
    pub(crate) fn add(phase: usize, ns: u64) {
        CURRENT.with(|current| {
            if let Ok(mut current) = current.try_borrow_mut() {
                if current.start.is_some() {
                    current.phases[phase] = current.phases[phase].saturating_add(ns);
                }
            }
        });
    }
    /// Linux: cumulative time this thread waited on a run queue (ns).
    fn run_delay() -> Option<u64> {
        #[cfg(target_os = "linux")]
        {
            let text = std::fs::read_to_string("/proc/thread-self/schedstat").ok()?;
            text.split_whitespace().nth(1)?.parse().ok()
        }
        #[cfg(not(target_os = "linux"))]
        {
            None
        }
    }
    /// A request frame was received; `handoff_ns` is the reader-thread →
    /// worker hand-off of the pumped transport (0 for direct execution).
    pub fn request_start(handoff_ns: u64) {
        let Some(config) = config() else { return };
        CURRENT.with(|current| {
            let mut current = current.borrow_mut();
            *current = Current {
                start: Some(Instant::now()),
                handoff_ns,
                extent: EXTENT_ACTIVITY.load(Ordering::Acquire),
                checkpoint: CHECKPOINT_ACTIVITY.load(Ordering::Acquire),
                run_delay_ns: if config.schedstat { run_delay() } else { None },
                ..Current::default()
            };
        });
    }
    fn overlapped(at_start: u64, now: u64) -> bool {
        at_start % 2 == 1 || now % 2 == 1 || at_start != now
    }
    /// The response was written. `kind` is a short request label.
    pub fn request_end(kind: &str) {
        let Some(config) = config() else { return };
        let Some(record) = CURRENT.with(|current| {
            let mut current = current.borrow_mut();
            let start = current.start.take()?;
            Some((
                start.elapsed().as_nanos() as u64,
                std::mem::take(&mut *current),
            ))
        }) else {
            return;
        };
        let (total, current) = record;
        REQUESTS.fetch_add(1, Ordering::Relaxed);
        if total < config.threshold_ns {
            return;
        }
        SLOW.fetch_add(1, Ordering::Relaxed);
        let scheduler = match (
            current.run_delay_ns,
            config.schedstat.then(run_delay).flatten(),
        ) {
            (Some(before), Some(after)) => (after.saturating_sub(before) / 1000).to_string(),
            _ => String::new(),
        };
        let p = &current.phases;
        // Disjoint top-level phases of the serving thread: statement view,
        // UNIQUE probe, the whole commit wait (commit_total covers its own
        // order wait, Stage A, force wait and publication, and the time spent
        // queued behind other commit groups), socket write.
        let covered = p[0] + p[1] + p[2] + p[13];
        let mut line = format!(
            "{},{},{},{},{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_or(0, |d| d.as_micros()),
            kind,
            std::thread::current().name().unwrap_or("?"),
            total / 1000,
            current.handoff_ns / 1000
        );
        for ns in p {
            line.push_str(&format!(",{}", ns / 1000));
        }
        line.push_str(&format!(
            ",{},{},{},{}\n",
            u8::from(overlapped(
                current.extent,
                EXTENT_ACTIVITY.load(Ordering::Acquire)
            )),
            u8::from(overlapped(
                current.checkpoint,
                CHECKPOINT_ACTIVITY.load(Ordering::Acquire)
            )),
            scheduler,
            total.saturating_sub(covered) / 1000
        ));
        if let Ok(mut out) = config.out.lock() {
            if out.is_none() {
                let path = std::env::var("PHOBOS_SLOW_REQUEST_LOG")
                    .unwrap_or_else(|_| "phobos-slow-requests.csv".into());
                let new = !std::path::Path::new(&path).exists();
                if let Ok(file) = std::fs::OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(&path)
                {
                    let mut writer = std::io::BufWriter::new(file);
                    if new {
                        let mut header = String::from("unix_us,kind,thread,total_us,handoff_us");
                        for (_, column) in PHASES {
                            header.push(',');
                            header.push_str(column);
                        }
                        header.push_str(",extent_overlap,checkpoint_overlap,run_queue_delay_us,unaccounted_us\n");
                        let _ = writer.write_all(header.as_bytes());
                    }
                    *out = Some(writer);
                }
            }
            if let Some(writer) = out.as_mut() {
                let _ = writer.write_all(line.as_bytes());
                let _ = writer.flush();
            }
        }
    }
    /// (requests traced, slow requests written).
    pub fn counts() -> (u64, u64) {
        (
            REQUESTS.load(Ordering::Relaxed),
            SLOW.load(Ordering::Relaxed),
        )
    }
    /// Marks a background activity (odd generation while it runs).
    pub struct Activity(&'static AtomicU64);
    pub fn activity(counter: &'static AtomicU64) -> Activity {
        counter.fetch_add(1, Ordering::AcqRel);
        Activity(counter)
    }
    impl Drop for Activity {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::AcqRel);
        }
    }
}
pub use trace::{request_end as trace_request_end, request_start as trace_request_start};
