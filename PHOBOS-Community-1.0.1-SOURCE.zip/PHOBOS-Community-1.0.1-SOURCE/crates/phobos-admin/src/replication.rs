//! G3 physical replication and LSN-targeted recovery. WAL bytes retain the
//! existing V2 encoding; only validated records are copied into a durable delta.
use phobos_error::{ErrorCode, PhobosError};
use phobos_execution::mvcc_runtime::MvccDatabase;
use phobos_wal::v2::{self, Body, Record};
use std::{
    fs::{self, OpenOptions},
    io::Write,
    path::{Path, PathBuf},
    time::Duration,
};

const STATE_HEADER: &str = "PHOBOS-REPLICATION-STATE-1";
const STATE_FILE: &str = "phobos.replication-state";
const STANDBY_MARKER: &str = "PHOBOS_STANDBY_1";
const RECEIVED_WAL: &str = "phobos.replication-received.wal";
const ARCHIVE_MARKER: &str = "PHOBOS_WAL_ARCHIVE_1";

type Result<T> = std::result::Result<T, PhobosError>;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReplicationState {
    pub system_id: String,
    pub slot: String,
    pub primary: PathBuf,
    pub last_received_lsn: u64,
    pub last_durable_received_lsn: u64,
    pub last_replayed_lsn: u64,
    pub next_txn_id: u64,
    pub page_format: u16,
}

pub fn initialize_standby(
    primary: &Path,
    backup: &Path,
    standby: &Path,
    slot: &str,
) -> Result<ReplicationState> {
    let system_id = v2::ensure_system_id(primary)?;
    if v2::read_system_id(backup)? != system_id {
        return Err(recovery(
            "backup belongs to a different database/system identity",
        ));
    }
    let end_lsn = backup_end_lsn(backup)?;
    if standby.exists() && fs::read_dir(standby)?.next().is_some() {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "standby destination must be empty",
        ));
    }
    fs::create_dir_all(standby)?;
    copy_database(backup, standby)?;
    let report = v2::inspect(standby.join("phobos.wal"))?;
    if report.checkpoint_lsn < end_lsn {
        return Err(recovery("online backup WAL does not cover its end LSN"));
    }
    let state = ReplicationState {
        system_id,
        slot: slot.to_string(),
        primary: fs::canonicalize(primary)?,
        last_received_lsn: end_lsn,
        last_durable_received_lsn: end_lsn,
        last_replayed_lsn: end_lsn,
        next_txn_id: report.next_txn_id,
        page_format: report.page_format,
    };
    fs::write(standby.join(STANDBY_MARKER), b"physical-read-only\n")?;
    write_state(standby, &state)?;
    v2::set_replication_slot(primary, slot, end_lsn)?;
    Ok(state)
}

pub fn receive_wal(primary: &Path, standby: &Path) -> Result<ReplicationState> {
    let mut state = read_state(standby)?;
    let identity = v2::read_system_id(primary)?;
    if identity != state.system_id {
        return Err(recovery(
            "replication source has a different database/system identity",
        ));
    }
    // 0.2-I.2: the target is the latest commit of the complete history
    // (retained + live WAL), validated for continuity from the replay position.
    let received = standby.join(RECEIVED_WAL);
    let mut cursor_trusted = true;
    if received.exists() {
        // A state file written by 0.2-I.1 advanced `next_txn_id` on receive.
        // A received delta that starts exactly at the replayed position records
        // the cursor there; a delta that cannot vouch for the state's cursor
        // (e.g. one 0.2-I.1 built over a "bridge") disables bridging.
        let mut file = fs::File::open(&received)?;
        match v2::read_record(&mut file)? {
            Some(Record {
                lsn,
                body: Body::Anchor { next_txn_id, .. },
                ..
            }) if lsn == state.last_replayed_lsn => {
                state.next_txn_id = next_txn_id.min(state.next_txn_id);
            }
            // A bridge anchor accepted by 0.2-I.2 carries exactly the cursor
            // in the state. A 0.2-I.1 bridged delta holding transactions left
            // the state's cursor ahead of its anchor, so it is not trusted.
            Some(Record {
                body: Body::Anchor { next_txn_id, .. },
                ..
            }) if next_txn_id == state.next_txn_id => {}
            _ => cursor_trusted = false,
        }
    }
    let plan = plan_delta(primary, &state, None, cursor_trusted)?;
    let target = plan.target;
    if target == state.last_replayed_lsn {
        return Ok(state);
    }
    let temporary = standby.join("phobos.replication-received.tmp");
    if temporary.exists() {
        fs::remove_file(&temporary)?;
    }
    write_delta(primary, &plan, &temporary)?;
    if received.exists() {
        fs::remove_file(&received)?;
    }
    fs::rename(temporary, received)?;
    state.last_received_lsn = target;
    state.last_durable_received_lsn = target;
    // 0.2-I.2: `next_txn_id` stays the transaction cursor at the *replayed*
    // position (deltas are rebuilt from there); replay advances it.
    write_state(standby, &state)?;
    Ok(state)
}

pub fn replay_received(standby: &Path) -> Result<ReplicationState> {
    // Replay changes the standby's WAL and data files. Reuse the database lock
    // so a serving standby cannot observe a partially replayed state.
    let _standby_lock = super::lock_dir(standby)?;
    let mut state = read_state(standby)?;
    let received = standby.join(RECEIVED_WAL);
    if !received.exists() {
        return Ok(state);
    }
    let received_report = v2::inspect(&received)?;
    let target = received_report.last_lsn;
    if target != state.last_durable_received_lsn || target < state.last_replayed_lsn {
        return Err(recovery(
            "received WAL position does not match replication state",
        ));
    }
    if target == state.last_replayed_lsn {
        v2::set_replication_slot(&state.primary, &state.slot, target)?;
        fs::remove_file(received)?;
        return Ok(state);
    }
    replace_wal(standby, &received)?;
    let database = MvccDatabase::open(standby)?;
    database.shutdown(Duration::from_secs(10))?;
    drop(database);
    state.last_replayed_lsn = target;
    state.next_txn_id = received_report.next_txn_id;
    write_state(standby, &state)?;
    v2::set_replication_slot(&state.primary, &state.slot, target)?;
    fs::remove_file(received)?;
    Ok(state)
}

pub fn archive_wal(primary: &Path, archive: &Path) -> Result<u64> {
    if archive.exists() && fs::read_dir(archive)?.next().is_some() {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "WAL archive destination must be empty",
        ));
    }
    fs::create_dir_all(archive)?;
    let system_id = v2::ensure_system_id(primary)?;
    fs::copy(
        primary.join("phobos.system-id"),
        archive.join("phobos.system-id"),
    )?;
    for path in wal_paths(primary)? {
        let name = path
            .file_name()
            .ok_or_else(|| recovery("WAL file has no name"))?;
        fs::copy(&path, archive.join(name))?;
    }
    // 0.2-I.2: history retained for slots across checkpoints/restarts is part
    // of the archive, in the same layout, so `recover-to` finds it.
    let retained = primary.join(v2::RETAINED_DIR);
    if retained.is_dir() {
        let destination = archive.join(v2::RETAINED_DIR);
        fs::create_dir_all(&destination)?;
        for entry in fs::read_dir(&retained)? {
            let entry = entry?;
            let name = entry.file_name();
            if entry.file_type()?.is_file() && name.to_string_lossy().ends_with(".seg") {
                fs::copy(entry.path(), destination.join(name))?;
            }
        }
        sync_files(&destination)?;
    }
    let lsn = latest_commit_lsn(archive)?;
    let mut marker = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(archive.join(ARCHIVE_MARKER))?;
    writeln!(marker, "system_id={system_id}")?;
    writeln!(marker, "end_lsn={lsn}")?;
    marker.sync_all()?;
    sync_files(archive)?;
    Ok(lsn)
}

pub fn pitr_recover_to(
    backup: &Path,
    wal_archive: &Path,
    destination: &Path,
    target_lsn: u64,
) -> Result<ReplicationState> {
    if !wal_archive.join(ARCHIVE_MARKER).exists() {
        return Err(recovery("WAL archive marker is missing"));
    }
    let system_id = v2::read_system_id(backup)?;
    if v2::read_system_id(wal_archive)? != system_id {
        return Err(recovery(
            "WAL archive belongs to a different database/system identity",
        ));
    }
    if destination.exists() && fs::read_dir(destination)?.next().is_some() {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "PITR destination must be empty",
        ));
    }
    fs::create_dir_all(destination)?;
    copy_database(backup, destination)?;
    let base_lsn = backup_end_lsn(backup)?;
    if target_lsn < base_lsn {
        return Err(recovery("PITR target precedes the base backup"));
    }
    let base = v2::inspect(destination.join("phobos.wal"))?;
    let mut state = ReplicationState {
        system_id,
        slot: "pitr".into(),
        primary: wal_archive.to_path_buf(),
        last_received_lsn: base_lsn,
        last_durable_received_lsn: base_lsn,
        last_replayed_lsn: base_lsn,
        next_txn_id: base.next_txn_id,
        page_format: base.page_format,
    };
    if target_lsn > base_lsn {
        let received = destination.join(RECEIVED_WAL);
        let report = build_delta(wal_archive, &state, target_lsn, &received)?;
        state.last_received_lsn = target_lsn;
        state.last_durable_received_lsn = target_lsn;
        state.next_txn_id = report.next_txn_id;
        replace_wal(destination, &received)?;
        let database = MvccDatabase::open(destination)?;
        database.shutdown(Duration::from_secs(10))?;
        drop(database);
        state.last_replayed_lsn = target_lsn;
        fs::remove_file(received)?;
    }
    fs::write(
        destination.join("PHOBOS_PITR_1"),
        format!("system_id={}\ntarget_lsn={}\n", state.system_id, target_lsn),
    )?;
    sync_files(destination)?;
    Ok(state)
}

/// 0.2-I.2: how a consumer (standby or PITR target) is fed from the WAL
/// history. 0.2-I.1 and earlier accepted any later format anchor as a
/// "bridge" over missing WAL and silently skipped the committed transactions
/// in between. Now every LSN after the consumer's replayed position must be
/// delivered, except a gap proven to hold no transaction:
///
/// * WAL transaction IDs are allocated in LSN order (BEGIN refuses a lower
///   ID), so if the format anchor after a gap carries the same transaction
///   cursor (`next_txn_id`) as the consumer had before it, no transaction
///   began, committed or aborted inside the gap; it held only format anchors /
///   checkpoint records, which redo ignores.
/// * Such gaps arise legitimately where a full checkpoint discarded an active
///   file holding nothing but an anchor after the slot (an idle restart), and
///   in front of a base backup's own checkpoint anchor.
///
/// Any other gap is refused ("new base backup required") instead of skipped.
struct DeltaPlan {
    /// The delta's first record: a format anchor at the consumer's position,
    /// or the history's own anchor that bridges a proven-harmless gap.
    start: Record,
    target: u64,
    /// Whether a proven-harmless gap may be bridged (see `plan_delta`).
    cursor_trusted: bool,
}

/// The transaction cursor / checkpoint horizon a consumer has reached.
#[derive(Clone, Copy)]
struct Cursor {
    next_txn_id: u64,
    checkpoint_lsn: u64,
}

impl Cursor {
    fn of_anchor(record: &Record) -> Self {
        match record.body {
            Body::Anchor {
                checkpoint_lsn,
                next_txn_id,
                ..
            } => Self {
                next_txn_id,
                checkpoint_lsn,
            },
            _ => unreachable!("delta start is a format anchor"),
        }
    }
    /// A gap in front of `record` is harmless (see [`DeltaPlan`]).
    fn bridges(&self, record: &Record) -> bool {
        matches!(
            record.body,
            Body::Anchor { checkpoint_lsn, next_txn_id, .. }
                if next_txn_id == self.next_txn_id && checkpoint_lsn >= self.checkpoint_lsn
        )
    }
    /// The record as delivered: later format anchors and the records of a
    /// dead transaction (left incomplete by a crash before a recovery
    /// checkpoint) become checkpoint records at the same LSN, so the delta is
    /// LSN-contiguous and never shows an interleaved transaction.
    fn deliver(&mut self, record: &Record, dead: bool) -> Record {
        let delivered = if dead {
            self.filler(record.lsn, record.txn_id.saturating_add(1))
        } else {
            match record.body {
                Body::Anchor {
                    checkpoint_lsn,
                    next_txn_id,
                    ..
                } => Record {
                    txn_id: 0,
                    lsn: record.lsn,
                    prev_lsn: 0,
                    body: Body::Checkpoint {
                        checkpoint_lsn,
                        next_txn_id,
                    },
                },
                _ => record.clone(),
            }
        };
        match delivered.body {
            Body::Checkpoint {
                checkpoint_lsn,
                next_txn_id,
            } => {
                self.checkpoint_lsn = checkpoint_lsn;
                self.next_txn_id = next_txn_id;
            }
            Body::Begin => self.next_txn_id = delivered.txn_id.saturating_add(1),
            _ => {}
        }
        delivered
    }
    /// A neutral checkpoint record standing in for a discarded format anchor
    /// (inside a proven-harmless gap) or a dead transaction's record.
    fn filler(&self, lsn: u64, at_least_next: u64) -> Record {
        Record {
            txn_id: 0,
            lsn,
            prev_lsn: 0,
            body: Body::Checkpoint {
                checkpoint_lsn: self.checkpoint_lsn,
                next_txn_id: self.next_txn_id.max(at_least_next),
            },
        }
    }
}

/// Validate, before anything is written, that the history after
/// `state.last_replayed_lsn` can be delivered completely through the target
/// (`None`: the latest commit). Read-only.
fn plan_delta(
    source: &Path,
    state: &ReplicationState,
    target: Option<u64>,
    cursor_trusted: bool,
) -> Result<DeltaPlan> {
    let replayed = state.last_replayed_lsn;
    let synthesized = |next_txn_id: u64| Record {
        txn_id: 0,
        lsn: replayed,
        prev_lsn: 0,
        body: Body::Anchor {
            checkpoint_lsn: replayed.saturating_sub(1),
            next_txn_id,
            page_format: state.page_format,
        },
    };
    let mut start: Option<Record> = None;
    let mut start_error: Option<String> = None;
    let mut cursor = Cursor {
        next_txn_id: state.next_txn_id,
        checkpoint_lsn: replayed.saturating_sub(1),
    };
    let mut expected = replayed.saturating_add(1);
    let mut bad_gap: Option<(u64, u64)> = None;
    let mut commits = std::collections::BTreeSet::new();
    v2::visit_history(
        source,
        replayed,
        target.unwrap_or(u64::MAX),
        |record, dead| {
            if start.is_none() && start_error.is_none() {
                if record.lsn == expected {
                    // A state file written by 0.2-I.1 after an unreplayed receive
                    // may carry a cursor ahead of the replayed position; never
                    // start above what the first record allows.
                    let bound = match record.body {
                        Body::Begin => record.txn_id,
                        Body::Anchor { next_txn_id, .. } | Body::Checkpoint { next_txn_id, .. } => {
                            next_txn_id
                        }
                        _ => state.next_txn_id,
                    };
                    let anchor = synthesized(state.next_txn_id.min(bound));
                    cursor = Cursor::of_anchor(&anchor);
                    start = Some(anchor);
                } else if cursor_trusted && cursor.bridges(record) && {
                    let Body::Anchor { checkpoint_lsn, .. } = record.body else {
                        unreachable!()
                    };
                    checkpoint_lsn >= replayed
                } {
                    cursor = Cursor::of_anchor(record);
                    start = Some(record.clone());
                    expected = record.lsn.saturating_add(1);
                    return Ok(());
                } else {
                    start_error = Some(format!(
                        "new base backup required: requested WAL was retired (replayed_lsn={replayed}, first_available={}): WAL records {}..={} are no longer available",
                        record.lsn,
                        expected,
                        record.lsn.saturating_sub(1)
                    ));
                }
            }
            if record.lsn != expected
                && bad_gap.is_none()
                && !(cursor_trusted && cursor.bridges(record))
            {
                bad_gap = Some((expected, record.lsn));
            }
            expected = record.lsn.saturating_add(1);
            cursor.deliver(record, dead);
            if matches!(record.body, Body::Commit) && !dead {
                commits.insert(record.lsn);
            }
            Ok(())
        },
    )?;
    // An unprovable gap anywhere after the consumer's position (for a PITR
    // target: before it) is refused even when no commit is visible after it:
    // the missing range may have held commits, and "nothing new" would be a
    // silent lie (e.g. after the slot was dropped and its WAL released).
    if let Some(error) = start_error {
        return Err(recovery(&error));
    }
    let requested = target;
    let target = match target {
        Some(target) => target,
        None => commits.last().copied().unwrap_or(replayed).max(replayed),
    };
    if let Some((missing, found)) = bad_gap {
        // Streaming (no explicit target) reads the whole history: any such
        // gap counts. A PITR target is only affected by gaps before it.
        if requested.is_none() || missing <= target {
            return Err(recovery(&format!(
                "WAL history gap: records {missing}..={} are missing before LSN {found} (retired WAL, or history changed while it was read; retry, else a new base backup is required)",
                found - 1
            )));
        }
    }
    if target == replayed {
        return Ok(DeltaPlan {
            start: synthesized(state.next_txn_id),
            target,
            cursor_trusted,
        });
    }
    let Some(start) = start else {
        return Err(recovery(&format!(
            "new base backup required: requested WAL was retired (replayed_lsn={replayed}, first_available=None)"
        )));
    };
    if expected <= target {
        return Err(recovery(&format!(
            "WAL history ends at LSN {} before the target {target}",
            expected - 1
        )));
    }
    if !commits.contains(&target) {
        return Err(recovery(
            "PITR/replication target is not a committed WAL LSN",
        ));
    }
    Ok(DeltaPlan {
        start,
        target,
        cursor_trusted,
    })
}

/// Write the planned delta. The output is a delta file only; WAL files on
/// disk are never rewritten.
fn build_delta(
    source: &Path,
    state: &ReplicationState,
    target: u64,
    destination: &Path,
) -> Result<v2::ScanReport> {
    let plan = plan_delta(source, state, Some(target), true)?;
    write_delta(source, &plan, destination)
}

fn write_delta(source: &Path, plan: &DeltaPlan, destination: &Path) -> Result<v2::ScanReport> {
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(destination)?;
    file.write_all(&plan.start.encode()?)?;
    let mut cursor = Cursor::of_anchor(&plan.start);
    let mut expected = plan.start.lsn.saturating_add(1);
    let changed = || recovery("WAL history changed while the delta was written; retry");
    v2::visit_history(source, plan.start.lsn, plan.target, |record, dead| {
        if record.lsn != expected {
            if record.lsn < expected || !plan.cursor_trusted || !cursor.bridges(record) {
                return Err(changed());
            }
            for lsn in expected..record.lsn {
                file.write_all(&cursor.filler(lsn, 0).encode()?)?;
            }
        }
        expected = record.lsn.saturating_add(1);
        file.write_all(&cursor.deliver(record, dead).encode()?)?;
        Ok(())
    })?;
    if expected <= plan.target {
        return Err(changed());
    }
    file.sync_all()?;
    drop(file);
    v2::inspect(destination)
}

/// Latest committed LSN reachable in the WAL history (retained + live);
/// the active checkpoint LSN when the history holds no commit.
fn latest_commit_lsn(directory: &Path) -> Result<u64> {
    let mut latest = None;
    v2::visit_history(directory, 0, u64::MAX, |record, dead| {
        if matches!(record.body, Body::Commit) && !dead {
            latest = Some(record.lsn);
        }
        Ok(())
    })?;
    match latest {
        Some(lsn) => Ok(lsn),
        None => Ok(v2::inspect(directory.join("phobos.wal"))?.checkpoint_lsn),
    }
}

/// 0.2-I.2: protect the WAL a PITR base backup needs. Registers slot `slot`
/// on the primary at the backup's end LSN, after verifying that the history
/// from that LSN is still complete. Until the slot is advanced or dropped,
/// checkpoints and restarts keep every later record (retained history), and
/// `wal-archive` copies it.
pub fn retain_wal_for_backup(primary: &Path, backup: &Path, slot: &str) -> Result<u64> {
    let system_id = v2::ensure_system_id(primary)?;
    if v2::read_system_id(backup)? != system_id {
        return Err(recovery(
            "backup belongs to a different database/system identity",
        ));
    }
    if v2::replication_slots(primary)?
        .iter()
        .any(|(name, _)| name == slot)
    {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "replication slot already exists",
        ));
    }
    let end_lsn = backup_end_lsn(backup)?;
    let report = v2::inspect(backup.join("phobos.wal"))?;
    let state = ReplicationState {
        system_id,
        slot: slot.to_string(),
        primary: primary.to_path_buf(),
        last_received_lsn: end_lsn,
        last_durable_received_lsn: end_lsn,
        last_replayed_lsn: end_lsn,
        next_txn_id: report.next_txn_id,
        page_format: report.page_format,
    };
    // Register first, then verify: a checkpoint between a successful check
    // and the registration could otherwise discard the WAL unnoticed.
    v2::set_replication_slot(primary, slot, end_lsn)?;
    if let Err(error) = plan_delta(primary, &state, None, true) {
        // WAL after the backup was already discarded: nothing to protect.
        let _ = v2::remove_replication_slot(primary, slot);
        return Err(error);
    }
    Ok(end_lsn)
}

/// 0.2-I.2: the explicit act that releases WAL protected by a slot.
pub fn drop_replication_slot(primary: &Path, slot: &str) -> Result<bool> {
    v2::remove_replication_slot(primary, slot)
}

/// 0.2-I.2 diagnostics for one slot.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SlotStatus {
    pub name: String,
    /// The slot's LSN: its consumer has replayed through here; every later
    /// record is protected.
    pub protected_after_lsn: u64,
    /// WAL bytes (whole files) holding records after `protected_after_lsn`.
    pub pinned_bytes: u64,
    pub pinned_files: usize,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReplicationStatus {
    pub current_lsn: u64,
    pub checkpoint_lsn: u64,
    pub last_commit_lsn: u64,
    pub oldest_retained_lsn: u64,
    pub history_files: usize,
    pub history_bytes: u64,
    pub retained_files: usize,
    pub retained_bytes: u64,
    pub slots: Vec<SlotStatus>,
}

/// Read-only retention diagnostics of a primary data directory (or archive).
pub fn replication_status(primary: &Path) -> Result<ReplicationStatus> {
    let report = v2::inspect(primary.join("phobos.wal"))?;
    let retention = v2::retention_report(primary)?;
    let files = v2::history_files(primary)?;
    let slots = retention
        .slots
        .iter()
        .map(|(name, lsn)| {
            let pinned: Vec<_> = files
                .iter()
                .enumerate()
                .filter(|(index, _)| {
                    files
                        .get(index + 1)
                        .is_none_or(|next| next.start_lsn.saturating_sub(1) > *lsn)
                })
                .map(|(_, file)| file.bytes)
                .collect();
            SlotStatus {
                name: name.clone(),
                protected_after_lsn: *lsn,
                pinned_bytes: pinned.iter().sum(),
                pinned_files: pinned.len(),
            }
        })
        .collect();
    Ok(ReplicationStatus {
        current_lsn: report.last_lsn,
        checkpoint_lsn: report.checkpoint_lsn,
        last_commit_lsn: latest_commit_lsn(primary)?,
        oldest_retained_lsn: retention.oldest_lsn,
        history_files: retention.files,
        history_bytes: retention.bytes,
        retained_files: retention.retained_files,
        retained_bytes: retention.retained_bytes,
        slots,
    })
}

/// A standby's persisted receive / replay positions.
pub fn standby_state(standby: &Path) -> Result<ReplicationState> {
    read_state(standby)
}

fn replace_wal(directory: &Path, received: &Path) -> Result<()> {
    let installing = directory.join("phobos.wal.installing");
    fs::copy(received, &installing)?;
    OpenOptions::new()
        .write(true)
        .open(&installing)?
        .sync_all()?;
    for entry in fs::read_dir(directory)? {
        let path = entry?.path();
        let name = path.file_name().and_then(|name| name.to_str());
        if name.is_some_and(|name| name.starts_with("phobos.wal.") && name.ends_with(".seg")) {
            fs::remove_file(path)?;
        }
    }
    let wal = directory.join("phobos.wal");
    if wal.exists() {
        fs::remove_file(&wal)?;
    }
    fs::rename(installing, wal)?;
    Ok(())
}

fn wal_paths(directory: &Path) -> Result<Vec<PathBuf>> {
    let mut paths = fs::read_dir(directory)?
        .filter_map(|entry| entry.ok())
        .filter(|entry| entry.file_type().is_ok_and(|kind| kind.is_file()))
        .map(|entry| entry.path())
        .filter(|path| {
            path.file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| {
                    name == "phobos.wal"
                        || (name.starts_with("phobos.wal.") && name.ends_with(".seg"))
                })
        })
        .collect::<Vec<_>>();
    paths.sort();
    if paths
        .iter()
        .all(|path| path.file_name().and_then(|name| name.to_str()) != Some("phobos.wal"))
    {
        return Err(recovery("active WAL file is missing"));
    }
    Ok(paths)
}

fn copy_database(source: &Path, destination: &Path) -> Result<()> {
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        if !entry.file_type()?.is_file() {
            continue;
        }
        let name = entry.file_name();
        let name = name.to_string_lossy();
        if name == "PHOBOS_BACKUP_2"
            || name == "PHOBOS_BACKUP_1"
            || name == "phobos.system-id"
            || name == "phobos.wal"
            || name.starts_with("phobos.wal.")
            || matches!(
                entry.path().extension().and_then(|value| value.to_str()),
                Some("phc" | "heap" | "idx" | "txn" | "stats")
            )
            || matches!(name.as_ref(), "phobos.mvcc-status" | "phobos.mvcc-freeze")
        {
            fs::copy(entry.path(), destination.join(entry.file_name()))?;
        }
    }
    sync_files(destination)
}

fn backup_end_lsn(backup: &Path) -> Result<u64> {
    let marker = fs::read_to_string(backup.join("PHOBOS_BACKUP_2"))?;
    marker
        .lines()
        .find_map(|line| line.strip_prefix("end_lsn="))
        .and_then(|value| value.parse().ok())
        .filter(|value| *value != 0)
        .ok_or_else(|| recovery("online backup marker has no valid end LSN"))
}

fn read_state(directory: &Path) -> Result<ReplicationState> {
    let text = fs::read_to_string(directory.join(STATE_FILE))?;
    let mut lines = text.lines();
    if lines.next() != Some(STATE_HEADER) {
        return Err(recovery("invalid replication state header"));
    }
    let mut field = |name: &str| -> Result<String> {
        lines
            .next()
            .and_then(|line| line.strip_prefix(&format!("{name}=")))
            .map(str::to_string)
            .ok_or_else(|| recovery("invalid replication state"))
    };
    let system_id = field("system_id")?;
    let slot = field("slot")?;
    let primary = PathBuf::from(field("primary")?);
    let last_received_lsn = field("last_received_lsn")?
        .parse()
        .map_err(|_| recovery("invalid replication LSN"))?;
    let last_durable_received_lsn = field("last_durable_received_lsn")?
        .parse()
        .map_err(|_| recovery("invalid replication LSN"))?;
    let last_replayed_lsn = field("last_replayed_lsn")?
        .parse()
        .map_err(|_| recovery("invalid replication LSN"))?;
    let next_txn_id = field("next_txn_id")?
        .parse()
        .map_err(|_| recovery("invalid replication transaction identity"))?;
    let page_format = field("page_format")?
        .parse()
        .map_err(|_| recovery("invalid replication page format"))?;
    if lines.next().is_some()
        || last_replayed_lsn > last_durable_received_lsn
        || last_durable_received_lsn > last_received_lsn
    {
        return Err(recovery("invalid replication state positions"));
    }
    Ok(ReplicationState {
        system_id,
        slot,
        primary,
        last_received_lsn,
        last_durable_received_lsn,
        last_replayed_lsn,
        next_txn_id,
        page_format,
    })
}

fn write_state(directory: &Path, state: &ReplicationState) -> Result<()> {
    let temporary = directory.join("phobos.replication-state.tmp");
    let target = directory.join(STATE_FILE);
    let mut file = OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .open(&temporary)?;
    writeln!(file, "{STATE_HEADER}")?;
    writeln!(file, "system_id={}", state.system_id)?;
    writeln!(file, "slot={}", state.slot)?;
    writeln!(file, "primary={}", state.primary.display())?;
    writeln!(file, "last_received_lsn={}", state.last_received_lsn)?;
    writeln!(
        file,
        "last_durable_received_lsn={}",
        state.last_durable_received_lsn
    )?;
    writeln!(file, "last_replayed_lsn={}", state.last_replayed_lsn)?;
    writeln!(file, "next_txn_id={}", state.next_txn_id)?;
    writeln!(file, "page_format={}", state.page_format)?;
    file.sync_all()?;
    drop(file);
    if target.exists() {
        fs::remove_file(&target)?;
    }
    fs::rename(temporary, target)?;
    Ok(())
}

fn sync_files(directory: &Path) -> Result<()> {
    for entry in fs::read_dir(directory)? {
        let entry = entry?;
        if entry.file_type()?.is_file() {
            OpenOptions::new()
                .write(true)
                .open(entry.path())?
                .sync_all()?;
        }
    }
    Ok(())
}

fn recovery(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_execution::{Database, QueryResult};
    use phobos_types::Value;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp(label: &str) -> PathBuf {
        std::env::temp_dir().join(format!(
            "phobos-g34-{label}-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ))
    }

    fn count(database: &MvccDatabase) -> i64 {
        match database.execute(90, "SELECT COUNT(*) AS n FROM t").unwrap() {
            QueryResult::Rows { rows, .. } => match rows[0].values[0] {
                Value::Int64(value) => value,
                _ => panic!("count was not BIGINT"),
            },
            _ => panic!("count did not return rows"),
        }
    }

    #[test]
    fn g3_backup_stream_reconnect_identity_and_pitr() {
        let root = temp("acceptance");
        let legacy = root.join("legacy");
        let migration_backup = root.join("migration-backup");
        let primary = root.join("primary");
        let backup = root.join("online-backup");
        let standby = root.join("standby");
        let archive = root.join("archive");
        let pitr = root.join("pitr");
        {
            let mut database = Database::open(&legacy).unwrap();
            database
                .execute("CREATE TABLE t (id BIGINT NOT NULL)")
                .unwrap();
            database.execute("INSERT INTO t VALUES (1)").unwrap();
        }
        super::super::migrate_mvcc_copy(&legacy, &migration_backup, &primary).unwrap();
        let database = MvccDatabase::open(&primary).unwrap();
        let base = database.backup_online(&backup).unwrap();
        let initialized = initialize_standby(&primary, &backup, &standby, "standby-a").unwrap();
        assert_eq!(initialized.last_replayed_lsn, base.end_lsn);

        database.execute(1, "INSERT INTO t VALUES (2)").unwrap();
        let (_, second_lsn) = database.wal_position().unwrap();
        let received = receive_wal(&primary, &standby).unwrap();
        assert_eq!(received.last_durable_received_lsn, second_lsn);
        assert_eq!(receive_wal(&primary, &standby).unwrap(), received);
        let replayed = replay_received(&standby).unwrap();
        assert_eq!(replayed.last_replayed_lsn, second_lsn);
        let replica = MvccDatabase::open(&standby).unwrap();
        assert_eq!(count(&replica), 2);
        replica.shutdown(Duration::from_secs(10)).unwrap();
        drop(replica);

        database.execute(1, "INSERT INTO t VALUES (3)").unwrap();
        let (_, third_lsn) = database.wal_position().unwrap();
        receive_wal(&primary, &standby).unwrap();
        assert_eq!(
            replay_received(&standby).unwrap().last_replayed_lsn,
            third_lsn
        );
        assert!(third_lsn > second_lsn);
        let replica = MvccDatabase::open(&standby).unwrap();
        assert_eq!(count(&replica), 3);
        replica.shutdown(Duration::from_secs(10)).unwrap();
        drop(replica);

        assert_eq!(archive_wal(&primary, &archive).unwrap(), third_lsn);
        database.disconnect(1);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        let recovered = pitr_recover_to(&backup, &archive, &pitr, second_lsn).unwrap();
        assert_eq!(recovered.last_replayed_lsn, second_lsn);
        let recovered = MvccDatabase::open(&pitr).unwrap();
        assert_eq!(count(&recovered), 2);
        recovered.execute(2, "INSERT INTO t VALUES (4)").unwrap();
        assert_eq!(count(&recovered), 3);
        recovered.disconnect(2);
        recovered.disconnect(90);
        recovered.shutdown(Duration::from_secs(10)).unwrap();
        drop(recovered);
        super::super::check_integrity(&pitr).unwrap();

        let original = fs::read_to_string(primary.join("phobos.system-id")).unwrap();
        fs::write(
            primary.join("phobos.system-id"),
            "PHOBOS-SYSTEM-1\nffffffffffffffffffffffffffffffff\n",
        )
        .unwrap();
        assert!(
            receive_wal(&primary, &standby)
                .unwrap_err()
                .message
                .contains("different database/system identity")
        );
        fs::write(primary.join("phobos.system-id"), original).unwrap();

        eprintln!(
            "G34_REPLICATION backup_start_lsn={} backup_end_lsn={} second_lsn={} replayed_lsn={} lag_bytes=0 pitr_rows=2",
            base.start_lsn, base.end_lsn, second_lsn, third_lsn
        );
        fs::remove_dir_all(root).unwrap();
    }

    fn restart(database: MvccDatabase, path: &Path) -> MvccDatabase {
        database.disconnect(1);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        MvccDatabase::open(path).unwrap()
    }

    fn standby_count(standby: &Path) -> i64 {
        let replica = MvccDatabase::open(standby).unwrap();
        let rows = count(&replica);
        replica.shutdown(Duration::from_secs(10)).unwrap();
        drop(replica);
        rows
    }

    fn primary(root: &Path) -> PathBuf {
        let legacy = root.join("legacy");
        let primary = root.join("primary");
        {
            let mut database = Database::open(&legacy).unwrap();
            database
                .execute("CREATE TABLE t (id BIGINT NOT NULL)")
                .unwrap();
            database.execute("INSERT INTO t VALUES (1)").unwrap();
        }
        super::super::migrate_mvcc_copy(&legacy, &root.join("migration-backup"), &primary).unwrap();
        primary
    }

    /// 0.2-I.2 I1/I2/I4/I5/I8: clean primary restarts never discard WAL a
    /// slot still needs, whether the standby received it or not.
    #[test]
    fn i2_primary_restarts_keep_wal_for_a_lagging_standby() {
        let root = temp("i2-restart");
        let primary = primary(&root);
        let backup = root.join("backup");
        let standby = root.join("standby");
        let database = MvccDatabase::open(&primary).unwrap();
        database.backup_online(&backup).unwrap();
        initialize_standby(&primary, &backup, &standby, "standby-a").unwrap();
        database.execute(1, "INSERT INTO t VALUES (2)").unwrap();
        // Not received before the restart (the 0.2-I.1 silent-loss case).
        let database = restart(database, &primary);
        database.execute(1, "INSERT INTO t VALUES (3)").unwrap();
        // Received, not replayed, across a second restart.
        let received = receive_wal(&primary, &standby).unwrap();
        let database = restart(database, &primary);
        database.execute(1, "INSERT INTO t VALUES (4)").unwrap();
        let replayed = replay_received(&standby).unwrap();
        assert_eq!(replayed.last_replayed_lsn, received.last_received_lsn);
        assert_eq!(standby_count(&standby), 3);
        receive_wal(&primary, &standby).unwrap();
        replay_received(&standby).unwrap();
        assert_eq!(standby_count(&standby), 4);
        super::super::check_integrity(&standby).unwrap();
        let status = replication_status(&primary).unwrap();
        assert_eq!(status.slots.len(), 1);
        assert_eq!(status.slots[0].protected_after_lsn, status.last_commit_lsn);
        // Caught up: the next checkpoint releases the retained history.
        let database = restart(database, &primary);
        assert_eq!(replication_status(&primary).unwrap().retained_files, 0);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }

    /// 0.2-I.2 I7: PITR from a base backup across several clean restarts,
    /// to exact commit LSNs, with the WAL protected by `wal-retain`.
    #[test]
    fn i2_pitr_crosses_primary_restarts_with_retained_wal() {
        let root = temp("i2-pitr");
        let primary = primary(&root);
        let backup = root.join("backup");
        let database = MvccDatabase::open(&primary).unwrap();
        database.backup_online(&backup).unwrap();
        retain_wal_for_backup(&primary, &backup, "pitr-base").unwrap();
        let mut targets = Vec::new();
        database.execute(1, "INSERT INTO t VALUES (2)").unwrap();
        targets.push((database.wal_position().unwrap().1, 2));
        let database = restart(database, &primary);
        database.execute(1, "INSERT INTO t VALUES (3)").unwrap();
        targets.push((database.wal_position().unwrap().1, 3));
        let database = restart(database, &primary);
        database.execute(1, "INSERT INTO t VALUES (4)").unwrap();
        targets.push((database.wal_position().unwrap().1, 4));
        let archive = root.join("archive");
        archive_wal(&primary, &archive).unwrap();
        for (index, (target, rows)) in targets.iter().enumerate() {
            let destination = root.join(format!("pitr-{index}"));
            let state = pitr_recover_to(&backup, &archive, &destination, *target).unwrap();
            assert_eq!(state.last_replayed_lsn, *target);
            assert_eq!(standby_count(&destination), *rows);
            super::super::check_integrity(&destination).unwrap();
        }
        // Dropping the slot is the explicit act that releases the history.
        assert!(drop_replication_slot(&primary, "pitr-base").unwrap());
        let database = restart(database, &primary);
        assert!(!primary.join(v2::RETAINED_DIR).exists());
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }

    /// 0.2-I.2 I8: when protected WAL is genuinely gone (no slot), PITR and
    /// replication fail closed instead of skipping committed transactions.
    #[test]
    fn i2_discarded_wal_is_refused_never_skipped() {
        let root = temp("i2-gap");
        let primary = primary(&root);
        let backup = root.join("backup");
        let standby = root.join("standby");
        let database = MvccDatabase::open(&primary).unwrap();
        database.backup_online(&backup).unwrap();
        initialize_standby(&primary, &backup, &standby, "standby-a").unwrap();
        // The operator drops the slot: nothing protects the WAL any more.
        assert!(drop_replication_slot(&primary, "standby-a").unwrap());
        database.execute(1, "INSERT INTO t VALUES (2)").unwrap();
        let database = restart(database, &primary);
        database.execute(1, "INSERT INTO t VALUES (3)").unwrap();
        let target = database.wal_position().unwrap().1;
        let error = receive_wal(&primary, &standby).unwrap_err();
        assert!(
            error.message.contains("new base backup required"),
            "{error:?}"
        );
        let archive = root.join("archive");
        archive_wal(&primary, &archive).unwrap();
        let error = pitr_recover_to(&backup, &archive, &root.join("pitr"), target).unwrap_err();
        assert!(
            error.message.contains("new base backup required"),
            "{error:?}"
        );
        database.disconnect(1);
        database.shutdown(Duration::from_secs(10)).unwrap();
        drop(database);
        fs::remove_dir_all(root).unwrap();
    }

    /// 0.2-I.2 I8 (independent-review probe): damage to the tail of a
    /// retained sealed segment is an error, never a shorter file whose last
    /// transaction is "bridged" away.
    #[test]
    fn i2_damaged_retained_segment_is_refused_never_bridged() {
        let source = temp("i2-damaged-src");
        let output = temp("i2-damaged-delta");
        let mut wal = phobos_wal::v2::Wal::create_with_page_lsn(&source).unwrap();
        wal.begin().unwrap();
        let first = wal.commit().unwrap().lsn();
        v2::set_replication_slot(&source, "standby", first).unwrap();
        wal.begin().unwrap();
        wal.commit().unwrap();
        wal.begin().unwrap();
        let third = wal.commit().unwrap().lsn();
        // An incremental checkpoint covering the active prefix seals it.
        wal.request_checkpoint(third).unwrap();
        while wal.checkpoint_pending() {
            wal.poll_checkpoint().unwrap();
            std::thread::yield_now();
        }
        wal.begin().unwrap();
        let fourth = wal.commit().unwrap().lsn();
        wal.checkpoint_all(fourth).unwrap();
        drop(wal);
        let state = ReplicationState {
            system_id: "0".repeat(32),
            slot: "standby".into(),
            primary: source.clone(),
            last_received_lsn: first,
            last_durable_received_lsn: first,
            last_replayed_lsn: first,
            next_txn_id: 2,
            page_format: 2,
        };
        // Undamaged: the delta holds every commit.
        build_delta(&source, &state, fourth, &output).unwrap();
        fs::remove_file(&output).unwrap();
        let mut retained: Vec<_> = fs::read_dir(source.join(v2::RETAINED_DIR))
            .unwrap()
            .map(|entry| entry.unwrap().path())
            .collect();
        retained.sort();
        let sealed = &retained[0];
        let mut bytes = fs::read(sealed).unwrap();
        let last = bytes.iter().rposition(|byte| *byte != 0).unwrap();
        bytes[last - 2] ^= 0x55; // inside the final COMMIT record
        fs::write(sealed, bytes).unwrap();
        assert!(build_delta(&source, &state, fourth, &output).is_err());
        fs::remove_dir_all(source).unwrap();
    }

    #[test]
    fn g3_retired_wal_requires_new_base_backup() {
        let source = temp("retired-source");
        let output = temp("retired-delta");
        let mut wal = phobos_wal::v2::Wal::create_with_page_lsn(&source).unwrap();
        wal.begin().unwrap();
        let commit = wal.commit().unwrap();
        wal.checkpoint_all(commit.lsn()).unwrap();
        drop(wal);
        let state = ReplicationState {
            system_id: "0".repeat(32),
            slot: "standby".into(),
            primary: source.clone(),
            last_received_lsn: 1,
            last_durable_received_lsn: 1,
            last_replayed_lsn: 1,
            next_txn_id: 1,
            page_format: 2,
        };
        assert!(
            build_delta(&source, &state, commit.lsn(), &output)
                .unwrap_err()
                .message
                .contains("new base backup required")
        );
        fs::remove_dir_all(source).unwrap();
    }
}
