//! Upgrade a restored copy; the original database is never migrated in place.
use super::*;
pub fn upgrade_community_copy(
    source: &Path,
    backup: &Path,
    output: &Path,
    accept_experimental_v4: bool,
) -> Result<IntegrityReport, PhobosError> {
    if !source.join("catalog.phc").is_file() {
        return Err(PhobosError::new(
            ErrorCode::NotFound,
            "source catalog missing",
        ));
    }
    let header = fs::read(source.join("catalog.phc"))?;
    if header.len() < 6 {
        return Err(PhobosError::new(
            ErrorCode::InvalidCatalog,
            "catalog header truncated",
        ));
    }
    let version = u16::from_le_bytes([header[4], header[5]]);
    if version == 4 && !accept_experimental_v4 {
        return Err(PhobosError::new(
            ErrorCode::Unsupported,
            "experimental catalog v4 requires explicit --accept-v4 after independent review",
        ));
    }
    check_integrity(source)?;
    backup_offline(source, backup)?;
    restore_offline(backup, output)?;
    check_integrity(output)?;
    {
        let db = phobos_execution::mvcc_runtime::MvccDatabase::open(output)?;
        let session = db.connect(1)?;
        db.upgrade_catalog_format(&session)?;
        drop(session);
        db.check_online()?;
    }
    check_integrity(output)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn upgrade_copy_preserves_source_requires_v4_consent_and_publishes_v5() {
        let root = std::env::temp_dir().join(format!(
            "phobos-upgrade-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let source = root.join("source");
        {
            let mut db = Database::open(root.join("legacy")).unwrap();
            db.execute("CREATE TABLE seed (id BIGINT)").unwrap();
        }
        migrate_mvcc_copy(&root.join("legacy"), &root.join("legacy-backup"), &source).unwrap();
        upgrade_community_copy(
            &source,
            &root.join("accepted-backup"),
            &root.join("accepted-upgraded"),
            false,
        )
        .unwrap();
        {
            let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&source).unwrap();
            db.execute(
                1,
                "CREATE TABLE items (id BIGINT PRIMARY KEY, n BIGINT DEFAULT 7)",
            )
            .unwrap();
            db.execute(1, "INSERT INTO items(id) VALUES(1)").unwrap();
            db.disconnect(1);
        }
        let before = fs::read(source.join("catalog.phc")).unwrap();
        assert_eq!(before[4], 4);
        assert!(
            upgrade_community_copy(
                &source,
                &root.join("rejected-backup"),
                &root.join("rejected-output"),
                false
            )
            .is_err()
        );
        assert!(!root.join("rejected-backup").exists());
        let output = root.join("upgraded");
        upgrade_community_copy(&source, &root.join("backup"), &output, true).unwrap();
        assert_eq!(before, fs::read(source.join("catalog.phc")).unwrap());
        assert_eq!(fs::read(output.join("catalog.phc")).unwrap()[4], 5);
        {
            let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&output).unwrap();
            assert!(
                db.execute(1, "SELECT * FROM items")
                    .unwrap()
                    .to_text()
                    .contains("1\t7")
            );
            db.execute(1, "INSERT INTO items(id) VALUES(2)").unwrap();
            db.disconnect(1);
        }
        check_integrity(&source).unwrap();
        check_integrity(&output).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
}
