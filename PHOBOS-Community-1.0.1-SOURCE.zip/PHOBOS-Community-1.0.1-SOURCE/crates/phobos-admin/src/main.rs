#![forbid(unsafe_code)]

use phobos_admin::{
    add_user, archive_wal, backup_offline, check_integrity, drop_replication_slot,
    initialize_standby, list_users, migrate_mvcc_copy, migrate_page_lsn, migrate_wal_v2,
    pitr_recover_to, receive_wal, reindex_memcomparable, remove_user, repair_overflow,
    replay_received, replication_status, restore_offline, retain_wal_for_backup, standby_state,
    storage_lifecycle,
};
use phobos_auth::Role;
use std::{env, path::PathBuf, process};

fn main() {
    if env::args().nth(1).as_deref() == Some("--version") {
        println!(
            "PHOBOS Admin {} Community Edition",
            env!("CARGO_PKG_VERSION")
        );
        return;
    }

    if let Err(error) = run() {
        eprintln!("phobos-admin failed: {error}");
        process::exit(1);
    }
}

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let mut args = env::args().skip(1);
    match args.next().as_deref() {
        Some("init") => {
            let instance = PathBuf::from(required(&mut args));
            let legacy = instance.join("initial-legacy");
            let backup = instance.join("initial-backup");
            let data = instance.join("data");
            if legacy.exists() || backup.exists() || data.exists() {
                return Err("init requires a fresh instance".into());
            }
            std::fs::create_dir_all(&instance)?;
            drop(phobos_execution::Database::open(&legacy)?);
            migrate_mvcc_copy(&legacy, &backup, &data)?;
            {
                let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&data)?;
                let session = db.connect(1)?;
                db.upgrade_catalog_format(&session)?;
            }
            println!("INITIALIZED {}", data.display());
        }
        Some("user-add-stdin") => {
            let auth = PathBuf::from(required(&mut args));
            let username = required(&mut args);
            let role = Role::parse(&required(&mut args))?;
            let mut password = String::new();
            std::io::stdin().read_line(&mut password)?;
            let password = password.trim_end_matches(['\r', '\n']);
            add_user(&auth, &username, password, role)?;
            println!("USER UPSERTED {username}");
        }
        Some("upgrade-community-copy") => {
            let source = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            let output = PathBuf::from(required(&mut args));
            let accept = match args.next().as_deref() {
                None => false,
                Some("--accept-v4") => true,
                _ => {
                    return Err(phobos_error::PhobosError::new(
                        phobos_error::ErrorCode::Semantic,
                        "unexpected upgrade option",
                    )
                    .into());
                }
            };
            let report = phobos_admin::upgrade_community_copy(&source, &backup, &output, accept)?;
            println!(
                "UPGRADED COPY catalog=5 tables={} indexes={}; source preserved",
                report.tables, report.indexes
            );
        }
        Some("migrate-mvcc-copy") => {
            let source = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            let destination = PathBuf::from(required(&mut args));
            let report = migrate_mvcc_copy(&source, &backup, &destination)?;
            println!(
                "MVCC COPY CREATED rows={} tables={} indexes={} backup_files={}",
                report.rows, report.tables, report.indexes, report.backup_files
            );
            println!(
                "Destination supports MVCC SQL reads and DML; C5 certification remains incomplete."
            );
        }
        Some("user-add") => {
            let auth = PathBuf::from(required(&mut args));
            let username = required(&mut args);
            let password = required(&mut args);
            let role = Role::parse(&required(&mut args))?;
            add_user(&auth, &username, &password, role)?;
            println!("USER UPSERTED {username} {}", role.as_str());
        }
        Some("user-remove") => {
            let auth = PathBuf::from(required(&mut args));
            let username = required(&mut args);
            println!("USER REMOVED {}", remove_user(&auth, &username)?);
        }
        Some("user-list") => {
            let auth = PathBuf::from(required(&mut args));
            for (username, role) in list_users(&auth)? {
                println!("{username}\t{}", role.as_str());
            }
        }
        Some("backup-base") => {
            let data = PathBuf::from(required(&mut args));
            let destination = PathBuf::from(required(&mut args));
            println!(
                "BASE BACKUP {:?}",
                phobos_admin::backup_base_offline(&data, &destination)?
            );
        }
        Some("backup") => {
            let data = PathBuf::from(required(&mut args));
            let dest = PathBuf::from(required(&mut args));
            println!("BACKUP {} FILES", backup_offline(&data, &dest)?);
        }
        Some("restore") => {
            let source = PathBuf::from(required(&mut args));
            let data = PathBuf::from(required(&mut args));
            println!("RESTORE {} FILES", restore_offline(&source, &data)?);
        }
        Some("check") => {
            let data = PathBuf::from(required(&mut args));
            let report = check_integrity(&data)?;
            println!(
                "INTEGRITY OK tables={} indexes={} index_pages={} index_live_entries={} index_stale_entries={} index_corrupt_entries=0 stale_ratio={:.4}",
                report.tables,
                report.indexes,
                report.index_pages,
                report.index_live_entries,
                report.index_stale_entries,
                report.index_stale_entries as f64
                    / (report.index_live_entries + report.index_stale_entries).max(1) as f64
            );
        }
        Some("storage-lifecycle") => {
            // 0.2-K Part N: storage-lifecycle diagnostics (read-only).
            let data = PathBuf::from(required(&mut args));
            let need = args
                .next()
                .map(|value| value.parse::<usize>())
                .transpose()?;
            let report = storage_lifecycle(&data, need)?;
            for table in &report.tables {
                println!(
                    "TABLE {} id={} heap_pages={} heap_bytes={} overflow_pages={} slots_total={} slots_occupied={} slots_retired={} slots_free={} slot_directory_bytes={} pages_slot_starved={} pages_all_free={} pages_accepting_rows={} free_bytes={} tuples_present={} dead_versions={} reclaimable_versions={} reclaim_candidate_pages={} row_need_bytes={} index_pages={} index_bytes={} index_entries={} index_free_pages={}",
                    table.table,
                    table.table_id,
                    table.heap_pages,
                    table.heap_bytes,
                    table.overflow_pages,
                    table.slots_total,
                    table.slots_occupied,
                    table.slots_retired,
                    table.slots_free,
                    table.slot_directory_bytes,
                    table.pages_slot_starved,
                    table.pages_all_free,
                    table.pages_accepting_rows,
                    table.free_bytes,
                    table.tuples_present,
                    table.dead_versions,
                    table.reclaimable_versions,
                    table.reclaim_candidate_pages,
                    table.row_need_bytes,
                    table.index_pages,
                    table.index_bytes,
                    table.index_entries,
                    table.index_free_pages,
                );
            }
            println!(
                "GLOBAL status_file_bytes={} status_file_allocated_bytes={} status_frozen_before={} wal_history_bytes={} wal_retained_bytes={} oldest_replication_slot={} published={} horizon={}",
                report.status_file_bytes,
                report.status_file_allocated_bytes,
                report.status_frozen_before,
                report.wal_history_bytes,
                report.wal_retained_bytes,
                report
                    .oldest_replication_slot
                    .as_ref()
                    .map_or_else(|| "none".into(), |(name, lsn)| format!("{name}@{lsn}")),
                report.published,
                report.horizon,
            );
            // 0.2-K.1: in-process maintenance fault (offline diagnostics
            // run in a fresh process, which never carries one).
            println!(
                "MAINTENANCE fault={}",
                report.maintenance_fault.as_deref().unwrap_or("none")
            );
        }
        Some("repair-overflow") => {
            // 0.2-I.1: offline repair of overflow pages holding ordinary tuples.
            let data = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            let dry_run = match args.next().as_deref() {
                None => false,
                Some("--dry-run") => true,
                Some(_) => usage(),
            };
            let report = repair_overflow(&data, &backup, dry_run)?;
            if report.tables.is_empty() {
                println!("OVERFLOW REPAIR: no damaged overflow pages found; nothing changed");
            }
            for table in &report.tables {
                println!(
                    "TABLE {} (id {}) HEAP {} pages {} -> {}",
                    table.table,
                    table.table_id,
                    table.heap_file,
                    table.pages_before,
                    table.pages_after
                );
                for violation in &table.violations {
                    println!("  DAMAGED {violation}");
                }
                for action in &table.actions {
                    println!(
                        "  {} {action}",
                        if report.dry_run { "WOULD" } else { "DID" }
                    );
                }
            }
            if let Some(integrity) = &report.integrity {
                println!(
                    "OVERFLOW REPAIR COMPLETE damaged_pages={} backup_files={}; INTEGRITY OK tables={} indexes={} index_pages={}",
                    report.damaged_pages(),
                    report.backup_files,
                    integrity.tables,
                    integrity.indexes,
                    integrity.index_pages
                );
                println!(
                    "NOTE: repair is not WAL-logged; take a new base backup and re-initialize any standby (old backups/WAL archives restore the damaged state)"
                );
            } else if report.dry_run && !report.tables.is_empty() {
                println!("DRY RUN: nothing changed");
            }
        }
        Some("migrate-page-lsn") => {
            let data = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            println!(
                "PAGE LSN MIGRATION COMPLETED; BACKUP {} FILES",
                migrate_page_lsn(&data, &backup)?
            );
        }
        Some("migrate-wal-v2") => {
            let data = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            println!(
                "WAL V2 MIGRATION COMPLETED; BACKUP {} FILES",
                migrate_wal_v2(&data, &backup)?
            );
        }
        Some("reindex") => {
            let data = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            let report = reindex_memcomparable(&data, &backup)?;
            println!(
                "REINDEX COMPLETED indexes={} backup_files={}",
                report.rebuilt, report.backup_files
            );
        }
        Some("replication-init") => {
            let primary = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            let standby = PathBuf::from(required(&mut args));
            let slot = required(&mut args);
            let state = initialize_standby(&primary, &backup, &standby, &slot)?;
            println!(
                "STANDBY INITIALIZED system_id={} replayed_lsn={}",
                state.system_id, state.last_replayed_lsn
            );
        }
        Some("replication-receive") => {
            let primary = PathBuf::from(required(&mut args));
            let standby = PathBuf::from(required(&mut args));
            let state = receive_wal(&primary, &standby)?;
            println!(
                "WAL DURABLE received_lsn={}",
                state.last_durable_received_lsn
            );
        }
        Some("replication-replay") => {
            let standby = PathBuf::from(required(&mut args));
            let state = replay_received(&standby)?;
            println!("WAL REPLAYED replayed_lsn={}", state.last_replayed_lsn);
        }
        Some("replication-status") => {
            // 0.2-I.2: read-only retention diagnostics.
            let primary = PathBuf::from(required(&mut args));
            let status = replication_status(&primary)?;
            println!(
                "WAL current_lsn={} checkpoint_lsn={} last_commit_lsn={} oldest_retained_lsn={} history_files={} history_bytes={} retained_files={} retained_bytes={}",
                status.current_lsn,
                status.checkpoint_lsn,
                status.last_commit_lsn,
                status.oldest_retained_lsn,
                status.history_files,
                status.history_bytes,
                status.retained_files,
                status.retained_bytes
            );
            for slot in &status.slots {
                println!(
                    "SLOT name={} protected_after_lsn={} lag_lsn={} pinned_files={} pinned_bytes={}",
                    slot.name,
                    slot.protected_after_lsn,
                    status
                        .last_commit_lsn
                        .saturating_sub(slot.protected_after_lsn),
                    slot.pinned_files,
                    slot.pinned_bytes
                );
            }
            if let Some(standby) = args.next() {
                let state = standby_state(&PathBuf::from(standby))?;
                println!(
                    "STANDBY slot={} received_lsn={} durable_received_lsn={} replayed_lsn={} replay_lag_lsn={}",
                    state.slot,
                    state.last_received_lsn,
                    state.last_durable_received_lsn,
                    state.last_replayed_lsn,
                    status
                        .last_commit_lsn
                        .saturating_sub(state.last_replayed_lsn)
                );
            }
        }
        Some("replication-slot-drop") => {
            let primary = PathBuf::from(required(&mut args));
            let slot = required(&mut args);
            let removed = drop_replication_slot(&primary, &slot)?;
            println!("SLOT DROPPED name={slot} existed={removed}");
            println!("NOTE: WAL it protected is released at the next checkpoint");
        }
        Some("wal-retain") => {
            let primary = PathBuf::from(required(&mut args));
            let backup = PathBuf::from(required(&mut args));
            let slot = required(&mut args);
            let lsn = retain_wal_for_backup(&primary, &backup, &slot)?;
            println!("WAL RETAINED slot={slot} protected_after_lsn={lsn}");
        }
        Some("wal-archive") => {
            let primary = PathBuf::from(required(&mut args));
            let archive = PathBuf::from(required(&mut args));
            println!("WAL ARCHIVED end_lsn={}", archive_wal(&primary, &archive)?);
        }
        Some("recover-to") => {
            let backup = PathBuf::from(required(&mut args));
            let wal = PathBuf::from(required(&mut args));
            let destination = PathBuf::from(required(&mut args));
            let target: u64 = required(&mut args).parse()?;
            let state = pitr_recover_to(&backup, &wal, &destination, target)?;
            println!("PITR COMPLETE target_lsn={}", state.last_replayed_lsn);
        }
        _ => usage(),
    }
    Ok(())
}

fn required(args: &mut impl Iterator<Item = String>) -> String {
    args.next().unwrap_or_else(|| usage())
}
fn usage() -> ! {
    eprintln!(
        "phobos-admin backup-base STOPPED_DATA NEW_BASE_BACKUP (checkpointed PITR/replication image)"
    );
    eprintln!("phobos-admin upgrade-community-copy SOURCE_DATA BACKUP NEW_DATA [--accept-v4]");
    eprintln!(
        "phobos-admin init INSTANCE_DIR | user-add-stdin AUTH_FILE USER ROLE (password on stdin)"
    );
    eprintln!(
        "phobos-admin migrate-mvcc-copy SOURCE_DATA_DIR EMPTY_BACKUP_DIR NEW_DESTINATION_DIR"
    );
    eprintln!("phobos-admin migrate-wal-v2 DATA_DIR EMPTY_BACKUP_DIR");
    eprintln!("phobos-admin migrate-page-lsn DATA_DIR EMPTY_BACKUP_DIR");
    eprintln!("phobos-admin reindex DATA_DIR EMPTY_BACKUP_DIR");
    eprintln!("phobos-admin repair-overflow DATA_DIR EMPTY_BACKUP_DIR [--dry-run]");
    eprintln!("phobos-admin replication-init PRIMARY_DATA ONLINE_BACKUP STANDBY_DATA SLOT");
    eprintln!("phobos-admin replication-receive PRIMARY_DATA STANDBY_DATA");
    eprintln!("phobos-admin replication-replay STANDBY_DATA");
    eprintln!("phobos-admin replication-status PRIMARY_DATA [STANDBY_DATA]");
    eprintln!("phobos-admin replication-slot-drop PRIMARY_DATA SLOT");
    eprintln!("phobos-admin wal-retain PRIMARY_DATA ONLINE_BACKUP SLOT");
    eprintln!("phobos-admin wal-archive PRIMARY_DATA EMPTY_ARCHIVE_DIR");
    eprintln!("phobos-admin recover-to ONLINE_BACKUP WAL_ARCHIVE EMPTY_DESTINATION TARGET_LSN");
    eprintln!(
        "phobos-admin user-add AUTH_FILE USER PASSWORD ROLE(reader|writer|admin)\nphobos-admin user-remove AUTH_FILE USER\nphobos-admin user-list AUTH_FILE\nphobos-admin backup DATA_DIR BACKUP_DIR\nphobos-admin restore BACKUP_DIR DATA_DIR\nphobos-admin check DATA_DIR"
    );
    process::exit(2)
}
