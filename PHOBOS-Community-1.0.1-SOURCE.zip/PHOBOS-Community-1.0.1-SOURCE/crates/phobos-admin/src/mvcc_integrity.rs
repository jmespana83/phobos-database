//! Recover an offline copy: integrity checking never repairs the source.
use super::*;
use phobos_index::{Bound, IndexKey};
use phobos_txn::mvcc::{SnapshotRegistry, Status, StatusFile, StatusLookup};
use phobos_wal::v2::FileId;
use std::sync::atomic::{AtomicU64, Ordering};

pub(super) fn is_versioned(directory: &Path) -> Result<bool, PhobosError> {
    let path = directory.join("phobos.wal");
    // 0.2-I.3: an interrupted segment rotation is judged by its validated
    // sealed history (the check recovers a scratch copy, never the source).
    if phobos_wal::v2::interrupted_rotation(directory)? {
        return Ok(phobos_wal::v2::inspect(path)?.page_format == 4);
    }
    if !path.exists() {
        return Ok(false);
    }
    let mut file = File::open(&path)?;
    if file.metadata()?.len() == 0 {
        return Ok(false);
    }
    let mut prefix = [0; 6];
    file.read_exact(&mut prefix)?;
    drop(file);
    Ok(&prefix[..4] == b"PHWL"
        && prefix[4..] == [2, 0]
        && phobos_wal::v2::inspect(path)?.page_format == 4)
}
struct Scratch(PathBuf);
impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
pub(super) fn check_locked(source: &Path) -> Result<IntegrityReport, PhobosError> {
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let path = std::env::temp_dir().join(format!(
        "phobos-integrity-{}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|_| invalid("invalid clock"))?
            .as_nanos(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    fs::create_dir(&path)?;
    let scratch = Scratch(path);
    for file in database_files(source)? {
        fs::copy(
            &file,
            scratch.0.join(
                file.file_name()
                    .ok_or_else(|| invalid("invalid filename"))?,
            ),
        )?;
    }
    // All recovery, catalog, heap, index and status handles are scoped inside
    // validate_copy; close them before removing the directory on Windows.
    let result = validate_copy(&scratch.0);
    let cleanup = fs::remove_dir_all(&scratch.0);
    match result {
        Err(error) => Err(error),
        Ok(report) => {
            cleanup?;
            Ok(report)
        }
    }
}
/// 0.2-K Part N: offline storage-lifecycle diagnostics. The source is never
/// opened for writing: an offline copy is recovered and inspected. The
/// status-file and WAL-retention figures are those of the source directory.
pub(super) fn lifecycle_locked(
    source: &Path,
    row_need: Option<usize>,
) -> Result<phobos_execution::mvcc_runtime::StorageLifecycleReport, PhobosError> {
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let path = std::env::temp_dir().join(format!(
        "phobos-lifecycle-{}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|_| invalid("invalid clock"))?
            .as_nanos(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    fs::create_dir(&path)?;
    let scratch = Scratch(path);
    for file in database_files(source)? {
        fs::copy(
            &file,
            scratch.0.join(
                file.file_name()
                    .ok_or_else(|| invalid("invalid filename"))?,
            ),
        )?;
    }
    let result = (|| -> Result<_, PhobosError> {
        let database = phobos_execution::mvcc_runtime::MvccDatabase::open(&scratch.0)?;
        let mut report = database.storage_lifecycle_report(row_need)?;
        drop(database);
        let status = fs::metadata(source.join("phobos.mvcc-status"))?;
        report.status_file_bytes = status.len();
        #[cfg(unix)]
        {
            use std::os::unix::fs::MetadataExt;
            report.status_file_allocated_bytes = status.blocks() * 512;
        }
        #[cfg(not(unix))]
        {
            report.status_file_allocated_bytes = status.len();
        }
        let retention = phobos_wal::v2::retention_report(source)?;
        report.wal_history_bytes = retention.bytes;
        report.wal_retained_bytes = retention.retained_bytes;
        report.oldest_replication_slot =
            retention.slots.iter().min_by_key(|(_, lsn)| *lsn).cloned();
        Ok(report)
    })();
    let cleanup = fs::remove_dir_all(&scratch.0);
    let report = result?;
    cleanup?;
    Ok(report)
}

fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}
fn committed(statuses: &mut StatusFile, transaction: u64) -> Result<u64, PhobosError> {
    match statuses.status(transaction)? {
        Status::Committed { sequence } => Ok(sequence),
        _ => Err(invalid(
            "persisted tuple refers to an uncommitted transaction",
        )),
    }
}
fn validate_copy(directory: &Path) -> Result<IntegrityReport, PhobosError> {
    let (mut statuses, _wal) = StatusFile::recover_database(directory)?;
    for name in ["catalog.phc", "indexes.phc"] {
        if !directory.join(name).is_file() {
            return Err(invalid("MVCC catalog is missing after WAL recovery"));
        }
    }
    let catalog = Catalog::open(directory)?;
    let mut snapshots = SnapshotRegistry::new(statuses.durable_frontier(), 1)?;
    let pin = snapshots.pin(None)?;
    let mut report = IntegrityReport {
        tables: 0,
        indexes: 0,
        index_pages: 0,
        index_live_entries: 0,
        index_stale_entries: 0,
    };
    // 0.2-K.4: under LAZY_INDEX_PRUNING_V1 a non-unique index may hold stale
    // entries (RID names a RETIRED/FREE/trimmed slot, or a reused slot whose
    // occupant has another key). They are legal; anything unclassifiable is
    // still corruption. UNIQUE indexes stay strict.
    let lazy = catalog.lazy_index_pruning();
    for table in catalog.tables() {
        let path = directory.join(FileId::Heap(table.id).name());
        if !path.is_file() {
            return Err(invalid("catalog heap is missing"));
        }
        // 0.2-I.1: an overflow page may never hold an ordinary heap tuple.
        // Read-only audit of every page; reported before any tuple decoding
        // so the failure names the damage instead of a downstream symptom.
        let violations = phobos_storage::overflow_safety::scan_overflow_violations(&path)?;
        if !violations.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                format!(
                    "overflow page invariant violated: table '{}' (id {}), heap file {}, {} damaged page(s): {}; repair offline with `phobos-admin repair-overflow`",
                    table.name,
                    table.id,
                    FileId::Heap(table.id).name(),
                    violations.len(),
                    violations
                        .iter()
                        .map(ToString::to_string)
                        .collect::<Vec<_>>()
                        .join("; ")
                ),
            ));
        }
        let mut heap = HeapTable::open_versioned(&path, table.clone(), 8)?;
        let mut lookup = HeapTable::open_versioned(&path, table.clone(), 8)?;
        let mut indexes = Vec::new();
        for definition in catalog.indexes_for_table(table.id) {
            let path = directory.join(FileId::Index(definition.id).name());
            if !path.is_file() {
                return Err(invalid("catalog index is missing"));
            }
            let mut tree = BPlusTree::open(path, definition.unique, definition.columns.len())?;
            report.index_pages += tree.validate()?.pages;
            report.indexes += 1;
            let columns = definition
                .columns
                .iter()
                .map(|name| {
                    table
                        .column_index(name)
                        .ok_or_else(|| invalid("index column is missing"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let mut last_visible_key = None;
            let lazy_index = lazy && !definition.unique;
            let (mut live, mut stale) = (0u64, 0u64);
            tree.inspect_entries(|key, rid| {
                let Some((tuple, row)) = lookup.get_version(rid)? else {
                    if lazy_index && lookup.slot_reclaimed(rid)? {
                        stale += 1;
                        return Ok(true);
                    }
                    return Err(invalid("index references missing tuple"));
                };
                let expected = IndexKey(
                    columns
                        .iter()
                        .map(|column| row.values[*column].clone())
                        .collect(),
                );
                if key != &expected {
                    if lazy_index {
                        stale += 1;
                        return Ok(true);
                    }
                    return Err(invalid("index key differs from tuple"));
                }
                live += 1;
                if pin.snapshot().visible(tuple.visibility, &mut statuses)?
                    && definition.unique
                    && !key.contains_null()
                {
                    if last_visible_key.as_ref() == Some(key) {
                        return Err(invalid("duplicate visible unique key"));
                    }
                    last_visible_key = Some(key.clone());
                }
                Ok(true)
            })?;
            report.index_live_entries += live;
            report.index_stale_entries += stale;
            indexes.push((tree, columns));
        }
        heap.scan_versions(|rid, tuple, row| {
            if pin.snapshot().visible(tuple.visibility, &mut statuses)? {
                if table
                    .columns
                    .iter()
                    .zip(&row.values)
                    .any(|(c, v)| !c.nullable && v.is_null())
                {
                    return Err(invalid("visible row violates NOT NULL"));
                }
                catalog.validate_row_definitions(table.id, &row)?;
            }
            let sequence = committed(&mut statuses, tuple.visibility.creator)?;
            if let Some(deleter) = tuple.visibility.deleter {
                if committed(&mut statuses, deleter)? <= sequence {
                    return Err(invalid("tuple deletion precedes creation"));
                }
            }
            if let Some(previous) = tuple.previous {
                // 0.2-K Part I. `previous` is advisory history: no execution
                // path dereferences it. The predecessor P of child C (creator
                // c, commit sequence s_c) was deleted by c, so it can be
                // reclaimed only after c committed, and its slot can be
                // reused only by a transaction committing after that. The
                // accepted states of the slot `previous` names are exactly:
                //  (a) the true predecessor: same logical row, deleter == c,
                //      created strictly before s_c (strict descent also
                //      excludes cycles);
                //  (b) empty: RETIRED, FREE, or past the end of a trimmed or
                //      reset directory (reclaimed predecessor);
                //  (c) a LATER occupant of a reused slot: committed strictly
                //      after s_c, and not shaped like a predecessor of C.
                // Anything else (a different row created at or before s_c, a
                // "predecessor" created after its successor, an overflow
                // page, a page beyond the heap, a self-reference) remains
                // "invalid tuple version chain" / "tuple predecessor is
                // missing".
                match lookup.get_version(previous)? {
                    Some((parent, _)) => {
                        let parent_sequence = committed(&mut statuses, parent.visibility.creator)?;
                        let predecessor_shape = parent.logical_row == tuple.logical_row
                            && parent.visibility.deleter == Some(tuple.visibility.creator);
                        let true_predecessor = predecessor_shape && parent_sequence < sequence;
                        let later_occupant = !predecessor_shape && parent_sequence > sequence;
                        if !true_predecessor && !later_occupant {
                            return Err(invalid("invalid tuple version chain"));
                        }
                    }
                    None => {
                        if !lookup.slot_reclaimed(previous)? {
                            return Err(invalid("tuple predecessor is missing"));
                        }
                    }
                }
            }
            for (tree, columns) in &mut indexes {
                let key = IndexKey(
                    columns
                        .iter()
                        .map(|column| row.values[*column].clone())
                        .collect(),
                );
                let mut references = 0;
                tree.range_visit(Bound::Included(&key), Bound::Included(&key), |candidate| {
                    references += usize::from(candidate == rid);
                    Ok(true)
                })?;
                if references != 1 {
                    return Err(invalid("tuple must have exactly one matching index entry"));
                }
            }
            Ok(true)
        })?;
        report.tables += 1;
    }
    let mut live_rows = |id| {
        let table = catalog
            .tables()
            .find(|t| t.id == id)
            .ok_or_else(|| invalid("FK table missing"))?;
        let mut heap =
            HeapTable::open_versioned(directory.join(FileId::Heap(id).name()), table.clone(), 8)?;
        let mut rows = Vec::new();
        heap.scan_versions(|_, tuple, row| {
            if pin.snapshot().visible(tuple.visibility, &mut statuses)? {
                rows.push(row);
            }
            Ok(true)
        })?;
        Ok(rows)
    };
    catalog.validate_identity_rows(&mut live_rows)?;
    catalog.validate_foreign_key_rows(&mut live_rows)?;

    snapshots.release(pin)?;
    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_types::{RecordId, Row, Value};
    use phobos_wal::v2::Wal;

    #[test]
    fn offline_check_recovers_segmented_post_crash_copy_and_rejects_corrupt_wal() {
        let root = std::env::temp_dir().join(format!(
            "phobos-integrity-post-crash-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir(&root).unwrap();
        let legacy = root.join("legacy");
        let mut legacy_db = Database::open(&legacy).unwrap();
        legacy_db
            .execute("CREATE TABLE t (id BIGINT NOT NULL, value TEXT)")
            .unwrap();
        legacy_db
            .execute("CREATE UNIQUE INDEX t_id ON t(id)")
            .unwrap();
        legacy_db
            .execute("INSERT INTO t VALUES (1,'one'),(2,'two')")
            .unwrap();
        legacy_db.shutdown().unwrap();
        drop(legacy_db);
        let source = root.join("source");
        migrate_mvcc_copy(&legacy, &root.join("legacy-backup"), &source).unwrap();
        let mut wal = Wal::open(&source).unwrap();
        wal.rotate_segment_for_test().unwrap();
        drop(wal);
        let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&source).unwrap();
        db.execute(1, "INSERT INTO t VALUES (3,'three')").unwrap();
        db.disconnect(1);
        // Dropping without shutdown models a terminated server: committed WAL
        // may still be ahead of its checkpoint, but all file handles are closed.
        drop(db);

        let segment = database_files(&source)
            .unwrap()
            .into_iter()
            .find(|path| {
                path.file_name()
                    .and_then(|name| name.to_str())
                    .is_some_and(|name| name.starts_with("phobos.wal.") && name.ends_with(".seg"))
            })
            .expect("sealed WAL segment included in offline image");
        let original = database_files(&source)
            .unwrap()
            .into_iter()
            .map(|path| {
                let bytes = fs::read(&path).unwrap();
                (path, bytes)
            })
            .collect::<Vec<_>>();
        let report = check_integrity(&source).unwrap();
        assert_eq!((report.tables, report.indexes), (1, 1));
        for (path, bytes) in &original {
            assert_eq!(&fs::read(path).unwrap(), bytes, "CHECK mutated source");
        }

        let corrupt = root.join("corrupt");
        fs::create_dir(&corrupt).unwrap();
        for (path, bytes) in &original {
            fs::write(corrupt.join(path.file_name().unwrap()), bytes).unwrap();
        }
        let corrupt_segment = corrupt.join(segment.file_name().unwrap());
        let mut bytes = fs::read(&corrupt_segment).unwrap();
        let offset = bytes.len() / 2;
        bytes[offset] ^= 0x5a;
        fs::write(corrupt_segment, bytes).unwrap();
        assert!(check_integrity(&corrupt).is_err());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn mvcc_integrity_rejects_corrupt_status_links_and_index_references_without_repair() {
        let root = std::env::temp_dir().join(format!(
            "phobos-integrity-negative-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir(&root).unwrap();
        let source = root.join("legacy");
        let mut db = Database::open(&source).unwrap();
        db.execute("CREATE TABLE t (id BIGINT)").unwrap();
        db.execute("CREATE UNIQUE INDEX u ON t(id)").unwrap();
        db.execute("INSERT INTO t VALUES (1),(2)").unwrap();
        db.shutdown().unwrap();
        drop(db);
        let capable = root.join("capable");
        migrate_mvcc_copy(&source, &root.join("legacy-backup"), &capable).unwrap();
        let db = phobos_execution::mvcc_runtime::MvccDatabase::open(&capable).unwrap();
        db.execute(1, "UPDATE t SET id=3 WHERE id=1").unwrap();
        db.disconnect(1);
        db.shutdown(std::time::Duration::from_secs(10)).unwrap();
        drop(db);
        check_integrity(&capable).unwrap();
        backup_offline(&capable, &root.join("backup")).unwrap();
        for defect in [
            "missing-heap",
            "missing-index",
            "missing-catalog",
            "missing-index-catalog",
            "status",
            "wrong-key",
            "dangling",
            "missing-entry",
            "chain",
        ] {
            let dir = root.join(defect);
            restore_offline(&root.join("backup"), &dir).unwrap();
            let catalog = Catalog::open(&dir).unwrap();
            let table = catalog.table("t").unwrap().clone();
            let definition = catalog.index("u").unwrap().clone();
            drop(catalog);
            let heap_path = dir.join(FileId::Heap(table.id).name());
            let index_path = dir.join(FileId::Index(definition.id).name());
            match defect {
                "missing-catalog" => fs::remove_file(dir.join("catalog.phc")).unwrap(),
                "missing-index-catalog" => fs::remove_file(dir.join("indexes.phc")).unwrap(),
                "missing-heap" => fs::remove_file(&heap_path).unwrap(),
                "missing-index" => fs::remove_file(&index_path).unwrap(),
                "status" => {
                    let path = dir.join("phobos.mvcc-status");
                    let mut bytes = fs::read(&path).unwrap();
                    bytes[32] ^= 1;
                    fs::write(path, bytes).unwrap();
                }
                "chain" => {
                    let mut heap = HeapTable::open_versioned(&heap_path, table, 2).unwrap();
                    let mut first = None;
                    heap.scan_versions(|rid, tuple, _| {
                        first = Some((rid, tuple));
                        Ok(false)
                    })
                    .unwrap();
                    let (rid, mut tuple) = first.unwrap();
                    tuple.previous = Some(rid);
                    tuple.visibility.deleter = None;
                    heap.insert_version(tuple, &Row::new(vec![Value::Int64(8)]))
                        .unwrap();
                    heap.flush().unwrap();
                }
                _ => {
                    let mut tree = BPlusTree::open(&index_path, true, 1).unwrap();
                    let key = IndexKey(vec![Value::Int64(3)]);
                    let rid = tree.point_lookup(&key).unwrap()[0];
                    if defect != "dangling" {
                        assert!(tree.delete(&key, rid).unwrap());
                    }
                    if defect == "wrong-key" {
                        tree.insert(IndexKey(vec![Value::Int64(8)]), rid).unwrap();
                    }
                    if defect == "dangling" {
                        tree.insert(
                            IndexKey(vec![Value::Int64(9)]),
                            RecordId {
                                page_id: 9999,
                                slot_id: 0,
                            },
                        )
                        .unwrap();
                    }
                    tree.sync().unwrap();
                }
            }
            let image = database_files(&dir)
                .unwrap()
                .into_iter()
                .map(|path| {
                    let bytes = fs::read(&path).unwrap();
                    (path, bytes)
                })
                .collect::<Vec<_>>();
            assert!(check_integrity(&dir).is_err(), "accepted {defect}");
            for (path, bytes) in image {
                assert_eq!(fs::read(path).unwrap(), bytes, "repaired {defect}");
            }
        }
        fs::remove_dir_all(root).unwrap();
    }
}
