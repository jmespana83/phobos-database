//! 0.2-K Storage Lifecycle V1 through the administration paths: online
//! backup, PITR, physical replication and standby reads of databases whose
//! heap slots are reclaimed, freed and reused; `previous`-pointer integrity
//! rules (Part I); offline diagnostics (Part N); status prefix release
//! (Part M).
use super::*;
use phobos_execution::QueryResult;
use phobos_execution::mvcc_runtime::MvccDatabase;
use phobos_types::Value;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

fn temp(label: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "phobos-k-{label}-{}-{}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}

fn scalar(database: &MvccDatabase, sql: &str) -> i64 {
    match database.execute(90, sql).unwrap() {
        QueryResult::Rows { rows, .. } => match rows.first().map(|row| &row.values[0]) {
            Some(Value::Int64(value)) => *value,
            Some(Value::Null) | None => 0,
            other => panic!("{other:?}"),
        },
        other => panic!("{other:?}"),
    }
}

/// Fingerprint of the logical content: (count, Σid, Σv, Σ(id*v) mod 2^61).
fn fingerprint(database: &MvccDatabase) -> (i64, i64, i64) {
    (
        scalar(database, "SELECT COUNT(*) AS n FROM t"),
        scalar(database, "SELECT SUM(id) AS s FROM t"),
        scalar(database, "SELECT SUM(v) AS s FROM t"),
    )
}

/// MVCC primary with `t(id unique, k, v)` and `rows` rows.
fn primary(root: &Path, rows: i64) -> PathBuf {
    let legacy = root.join("legacy");
    let primary = root.join("primary");
    {
        let mut database = Database::open(&legacy).unwrap();
        database
            .execute("CREATE TABLE t (id BIGINT NOT NULL, k BIGINT, v BIGINT, pad TEXT)")
            .unwrap();
        database
            .execute("CREATE UNIQUE INDEX t_id ON t(id)")
            .unwrap();
        database.execute("CREATE INDEX t_k ON t(k)").unwrap();
        let mut id = 1;
        while id <= rows {
            let end = (id + 199).min(rows);
            let values = (id..=end)
                .map(|id| format!("({id},{},{id},'{}')", id % 5, "p".repeat(24)))
                .collect::<Vec<_>>()
                .join(",");
            database
                .execute(&format!("INSERT INTO t VALUES {values}"))
                .unwrap();
            id = end + 1;
        }
    }
    migrate_mvcc_copy(&legacy, &root.join("migration-backup"), &primary).unwrap();
    primary
}

/// One churn round: update, delete+insert, two reclaim passes separated by
/// a publication (so phase 2 frees what phase 1 retired), then inserts that
/// reuse FREE slots. Returns slots freed in the round.
fn churn(database: &MvccDatabase, round: i64) -> usize {
    database
        .execute(1, &format!("UPDATE t SET v=v+1 WHERE k={}", round % 5))
        .unwrap();
    database
        .execute(
            1,
            &format!(
                "DELETE FROM t WHERE id>={} AND id<{}",
                round * 1000 + 1,
                round * 1000 + 30
            ),
        )
        .unwrap();
    let mut freed = 0;
    for step in 0..4 {
        let report = database.reclaim_once(256).unwrap();
        freed += report.slots_freed;
        database
            .execute(
                1,
                &format!(
                    "INSERT INTO t VALUES ({}, 0, 0, 'm')",
                    500_000 + round * 100 + step
                ),
            )
            .unwrap();
    }
    let values = (0..30)
        .map(|n| format!("({},{},{},'r')", 1_000_000 + round * 100 + n, n % 5, n))
        .collect::<Vec<_>>()
        .join(",");
    database
        .execute(1, &format!("INSERT INTO t VALUES {values}"))
        .unwrap();
    freed
}

fn restart(database: MvccDatabase, path: &Path) -> MvccDatabase {
    database.disconnect(1);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    MvccDatabase::open(path).unwrap()
}

fn open_fingerprint(path: &Path) -> (i64, i64, i64) {
    let database = MvccDatabase::open(path).unwrap();
    let result = fingerprint(&database);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    result
}

/// Part O 20, 21, 22, 23, 28: online backup, WAL retention, PITR, physical
/// replication and standby reads reproduce reused slots exactly.
#[test]
fn k_backup_pitr_replication_and_standby_reads_reproduce_reused_slots() {
    let root = temp("replication");
    let primary = primary(&root, 3000);
    let backup = root.join("backup");
    let standby = root.join("standby");
    let archive = root.join("archive");
    let mut database = MvccDatabase::open(&primary).unwrap();
    database.backup_online(&backup).unwrap();
    // A lagging standby slot and a PITR slot protect the WAL (0.2-I.2).
    initialize_standby(&primary, &backup, &standby, "standby-a").unwrap();
    retain_wal_for_backup(&primary, &backup, "pitr-base").unwrap();
    let mut targets = Vec::new();
    let mut freed = 0;
    for round in 1..=8 {
        freed += churn(&database, round);
        targets.push((database.wal_position().unwrap().1, fingerprint(&database)));
        if round == 3 {
            // Standby receives and replays mid-way (while the primary runs).
            receive_wal(&primary, &standby).unwrap();
            replay_received(&standby).unwrap();
            assert_eq!(open_fingerprint(&standby), targets[2].1);
        }
        if round % 4 == 0 {
            database = restart(database, &primary);
        }
    }
    assert!(freed > 50, "the workload must exercise slot reuse: {freed}");
    let final_print = fingerprint(&database);
    // Standby catches up across reuse; its reads equal the primary's.
    receive_wal(&primary, &standby).unwrap();
    replay_received(&standby).unwrap();
    assert_eq!(open_fingerprint(&standby), final_print);
    check_integrity(&standby).unwrap();
    // Standby read path through the SQL statement layer, including indexes.
    {
        let replica = MvccDatabase::open(&standby).unwrap();
        for id in [5, 1_000_105, 2_000, 1_000_801] {
            let sql = format!("SELECT COUNT(*) AS n FROM t WHERE id={id}");
            assert_eq!(scalar(&replica, &sql), scalar(&database, &sql), "{sql}");
        }
        assert_eq!(
            scalar(&replica, "SELECT COUNT(*) AS n FROM t WHERE k=3"),
            scalar(&database, "SELECT COUNT(*) AS n FROM t WHERE k=3")
        );
        replica.disconnect(90);
        replica.shutdown(Duration::from_secs(10)).unwrap();
    }
    // PITR to every round boundary (before and after reuse).
    archive_wal(&primary, &archive).unwrap();
    for (index, (target, print)) in targets.iter().enumerate() {
        let destination = root.join(format!("pitr-{index}"));
        let state = pitr_recover_to(&backup, &archive, &destination, *target).unwrap();
        assert_eq!(state.last_replayed_lsn, *target);
        assert_eq!(open_fingerprint(&destination), *print, "PITR round {index}");
        check_integrity(&destination).unwrap();
    }
    database.disconnect(1);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    check_integrity(&primary).unwrap();
    fs::remove_dir_all(root).unwrap();
}

/// K.5: exact WAL cut points around RETIRE/FREE retain logical visibility,
/// and replaying the same received lifecycle WAL twice is idempotent.
#[test]
fn k5_lifecycle_pitr_boundaries_and_replay_are_idempotent() {
    let root = temp("k5-boundaries");
    let primary = primary(&root, 300);
    let backup = root.join("backup");
    let standby = root.join("standby");
    let archive = root.join("archive");
    let database = MvccDatabase::open(&primary).unwrap();
    database.backup_online(&backup).unwrap();
    initialize_standby(&primary, &backup, &standby, "k5-standby").unwrap();
    retain_wal_for_backup(&primary, &backup, "k5-pitr").unwrap();
    database
        .execute(1, "UPDATE t SET v=v+1 WHERE id<=100")
        .unwrap();
    let mut targets = vec![(database.wal_position().unwrap().1, fingerprint(&database))];
    let retired = database.reclaim_once(256).unwrap();
    assert_eq!(retired.versions_reclaimed, 100);
    targets.push((database.wal_position().unwrap().1, fingerprint(&database)));
    database
        .execute(1, "INSERT INTO t VALUES (999,0,0,'marker')")
        .unwrap();
    targets.push((database.wal_position().unwrap().1, fingerprint(&database)));
    let freed = database.reclaim_once(256).unwrap();
    assert_eq!(freed.slots_freed, 100);
    targets.push((database.wal_position().unwrap().1, fingerprint(&database)));
    database.checkpoint().unwrap();
    receive_wal(&primary, &standby).unwrap();
    replay_received(&standby).unwrap();
    replay_received(&standby).unwrap();
    assert_eq!(open_fingerprint(&standby), fingerprint(&database));
    check_integrity(&standby).unwrap();
    archive_wal(&primary, &archive).unwrap();
    for (index, (target, expected)) in targets.iter().enumerate() {
        let destination = root.join(format!("boundary-{index}"));
        pitr_recover_to(&backup, &archive, &destination, *target).unwrap();
        assert_eq!(open_fingerprint(&destination), *expected);
        // A second restart must not apply the lifecycle change twice.
        assert_eq!(open_fingerprint(&destination), *expected);
        check_integrity(&destination).unwrap();
    }
    database.disconnect(1);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    fs::remove_dir_all(root).unwrap();
}

/// Part J: a standby never replays while it serves. `replication-replay`
/// takes the data-directory lock that a serving standby holds, so no standby
/// statement can observe a slot changing under it; after replay, a restarted
/// standby reads the reused slots as the primary does.
#[test]
fn k_standby_replay_is_excluded_while_the_standby_serves() {
    let root = temp("standby-lock");
    let primary = primary(&root, 500);
    let backup = root.join("backup");
    let standby = root.join("standby");
    let database = MvccDatabase::open(&primary).unwrap();
    database.backup_online(&backup).unwrap();
    initialize_standby(&primary, &backup, &standby, "standby-a").unwrap();
    for round in 1..=3 {
        churn(&database, round);
    }
    receive_wal(&primary, &standby).unwrap();
    // A serving standby holds the data-directory lock (as the server does).
    let serving = File::create(standby.join("phobos.lock")).unwrap();
    fs2::FileExt::lock_exclusive(&serving).unwrap();
    let error = replay_received(&standby).unwrap_err();
    assert_eq!(error.code, ErrorCode::DataDirectoryLocked, "{error:?}");
    drop(serving);
    replay_received(&standby).unwrap();
    assert_eq!(open_fingerprint(&standby), fingerprint(&database));
    database.disconnect(1);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    fs::remove_dir_all(root).unwrap();
}

/// Part I: `previous` pointers that name FREE, trimmed/reset or reused
/// slots pass integrity; real chain corruption is still reported.
#[test]
fn k_previous_pointer_rule_accepts_reuse_and_still_rejects_corruption() {
    let root = temp("previous");
    let primary = primary(&root, 200);
    let database = MvccDatabase::open(&primary).unwrap();
    // Hot updates: successors' `previous` chain through slots that are
    // retired, freed, trimmed and reused by later versions of the same rows.
    for round in 0..60 {
        database
            .execute(1, "UPDATE t SET v=v+1 WHERE id<=40")
            .unwrap();
        if round % 3 == 2 {
            for step in 0..3 {
                database.reclaim_once(256).unwrap();
                database
                    .execute(
                        1,
                        &format!(
                            "INSERT INTO t VALUES ({}, 0, 0, 'x')",
                            10_000 + round * 10 + step
                        ),
                    )
                    .unwrap();
            }
        }
    }
    let report = database.storage_lifecycle_report(None).unwrap();
    assert!(report.reclaim.slots_freed > 0, "{report:?}");
    database.disconnect(1);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    check_integrity(&primary).unwrap();
    // Corruption: a successor whose `previous` names an older, unrelated live
    // row (created before it, not its predecessor) is still invalid.
    let backup = root.join("offline");
    backup_offline(&primary, &backup).unwrap();
    let damaged = root.join("damaged");
    restore_offline(&backup, &damaged).unwrap();
    let catalog = Catalog::open(&damaged).unwrap();
    let table = catalog.table("t").unwrap().clone();
    drop(catalog);
    let heap_path = damaged.join(phobos_wal::v2::FileId::Heap(table.id).name());
    let mut heap = HeapTable::open_versioned(&heap_path, table.clone(), 4).unwrap();
    let mut old = None;
    let mut newest = None;
    heap.scan_versions(|rid, tuple, row| {
        if old.is_none() {
            old = Some((rid, tuple));
        }
        if newest.as_ref().is_none_or(
            |(_, version, _): &(_, phobos_storage::tuple_version::TupleVersion, _)| {
                tuple.visibility.creator > version.visibility.creator
            },
        ) {
            newest = Some((rid, tuple, row));
        }
        Ok(true)
    })
    .unwrap();
    let (old_rid, old_tuple) = old.unwrap();
    let (_, mut forged, row) = newest.unwrap();
    assert_ne!(forged.logical_row, old_tuple.logical_row);
    forged.previous = Some(old_rid);
    forged.logical_row += 1_000_000;
    heap.insert_version(forged, &row).unwrap();
    heap.flush().unwrap();
    drop(heap);
    let error = check_integrity(&damaged).unwrap_err();
    assert!(
        error.message.contains("invalid tuple version chain")
            || error.message.contains("exactly one matching index entry"),
        "{error:?}"
    );
    fs::remove_dir_all(root).unwrap();
}

/// Part N: offline diagnostics report the slot census, backlog, index and
/// status/WAL figures without changing the source directory.
#[test]
fn k_storage_lifecycle_diagnostics_are_read_only_and_complete() {
    let root = temp("diagnostics");
    let primary = primary(&root, 1000);
    let database = MvccDatabase::open(&primary).unwrap();
    for round in 1..=3 {
        churn(&database, round);
    }
    database.execute(1, "DELETE FROM t WHERE id<=100").unwrap();
    database.reclaim_once(256).unwrap();
    database.disconnect(1);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    let image = database_files(&primary)
        .unwrap()
        .into_iter()
        .map(|path| {
            let bytes = fs::read(&path).unwrap();
            (path, bytes)
        })
        .collect::<Vec<_>>();
    let report = storage_lifecycle(&primary, None).unwrap();
    for (path, bytes) in image {
        assert_eq!(
            fs::read(&path).unwrap(),
            bytes,
            "diagnostics mutated {path:?}"
        );
    }
    let table = report
        .tables
        .iter()
        .find(|table| table.table == "t")
        .unwrap();
    assert_eq!(
        table.slots_total,
        table.slots_occupied + table.slots_retired + table.slots_free
    );
    assert_eq!(table.slot_directory_bytes, table.slots_total * 4);
    assert!(table.heap_pages > 0 && table.heap_bytes == table.heap_pages * 8192);
    assert!(table.index_entries >= table.tuples_present * 2);
    assert!(table.slots_retired > 0, "{table:?}");
    assert!(report.status_file_bytes > 0);
    assert!(report.status_file_allocated_bytes > 0);
    fs::remove_dir_all(root).unwrap();
}

/// Part M: the logically frozen status prefix is released physically
/// (sparse rewrite, same format) and the database stays fully usable and
/// recoverable; a crash leaves the temporary copy, which recovery removes.
#[cfg(unix)]
#[test]
fn k_status_prefix_release_is_physical_crash_safe_and_format_neutral() {
    use std::os::unix::fs::MetadataExt;
    let root = temp("status-trim");
    let primary = primary(&root, 50);
    let database = MvccDatabase::open(&primary).unwrap();
    // First 15,000 write transactions with the default release threshold
    // (4 MiB of releasable records: nothing is released yet).
    for n in 0..15_000i64 {
        database
            .execute(1, &format!("UPDATE t SET v={n} WHERE id={}", n % 50 + 1))
            .unwrap();
        if n % 2000 == 1999 {
            database.reclaim_once(256).unwrap();
        }
    }
    let unreleased = fs::metadata(primary.join("phobos.mvcc-status")).unwrap();
    assert!(unreleased.blocks() * 512 >= unreleased.len() - 8192);
    // Then with a small threshold: the frozen prefix is released as the
    // logical freeze advances (reclaim passes run it on an idle database).
    database.set_status_trim_threshold(1000).unwrap();
    for n in 15_000..30_000i64 {
        database
            .execute(1, &format!("UPDATE t SET v={n} WHERE id={}", n % 50 + 1))
            .unwrap();
        if n % 2000 == 1999 {
            database.reclaim_once(256).unwrap();
        }
    }
    for _ in 0..20 {
        database.reclaim_once(1024).unwrap();
    }
    database.disconnect(1);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    let status = primary.join("phobos.mvcc-status");
    let before = fs::metadata(&status).unwrap();
    let report = storage_lifecycle(&primary, None).unwrap();
    assert!(report.status_frozen_before > 25_000, "{report:?}");
    // Fixed-address format: the apparent length keeps one record per
    // identity; the released prefix no longer occupies disk blocks.
    assert_eq!(before.len(), report.status_file_bytes);
    assert!(before.len() >= 30_000 * 32);
    assert!(
        before.blocks() * 512 < before.len() / 4,
        "allocated {} of {} bytes",
        before.blocks() * 512,
        before.len()
    );
    // Crash shape: a leftover temporary copy is ignored and removed.
    fs::write(primary.join("phobos.mvcc-status.compact"), b"junk").unwrap();
    let database = MvccDatabase::open(&primary).unwrap();
    assert!(!primary.join("phobos.mvcc-status.compact").exists());
    assert_eq!(scalar(&database, "SELECT COUNT(*) AS n FROM t"), 50);
    database
        .execute(1, "UPDATE t SET v=v+1 WHERE id=1")
        .unwrap();
    database.disconnect(1);
    database.disconnect(90);
    drop(database); // crash: no shutdown
    let database = MvccDatabase::open(&primary).unwrap();
    assert_eq!(scalar(&database, "SELECT COUNT(*) AS n FROM t"), 50);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    check_integrity(&primary).unwrap();
    fs::remove_dir_all(root).unwrap();
}

/// Part M with Part O 20-22: online backup, a lagging standby and PITR
/// across physical releases of the frozen status prefix (released before
/// and after the backup), with restarts in between.
#[cfg(unix)]
#[test]
fn k_status_prefix_release_preserves_backup_pitr_and_replication() {
    use std::os::unix::fs::MetadataExt;
    let root = temp("status-trim-replication");
    let primary = primary(&root, 50);
    let backup = root.join("backup");
    let standby = root.join("standby");
    let archive = root.join("archive");
    let mut database = MvccDatabase::open(&primary).unwrap();
    database.set_status_trim_threshold(500).unwrap();
    let write = |database: &MvccDatabase, from: i64, to: i64| {
        for n in from..to {
            database
                .execute(1, &format!("UPDATE t SET v={n} WHERE id={}", n % 50 + 1))
                .unwrap();
            if n % 1000 == 999 {
                database.reclaim_once(256).unwrap();
            }
        }
    };
    // Released before the backup.
    write(&database, 0, 6_000);
    let released_before = database.freeze_metrics().unwrap().0;
    assert!(released_before > 3_000, "{released_before}");
    database.backup_online(&backup).unwrap();
    initialize_standby(&primary, &backup, &standby, "standby-a").unwrap();
    retain_wal_for_backup(&primary, &backup, "pitr-base").unwrap();
    let mut targets = Vec::new();
    for round in 0..4i64 {
        write(&database, 6_000 + round * 3_000, 9_000 + round * 3_000);
        targets.push((database.wal_position().unwrap().1, fingerprint(&database)));
        if round == 1 {
            database = restart(database, &primary);
            database.set_status_trim_threshold(500).unwrap();
        }
    }
    database.set_status_trim_threshold(500).unwrap();
    for _ in 0..10 {
        database.reclaim_once(1024).unwrap();
    }
    let final_print = fingerprint(&database);
    let status = fs::metadata(primary.join("phobos.mvcc-status")).unwrap();
    assert!(
        status.blocks() * 512 < status.len() / 2,
        "prefix released: allocated {} of {}",
        status.blocks() * 512,
        status.len()
    );
    receive_wal(&primary, &standby).unwrap();
    replay_received(&standby).unwrap();
    assert_eq!(open_fingerprint(&standby), final_print);
    check_integrity(&standby).unwrap();
    archive_wal(&primary, &archive).unwrap();
    for (index, (target, print)) in targets.iter().enumerate() {
        let destination = root.join(format!("pitr-{index}"));
        let state = pitr_recover_to(&backup, &archive, &destination, *target).unwrap();
        assert_eq!(state.last_replayed_lsn, *target);
        assert_eq!(open_fingerprint(&destination), *print, "PITR {index}");
        check_integrity(&destination).unwrap();
    }
    database.disconnect(1);
    database.disconnect(90);
    database.shutdown(Duration::from_secs(10)).unwrap();
    drop(database);
    check_integrity(&primary).unwrap();
    assert_eq!(open_fingerprint(&primary), final_print);
    fs::remove_dir_all(root).unwrap();
}
