use super::*;
use phobos_execution::QueryResult;
use phobos_execution::mvcc_runtime::MvccDatabase;
use std::time::{SystemTime, UNIX_EPOCH};
fn scalar(db: &MvccDatabase, sql: &str) -> String {
    db.execute(90, sql).unwrap().to_text()
}
#[test]
fn schema_v2_backup_restore_pitr_replication_and_integrity() {
    let root = std::env::temp_dir().join(format!(
        "phobos-schema-v2-admin-{}-{}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    let legacy = root.join("legacy");
    let primary = root.join("primary");
    {
        let mut db = Database::open(&legacy).unwrap();
        db.execute("CREATE TABLE seed (id BIGINT)").unwrap();
    }
    migrate_mvcc_copy(&legacy, &root.join("migration"), &primary).unwrap();
    let db = MvccDatabase::open(&primary).unwrap();
    let base = root.join("base");
    db.backup_online(&base).unwrap();
    let standby = root.join("standby");
    initialize_standby(&primary, &base, &standby, "schema-v2").unwrap();
    retain_wal_for_backup(&primary, &base, "schema-pitr").unwrap();
    db.execute(1, "BEGIN").unwrap();
    db.execute(
        1,
        "CREATE TABLE accounts (id BIGINT PRIMARY KEY, amount BIGINT DEFAULT 5 CHECK(amount>=0))",
    )
    .unwrap();
    db.execute(1, "INSERT INTO accounts (id) VALUES (1)")
        .unwrap();
    db.execute(1, "COMMIT").unwrap();
    let first = db.wal_position().unwrap().1;
    db.execute(1, "ALTER TABLE accounts ALTER COLUMN amount SET DEFAULT 8")
        .unwrap();
    db.execute(1, "INSERT INTO accounts (id) VALUES (2)")
        .unwrap();
    let final_lsn = db.wal_position().unwrap().1;
    let expected = scalar(&db, "SELECT * FROM accounts ORDER BY id");
    let metadata = scalar(&db, "SHOW CATALOG CONSTRAINTS FROM accounts");
    let full = root.join("full");
    let full_report = db.backup_online(&full).unwrap();
    receive_wal(&primary, &standby).unwrap();
    replay_received(&standby).unwrap();
    replay_received(&standby).unwrap();
    {
        let replica = MvccDatabase::open(&standby).unwrap();
        assert_eq!(
            scalar(&replica, "SELECT * FROM accounts ORDER BY id"),
            expected
        );
        assert_eq!(
            scalar(&replica, "SHOW CATALOG CONSTRAINTS FROM accounts"),
            metadata
        );
        replica.disconnect(90);
    }
    check_integrity(&standby).unwrap();
    let archive = root.join("archive");
    archive_wal(&primary, &archive).unwrap();
    for (name, lsn, count, default) in [("first", first, 1, 5), ("final", final_lsn, 2, 8)] {
        let out = root.join(name);
        pitr_recover_to(&base, &archive, &out, lsn).unwrap();
        check_integrity(&out).unwrap();
        let restored = MvccDatabase::open(&out).unwrap();
        if let QueryResult::Rows { rows, .. } =
            restored.execute(1, "SELECT * FROM accounts").unwrap()
        {
            assert_eq!(rows.len(), count);
        } else {
            panic!("rows");
        }
        assert!(
            scalar(&restored, "SHOW CATALOG COLUMNS FROM accounts")
                .contains(&format!("true\t{default}"))
        );
        assert_eq!(
            scalar(&restored, "SHOW CATALOG CONSTRAINTS FROM accounts"),
            metadata
        );
        restored.disconnect(1);
        restored.disconnect(90);
    }
    db.disconnect(1);
    db.disconnect(90);
    drop(db);
    check_integrity(&primary).unwrap();
    let offline = root.join("offline");
    backup_offline(&primary, &offline).unwrap();
    for (i, backup) in [full, offline].iter().enumerate() {
        let restored = root.join(format!("restore-{i}"));
        if i == 0 {
            pitr_recover_to(backup, &archive, &restored, full_report.end_lsn).unwrap();
        } else {
            restore_offline(backup, &restored).unwrap();
        }
        check_integrity(&restored).unwrap();
        let db = MvccDatabase::open(&restored).unwrap();
        assert_eq!(scalar(&db, "SELECT * FROM accounts ORDER BY id"), expected);
        db.execute(1, "INSERT INTO accounts (id) VALUES (3)")
            .unwrap();
        assert!(scalar(&db, "SELECT amount FROM accounts WHERE id=3").contains('8'));
        assert!(db.execute(1, "UPDATE accounts SET amount=-1").is_err());
        assert!(
            db.execute(1, "INSERT INTO accounts (id) VALUES (3)")
                .is_err()
        );
        db.disconnect(1);
        db.disconnect(90);
    }
    fs::remove_dir_all(root).unwrap();
}
