#![forbid(unsafe_code)]
//! Phase 7 offline administration: user management, backup/restore, and integrity checking.

use fs2::FileExt;
#[cfg(test)]
mod k_lifecycle_tests;
mod mvcc_integrity;
mod mvcc_migration;
mod upgrade;
pub use upgrade::upgrade_community_copy;
mod overflow_repair;
mod replication;
pub use mvcc_migration::{
    INITIAL_STATUS_CAPACITY, MvccMigrationReport, migrate_mvcc_copy,
    migrate_mvcc_copy_with_capacity,
};
pub use overflow_repair::{OverflowRepairReport, TableOverflowRepair, repair_overflow};
use phobos_auth::{AuthStore, Role};
use phobos_catalog::Catalog;
use phobos_error::{ErrorCode, PhobosError};
#[cfg(test)]
use phobos_execution::Database;
use phobos_index::BPlusTree;
use phobos_storage::HeapTable;
pub use replication::{
    ReplicationState, ReplicationStatus, SlotStatus, archive_wal, drop_replication_slot,
    initialize_standby, pitr_recover_to, receive_wal, replay_received, replication_status,
    retain_wal_for_backup, standby_state,
};
use std::{
    fs::{self, File, OpenOptions},
    io::Read,
    path::{Path, PathBuf},
};

pub fn add_user(
    auth_file: &Path,
    username: &str,
    password: &str,
    role: Role,
) -> Result<(), PhobosError> {
    let mut store = AuthStore::open(auth_file)?;
    store.upsert_user(username, password, role)
}

pub fn remove_user(auth_file: &Path, username: &str) -> Result<bool, PhobosError> {
    let mut store = AuthStore::open(auth_file)?;
    store.remove_user(username)
}

pub fn list_users(auth_file: &Path) -> Result<Vec<(String, Role)>, PhobosError> {
    Ok(AuthStore::open(auth_file)?.list_users())
}

pub fn backup_offline(data_dir: &Path, destination: &Path) -> Result<usize, PhobosError> {
    fs::create_dir_all(data_dir)?;
    let _lock = lock_dir(data_dir)?;
    backup_locked(data_dir, destination)
}

/// Create a checkpointed PITR/replication base while holding the server's offline owner lock.
pub fn backup_base_offline(
    data_dir: &Path,
    destination: &Path,
) -> Result<phobos_execution::mvcc_runtime::OnlineBackupReport, PhobosError> {
    if !data_dir.join("catalog.phc").is_file() {
        return Err(PhobosError::new(
            ErrorCode::Recovery,
            "backup-base requires an existing stopped MVCC database",
        ));
    }
    let _lock = lock_dir(data_dir)?;
    if !mvcc_integrity::is_versioned(data_dir)? {
        return Err(PhobosError::new(
            ErrorCode::Unsupported,
            "backup-base requires an MVCC database",
        ));
    }
    mvcc_integrity::check_locked(data_dir)?;
    let database = phobos_execution::mvcc_runtime::MvccDatabase::open(data_dir)?;
    database.backup_online(destination)
}

pub fn backup_online(
    database: &phobos_execution::mvcc_runtime::MvccDatabase,
    destination: &Path,
) -> Result<phobos_execution::mvcc_runtime::OnlineBackupReport, PhobosError> {
    database.backup_online(destination)
}

pub fn check_online(
    database: &phobos_execution::mvcc_runtime::MvccDatabase,
) -> Result<phobos_execution::mvcc_runtime::OnlineCheckReport, PhobosError> {
    database.check_online()
}

fn backup_locked(data_dir: &Path, destination: &Path) -> Result<usize, PhobosError> {
    if destination.exists() && fs::read_dir(destination)?.next().is_some() {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "backup destination must be empty",
        ));
    }
    fs::create_dir_all(destination)?;
    let mut copied = 0usize;
    for path in database_files(data_dir)? {
        let name = path
            .file_name()
            .ok_or_else(|| PhobosError::new(ErrorCode::Io, "database file has no name"))?;
        fs::copy(&path, destination.join(name))?;
        copied += 1;
        phobos_observability::certification_crash("during_backup");
    }
    fs::write(destination.join("PHOBOS_BACKUP_1"), b"offline-consistent\n")?;
    sync_directory_files(destination)?;
    Ok(copied)
}

pub fn restore_offline(source: &Path, data_dir: &Path) -> Result<usize, PhobosError> {
    if !source.join("PHOBOS_BACKUP_1").exists() {
        return Err(PhobosError::new(
            ErrorCode::Recovery,
            "backup marker is missing",
        ));
    }
    fs::create_dir_all(data_dir)?;
    let _lock = lock_dir(data_dir)?;
    let existing: Vec<_> = database_files(data_dir)?;
    if !existing.is_empty() {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "restore destination contains database files",
        ));
    }
    let mut copied = 0usize;
    for path in database_files(source)? {
        let name = path
            .file_name()
            .ok_or_else(|| PhobosError::new(ErrorCode::Io, "backup file has no name"))?;
        fs::copy(&path, data_dir.join(name))?;
        copied += 1;
    }
    sync_directory_files(data_dir)?;
    Ok(copied)
}

/// 0.2-K Part N: storage-lifecycle diagnostics of an offline MVCC data
/// directory (per-table slot census, reclaim backlog, index size, status-file
/// size, WAL retention). Read-only: a recovered scratch copy is inspected.
pub fn storage_lifecycle(
    data_dir: &Path,
    row_need: Option<usize>,
) -> Result<phobos_execution::mvcc_runtime::StorageLifecycleReport, PhobosError> {
    let _lock = lock_dir(data_dir)?;
    if !mvcc_integrity::is_versioned(data_dir)? {
        return Err(PhobosError::new(
            ErrorCode::Unsupported,
            "storage lifecycle diagnostics require an MVCC database",
        ));
    }
    mvcc_integrity::lifecycle_locked(data_dir, row_need)
}

pub fn check_integrity(data_dir: &Path) -> Result<IntegrityReport, PhobosError> {
    let _lock = lock_dir(data_dir)?;
    if mvcc_integrity::is_versioned(data_dir)? {
        return mvcc_integrity::check_locked(data_dir);
    }
    preflight_wal(data_dir)?;
    let catalog = Catalog::open(data_dir)?;
    let tables: Vec<_> = catalog.tables().cloned().collect();
    let indexes: Vec<_> = catalog.indexes().cloned().collect();

    // Validate every heap directly while the database is offline. Opening and scanning the
    // heap verifies page framing/checksums and row decoding without invoking normal database
    // startup/recovery paths, which may create or rotate files and is undesirable during an
    // integrity-only operation.
    for table in &tables {
        let path = data_dir.join(format!("table-{:016x}.heap", table.id));
        let mut heap = HeapTable::open(path, table.clone(), 8)?;
        heap.scan_visit(|_, row| {
            catalog.validate_row_definitions(table.id, &row)?;
            Ok(true)
        })?;
    }

    let mut index_pages = 0usize;
    for index in &indexes {
        let path = data_dir.join(format!("index-{:016x}.idx", index.id));
        let mut tree = BPlusTree::open(path, index.unique, index.columns.len())?;
        index_pages += tree.validate()?.pages;
    }

    Ok(IntegrityReport {
        tables: tables.len(),
        indexes: indexes.len(),
        index_pages,
        index_live_entries: 0,
        index_stale_entries: 0,
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ReindexReport {
    pub rebuilt: usize,
    pub backup_files: usize,
}

/// Offline upgrade from legacy index codecs to the V3 memcomparable codec.
/// Heap, catalog, transaction status and WAL files are copied but untouched.
pub fn reindex_memcomparable(data_dir: &Path, backup: &Path) -> Result<ReindexReport, PhobosError> {
    let data_dir = fs::canonicalize(data_dir)?;
    let _lock = lock_dir(&data_dir)?;
    preflight_wal(&data_dir)?;
    let backup_files = backup_locked(&data_dir, backup)?;
    let catalog = Catalog::open(&data_dir)?;
    let indexes: Vec<_> = catalog.indexes().cloned().collect();
    let mut replacements = Vec::new();
    for index in indexes {
        let path = data_dir.join(format!("index-{:016x}.idx", index.id));
        let header = fs::read(&path)?;
        if header.len() < 6 {
            return Err(PhobosError::new(
                ErrorCode::InvalidPage,
                "truncated index meta page",
            ));
        }
        let version = u16::from_le_bytes([header[4], header[5]]);
        if version == 3 {
            continue;
        }
        let mut old = BPlusTree::open_legacy_for_reindex(&path, index.unique, index.columns.len())?;
        old.validate()?;
        let entries = old.all_entries()?;
        drop(old);
        let temporary = path.with_extension("idx.reindex-v3");
        if temporary.exists() {
            fs::remove_file(&temporary)?;
        }
        let mut rebuilt = BPlusTree::open(&temporary, index.unique, index.columns.len())?;
        for (key, rid) in entries {
            rebuilt.insert_reindex_entry(key, rid)?;
        }
        rebuilt.validate()?;
        rebuilt.sync()?;
        drop(rebuilt);
        replacements.push((path, temporary));
    }
    for (path, temporary) in &replacements {
        let legacy = path.with_extension("idx.reindex-old");
        fs::rename(path, &legacy)?;
        if let Err(error) = fs::rename(temporary, path) {
            let _ = fs::rename(&legacy, path);
            return Err(error.into());
        }
        fs::remove_file(legacy)?;
    }
    sync_directory_files(&data_dir)?;
    Ok(ReindexReport {
        rebuilt: replacements.len(),
        backup_files,
    })
}

#[cfg(test)]
mod phase_b_tests {
    use super::*;
    #[test]
    fn full_admin_check_detects_unread_interior_corruption() {
        let root = std::env::temp_dir().join(format!("phobos-b5-admin-{}", std::process::id()));
        {
            let mut db = phobos_execution::Database::open(&root).unwrap();
            db.execute("CREATE TABLE t (v TEXT NOT NULL)").unwrap();
            for _ in 0..8 {
                db.execute(&format!("INSERT INTO t VALUES ('{}')", "x".repeat(5000)))
                    .unwrap();
            }
        }
        check_integrity(&root).unwrap();
        let heap = fs::read_dir(&root)
            .unwrap()
            .map(|e| e.unwrap().path())
            .find(|p| p.extension().is_some_and(|e| e == "heap"))
            .unwrap();
        let mut bytes = fs::read(&heap).unwrap();
        assert!(bytes.len() >= 8 * phobos_storage::PAGE_SIZE);
        bytes[3 * phobos_storage::PAGE_SIZE + 4000] ^= 1;
        fs::write(&heap, &bytes).unwrap();
        assert!(check_integrity(&root).is_err());
        assert_eq!(fs::read(&heap).unwrap(), bytes);
        fs::remove_dir_all(root).unwrap();
    }
}

/// Preserve a complete offline backup before changing the legacy WAL format.
/// The backup must be a separate empty directory, never inside the database.
pub fn migrate_wal_v2(data_dir: &Path, backup: &Path) -> Result<usize, PhobosError> {
    let data_dir = fs::canonicalize(data_dir)?;
    let _lock = lock_dir(&data_dir)?;
    if preflight_wal(&data_dir)? == 2 {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "database already uses WAL v2",
        ));
    }
    let copied = migration_backup(&data_dir, backup)?;
    // This may repair a torn legacy control tail, only after its backup exists.
    let manager = phobos_txn::TransactionManager::open(&data_dir)?;
    let next = manager.next_id();
    drop(manager);
    drop(phobos_wal::v2::Wal::migrate_legacy(&data_dir, next)?);
    Ok(copied)
}

/// Explicit W1-to-W2 migration. Untouched version-1 pages retain LSN zero until
/// their next logged modification; the retained capability anchor prevents old
/// V2 readers from modifying the database after the first page-format upgrade.
pub fn migrate_page_lsn(data_dir: &Path, backup: &Path) -> Result<usize, PhobosError> {
    let data_dir = fs::canonicalize(data_dir)?;
    let _lock = lock_dir(&data_dir)?;
    if preflight_wal(&data_dir)? != 2 {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "migrate legacy WAL to v2 before enabling page LSNs",
        ));
    }
    if phobos_wal::v2::inspect(data_dir.join("phobos.wal"))?.page_format != 1 {
        return Err(PhobosError::new(
            ErrorCode::AlreadyExists,
            "database already supports page LSNs",
        ));
    }
    let copied = migration_backup(&data_dir, backup)?;
    let mut wal = phobos_wal::v2::Wal::recover(&data_dir)?;
    phobos_observability::certification_crash("v2_page_migration_before_anchor");
    wal.enable_page_lsn()?;
    phobos_observability::certification_crash("v2_page_migration_after_anchor");
    drop(wal);
    Ok(copied)
}
fn migration_backup(data_dir: &Path, backup: &Path) -> Result<usize, PhobosError> {
    fs::create_dir_all(backup)?;
    let backup = fs::canonicalize(backup)?;
    if backup.starts_with(data_dir) || data_dir.starts_with(&backup) {
        return Err(PhobosError::new(
            ErrorCode::Semantic,
            "migration backup must be separate from the database",
        ));
    }
    backup_locked(data_dir, &backup)
}

fn preflight_wal(data_dir: &Path) -> Result<u16, PhobosError> {
    let path = data_dir.join("phobos.wal");
    // 0.2-I.3: an interrupted V2 segment rotation is V2, never "no WAL" (V1).
    if phobos_wal::v2::interrupted_rotation(data_dir)? {
        if phobos_wal::v2::inspect(path)?.page_format >= 3 {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "MVCC admin/integrity integration is not enabled",
            ));
        }
        return Ok(2);
    }
    if !path.exists() {
        return Ok(1);
    }
    let mut file = File::open(&path)?;
    if file.metadata()?.len() == 0 {
        return Ok(1);
    }
    let mut prefix = [0; 6];
    file.read_exact(&mut prefix)?;
    let version = u16::from_le_bytes([prefix[4], prefix[5]]);
    if &prefix[..4] != b"PHWL" || !matches!(version, 1 | 2) {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "unsupported WAL format",
        ));
    }
    drop(file);
    if version == 2 {
        if phobos_wal::v2::inspect(path)?.page_format >= 3 {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "MVCC admin/integrity integration is not enabled",
            ));
        }
    } else {
        phobos_wal::inspect_legacy(data_dir)?;
    }
    Ok(version)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct IntegrityReport {
    pub tables: usize,
    pub indexes: usize,
    pub index_pages: usize,
    /// 0.2-K.4: index entries naming a valid version with a matching key.
    pub index_live_entries: u64,
    /// 0.2-K.4: stale non-unique entries (legal only under the catalog
    /// capability LAZY_INDEX_PRUNING_V1; otherwise reported as corruption).
    pub index_stale_entries: u64,
}

fn lock_dir(data_dir: &Path) -> Result<File, PhobosError> {
    let file = OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false)
        .open(data_dir.join("phobos.lock"))?;
    file.try_lock_exclusive().map_err(|_| {
        PhobosError::new(
            ErrorCode::DataDirectoryLocked,
            "data directory is in use; offline administration refused",
        )
    })?;
    Ok(file)
}

fn database_files(dir: &Path) -> Result<Vec<PathBuf>, PhobosError> {
    let mut files = Vec::new();
    if !dir.exists() {
        return Ok(files);
    }
    for entry in fs::read_dir(dir)? {
        let path = entry?.path();
        if path.is_file() && is_database_file(&path) {
            files.push(path);
        }
    }
    files.sort();
    Ok(files)
}

fn is_database_file(path: &Path) -> bool {
    let name = path.file_name().and_then(|v| v.to_str()).unwrap_or("");
    matches!(
        path.extension().and_then(|v| v.to_str()),
        Some("phc" | "heap" | "idx" | "wal" | "txn" | "stats")
    ) || (name.starts_with("phobos.wal.") && name.ends_with(".seg"))
        || matches!(
            name,
            "phobos.wal.gen"
                | "phobos.auth"
                | "phobos.mvcc-status"
                | "phobos.mvcc-freeze"
                | "phobos.system-id"
        )
}

fn sync_directory_files(dir: &Path) -> Result<(), PhobosError> {
    for path in database_files(dir)? {
        // Windows FlushFileBuffers requires write access, even when syncing a copied file.
        // Keep each handle scoped to this iteration, inside the caller's offline lock.
        let file = OpenOptions::new().write(true).open(&path)?;
        file.sync_all().map_err(|error| {
            PhobosError::from(error).with_detail(format!("sync_all: {}", path.display()))
        })?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn w1_database(data: &Path) -> phobos_execution::QueryResult {
        drop(phobos_wal::v2::Wal::create(data).unwrap());
        let mut db = Database::open(data).unwrap();
        db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT)")
            .unwrap();
        db.execute("INSERT INTO t VALUES (7,70),(9,90)").unwrap();
        db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
        db.execute("SELECT * FROM t ORDER BY id").unwrap()
    }

    #[test]
    fn migration_page_lsn_preserves_backup_and_upgrades_only_logged_pages() {
        let data = temp("page-migration");
        let backup = temp("page-migration-backup");
        let restored = temp("page-migration-restored");
        let expected = w1_database(&data);
        let before = phobos_wal::v2::inspect(data.join("phobos.wal")).unwrap();
        assert_eq!(before.page_format, 1);
        let original: Vec<_> = database_files(&data)
            .unwrap()
            .into_iter()
            .map(|path| {
                (
                    path.file_name().unwrap().to_owned(),
                    fs::read(path).unwrap(),
                )
            })
            .collect();
        migrate_page_lsn(&data, &backup).unwrap();
        let after = phobos_wal::v2::inspect(data.join("phobos.wal")).unwrap();
        assert_eq!(after.page_format, 2);
        assert_eq!(after.next_txn_id, before.next_txn_id);
        for (name, bytes) in &original {
            assert_eq!(&fs::read(backup.join(name)).unwrap(), bytes);
            if name != "phobos.wal" {
                assert_eq!(&fs::read(data.join(name)).unwrap(), bytes);
            }
        }
        {
            let mut db = Database::open(&data).unwrap();
            assert_eq!(db.execute("SELECT * FROM t ORDER BY id").unwrap(), expected);
            db.execute("UPDATE t SET id=17 WHERE id=7").unwrap();
        }
        check_integrity(&data).unwrap();
        assert_eq!(
            &fs::read(data.join("table-0000000000000001.heap")).unwrap()[4..6],
            &2u16.to_le_bytes()
        );
        assert!(migrate_page_lsn(&data, &temp("already-page-lsn")).is_err());
        restore_offline(&backup, &restored).unwrap();
        assert_eq!(
            phobos_wal::v2::inspect(restored.join("phobos.wal"))
                .unwrap()
                .page_format,
            1
        );
        {
            let mut db = Database::open(&restored).unwrap();
            assert_eq!(db.execute("SELECT * FROM t ORDER BY id").unwrap(), expected);
        }
        for dir in [data, backup, restored] {
            fs::remove_dir_all(dir).unwrap();
        }
    }

    #[cfg(feature = "certification")]
    #[test]
    fn migration_page_lsn_crashes_preserve_readability_and_backup() {
        if let Ok(data) = std::env::var("PHOBOS_PAGE_MIGRATION_DATA") {
            let backup = std::env::var("PHOBOS_PAGE_MIGRATION_BACKUP").unwrap();
            migrate_page_lsn(Path::new(&data), Path::new(&backup)).unwrap();
            std::process::exit(74);
        }
        for point in [
            "v2_page_migration_before_anchor",
            "v2_page_migration_after_anchor",
        ] {
            let data = temp("page-migration-crash");
            let backup = temp("page-migration-crash-backup");
            let retry = temp("page-migration-crash-retry");
            let expected = w1_database(&data);
            let original = fs::read(data.join("phobos.wal")).unwrap();
            let child = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "tests::migration_page_lsn_crashes_preserve_readability_and_backup",
                    "--nocapture",
                ])
                .env("PHOBOS_PAGE_MIGRATION_DATA", &data)
                .env("PHOBOS_PAGE_MIGRATION_BACKUP", &backup)
                .env("PHOBOS_BETA_CRASH_POINT", point)
                .output()
                .unwrap();
            assert!(!child.status.success());
            assert_ne!(child.status.code(), Some(74));
            assert_ne!(child.status.code(), Some(101));
            assert!(
                String::from_utf8_lossy(&child.stderr)
                    .contains(&format!("BETA_CRASH_REACHED {point}"))
            );
            assert_eq!(fs::read(backup.join("phobos.wal")).unwrap(), original);
            for _ in 0..2 {
                let mut db = Database::open(&data).unwrap();
                assert_eq!(db.execute("SELECT * FROM t ORDER BY id").unwrap(), expected);
            }
            if point == "v2_page_migration_before_anchor" {
                migrate_page_lsn(&data, &retry).unwrap();
            }
            assert_eq!(
                phobos_wal::v2::inspect(data.join("phobos.wal"))
                    .unwrap()
                    .page_format,
                2
            );
            for dir in [data, backup, retry] {
                if dir.exists() {
                    fs::remove_dir_all(dir).unwrap();
                }
            }
        }
    }

    #[cfg(feature = "certification")]
    #[test]
    fn migration_process_crash_keeps_a_readable_format_and_backup() {
        if let Ok(data) = std::env::var("PHOBOS_MIGRATION_TEST_DATA") {
            let backup = std::env::var("PHOBOS_MIGRATION_TEST_BACKUP").unwrap();
            migrate_wal_v2(Path::new(&data), Path::new(&backup)).unwrap();
            std::process::exit(74);
        }
        for point in ["v2_migration_prepared", "v2_migration_installed"] {
            let data = temp("migration-crash");
            let backup = temp("migration-crash-backup");
            let retry = temp("migration-crash-retry");
            fs::create_dir_all(&data).unwrap();
            drop(phobos_wal::Wal::open(&data).unwrap());
            let expected = {
                let mut db = Database::open(&data).unwrap();
                db.execute("CREATE TABLE t (id BIGINT)").unwrap();
                db.execute("INSERT INTO t VALUES (7)").unwrap();
                db.execute("SELECT * FROM t").unwrap()
            };
            let original = fs::read(data.join("phobos.wal")).unwrap();
            let child = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "tests::migration_process_crash_keeps_a_readable_format_and_backup",
                    "--nocapture",
                ])
                .env("PHOBOS_MIGRATION_TEST_DATA", &data)
                .env("PHOBOS_MIGRATION_TEST_BACKUP", &backup)
                .env("PHOBOS_BETA_CRASH_POINT", point)
                .output()
                .unwrap();
            assert!(!child.status.success());
            assert_ne!(child.status.code(), Some(74));
            assert_ne!(child.status.code(), Some(101));
            assert!(
                String::from_utf8_lossy(&child.stderr)
                    .contains(&format!("BETA_CRASH_REACHED {point}"))
            );
            assert_eq!(fs::read(backup.join("phobos.wal")).unwrap(), original);
            for _ in 0..2 {
                let mut db = Database::open(&data).unwrap();
                assert_eq!(db.execute("SELECT * FROM t").unwrap(), expected);
            }
            if point == "v2_migration_prepared" {
                migrate_wal_v2(&data, &retry).unwrap();
            }
            assert_eq!(preflight_wal(&data).unwrap(), 2);
            for dir in [data, backup, retry] {
                if dir.exists() {
                    fs::remove_dir_all(dir).unwrap();
                }
            }
        }
    }

    #[test]
    fn migration_preserves_legacy_backup_rows_indexes_and_transaction_cursor() {
        let data = temp("migration-data");
        let backup = temp("migration-backup");
        let restored = temp("migration-restored");
        fs::create_dir_all(&data).unwrap();
        drop(phobos_wal::Wal::open(&data).unwrap());
        let expected = {
            let mut db = Database::open(&data).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
            db.execute("CREATE UNIQUE INDEX ix ON t (id)").unwrap();
            db.execute("INSERT INTO t VALUES (1),(2)").unwrap();
            db.execute("SELECT * FROM t ORDER BY id").unwrap()
        };
        let manager = phobos_txn::TransactionManager::open(&data).unwrap();
        let next_id = manager.next_id();
        drop(manager);
        let original: Vec<_> = database_files(&data)
            .unwrap()
            .into_iter()
            .map(|path| {
                (
                    path.file_name().unwrap().to_owned(),
                    fs::read(path).unwrap(),
                )
            })
            .collect();
        assert!(migrate_wal_v2(&data, &backup).unwrap() >= 3);
        assert!(
            phobos_wal::v2::inspect(data.join("phobos.wal"))
                .unwrap()
                .next_txn_id
                >= next_id
        );
        for (name, bytes) in original {
            assert_eq!(fs::read(backup.join(name)).unwrap(), bytes);
        }
        let mut db = Database::open(&data).unwrap();
        assert_eq!(db.execute("SELECT * FROM t ORDER BY id").unwrap(), expected);
        db.execute("INSERT INTO t VALUES (3)").unwrap();
        drop(db);
        assert_eq!(check_integrity(&data).unwrap().indexes, 1);
        restore_offline(&backup, &restored).unwrap();
        let mut old = Database::open(&restored).unwrap();
        assert_eq!(
            old.execute("SELECT * FROM t ORDER BY id").unwrap(),
            expected
        );
        drop(old);
        assert!(migrate_wal_v2(&data, &backup).is_err());
        for dir in [data, backup, restored] {
            fs::remove_dir_all(dir).unwrap();
        }
    }

    #[test]
    fn unsupported_partial_legacy_version_is_never_trimmed_or_migrated() {
        use std::io::Write;
        let data = temp("migration-version");
        let backup = temp("migration-version-backup");
        fs::create_dir_all(&data).unwrap();
        let mut wal = phobos_wal::Wal::open(&data).unwrap();
        wal.append(phobos_wal::RecordType::Begin, 1, 0, &[])
            .unwrap();
        wal.sync().unwrap();
        drop(wal);
        let path = data.join("phobos.wal");
        let mut file = OpenOptions::new().append(true).open(&path).unwrap();
        file.write_all(b"PHWL\x03\x00").unwrap();
        drop(file);
        let before = fs::read(&path).unwrap();
        assert!(phobos_wal::recover(&data).is_err());
        assert!(migrate_wal_v2(&data, &backup).is_err());
        assert!(check_integrity(&data).is_err());
        assert_eq!(fs::read(path).unwrap(), before);
        assert!(!backup.exists());
        assert!(!data.join("catalog.phc").exists());
        assert!(!data.join("phobos.txn").exists());
        fs::remove_dir_all(data).unwrap();
    }
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp(label: &str) -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-admin-{label}-{n}"))
    }

    #[test]
    fn sync_preserves_contents_and_releases_handles() {
        let dir = temp("sync");
        fs::create_dir_all(&dir).unwrap();
        let path = dir.join("catalog.phc");
        let contents = b"sync must not truncate or change these bytes";
        fs::write(&path, contents).unwrap();

        sync_directory_files(&dir).unwrap();

        assert_eq!(fs::read(&path).unwrap(), contents);
        fs::rename(&path, dir.join("renamed.phc")).unwrap();
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn offline_backup_restore_and_integrity() {
        let data = temp("data");
        let backup = temp("backup");
        let restored = temp("restored");
        {
            let mut db = Database::open(&data).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
            db.execute("CREATE UNIQUE INDEX ux_t_id ON t (id)").unwrap();
            db.execute("INSERT INTO t VALUES (1),(2)").unwrap();
        }
        assert!(backup_offline(&data, &backup).unwrap() >= 3);
        restore_offline(&backup, &restored).unwrap();
        let report = check_integrity(&restored).unwrap();
        assert_eq!(report.tables, 1);
        assert_eq!(report.indexes, 1);
        fs::remove_dir_all(data).unwrap();
        fs::remove_dir_all(backup).unwrap();
        fs::remove_dir_all(restored).unwrap();
    }

    #[test]
    fn e2_old_index_is_rejected_then_offline_reindexed() {
        let data = temp("e2-data");
        let backup = temp("e2-backup");
        {
            let mut db = Database::open(&data).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL)").unwrap();
            db.execute("CREATE INDEX ix_t_id ON t(id)").unwrap();
        }
        let path = fs::read_dir(&data)
            .unwrap()
            .map(|entry| entry.unwrap().path())
            .find(|path| path.extension().is_some_and(|extension| extension == "idx"))
            .unwrap();
        let mut bytes = fs::read(&path).unwrap();
        for page in bytes.chunks_exact_mut(phobos_index::INDEX_PAGE_SIZE) {
            page[4..6].copy_from_slice(&2u16.to_le_bytes());
            let (lsn, checksum) = if &page[..4] == b"PHIX" {
                (32, 28)
            } else {
                (40, 36)
            };
            page[lsn..lsn + 8].copy_from_slice(&1u64.to_le_bytes());
            page[checksum..checksum + 4].fill(0);
            let crc = phobos_wal::page_checksum::checksum(page, checksum);
            page[checksum..checksum + 4].copy_from_slice(&crc.to_le_bytes());
        }
        fs::write(&path, bytes).unwrap();
        let error = match Database::open(&data) {
            Ok(_) => panic!("legacy index unexpectedly opened"),
            Err(error) => error,
        };
        assert!(
            error.message.contains("offline phobos-admin reindex"),
            "{error}"
        );
        let report = reindex_memcomparable(&data, &backup).unwrap();
        assert_eq!(report.rebuilt, 1);
        drop(Database::open(&data).unwrap());
        check_integrity(&data).unwrap();
        fs::remove_dir_all(data).unwrap();
        fs::remove_dir_all(backup).unwrap();
    }
}

#[cfg(test)]
mod foreign_key_tests;
#[cfg(test)]
mod identity_tests;
#[cfg(test)]
mod schema_v2_tests;
#[cfg(test)]
mod view_tests;
