//! 0.2-I.1: offline repair of heap overflow pages that received ordinary
//! tuples (0.2-I post-restart free-space defect).
//!
//! Safety model (see `docs/overflow_safety_0_2_i_1.md`):
//! * offline only: the data-directory lock is held for the whole operation;
//! * the WAL must hold nothing to redo (clean shutdown), so no later recovery
//!   can replay a record onto a repaired page;
//! * a complete copy of every database file is written to an empty backup
//!   directory and forced before anything changes;
//! * each heap file is replaced atomically (temporary file + rename);
//! * no ordinary tuple moves, so RecordIds, indexes, UNIQUE references and
//!   version chains are untouched;
//! * the full integrity check runs afterwards; on any failure every planned
//!   heap file is restored atomically from the backup.
use super::*;
use phobos_storage::overflow_safety::{
    OverflowRepair, plan_overflow_repair, remove_stale_repair_file, sync_parent,
    write_repaired_heap,
};
use phobos_wal::v2::{FileId, Tail};

/// What the repair found and did for one table.
#[derive(Debug, Clone)]
pub struct TableOverflowRepair {
    pub table: String,
    pub table_id: u64,
    pub heap_file: String,
    pub pages_before: u64,
    pub pages_after: u64,
    pub violations: Vec<String>,
    pub actions: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct OverflowRepairReport {
    pub dry_run: bool,
    pub backup_files: usize,
    pub tables: Vec<TableOverflowRepair>,
    /// Integrity report after the repair (absent for a dry run or no-op).
    pub integrity: Option<IntegrityReport>,
}

impl OverflowRepairReport {
    #[must_use]
    pub fn damaged_pages(&self) -> usize {
        self.tables.iter().map(|t| t.violations.len()).sum()
    }
}

fn refuse(message: impl Into<String>) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}

/// Refuses unless WAL recovery would replay nothing: no committed or
/// incomplete transaction is retained and the tail is clean. A cleanly
/// stopped PHOBOS server leaves exactly this state.
fn require_quiescent_wal(data_dir: &Path) -> Result<(), PhobosError> {
    let report = phobos_wal::v2::inspect(data_dir.join("phobos.wal"))?;
    if report.committed_transactions != 0
        || report.incomplete_transactions != 0
        || !matches!(report.tail, Tail::Clean)
    {
        return Err(refuse(format!(
            "WAL still holds redo (committed={}, incomplete={}, tail={:?}); start and cleanly stop the PHOBOS server once, then rerun repair-overflow",
            report.committed_transactions, report.incomplete_transactions, report.tail
        )));
    }
    Ok(())
}

fn backup_all(data_dir: &Path, backup_dir: &Path) -> Result<usize, PhobosError> {
    if backup_dir.exists() && fs::read_dir(backup_dir)?.next().is_some() {
        return Err(refuse("backup directory must be empty or absent"));
    }
    fs::create_dir_all(backup_dir)?;
    let files = database_files(data_dir)?;
    for file in &files {
        let name = file.file_name().ok_or_else(|| refuse("invalid filename"))?;
        fs::copy(file, backup_dir.join(name))?;
    }
    sync_directory_files(backup_dir)?;
    Ok(files.len())
}

/// Atomically puts each heap back from the backup: copy to a temporary file
/// next to the heap, force it, rename it over the heap, force the directory.
/// Restoring a heap that was never replaced is harmless (identical bytes).
fn restore_heaps(backup_dir: &Path, data_dir: &Path, heaps: &[String]) -> Result<(), PhobosError> {
    for name in heaps {
        let target = data_dir.join(name);
        let temporary = data_dir.join(format!("{name}.overflow-restore.tmp"));
        let _ = fs::remove_file(&temporary);
        fs::copy(backup_dir.join(name), &temporary)?;
        OpenOptions::new()
            .write(true)
            .open(&temporary)?
            .sync_all()?;
        fs::rename(&temporary, &target)?;
        sync_parent(&target)?;
    }
    Ok(())
}

/// Restores every planned heap after a failure and reports both the cause and
/// the restore outcome; a failed restore tells the operator exactly what to do.
fn fail_and_restore(
    backup_dir: &Path,
    data_dir: &Path,
    heaps: &[String],
    cause: String,
) -> PhobosError {
    match restore_heaps(backup_dir, data_dir, heaps) {
        Ok(()) => refuse(format!(
            "{cause}; original heap files restored from backup {}",
            backup_dir.display()
        )),
        Err(restore) => refuse(format!(
            "{cause}; RESTORE ALSO FAILED ({}): the database may be partially repaired - restore every file from {} before starting PHOBOS",
            restore.message,
            backup_dir.display()
        )),
    }
}

/// Detects and (unless `dry_run`) repairs every damaged overflow page of an
/// offline MVCC database. `backup_dir` must be empty or absent; it receives a
/// full copy of the database before any change.
pub fn repair_overflow(
    data_dir: &Path,
    backup_dir: &Path,
    dry_run: bool,
) -> Result<OverflowRepairReport, PhobosError> {
    let _lock = lock_dir(data_dir)?;
    if !mvcc_integrity::is_versioned(data_dir)? {
        return Err(PhobosError::new(
            ErrorCode::Unsupported,
            "repair-overflow applies to MVCC databases only (legacy heaps have no overflow pages)",
        ));
    }
    require_quiescent_wal(data_dir)?;
    let catalog = Catalog::open(data_dir)?;
    let mut plans: Vec<(TableOverflowRepair, OverflowRepair)> = Vec::new();
    for table in catalog.tables() {
        let heap_file = FileId::Heap(table.id).name();
        let path = data_dir.join(&heap_file);
        if !path.is_file() {
            return Err(refuse(format!("catalog heap {heap_file} is missing")));
        }
        if !dry_run {
            remove_stale_repair_file(&path)?;
        }
        let repair = plan_overflow_repair(&path).map_err(|error| {
            refuse(format!(
                "table '{}' heap {heap_file}: {}",
                table.name, error.message
            ))
        })?;
        if repair.violations.is_empty() {
            continue;
        }
        plans.push((
            TableOverflowRepair {
                table: table.name.clone(),
                table_id: table.id,
                heap_file,
                pages_before: repair.original_pages,
                pages_after: repair.final_pages(),
                violations: repair.violations.iter().map(ToString::to_string).collect(),
                actions: repair.actions.iter().map(ToString::to_string).collect(),
            },
            repair,
        ));
    }
    let mut report = OverflowRepairReport {
        dry_run,
        backup_files: 0,
        tables: plans.iter().map(|(table, _)| table.clone()).collect(),
        integrity: None,
    };
    if dry_run || plans.is_empty() {
        return Ok(report);
    }
    report.backup_files = backup_all(data_dir, backup_dir)?;
    // Every planned heap is restored on any failure: a failing write may
    // already have renamed its file into place (e.g. directory fsync error).
    let planned = plans
        .iter()
        .map(|(table, _)| table.heap_file.clone())
        .collect::<Vec<_>>();
    for (table, repair) in &plans {
        if let Err(error) = write_repaired_heap(&data_dir.join(&table.heap_file), repair) {
            return Err(fail_and_restore(
                backup_dir,
                data_dir,
                &planned,
                format!(
                    "writing repaired {} failed ({})",
                    table.heap_file, error.message
                ),
            ));
        }
    }
    match mvcc_integrity::check_locked(data_dir) {
        Ok(integrity) => report.integrity = Some(integrity),
        Err(error) => {
            return Err(fail_and_restore(
                backup_dir,
                data_dir,
                &planned,
                format!("post-repair integrity check failed ({})", error.message),
            ));
        }
    }
    Ok(report)
}
