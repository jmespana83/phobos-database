//! Backup-first conversion to a separate, atomically published destination.
//! No source files are recovered, rewritten or removed by this operation.
use super::*;
use phobos_index::IndexKey;
use phobos_storage::tuple_version::TupleVersion;
use phobos_txn::mvcc::{SnapshotRegistry, StatusFile, TransactionRegistry, Version};
use phobos_wal::v2::{Body, FileId, PageAction, Wal};
use std::io::Write;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MvccMigrationReport {
    pub backup_files: usize,
    pub tables: usize,
    pub indexes: usize,
    pub rows: u64,
}

/// Eligible inputs have WAL V2 with capability 1 or 2. The source and backup
/// remain independently usable by C4. Destination must not exist and its parent
/// must exist. All three locations must be disjoint. This is an explicit copy
/// migration; callers must choose the new database path after validation.
/// Initial transaction-status grant of a migrated store. Since 0.1.9-A3 this
/// is only the first extent: the status file grows on demand, so it no longer
/// bounds how many transactions the database can process over its lifetime.
pub const INITIAL_STATUS_CAPACITY: u64 = 16_777_216;

pub fn migrate_mvcc_copy(
    source: &Path,
    backup: &Path,
    destination: &Path,
) -> Result<MvccMigrationReport, PhobosError> {
    migrate_mvcc_copy_with_capacity(source, backup, destination, INITIAL_STATUS_CAPACITY)
}

/// `initial_status_capacity` chooses the first status extent only (see
/// [`INITIAL_STATUS_CAPACITY`]); it must be at least 1.
pub fn migrate_mvcc_copy_with_capacity(
    source: &Path,
    backup: &Path,
    destination: &Path,
    initial_status_capacity: u64,
) -> Result<MvccMigrationReport, PhobosError> {
    if initial_status_capacity == 0 {
        return Err(error("initial MVCC status capacity must be at least 1"));
    }
    let source = fs::canonicalize(source)?;
    let _source_lock = lock_dir(&source)?;
    if preflight_wal(&source)? != 2 {
        return Err(error("migrate legacy WAL to V2 before tuple migration"));
    }
    let destination = resolve_new(destination)?;
    let backup_path = if backup.exists() {
        fs::canonicalize(backup)?
    } else {
        resolve_new(backup)?
    };
    if overlaps(&source, &destination)
        || overlaps(&backup_path, &destination)
        || overlaps(&source, &backup_path)
    {
        return Err(error("source, backup and destination must be disjoint"));
    }
    let backup_files = migration_backup(&source, &backup_path)?;
    phobos_observability::synchronization_boundary("c5_migration_after_backup", &source);
    phobos_observability::certification_crash("c5_migration_after_backup");
    let suffix = format!(
        "{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|_| error("system clock predates epoch"))?
            .as_nanos()
    );
    let parent = destination
        .parent()
        .ok_or_else(|| error("destination needs a parent"))?;
    let working = parent.join(format!(".phobos-mvcc-source-{suffix}"));
    let staging = parent.join(format!(".phobos-mvcc-staging-{suffix}"));
    fs::create_dir(&working)?;
    for path in database_files(&backup_path)? {
        fs::copy(
            &path,
            working.join(
                path.file_name()
                    .ok_or_else(|| error("invalid backup filename"))?,
            ),
        )?;
    }
    sync_directory_files(&working)?;
    drop(Wal::recover(&working)?);
    let catalog = Catalog::open(&working)?;
    for index in catalog.indexes() {
        BPlusTree::open(
            working.join(FileId::Index(index.id).name()),
            index.unique,
            index.columns.len(),
        )?
        .validate()?;
    }
    let mut wal = Wal::create_with_versioned_heap(&staging)?;
    File::create(staging.join("phobos.lock"))?.sync_all()?;
    let mut transactions =
        TransactionRegistry::new(StatusFile::create(&staging, initial_status_capacity)?, 1)?;
    let stable = transactions.allocate()?;
    wal.begin_mvcc(stable)?;
    for identity in [FileId::Tables, FileId::Indexes, FileId::Statistics] {
        let path = working.join(identity.name());
        if path.exists() {
            append_metadata(&mut wal, identity, &path)?;
        }
    }
    if working.join("phobos.auth").exists() {
        fs::copy(working.join("phobos.auth"), staging.join("phobos.auth"))?;
    }
    let scratch = staging.join(".migration-private");
    fs::create_dir(&scratch)?;
    let mut report = MvccMigrationReport {
        backup_files,
        tables: 0,
        indexes: 0,
        rows: 0,
    };
    for table in catalog.tables() {
        let file = FileId::Heap(table.id);
        let mut input = HeapTable::open(working.join(file.name()), table.clone(), 64)?;
        let mut output = HeapTable::open_versioned(staging.join(file.name()), table.clone(), 64)?;
        output.begin_private(&scratch.join(file.name()), stable, &staging)?;
        let definitions: Vec<_> = catalog.indexes_for_table(table.id).cloned().collect();
        let mut indexes = Vec::new();
        for definition in &definitions {
            let identity = FileId::Index(definition.id);
            let mut tree = BPlusTree::open(
                staging.join(identity.name()),
                definition.unique,
                definition.columns.len(),
            )?;
            tree.begin_private(&scratch.join(identity.name()), stable, &staging)?;
            let columns: Vec<_> = definition
                .columns
                .iter()
                .map(|name| {
                    table
                        .column_index(name)
                        .ok_or_else(|| error("index references a missing column"))
                })
                .collect::<Result<_, _>>()?;
            indexes.push((identity, tree, columns));
        }
        let mut logical = 0u64;
        input.scan_visit(|_, row| {
            logical = logical
                .checked_add(1)
                .ok_or_else(|| error("logical row identity exhausted"))?;
            let rid = output.insert_version(
                TupleVersion {
                    logical_row: logical,
                    visibility: Version {
                        creator: stable,
                        deleter: None,
                    },
                    previous: None,
                },
                &row,
            )?;
            for (_, tree, columns) in &mut indexes {
                tree.insert(
                    IndexKey(
                        columns
                            .iter()
                            .map(|&column| row.values[column].clone())
                            .collect(),
                    ),
                    rid,
                )?;
            }
            Ok(true)
        })?;
        output.prepare_private_redo(file, |page, bytes, _| {
            wal.append_page(PageAction::Initialize, file, page, bytes)?;
            Ok(())
        })?;
        for (identity, tree, _) in &mut indexes {
            tree.prepare_private_redo(*identity, |page, bytes, _| {
                wal.append_page(PageAction::Initialize, *identity, page, bytes)?;
                Ok(())
            })?;
        }
        report.rows = report
            .rows
            .checked_add(logical)
            .ok_or_else(|| error("migration row count overflow"))?;
        report.tables += 1;
        report.indexes += indexes.len();
        // Only bounded private caches exist per table. The complete redo images
        // are in WAL; recovery installs them after its COMMIT becomes durable.
    }
    let receipt = wal.commit()?;
    transactions.commit(&receipt)?;
    phobos_observability::synchronization_boundary("c5_migration_after_commit", &source);
    phobos_observability::certification_crash("c5_migration_after_commit");
    drop(transactions);
    drop(wal);
    drop(catalog);
    let (mut statuses, wal) = StatusFile::recover_database(&staging)?;
    let catalog = Catalog::open(&staging)?;
    let mut snapshots = SnapshotRegistry::new(statuses.durable_frontier(), 1)?;
    let pin = snapshots.pin(None)?;
    let mut verified_rows = 0u64;
    for table in catalog.tables() {
        let mut heap = HeapTable::open_versioned(
            staging.join(FileId::Heap(table.id).name()),
            table.clone(),
            64,
        )?;
        heap.scan_visible(pin.snapshot(), &mut statuses, |_, _| {
            verified_rows += 1;
            Ok(true)
        })?;
    }
    if verified_rows != report.rows {
        return Err(error("migration visible row count mismatch"));
    }
    for index in catalog.indexes() {
        BPlusTree::open(
            staging.join(FileId::Index(index.id).name()),
            index.unique,
            index.columns.len(),
        )?
        .validate()?;
    }
    snapshots.release(pin)?;
    drop(catalog);
    drop(statuses);
    drop(wal);
    fs::remove_dir_all(&scratch)?;
    sync_directory_files(&staging)?;
    let mut marker = File::create(staging.join("PHOBOS_MVCC_COPY_1"))?;
    writeln!(
        marker,
        "capability=4 rows={} tables={} indexes={}",
        report.rows, report.tables, report.indexes
    )?;
    marker.sync_all()?;
    drop(marker);
    phobos_observability::synchronization_boundary("c5_migration_before_publish", &source);
    phobos_observability::certification_crash("c5_migration_before_publish");
    fs::rename(&staging, &destination)?;
    #[cfg(unix)]
    File::open(parent)?.sync_all()?;
    phobos_observability::synchronization_boundary("c5_migration_after_publish", &source);
    phobos_observability::certification_crash("c5_migration_after_publish");
    fs::remove_dir_all(&working)?;
    Ok(report)
}

fn append_metadata(wal: &mut Wal, identity: FileId, path: &Path) -> Result<(), PhobosError> {
    let mut file = File::open(path)?;
    let total_len = file.metadata()?.len();
    let mut offset = 0;
    loop {
        let count = (total_len - offset).min(60 * 1024) as usize;
        let mut bytes = vec![0; count];
        file.read_exact(&mut bytes)?;
        wal.append(Body::Metadata {
            file: identity,
            offset,
            total_len,
            bytes,
        })?;
        offset += count as u64;
        if offset == total_len {
            return Ok(());
        }
    }
}

fn resolve_new(path: &Path) -> Result<PathBuf, PhobosError> {
    if path.exists() {
        return Err(error("migration destination already exists"));
    }
    let parent = fs::canonicalize(
        path.parent()
            .ok_or_else(|| error("migration path needs parent"))?,
    )?;
    Ok(parent.join(
        path.file_name()
            .ok_or_else(|| error("migration path needs filename"))?,
    ))
}
fn overlaps(a: &Path, b: &Path) -> bool {
    a.starts_with(b) || b.starts_with(a)
}
fn error(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_types::Value;

    #[test]
    fn migration_twenty_crash_cycles_preserve_backup_and_committed_destination() {
        use std::process::{Command, exit};
        use std::sync::Arc;
        const TEST: &str = "mvcc_migration::tests::migration_twenty_crash_cycles_preserve_backup_and_committed_destination";
        const ENV: &str = "PHOBOS_C5_MIGRATION_CRASH";
        if let Ok(point) = std::env::var(ENV) {
            let root = PathBuf::from(std::env::var_os("PHOBOS_C5_MIGRATION_ROOT").unwrap());
            let source = root.join("source");
            let marker_path = root.join("crash.marker");
            let _hook = phobos_observability::test_hooks::register(
                &source,
                Arc::new(move |observed| {
                    if observed == point {
                        let mut marker = File::create(&marker_path).unwrap();
                        marker.write_all(observed.as_bytes()).unwrap();
                        marker.sync_all().unwrap();
                        exit(86);
                    }
                }),
            );
            migrate_mvcc_copy(&source, &root.join("backup"), &root.join("converted")).unwrap();
            panic!("migration crash hook was not reached");
        }
        for point in [
            "c5_migration_after_backup",
            "c5_migration_after_commit",
            "c5_migration_before_publish",
            "c5_migration_after_publish",
        ] {
            for round in 0..5 {
                let root = std::env::temp_dir().join(format!(
                    "phobos-migrate-crash-{}-{}-{round}",
                    std::process::id(),
                    std::time::SystemTime::now()
                        .duration_since(std::time::UNIX_EPOCH)
                        .unwrap()
                        .as_nanos()
                ));
                fs::create_dir(&root).unwrap();
                let source = root.join("source");
                {
                    let mut db = Database::open(&source).unwrap();
                    db.execute("CREATE TABLE t (id BIGINT, v BIGINT)").unwrap();
                    db.execute("INSERT INTO t VALUES (1,11),(2,22),(NULL,33)")
                        .unwrap();
                    db.execute("CREATE UNIQUE INDEX ix ON t (id,v)").unwrap();
                    db.shutdown().unwrap();
                }
                let original: Vec<_> = database_files(&source)
                    .unwrap()
                    .into_iter()
                    .map(|p| (p.file_name().unwrap().to_os_string(), fs::read(p).unwrap()))
                    .collect();
                let child = Command::new(std::env::current_exe().unwrap())
                    .args(["--exact", TEST, "--nocapture"])
                    .env(ENV, point)
                    .env("PHOBOS_C5_MIGRATION_ROOT", &root)
                    .output()
                    .unwrap();
                assert_eq!(
                    child.status.code(),
                    Some(86),
                    "{point}: {}",
                    String::from_utf8_lossy(&child.stderr)
                );
                assert_eq!(
                    fs::read_to_string(root.join("crash.marker")).unwrap(),
                    point
                );
                for (name, bytes) in &original {
                    assert_eq!(&fs::read(source.join(name)).unwrap(), bytes);
                    assert_eq!(&fs::read(root.join("backup").join(name)).unwrap(), bytes);
                }
                assert!(root.join("backup/PHOBOS_BACKUP_1").exists());
                let converted = if point == "c5_migration_after_publish" {
                    Some(root.join("converted"))
                } else {
                    assert!(!root.join("converted").exists());
                    fs::read_dir(&root)
                        .unwrap()
                        .map(|e| e.unwrap().path())
                        .find(|p| {
                            p.file_name()
                                .unwrap()
                                .to_string_lossy()
                                .starts_with(".phobos-mvcc-staging-")
                        })
                };
                if let Some(converted) = converted {
                    for _ in 0..2 {
                        let (mut statuses, wal) = StatusFile::recover_database(&converted).unwrap();
                        let catalog = Catalog::open(&converted).unwrap();
                        let table = catalog.table("t").unwrap().clone();
                        let mut heap = HeapTable::open_versioned(
                            converted.join(FileId::Heap(table.id).name()),
                            table,
                            2,
                        )
                        .unwrap();
                        let mut snapshots =
                            SnapshotRegistry::new(statuses.durable_frontier(), 1).unwrap();
                        let pin = snapshots.pin(None).unwrap();
                        let mut values = Vec::new();
                        heap.scan_visible(pin.snapshot(), &mut statuses, |_, row| {
                            values.push(row.values);
                            Ok(true)
                        })
                        .unwrap();
                        assert_eq!(
                            values,
                            vec![
                                vec![Value::Int64(1), Value::Int64(11)],
                                vec![Value::Int64(2), Value::Int64(22)],
                                vec![Value::Null, Value::Int64(33)]
                            ]
                        );
                        snapshots.release(pin).unwrap();
                        drop(heap);
                        drop(catalog);
                        drop(statuses);
                        drop(wal);
                    }
                }
                fs::remove_dir_all(root).unwrap();
            }
        }
    }

    #[test]
    fn backup_first_copy_preserves_source_and_rebuilds_versioned_index_rids() {
        let root = std::env::temp_dir().join(format!(
            "phobos-mvcc-migration-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir(&root).unwrap();
        let source = root.join("source");
        let backup = root.join("backup");
        let destination = root.join("converted");
        {
            let mut db = Database::open(&source).unwrap();
            db.execute("CREATE TABLE t (id BIGINT, v BIGINT)").unwrap();
            db.execute("CREATE TABLE empty (id BIGINT)").unwrap();
            for start in (0..1000).step_by(100) {
                let values = (start..start + 100)
                    .map(|id| format!("({id},{})", id + 10))
                    .collect::<Vec<_>>()
                    .join(",");
                db.execute(&format!("INSERT INTO t VALUES {values}"))
                    .unwrap();
            }
            db.execute("INSERT INTO t VALUES (NULL, 7),(NULL, 7)")
                .unwrap();
            db.execute("CREATE UNIQUE INDEX ix ON t (id,v)").unwrap();
            db.shutdown().unwrap();
        }
        let original: Vec<_> = database_files(&source)
            .unwrap()
            .into_iter()
            .map(|path| {
                (
                    path.file_name().unwrap().to_os_string(),
                    fs::read(path).unwrap(),
                )
            })
            .collect();
        let report = migrate_mvcc_copy(&source, &backup, &destination).unwrap();
        assert_eq!(report.rows, 1002);
        assert_eq!(report.tables, 2);
        assert_eq!(report.indexes, 1);
        for (name, bytes) in &original {
            assert_eq!(&fs::read(source.join(name)).unwrap(), bytes);
            assert_eq!(&fs::read(backup.join(name)).unwrap(), bytes);
        }
        assert!(backup.join("PHOBOS_BACKUP_1").exists());
        assert_eq!(
            phobos_wal::v2::inspect(destination.join("phobos.wal"))
                .unwrap()
                .page_format,
            4
        );
        assert!(Database::open(&destination).is_err()); // Legacy embedded open must still reject capability 4.
        let (mut statuses, wal) = StatusFile::recover_database(&destination).unwrap();
        let catalog = Catalog::open(&destination).unwrap();
        let schema = catalog.table("t").unwrap().clone();
        let index = catalog.index("ix").unwrap();
        let mut tree =
            BPlusTree::open(destination.join(FileId::Index(index.id).name()), true, 2).unwrap();
        let ids = tree
            .point_lookup(&IndexKey(vec![Value::Int64(999), Value::Int64(1009)]))
            .unwrap();
        assert_eq!(ids.len(), 1);
        let mut heap =
            HeapTable::open_versioned(destination.join(FileId::Heap(schema.id).name()), schema, 2)
                .unwrap();
        let mut snapshots = SnapshotRegistry::new(statuses.durable_frontier(), 1).unwrap();
        let pin = snapshots.pin(None).unwrap();
        assert_eq!(
            heap.get_visible(ids[0], pin.snapshot(), &mut statuses)
                .unwrap()
                .unwrap()
                .values,
            vec![Value::Int64(999), Value::Int64(1009)]
        );
        snapshots.release(pin).unwrap();
        drop(heap);
        drop(tree);
        drop(catalog);
        drop(statuses);
        drop(wal);
        assert!(migrate_mvcc_copy(&source, &backup, &root.join("another")).is_err());
        assert!(!root.join("another").exists());
        fs::remove_dir_all(root).unwrap();
    }
}
