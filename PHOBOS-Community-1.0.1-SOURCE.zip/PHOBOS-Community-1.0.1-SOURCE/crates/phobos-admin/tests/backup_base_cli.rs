use phobos_execution::mvcc_runtime::MvccDatabase;
use std::{
    path::Path,
    process::Command,
    time::{SystemTime, UNIX_EPOCH},
};
fn command(args: &[&Path], verb: &str) -> bool {
    Command::new(env!("CARGO_BIN_EXE_phobos-admin"))
        .arg(verb)
        .args(args)
        .output()
        .unwrap()
        .status
        .success()
}
#[test]
fn checkpointed_cli_base_supports_pitr_replication_and_rejects_bad_inputs() {
    let root = std::env::temp_dir().join(format!(
        "phobos-base-cli-{}-{}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    std::fs::create_dir_all(&root).unwrap();
    let missing = root.join("missing");
    let base = root.join("base");
    assert!(!command(&[&missing, &base], "backup-base"));
    assert!(!missing.exists());
    assert!(!base.exists());
    let instance = root.join("instance");
    assert!(command(&[&instance], "init"));
    let data = instance.join("data");
    let owner = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(data.join("phobos.lock"))
        .unwrap();
    fs2::FileExt::try_lock_exclusive(&owner).unwrap();
    let db = MvccDatabase::open(&data).unwrap();
    db.execute(
        1,
        "CREATE TABLE t (id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, label TEXT)",
    )
    .unwrap();
    db.execute(1, "INSERT INTO t (label) VALUES ('base')")
        .unwrap();
    assert!(!command(&[&data, &base], "backup-base"));
    drop(db);
    drop(owner);
    assert!(command(&[&data, &base], "backup-base"));
    assert!(base.join("PHOBOS_BACKUP_2").is_file());
    assert!(!command(&[&data, &base], "backup-base"));
    phobos_admin::retain_wal_for_backup(&data, &base, "base-cli").unwrap();
    let standby = root.join("standby");
    phobos_admin::initialize_standby(&data, &base, &standby, "replica-cli").unwrap();
    let db = MvccDatabase::open(&data).unwrap();
    db.execute(1, "INSERT INTO t (label) VALUES ('later')")
        .unwrap();
    let lsn = db.wal_position().unwrap().1;
    let expected = db
        .execute(1, "SELECT * FROM t ORDER BY id")
        .unwrap()
        .to_text();
    drop(db);
    let archive = root.join("archive");
    phobos_admin::archive_wal(&data, &archive).unwrap();
    let recovered = root.join("recovered");
    phobos_admin::pitr_recover_to(&base, &archive, &recovered, lsn).unwrap();
    phobos_admin::receive_wal(&data, &standby).unwrap();
    phobos_admin::replay_received(&standby).unwrap();
    for path in [&recovered, &standby] {
        phobos_admin::check_integrity(path).unwrap();
        let db = MvccDatabase::open(path).unwrap();
        assert_eq!(
            db.execute(2, "SELECT * FROM t ORDER BY id")
                .unwrap()
                .to_text(),
            expected
        );
    }
    std::fs::remove_dir_all(root).unwrap();
}
