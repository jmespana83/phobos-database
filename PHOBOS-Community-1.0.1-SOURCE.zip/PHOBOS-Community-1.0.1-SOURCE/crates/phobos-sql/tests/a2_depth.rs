use phobos_error::ErrorCode;
use phobos_sql::{MAX_PARSE_DEPTH, parse};
fn sql(expr: String) -> String {
    format!("SELECT x FROM t WHERE {expr}")
}
fn shapes(n: usize) -> Vec<String> {
    vec![
        sql(format!("{}x{}", "(".repeat(n), ")".repeat(n))),
        sql(format!("{}x", "NOT ".repeat(n))),
        sql(format!("{}x", "- ".repeat(n))),
        sql(format!("{}x", "x OR ".repeat(n))),
        sql(format!("{}x", "x AND ".repeat(n))),
        sql(format!("{}x", "x + ".repeat(n))),
        sql(format!("{}x", "x * ".repeat(n))),
        format!("{}SELECT x FROM t", "EXPLAIN ".repeat(n)),
    ]
}
#[test]
fn a2_depth_boundaries_and_error_unwind() {
    for n in [MAX_PARSE_DEPTH - 1, MAX_PARSE_DEPTH, MAX_PARSE_DEPTH + 1] {
        for input in shapes(n) {
            let result = parse(&input);
            if input.starts_with("EXPLAIN") && n <= MAX_PARSE_DEPTH {
                assert_eq!(result.unwrap_err().code, ErrorCode::SqlSyntax);
            } else if n <= MAX_PARSE_DEPTH {
                assert!(result.is_ok(), "{input}: {result:?}");
            } else {
                assert_eq!(result.unwrap_err().code, ErrorCode::ParserDepth, "{input}");
            }
            assert!(parse("SELECT x FROM t WHERE x = 1").is_ok());
        }
    }
    let mixed = format!("{}x{}", "NOT (- (".repeat(1000), "))".repeat(1000));
    assert_eq!(parse(&sql(mixed)).unwrap_err().code, ErrorCode::ParserDepth);
    assert_eq!(
        parse(&sql("(".repeat(10000))).unwrap_err().code,
        ErrorCode::ParserDepth
    );
}
#[test]
fn a2_malicious_subprocess() {
    const CHILD: &str = "PHOBOS_A2_PARSER_CHILD";
    if std::env::var_os(CHILD).is_some() {
        for input in shapes(20000) {
            assert_eq!(parse(&input).unwrap_err().code, ErrorCode::ParserDepth);
        }
        return;
    }
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "a2_malicious_subprocess", "--nocapture"])
        .env(CHILD, "1")
        .status()
        .unwrap();
    assert!(
        status.success(),
        "malicious input subprocess failed: {status}"
    );
}
