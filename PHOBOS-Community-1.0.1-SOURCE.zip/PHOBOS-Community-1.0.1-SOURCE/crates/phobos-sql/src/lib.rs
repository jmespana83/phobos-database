#![forbid(unsafe_code)]
//! Owned SQL AST and parser through Phase 6: DML, indexes, joins, aggregates, ANALYZE, and EXPLAIN.

use phobos_error::{ErrorCode, PhobosError};
use phobos_types::{ColumnSchema, DataType, Value};

#[derive(Debug, Clone, PartialEq)]
pub enum Statement {
    CreateView {
        name: String,
        query: Box<Statement>,
        sql: String,
    },
    DropView {
        name: String,
    },
    CreateDefinedTable {
        name: String,
        columns: Vec<ColumnSchema>,
        defaults: Vec<(String, Expr)>,
        checks: Vec<Expr>,
        primary_key: Vec<String>,
        identity: Option<(String, bool)>,
        foreign_keys: Vec<(Vec<String>, String, Vec<String>)>,
    },
    AlterNullable {
        table: String,
        column: String,
        nullable: bool,
    },
    AddColumn {
        table: String,
        column: ColumnSchema,
        default: Option<Expr>,
    },
    AlterDefault {
        table: String,
        column: String,
        value: Option<Expr>,
    },
    RenameTable {
        table: String,
        column: Option<String>,
        new_name: String,
    },
    ShowCatalog {
        kind: CatalogKind,
        table: Option<String>,
    },
    CreateTable {
        name: String,
        columns: Vec<ColumnSchema>,
    },
    CreatePartitionedTable {
        name: String,
        columns: Vec<ColumnSchema>,
        key: String,
    },
    CreateRangePartition {
        name: String,
        parent: String,
        lower: Expr,
        upper: Expr,
    },
    CreateIndex {
        name: String,
        table: String,
        columns: Vec<String>,
        unique: bool,
    },
    DropIndex {
        name: String,
    },
    InsertSelect {
        table: String,
        columns: Option<Vec<String>>,
        query: Box<Statement>,
    },
    Union {
        left: Box<Statement>,
        right: Box<Statement>,
        all: bool,
        order_by: Vec<OrderBy>,
        limit: Option<Expr>,
        offset: Option<Expr>,
    },
    InsertReturning {
        statement: Box<Statement>,
        columns: SelectColumns,
    },
    InsertColumns {
        table: String,
        columns: Vec<String>,
        rows: Vec<Vec<Expr>>,
    },
    Insert {
        table: String,
        rows: Vec<Vec<Expr>>,
    },
    Select {
        table: String,
        columns: SelectColumns,
        filter: Option<Expr>,
        order_by: Vec<OrderBy>,
        limit: Option<Expr>,
        offset: Option<Expr>,
    },
    RelationalSelect(RelationalSelect),
    Analyze {
        table: String,
    },
    Explain {
        analyze: bool,
        statement: Box<Statement>,
    },
    Update {
        table: String,
        assignments: Vec<(String, Expr)>,
        filter: Option<Expr>,
    },
    Delete {
        table: String,
        filter: Option<Expr>,
    },
    Begin,
    BeginSnapshot,
    Savepoint {
        name: String,
    },
    RollbackTo {
        name: String,
    },
    ReleaseSavepoint {
        name: String,
    },
    Commit,
    Rollback,
    Checkpoint,
}

/// Version 1 management result sets, carried by the normal SQL protocol.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CatalogKind {
    Views,
    Tables,
    Columns,
    Indexes,
    Constraints,
    Capabilities,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SelectColumns {
    All,
    Named(Vec<String>),
}

#[derive(Debug, Clone, PartialEq)]
pub struct RelationalSelect {
    /// Query-local derived input. Never a catalog or storage object.
    pub source: Option<Box<Statement>>,
    pub table: String,
    pub alias: Option<String>,
    pub items: Vec<SelectItem>,
    pub distinct: bool,
    pub joins: Vec<JoinClause>,
    pub filter: Option<Expr>,
    pub group_by: Vec<String>,
    pub having: Option<Expr>,
    pub order_by: Vec<OrderBy>,
    pub limit: Option<Expr>,
    pub offset: Option<Expr>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum SelectItem {
    All,
    Column {
        name: String,
        alias: Option<String>,
    },
    Aggregate {
        function: AggregateFunction,
        column: Option<String>,
        alias: Option<String>,
    },
    Expression {
        expr: Expr,
        alias: Option<String>,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AggregateFunction {
    Count,
    Sum,
    Avg,
    Min,
    Max,
}

#[derive(Debug, Clone, PartialEq)]
pub struct JoinClause {
    pub predicate: Option<Expr>,
    pub kind: JoinKind,
    pub table: String,
    pub alias: Option<String>,
    pub left_column: String,
    pub right_column: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum JoinKind {
    Inner,
    Left,
}

#[derive(Debug, Clone, PartialEq)]
pub struct OrderBy {
    pub column: String,
    pub ascending: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    ScalarSubquery(Box<Statement>),
    Exists(Box<Statement>),
    Literal(Value),
    Column(String),
    QuotedColumn(String),
    Parameter(usize),
    Unary {
        op: UnaryOp,
        expr: Box<Expr>,
    },
    Binary {
        left: Box<Expr>,
        op: BinaryOp,
        right: Box<Expr>,
    },
    IsNull {
        expr: Box<Expr>,
        negated: bool,
    },
    Function {
        name: String,
        args: Vec<Expr>,
    },
    Like {
        expr: Box<Expr>,
        pattern: Box<Expr>,
    },
    InList {
        expr: Box<Expr>,
        values: Vec<Expr>,
    },
    InSubquery {
        expr: Box<Expr>,
        query: Box<Statement>,
    },
    Case {
        branches: Vec<(Expr, Expr)>,
        else_expr: Option<Box<Expr>>,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp {
    Not,
    Negate,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinaryOp {
    Or,
    And,
    Eq,
    NotEq,
    Lt,
    LtEq,
    Gt,
    GtEq,
    Add,
    Subtract,
    Multiply,
    Divide,
}

#[derive(Debug, Clone, PartialEq)]
enum Token {
    Word(String),
    QuotedWord(String),
    Number(String),
    String(String),
    Parameter(usize),
    LParen,
    RParen,
    Comma,
    Star,
    Semicolon,
    Eq,
    NotEq,
    Lt,
    LtEq,
    Gt,
    GtEq,
    Plus,
    Minus,
    Slash,
}

pub fn parse(sql: &str) -> Result<Statement, PhobosError> {
    let _profile = phobos_observability::span("sql.parse");
    let tokens = tokenize(sql)?;
    let mut parser = Parser {
        tokens,
        cursor: 0,
        depth: 0,
        ctes: Vec::new(),
        defining: Vec::new(),
        expansion_bytes: 0,
    };
    let statement = parser.parse_statement()?;
    if parser.expansion_bytes > 0 {
        check_expanded_query_depth(&statement)?;
    }
    let _ = parser.consume_token(&Token::Semicolon);
    if parser.cursor != parser.tokens.len() {
        return Err(parser.error("unexpected trailing SQL input"));
    }
    Ok(statement)
}

fn tokenize(sql: &str) -> Result<Vec<Token>, PhobosError> {
    let chars: Vec<char> = sql.chars().collect();
    let mut tokens = Vec::new();
    let mut index = 0usize;
    while index < chars.len() {
        let ch = chars[index];
        if ch.is_whitespace() {
            index += 1;
            continue;
        }
        match ch {
            '-' if index + 1 < chars.len() && chars[index + 1] == '-' => {
                index += 2;
                while index < chars.len() && chars[index] != '\n' {
                    index += 1;
                }
            }
            '/' if index + 1 < chars.len() && chars[index + 1] == '*' => {
                index += 2;
                let mut closed = false;
                while index + 1 < chars.len() {
                    if chars[index] == '*' && chars[index + 1] == '/' {
                        index += 2;
                        closed = true;
                        break;
                    }
                    index += 1;
                }
                if !closed {
                    return Err(PhobosError::new(
                        ErrorCode::SqlSyntax,
                        "unterminated block comment",
                    ));
                }
            }
            '"' => {
                index += 1;
                let mut value = String::new();
                let mut closed = false;
                while index < chars.len() {
                    if chars[index] == '"' {
                        if index + 1 < chars.len() && chars[index + 1] == '"' {
                            value.push('"');
                            index += 2;
                        } else {
                            index += 1;
                            closed = true;
                            break;
                        }
                    } else {
                        value.push(chars[index]);
                        index += 1;
                    }
                }
                if !closed {
                    return Err(PhobosError::new(
                        ErrorCode::SqlSyntax,
                        "unterminated quoted identifier",
                    ));
                }
                tokens.push(Token::QuotedWord(value));
            }
            '(' => {
                tokens.push(Token::LParen);
                index += 1;
            }
            ')' => {
                tokens.push(Token::RParen);
                index += 1;
            }
            ',' => {
                tokens.push(Token::Comma);
                index += 1;
            }
            '*' => {
                tokens.push(Token::Star);
                index += 1;
            }
            ';' => {
                tokens.push(Token::Semicolon);
                index += 1;
            }
            '+' => {
                tokens.push(Token::Plus);
                index += 1;
            }
            '-' => {
                tokens.push(Token::Minus);
                index += 1;
            }
            '/' => {
                tokens.push(Token::Slash);
                index += 1;
            }
            '=' => {
                tokens.push(Token::Eq);
                index += 1;
            }
            '<' => {
                if index + 1 < chars.len() && chars[index + 1] == '=' {
                    tokens.push(Token::LtEq);
                    index += 2;
                } else if index + 1 < chars.len() && chars[index + 1] == '>' {
                    tokens.push(Token::NotEq);
                    index += 2;
                } else {
                    tokens.push(Token::Lt);
                    index += 1;
                }
            }
            '>' => {
                if index + 1 < chars.len() && chars[index + 1] == '=' {
                    tokens.push(Token::GtEq);
                    index += 2;
                } else {
                    tokens.push(Token::Gt);
                    index += 1;
                }
            }
            '!' if index + 1 < chars.len() && chars[index + 1] == '=' => {
                tokens.push(Token::NotEq);
                index += 2;
            }
            '$' => {
                let start = index + 1;
                index += 1;
                while index < chars.len() && chars[index].is_ascii_digit() {
                    index += 1;
                }
                if start == index {
                    return Err(PhobosError::new(
                        ErrorCode::SqlSyntax,
                        "parameter must use $1, $2, ...",
                    ));
                }
                let n: usize = chars[start..index]
                    .iter()
                    .collect::<String>()
                    .parse()
                    .map_err(|_| {
                        PhobosError::new(ErrorCode::SqlSyntax, "invalid parameter number")
                    })?;
                if n == 0 {
                    return Err(PhobosError::new(
                        ErrorCode::SqlSyntax,
                        "parameter numbering starts at $1",
                    ));
                }
                tokens.push(Token::Parameter(n - 1));
            }
            '\'' => {
                index += 1;
                let mut value = String::new();
                let mut closed = false;
                while index < chars.len() {
                    if chars[index] == '\'' {
                        if index + 1 < chars.len() && chars[index + 1] == '\'' {
                            value.push('\'');
                            index += 2;
                        } else {
                            index += 1;
                            closed = true;
                            break;
                        }
                    } else {
                        value.push(chars[index]);
                        index += 1;
                    }
                }
                if !closed {
                    return Err(PhobosError::new(
                        ErrorCode::SqlSyntax,
                        "unterminated string literal",
                    ));
                }
                tokens.push(Token::String(value));
            }
            value if value.is_ascii_digit() => {
                let start = index;
                index += 1;
                while index < chars.len() && (chars[index].is_ascii_digit() || chars[index] == '.')
                {
                    index += 1;
                }
                tokens.push(Token::Number(chars[start..index].iter().collect()));
            }
            value if value.is_ascii_alphabetic() || value == '_' => {
                let start = index;
                index += 1;
                while index < chars.len()
                    && (chars[index].is_ascii_alphanumeric()
                        || chars[index] == '_'
                        || chars[index] == '.')
                {
                    index += 1;
                }
                tokens.push(Token::Word(chars[start..index].iter().collect()));
            }
            _ => {
                return Err(PhobosError::new(
                    ErrorCode::SqlSyntax,
                    format!("unexpected character {ch:?}"),
                ));
            }
        }
    }
    Ok(tokens)
}

/// Maximum recursive syntax nesting and expression-tree height (leaves have height zero).
// Bound debug and release parser stack use on standard Windows worker stacks.
pub const MAX_PARSE_DEPTH: usize = 32;

struct Parser {
    ctes: Vec<(String, Statement)>,
    defining: Vec<String>,
    expansion_bytes: usize,
    depth: usize,
    tokens: Vec<Token>,
    cursor: usize,
}

impl Parser {
    // All recursive grammar edges share this budget. Restore it on errors too.
    fn nested<T>(
        &mut self,
        parse: impl FnOnce(&mut Self) -> Result<T, PhobosError>,
    ) -> Result<T, PhobosError> {
        Self::check_depth(self.depth + 1)?;
        self.depth += 1;
        let result = parse(self);
        self.depth -= 1;
        result
    }
    fn check_depth(depth: usize) -> Result<(), PhobosError> {
        if depth > MAX_PARSE_DEPTH {
            Err(PhobosError::new(
                ErrorCode::ParserDepth,
                "SQL parser depth limit exceeded",
            ))
        } else {
            Ok(())
        }
    }
    // Iterative grammar rules can also build deep trees. Check at construction,
    // before a dangerous tree can reach evaluation, cloning or recursive Drop.
    fn bounded(expr: Expr) -> Result<Expr, PhobosError> {
        let mut pending = vec![(&expr, 0)];
        while let Some((node, depth)) = pending.pop() {
            Self::check_depth(depth)?;
            match node {
                Expr::Binary { left, right, .. } => {
                    pending.push((left, depth + 1));
                    pending.push((right, depth + 1));
                }
                Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => {
                    pending.push((expr, depth + 1))
                }
                Expr::Function { args, .. } => {
                    pending.extend(args.iter().map(|arg| (arg, depth + 1)));
                }
                Expr::Like { expr, pattern } => {
                    pending.push((expr, depth + 1));
                    pending.push((pattern, depth + 1));
                }
                Expr::InList { expr, values } => {
                    pending.push((expr, depth + 1));
                    pending.extend(values.iter().map(|value| (value, depth + 1)));
                }
                Expr::InSubquery { expr, .. } => pending.push((expr, depth + 1)),
                Expr::Case {
                    branches,
                    else_expr,
                } => {
                    for (when, then) in branches {
                        pending.push((when, depth + 1));
                        pending.push((then, depth + 1));
                    }
                    if let Some(expr) = else_expr {
                        pending.push((expr, depth + 1));
                    }
                }
                _ => (),
            }
        }
        Ok(expr)
    }

    fn parse_statement(&mut self) -> Result<Statement, PhobosError> {
        if self.consume_keyword("WITH") {
            let saved = self.ctes.len();
            let result = self.nested(|parser| {
                loop {
                    let name = parser.expect_word()?;
                    if parser.ctes[saved..]
                        .iter()
                        .any(|(n, _)| n.eq_ignore_ascii_case(&name))
                    {
                        return Err(parser.error("duplicate CTE name"));
                    }
                    parser.expect_keyword("AS")?;
                    parser.expect_token(Token::LParen)?;
                    parser.defining.push(name.clone());
                    let query = parser.nested(Self::parse_statement)?;
                    check_expanded_query_depth(&query)?;
                    parser.defining.pop();
                    if !matches!(
                        query,
                        Statement::Select { .. }
                            | Statement::RelationalSelect(_)
                            | Statement::Union { .. }
                    ) {
                        return Err(parser.error("CTE must contain a SELECT"));
                    }
                    parser.expect_token(Token::RParen)?;
                    parser.ctes.push((name, query));
                    if parser.ctes.len() > 64 {
                        return Err(parser.error("too many CTEs"));
                    }
                    if !parser.consume_token(&Token::Comma) {
                        break;
                    }
                }
                parser.expect_keyword("SELECT")?;
                parser.parse_select()
            });
            self.ctes.truncate(saved);
            return result;
        }
        if self.consume_keyword("ALTER") {
            self.expect_keyword("TABLE")?;
            let table = self.expect_word()?;
            if self.consume_keyword("ADD") {
                self.expect_keyword("COLUMN")?;
                let name = self.expect_word()?;
                let data_type = self.parse_data_type()?;
                let mut nullable = true;
                let mut default = None;
                loop {
                    if self.consume_keyword("NOT") {
                        self.expect_keyword("NULL")?;
                        nullable = false;
                    } else if self.consume_keyword("NULL") {
                        nullable = true;
                    } else if self.consume_keyword("DEFAULT") {
                        if default.is_some() {
                            return Err(self.error("duplicate default"));
                        }
                        default = Some(self.parse_expr()?);
                    } else {
                        break;
                    }
                }
                return Ok(Statement::AddColumn {
                    table,
                    column: ColumnSchema {
                        name,
                        data_type,
                        nullable,
                    },
                    default,
                });
            }
            if self.consume_keyword("ALTER") {
                self.expect_keyword("COLUMN")?;
                let column = self.expect_word()?;
                let set = self.consume_keyword("SET");
                if !set {
                    self.expect_keyword("DROP")?;
                }
                if self.consume_keyword("NOT") {
                    self.expect_keyword("NULL")?;
                    return Ok(Statement::AlterNullable {
                        table,
                        column,
                        nullable: !set,
                    });
                }
                self.expect_keyword("DEFAULT")?;
                let value = if set { Some(self.parse_expr()?) } else { None };
                return Ok(Statement::AlterDefault {
                    table,
                    column,
                    value,
                });
            }
            self.expect_keyword("RENAME")?;
            let column = if self.consume_keyword("COLUMN") {
                Some(self.expect_word()?)
            } else {
                None
            };
            self.expect_keyword("TO")?;
            return Ok(Statement::RenameTable {
                table,
                column,
                new_name: self.expect_word()?,
            });
        }
        if self.consume_keyword("SHOW") {
            self.expect_keyword("CATALOG")?;
            let kind = match self.expect_word()?.to_ascii_uppercase().as_str() {
                "VIEWS" => CatalogKind::Views,
                "TABLES" => CatalogKind::Tables,
                "COLUMNS" => CatalogKind::Columns,
                "INDEXES" => CatalogKind::Indexes,
                "CONSTRAINTS" => CatalogKind::Constraints,
                "CAPABILITIES" => CatalogKind::Capabilities,
                _ => return Err(self.error("unknown catalog result set")),
            };
            let table = if self.consume_keyword("FROM") {
                Some(self.expect_word()?)
            } else {
                None
            };
            if kind == CatalogKind::Capabilities && table.is_some() {
                return Err(self.error("CAPABILITIES does not accept FROM"));
            }
            return Ok(Statement::ShowCatalog { kind, table });
        }
        if self.consume_keyword("EXPLAIN") {
            let analyze = self.consume_keyword("ANALYZE");
            let statement = self.nested(Self::parse_statement)?;
            if !matches!(
                statement,
                Statement::Select { .. } | Statement::RelationalSelect(_) | Statement::Union { .. }
            ) {
                return Err(self.error("EXPLAIN currently supports SELECT only"));
            }
            return Ok(Statement::Explain {
                analyze,
                statement: Box::new(statement),
            });
        }
        if self.consume_keyword("ANALYZE") {
            return Ok(Statement::Analyze {
                table: self.expect_word()?,
            });
        }
        if self.consume_keyword("CREATE") {
            if self.consume_keyword("VIEW") {
                let name = self.expect_word()?;
                self.expect_keyword("AS")?;
                let start = self.cursor;
                let query = self.nested(Self::parse_statement)?;
                if !matches!(
                    query,
                    Statement::Select { .. }
                        | Statement::RelationalSelect(_)
                        | Statement::Union { .. }
                ) {
                    return Err(self.error("view must be read-only SELECT"));
                }
                if self.tokens[start..self.cursor]
                    .iter()
                    .any(|t| matches!(t, Token::Parameter(_)))
                {
                    return Err(self.error("view cannot contain parameters"));
                }
                let sql = self.tokens[start..self.cursor]
                    .iter()
                    .map(token_sql)
                    .collect::<Vec<_>>()
                    .join(" ");
                return Ok(Statement::CreateView {
                    name,
                    query: Box::new(query),
                    sql,
                });
            }
            let unique = self.consume_keyword("UNIQUE");
            if self.consume_keyword("TABLE") {
                if unique {
                    return Err(self.error("UNIQUE is only valid with CREATE INDEX"));
                }
                return self.parse_create_table();
            }
            if self.consume_keyword("INDEX") {
                return self.parse_create_index(unique);
            }
            return Err(self.error("expected TABLE or INDEX after CREATE"));
        }
        if self.consume_keyword("DROP") {
            if self.consume_keyword("VIEW") {
                return Ok(Statement::DropView {
                    name: self.expect_word()?,
                });
            }
            self.expect_keyword("INDEX")?;
            return Ok(Statement::DropIndex {
                name: self.expect_word()?,
            });
        }
        if self.consume_keyword("INSERT") {
            self.expect_keyword("INTO")?;
            return self.parse_insert();
        }
        if self.consume_keyword("SELECT") {
            return self.parse_select();
        }
        if self.consume_keyword("UPDATE") {
            return self.parse_update();
        }
        if self.consume_keyword("DELETE") {
            self.expect_keyword("FROM")?;
            return self.parse_delete();
        }
        if self.consume_keyword("BEGIN") {
            let _ = self.consume_keyword("TRANSACTION");
            if self.consume_keyword("ISOLATION") {
                self.expect_keyword("LEVEL")?;
                self.expect_keyword("SNAPSHOT")?;
                return Ok(Statement::BeginSnapshot);
            }
            return Ok(Statement::Begin);
        }
        if self.consume_keyword("COMMIT") {
            return Ok(Statement::Commit);
        }
        if self.consume_keyword("ROLLBACK") {
            if self.consume_keyword("TO") {
                let _ = self.consume_keyword("SAVEPOINT");
                return Ok(Statement::RollbackTo {
                    name: self.expect_word()?,
                });
            }
            return Ok(Statement::Rollback);
        }
        if self.consume_keyword("SAVEPOINT") {
            return Ok(Statement::Savepoint {
                name: self.expect_word()?,
            });
        }
        if self.consume_keyword("RELEASE") {
            self.expect_keyword("SAVEPOINT")?;
            return Ok(Statement::ReleaseSavepoint {
                name: self.expect_word()?,
            });
        }
        if self.consume_keyword("CHECKPOINT") {
            return Ok(Statement::Checkpoint);
        }
        Err(self.error("expected CREATE, DROP, INSERT, SELECT, UPDATE, DELETE, ANALYZE, EXPLAIN, BEGIN, COMMIT, ROLLBACK, or CHECKPOINT"))
    }

    fn parse_create_table(&mut self) -> Result<Statement, PhobosError> {
        let name = self.expect_word()?;
        if self.consume_keyword("PARTITION") {
            self.expect_keyword("OF")?;
            let parent = self.expect_word()?;
            self.expect_keyword("FOR")?;
            self.expect_keyword("VALUES")?;
            self.expect_keyword("FROM")?;
            self.expect_token(Token::LParen)?;
            let lower = self.parse_expr()?;
            self.expect_token(Token::RParen)?;
            self.expect_keyword("TO")?;
            self.expect_token(Token::LParen)?;
            let upper = self.parse_expr()?;
            self.expect_token(Token::RParen)?;
            return Ok(Statement::CreateRangePartition {
                name,
                parent,
                lower,
                upper,
            });
        }
        self.expect_token(Token::LParen)?;
        let mut columns = Vec::new();
        let mut defaults = Vec::new();
        let mut checks = Vec::new();
        let mut primary_key = Vec::new();
        let mut identity = None;
        let mut foreign_keys = Vec::new();
        loop {
            if self.consume_keyword("FOREIGN") {
                self.expect_keyword("KEY")?;
                let child = self.parse_column_list()?;
                self.expect_keyword("REFERENCES")?;
                let parent = self.expect_word()?;
                let referenced = self.parse_column_list()?;
                let mut actions = std::collections::BTreeSet::new();
                while self.consume_keyword("ON") {
                    let action = self.expect_word()?.to_ascii_uppercase();
                    if !matches!(action.as_str(), "DELETE" | "UPDATE") || !actions.insert(action) {
                        return Err(self.error("invalid or repeated FK action"));
                    }
                    if !self.consume_keyword("RESTRICT") {
                        self.expect_keyword("NO")?;
                        self.expect_keyword("ACTION")?;
                    }
                }
                foreign_keys.push((child, parent, referenced));
            } else if self.consume_keyword("CHECK") {
                self.expect_token(Token::LParen)?;
                checks.push(self.parse_expr()?);
                self.expect_token(Token::RParen)?;
            } else if self.consume_keyword("PRIMARY") {
                self.expect_keyword("KEY")?;
                if !primary_key.is_empty() {
                    return Err(self.error("multiple primary keys"));
                }
                self.expect_token(Token::LParen)?;
                primary_key.push(self.expect_word()?);
                while self.consume_token(&Token::Comma) {
                    primary_key.push(self.expect_word()?);
                }
                self.expect_token(Token::RParen)?;
            } else {
                let column_name = self.expect_word()?;
                let data_type = self.parse_data_type()?;
                let mut nullable = true;
                let mut null_seen = false;
                let mut default_seen = false;
                loop {
                    if self.consume_keyword("NOT") {
                        self.expect_keyword("NULL")?;
                        if null_seen {
                            return Err(self.error("duplicate nullability"));
                        }
                        nullable = false;
                        null_seen = true;
                    } else if self.consume_keyword("NULL") {
                        if null_seen {
                            return Err(self.error("duplicate nullability"));
                        }
                        nullable = true;
                        null_seen = true;
                    } else if self.consume_keyword("GENERATED") {
                        if identity.is_some() || default_seen {
                            return Err(
                                self.error("one identity per table; identity cannot have DEFAULT")
                            );
                        }
                        let always = if self.consume_keyword("ALWAYS") {
                            true
                        } else {
                            self.expect_keyword("BY")?;
                            self.expect_keyword("DEFAULT")?;
                            false
                        };
                        self.expect_keyword("AS")?;
                        self.expect_keyword("IDENTITY")?;
                        if data_type != DataType::Int64 {
                            return Err(self.error("identity requires BIGINT"));
                        }
                        identity = Some((column_name.clone(), always));
                        nullable = false;
                    } else if self.consume_keyword("DEFAULT") {
                        if default_seen
                            || identity
                                .as_ref()
                                .is_some_and(|(name, _)| name == &column_name)
                        {
                            return Err(self.error("duplicate default"));
                        }
                        defaults.push((column_name.clone(), self.parse_expr()?));
                        default_seen = true;
                    } else if self.consume_keyword("PRIMARY") {
                        self.expect_keyword("KEY")?;
                        if !primary_key.is_empty() {
                            return Err(self.error("multiple primary keys"));
                        }
                        primary_key.push(column_name.clone());
                    } else if self.consume_keyword("CHECK") {
                        self.expect_token(Token::LParen)?;
                        checks.push(self.parse_expr()?);
                        self.expect_token(Token::RParen)?;
                    } else {
                        break;
                    }
                }
                columns.push(ColumnSchema {
                    name: column_name,
                    data_type,
                    nullable,
                });
            }
            if !self.consume_token(&Token::Comma) {
                self.expect_token(Token::RParen)?;
                break;
            }
        }
        let defined = !foreign_keys.is_empty()
            || !defaults.is_empty()
            || !checks.is_empty()
            || !primary_key.is_empty()
            || identity.is_some();
        if self.consume_keyword("PARTITION") {
            if defined {
                return Err(
                    self.error("schema definitions on partitioned tables are not supported")
                );
            }
            self.expect_keyword("BY")?;
            self.expect_keyword("RANGE")?;
            self.expect_token(Token::LParen)?;
            let key = self.expect_word()?;
            self.expect_token(Token::RParen)?;
            Ok(Statement::CreatePartitionedTable { name, columns, key })
        } else if defined {
            Ok(Statement::CreateDefinedTable {
                name,
                columns,
                defaults,
                checks,
                primary_key,
                identity,
                foreign_keys,
            })
        } else {
            Ok(Statement::CreateTable { name, columns })
        }
    }

    fn parse_column_list(&mut self) -> Result<Vec<String>, PhobosError> {
        self.expect_token(Token::LParen)?;
        let mut columns = vec![self.expect_word()?];
        while self.consume_token(&Token::Comma) {
            columns.push(self.expect_word()?);
        }
        self.expect_token(Token::RParen)?;
        Ok(columns)
    }
    fn parse_create_index(&mut self, unique: bool) -> Result<Statement, PhobosError> {
        let name = self.expect_word()?;
        self.expect_keyword("ON")?;
        let table = self.expect_word()?;
        self.expect_token(Token::LParen)?;
        let mut columns = vec![self.expect_word()?];
        while self.consume_token(&Token::Comma) {
            columns.push(self.expect_word()?);
        }
        self.expect_token(Token::RParen)?;
        Ok(Statement::CreateIndex {
            name,
            table,
            columns,
            unique,
        })
    }

    fn parse_data_type(&mut self) -> Result<DataType, PhobosError> {
        let word = self.expect_word()?;
        match word.to_ascii_uppercase().as_str() {
            "INT" | "INTEGER" | "BIGINT" => Ok(DataType::Int64),
            "BOOL" | "BOOLEAN" => Ok(DataType::Boolean),
            "FLOAT" | "DOUBLE" | "REAL" => Ok(DataType::Float64),
            "TEXT" | "VARCHAR" => Ok(DataType::Text),
            "BINARY" | "BLOB" => Ok(DataType::Binary),
            "DATE" => Ok(DataType::Date),
            "TIMESTAMP" => Ok(DataType::Timestamp),
            "DECIMAL" | "NUMERIC" => {
                self.expect_token(Token::LParen)?;
                let precision = self.expect_u8()?;
                self.expect_token(Token::Comma)?;
                let scale = self.expect_u8()?;
                self.expect_token(Token::RParen)?;
                if precision == 0 || precision > 38 || scale > precision {
                    return Err(
                        self.error("DECIMAL requires precision 1..=38 and scale <= precision")
                    );
                }
                Ok(DataType::Decimal { precision, scale })
            }
            _ => Err(self.error("unsupported data type")),
        }
    }

    fn parse_insert(&mut self) -> Result<Statement, PhobosError> {
        let table = self.expect_word()?;
        let columns = if self.consume_token(&Token::LParen) {
            let mut columns = vec![self.expect_word()?];
            while self.consume_token(&Token::Comma) {
                columns.push(self.expect_word()?);
            }
            self.expect_token(Token::RParen)?;
            Some(columns)
        } else {
            None
        };
        if self.consume_keyword("SELECT") {
            let query = self.nested(Self::parse_select)?;
            let statement = Statement::InsertSelect {
                table,
                columns,
                query: Box::new(query),
            };
            return self.parse_returning(statement);
        }
        self.expect_keyword("VALUES")?;
        let mut rows = Vec::new();
        loop {
            self.expect_token(Token::LParen)?;
            let mut values = Vec::new();
            loop {
                values.push(if self.consume_keyword("DEFAULT") {
                    Expr::Function {
                        name: "__phobos_default".into(),
                        args: Vec::new(),
                    }
                } else {
                    self.parse_expr()?
                });
                if self.consume_token(&Token::Comma) {
                    continue;
                }
                self.expect_token(Token::RParen)?;
                break;
            }
            rows.push(values);
            if !self.consume_token(&Token::Comma) {
                break;
            }
        }
        let inserted = match columns {
            Some(columns) => Statement::InsertColumns {
                table,
                columns,
                rows,
            },
            None => Statement::Insert { table, rows },
        };
        self.parse_returning(inserted)
    }
    fn parse_returning(&mut self, inserted: Statement) -> Result<Statement, PhobosError> {
        if self.consume_keyword("RETURNING") {
            let columns = if self.consume_token(&Token::Star) {
                SelectColumns::All
            } else {
                let mut names = vec![self.expect_word()?];
                while self.consume_token(&Token::Comma) {
                    names.push(self.expect_word()?);
                }
                SelectColumns::Named(names)
            };
            Ok(Statement::InsertReturning {
                statement: Box::new(inserted),
                columns,
            })
        } else {
            Ok(inserted)
        }
    }

    fn parse_select(&mut self) -> Result<Statement, PhobosError> {
        let mut query = self.parse_select_core()?;
        let mut union_depth = 0;
        while self.consume_keyword("UNION") {
            union_depth += 1;
            Self::check_depth(self.depth + union_depth)?;
            let (order, limit, offset) = take_query_tail(&mut query);
            if !order.is_empty() || limit.is_some() || offset.is_some() {
                return Err(self.error("ORDER/LIMIT/OFFSET must follow the final UNION operand"));
            }
            let all = self.consume_keyword("ALL");
            if !all {
                let _ = self.consume_keyword("DISTINCT");
            }
            self.expect_keyword("SELECT")?;
            let mut right = self.nested(Self::parse_select_core)?;
            let (order_by, limit, offset) = take_query_tail(&mut right);
            query = Statement::Union {
                left: Box::new(query),
                right: Box::new(right),
                all,
                order_by,
                limit,
                offset,
            };
        }
        Ok(query)
    }
    fn parse_select_core(&mut self) -> Result<Statement, PhobosError> {
        let distinct = self.consume_keyword("DISTINCT");
        let items = self.parse_select_items()?;
        let has_from = self.consume_keyword("FROM");
        if !has_from && items.iter().any(|i| matches!(i, SelectItem::All)) {
            return Err(self.error("SELECT * requires FROM"));
        }
        let (table, source, alias) = if !has_from {
            (String::new(), None, None)
        } else if self.consume_token(&Token::LParen) {
            let query = self.nested(Self::parse_statement)?;
            if !matches!(
                query,
                Statement::Select { .. } | Statement::RelationalSelect(_) | Statement::Union { .. }
            ) {
                return Err(self.error("derived input must be a SELECT"));
            }
            self.expect_token(Token::RParen)?;
            let alias = self
                .parse_table_alias()?
                .ok_or_else(|| self.error("derived input requires an alias"))?;
            (alias.clone(), Some(Box::new(query)), Some(alias))
        } else {
            let table = self.expect_word()?;
            if self.defining.iter().any(|n| n.eq_ignore_ascii_case(&table)) {
                return Err(self.error("recursive CTEs are not supported"));
            }
            let source = if let Some((_, query)) = self
                .ctes
                .iter()
                .rev()
                .find(|(n, _)| n.eq_ignore_ascii_case(&table))
            {
                self.expansion_bytes = self
                    .expansion_bytes
                    .saturating_add(format!("{query:?}").len());
                if self.expansion_bytes > 1024 * 1024 {
                    return Err(self.error("CTE expansion exceeds 1 MiB"));
                }
                Some(Box::new(query.clone()))
            } else {
                None
            };
            let alias = self.parse_table_alias()?;
            (table, source, alias)
        };

        let mut joins = Vec::new();
        loop {
            let kind = if self.consume_keyword("INNER") {
                self.expect_keyword("JOIN")?;
                Some(JoinKind::Inner)
            } else if self.consume_keyword("LEFT") {
                let _ = self.consume_keyword("OUTER");
                self.expect_keyword("JOIN")?;
                Some(JoinKind::Left)
            } else if self.consume_keyword("CROSS") {
                self.expect_keyword("JOIN")?;
                let table = self.expect_word()?;
                if self
                    .ctes
                    .iter()
                    .any(|(name, _)| name.eq_ignore_ascii_case(&table))
                {
                    return Err(self.error("CTEs in JOIN inputs are not yet supported"));
                }
                let alias = self.parse_table_alias()?;
                joins.push(JoinClause {
                    kind: JoinKind::Inner,
                    table,
                    alias,
                    left_column: String::new(),
                    right_column: String::new(),
                    predicate: Some(Expr::Literal(Value::Boolean(true))),
                });
                continue;
            } else if self.consume_keyword("JOIN") {
                Some(JoinKind::Inner)
            } else {
                None
            };
            let Some(kind) = kind else { break };
            joins.push(self.parse_join_clause(kind)?);
        }

        let filter = if self.consume_keyword("WHERE") {
            Some(self.parse_expr()?)
        } else {
            None
        };

        let mut group_by = Vec::new();
        if self.consume_keyword("GROUP") {
            self.expect_keyword("BY")?;
            group_by.push(self.expect_word()?);
            while self.consume_token(&Token::Comma) {
                group_by.push(self.expect_word()?);
            }
        }
        let having = if self.consume_keyword("HAVING") {
            Some(self.parse_expr()?)
        } else {
            None
        };

        let mut order_by = Vec::new();
        if self.consume_keyword("ORDER") {
            self.expect_keyword("BY")?;
            loop {
                let column = match self.tokens.get(self.cursor).cloned() {
                    Some(Token::Number(value)) if !value.contains('.') => {
                        self.cursor += 1;
                        value
                    }
                    _ => self.expect_word()?,
                };
                let ascending = if self.consume_keyword("DESC") {
                    false
                } else {
                    let _ = self.consume_keyword("ASC");
                    true
                };
                order_by.push(OrderBy { column, ascending });
                if !self.consume_token(&Token::Comma) {
                    break;
                }
            }
        }
        let limit = if self.consume_keyword("LIMIT") {
            Some(self.parse_expr()?)
        } else {
            None
        };
        let offset = if self.consume_keyword("OFFSET") {
            Some(self.parse_expr()?)
        } else {
            None
        };

        if source.is_some() && !joins.is_empty() {
            return Err(self.error(
                "joins over derived inputs are not yet supported; place the join inside the CTE",
            ));
        }
        let advanced = !has_from
            || source.is_some()
            || alias.is_some()
            || distinct
            || !joins.is_empty()
            || filter.as_ref().is_some_and(expr_contains_subquery)
            || limit.as_ref().is_some_and(expr_contains_subquery)
            || offset.as_ref().is_some_and(expr_contains_subquery)
            || !group_by.is_empty()
            || having.is_some()
            || items
                .iter()
                .any(|item| matches!(item, SelectItem::Aggregate { .. }))
            || items.iter().any(|item| match item {
                SelectItem::Column { name, alias } => alias.is_some() || name.contains('.'),
                SelectItem::Aggregate { alias, .. } => alias.is_some(),
                SelectItem::Expression { .. } => true,
                SelectItem::All => false,
            });

        if advanced {
            return Ok(Statement::RelationalSelect(RelationalSelect {
                source,
                table,
                alias,
                items,
                distinct,
                joins,
                filter,
                group_by,
                having,
                order_by,
                limit,
                offset,
            }));
        }

        let columns = if items.len() == 1 && matches!(items[0], SelectItem::All) {
            SelectColumns::All
        } else {
            let names = items
                .into_iter()
                .map(|item| match item {
                    SelectItem::Column { name, alias: None } => Ok(name),
                    _ => Err(self.error("unsupported simple SELECT item")),
                })
                .collect::<Result<Vec<_>, _>>()?;
            SelectColumns::Named(names)
        };
        Ok(Statement::Select {
            table,
            columns,
            filter,
            order_by,
            limit,
            offset,
        })
    }

    fn parse_select_items(&mut self) -> Result<Vec<SelectItem>, PhobosError> {
        if self.consume_token(&Token::Star) {
            return Ok(vec![SelectItem::All]);
        }
        let mut items = Vec::new();
        loop {
            let start = self.cursor;
            let maybe_word = self.peek_word().map(str::to_string);
            let upper = maybe_word.as_deref().unwrap_or("").to_ascii_uppercase();
            let item = if matches!(upper.as_str(), "COUNT" | "SUM" | "AVG" | "MIN" | "MAX")
                && self.tokens.get(self.cursor + 1) == Some(&Token::LParen)
            {
                let _word = self.expect_word()?;
                self.expect_token(Token::LParen)?;
                let function = match upper.as_str() {
                    "COUNT" => AggregateFunction::Count,
                    "SUM" => AggregateFunction::Sum,
                    "AVG" => AggregateFunction::Avg,
                    "MIN" => AggregateFunction::Min,
                    "MAX" => AggregateFunction::Max,
                    _ => unreachable!(),
                };
                let column = if self.consume_token(&Token::Star) {
                    None
                } else {
                    Some(self.expect_word()?)
                };
                self.expect_token(Token::RParen)?;
                let alias = if self.consume_keyword("AS") {
                    Some(self.expect_word()?)
                } else {
                    None
                };
                SelectItem::Aggregate {
                    function,
                    column,
                    alias,
                }
            } else {
                self.cursor = start;
                let expr = self.parse_expr()?;
                let alias = if self.consume_keyword("AS") {
                    Some(self.expect_word()?)
                } else {
                    None
                };
                match expr {
                    Expr::Column(name) => SelectItem::Column { name, alias },
                    expr => SelectItem::Expression { expr, alias },
                }
            };
            items.push(item);
            if !self.consume_token(&Token::Comma) {
                break;
            }
        }
        Ok(items)
    }

    fn parse_table_alias(&mut self) -> Result<Option<String>, PhobosError> {
        if self.consume_keyword("AS") {
            return self.expect_word().map(Some);
        }
        match self.tokens.get(self.cursor) {
            Some(Token::QuotedWord(_)) => self.expect_word().map(Some),
            Some(Token::Word(word))
                if ![
                    "INNER",
                    "LEFT",
                    "RIGHT",
                    "FULL",
                    "CROSS",
                    "NATURAL",
                    "JOIN",
                    "ON",
                    "USING",
                    "WHERE",
                    "GROUP",
                    "HAVING",
                    "ORDER",
                    "LIMIT",
                    "OFFSET",
                    "UNION",
                    "RETURNING",
                    "EXCEPT",
                    "INTERSECT",
                ]
                .iter()
                .any(|keyword| word.eq_ignore_ascii_case(keyword)) =>
            {
                self.expect_word().map(Some)
            }
            _ => Ok(None),
        }
    }

    fn parse_join_clause(&mut self, kind: JoinKind) -> Result<JoinClause, PhobosError> {
        let table = self.expect_word()?;
        if self
            .ctes
            .iter()
            .any(|(n, _)| n.eq_ignore_ascii_case(&table))
        {
            return Err(self.error("CTEs in JOIN inputs are not yet supported"));
        }
        let alias = self.parse_table_alias()?;
        self.expect_keyword("ON")?;
        let predicate = self.parse_expr()?;
        let (left_column, right_column, predicate) = match predicate {
            Expr::Binary {
                left,
                op: BinaryOp::Eq,
                right,
            } if matches!(left.as_ref(), Expr::Column(_))
                && matches!(right.as_ref(), Expr::Column(_)) =>
            {
                let Expr::Column(left) = *left else {
                    unreachable!()
                };
                let Expr::Column(right) = *right else {
                    unreachable!()
                };
                (left, right, None)
            }
            predicate => (String::new(), String::new(), Some(predicate)),
        };
        Ok(JoinClause {
            kind,
            table,
            alias,
            left_column,
            right_column,
            predicate,
        })
    }

    fn parse_update(&mut self) -> Result<Statement, PhobosError> {
        let table = self.expect_word()?;
        self.expect_keyword("SET")?;
        let mut assignments = Vec::new();
        loop {
            let column = self.expect_word()?;
            self.expect_token(Token::Eq)?;
            assignments.push((column, self.parse_expr()?));
            if !self.consume_token(&Token::Comma) {
                break;
            }
        }
        let filter = if self.consume_keyword("WHERE") {
            Some(self.parse_expr()?)
        } else {
            None
        };
        Ok(Statement::Update {
            table,
            assignments,
            filter,
        })
    }

    fn parse_delete(&mut self) -> Result<Statement, PhobosError> {
        let table = self.expect_word()?;
        let filter = if self.consume_keyword("WHERE") {
            Some(self.parse_expr()?)
        } else {
            None
        };
        Ok(Statement::Delete { table, filter })
    }

    fn parse_expr(&mut self) -> Result<Expr, PhobosError> {
        self.parse_or()
    }
    fn parse_or(&mut self) -> Result<Expr, PhobosError> {
        let mut expr = self.parse_and()?;
        while self.consume_keyword("OR") {
            expr = Self::bounded(Expr::Binary {
                left: Box::new(expr),
                op: BinaryOp::Or,
                right: Box::new(self.parse_and()?),
            })?;
        }
        Ok(expr)
    }
    fn parse_and(&mut self) -> Result<Expr, PhobosError> {
        let mut expr = self.parse_not()?;
        while self.consume_keyword("AND") {
            expr = Self::bounded(Expr::Binary {
                left: Box::new(expr),
                op: BinaryOp::And,
                right: Box::new(self.parse_not()?),
            })?;
        }
        Ok(expr)
    }
    fn parse_not(&mut self) -> Result<Expr, PhobosError> {
        if self.consume_keyword("NOT") {
            return Self::bounded(Expr::Unary {
                op: UnaryOp::Not,
                expr: Box::new(self.nested(Self::parse_not)?),
            });
        }
        self.parse_comparison()
    }
    fn parse_comparison(&mut self) -> Result<Expr, PhobosError> {
        let mut expr = self.parse_additive()?;
        if self.consume_keyword("IS") {
            let negated = self.consume_keyword("NOT");
            self.expect_keyword("NULL")?;
            return Self::bounded(Expr::IsNull {
                expr: Box::new(expr),
                negated,
            });
        }
        if self.consume_keyword("LIKE") {
            return Self::bounded(Expr::Like {
                expr: Box::new(expr),
                pattern: Box::new(self.parse_additive()?),
            });
        }
        if self.consume_keyword("IN") {
            self.expect_token(Token::LParen)?;
            if self.consume_keyword("SELECT") {
                let query = self.nested(Self::parse_select)?;
                self.expect_token(Token::RParen)?;
                return Self::bounded(Expr::InSubquery {
                    expr: Box::new(expr),
                    query: Box::new(query),
                });
            }
            let mut values = Vec::new();
            if !self.consume_token(&Token::RParen) {
                loop {
                    values.push(self.nested(Self::parse_expr)?);
                    if self.consume_token(&Token::Comma) {
                        continue;
                    }
                    self.expect_token(Token::RParen)?;
                    break;
                }
            }
            return Self::bounded(Expr::InList {
                expr: Box::new(expr),
                values,
            });
        }
        let op = if self.consume_token(&Token::Eq) {
            Some(BinaryOp::Eq)
        } else if self.consume_token(&Token::NotEq) {
            Some(BinaryOp::NotEq)
        } else if self.consume_token(&Token::LtEq) {
            Some(BinaryOp::LtEq)
        } else if self.consume_token(&Token::GtEq) {
            Some(BinaryOp::GtEq)
        } else if self.consume_token(&Token::Lt) {
            Some(BinaryOp::Lt)
        } else if self.consume_token(&Token::Gt) {
            Some(BinaryOp::Gt)
        } else {
            None
        };
        if let Some(op) = op {
            expr = Self::bounded(Expr::Binary {
                left: Box::new(expr),
                op,
                right: Box::new(self.parse_additive()?),
            })?;
        }
        Ok(expr)
    }
    fn parse_additive(&mut self) -> Result<Expr, PhobosError> {
        let mut expr = self.parse_multiplicative()?;
        loop {
            let op = if self.consume_token(&Token::Plus) {
                Some(BinaryOp::Add)
            } else if self.consume_token(&Token::Minus) {
                Some(BinaryOp::Subtract)
            } else {
                None
            };
            let Some(op) = op else {
                break;
            };
            expr = Self::bounded(Expr::Binary {
                left: Box::new(expr),
                op,
                right: Box::new(self.parse_multiplicative()?),
            })?;
        }
        Ok(expr)
    }
    fn parse_multiplicative(&mut self) -> Result<Expr, PhobosError> {
        let mut expr = self.parse_unary()?;
        loop {
            let op = if self.consume_token(&Token::Star) {
                Some(BinaryOp::Multiply)
            } else if self.consume_token(&Token::Slash) {
                Some(BinaryOp::Divide)
            } else {
                None
            };
            let Some(op) = op else {
                break;
            };
            expr = Self::bounded(Expr::Binary {
                left: Box::new(expr),
                op,
                right: Box::new(self.parse_unary()?),
            })?;
        }
        Ok(expr)
    }
    fn parse_unary(&mut self) -> Result<Expr, PhobosError> {
        if self.consume_token(&Token::Minus) {
            return Self::bounded(Expr::Unary {
                op: UnaryOp::Negate,
                expr: Box::new(self.nested(Self::parse_unary)?),
            });
        }
        self.parse_primary()
    }
    fn parse_primary(&mut self) -> Result<Expr, PhobosError> {
        if self.consume_keyword("EXISTS") {
            self.expect_token(Token::LParen)?;
            self.expect_keyword("SELECT")?;
            let query = self.nested(Self::parse_select)?;
            self.expect_token(Token::RParen)?;
            return Ok(Expr::Exists(Box::new(query)));
        }
        if self.consume_token(&Token::LParen) {
            if self.consume_keyword("SELECT") {
                let query = self.nested(Self::parse_select)?;
                self.expect_token(Token::RParen)?;
                return Ok(Expr::ScalarSubquery(Box::new(query)));
            }
            let expr = self.nested(Self::parse_expr)?;
            self.expect_token(Token::RParen)?;
            return Ok(expr);
        }
        if self.consume_keyword("CASE") {
            let mut branches = Vec::new();
            while self.consume_keyword("WHEN") {
                let when = self.nested(Self::parse_expr)?;
                self.expect_keyword("THEN")?;
                let then = self.nested(Self::parse_expr)?;
                branches.push((when, then));
            }
            if branches.is_empty() {
                return Err(self.error("CASE requires WHEN"));
            }
            let else_expr = if self.consume_keyword("ELSE") {
                Some(Box::new(self.nested(Self::parse_expr)?))
            } else {
                None
            };
            self.expect_keyword("END")?;
            return Self::bounded(Expr::Case {
                branches,
                else_expr,
            });
        }
        let token = self
            .tokens
            .get(self.cursor)
            .cloned()
            .ok_or_else(|| self.error("expected expression"))?;
        self.cursor += 1;
        match token {
            Token::String(v) => Ok(Expr::Literal(Value::Text(v))),
            Token::Number(v) => {
                if v.contains('.') {
                    v.parse::<f64>()
                        .map(Value::Float64)
                        .map(Expr::Literal)
                        .map_err(|_| self.error("invalid floating-point literal"))
                } else {
                    v.parse::<i64>()
                        .map(Value::Int64)
                        .map(Expr::Literal)
                        .map_err(|_| self.error("integer literal is out of range"))
                }
            }
            Token::Parameter(n) => Ok(Expr::Parameter(n)),
            Token::Word(v) if v.eq_ignore_ascii_case("NULL") => Ok(Expr::Literal(Value::Null)),
            Token::Word(v) if v.eq_ignore_ascii_case("TRUE") => {
                Ok(Expr::Literal(Value::Boolean(true)))
            }
            Token::Word(v) if v.eq_ignore_ascii_case("FALSE") => {
                Ok(Expr::Literal(Value::Boolean(false)))
            }
            Token::Word(v) if v.eq_ignore_ascii_case("CURRENT_TIMESTAMP") => {
                if self.consume_token(&Token::LParen) {
                    self.expect_token(Token::RParen)?;
                }
                Ok(Expr::Function {
                    name: v,
                    args: Vec::new(),
                })
            }
            Token::Word(v) => {
                if self.consume_token(&Token::LParen) {
                    let mut args = Vec::new();
                    if !self.consume_token(&Token::RParen) {
                        loop {
                            args.push(self.nested(Self::parse_expr)?);
                            if self.consume_token(&Token::Comma) {
                                continue;
                            }
                            self.expect_token(Token::RParen)?;
                            break;
                        }
                    }
                    Self::bounded(Expr::Function { name: v, args })
                } else {
                    Ok(Expr::Column(v))
                }
            }
            Token::QuotedWord(v) => Ok(Expr::QuotedColumn(v)),
            _ => Err(self.error("expected expression")),
        }
    }

    fn expect_u8(&mut self) -> Result<u8, PhobosError> {
        let token = self
            .tokens
            .get(self.cursor)
            .cloned()
            .ok_or_else(|| self.error("expected unsigned integer"))?;
        self.cursor += 1;
        match token {
            Token::Number(v) if !v.contains('.') => v
                .parse::<u8>()
                .map_err(|_| self.error("integer is out of range")),
            _ => Err(self.error("expected unsigned integer")),
        }
    }
    fn expect_word(&mut self) -> Result<String, PhobosError> {
        let token = self
            .tokens
            .get(self.cursor)
            .cloned()
            .ok_or_else(|| self.error("expected identifier"))?;
        self.cursor += 1;
        match token {
            Token::Word(v) | Token::QuotedWord(v)
                if !v.to_ascii_lowercase().starts_with("__phobos_") =>
            {
                Ok(v)
            }
            _ => Err(self.error("expected identifier")),
        }
    }
    fn expect_keyword(&mut self, keyword: &str) -> Result<(), PhobosError> {
        if self.consume_keyword(keyword) {
            Ok(())
        } else {
            Err(self.error(&format!("expected {keyword}")))
        }
    }
    fn consume_keyword(&mut self, keyword: &str) -> bool {
        match self.tokens.get(self.cursor) {
            Some(Token::Word(v)) if v.eq_ignore_ascii_case(keyword) => {
                self.cursor += 1;
                true
            }
            _ => false,
        }
    }
    fn peek_word(&self) -> Option<&str> {
        match self.tokens.get(self.cursor) {
            Some(Token::Word(value)) | Some(Token::QuotedWord(value)) => Some(value),
            _ => None,
        }
    }
    fn expect_token(&mut self, token: Token) -> Result<(), PhobosError> {
        if self.consume_token(&token) {
            Ok(())
        } else {
            Err(self.error("unexpected token"))
        }
    }
    fn consume_token(&mut self, token: &Token) -> bool {
        if self.tokens.get(self.cursor) == Some(token) {
            self.cursor += 1;
            true
        } else {
            false
        }
    }
    fn error(&self, message: &str) -> PhobosError {
        PhobosError::new(ErrorCode::SqlSyntax, message).with_position(self.cursor as u32)
    }
}

// CTE substitution can deepen an AST without nesting its source SQL. Traverse
// iteratively before retaining/cloning a definition so the parser budget still
// bounds the evaluator and destructor stack, not just parentheses in the text.
fn check_expanded_query_depth(statement: &Statement) -> Result<(), PhobosError> {
    enum Node<'a> {
        Statement(&'a Statement),
        Expr(&'a Expr),
    }
    let mut pending = vec![(Node::Statement(statement), 0usize)];
    while let Some((node, depth)) = pending.pop() {
        Parser::check_depth(depth)?;
        match node {
            Node::Statement(Statement::Union {
                left,
                right,
                limit,
                offset,
                ..
            }) => {
                pending.push((Node::Statement(left), depth + 1));
                pending.push((Node::Statement(right), depth + 1));
                for expr in [limit.as_ref(), offset.as_ref()].into_iter().flatten() {
                    pending.push((Node::Expr(expr), depth));
                }
            }
            Node::Statement(Statement::InsertReturning { statement, .. }) => {
                pending.push((Node::Statement(statement), depth + 1))
            }
            Node::Statement(Statement::CreateView { query, .. }) => {
                pending.push((Node::Statement(query), depth + 1))
            }
            Node::Statement(Statement::InsertSelect { query, .. }) => {
                pending.push((Node::Statement(query), depth + 1))
            }
            Node::Statement(Statement::Select {
                filter,
                limit,
                offset,
                ..
            }) => {
                pending.extend(
                    [filter.as_ref(), limit.as_ref(), offset.as_ref()]
                        .into_iter()
                        .flatten()
                        .map(|e| (Node::Expr(e), depth)),
                );
            }
            Node::Statement(Statement::RelationalSelect(q)) => {
                if let Some(source) = &q.source {
                    pending.push((Node::Statement(source), depth + 1));
                }
                for item in &q.items {
                    if let SelectItem::Expression { expr, .. } = item {
                        pending.push((Node::Expr(expr), depth));
                    }
                }
                for join in &q.joins {
                    if let Some(expr) = &join.predicate {
                        pending.push((Node::Expr(expr), depth));
                    }
                }
                pending.extend(
                    [
                        q.filter.as_ref(),
                        q.having.as_ref(),
                        q.limit.as_ref(),
                        q.offset.as_ref(),
                    ]
                    .into_iter()
                    .flatten()
                    .map(|e| (Node::Expr(e), depth)),
                );
            }
            Node::Statement(Statement::Explain { statement, .. }) => {
                pending.push((Node::Statement(statement), depth + 1))
            }
            Node::Statement(_) => (),
            Node::Expr(expr) => match expr {
                Expr::ScalarSubquery(q) | Expr::Exists(q) => {
                    pending.push((Node::Statement(q), depth + 1))
                }
                Expr::InSubquery { expr, query } => {
                    pending.push((Node::Expr(expr), depth + 1));
                    pending.push((Node::Statement(query), depth + 1));
                }
                Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => {
                    pending.push((Node::Expr(expr), depth + 1))
                }
                Expr::Binary { left, right, .. }
                | Expr::Like {
                    expr: left,
                    pattern: right,
                } => {
                    pending.push((Node::Expr(left), depth + 1));
                    pending.push((Node::Expr(right), depth + 1));
                }
                Expr::Function { args, .. } => {
                    pending.extend(args.iter().map(|e| (Node::Expr(e), depth + 1)))
                }
                Expr::InList { expr, values } => {
                    pending.push((Node::Expr(expr), depth + 1));
                    pending.extend(values.iter().map(|e| (Node::Expr(e), depth + 1)));
                }
                Expr::Case {
                    branches,
                    else_expr,
                } => {
                    for (a, b) in branches {
                        pending.push((Node::Expr(a), depth + 1));
                        pending.push((Node::Expr(b), depth + 1));
                    }
                    if let Some(e) = else_expr {
                        pending.push((Node::Expr(e), depth + 1));
                    }
                }
                _ => (),
            },
        }
    }
    Ok(())
}

fn expr_contains_subquery(expr: &Expr) -> bool {
    match expr {
        Expr::InSubquery { .. } | Expr::ScalarSubquery(_) | Expr::Exists(_) => true,
        Expr::Unary { expr, .. } | Expr::IsNull { expr, .. } => expr_contains_subquery(expr),
        Expr::Binary { left, right, .. }
        | Expr::Like {
            expr: left,
            pattern: right,
        } => expr_contains_subquery(left) || expr_contains_subquery(right),
        Expr::Function { args, .. } => args.iter().any(expr_contains_subquery),
        Expr::InList { expr, values } => {
            expr_contains_subquery(expr) || values.iter().any(expr_contains_subquery)
        }
        Expr::Case {
            branches,
            else_expr,
        } => {
            branches
                .iter()
                .any(|(a, b)| expr_contains_subquery(a) || expr_contains_subquery(b))
                || else_expr.as_deref().is_some_and(expr_contains_subquery)
        }
        Expr::Literal(_) | Expr::Column(_) | Expr::QuotedColumn(_) | Expr::Parameter(_) => false,
    }
}

fn take_query_tail(query: &mut Statement) -> (Vec<OrderBy>, Option<Expr>, Option<Expr>) {
    match query {
        Statement::Select {
            order_by,
            limit,
            offset,
            ..
        }
        | Statement::Union {
            order_by,
            limit,
            offset,
            ..
        } => (std::mem::take(order_by), limit.take(), offset.take()),
        Statement::RelationalSelect(q) => (
            std::mem::take(&mut q.order_by),
            q.limit.take(),
            q.offset.take(),
        ),
        _ => unreachable!("query"),
    }
}

fn token_sql(token: &Token) -> String {
    match token {
        Token::Word(s) | Token::Number(s) => s.clone(),
        Token::QuotedWord(s) => format!("\"{}\"", s.replace('"', "\"\"")),
        Token::String(s) => format!("'{}'", s.replace('\'', "''")),
        Token::Parameter(n) => format!("${}", n + 1),
        Token::LParen => "(".into(),
        Token::RParen => ")".into(),
        Token::Comma => ",".into(),
        Token::Star => "*".into(),
        Token::Semicolon => ";".into(),
        Token::Eq => "=".into(),
        Token::NotEq => "<>".into(),
        Token::Lt => "<".into(),
        Token::LtEq => "<=".into(),
        Token::Gt => ">".into(),
        Token::GtEq => ">=".into(),
        Token::Plus => "+".into(),
        Token::Minus => "-".into(),
        Token::Slash => "/".into(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parses_phase2_select() {
        let stmt = parse("SELECT id,name FROM people WHERE id >= $1 AND name IS NOT NULL ORDER BY name DESC LIMIT 10 OFFSET 2").unwrap();
        let Statement::Select {
            order_by,
            limit,
            offset,
            ..
        } = stmt
        else {
            panic!("select")
        };
        assert_eq!(order_by.len(), 1);
        assert!(limit.is_some());
        assert!(offset.is_some());
    }
    #[test]
    fn parses_update_and_delete() {
        assert!(matches!(
            parse("UPDATE t SET n=n+1 WHERE id=$1").unwrap(),
            Statement::Update { .. }
        ));
        assert!(matches!(
            parse("DELETE FROM t WHERE id<>4").unwrap(),
            Statement::Delete { .. }
        ));
    }
    #[test]
    fn parses_multi_row_insert_and_escaped_string() {
        let stmt = parse("INSERT INTO t VALUES (1,'it''s'),($1,NULL)").unwrap();
        let Statement::Insert { rows, .. } = stmt else {
            panic!("insert")
        };
        assert_eq!(rows.len(), 2);
    }

    #[test]
    fn parses_transaction_control() {
        assert_eq!(parse("BEGIN").unwrap(), Statement::Begin);
        assert_eq!(parse("BEGIN TRANSACTION").unwrap(), Statement::Begin);
        assert_eq!(parse("COMMIT").unwrap(), Statement::Commit);
        assert_eq!(parse("ROLLBACK").unwrap(), Statement::Rollback);
        assert_eq!(
            parse("BEGIN ISOLATION LEVEL SNAPSHOT").unwrap(),
            Statement::BeginSnapshot
        );
        assert_eq!(
            parse("BEGIN TRANSACTION ISOLATION LEVEL SNAPSHOT").unwrap(),
            Statement::BeginSnapshot
        );
        assert_eq!(
            parse("SAVEPOINT one").unwrap(),
            Statement::Savepoint { name: "one".into() }
        );
        assert_eq!(
            parse("ROLLBACK TO SAVEPOINT one").unwrap(),
            Statement::RollbackTo { name: "one".into() }
        );
        assert_eq!(
            parse("RELEASE SAVEPOINT one").unwrap(),
            Statement::ReleaseSavepoint { name: "one".into() }
        );
        assert_eq!(parse("CHECKPOINT").unwrap(), Statement::Checkpoint);
    }

    #[test]
    fn parses_create_and_drop_index() {
        assert_eq!(
            parse("CREATE UNIQUE INDEX ix_people_name_id ON people (name, id)").unwrap(),
            Statement::CreateIndex {
                name: "ix_people_name_id".into(),
                table: "people".into(),
                columns: vec!["name".into(), "id".into()],
                unique: true,
            }
        );
        assert_eq!(
            parse("DROP INDEX ix_people_name_id").unwrap(),
            Statement::DropIndex {
                name: "ix_people_name_id".into(),
            }
        );
    }
    #[test]
    fn parses_phase6_join_group_and_explain() {
        assert!(matches!(
            parse("SELECT a.id, COUNT(*) AS n FROM a LEFT JOIN b ON a.id=b.a_id GROUP BY a.id HAVING n > 0 ORDER BY a.id").unwrap(),
            Statement::RelationalSelect(_)
        ));
        assert!(matches!(
            parse("EXPLAIN ANALYZE SELECT COUNT(*) AS n FROM a").unwrap(),
            Statement::Explain { analyze: true, .. }
        ));
        assert_eq!(
            parse("ANALYZE people").unwrap(),
            Statement::Analyze {
                table: "people".into()
            }
        );
    }
}

#[cfg(test)]
mod enterprise_parser_tests {
    use super::*;
    #[test]
    fn enterprise_ast_and_negative_syntax() {
        let Statement::RelationalSelect(query) =
            parse("SELECT a.id FROM orders AS a LEFT OUTER JOIN orders b ON a.id=b.id AND b.id>0")
                .unwrap()
        else {
            panic!()
        };
        assert_eq!(query.table, "orders");
        assert_eq!(query.alias.as_deref(), Some("a"));
        assert!(query.joins[0].predicate.is_some());
        assert!(matches!(
            parse("INSERT INTO t (b,a) VALUES (1,2)").unwrap(),
            Statement::InsertColumns { .. }
        ));
        assert!(matches!(
            parse("ALTER TABLE t RENAME COLUMN a TO b").unwrap(),
            Statement::RenameTable {
                column: Some(_),
                ..
            }
        ));
        for sql in [
            "SHOW CATALOG unknown",
            "SHOW CATALOG CAPABILITIES FROM t",
            "SELECT * FROM t CROSS JOIN",
            "WITH RECURSIVE x AS (SELECT * FROM t) SELECT * FROM x",
            "WITH x AS (SELECT * FROM t) DELETE FROM t",
            "ALTER TABLE t DROP COLUMN a",
            "INSERT INTO t () VALUES (1)",
        ] {
            assert!(parse(sql).is_err(), "{sql}");
        }
    }
    #[test]
    fn enterprise_nested_queries_keep_depth_limit() {
        let mut sql = "SELECT id FROM t".to_owned();
        for _ in 0..MAX_PARSE_DEPTH + 2 {
            sql = format!("SELECT id FROM ({sql}) q");
        }
        assert_eq!(parse(&sql).unwrap_err().code, ErrorCode::ParserDepth);
        let mut definitions = vec!["c0 AS (SELECT id FROM t)".to_owned()];
        for n in 1..64 {
            definitions.push(format!(
                "c{n} AS (SELECT id FROM (SELECT id FROM c{}) q)",
                n - 1
            ));
        }
        let expanded = format!("WITH {} SELECT id FROM c63", definitions.join(","));
        assert_eq!(parse(&expanded).unwrap_err().code, ErrorCode::ParserDepth);
        let mut mixed = vec!["c0 AS (SELECT id FROM t)".to_owned()];
        for n in 1..10 {
            let mut expression = format!("(SELECT id FROM c{})", n - 1);
            for _ in 0..10 {
                expression = format!("COALESCE({expression},0)");
            }
            mixed.push(format!("c{n} AS (SELECT {expression} AS id FROM t)"));
        }
        assert_eq!(
            parse(&format!("WITH {} SELECT id FROM c9", mixed.join(",")))
                .unwrap_err()
                .code,
            ErrorCode::ParserDepth
        );

        assert!(
            parse("WITH a AS (SELECT id FROM t), b AS (SELECT id FROM a) SELECT id FROM b").is_ok()
        );
    }
}

#[cfg(test)]
mod schema_v2_parser_tests {
    use super::*;
    #[test]
    fn schema_v2_ast_and_rejected_grammar() {
        assert!(matches!(
            parse("CREATE TABLE t (id BIGINT PRIMARY KEY, n BIGINT DEFAULT -2 CHECK(n>=0))")
                .unwrap(),
            Statement::CreateDefinedTable { .. }
        ));
        assert!(matches!(
            parse("ALTER TABLE t ALTER COLUMN n SET DEFAULT 7").unwrap(),
            Statement::AlterDefault { value: Some(_), .. }
        ));
        assert!(matches!(
            parse("ALTER TABLE t ALTER COLUMN n DROP DEFAULT").unwrap(),
            Statement::AlterDefault { value: None, .. }
        ));
        for sql in [
            "CREATE TABLE t (a BIGINT PRIMARY KEY, b BIGINT PRIMARY KEY)",
            "CREATE TABLE t (a BIGINT DEFAULT 1 DEFAULT 2)",
            "CREATE TABLE t (a BIGINT NULL NOT NULL)",
            "CREATE TABLE t (a BIGINT, PRIMARY KEY())",
            "CREATE TABLE t (a BIGINT, CHECK())",
            "CREATE TABLE t (a BIGINT GENERATED SOMETIMES AS IDENTITY)",
            "ALTER TABLE t ALTER COLUMN n TYPE TEXT",
        ] {
            assert!(parse(sql).is_err(), "{sql}");
        }
    }
}

#[cfg(test)]
mod community_parser_tests {
    use super::*;
    #[test]
    fn community_ast_and_negative_cases() {
        assert!(matches!(parse("CREATE TABLE x (id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, p BIGINT, FOREIGN KEY(p) REFERENCES parent(id) ON DELETE RESTRICT)").unwrap(),Statement::CreateDefinedTable{identity:Some(_),..}));
        assert!(matches!(
            parse("INSERT INTO x(p) SELECT 1 UNION ALL SELECT 2 RETURNING id").unwrap(),
            Statement::InsertReturning { .. }
        ));
        assert!(matches!(
            parse("CREATE VIEW v AS SELECT CURRENT_TIMESTAMP AS now").unwrap(),
            Statement::CreateView { .. }
        ));
        assert!(matches!(
            parse("ALTER TABLE t ADD COLUMN n BIGINT DEFAULT 3 NOT NULL").unwrap(),
            Statement::AddColumn { .. }
        ));
        for sql in [
            "SELECT *",
            "SELECT 1 UNION SELECT",
            "CREATE VIEW v AS DELETE FROM x",
            "CREATE TABLE x (p BIGINT, FOREIGN KEY(p) REFERENCES y(id) ON DELETE CASCADE)",
        ] {
            assert!(parse(sql).is_err(), "{sql}");
        }
    }
    #[test]
    fn long_union_fails_boundedly() {
        let sql = std::iter::repeat_n("SELECT 1", 10000)
            .collect::<Vec<_>>()
            .join(" UNION ALL ");
        assert_eq!(parse(&sql).unwrap_err().code, ErrorCode::ParserDepth);
    }
}
