//! Physical page checksum selector at header byte 7, independent of tuple/LSN versions.
//! Zero is the original FNV-1a format; one is CRC32C. Readers reject unknown schemes.
use phobos_error::{ErrorCode, PhobosError};

pub const CRC32C: u8 = 1;

pub fn validate_scheme(bytes: &[u8]) -> Result<(), PhobosError> {
    if matches!(bytes.get(7).copied(), Some(0 | CRC32C)) {
        Ok(())
    } else {
        Err(PhobosError::new(
            ErrorCode::InvalidPage,
            "unsupported page checksum scheme",
        ))
    }
}

/// Compute the selected checksum with the four-byte checksum field treated as zero.
pub fn checksum(bytes: &[u8], offset: usize) -> u32 {
    phobos_observability::event("page.checksums", 1);
    if bytes[7] == CRC32C {
        let crc = crc32c::crc32c(&bytes[..offset]);
        let crc = crc32c::crc32c_append(crc, &[0; 4]);
        crc32c::crc32c_append(crc, &bytes[offset + 4..])
    } else {
        bytes
            .iter()
            .enumerate()
            .fold(0x811c_9dc5u32, |hash, (i, byte)| {
                let value = if (offset..offset + 4).contains(&i) {
                    0
                } else {
                    *byte
                };
                (hash ^ u32::from(value)).wrapping_mul(0x0100_0193)
            })
    }
}

/// Ephemeral private-overlay records have no durable compatibility contract.
pub fn scratch_checksum(bytes: &[u8]) -> u32 {
    crc32c::crc32c(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn crc32c_known_vector_and_legacy_page_compatibility() {
        assert_eq!(scratch_checksum(b"123456789"), 0xe306_9283);
        let mut page = [0; 8192];
        let old = checksum(&page, 32);
        page[32..36].copy_from_slice(&old.to_le_bytes());
        assert_eq!(checksum(&page, 32), old);
        page[7] = CRC32C;
        let new = checksum(&page, 32);
        assert_ne!(old, new);
        page[4096] ^= 1;
        assert_ne!(checksum(&page, 32), new);
        page[7] = 2;
        assert!(validate_scheme(&page).is_err());
    }
}
