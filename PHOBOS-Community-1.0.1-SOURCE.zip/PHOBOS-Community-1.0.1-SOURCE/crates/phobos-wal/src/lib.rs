#![forbid(unsafe_code)]
//! Phase 3 write-ahead log with framed, checksummed records and redo recovery.
//! The current alpha recovery strategy logs durable file-image chunks before installing them.

use phobos_error::{ErrorCode, PhobosError};
use std::{
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
};

pub mod page_checksum;
pub mod v2;

const MAGIC: [u8; 4] = *b"PHWL";
const VERSION: u16 = 1;
const HEADER_LEN: usize = 44;
const CHECKSUM_OFFSET: usize = 40;
const CHUNK_SIZE: usize = 1024 * 1024;
const WAL_FILE: &str = "phobos.wal";
const GENERATION_FILE: &str = "phobos.wal.gen";
static WRITTEN_BYTES: AtomicU64 = AtomicU64::new(0);

/// Successfully written framed WAL bytes in this process, including setup transactions.
/// This is emitted volume, not current file size; subprocesses have independent counters.
pub fn total_written_bytes() -> u64 {
    WRITTEN_BYTES.load(Ordering::Relaxed)
}

/// Read-only legacy framing/version preflight for offline administration.
pub fn inspect_legacy(data_dir: &Path) -> Result<(), PhobosError> {
    scan_records(&data_dir.join(WAL_FILE), true)?;
    Ok(())
}

pub type TxnId = u64;
pub type Lsn = u64;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum RecordType {
    Begin = 1,
    FileChunk = 2,
    Commit = 3,
    Abort = 4,
    Checkpoint = 5,
}

impl TryFrom<u8> for RecordType {
    type Error = PhobosError;

    fn try_from(value: u8) -> Result<Self, PhobosError> {
        match value {
            1 => Ok(Self::Begin),
            2 => Ok(Self::FileChunk),
            3 => Ok(Self::Commit),
            4 => Ok(Self::Abort),
            5 => Ok(Self::Checkpoint),
            _ => Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "unknown WAL record type",
            )),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WalRecord {
    pub record_type: RecordType,
    pub txn_id: TxnId,
    pub lsn: Lsn,
    pub prev_lsn: Lsn,
    pub payload: Vec<u8>,
}

#[derive(Debug, Clone)]
struct FileChunk {
    path: String,
    offset: u64,
    total_len: u64,
    bytes: Vec<u8>,
}

#[derive(Debug, Default)]
struct RecoveryTxn {
    chunks: Vec<FileChunk>,
    committed: bool,
    commit_lsn: Lsn,
}

pub struct Wal {
    path: PathBuf,
    generation_path: PathBuf,
    file: File,
    generation: u32,
    next_sequence: u32,
}

impl Wal {
    pub fn open(data_dir: impl AsRef<Path>) -> Result<Self, PhobosError> {
        phobos_observability::measure("fs.create_dir_all", || {
            fs::create_dir_all(data_dir.as_ref())
        })?;
        let path = data_dir.as_ref().join(WAL_FILE);
        let generation_path = data_dir.as_ref().join(GENERATION_FILE);
        let generation = read_generation(&generation_path)?;
        let file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .truncate(false)
            .open(&path)?;
        let records = scan_records(&path, false)?.0;
        let next_sequence = records
            .iter()
            .map(|record| (record.lsn & 0xffff_ffff) as u32)
            .max()
            .unwrap_or(0)
            .saturating_add(1)
            .max(1);
        Ok(Self {
            path,
            generation_path,
            file,
            generation,
            next_sequence,
        })
    }

    pub fn append(
        &mut self,
        record_type: RecordType,
        txn_id: TxnId,
        prev_lsn: Lsn,
        payload: &[u8],
    ) -> Result<Lsn, PhobosError> {
        self.file.seek(SeekFrom::End(0))?;

        let lsn = self.allocate_lsn()?;
        let record = WalRecord {
            record_type,
            txn_id,
            lsn,
            prev_lsn,
            payload: payload.to_vec(),
        };

        write_record(&mut self.file, &record)?;
        Ok(lsn)
    }

    pub fn sync(&mut self) -> Result<(), PhobosError> {
        {
            let _sync = phobos_observability::span("wal.fsync");
            phobos_observability::measure("fs.sync_data", || self.file.sync_data())?;
        }
        Ok(())
    }

    pub fn write_transaction_snapshot(
        &mut self,
        txn_id: TxnId,
        snapshot_dir: &Path,
    ) -> Result<Lsn, PhobosError> {
        let _profile = phobos_observability::span("wal.write_transaction_snapshot");
        let mut prev_lsn = self.append(RecordType::Begin, txn_id, 0, &[])?;
        for path in snapshot_files(snapshot_dir)? {
            let relative = path.strip_prefix(snapshot_dir).map_err(|_| {
                PhobosError::new(
                    ErrorCode::InvalidWal,
                    "snapshot path escaped transaction directory",
                )
            })?;
            let relative = relative.to_str().ok_or_else(|| {
                PhobosError::new(ErrorCode::InvalidWal, "snapshot file name is not UTF-8")
            })?;
            let bytes = phobos_observability::measure("wal.snapshot_read", || {
                phobos_observability::measure("fs.read", || fs::read(&path))
            })?;
            let total_len = bytes.len() as u64;
            if bytes.is_empty() {
                let payload = encode_chunk(relative, 0, 0, &[])?;
                prev_lsn = self.append(RecordType::FileChunk, txn_id, prev_lsn, &payload)?;
                continue;
            }
            for (index, chunk) in bytes.chunks(CHUNK_SIZE).enumerate() {
                let offset = (index * CHUNK_SIZE) as u64;
                let payload = encode_chunk(relative, offset, total_len, chunk)?;
                prev_lsn = self.append(RecordType::FileChunk, txn_id, prev_lsn, &payload)?;
            }
        }
        phobos_observability::certification_crash("before_commit_record");
        let commit_lsn = self.append(RecordType::Commit, txn_id, prev_lsn, &[])?;
        phobos_observability::certification_crash("after_commit_record");
        phobos_observability::certification_crash("before_wal_sync");
        self.sync()?;
        phobos_observability::certification_crash("after_wal_sync");
        Ok(commit_lsn)
    }

    pub fn checkpoint(&mut self, durable_lsn: Lsn) -> Result<Lsn, PhobosError> {
        let checkpoint_lsn =
            self.append(RecordType::Checkpoint, 0, 0, &durable_lsn.to_le_bytes())?;
        phobos_observability::certification_crash("during_checkpoint");
        self.sync()?;
        Ok(checkpoint_lsn)
    }

    pub fn rotate_after_checkpoint(&mut self) -> Result<(), PhobosError> {
        {
            let _sync = phobos_observability::span("wal.fsync");
            phobos_observability::measure("fs.sync_data", || self.file.sync_data())?;
        }
        self.generation = self
            .generation
            .checked_add(1)
            .ok_or_else(|| PhobosError::new(ErrorCode::InvalidWal, "WAL generation exhausted"))?;
        write_generation(&self.generation_path, self.generation)?;
        self.file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .truncate(true)
            .open(&self.path)?;
        {
            let _sync = phobos_observability::span("wal.fsync");
            phobos_observability::measure("fs.sync_data", || self.file.sync_data())?;
        }
        self.next_sequence = 1;
        Ok(())
    }

    fn allocate_lsn(&mut self) -> Result<Lsn, PhobosError> {
        if self.next_sequence == u32::MAX {
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "WAL sequence exhausted for current generation",
            ));
        }
        let sequence = self.next_sequence;
        self.next_sequence += 1;
        Ok((u64::from(self.generation) << 32) | u64::from(sequence))
    }
}

pub fn recover(data_dir: impl AsRef<Path>) -> Result<RecoveryReport, PhobosError> {
    phobos_observability::measure("fs.create_dir_all", || {
        fs::create_dir_all(data_dir.as_ref())
    })?;
    let wal_path = data_dir.as_ref().join(WAL_FILE);
    if !wal_path.exists() {
        return Ok(RecoveryReport::default());
    }
    let (records, valid_len) = scan_records(&wal_path, true)?;
    let physical_len =
        phobos_observability::measure("fs.metadata", || fs::metadata(&wal_path))?.len();
    if valid_len < physical_len {
        let file = OpenOptions::new().write(true).open(&wal_path)?;
        file.set_len(valid_len)?;
        phobos_observability::measure("fs.sync_data", || file.sync_data())?;
    }

    let mut checkpoint_lsn = 0;
    let mut txns: BTreeMap<TxnId, RecoveryTxn> = BTreeMap::new();
    for record in records {
        match record.record_type {
            RecordType::Begin => {
                txns.entry(record.txn_id).or_default();
            }
            RecordType::FileChunk => {
                txns.entry(record.txn_id)
                    .or_default()
                    .chunks
                    .push(decode_chunk(&record.payload)?);
            }
            RecordType::Commit => {
                let txn = txns.entry(record.txn_id).or_default();
                txn.committed = true;
                txn.commit_lsn = record.lsn;
            }
            RecordType::Abort => {
                txns.remove(&record.txn_id);
            }
            RecordType::Checkpoint => {
                if record.payload.len() == 8 {
                    checkpoint_lsn =
                        u64::from_le_bytes(record.payload[..8].try_into().expect("checkpoint lsn"));
                }
            }
        }
    }

    let mut redone = 0usize;
    let mut ignored_incomplete = 0usize;
    for txn in txns.values() {
        if txn.committed && txn.commit_lsn > checkpoint_lsn {
            install_chunks(data_dir.as_ref(), &txn.chunks)?;
            redone += 1;
        } else if !txn.committed {
            ignored_incomplete += 1;
        }
    }
    Ok(RecoveryReport {
        redone_transactions: redone,
        ignored_incomplete_transactions: ignored_incomplete,
        truncated_tail: valid_len < physical_len,
    })
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct RecoveryReport {
    pub redone_transactions: usize,
    pub ignored_incomplete_transactions: usize,
    pub truncated_tail: bool,
}

pub fn install_snapshot(snapshot_dir: &Path, data_dir: &Path) -> Result<(), PhobosError> {
    let _measurement = phobos_observability::span("wal.install_snapshot");
    let mut chunks = Vec::new();
    for path in snapshot_files(snapshot_dir)? {
        let relative = path.strip_prefix(snapshot_dir).map_err(|_| {
            PhobosError::new(
                ErrorCode::Recovery,
                "snapshot path escaped transaction directory",
            )
        })?;
        let relative = relative.to_str().ok_or_else(|| {
            PhobosError::new(ErrorCode::Recovery, "snapshot file name is not UTF-8")
        })?;
        let bytes = phobos_observability::measure("wal.snapshot_read", || {
            phobos_observability::measure("fs.read", || fs::read(&path))
        })?;
        chunks.push(FileChunk {
            path: relative.to_string(),
            offset: 0,
            total_len: bytes.len() as u64,
            bytes,
        });
    }
    install_chunks(data_dir, &chunks)
}

fn install_chunks(data_dir: &Path, chunks: &[FileChunk]) -> Result<(), PhobosError> {
    let mut by_path: BTreeMap<&str, Vec<&FileChunk>> = BTreeMap::new();
    for chunk in chunks {
        validate_relative_path(&chunk.path)?;
        by_path.entry(&chunk.path).or_default().push(chunk);
    }
    for (relative, mut file_chunks) in by_path {
        file_chunks.sort_by_key(|chunk| chunk.offset);
        let total_len = file_chunks.first().map_or(0, |chunk| chunk.total_len);
        if file_chunks.iter().any(|chunk| chunk.total_len != total_len) {
            return Err(PhobosError::new(
                ErrorCode::Recovery,
                "inconsistent WAL file image length",
            ));
        }
        let destination = data_dir.join(relative);
        let temporary = destination.with_extension("recovery.tmp");
        if let Some(parent) = temporary.parent() {
            phobos_observability::measure("fs.create_dir_all", || fs::create_dir_all(parent))?;
        }
        let mut file = OpenOptions::new()
            .create(true)
            .truncate(true)
            .read(true)
            .write(true)
            .open(&temporary)?;
        file.set_len(total_len)?;
        for chunk in file_chunks {
            let end = chunk
                .offset
                .checked_add(chunk.bytes.len() as u64)
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::Recovery, "WAL file chunk offset overflow")
                })?;
            if end > total_len {
                return Err(PhobosError::new(
                    ErrorCode::Recovery,
                    "WAL file chunk exceeds declared image length",
                ));
            }
            file.seek(SeekFrom::Start(chunk.offset))?;
            file.write_all(&chunk.bytes)?;
        }
        phobos_observability::measure("fs.sync_all", || file.sync_all())?;
        drop(file);
        if destination.exists() {
            phobos_observability::measure("fs.remove_file", || fs::remove_file(&destination))?;
        }
        phobos_observability::measure("fs.rename", || fs::rename(&temporary, &destination))?;
        if relative.ends_with(".idx") {
            phobos_observability::certification_crash("during_installation");
        }
    }
    Ok(())
}

fn snapshot_files(dir: &Path) -> Result<Vec<PathBuf>, PhobosError> {
    let _measurement = phobos_observability::span("fs.snapshot_metadata");
    let mut paths = Vec::new();
    if !dir.exists() {
        return Ok(paths);
    }
    for entry in phobos_observability::measure("fs.read_dir", || fs::read_dir(dir))? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file() && is_database_file(&path) {
            paths.push(path);
        }
    }
    paths.sort();
    Ok(paths)
}

fn is_database_file(path: &Path) -> bool {
    matches!(
        path.extension().and_then(|value| value.to_str()),
        Some("phc" | "heap" | "idx" | "stats")
    )
}

fn encode_chunk(
    path: &str,
    offset: u64,
    total_len: u64,
    bytes: &[u8],
) -> Result<Vec<u8>, PhobosError> {
    validate_relative_path(path)?;
    let path_bytes = path.as_bytes();
    let path_len = u16::try_from(path_bytes.len())
        .map_err(|_| PhobosError::new(ErrorCode::InvalidWal, "WAL file path too long"))?;
    let chunk_len = u32::try_from(bytes.len())
        .map_err(|_| PhobosError::new(ErrorCode::InvalidWal, "WAL chunk too large"))?;
    let mut out = Vec::with_capacity(2 + path_bytes.len() + 8 + 8 + 4 + bytes.len());
    out.extend_from_slice(&path_len.to_le_bytes());
    out.extend_from_slice(path_bytes);
    out.extend_from_slice(&offset.to_le_bytes());
    out.extend_from_slice(&total_len.to_le_bytes());
    out.extend_from_slice(&chunk_len.to_le_bytes());
    out.extend_from_slice(bytes);
    Ok(out)
}

fn decode_chunk(payload: &[u8]) -> Result<FileChunk, PhobosError> {
    let mut cursor = 0usize;
    let path_len = usize::from(take_u16(payload, &mut cursor)?);
    let path_end = cursor
        .checked_add(path_len)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidWal, "WAL path offset overflow"))?;
    if path_end > payload.len() {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "truncated WAL path",
        ));
    }
    let path = String::from_utf8(payload[cursor..path_end].to_vec())
        .map_err(|_| PhobosError::new(ErrorCode::InvalidWal, "WAL path is not UTF-8"))?;
    cursor = path_end;
    validate_relative_path(&path)?;
    let offset = take_u64(payload, &mut cursor)?;
    let total_len = take_u64(payload, &mut cursor)?;
    let chunk_len = take_u32(payload, &mut cursor)? as usize;
    let end = cursor
        .checked_add(chunk_len)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidWal, "WAL chunk offset overflow"))?;
    if end != payload.len() {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "truncated or trailing WAL chunk bytes",
        ));
    }
    Ok(FileChunk {
        path,
        offset,
        total_len,
        bytes: payload[cursor..end].to_vec(),
    })
}

fn validate_relative_path(path: &str) -> Result<(), PhobosError> {
    let candidate = Path::new(path);
    if candidate.is_absolute() || candidate.components().count() != 1 || path.contains("..") {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "invalid WAL snapshot path",
        ));
    }
    Ok(())
}

fn write_record(file: &mut File, record: &WalRecord) -> Result<(), PhobosError> {
    let _profile = phobos_observability::span("wal.write_record");
    let payload_len = u32::try_from(record.payload.len())
        .map_err(|_| PhobosError::new(ErrorCode::InvalidWal, "WAL record payload too large"))?;
    let total_len = HEADER_LEN
        .checked_add(record.payload.len())
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidWal, "WAL record length overflow"))?;
    let total_len_u32 = u32::try_from(total_len)
        .map_err(|_| PhobosError::new(ErrorCode::InvalidWal, "WAL record too large"))?;
    let mut bytes = Vec::with_capacity(total_len);
    bytes.extend_from_slice(&MAGIC);
    bytes.extend_from_slice(&VERSION.to_le_bytes());
    bytes.push(record.record_type as u8);
    bytes.push(0);
    bytes.extend_from_slice(&total_len_u32.to_le_bytes());
    bytes.extend_from_slice(&record.txn_id.to_le_bytes());
    bytes.extend_from_slice(&record.lsn.to_le_bytes());
    bytes.extend_from_slice(&record.prev_lsn.to_le_bytes());
    bytes.extend_from_slice(&payload_len.to_le_bytes());
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.extend_from_slice(&record.payload);
    let value = checksum_record(&bytes);
    bytes[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4].copy_from_slice(&value.to_le_bytes());
    file.write_all(&bytes)?;
    WRITTEN_BYTES.fetch_add(bytes.len() as u64, Ordering::Relaxed);
    phobos_observability::event("wal.bytes", bytes.len() as u64);
    Ok(())
}

fn scan_records(
    path: &Path,
    tolerate_truncated_tail: bool,
) -> Result<(Vec<WalRecord>, u64), PhobosError> {
    if !path.exists() {
        return Ok((Vec::new(), 0));
    }
    let mut file = File::open(path)?;
    let len = phobos_observability::measure("fs.file_metadata", || file.metadata())?.len();
    let mut offset = 0u64;
    let mut records = Vec::new();
    while offset < len {
        let remaining = len - offset;
        if remaining < HEADER_LEN as u64 {
            if remaining >= 6 {
                let mut prefix = [0; 6];
                file.read_exact(&mut prefix)?;
                if prefix[..4] == MAGIC && u16::from_le_bytes([prefix[4], prefix[5]]) != VERSION {
                    return Err(PhobosError::new(
                        ErrorCode::InvalidWal,
                        "unsupported WAL version in partial header",
                    ));
                }
            }
            if tolerate_truncated_tail {
                break;
            }
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "truncated WAL header",
            ));
        }
        let mut header = [0u8; HEADER_LEN];
        file.read_exact(&mut header)?;
        if header[0..4] != MAGIC {
            return Err(PhobosError::new(ErrorCode::InvalidWal, "invalid WAL magic"));
        }
        if u16::from_le_bytes([header[4], header[5]]) != VERSION {
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "unsupported WAL version",
            ));
        }
        let total_len = u32::from_le_bytes(header[8..12].try_into().expect("wal length")) as usize;
        if total_len < HEADER_LEN {
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "invalid WAL record length",
            ));
        }
        if offset + total_len as u64 > len {
            if tolerate_truncated_tail {
                break;
            }
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "truncated WAL record",
            ));
        }
        let payload_len =
            u32::from_le_bytes(header[36..40].try_into().expect("payload length")) as usize;
        if HEADER_LEN + payload_len != total_len {
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "WAL payload length mismatch",
            ));
        }
        let mut bytes = Vec::with_capacity(total_len);
        bytes.extend_from_slice(&header);
        let mut payload = vec![0u8; payload_len];
        file.read_exact(&mut payload)?;
        bytes.extend_from_slice(&payload);
        let expected = u32::from_le_bytes(
            header[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4]
                .try_into()
                .expect("checksum"),
        );
        if checksum_record(&bytes) != expected {
            if tolerate_truncated_tail && offset + total_len as u64 == len {
                break;
            }
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "WAL checksum mismatch",
            ));
        }
        records.push(WalRecord {
            record_type: RecordType::try_from(header[6])?,
            txn_id: u64::from_le_bytes(header[12..20].try_into().expect("txn id")),
            lsn: u64::from_le_bytes(header[20..28].try_into().expect("lsn")),
            prev_lsn: u64::from_le_bytes(header[28..36].try_into().expect("prev lsn")),
            payload,
        });
        offset += total_len as u64;
    }
    Ok((records, offset))
}

fn checksum_record(bytes: &[u8]) -> u32 {
    let mut hash = 0x811c_9dc5u32;
    for (index, byte) in bytes.iter().enumerate() {
        let value = if (CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4).contains(&index) {
            0
        } else {
            *byte
        };
        hash ^= u32::from(value);
        hash = hash.wrapping_mul(0x0100_0193);
    }
    hash
}

fn read_generation(path: &Path) -> Result<u32, PhobosError> {
    if !path.exists() {
        let mut file = OpenOptions::new()
            .create_new(true)
            .append(true)
            .read(true)
            .open(path)?;
        file.write_all(b"PHWG")?;
        file.write_all(&VERSION.to_le_bytes())?;
        phobos_observability::measure("fs.sync_data", || file.sync_data())?;
        return Ok(0);
    }
    let mut file = OpenOptions::new().read(true).write(true).open(path)?;
    let len = phobos_observability::measure("fs.file_metadata", || file.metadata())?.len();
    if len < 6 {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "truncated WAL generation header",
        ));
    }
    let mut header = [0u8; 6];
    file.read_exact(&mut header)?;
    if &header[0..4] != b"PHWG" || u16::from_le_bytes([header[4], header[5]]) != VERSION {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "invalid WAL generation file",
        ));
    }
    let mut offset = 6u64;
    let mut generation = 0u32;
    while len - offset >= 8 {
        let mut record = [0u8; 8];
        file.read_exact(&mut record)?;
        let value_bytes: [u8; 4] = record[0..4].try_into().expect("generation bytes");
        let expected = u32::from_le_bytes(record[4..8].try_into().expect("generation checksum"));
        if checksum_record(&value_bytes) != expected {
            if offset + 8 == len {
                break;
            }
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "WAL generation checksum mismatch",
            ));
        }
        let value = u32::from_le_bytes(value_bytes);
        if value <= generation {
            return Err(PhobosError::new(
                ErrorCode::InvalidWal,
                "WAL generations are not strictly increasing",
            ));
        }
        generation = value;
        offset += 8;
    }
    if offset < len {
        file.set_len(offset)?;
        phobos_observability::measure("fs.sync_data", || file.sync_data())?;
    }
    Ok(generation)
}

fn write_generation(path: &Path, generation: u32) -> Result<(), PhobosError> {
    let bytes = generation.to_le_bytes();
    let mut file = OpenOptions::new().append(true).open(path)?;
    file.write_all(&bytes)?;
    phobos_observability::event("wal.bytes", bytes.len() as u64);
    file.write_all(&checksum_record(&bytes).to_le_bytes())?;
    phobos_observability::measure("fs.sync_data", || file.sync_data())?;
    Ok(())
}

fn take_u16(bytes: &[u8], cursor: &mut usize) -> Result<u16, PhobosError> {
    let value = take(bytes, cursor, 2)?;
    Ok(u16::from_le_bytes(value.try_into().expect("u16")))
}

fn take_u32(bytes: &[u8], cursor: &mut usize) -> Result<u32, PhobosError> {
    let value = take(bytes, cursor, 4)?;
    Ok(u32::from_le_bytes(value.try_into().expect("u32")))
}

fn take_u64(bytes: &[u8], cursor: &mut usize) -> Result<u64, PhobosError> {
    let value = take(bytes, cursor, 8)?;
    Ok(u64::from_le_bytes(value.try_into().expect("u64")))
}

fn take<'a>(bytes: &'a [u8], cursor: &mut usize, len: usize) -> Result<&'a [u8], PhobosError> {
    let end = cursor
        .checked_add(len)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidWal, "WAL decode offset overflow"))?;
    if end > bytes.len() {
        return Err(PhobosError::new(
            ErrorCode::InvalidWal,
            "truncated WAL payload",
        ));
    }
    let value = &bytes[*cursor..end];
    *cursor = end;
    Ok(value)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_dir(label: &str) -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-wal-{label}-{n}"))
    }

    #[test]
    fn framed_records_round_trip_and_checksum_detects_corruption() {
        let dir = temp_dir("frame");
        fs::create_dir_all(&dir).unwrap();
        let mut wal = Wal::open(&dir).unwrap();
        wal.append(RecordType::Begin, 7, 0, b"abc").unwrap();
        wal.sync().unwrap();
        let (records, _) = scan_records(&dir.join(WAL_FILE), false).unwrap();
        assert_eq!(records.len(), 1);
        assert_eq!(records[0].txn_id, 7);
        drop(wal);
        let path = dir.join(WAL_FILE);
        let mut bytes = fs::read(&path).unwrap();
        let last = bytes.len() - 1;
        bytes[last] ^= 0x40;
        fs::write(&path, bytes).unwrap();
        assert_eq!(
            scan_records(&path, false).unwrap_err().code,
            ErrorCode::ChecksumMismatch
        );
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn truncated_final_record_is_ignored_and_trimmed() {
        let dir = temp_dir("truncate");
        fs::create_dir_all(&dir).unwrap();
        let mut wal = Wal::open(&dir).unwrap();
        wal.append(RecordType::Begin, 1, 0, &[]).unwrap();
        wal.append(RecordType::Commit, 1, 0, &[]).unwrap();
        wal.sync().unwrap();
        drop(wal);
        let path = dir.join(WAL_FILE);
        let len = fs::metadata(&path).unwrap().len();
        OpenOptions::new()
            .write(true)
            .open(&path)
            .unwrap()
            .set_len(len - 5)
            .unwrap();
        let report = recover(&dir).unwrap();
        assert!(report.truncated_tail);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn committed_snapshot_redoes_idempotently() {
        let base = temp_dir("redo");
        let snapshot = base.join("snapshot");
        let data = base.join("data");
        fs::create_dir_all(&snapshot).unwrap();
        fs::create_dir_all(&data).unwrap();
        fs::write(snapshot.join("catalog.phc"), b"catalog-image").unwrap();
        fs::write(snapshot.join("table-0000000000000001.heap"), b"heap-image").unwrap();
        let mut wal = Wal::open(&data).unwrap();
        wal.write_transaction_snapshot(9, &snapshot).unwrap();
        drop(wal);
        assert_eq!(recover(&data).unwrap().redone_transactions, 1);
        assert_eq!(
            fs::read(data.join("catalog.phc")).unwrap(),
            b"catalog-image"
        );
        assert_eq!(recover(&data).unwrap().redone_transactions, 1);
        assert_eq!(
            fs::read(data.join("table-0000000000000001.heap")).unwrap(),
            b"heap-image"
        );
        let _ = fs::remove_dir_all(base);
    }
}
