//! WAL version 2: bounded full-page redo, durable commit receipts, and recovery.
//! Fresh databases use V2; existing legacy databases require offline migration.
#[cfg(test)]
mod compact_tests;
mod delta;
mod format;
pub mod page_format;
#[cfg(test)]
mod writethrough_tests;
pub use format::{Body, FileId, MAX_RECORD_BYTES, PageAction, Record, read_record};

mod scan;
pub use scan::{ScanReport, Tail, inspect, interrupted_rotation, visit_validated};

mod log;
pub use log::{DurabilityMode, DurableCommit, ForceIntent, PendingCommit, Wal};
#[cfg(any(test, feature = "test-hooks"))]
pub use log::{set_thread_mode_for_test, test_short_write};

mod replay;
pub use replay::visit_committed;

mod recovery;
pub use recovery::redo;

/// Copy active and sealed WAL files before a diagnostic checkpoint can retire
/// them. Test-only: production retention and on-disk formats are unchanged.
#[cfg(feature = "test-hooks")]
pub fn preserve_wal_for_test(
    directory: &std::path::Path,
    destination: &std::path::Path,
) -> std::io::Result<usize> {
    std::fs::create_dir_all(destination)?;
    let mut copied = 0;
    for entry in std::fs::read_dir(directory)? {
        let entry = entry?;
        let name = entry.file_name();
        if name.to_string_lossy().starts_with("phobos.wal") && entry.file_type()?.is_file() {
            std::fs::copy(entry.path(), destination.join(name))?;
            copied += 1;
        }
    }
    Ok(copied)
}

mod replication;
pub use replication::{
    ensure_system_id, read_system_id, remove_replication_slot, replication_retention_lsn,
    replication_slots, set_replication_slot,
};

mod retention;
pub use retention::{
    HistoryFile, RETAINED_DIR, RetentionReport, history_files, retention_report, visit_history,
};
