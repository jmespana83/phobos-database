use phobos_error::{ErrorCode, PhobosError};
use std::io::Read;

pub const MAX_RECORD_BYTES: usize = 64 * 1024;
pub(super) const HEADER_LEN: usize = 44;
const PAGE_BYTES: usize = 8192;
const VERSION: u16 = 2;

type Result<T> = std::result::Result<T, PhobosError>;

/// File identities are encoded as a kind and numeric ID, never an arbitrary
/// path. Recovery cannot target a path outside the database through WAL input.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum FileId {
    Heap(u64),
    Index(u64),
    Tables,
    Indexes,
    Statistics,
}
impl FileId {
    #[must_use]
    pub fn name(self) -> String {
        match self {
            Self::Heap(id) => format!("table-{id:016x}.heap"),
            Self::Index(id) => format!("index-{id:016x}.idx"),
            Self::Tables => "catalog.phc".into(),
            Self::Indexes => "indexes.phc".into(),
            Self::Statistics => "phobos.stats".into(),
        }
    }
    #[must_use]
    pub fn is_paged(self) -> bool {
        matches!(self, Self::Heap(_) | Self::Index(_))
    }
    fn encode(self, out: &mut Vec<u8>) -> Result<()> {
        let (kind, id) = match self {
            Self::Heap(id) if id > 0 => (1, id),
            Self::Index(id) if id > 0 => (2, id),
            Self::Tables => (3, 0),
            Self::Indexes => (4, 0),
            Self::Statistics => (5, 0),
            _ => return Err(invalid("zero V2 WAL file ID")),
        };
        out.push(kind);
        out.extend_from_slice(&id.to_le_bytes());
        Ok(())
    }
    fn decode(input: &mut Input<'_>) -> Result<Self> {
        let kind = input.byte()?;
        let id = input.u64()?;
        match (kind, id) {
            (1, id) if id > 0 => Ok(Self::Heap(id)),
            (2, id) if id > 0 => Ok(Self::Index(id)),
            (3, 0) => Ok(Self::Tables),
            (4, 0) => Ok(Self::Indexes),
            (5, 0) => Ok(Self::Statistics),
            _ => Err(invalid("invalid V2 WAL file identity")),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PageAction {
    HeapInsert,
    HeapUpdate,
    HeapDelete,
    Index,
    Initialize,
}
impl PageAction {
    fn kind(self) -> u8 {
        match self {
            Self::HeapInsert => 2,
            Self::HeapUpdate => 3,
            Self::HeapDelete => 4,
            Self::Index => 5,
            Self::Initialize => 8,
        }
    }
    fn from_kind(kind: u8) -> Result<Self> {
        Ok(match kind {
            2 => Self::HeapInsert,
            3 => Self::HeapUpdate,
            4 => Self::HeapDelete,
            5 => Self::Index,
            8 => Self::Initialize,
            _ => return Err(invalid("invalid V3 page action")),
        })
    }
    fn validate(self, file: FileId) -> Result<()> {
        if matches!(
            (self, file),
            (
                Self::HeapInsert | Self::HeapUpdate | Self::HeapDelete,
                FileId::Heap(_)
            ) | (Self::Index, FileId::Index(_))
                | (Self::Initialize, FileId::Heap(_) | FileId::Index(_))
        ) {
            Ok(())
        } else {
            Err(invalid("V2 WAL page action/file kind mismatch"))
        }
    }
}

/// Initial redo uses full changed-page images. Heap operation labels distinguish
/// insert/update/delete intent; replay does not require undo or an old page.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Body {
    Anchor {
        checkpoint_lsn: u64,
        next_txn_id: u64,
        /// Version 2 permits checksummed page LSNs and deferred data forcing.
        /// Encoded in a retained header flag that W1 readers reject.
        page_format: u16,
    },
    Begin,
    /// Stable MVCC identity, independent of this record chain's append-order ID.
    MvccIdentity(u64),
    Page {
        action: PageAction,
        file: FileId,
        page: u64,
        image: Box<[u8; PAGE_BYTES]>,
    },
    /// 0.2-D compact redo (record kind 15): turn the exact image logged at
    /// `base_lsn` (identified by its embedded page checksum) into this
    /// record's image. `ops` is a validated `delta` program; the stamped
    /// fields (scheme byte, page LSN, checksum) are re-stamped by redo and the
    /// recomputed page checksum must equal `result_checksum`.
    PageDelta {
        action: PageAction,
        file: FileId,
        page: u64,
        base_lsn: u64,
        base_checksum: u32,
        result_checksum: u32,
        ops: Vec<u8>,
    },
    Metadata {
        file: FileId,
        offset: u64,
        total_len: u64,
        bytes: Vec<u8>,
    },
    Allocate {
        file: FileId,
        pages: u64,
    },
    Commit,
    Abort,
    Checkpoint {
        checkpoint_lsn: u64,
        next_txn_id: u64,
    },
    Create(FileId),
    Delete(FileId),
}
impl Body {
    /// Semantic bounds/type checks shared by encoding and decoding.
    fn validate(&self) -> Result<()> {
        match self {
            Self::Anchor { next_txn_id, .. } | Self::Checkpoint { next_txn_id, .. } => {
                if *next_txn_id == 0 {
                    return Err(invalid("zero V2 next transaction ID"));
                }
            }
            Self::MvccIdentity(id) => {
                if *id == 0 {
                    return Err(invalid("zero MVCC identity"));
                }
            }
            Self::Begin | Self::Commit | Self::Abort => {}
            Self::Page {
                action, file, page, ..
            } => {
                action.validate(*file)?;
                page_bounds(*page)?;
                file_id_ok(*file)?;
            }
            Self::PageDelta {
                action,
                file,
                page,
                base_lsn,
                ops,
                ..
            } => {
                if *action == PageAction::Initialize || !file.is_paged() {
                    return Err(invalid("V3 page delta needs an existing paged page"));
                }
                action.validate(*file)?;
                page_bounds(*page)?;
                file_id_ok(*file)?;
                if *base_lsn == 0 {
                    return Err(invalid("V3 page delta has no base LSN"));
                }
                super::delta::validate(ops, true)?;
                if HEADER_LEN + DELTA_FIXED + ops.len() > MAX_RECORD_BYTES {
                    return Err(invalid("V3 page delta exceeds maximum"));
                }
            }
            Self::Metadata {
                file,
                offset,
                total_len,
                bytes,
            } => {
                if file.is_paged()
                    || bytes.len() > MAX_RECORD_BYTES - HEADER_LEN - 25
                    || offset
                        .checked_add(bytes.len() as u64)
                        .is_none_or(|end| end > *total_len)
                    || (bytes.is_empty() && (*offset != 0 || *total_len != 0))
                {
                    return Err(invalid("invalid V2 metadata chunk bounds"));
                }
                file_id_ok(*file)?;
            }
            Self::Allocate { file, pages } => {
                if !file.is_paged() || pages.checked_mul(PAGE_BYTES as u64).is_none() {
                    return Err(invalid("invalid V2 page allocation"));
                }
                file_id_ok(*file)?;
            }
            Self::Create(file) | Self::Delete(file) => file_id_ok(*file)?,
        }
        Ok(())
    }

    /// Append the payload to `out` and return the record kind. A full page
    /// image is written zero-elided (kind 16) only when that is smaller.
    fn encode_payload(&self, out: &mut Vec<u8>) -> Result<u8> {
        self.validate()?;
        let kind = match self {
            Self::Anchor {
                checkpoint_lsn,
                next_txn_id,
                ..
            }
            | Self::Checkpoint {
                checkpoint_lsn,
                next_txn_id,
            } => {
                out.extend_from_slice(&checkpoint_lsn.to_le_bytes());
                out.extend_from_slice(&next_txn_id.to_le_bytes());
                if matches!(self, Self::Anchor { .. }) {
                    0
                } else {
                    11
                }
            }
            Self::MvccIdentity(id) => {
                out.extend_from_slice(&id.to_le_bytes());
                14
            }
            Self::Begin => 1,
            Self::Commit => 9,
            Self::Abort => 10,
            Self::Page {
                action,
                file,
                page,
                image,
            } => {
                file.encode(out)?;
                out.extend_from_slice(&page.to_le_bytes());
                // Zero-elided only when it saves a meaningful amount.
                if 1 + super::delta::sparse_len(image) + 64 < PAGE_BYTES {
                    out.push(action.kind());
                    super::delta::encode_sparse(image, out);
                    KIND_PAGE_IMAGE
                } else {
                    out.extend_from_slice(image.as_ref());
                    action.kind()
                }
            }
            Self::PageDelta {
                action,
                file,
                page,
                base_lsn,
                base_checksum,
                result_checksum,
                ops,
            } => {
                encode_delta_head(
                    out,
                    *file,
                    *page,
                    *action,
                    *base_lsn,
                    *base_checksum,
                    *result_checksum,
                )?;
                out.extend_from_slice(ops);
                KIND_PAGE_DELTA
            }
            Self::Metadata {
                file,
                offset,
                total_len,
                bytes,
            } => {
                file.encode(out)?;
                out.extend_from_slice(&offset.to_le_bytes());
                out.extend_from_slice(&total_len.to_le_bytes());
                out.extend_from_slice(bytes);
                6
            }
            Self::Allocate { file, pages } => {
                file.encode(out)?;
                out.extend_from_slice(&pages.to_le_bytes());
                7
            }
            Self::Create(file) => {
                file.encode(out)?;
                12
            }
            Self::Delete(file) => {
                file.encode(out)?;
                13
            }
        };
        Ok(kind)
    }
    fn decode(kind: u8, flags: u8, payload: &[u8]) -> Result<Self> {
        if matches!(kind, KIND_PAGE_DELTA | KIND_PAGE_IMAGE) && flags != RECORD_CRC32C {
            return Err(invalid("V3 page record requires a CRC32C record checksum"));
        }
        let mut input = Input(payload);
        let body = match kind {
            0 | 11 => {
                let checkpoint_lsn = input.u64()?;
                let next_txn_id = input.u64()?;
                if kind == 0 {
                    Self::Anchor {
                        checkpoint_lsn,
                        next_txn_id,
                        page_format: u16::from(flags & !(ANCHOR_V3 | ANCHOR_PREALLOC)) + 1,
                    }
                } else {
                    Self::Checkpoint {
                        checkpoint_lsn,
                        next_txn_id,
                    }
                }
            }
            14 => Self::MvccIdentity(input.u64()?),
            1 => Self::Begin,
            9 => Self::Commit,
            10 => Self::Abort,
            2 | 3 | 4 | 5 | 8 => {
                let action = PageAction::from_kind(kind)?;
                let file = FileId::decode(&mut input)?;
                let page = input.u64()?;
                let image = Box::new(
                    input
                        .take(PAGE_BYTES)?
                        .try_into()
                        .expect("bounded page image"),
                );
                Self::Page {
                    action,
                    file,
                    page,
                    image,
                }
            }
            KIND_PAGE_IMAGE => {
                let file = FileId::decode(&mut input)?;
                let page = input.u64()?;
                let action = PageAction::from_kind(input.byte()?)?;
                let image = super::delta::decode_sparse(input.take(input.0.len())?)?;
                Self::Page {
                    action,
                    file,
                    page,
                    image,
                }
            }
            KIND_PAGE_DELTA => {
                let file = FileId::decode(&mut input)?;
                let page = input.u64()?;
                let action = PageAction::from_kind(input.byte()?)?;
                let base_lsn = input.u64()?;
                let base_checksum = input.u32()?;
                let result_checksum = input.u32()?;
                Self::PageDelta {
                    action,
                    file,
                    page,
                    base_lsn,
                    base_checksum,
                    result_checksum,
                    ops: input.take(input.0.len())?.to_vec(),
                }
            }
            6 => {
                let file = FileId::decode(&mut input)?;
                let offset = input.u64()?;
                let total_len = input.u64()?;
                let bytes = input.take(input.0.len())?.to_vec();
                Self::Metadata {
                    file,
                    offset,
                    total_len,
                    bytes,
                }
            }
            7 => Self::Allocate {
                file: FileId::decode(&mut input)?,
                pages: input.u64()?,
            },
            12 => Self::Create(FileId::decode(&mut input)?),
            13 => Self::Delete(FileId::decode(&mut input)?),
            _ => return Err(invalid("unknown V2 WAL record type")),
        };
        if !input.0.is_empty() {
            return Err(invalid("trailing V2 WAL payload bytes"));
        }
        body.validate()?;
        Ok(body)
    }
}

/// 0.2-D record kinds. Kind 16 decodes to `Body::Page`.
pub(super) const KIND_PAGE_DELTA: u8 = 15;
pub(super) const KIND_PAGE_IMAGE: u8 = 16;
/// Anchor flag bit: this WAL may contain V3 compact page records. 0.2-C and
/// earlier reject the flag during preflight instead of misreading records.
pub(super) const ANCHOR_V3: u8 = 0x10;
/// 0.2-E anchor flag: the segment is preallocated (zero-filled extents); its
/// logical end is the end of the valid record prefix, followed by zeros.
/// 0.2-D requires `flags & 0xe0 == 0` and therefore refuses such a WAL.
pub(super) const ANCHOR_PREALLOC: u8 = 0x20;
/// Payload bytes of a delta before its ops: file, page, action, base LSN,
/// base checksum, result checksum.
pub(super) const DELTA_FIXED: usize = 9 + 8 + 1 + 8 + 4 + 4;

fn page_bounds(page: u64) -> Result<()> {
    page.checked_mul(PAGE_BYTES as u64)
        .and_then(|v| v.checked_add(PAGE_BYTES as u64))
        .map(|_| ())
        .ok_or_else(|| invalid("V2 WAL page offset overflow"))
}
fn file_id_ok(file: FileId) -> Result<()> {
    match file {
        FileId::Heap(0) | FileId::Index(0) => Err(invalid("zero V2 WAL file ID")),
        _ => Ok(()),
    }
}

/// Write a delta payload's fixed part (shared with the writer's direct path).
pub(super) fn encode_delta_head(
    out: &mut Vec<u8>,
    file: FileId,
    page: u64,
    action: PageAction,
    base_lsn: u64,
    base_checksum: u32,
    result_checksum: u32,
) -> Result<()> {
    file.encode(out)?;
    out.extend_from_slice(&page.to_le_bytes());
    out.push(action.kind());
    out.extend_from_slice(&base_lsn.to_le_bytes());
    out.extend_from_slice(&base_checksum.to_le_bytes());
    out.extend_from_slice(&result_checksum.to_le_bytes());
    Ok(())
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Record {
    pub txn_id: u64,
    pub lsn: u64,
    pub prev_lsn: u64,
    pub body: Body,
}
impl Record {
    fn validate(&self) -> Result<()> {
        if self.lsn == 0 {
            return Err(invalid("zero V2 WAL LSN"));
        }
        match &self.body {
            Body::Anchor { checkpoint_lsn, .. } | Body::Checkpoint { checkpoint_lsn, .. } => {
                if self.txn_id != 0 || self.prev_lsn != 0 || *checkpoint_lsn >= self.lsn {
                    return Err(invalid("invalid V2 WAL checkpoint identity"));
                }
            }
            Body::Begin => {
                if self.txn_id == 0 || self.prev_lsn != 0 {
                    return Err(invalid("invalid V2 WAL BEGIN identity"));
                }
            }
            _ => {
                if self.txn_id == 0 || self.prev_lsn == 0 || self.prev_lsn >= self.lsn {
                    return Err(invalid("invalid V2 WAL transaction chain identity"));
                }
            }
        }
        if matches!(self.body, Body::Anchor { page_format, .. } if !matches!(page_format, 1..=4)) {
            return Err(invalid("unsupported V2 anchor page format"));
        }
        if matches!(self.body, Body::PageDelta { base_lsn, .. } if base_lsn >= self.lsn) {
            return Err(invalid("V3 page delta base is not older than its record"));
        }
        Ok(())
    }
    pub fn encode(&self) -> Result<Vec<u8>> {
        let mut out = Vec::new();
        self.encode_into(&mut out)?;
        Ok(out)
    }
    /// 0.2-D: encode straight into an existing buffer (the WAL writer's
    /// batch buffer). On error `out` is left unchanged.
    pub fn encode_into(&self, out: &mut Vec<u8>) -> Result<usize> {
        self.validate()?;
        let start = out.len();
        out.resize(start + HEADER_LEN, 0);
        let kind = match self.body.encode_payload(out) {
            Ok(kind) => kind,
            Err(error) => {
                out.truncate(start);
                return Err(error);
            }
        };
        let flags = match self.body {
            Body::Anchor { page_format, .. } => (page_format - 1) as u8 | ANCHOR_V3,
            // 0.2-C: data records carry a hardware CRC32C (flag 4) instead
            // of the byte-serial FNV-1a; anchors keep their established form.
            _ => RECORD_CRC32C,
        };
        finish_record(
            out,
            start,
            kind,
            flags,
            self.txn_id,
            self.lsn,
            self.prev_lsn,
        )
    }
    pub fn decode(bytes: &[u8]) -> Result<Self> {
        if bytes.len() < HEADER_LEN {
            return Err(invalid("truncated V2 WAL header"));
        }
        let total = header_len(bytes[..HEADER_LEN].try_into().expect("checked header"))?;
        if bytes.len() != total {
            return Err(invalid("V2 WAL record length mismatch"));
        }
        let crc = u32::from_le_bytes(bytes[40..44].try_into().expect("checksum"));
        if record_checksum(bytes) != crc {
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "V2 WAL checksum mismatch",
            ));
        }
        let record = Self {
            txn_id: u64::from_le_bytes(bytes[12..20].try_into().expect("transaction")),
            lsn: u64::from_le_bytes(bytes[20..28].try_into().expect("lsn")),
            prev_lsn: u64::from_le_bytes(bytes[28..36].try_into().expect("previous lsn")),
            body: Body::decode(bytes[6], bytes[7], &bytes[HEADER_LEN..])?,
        };
        record.validate()?;
        Ok(record)
    }
}

/// Fill the header of the record whose payload follows `start + HEADER_LEN`
/// in `out`, and its checksum. Returns the record length.
pub(super) fn finish_record(
    out: &mut Vec<u8>,
    start: usize,
    kind: u8,
    flags: u8,
    txn_id: u64,
    lsn: u64,
    prev_lsn: u64,
) -> Result<usize> {
    let total = out.len() - start;
    if total > MAX_RECORD_BYTES {
        out.truncate(start);
        return Err(invalid("V2 WAL record exceeds maximum"));
    }
    let header = &mut out[start..start + HEADER_LEN];
    header[..4].copy_from_slice(b"PHWL");
    header[4..6].copy_from_slice(&VERSION.to_le_bytes());
    header[6] = kind;
    header[7] = flags;
    header[8..12].copy_from_slice(&(total as u32).to_le_bytes());
    header[12..20].copy_from_slice(&txn_id.to_le_bytes());
    header[20..28].copy_from_slice(&lsn.to_le_bytes());
    header[28..36].copy_from_slice(&prev_lsn.to_le_bytes());
    header[36..40].copy_from_slice(&((total - HEADER_LEN) as u32).to_le_bytes());
    header[40..44].copy_from_slice(&0u32.to_le_bytes());
    let crc = record_checksum(&out[start..]);
    out[start + 40..start + 44].copy_from_slice(&crc.to_le_bytes());
    Ok(total)
}

/// Record flag (non-anchor records): checksum is CRC32C, not FNV-1a.
pub(super) const RECORD_CRC32C: u8 = 4;

/// Checksum of a complete encoded record, its checksum field read as zero.
/// The algorithm is selected by the record's own header (kind/flags), so
/// records written before 0.2-C keep verifying with FNV-1a.
pub(super) fn record_checksum(bytes: &[u8]) -> u32 {
    if bytes.len() >= HEADER_LEN && bytes[6] != 0 && bytes[7] == RECORD_CRC32C {
        let crc = crc32c::crc32c(&bytes[..40]);
        let crc = crc32c::crc32c_append(crc, &[0; 4]);
        crc32c::crc32c_append(crc, &bytes[44..])
    } else {
        super::super::checksum_record(bytes)
    }
}

pub(super) fn header_len(header: &[u8; HEADER_LEN]) -> Result<usize> {
    if &header[..4] != b"PHWL" {
        return Err(invalid("invalid V2 WAL magic"));
    }
    if u16::from_le_bytes(header[4..6].try_into().expect("version")) != VERSION {
        return Err(invalid("unsupported WAL version; expected V2"));
    }
    let anchor_format = header[7] & !(ANCHOR_V3 | ANCHOR_PREALLOC);
    if header[7] != 0
        && !(header[6] == 0 && anchor_format <= 3 && (header[7] & 0xc0) == 0)
        && !(header[6] != 0 && header[7] == RECORD_CRC32C)
    {
        return Err(invalid("unsupported V2 WAL flags"));
    }
    let total = u32::from_le_bytes(header[8..12].try_into().expect("length")) as usize;
    if !(HEADER_LEN..=MAX_RECORD_BYTES).contains(&total) {
        return Err(invalid("invalid or oversized V2 WAL record length"));
    }
    let payload = u32::from_le_bytes(header[36..40].try_into().expect("payload length")) as usize;
    if payload != total - HEADER_LEN {
        return Err(invalid("V2 WAL payload length mismatch"));
    }
    Ok(total)
}

/// True when an encoded anchor header carries the V3 compact-redo flag.
pub(super) fn anchor_is_v3(header: &[u8]) -> bool {
    header.len() >= 8 && header[6] == 0 && header[7] & ANCHOR_V3 != 0
}

/// 0.2-E: true when an encoded anchor header marks a preallocated segment.
pub(super) fn anchor_is_prealloc(header: &[u8]) -> bool {
    header.len() >= 8 && header[6] == 0 && header[7] & ANCHOR_PREALLOC != 0
}

/// 0.2-E: encode an anchor record, optionally marking its segment as
/// preallocated (flag 0x20); the checksum covers the final flags byte.
pub(super) fn encode_anchor(record: &Record, prealloc: bool) -> Result<Vec<u8>> {
    if !matches!(record.body, Body::Anchor { .. }) {
        return Err(invalid("not a V2 anchor record"));
    }
    let mut bytes = record.encode()?;
    if prealloc {
        bytes[7] |= ANCHOR_PREALLOC;
        bytes[40..44].copy_from_slice(&0u32.to_le_bytes());
        let crc = record_checksum(&bytes);
        bytes[40..44].copy_from_slice(&crc.to_le_bytes());
    }
    Ok(bytes)
}

/// Strict single-record reader. Length/version checks precede payload allocation.
/// Recovery's separate scan policy determines whether a final tail is incomplete.
pub fn read_record(reader: &mut impl Read) -> Result<Option<Record>> {
    let mut header = [0; HEADER_LEN];
    if reader.read(&mut header[..1])? == 0 {
        return Ok(None);
    }
    reader.read_exact(&mut header[1..])?;
    let total = header_len(&header)?;
    let mut bytes = vec![0; total];
    bytes[..HEADER_LEN].copy_from_slice(&header);
    reader.read_exact(&mut bytes[HEADER_LEN..])?;
    Record::decode(&bytes).map(Some)
}

struct Input<'a>(&'a [u8]);
impl<'a> Input<'a> {
    fn take(&mut self, size: usize) -> Result<&'a [u8]> {
        if size > self.0.len() {
            return Err(invalid("truncated V2 WAL payload"));
        }
        let (value, rest) = self.0.split_at(size);
        self.0 = rest;
        Ok(value)
    }
    fn byte(&mut self) -> Result<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> Result<u32> {
        Ok(u32::from_le_bytes(
            self.take(4)?.try_into().expect("bounded integer"),
        ))
    }
    fn u64(&mut self) -> Result<u64> {
        Ok(u64::from_le_bytes(
            self.take(8)?.try_into().expect("bounded integer"),
        ))
    }
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidWal, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn record(body: Body) -> Record {
        let global = matches!(body, Body::Anchor { .. } | Body::Checkpoint { .. });
        let begin = matches!(body, Body::Begin);
        Record {
            txn_id: if global { 0 } else { 7 },
            lsn: 20,
            prev_lsn: if global || begin { 0 } else { 19 },
            body,
        }
    }
    #[test]
    fn all_v2_record_types_round_trip_with_bounded_images_and_identities() {
        let mut bodies = vec![
            Body::Anchor {
                checkpoint_lsn: 0,
                next_txn_id: 1,
                page_format: 1,
            },
            Body::Anchor {
                checkpoint_lsn: 0,
                next_txn_id: 1,
                page_format: 2,
            },
            Body::Begin,
            Body::Commit,
            Body::Abort,
            Body::Checkpoint {
                checkpoint_lsn: 19,
                next_txn_id: 8,
            },
            Body::Create(FileId::Heap(1)),
            Body::Delete(FileId::Index(2)),
            Body::Metadata {
                file: FileId::Tables,
                offset: 0,
                total_len: 3,
                bytes: vec![1, 2, 3],
            },
            Body::Allocate {
                file: FileId::Heap(1),
                pages: 3,
            },
        ];
        for action in [
            PageAction::HeapInsert,
            PageAction::HeapUpdate,
            PageAction::HeapDelete,
            PageAction::Index,
            PageAction::Initialize,
        ] {
            bodies.push(Body::Page {
                action,
                file: if action == PageAction::Index {
                    FileId::Index(2)
                } else {
                    FileId::Heap(1)
                },
                page: 1,
                image: Box::new([17; PAGE_BYTES]),
            });
        }
        for body in bodies {
            let record = record(body);
            let bytes = record.encode().unwrap();
            assert!(bytes.len() <= MAX_RECORD_BYTES);
            assert_eq!(Record::decode(&bytes).unwrap(), record);
            assert_eq!(
                read_record(&mut std::io::Cursor::new(bytes)).unwrap(),
                Some(record)
            );
        }
        assert_eq!(FileId::Heap(1).name(), "table-0000000000000001.heap");
        assert_eq!(FileId::Index(2).name(), "index-0000000000000002.idx");
    }
    #[test]
    fn v2c_crc32c_records_verify_and_pre_0_2_c_fnv_records_still_decode() {
        let body = || Body::Commit;
        let mut current = record(body()).encode().unwrap();
        assert_eq!(current[7], RECORD_CRC32C);
        assert_eq!(Record::decode(&current).unwrap(), record(body()));
        // A pre-0.2-C data record: flags 0 and an FNV-1a checksum.
        let mut legacy = current.clone();
        legacy[7] = 0;
        let crc = super::super::super::checksum_record(&legacy);
        legacy[40..44].copy_from_slice(&crc.to_le_bytes());
        assert_eq!(Record::decode(&legacy).unwrap(), record(body()));
        // Each checksum detects corruption; flags cannot be swapped silently.
        let last = current.len() - 1;
        current[last] ^= 1;
        assert!(Record::decode(&current).is_err());
        let mut swapped = legacy.clone();
        swapped[7] = RECORD_CRC32C;
        assert!(Record::decode(&swapped).is_err());
        // Anchors keep the established FNV form.
        let anchor = record(Body::Anchor {
            checkpoint_lsn: 3,
            next_txn_id: 9,
            page_format: 3,
        })
        .encode()
        .unwrap();
        // 0.2-D anchors add the V3 flag bit; pre-0.2-D anchors still decode.
        assert_eq!(anchor[7], 2 | ANCHOR_V3);
        assert!(Record::decode(&anchor).is_ok());
        let mut old_anchor = anchor.clone();
        old_anchor[7] = 2;
        let crc = record_checksum(&old_anchor);
        old_anchor[40..44].copy_from_slice(&crc.to_le_bytes());
        assert_eq!(
            Record::decode(&old_anchor).unwrap(),
            Record::decode(&anchor).unwrap()
        );
    }

    /// The exact 0.2-C header flag rule: it must reject every 0.2-D anchor,
    /// so an older binary refuses a V3 WAL during preflight.
    fn header_accepted_by_0_2_c(header: &[u8]) -> bool {
        header[7] == 0
            || (header[6] == 0 && matches!(header[7], 1..=3))
            || (header[6] != 0 && header[7] == RECORD_CRC32C)
    }

    #[test]
    fn v3_anchors_are_refused_by_the_0_2_c_header_rule() {
        for page_format in 1..=4 {
            let anchor = record(Body::Anchor {
                checkpoint_lsn: 3,
                next_txn_id: 9,
                page_format,
            })
            .encode()
            .unwrap();
            assert!(anchor_is_v3(&anchor));
            assert!(!header_accepted_by_0_2_c(&anchor));
            assert!(Record::decode(&anchor).is_ok());
        }
        // Unknown anchor bits stay rejected.
        let mut anchor = record(Body::Anchor {
            checkpoint_lsn: 3,
            next_txn_id: 9,
            page_format: 4,
        })
        .encode()
        .unwrap();
        for flags in [0x20, 0x14, 0x18, 0x80] {
            anchor[7] = flags;
            assert!(Record::decode(&anchor).is_err(), "{flags:#x}");
        }
    }

    fn heap_page(fill: u8, used: usize) -> Box<[u8; PAGE_BYTES]> {
        let mut image = Box::new([0; PAGE_BYTES]);
        image[..4].copy_from_slice(b"PHOP");
        image[8192 - used..].fill(fill);
        image
    }

    #[test]
    fn v3_delta_and_zero_elided_image_round_trip() {
        let delta = record(Body::PageDelta {
            action: PageAction::HeapInsert,
            file: FileId::Heap(3),
            page: 9,
            base_lsn: 11,
            base_checksum: 0xdead_beef,
            result_checksum: 0x1234_5678,
            ops: vec![1, 0, 1, 2, 0, 7, 7, 2, 0, 2, 0, 3, 4, 0],
        });
        let bytes = delta.encode().unwrap();
        assert_eq!(bytes[6], KIND_PAGE_DELTA);
        assert_eq!(bytes.len(), HEADER_LEN + DELTA_FIXED + 14);
        assert_eq!(Record::decode(&bytes).unwrap(), delta);
        // A mostly empty page is logged zero-elided and decodes to the same image.
        let sparse = record(Body::Page {
            action: PageAction::Initialize,
            file: FileId::Heap(3),
            page: 9,
            image: heap_page(5, 300),
        });
        let bytes = sparse.encode().unwrap();
        assert_eq!(bytes[6], KIND_PAGE_IMAGE);
        assert!(bytes.len() < 400);
        assert_eq!(Record::decode(&bytes).unwrap(), sparse);
        assert_eq!(
            read_record(&mut std::io::Cursor::new(&bytes)).unwrap(),
            Some(sparse)
        );
        // A full page keeps the raw V2 encoding.
        let full = record(Body::Page {
            action: PageAction::Index,
            file: FileId::Index(3),
            page: 9,
            image: Box::new([0x5a; PAGE_BYTES]),
        });
        let bytes = full.encode().unwrap();
        assert_eq!(bytes[6], 5);
        assert_eq!(Record::decode(&bytes).unwrap(), full);
    }

    #[test]
    fn v3_records_reject_corrupt_header_payload_length_checksum_and_truncation() {
        let delta = record(Body::PageDelta {
            action: PageAction::Index,
            file: FileId::Index(3),
            page: 2,
            base_lsn: 11,
            base_checksum: 1,
            result_checksum: 2,
            ops: vec![1, 100, 0, 3, 0, 9, 9, 9],
        })
        .encode()
        .unwrap();
        let sparse = record(Body::Page {
            action: PageAction::HeapUpdate,
            file: FileId::Heap(3),
            page: 2,
            image: heap_page(6, 100),
        })
        .encode()
        .unwrap();
        for good in [delta, sparse] {
            assert!(Record::decode(&good).is_ok());
            // Every single-byte change anywhere is detected (header or payload).
            for at in 0..good.len() {
                let mut bad = good.clone();
                bad[at] ^= 0x41;
                assert!(Record::decode(&bad).is_err(), "byte {at}");
            }
            // Truncation at every length.
            for end in 0..good.len() {
                assert!(read_record(&mut std::io::Cursor::new(&good[..end])).is_err() || end == 0);
            }
            // A consistent length/checksum with a malformed op program is still rejected.
            let mut bad = good.clone();
            bad.push(OP_GARBAGE);
            let total = bad.len() as u32;
            bad[8..12].copy_from_slice(&total.to_le_bytes());
            bad[36..40].copy_from_slice(&(total - HEADER_LEN as u32).to_le_bytes());
            let crc = record_checksum(&bad);
            bad[40..44].copy_from_slice(&crc.to_le_bytes());
            assert!(Record::decode(&bad).is_err());
            // V3 kinds require the CRC32C flag.
            let mut bad = good.clone();
            bad[7] = 0;
            let crc = record_checksum(&bad);
            bad[40..44].copy_from_slice(&crc.to_le_bytes());
            assert!(Record::decode(&bad).is_err());
        }
        // Semantic checks: initialize deltas, zero base, base not older than record.
        for body in [
            Body::PageDelta {
                action: PageAction::Initialize,
                file: FileId::Heap(1),
                page: 0,
                base_lsn: 1,
                base_checksum: 0,
                result_checksum: 0,
                ops: Vec::new(),
            },
            Body::PageDelta {
                action: PageAction::Index,
                file: FileId::Heap(1),
                page: 0,
                base_lsn: 1,
                base_checksum: 0,
                result_checksum: 0,
                ops: Vec::new(),
            },
            Body::PageDelta {
                action: PageAction::HeapUpdate,
                file: FileId::Heap(1),
                page: 0,
                base_lsn: 0,
                base_checksum: 0,
                result_checksum: 0,
                ops: Vec::new(),
            },
            Body::PageDelta {
                action: PageAction::HeapUpdate,
                file: FileId::Heap(1),
                page: 0,
                base_lsn: 20,
                base_checksum: 0,
                result_checksum: 0,
                ops: Vec::new(),
            },
        ] {
            assert!(record(body).encode().is_err());
        }
    }
    const OP_GARBAGE: u8 = 9;

    #[test]
    fn v2_rejects_bad_versions_lengths_flags_crc_and_payload_semantics() {
        let good = record(Body::Begin).encode().unwrap();
        for (offset, value) in [(4, 1), (4, 99), (7, 1), (8, 0), (40, 77)] {
            let mut bad = good.clone();
            bad[offset] = value;
            assert!(Record::decode(&bad).is_err());
        }
        let mut oversized = good.clone();
        oversized[8..12].copy_from_slice(&u32::MAX.to_le_bytes());
        let mut input = std::io::Cursor::new(oversized);
        assert!(read_record(&mut input).is_err());
        assert_eq!(input.position(), HEADER_LEN as u64);
        for body in [
            Body::Create(FileId::Heap(0)),
            Body::Allocate {
                file: FileId::Tables,
                pages: 1,
            },
            Body::Metadata {
                file: FileId::Tables,
                offset: u64::MAX,
                total_len: u64::MAX,
                bytes: vec![1],
            },
            Body::Metadata {
                file: FileId::Tables,
                offset: 0,
                total_len: MAX_RECORD_BYTES as u64,
                bytes: vec![0; MAX_RECORD_BYTES],
            },
            Body::Page {
                action: PageAction::Index,
                file: FileId::Heap(1),
                page: 0,
                image: Box::new([0; PAGE_BYTES]),
            },
        ] {
            assert!(record(body).encode().is_err());
        }
        let mut bad = record(Body::Commit);
        bad.prev_lsn = bad.lsn;
        assert!(bad.encode().is_err());
    }
    #[test]
    fn v2_strict_reader_rejects_truncation_and_trailing_payload() {
        let good = record(Body::Metadata {
            file: FileId::Indexes,
            offset: 0,
            total_len: 4,
            bytes: vec![1, 2, 3, 4],
        })
        .encode()
        .unwrap();
        assert!(
            read_record(&mut std::io::Cursor::new(Vec::<u8>::new()))
                .unwrap()
                .is_none()
        );
        for end in [1, 3, 6, HEADER_LEN - 1, HEADER_LEN, good.len() - 1] {
            assert!(read_record(&mut std::io::Cursor::new(&good[..end])).is_err());
        }
        let mut bad = record(Body::Begin).encode().unwrap();
        bad.push(0);
        bad[8..12].copy_from_slice(&((HEADER_LEN + 1) as u32).to_le_bytes());
        bad[36..40].copy_from_slice(&1u32.to_le_bytes());
        let crc = record_checksum(&bad);
        bad[40..44].copy_from_slice(&crc.to_le_bytes());
        assert!(Record::decode(&bad).is_err());
    }
}
