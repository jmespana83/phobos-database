//! Shared physical page version/LSN checks, without a storage/index dependency.
//! Version 1 pages have no LSN. Only explicit V2-capable WAL may upgrade them.
use super::FileId;
use phobos_error::{ErrorCode, PhobosError};

pub const PAGE_BYTES: usize = 8192;
type Result<T> = std::result::Result<T, PhobosError>;

struct Layout {
    magic: [u8; 4],
    checksum: usize,
    lsn: usize,
    has_id: bool,
}
fn layout(file: FileId, page: u64) -> Result<Layout> {
    match file {
        FileId::Heap(id) if id != 0 => Ok(Layout {
            magic: *b"PHOP",
            checksum: 32,
            lsn: 16,
            has_id: true,
        }),
        FileId::Index(id) if id != 0 && page == 0 => Ok(Layout {
            magic: *b"PHIX",
            checksum: 28,
            lsn: 32,
            has_id: false,
        }),
        FileId::Index(id) if id != 0 => Ok(Layout {
            magic: *b"PHIN",
            checksum: 36,
            lsn: 40,
            has_id: true,
        }),
        _ => Err(invalid(
            "page format requires a nonzero heap/index identity",
        )),
    }
}
fn checksum(bytes: &[u8; PAGE_BYTES], skip: usize) -> u32 {
    crate::page_checksum::checksum(bytes, skip)
}
fn inspect(file: FileId, page: u64, bytes: &[u8; PAGE_BYTES]) -> Result<(Layout, u16)> {
    let layout = layout(file, page)?;
    if bytes[..4] != layout.magic {
        return Err(invalid("page magic does not match WAL file identity"));
    }
    crate::page_checksum::validate_scheme(bytes)?;
    let stored = u32::from_le_bytes(
        bytes[layout.checksum..layout.checksum + 4]
            .try_into()
            .expect("checksum"),
    );
    if checksum(bytes, layout.checksum) != stored {
        return Err(PhobosError::new(
            ErrorCode::ChecksumMismatch,
            "page LSN checksum mismatch",
        ));
    }
    let version = u16::from_le_bytes(bytes[4..6].try_into().expect("version"));
    if !matches!(version, 1..=3) {
        return Err(invalid("unsupported page LSN format"));
    }
    if layout.has_id && u64::from_le_bytes(bytes[8..16].try_into().expect("page ID")) != page {
        return Err(invalid("page identity does not match WAL page number"));
    }
    Ok((layout, version))
}

/// Return an LSN only after validating the complete page checksum and identity.
/// A legacy page is represented by zero; a V2 page must have a positive LSN.
pub fn lsn(file: FileId, page: u64, bytes: &[u8; PAGE_BYTES]) -> Result<u64> {
    let (layout, version) = inspect(file, page, bytes)?;
    if version == 1 {
        return Ok(0);
    }
    let lsn = u64::from_le_bytes(
        bytes[layout.lsn..layout.lsn + 8]
            .try_into()
            .expect("page LSN"),
    );
    if lsn == 0 {
        return Err(invalid("V2 page has zero LSN"));
    }
    Ok(lsn)
}

/// Upgrade/stamp a valid image before encoding its WAL record. The resulting
/// bytes, including version and checksum, must also be the installed image.
pub fn stamp(file: FileId, page: u64, bytes: &mut [u8; PAGE_BYTES], lsn: u64) -> Result<()> {
    if lsn == 0 {
        return Err(invalid("cannot stamp a zero page LSN"));
    }
    let (layout, version) = inspect(file, page, bytes)?;
    bytes[4..6].copy_from_slice(&version.max(2).to_le_bytes());
    bytes[layout.lsn..layout.lsn + 8].copy_from_slice(&lsn.to_le_bytes());
    bytes[7] = crate::page_checksum::CRC32C;
    let crc = checksum(bytes, layout.checksum);
    bytes[layout.checksum..layout.checksum + 4].copy_from_slice(&crc.to_le_bytes());
    Ok(())
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}

/// 0.2-D: offsets of the fields `stamp` rewrites (page LSN, embedded checksum).
/// Byte 7 (checksum scheme) is the third stamped field.
pub fn stamped_fields(file: FileId, page: u64) -> Result<(usize, usize)> {
    let layout = layout(file, page)?;
    Ok((layout.lsn, layout.checksum))
}

/// 0.2-G: the embedded page LSN, as stored (not validated; header magic
/// checked). Callers that need a validated LSN use `lsn`.
pub fn stored_lsn(file: FileId, page: u64, bytes: &[u8; PAGE_BYTES]) -> Result<u64> {
    let layout = layout(file, page)?;
    if bytes[..4] != layout.magic {
        return Err(invalid("page magic does not match WAL file identity"));
    }
    Ok(u64::from_le_bytes(
        bytes[layout.lsn..layout.lsn + 8]
            .try_into()
            .expect("page LSN"),
    ))
}

/// 0.2-D: the embedded page checksum value, as stored (not validated).
pub fn stored_checksum(file: FileId, page: u64, bytes: &[u8; PAGE_BYTES]) -> Result<u32> {
    let layout = layout(file, page)?;
    Ok(u32::from_le_bytes(
        bytes[layout.checksum..layout.checksum + 4]
            .try_into()
            .expect("checksum"),
    ))
}

/// 0.2-D compact redo: after delta ops reproduced an image's content, write
/// the same three stamped fields `stamp` writes (scheme byte, LSN, checksum).
/// The stored checksum is stale by construction, so it is not validated here;
/// the caller compares the recomputed checksum with the logged one and then
/// validates the complete page with `lsn`.
pub fn restamp(file: FileId, page: u64, bytes: &mut [u8; PAGE_BYTES], lsn: u64) -> Result<u32> {
    if lsn == 0 {
        return Err(invalid("cannot stamp a zero page LSN"));
    }
    let layout = layout(file, page)?;
    if bytes[..4] != layout.magic {
        return Err(invalid("page magic does not match WAL file identity"));
    }
    let version = u16::from_le_bytes(bytes[4..6].try_into().expect("version"));
    if !matches!(version, 2..=3) {
        return Err(invalid("compact redo requires an LSN page format"));
    }
    if layout.has_id && u64::from_le_bytes(bytes[8..16].try_into().expect("page ID")) != page {
        return Err(invalid("page identity does not match WAL page number"));
    }
    bytes[layout.lsn..layout.lsn + 8].copy_from_slice(&lsn.to_le_bytes());
    bytes[7] = crate::page_checksum::CRC32C;
    let crc = checksum(bytes, layout.checksum);
    bytes[layout.checksum..layout.checksum + 4].copy_from_slice(&crc.to_le_bytes());
    Ok(crc)
}

/// Validate the database capability separately from the physical page codec.
pub fn validate_capability(capability: u16, file: FileId, bytes: &[u8; PAGE_BYTES]) -> Result<()> {
    let version = u16::from_le_bytes([bytes[4], bytes[5]]);
    if matches!(file, FileId::Heap(_)) && ((capability == 4) != (version == 3)) {
        return Err(invalid(
            "heap tuple format does not match database capability",
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn versioned_heap_stamp_preserves_format_and_requires_capability_four() {
        let file = FileId::Heap(1);
        let mut image = legacy(file, 0);
        assert!(validate_capability(4, file, &image).is_err());
        image[4..6].copy_from_slice(&3u16.to_le_bytes());
        let crc = checksum(&image, 32);
        image[32..36].copy_from_slice(&crc.to_le_bytes());
        assert!(validate_capability(3, file, &image).is_err());
        validate_capability(4, file, &image).unwrap();
        stamp(file, 0, &mut image, 19).unwrap();
        assert_eq!(&image[4..6], &3u16.to_le_bytes());
        assert_eq!(lsn(file, 0, &image).unwrap(), 19);
        image[100] ^= 1;
        assert!(lsn(file, 0, &image).is_err());
    }
    pub(super) fn legacy(file: FileId, page: u64) -> [u8; PAGE_BYTES] {
        let layout = layout(file, page).unwrap();
        let mut bytes = [0; PAGE_BYTES];
        bytes[..4].copy_from_slice(&layout.magic);
        bytes[4..6].copy_from_slice(&1u16.to_le_bytes());
        if layout.has_id {
            bytes[8..16].copy_from_slice(&page.to_le_bytes());
        }
        let crc = checksum(&bytes, layout.checksum);
        bytes[layout.checksum..layout.checksum + 4].copy_from_slice(&crc.to_le_bytes());
        bytes
    }
    #[test]
    fn heap_index_meta_and_node_lsns_require_full_checksums_and_identity() {
        for (file, page) in [
            (FileId::Heap(1), 3),
            (FileId::Index(2), 0),
            (FileId::Index(2), 3),
        ] {
            let mut bytes = legacy(file, page);
            assert_eq!(lsn(file, page, &bytes).unwrap(), 0);
            let original = bytes;
            assert!(stamp(file, page, &mut bytes, 0).is_err());
            assert_eq!(bytes, original);
            stamp(file, page, &mut bytes, 17).unwrap();
            assert_eq!(&bytes[4..6], &2u16.to_le_bytes());
            assert_eq!(lsn(file, page, &bytes).unwrap(), 17);
            if page != 0 {
                assert!(lsn(file, page + 1, &bytes).is_err());
            }
            bytes[layout(file, page).unwrap().lsn] ^= 0xff;
            assert_eq!(
                lsn(file, page, &bytes).unwrap_err().code,
                ErrorCode::ChecksumMismatch
            );
        }
    }
}
