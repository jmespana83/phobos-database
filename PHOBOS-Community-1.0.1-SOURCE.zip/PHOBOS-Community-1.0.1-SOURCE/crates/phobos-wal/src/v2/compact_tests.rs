//! 0.2-D compact redo: writer FPI policy, idempotent delta redo, torn pages,
//! segment-scoped bases, mixed record generations and fail-closed recovery.
use super::{Body, FileId, PageAction, Wal, redo, visit_validated};
use crate::page_checksum;
use std::{
    collections::BTreeMap,
    fs,
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
};

const PAGE: usize = 8192;
const HEAP: FileId = FileId::Heap(1);
const INDEX: FileId = FileId::Index(2);

fn directory() -> PathBuf {
    static NEXT: AtomicU64 = AtomicU64::new(0);
    std::env::temp_dir().join(format!(
        "phobos-v3-compact-{}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ))
}

/// A valid, unstamped version-2 page: heap (`PHOP`), index node (`PHIN`) or
/// index metadata (`PHIX`, page 0), body filled from `entries` (offset, bytes).
fn page_image(file: FileId, page: u64, entries: &[(usize, Vec<u8>)]) -> [u8; PAGE] {
    let mut bytes = [0; PAGE];
    let (magic, checksum) = match file {
        FileId::Heap(_) => (b"PHOP", 32),
        FileId::Index(_) if page == 0 => (b"PHIX", 28),
        _ => (b"PHIN", 36),
    };
    bytes[..4].copy_from_slice(magic);
    bytes[4..6].copy_from_slice(&2u16.to_le_bytes());
    bytes[7] = page_checksum::CRC32C;
    if !(matches!(file, FileId::Index(_)) && page == 0) {
        bytes[8..16].copy_from_slice(&page.to_le_bytes());
    }
    for (offset, data) in entries {
        bytes[*offset..*offset + data.len()].copy_from_slice(data);
    }
    let crc = page_checksum::checksum(&bytes, checksum);
    bytes[checksum..checksum + 4].copy_from_slice(&crc.to_le_bytes());
    bytes
}

/// A packed "leaf": entries of `width` bytes from offset 64, like a B+tree
/// leaf (inserts in the middle shift the tail).
fn leaf(file: FileId, page: u64, keys: &[u32], width: usize) -> [u8; PAGE] {
    let entries: Vec<_> = keys
        .iter()
        .enumerate()
        .map(|(i, key)| {
            let mut entry = vec![0xe0; width];
            entry[..4].copy_from_slice(&key.to_be_bytes());
            entry[width - 1] = (*key % 251) as u8 + 1;
            (64 + i * width, entry)
        })
        .collect();
    page_image(file, page, &entries)
}

/// Placeholder for the index metadata page in page lists.
const META: (FileId, u64, [u8; PAGE]) = (INDEX, 0, [0; PAGE]);
fn meta_or(entry: (FileId, u64, [u8; PAGE])) -> (FileId, u64, [u8; PAGE]) {
    if entry.0 == INDEX && entry.1 == 0 && entry.2 == [0; PAGE] {
        (INDEX, 0, page_image(INDEX, 0, &[(40, vec![7; 8])]))
    } else {
        entry
    }
}

/// The storage-side contract: logged images are the images later used as bases.
struct Model {
    dir: PathBuf,
    wal: Wal,
    current: BTreeMap<(FileId, u64), [u8; PAGE]>,
}
impl Model {
    fn new(dir: &Path) -> Self {
        let mut wal = Wal::create_with_page_lsn(dir).unwrap();
        wal.begin().unwrap();
        for file in [HEAP, INDEX] {
            wal.append(Body::Create(file)).unwrap();
        }
        wal.commit().unwrap();
        Self {
            dir: dir.to_path_buf(),
            wal,
            current: BTreeMap::new(),
        }
    }
    /// One committed transaction changing `pages`; returns record kinds.
    fn commit(&mut self, pages: Vec<(FileId, u64, [u8; PAGE])>) -> Vec<&'static str> {
        self.wal.begin().unwrap();
        let mut kinds = Vec::new();
        for (file, page, mut image) in pages {
            let base = self.current.get(&(file, page)).copied();
            let action = match (file, base.is_some()) {
                (_, false) => PageAction::Initialize,
                (FileId::Heap(_), true) => PageAction::HeapUpdate,
                _ => PageAction::Index,
            };
            self.wal.stamp_next_page(file, page, &mut image).unwrap();
            let lsn = self
                .wal
                .append_prepared_page_with_base(action, file, page, &image, base.as_ref())
                .unwrap();
            kinds.push(lsn);
            self.current.insert((file, page), image);
        }
        self.wal.commit().unwrap();
        record_kinds(&self.dir, &kinds)
    }
}

/// Kinds of written (flushed) records, read back through full validation.
fn record_kinds(dir: &Path, lsns: &[u64]) -> Vec<&'static str> {
    let mut kinds = BTreeMap::new();
    visit_validated(dir.join("phobos.wal"), |_, record| {
        kinds.insert(
            record.lsn,
            match record.body {
                Body::PageDelta { .. } => "delta",
                Body::Page { .. } => "image",
                _ => "other",
            },
        );
        Ok(())
    })
    .unwrap();
    lsns.iter()
        .map(|lsn| kinds.get(lsn).copied().unwrap_or("missing"))
        .collect()
}

fn read_page(dir: &Path, file: FileId, page: u64) -> Option<[u8; PAGE]> {
    let mut handle = fs::File::open(dir.join(file.name())).ok()?;
    let mut bytes = [0; PAGE];
    handle.seek(SeekFrom::Start(page * PAGE as u64)).ok()?;
    handle.read_exact(&mut bytes).ok()?;
    Some(bytes)
}
fn write_page(dir: &Path, file: FileId, page: u64, bytes: &[u8]) {
    let mut handle = fs::OpenOptions::new()
        .write(true)
        .open(dir.join(file.name()))
        .unwrap();
    handle.seek(SeekFrom::Start(page * PAGE as u64)).unwrap();
    handle.write_all(bytes).unwrap();
}
fn assert_matches_model(dir: &Path, model: &BTreeMap<(FileId, u64), [u8; PAGE]>) {
    for ((file, page), image) in model {
        assert_eq!(
            read_page(dir, *file, *page).as_ref().map(|b| &b[..]),
            Some(&image[..]),
            "{} page {page}",
            file.name()
        );
    }
}
fn counts(dir: &Path) -> (usize, usize) {
    let (mut deltas, mut images) = (0, 0);
    visit_validated(dir.join("phobos.wal"), |_, record| {
        match record.body {
            Body::PageDelta { .. } => deltas += 1,
            Body::Page { .. } => images += 1,
            _ => {}
        }
        Ok(())
    })
    .unwrap();
    (deltas, images)
}

/// Heap insert/update/delete and index insert/delete histories, with the
/// segment's first touch of every page a full image and later ones deltas.
fn workload(model: &mut Model) {
    let tuple = |n: u8| vec![n; 40 + usize::from(n % 7)];
    let mut heap: Vec<(usize, Vec<u8>)> = vec![(40, vec![1, 2, 3, 4])];
    let mut keys: Vec<u32> = (0..60).map(|k| k * 10).collect();
    // First touch: full images (heap page 0, index meta 0, leaf 1).
    let kinds = model.commit(vec![
        (HEAP, 0, page_image(HEAP, 0, &heap)),
        (INDEX, 0, page_image(INDEX, 0, &[(40, vec![7; 8])])),
        (INDEX, 1, leaf(INDEX, 1, &keys, 24)),
    ]);
    assert_eq!(kinds, ["image", "image", "image"]);
    for round in 0..12u8 {
        // heap insert: a slot plus a tuple at the end of the page.
        heap.push((40 + 4 * (usize::from(round) + 1), vec![round, 0xaa, 0, 1]));
        heap.push((7000 - 60 * usize::from(round), tuple(round)));
        // index insert in the middle (shifts the tail) and an append.
        let key = 5 + 10 * u32::from(round) * 3;
        let at = keys.partition_point(|k| *k < key);
        keys.insert(at, key);
        keys.push(10_000 + u32::from(round));
        let kinds = model.commit(vec![
            (HEAP, 0, page_image(HEAP, 0, &heap)),
            (INDEX, 1, leaf(INDEX, 1, &keys, 24)),
        ]);
        assert_eq!(kinds, ["delta", "delta"], "insert round {round}");
        // heap update (version metadata rewrite) and delete (tombstone).
        heap[1].1[0] = round.wrapping_mul(3);
        if round % 3 == 2 {
            let last = heap.len() - 1;
            heap[last].1.fill(0);
            keys.remove(at / 2 + 1);
        }
        let kinds = model.commit(vec![
            (HEAP, 0, page_image(HEAP, 0, &heap)),
            (INDEX, 1, leaf(INDEX, 1, &keys, 24)),
        ]);
        assert_eq!(kinds, ["delta", "delta"], "update/delete round {round}");
    }
    // A leaf split: the left half shrinks (delta), a new right sibling (image),
    // and the parent/meta gains a separator (delta).
    let (left, right) = keys.split_at(keys.len() / 2);
    let kinds = model.commit(vec![
        (INDEX, 1, leaf(INDEX, 1, left, 24)),
        (INDEX, 2, leaf(INDEX, 2, right, 24)),
        (
            INDEX,
            0,
            page_image(
                INDEX,
                0,
                &[(40, vec![7; 8]), (48, right[0].to_be_bytes().to_vec())],
            ),
        ),
    ]);
    assert_eq!(kinds[1], "image");
    assert_eq!(kinds[2], "delta");
}

#[test]
fn delta_redo_reproduces_every_image_and_is_idempotent() {
    // 0.2-D file-layout test (EOF = end of log): Mode A writer.
    crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
    let dir = directory();
    let mut model = Model::new(&dir);
    workload(&mut model);
    let expected = model.current.clone();
    let (deltas, images) = counts(&dir);
    assert!(deltas >= 48, "{deltas} deltas, {images} images");
    let wal_bytes = fs::metadata(dir.join("phobos.wal")).unwrap().len();
    drop(model);
    // Nothing reached the data files: redo rebuilds everything, twice.
    for _ in 0..3 {
        redo(&dir).unwrap();
        assert_matches_model(&dir, &expected);
    }
    // The WAL is far smaller than one image per changed page.
    assert!(wal_bytes < (deltas as u64) * 2048 + (images as u64 + 4) * 8400);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn redo_from_any_intermediate_on_disk_version_and_interrupted_redo() {
    let dir = directory();
    let mut model = Model::new(&dir);
    workload(&mut model);
    let expected = model.current.clone();
    drop(model);
    redo(&dir).unwrap();
    let final_heap = read_page(&dir, HEAP, 0).unwrap();
    // Collect every logged heap image to emulate a background write of an
    // intermediate version (or a redo interrupted after some pages).
    let mut versions = Vec::new();
    {
        let mut image = [0; PAGE];
        visit_validated(dir.join("phobos.wal"), |_, record| {
            match &record.body {
                Body::Page {
                    file: HEAP,
                    page: 0,
                    image: logged,
                    ..
                } => image = **logged,
                Body::PageDelta {
                    file: HEAP,
                    page: 0,
                    ops,
                    ..
                } => {
                    super::delta::apply(&mut image, ops).unwrap();
                    super::page_format::restamp(HEAP, 0, &mut image, record.lsn).unwrap();
                }
                _ => return Ok(()),
            }
            versions.push(image);
            Ok(())
        })
        .unwrap();
    }
    assert_eq!(versions.last().unwrap(), &final_heap);
    for version in versions.iter().step_by(5) {
        write_page(&dir, HEAP, 0, version);
        // A redo interrupted before reaching the index file leaves it stale too.
        write_page(&dir, INDEX, 1, &[0; PAGE]);
        redo(&dir).unwrap();
        redo(&dir).unwrap();
        assert_matches_model(&dir, &expected);
    }
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn torn_data_page_is_repaired_from_the_segment_first_touch_image() {
    let dir = directory();
    let mut model = Model::new(&dir);
    workload(&mut model);
    let expected = model.current.clone();
    drop(model);
    redo(&dir).unwrap();
    for (file, page) in [(HEAP, 0), (INDEX, 1), (INDEX, 0)] {
        let mut torn = read_page(&dir, file, page).unwrap();
        // Second half from a different version (here: garbage): checksum fails.
        torn[4096..].fill(0x5a);
        write_page(&dir, file, page, &torn);
        assert!(super::page_format::lsn(file, page, &torn).is_err());
        // Detected and repaired (first record of this page is a full image).
        redo(&dir).unwrap();
        assert_matches_model(&dir, &expected);
    }
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn rotation_restarts_the_chain_and_retirement_keeps_torn_pages_repairable() {
    let dir = directory();
    let mut model = Model::new(&dir);
    let keys: Vec<u32> = (0..100).collect();
    model.commit(
        [META, (INDEX, 1, leaf(INDEX, 1, &keys, 20))]
            .map(meta_or)
            .to_vec(),
    );
    let kinds = model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[1..], 20))]);
    assert_eq!(kinds, ["delta"]);
    model.wal.rotate_segment_for_test().unwrap();
    // First touch in the new segment: a full image even though a base exists.
    let kinds = model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[2..], 20))]);
    assert_eq!(kinds, ["image"]);
    let kinds = model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[3..], 20))]);
    assert_eq!(kinds, ["delta"]);
    let expected = model.current.clone();
    drop(model);
    // Emulate checkpoint retirement: the sealed segment's effects are on disk
    // (redo applies everything), then the sealed segment is deleted.
    redo(&dir).unwrap();
    let sealed: Vec<_> = fs::read_dir(&dir)
        .unwrap()
        .filter_map(|e| e.ok().map(|e| e.path()))
        .filter(|p| p.to_string_lossy().ends_with(".seg"))
        .collect();
    assert_eq!(sealed.len(), 1);
    for path in sealed {
        fs::remove_file(path).unwrap();
    }
    // The page tears later. Only the new segment remains: image + delta.
    let mut torn = read_page(&dir, INDEX, 1).unwrap();
    torn[5000..].fill(0x77);
    write_page(&dir, INDEX, 1, &torn);
    redo(&dir).unwrap();
    assert_matches_model(&dir, &expected);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn stale_or_aborted_bases_never_produce_deltas() {
    // 0.2-D file-layout test (EOF = end of log): Mode A writer.
    crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
    let dir = directory();
    let mut model = Model::new(&dir);
    let v1 = page_image(HEAP, 0, &[(40, vec![1; 30])]);
    model.commit(vec![(HEAP, 0, v1)]);
    let committed = model.current[&(HEAP, 0)];
    // An aborted chain logs the page, then aborts: its image is not a base.
    model.wal.begin().unwrap();
    let mut aborted = page_image(HEAP, 0, &[(40, vec![2; 30])]);
    model.wal.stamp_next_page(HEAP, 0, &mut aborted).unwrap();
    let lsn = model
        .wal
        .append_prepared_page_with_base(PageAction::HeapUpdate, HEAP, 0, &aborted, Some(&committed))
        .unwrap();
    model.wal.abort().unwrap();
    assert_eq!(record_kinds(&dir, &[lsn]), ["delta"]);
    let kinds = model.commit(vec![(HEAP, 0, page_image(HEAP, 0, &[(40, vec![3; 30])]))]);
    assert_eq!(kinds, ["image"], "abort must forget the page chain");
    let current = model.current[&(HEAP, 0)];
    model.wal.begin().unwrap();
    // A stale base (older committed version) is rejected: full image.
    let mut next = page_image(HEAP, 0, &[(40, vec![4; 30])]);
    model.wal.stamp_next_page(HEAP, 0, &mut next).unwrap();
    let stale = model
        .wal
        .append_prepared_page_with_base(PageAction::HeapUpdate, HEAP, 0, &next, Some(&committed))
        .unwrap();
    // A corrupted base carrying the right LSN is rejected too.
    let mut corrupt = next;
    corrupt[4000] ^= 1;
    let mut after = page_image(HEAP, 0, &[(40, vec![5; 30])]);
    model.wal.stamp_next_page(HEAP, 0, &mut after).unwrap();
    let corrupted = model
        .wal
        .append_prepared_page_with_base(PageAction::HeapUpdate, HEAP, 0, &after, Some(&corrupt))
        .unwrap();
    // The exact last image is accepted.
    let mut last = page_image(HEAP, 0, &[(40, vec![6; 30])]);
    model.wal.stamp_next_page(HEAP, 0, &mut last).unwrap();
    let exact = model
        .wal
        .append_prepared_page_with_base(PageAction::HeapUpdate, HEAP, 0, &last, Some(&after))
        .unwrap();
    model.wal.commit().unwrap();
    assert_eq!(
        record_kinds(&dir, &[stale, corrupted, exact]),
        ["image", "image", "delta"]
    );
    let _ = current;
    // A delta can only come from the writer's own decision.
    model.wal.begin().unwrap();
    assert!(
        model
            .wal
            .append(Body::PageDelta {
                action: PageAction::HeapUpdate,
                file: HEAP,
                page: 0,
                base_lsn: 1,
                base_checksum: 0,
                result_checksum: 0,
                ops: Vec::new(),
            })
            .is_err()
    );
    drop(model);
    fs::remove_dir_all(dir).unwrap();
}

/// Turn the image transaction into an aborted one: the page's only committed
/// record is then a delta. Without its exact base on disk, recovery must fail
/// closed (torn, foreign or missing base), never guess.
#[test]
fn delta_without_valid_base_fails_recovery_closed() {
    let dir = directory();
    let mut model = Model::new(&dir);
    let keys: Vec<u32> = (0..50).collect();
    model.commit(
        [META, (INDEX, 1, leaf(INDEX, 1, &keys, 20))]
            .map(meta_or)
            .to_vec(),
    );
    let base_image = model.current[&(INDEX, 1)];
    model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[1..], 20))]);
    let expected = model.current.clone();
    drop(model);
    let mut records = Vec::new();
    visit_validated(dir.join("phobos.wal"), |_, record| {
        records.push(record.clone());
        Ok(())
    })
    .unwrap();
    let image_txn = records
        .iter()
        .find(|r| matches!(r.body, Body::Page { page: 1, .. }))
        .unwrap()
        .txn_id;
    let mut bytes = Vec::new();
    for mut record in records {
        if record.txn_id == image_txn && matches!(record.body, Body::Commit) {
            record.body = Body::Abort;
        }
        bytes.extend(record.encode().unwrap());
    }
    fs::write(dir.join("phobos.wal"), &bytes).unwrap();
    let reset = |page: Option<&[u8; PAGE]>| {
        fs::write(dir.join(INDEX.name()), [0; PAGE]).unwrap();
        if let Some(page) = page {
            fs::OpenOptions::new()
                .append(true)
                .open(dir.join(INDEX.name()))
                .unwrap()
                .write_all(page)
                .unwrap();
        }
    };
    // Missing page (short file).
    reset(None);
    let error = redo(&dir).unwrap_err();
    assert!(error.message.contains("no valid base"), "{}", error.message);
    // Valid but foreign base (another version of the page).
    reset(Some(&expected[&(INDEX, 1)].map(|b| b)));
    let mut foreign = leaf(INDEX, 1, &keys[7..], 20);
    super::page_format::stamp(INDEX, 1, &mut foreign, 3).unwrap();
    reset(Some(&foreign));
    assert!(redo(&dir).is_err());
    // Torn base.
    let mut torn = base_image;
    torn[6000] ^= 0xff;
    reset(Some(&torn));
    assert!(redo(&dir).is_err());
    // Control: the exact base on disk lets the delta apply.
    reset(Some(&base_image));
    redo(&dir).unwrap();
    assert_eq!(read_page(&dir, INDEX, 1).unwrap(), expected[&(INDEX, 1)]);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn mixed_pre_v3_and_v3_records_replay_in_one_wal() {
    // 0.2-D file-layout test (EOF = end of log): Mode A writer.
    crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
    // A 0.2-C-style WAL: V2 anchor flag (no V3 bit), FNV and CRC32C page images.
    let dir = directory();
    let mut model = Model::new(&dir);
    let keys: Vec<u32> = (0..80).collect();
    let dense = |fill: u8| page_image(HEAP, 0, &[(16, vec![3; 16]), (40, vec![fill; 8152])]);
    model.commit(vec![
        (HEAP, 0, dense(9)),
        (INDEX, 0, page_image(INDEX, 0, &[(40, vec![7; 8])])),
        (INDEX, 1, leaf(INDEX, 1, &keys, 20)),
    ]);
    model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[3..], 20))]);
    let mut changed = dense(9);
    changed[300..340].fill(1);
    let crc = page_checksum::checksum(&changed, 32);
    changed[32..36].copy_from_slice(&crc.to_le_bytes());
    model.commit(vec![(HEAP, 0, changed)]);
    let expected = model.current.clone();
    drop(model);
    let wal = dir.join("phobos.wal");
    let mut bytes = fs::read(&wal).unwrap();
    // Downgrade the anchor to the 0.2-C flags, and the first image record of
    // the first transaction to a pre-0.2-C FNV-1a record.
    assert!(super::format::anchor_is_v3(&bytes));
    bytes[7] &= !super::format::ANCHOR_V3;
    let anchor_len = u32::from_le_bytes(bytes[8..12].try_into().unwrap()) as usize;
    let crc = super::format::record_checksum(&bytes[..anchor_len]);
    bytes[40..44].copy_from_slice(&crc.to_le_bytes());
    let mut offset = 0;
    let mut converted = 0;
    while offset < bytes.len() {
        let total = u32::from_le_bytes(bytes[offset + 8..offset + 12].try_into().unwrap()) as usize;
        if matches!(bytes[offset + 6], 2..=5 | 8) && converted == 0 {
            bytes[offset + 7] = 0;
            bytes[offset + 40..offset + 44].fill(0);
            let crc = super::super::checksum_record(&bytes[offset..offset + total]);
            bytes[offset + 40..offset + 44].copy_from_slice(&crc.to_le_bytes());
            converted += 1;
        }
        offset += total;
    }
    assert_eq!(converted, 1);
    fs::write(&wal, &bytes).unwrap();
    assert!(!super::format::anchor_is_v3(&fs::read(&wal).unwrap()));
    let (deltas, images) = counts(&dir);
    assert!(deltas >= 2 && images >= 3, "{deltas} {images}");
    for _ in 0..2 {
        redo(&dir).unwrap();
        assert_matches_model(&dir, &expected);
    }
    // Writer recovery rewrites to a V3 anchor (after replay).
    drop(Wal::recover(&dir).unwrap());
    assert!(super::format::anchor_is_v3(&fs::read(&wal).unwrap()));
    assert_matches_model(&dir, &expected);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn clean_pre_v3_wal_gets_a_v3_anchor_before_any_v3_record() {
    // 0.2-D file-layout test (EOF = end of log): Mode A writer.
    crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
    let dir = directory();
    let wal = Wal::create_with_page_lsn(&dir).unwrap();
    drop(wal);
    let path = dir.join("phobos.wal");
    let mut bytes = fs::read(&path).unwrap();
    bytes[7] &= !super::format::ANCHOR_V3;
    let crc = super::format::record_checksum(&bytes);
    bytes[40..44].copy_from_slice(&crc.to_le_bytes());
    fs::write(&path, &bytes).unwrap();
    let before = super::inspect(&path).unwrap();
    let wal = Wal::open(&dir).unwrap();
    assert!(super::format::anchor_is_v3(&fs::read(&path).unwrap()));
    let after = super::inspect(&path).unwrap();
    assert_eq!(after.next_txn_id, before.next_txn_id);
    assert!(after.last_lsn > before.last_lsn);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn truncated_and_corrupted_v3_tails() {
    // 0.2-D file-layout test (EOF = end of log): Mode A writer.
    crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
    let dir = directory();
    let mut model = Model::new(&dir);
    let keys: Vec<u32> = (0..80).collect();
    model.commit(
        [META, (INDEX, 1, leaf(INDEX, 1, &keys, 20))]
            .map(meta_or)
            .to_vec(),
    );
    let committed = model.current.clone();
    // An uncommitted delta transaction is in the WAL buffer; flush it.
    model.wal.begin().unwrap();
    let mut next = leaf(INDEX, 1, &keys[5..], 20);
    model.wal.stamp_next_page(INDEX, 1, &mut next).unwrap();
    model
        .wal
        .append_prepared_page_with_base(
            PageAction::Index,
            INDEX,
            1,
            &next,
            committed.get(&(INDEX, 1)),
        )
        .unwrap();
    model.wal.commit().unwrap();
    drop(model);
    let path = dir.join("phobos.wal");
    let full = fs::read(&path).unwrap();
    // Find the final (delta) transaction's commit: truncate inside the
    // transaction at every byte. The committed prefix always replays.
    let mut offsets = Vec::new();
    let mut offset = 0;
    while offset < full.len() {
        offsets.push(offset);
        offset += u32::from_le_bytes(full[offset + 8..offset + 12].try_into().unwrap()) as usize;
    }
    let delta_at = *offsets
        .iter()
        .find(|o| full[**o + 6] == super::format::KIND_PAGE_DELTA)
        .unwrap();
    for end in (delta_at..full.len() - 1).step_by(7) {
        fs::write(&path, &full[..end]).unwrap();
        let _ = fs::remove_file(dir.join(INDEX.name()));
        fs::write(dir.join(INDEX.name()), []).unwrap();
        redo(&dir).unwrap();
        assert_matches_model(&dir, &committed);
    }
    // A corrupted byte inside a complete, non-final V3 record is not a torn
    // tail: preflight refuses before any data-file effect.
    let mut corrupt = full.clone();
    corrupt[delta_at + 60] ^= 1;
    fs::write(&path, &corrupt).unwrap();
    fs::write(dir.join(INDEX.name()), []).unwrap();
    assert!(redo(&dir).is_err());
    assert_eq!(fs::metadata(dir.join(INDEX.name())).unwrap().len(), 0);
    fs::remove_dir_all(dir).unwrap();
}

/// Targeted test 12: a crash inside a segment rotation, after the active WAL
/// was renamed to a sealed segment and before the new active file held a
/// complete anchor. Read-only inspection already sees the sealed segment as
/// the end of the log; writer recovery restores it as the active WAL, redoes
/// every committed change (images and deltas) and is repeatable.
#[test]
fn crash_inside_segment_rotation_is_recovered() {
    for partial in [None, Some(0usize), Some(30), Some(60)] {
        let dir = directory();
        let mut model = Model::new(&dir);
        let keys: Vec<u32> = (0..90).collect();
        model.commit(
            [META, (INDEX, 1, leaf(INDEX, 1, &keys, 20))]
                .map(meta_or)
                .to_vec(),
        );
        model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[2..], 20))]);
        model.wal.rotate_segment_for_test().unwrap();
        model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[4..], 20))]);
        let kinds = model.commit(vec![(INDEX, 1, leaf(INDEX, 1, &keys[5..], 20))]);
        assert_eq!(kinds, ["delta"]);
        let expected = model.current.clone();
        drop(model);
        // Emulate the interrupted second rotation: rename done, new file
        // missing, empty, a torn anchor prefix, or 60 zero bytes.
        let active = dir.join("phobos.wal");
        let anchor = fs::read(&active).unwrap();
        let lsn = u64::from_le_bytes(anchor[20..28].try_into().unwrap());
        fs::rename(&active, dir.join(format!("phobos.wal.{lsn:016x}.seg"))).unwrap();
        match partial {
            None => {}
            Some(60) => fs::write(&active, [0; 60]).unwrap(),
            Some(n) => fs::write(&active, &anchor[..n]).unwrap(),
        }
        let report = super::inspect(&active).unwrap();
        assert_eq!(report.committed_transactions, 5);
        for _ in 0..2 {
            drop(Wal::recover(&dir).unwrap());
            assert_matches_model(&dir, &expected);
            assert!(super::format::anchor_is_v3(&fs::read(&active).unwrap()));
        }
        fs::remove_dir_all(dir).unwrap();
    }
}
