//! 0.2-E: preallocated write-through WAL — zero-tail recovery, fault
//! injection, segment lifecycle and 0.2-D compatibility (Part O).
use super::format::{ANCHOR_PREALLOC, ANCHOR_V3, HEADER_LEN};
use super::log::{DurabilityMode, set_thread_mode_for_test, test_short_write};
use super::scan::{ANCHOR_RECORD_LEN, TORN_WINDOW};
use super::{Tail, Wal, inspect};
use std::fs;
use std::path::{Path, PathBuf};

const EXTENT: u64 = 4 * 1024 * 1024;

fn directory() -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    std::env::temp_dir().join(format!(
        "phobos-v2e-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
    ))
}
fn e() {
    set_thread_mode_for_test(Some(DurabilityMode::WriteThrough));
}
fn wal_path(dir: &Path) -> PathBuf {
    dir.join("phobos.wal")
}
/// Commit `n` empty transactions through the out-of-lock force protocol.
fn commit_n(wal: &mut Wal, n: usize) {
    for _ in 0..n {
        wal.begin().unwrap();
        let ticket = wal.append_commit().unwrap();
        let intent = wal.begin_force().unwrap().expect("bytes to force");
        let result = intent.sync();
        wal.complete_force(intent, result).unwrap();
        assert_eq!(wal.receipts_for(&[ticket]).unwrap().len(), 1);
    }
}
fn committed(dir: &Path) -> u64 {
    inspect(wal_path(dir)).unwrap().committed_transactions
}
fn valid_len(dir: &Path) -> u64 {
    super::scan::inspect_file(&wal_path(dir), true)
        .unwrap()
        .valid_len
}
fn patch(dir: &Path, offset: u64, bytes: &[u8]) {
    patch_file(&wal_path(dir), offset, bytes);
}
fn patch_file(path: &Path, offset: u64, bytes: &[u8]) {
    use std::io::{Seek, SeekFrom, Write};
    let mut file = fs::OpenOptions::new().write(true).open(path).unwrap();
    file.seek(SeekFrom::Start(offset)).unwrap();
    file.write_all(bytes).unwrap();
}

#[test]
fn e_creates_preallocated_anchor_and_zero_extent() {
    e();
    let dir = directory();
    let wal = Wal::create(&dir).unwrap();
    assert_eq!(wal.durability_mode(), DurabilityMode::WriteThrough);
    drop(wal);
    let bytes = fs::read(wal_path(&dir)).unwrap();
    assert_eq!(bytes.len() as u64, EXTENT);
    assert_ne!(bytes[7] & ANCHOR_PREALLOC, 0);
    assert_ne!(bytes[7] & ANCHOR_V3, 0);
    assert!(bytes[ANCHOR_RECORD_LEN as usize..].iter().all(|b| *b == 0));
    // 0.2-D's anchor rule (flags & 0xe0 == 0) rejects this header.
    assert_ne!(bytes[7] & 0xe0, 0);
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(report.tail, Tail::Clean);
    assert_eq!(report.valid_len, ANCHOR_RECORD_LEN);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn stage_a_performs_no_io_and_the_force_write_is_the_durable_event() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    wal.begin().unwrap();
    let ticket = wal.append_commit().unwrap();
    // Appended, not written: a crash now loses only this unacknowledged commit.
    assert_eq!(valid_len(&dir), ANCHOR_RECORD_LEN);
    assert!(wal.receipts_for(&[]).unwrap().is_empty());
    let intent = wal.begin_force().unwrap().unwrap();
    assert!(intent.write_len() > 0);
    // A second reservation while one is in flight is refused (single flight).
    assert!(wal.begin_force().is_err());
    let result = intent.sync();
    wal.complete_force(intent, result).unwrap();
    assert!(wal.durable_lsn() >= ticket.lsn());
    assert_eq!(wal.receipts_for(&[ticket]).unwrap().len(), 1);
    drop(wal);
    assert_eq!(committed(&dir), 1);
    let wal = Wal::recover(&dir).unwrap();
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn receipts_are_refused_until_the_write_completes() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    wal.begin().unwrap();
    let ticket = wal.append_commit().unwrap();
    let intent = wal.begin_force().unwrap().unwrap();
    // Reserved but not written: no receipt.
    assert!(wal.receipts_for(std::slice::from_ref(&ticket)).is_err());
    let result = intent.sync();
    wal.complete_force(intent, result).unwrap();
    assert_eq!(wal.receipts_for(&[ticket]).unwrap().len(), 1);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn in_lock_durable_advance_while_a_range_is_in_flight() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    wal.begin().unwrap();
    let first = wal.append_commit().unwrap();
    let intent = wal.begin_force().unwrap().unwrap();
    // More records after the reservation, then an in-lock durable advance
    // (synchronous path) rewrites the in-flight bytes and its own.
    wal.begin().unwrap();
    wal.sync_for_test().unwrap();
    // The late completion of the old range must not move anything back.
    let result = intent.sync();
    wal.complete_force(intent, result).unwrap();
    assert_eq!(wal.receipts_for(&[first]).unwrap().len(), 1);
    let second = wal.append_commit().unwrap();
    let intent = wal.begin_force().unwrap().unwrap();
    let result = intent.sync();
    wal.complete_force(intent, result).unwrap();
    assert_eq!(wal.receipts_for(&[second]).unwrap().len(), 1);
    drop(wal);
    assert_eq!(committed(&dir), 2);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o1_o3_short_write_fences_without_receipt_and_recovers_the_prefix() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    commit_n(&mut wal, 3);
    wal.begin().unwrap();
    let ticket = wal.append_commit().unwrap();
    let intent = wal.begin_force().unwrap().unwrap();
    // Only 30 bytes reach the file, then the write fails (e.g. disk full).
    test_short_write::arm(30);
    let result = intent.sync();
    assert!(result.is_err());
    assert!(wal.complete_force(intent, result).is_err());
    assert!(wal.is_fenced());
    assert!(wal.receipts_for(&[ticket]).is_err());
    drop(wal);
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(report.tail, Tail::PartialRecord);
    assert_eq!(report.committed_transactions, 3);
    // Recovery keeps exactly the acknowledged prefix and rewrites the WAL.
    drop(Wal::recover(&dir).unwrap());
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(report.tail, Tail::Clean);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o2_o4_failed_write_fences_every_pending_commit() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    commit_n(&mut wal, 1);
    let before = wal.durable_lsn();
    wal.begin().unwrap();
    let first = wal.append_commit().unwrap();
    wal.begin().unwrap();
    let second = wal.append_commit().unwrap();
    wal.fail_next_force_for_test();
    let intent = wal.begin_force().unwrap().unwrap();
    let result = intent.sync();
    assert!(wal.complete_force(intent, result).is_err());
    assert_eq!(wal.durable_lsn(), before);
    assert!(wal.receipts_for(&[first, second]).is_err());
    assert!(wal.begin().is_err());
    drop(wal);
    assert_eq!(committed(&dir), 1);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o5_torn_final_record_is_a_torn_tail() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    commit_n(&mut wal, 4);
    drop(wal);
    let end = valid_len(&dir);
    let bytes = fs::read(wal_path(&dir)).unwrap();
    // Half of the last record lost (zeros): the last commit disappears.
    let mut half = bytes[..end as usize].to_vec();
    let cut = end as usize - 20;
    half[cut..].fill(0);
    patch(&dir, 0, &half);
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(report.tail, Tail::PartialRecord);
    assert_eq!(report.committed_transactions, 3);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o6_o7_zero_tail_is_clean_and_nonzero_tail_is_bounded() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    commit_n(&mut wal, 2);
    drop(wal);
    let end = valid_len(&dir);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    // Garbage inside the torn window: a torn final write, tolerated.
    patch(&dir, end + 1000, &[0xab; 16]);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::PartialRecord);
    assert_eq!(committed(&dir), 2);
    patch(&dir, end + 1000, &[0; 16]);
    // Non-zero bytes beyond the window: corruption, never "end of WAL".
    patch(&dir, end + TORN_WINDOW + 10, &[1]);
    assert!(inspect(wal_path(&dir)).is_err());
    assert!(Wal::recover(&dir).is_err());
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o8_corruption_inside_the_committed_prefix_is_a_hard_error() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    // Enough committed WAL that the damaged record is followed by more than
    // one torn window of valid records.
    let mut n = 0;
    while valid_len(&dir) < ANCHOR_RECORD_LEN + TORN_WINDOW + 4096 {
        commit_n(&mut wal, 200);
        n += 200;
    }
    drop(wal);
    assert_eq!(committed(&dir), n);
    let bytes = fs::read(wal_path(&dir)).unwrap();
    let target = ANCHOR_RECORD_LEN as usize + HEADER_LEN + 2;
    patch(&dir, target as u64, &[bytes[target] ^ 0x40]);
    let error = inspect(wal_path(&dir)).unwrap_err();
    assert!(
        error.message.contains("torn-write window"),
        "{}",
        error.message
    );
    assert!(Wal::recover(&dir).is_err());
    // Nothing was modified by the failed recovery.
    let after = fs::read(wal_path(&dir)).unwrap();
    assert_eq!(after.len(), bytes.len());
    assert_eq!(after[target], bytes[target] ^ 0x40);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o9_leftover_preallocated_temporary_is_discarded() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    commit_n(&mut wal, 2);
    drop(wal);
    // Crash while/after preallocating a new file under the temporary name.
    fs::write(dir.join("phobos.wal.v2-checkpoint.tmp"), vec![0u8; 1 << 20]).unwrap();
    drop(Wal::recover(&dir).unwrap());
    assert!(!dir.join("phobos.wal.v2-checkpoint.tmp").exists());
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o10_o11_crash_before_and_during_the_first_transaction() {
    e();
    let dir = directory();
    let wal = Wal::create(&dir).unwrap();
    drop(wal);
    // Anchor + zeros only.
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(
        (report.tail, report.committed_transactions),
        (Tail::Clean, 0)
    );
    let mut wal = Wal::recover(&dir).unwrap();
    // First transaction appended and partly written, then a crash.
    wal.begin().unwrap();
    wal.sync_for_test().unwrap();
    let _ = wal.append_commit().unwrap();
    drop(wal);
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(report.committed_transactions, 0);
    assert_eq!(report.incomplete_transactions, 1);
    drop(Wal::recover(&dir).unwrap());
    let report = inspect(wal_path(&dir)).unwrap();
    assert_eq!(report.incomplete_transactions, 0);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o12_o15_rotation_crash_states_and_preallocated_segments() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    commit_n(&mut wal, 3);
    wal.rotate_segment_for_test().unwrap();
    commit_n(&mut wal, 2);
    drop(wal);
    // Old sealed (preallocated, zero tail) + new active (preallocated).
    let sealed: Vec<_> = fs::read_dir(&dir)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| path.extension().is_some_and(|ext| ext == "seg"))
        .collect();
    assert_eq!(sealed.len(), 1);
    assert_eq!(fs::metadata(&sealed[0]).unwrap().len(), EXTENT);
    assert_eq!(committed(&dir), 5);
    // O15: a sealed segment's tail must be all zero.
    patch_file(&sealed[0], EXTENT - 1, &[7]);
    assert!(inspect(wal_path(&dir)).is_err());
    patch_file(&sealed[0], EXTENT - 1, &[0]);
    // O12/O13: crash between the two rotation renames — no active file.
    let copy = directory();
    fs::create_dir_all(&copy).unwrap();
    for entry in fs::read_dir(&dir).unwrap() {
        let entry = entry.unwrap();
        fs::copy(entry.path(), copy.join(entry.file_name())).unwrap();
    }
    fs::remove_file(wal_path(&copy)).unwrap();
    drop(Wal::recover(&copy).unwrap());
    assert!(inspect(wal_path(&copy)).unwrap().last_lsn > 0);
    // O14: an all-zero active file (never received an anchor) is repaired too.
    let zero = directory();
    fs::create_dir_all(&zero).unwrap();
    for entry in fs::read_dir(&dir).unwrap() {
        let entry = entry.unwrap();
        fs::copy(entry.path(), zero.join(entry.file_name())).unwrap();
    }
    fs::write(wal_path(&zero), vec![0u8; EXTENT as usize]).unwrap();
    drop(Wal::recover(&zero).unwrap());
    // O16: recovery twice is idempotent.
    drop(Wal::recover(&dir).unwrap());
    let first = inspect(wal_path(&dir)).unwrap();
    drop(Wal::recover(&dir).unwrap());
    let second = inspect(wal_path(&dir)).unwrap();
    assert_eq!(first.next_txn_id, second.next_txn_id);
    for path in [dir, copy, zero] {
        fs::remove_dir_all(path).unwrap();
    }
}

#[test]
fn capacity_grows_by_flushed_zero_extents() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    while valid_len(&dir) < EXTENT + 1024 {
        commit_n(&mut wal, 500);
    }
    drop(wal);
    let length = fs::metadata(wal_path(&dir)).unwrap().len();
    assert_eq!(length % EXTENT, 0);
    assert!(length >= 2 * EXTENT);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn o17_o18_mode_switch_rewrites_the_anchor_format_in_both_directions() {
    // A 0.2-D-format (Mode A) WAL with committed work, crashed.
    set_thread_mode_for_test(Some(DurabilityMode::Flush));
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    for _ in 0..3 {
        wal.begin().unwrap();
        let ticket = wal.append_commit().unwrap();
        wal.force_commits(&[ticket]).unwrap();
    }
    drop(wal);
    let bytes = fs::read(wal_path(&dir)).unwrap();
    assert_eq!(bytes[7] & ANCHOR_PREALLOC, 0);
    assert_eq!(committed(&dir), 3);
    // 0.2-E (Mode E) recovers it and continues in the preallocated format.
    e();
    let mut wal = Wal::recover(&dir).unwrap();
    commit_n(&mut wal, 2);
    drop(wal);
    let bytes = fs::read(wal_path(&dir)).unwrap();
    assert_ne!(bytes[7] & ANCHOR_PREALLOC, 0);
    assert_eq!(committed(&dir), 2);
    // Back to Mode A: recovery rewrites a non-preallocated anchor.
    set_thread_mode_for_test(Some(DurabilityMode::Flush));
    drop(Wal::recover(&dir).unwrap());
    let bytes = fs::read(wal_path(&dir)).unwrap();
    assert_eq!(bytes[7] & ANCHOR_PREALLOC, 0);
    assert_eq!(bytes.len() as u64, ANCHOR_RECORD_LEN);
    fs::remove_dir_all(dir).unwrap();
}

// ---- 0.2-F Part N: background extent preparation ----

/// A valid version-2 heap page with an incompressible body.
fn heap_page(page: u64) -> [u8; 8192] {
    let mut bytes = [0u8; 8192];
    bytes[..4].copy_from_slice(b"PHOP");
    bytes[4..6].copy_from_slice(&2u16.to_le_bytes());
    bytes[7] = crate::page_checksum::CRC32C;
    bytes[8..16].copy_from_slice(&page.to_le_bytes());
    let mut x = page.wrapping_mul(0x9e37_79b9_7f4a_7c15) | 1;
    for byte in &mut bytes[64..8000] {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        *byte = x as u8;
    }
    let crc = crate::page_checksum::checksum(&bytes, 32);
    bytes[32..36].copy_from_slice(&crc.to_le_bytes());
    bytes
}
/// Commit transactions of four fresh full page images (~32 KiB each)
/// through the out-of-lock force protocol until `stop` holds.
fn commit_pages_until(wal: &mut Wal, next_page: &mut u64, mut stop: impl FnMut(&Wal) -> bool) {
    for _ in 0..2_000 {
        if stop(wal) {
            return;
        }
        wal.begin().unwrap();
        for _ in 0..4 {
            let mut image = heap_page(*next_page);
            wal.append_page(
                super::PageAction::Initialize,
                super::FileId::Heap(1),
                *next_page,
                &mut image,
            )
            .unwrap();
            *next_page += 1;
        }
        let ticket = wal.append_commit().unwrap();
        let intent = wal.begin_force().unwrap().expect("bytes to force");
        let result = intent.sync();
        wal.complete_force(intent, result).unwrap();
        assert_eq!(wal.receipts_for(&[ticket]).unwrap().len(), 1);
    }
    panic!("the condition was never reached");
}
fn extender_running(wal: &Wal) -> bool {
    wal.extension_state_for_test().2
}
fn zeros_after(dir: &Path, from: u64) -> bool {
    let bytes = fs::read(wal_path(dir)).unwrap();
    bytes[usize::try_from(from).unwrap()..]
        .iter()
        .all(|b| *b == 0)
}

#[test]
fn n1_background_extent_is_flushed_before_it_is_usable_and_avoids_foreground_growth() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    let mut page = 1;
    commit_pages_until(&mut wal, &mut page, extender_running);
    let (capacity, limit, running, _) = wal.extension_state_for_test();
    assert_eq!(
        capacity, EXTENT,
        "capacity is never advanced before the flush"
    );
    assert_eq!(limit, 2 * EXTENT);
    assert!(running);
    assert!(valid_len(&dir) <= capacity);
    wal.wait_for_extender_for_test();
    let (capacity, limit, running, _) = wal.extension_state_for_test();
    assert_eq!((capacity, limit, running), (2 * EXTENT, 2 * EXTENT, false));
    assert_eq!(fs::metadata(wal_path(&dir)).unwrap().len(), 2 * EXTENT);
    assert!(zeros_after(&dir, valid_len(&dir)));
    // Cross the old capacity and the next one: no commit-path extension.
    commit_pages_until(&mut wal, &mut page, |wal| {
        wal.extension_state_for_test().0 >= 3 * EXTENT
    });
    assert_eq!(wal.extension_state_for_test().3, 0);
    drop(wal);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    assert_eq!(fs::metadata(wal_path(&dir)).unwrap().len() % EXTENT, 0);
    assert!(valid_len(&dir) > EXTENT);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn n2_disabled_or_late_extender_falls_back_to_the_foreground_extent() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    wal.set_background_extend_for_test(false);
    let mut page = 1;
    commit_pages_until(&mut wal, &mut page, |wal| {
        wal.extension_state_for_test().0 > EXTENT
    });
    let (capacity, _, running, foreground) = wal.extension_state_for_test();
    assert_eq!(capacity, 2 * EXTENT);
    assert!(!running);
    assert_eq!(foreground, 1);
    drop(wal);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn n3_crash_during_background_preparation_is_harmless() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    let mut page = 0;
    commit_pages_until(&mut wal, &mut page, extender_running);
    wal.wait_for_extender_for_test();
    drop(wal);
    let durable = committed(&dir);
    assert!(durable > 0);
    // A crash mid-preparation leaves any zero-filled length up to the next
    // extent (unaligned, never adopted); recovery keeps every commit.
    for partial in [2 * EXTENT - 1, EXTENT + 1_234_567, EXTENT + 4096] {
        let file = fs::OpenOptions::new()
            .write(true)
            .open(wal_path(&dir))
            .unwrap();
        file.set_len(partial).unwrap();
        drop(file);
        assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
        assert_eq!(committed(&dir), durable);
    }
    // Redo target of the logged page images.
    fs::File::create(dir.join(super::FileId::Heap(1).name())).unwrap();
    let mut wal = Wal::recover(&dir).unwrap();
    commit_pages_until(&mut wal, &mut page, |wal| {
        wal.extension_state_for_test().0 >= 2 * EXTENT && !extender_running(wal)
    });
    drop(wal);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    assert!(committed(&dir) > 0);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn n4_failed_background_extension_is_rewritten_and_bounded() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    wal.set_background_extend_for_test(false);
    commit_n(&mut wal, 10);
    // A worker that wrote 1 MiB of zeros and then failed: never adopted.
    wal.simulate_failed_extension_for_test(1024 * 1024);
    assert_eq!(wal.extension_state_for_test().0, EXTENT);
    commit_n(&mut wal, 10);
    let mut page = 1;
    commit_pages_until(&mut wal, &mut page, |wal| {
        wal.extension_state_for_test().0 > EXTENT
    });
    assert_eq!(wal.extension_state_for_test().0, 2 * EXTENT);
    // Growth past the bound is still detected and fences the writer.
    let file = fs::OpenOptions::new()
        .write(true)
        .open(wal_path(&dir))
        .unwrap();
    file.set_len(3 * EXTENT + 1).unwrap();
    drop(file);
    let detected = wal.begin().is_err() || {
        wal.append_commit().unwrap();
        wal.begin_force().is_err()
    };
    assert!(detected);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn n5_rotation_and_checkpoint_wait_for_the_extender() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    let mut page = 1;
    commit_pages_until(&mut wal, &mut page, extender_running);
    wal.rotate_segment_for_test().unwrap();
    assert!(!extender_running(&wal));
    commit_n(&mut wal, 5);
    commit_pages_until(&mut wal, &mut page, extender_running);
    let applied = wal.last_commit_lsn();
    if wal.page_format() >= 3 {
        wal.checkpoint_with_visibility(applied, |_| Ok(u64::MAX))
            .unwrap();
    } else {
        wal.checkpoint_all(applied).unwrap();
    }
    assert!(!extender_running(&wal));
    assert_eq!(fs::metadata(wal_path(&dir)).unwrap().len(), EXTENT);
    commit_n(&mut wal, 5);
    drop(wal);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    for segment in super::scan::segments(&wal_path(&dir)).unwrap() {
        let report = super::scan::inspect_file(&segment.path, false).unwrap();
        assert_eq!(report.tail, Tail::Clean);
    }
    fs::remove_dir_all(dir).unwrap();
}

// ---- 0.2-G: adaptive background extension and the stamp token ----

#[test]
fn n6_extend_step_grows_when_the_commit_path_waits_and_resets_on_replacement() {
    e();
    let dir = directory();
    let mut wal = Wal::create(&dir).unwrap();
    let mut page = 1;
    assert_eq!(wal.extend_step_for_test(), EXTENT);
    // Exhaust the prepared capacity while the extender may still run: the
    // commit path waits for it (or extends itself) and the step doubles.
    // A slow device: the extender is still running when the commit path
    // needs the capacity, so it waits (step doubles) and extends itself.
    super::log::EXTENDER_DELAY_MS_FOR_TEST.store(300, std::sync::atomic::Ordering::Relaxed);
    commit_pages_until(&mut wal, &mut page, extender_running);
    let (capacity, ..) = wal.extension_state_for_test();
    wal.ensure_capacity_for_test(capacity + EXTENT + 1).unwrap();
    super::log::EXTENDER_DELAY_MS_FOR_TEST.store(0, std::sync::atomic::Ordering::Relaxed);
    let (grown, ..) = wal.extension_state_for_test();
    assert!(grown >= capacity + 2 * EXTENT);
    let step = wal.extend_step_for_test();
    assert!(step > EXTENT && step <= 8 * EXTENT, "step {step}");
    // Every adopted capacity stays a whole number of extents, flushed before use.
    wal.wait_for_extender_for_test();
    let (capacity, limit, running, _) = wal.extension_state_for_test();
    assert_eq!(capacity % EXTENT, 0);
    assert_eq!((limit, running), (capacity, false));
    assert!(valid_len(&dir) <= capacity);
    assert!(zeros_after(&dir, valid_len(&dir)));
    // Bounded at 32 MiB.
    for _ in 0..8 {
        wal.grow_extend_step_for_test();
    }
    assert_eq!(wal.extend_step_for_test(), 8 * EXTENT);
    // Replacing the active file restarts at one extent.
    wal.rotate_segment_for_test().unwrap();
    assert_eq!(wal.extend_step_for_test(), EXTENT);
    commit_n(&mut wal, 3);
    drop(wal);
    assert_eq!(inspect(wal_path(&dir)).unwrap().tail, Tail::Clean);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn n7_stamp_token_covers_only_the_stamped_image() {
    e();
    let dir = directory();
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let file = super::FileId::Heap(1);
    // The stamped image is accepted for its own record.
    wal.begin().unwrap();
    let mut image = heap_page(0);
    wal.stamp_next_page(file, 0, &mut image).unwrap();
    wal.append_prepared_page(super::PageAction::Initialize, file, 0, &image)
        .unwrap();
    let ticket = wal.append_commit().unwrap();
    let intent = wal.begin_force().unwrap().expect("bytes");
    let result = intent.sync();
    wal.complete_force(intent, result).unwrap();
    assert_eq!(wal.receipts_for(&[ticket]).unwrap().len(), 1);
    // A different page under the same LSN takes the full check and fails
    // (its embedded LSN/checksum were never stamped).
    wal.begin().unwrap();
    let mut stamped = heap_page(1);
    wal.stamp_next_page(file, 1, &mut stamped).unwrap();
    let foreign = heap_page(2);
    assert!(
        wal.append_prepared_page(super::PageAction::Initialize, file, 2, &foreign)
            .is_err()
    );
    drop(wal);
    // A stamped image whose LSN field was altered is rejected as well.
    let dir2 = directory();
    let mut wal = Wal::create_with_page_lsn(&dir2).unwrap();
    wal.begin().unwrap();
    let mut image = heap_page(0);
    wal.stamp_next_page(file, 0, &mut image).unwrap();
    image[16] ^= 1;
    assert!(
        wal.append_prepared_page(super::PageAction::Initialize, file, 0, &image)
            .is_err()
    );
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
    fs::remove_dir_all(dir2).unwrap();
}
