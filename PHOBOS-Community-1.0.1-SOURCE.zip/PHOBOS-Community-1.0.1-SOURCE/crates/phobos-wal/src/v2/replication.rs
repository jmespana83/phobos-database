//! Small durable metadata used by physical replication. It is deliberately
//! outside WAL records so existing WAL/page formats remain byte compatible.
use phobos_error::{ErrorCode, PhobosError};
use std::{
    collections::BTreeMap,
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
    sync::atomic::{AtomicU64, Ordering},
    time::{SystemTime, UNIX_EPOCH},
};

const ID_FILE: &str = "phobos.system-id";
const SLOT_FILE: &str = "phobos.replication-slots";
const ID_HEADER: &str = "PHOBOS-SYSTEM-1";
const SLOT_HEADER: &str = "PHOBOS-REPLICATION-SLOTS-1";
static NEXT_ID: AtomicU64 = AtomicU64::new(1);

type Result<T> = std::result::Result<T, PhobosError>;

pub fn ensure_system_id(directory: &Path) -> Result<String> {
    let path = directory.join(ID_FILE);
    if path.exists() {
        return read_system_id(directory);
    }
    fs::create_dir_all(directory)?;
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|_| invalid("system clock is before the Unix epoch"))?
        .as_nanos();
    let entropy = now
        ^ ((u128::from(std::process::id())) << 64)
        ^ u128::from(NEXT_ID.fetch_add(1, Ordering::Relaxed));
    let id = format!("{entropy:032x}");
    let temporary = directory.join("phobos.system-id.tmp");
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&temporary)?;
    writeln!(file, "{ID_HEADER}")?;
    writeln!(file, "{id}")?;
    file.sync_all()?;
    drop(file);
    match fs::rename(&temporary, &path) {
        Ok(()) => Ok(id),
        Err(_error) if path.exists() => {
            let _ = fs::remove_file(temporary);
            read_system_id(directory)
        }
        Err(error) => Err(error.into()),
    }
}

pub fn read_system_id(directory: &Path) -> Result<String> {
    let text = fs::read_to_string(directory.join(ID_FILE))?;
    let mut lines = text.lines();
    if lines.next() != Some(ID_HEADER) {
        return Err(invalid("invalid database system identity header"));
    }
    let id = lines.next().unwrap_or_default();
    if id.len() != 32 || !id.bytes().all(|byte| byte.is_ascii_hexdigit()) || lines.next().is_some()
    {
        return Err(invalid("invalid database system identity"));
    }
    Ok(id.to_ascii_lowercase())
}

pub fn set_replication_slot(directory: &Path, name: &str, replayed_lsn: u64) -> Result<()> {
    validate_slot(name)?;
    if replayed_lsn == 0 {
        return Err(invalid("replication slot LSN must be nonzero"));
    }
    let mut slots = read_slots(directory)?;
    slots.insert(name.to_string(), replayed_lsn);
    write_slots(directory, &slots)
}

pub fn remove_replication_slot(directory: &Path, name: &str) -> Result<bool> {
    validate_slot(name)?;
    let mut slots = read_slots(directory)?;
    let removed = slots.remove(name).is_some();
    if removed {
        write_slots(directory, &slots)?;
    }
    Ok(removed)
}

pub fn replication_retention_lsn(directory: &Path) -> Result<Option<u64>> {
    Ok(read_slots(directory)?.values().copied().min())
}

/// 0.2-I.2 diagnostics: every registered slot and the LSN it protects after.
pub fn replication_slots(directory: &Path) -> Result<Vec<(String, u64)>> {
    Ok(read_slots(directory)?.into_iter().collect())
}

fn validate_slot(name: &str) -> Result<()> {
    if name.is_empty()
        || name.len() > 63
        || !name
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-'))
    {
        return Err(invalid("invalid replication slot name"));
    }
    Ok(())
}

fn read_slots(directory: &Path) -> Result<BTreeMap<String, u64>> {
    let path = directory.join(SLOT_FILE);
    if !path.exists() {
        return Ok(BTreeMap::new());
    }
    let text = fs::read_to_string(path)?;
    let mut lines = text.lines();
    if lines.next() != Some(SLOT_HEADER) {
        return Err(invalid("invalid replication slot file header"));
    }
    let mut slots = BTreeMap::new();
    for line in lines {
        let (name, lsn) = line
            .split_once('\t')
            .ok_or_else(|| invalid("invalid replication slot record"))?;
        validate_slot(name)?;
        let lsn = lsn
            .parse::<u64>()
            .map_err(|_| invalid("invalid replication slot LSN"))?;
        if lsn == 0 || slots.insert(name.to_string(), lsn).is_some() {
            return Err(invalid("invalid or duplicate replication slot"));
        }
    }
    Ok(slots)
}

fn write_slots(directory: &Path, slots: &BTreeMap<String, u64>) -> Result<()> {
    // 0.2-I.2: retention depends on this file, so it must never be absent:
    // a unique temporary (concurrent writers) is renamed *over* the target
    // (atomic replace on POSIX and Windows); the target is never removed
    // first. The directory entry is then made durable.
    let temporary = directory.join(format!(
        "phobos.replication-slots.{}.{}.tmp",
        std::process::id(),
        NEXT_ID.fetch_add(1, Ordering::Relaxed)
    ));
    let target = directory.join(SLOT_FILE);
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&temporary)?;
    writeln!(file, "{SLOT_HEADER}")?;
    for (name, lsn) in slots {
        writeln!(file, "{name}\t{lsn}")?;
    }
    file.sync_all()?;
    drop(file);
    if let Err(error) = fs::rename(&temporary, target) {
        let _ = fs::remove_file(&temporary);
        return Err(error.into());
    }
    #[cfg(unix)]
    fs::File::open(directory)?.sync_all()?;
    Ok(())
}

fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn system_identity_and_replication_slots_are_durable_and_bounded() {
        let directory = std::env::temp_dir().join(format!(
            "phobos-g3-replication-meta-{}-{}",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        let first = ensure_system_id(&directory).unwrap();
        assert_eq!(ensure_system_id(&directory).unwrap(), first);
        set_replication_slot(&directory, "standby-a", 40).unwrap();
        set_replication_slot(&directory, "standby-b", 20).unwrap();
        assert_eq!(replication_retention_lsn(&directory).unwrap(), Some(20));
        set_replication_slot(&directory, "standby-b", 60).unwrap();
        assert_eq!(replication_retention_lsn(&directory).unwrap(), Some(40));
        assert!(remove_replication_slot(&directory, "standby-a").unwrap());
        assert_eq!(replication_retention_lsn(&directory).unwrap(), Some(60));
        fs::remove_dir_all(directory).unwrap();
    }
}
