//! Segment-granular checkpoint retirement. Complete sealed segments at or below
//! the safe frontier are deleted; the active segment is never copied or rewritten.
use super::*;
use std::thread::JoinHandle;

pub(super) struct Task {
    worker: JoinHandle<Result<Prepared>>,
}
struct Prepared {
    safe: u64,
    segments: Vec<PathBuf>,
    /// 0.2-I.2: retained history no slot needs any more.
    retained: Vec<PathBuf>,
}

impl Wal {
    pub fn checkpoint_pending(&self) -> bool {
        self.checkpoint_task.is_some()
    }

    /// 0.2-C: a finished retirement worker waits for a quiescent writer.
    pub(super) fn checkpoint_task_finished(&self) -> bool {
        self.checkpoint_task
            .as_ref()
            .is_some_and(|task| task.worker.is_finished())
    }

    pub fn request_checkpoint(&mut self, safe_lsn: u64) -> Result<()> {
        if self.page_format >= 3 {
            return Err(state(
                "incremental MVCC retirement requires status horizon integration",
            ));
        }
        self.request_checkpoint_inner(safe_lsn)
    }

    pub fn request_checkpoint_with_visibility(
        &mut self,
        safe_lsn: u64,
        drain: impl FnOnce(&Path) -> Result<u64>,
    ) -> Result<()> {
        if self.page_format < 3 {
            return Err(state("visibility barrier requires MVCC capability"));
        }
        if drain(&self.directory)? < safe_lsn {
            return Err(state("visibility state is behind incremental retirement"));
        }
        self.request_checkpoint_inner(safe_lsn)
    }

    fn request_checkpoint_inner(&mut self, safe_lsn: u64) -> Result<()> {
        self.available()?;
        if self.active.is_some() || !self.pending.is_empty() || safe_lsn > self.durable_lsn {
            return Err(state(
                "incremental checkpoint requires a durable publication boundary",
            ));
        }
        if self.checkpoint_task.is_some() {
            return Ok(());
        }
        // A checkpoint covering the complete active prefix seals it first.
        // Retirement can then unlink the whole segment without copying bytes.
        if safe_lsn >= self.last_commit_lsn && self.last_commit_lsn > self.segment_start_lsn {
            self.checkpoint_lsn = self.checkpoint_lsn.max(safe_lsn);
            self.rotate_segment()?;
        }
        let directory = self.directory.clone();
        let worker = std::thread::Builder::new()
            .name("phobos-wal-checkpoint".into())
            .spawn(move || prepare(&directory, safe_lsn))?;
        self.checkpoint_task = Some(Task { worker });
        self.commits_since_checkpoint = 0;
        self.checkpoint_bytes = self.written_len;
        Ok(())
    }

    pub fn poll_checkpoint(&mut self) -> Result<bool> {
        self.available()?;
        if self.active.is_some() || !self.pending.is_empty() {
            return Ok(false);
        }
        if !self
            .checkpoint_task
            .as_ref()
            .is_some_and(|task| task.worker.is_finished())
        {
            return Ok(false);
        }
        let result = self.finish_checkpoint();
        if result.is_err() {
            self.fenced = true;
        }
        result
    }

    fn finish_checkpoint(&mut self) -> Result<bool> {
        let _span = phobos_observability::span("checkpoint.foreground_finish");
        let prepared = self
            .checkpoint_task
            .take()
            .expect("finished task")
            .worker
            .join()
            .map_err(|_| state("checkpoint worker panicked"))??;
        phobos_observability::synchronization_boundary("c4_checkpoint_prepared", &self.directory);
        phobos_observability::certification_crash("c4_checkpoint_prepared");
        for path in &prepared.segments {
            fs::remove_file(path)?;
        }
        super::super::retention::prune(&self.directory, &prepared.retained)?;
        if !prepared.segments.is_empty() {
            sync_directory(&self.directory)?;
            phobos_observability::event(
                "checkpoint.wal_segments_retired",
                prepared.segments.len() as u64,
            );
        }
        phobos_observability::synchronization_boundary("c4_checkpoint_replaced", &self.directory);
        phobos_observability::certification_crash("c4_checkpoint_replaced");
        self.checkpoint_lsn = self.checkpoint_lsn.max(prepared.safe);
        self.checkpoint_bytes = self.written_len;
        phobos_observability::event("checkpoint.completed", 1);
        Ok(true)
    }

    pub(super) fn cancel_checkpoint(&mut self) -> Result<()> {
        if let Some(task) = self.checkpoint_task.take() {
            task.worker
                .join()
                .map_err(|_| state("checkpoint worker panicked"))??;
        }
        Ok(())
    }
}

impl Drop for Wal {
    fn drop(&mut self) {
        let _ = self.cancel_checkpoint();
        // 0.2-F: never leave a background extender running past its writer.
        self.join_extender();
    }
}

fn prepare(directory: &Path, safe: u64) -> Result<Prepared> {
    let _span = phobos_observability::span("checkpoint.wal_prepare");
    // 0.2-I.2: an unreadable slot file retains everything (frontier 0).
    let standby = super::super::retention::frontier(directory)?;
    let retirement_safe = standby.map_or(safe, |standby| safe.min(standby));
    // Pruning is optional: a listing raced by a concurrent segment rotation
    // must not fail (and fence) the checkpoint; the next one prunes instead.
    let retained = super::super::retention::prunable(directory, standby).unwrap_or_default();
    let mut retired = Vec::new();
    for segment in super::super::scan::segments(&directory.join(NAME))? {
        if segment.active {
            continue;
        }
        let report = super::super::scan::inspect_file(&segment.path, false)?;
        if report.tail != Tail::Clean || report.incomplete_transactions != 0 {
            return Err(state("sealed WAL segment is incomplete"));
        }
        if report.last_lsn <= retirement_safe {
            retired.push(segment.path);
        }
    }
    Ok(Prepared {
        safe,
        segments: retired,
        retained,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn finish(wal: &mut Wal) -> Result<()> {
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
        while wal.checkpoint_pending() {
            wal.poll_checkpoint()?;
            assert!(std::time::Instant::now() < deadline);
            std::thread::yield_now();
        }
        Ok(())
    }

    #[test]
    fn checkpoint_deletes_only_fully_retired_sealed_segments() {
        let dir = super::super::tests::directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        wal.begin().unwrap();
        let first = wal.commit().unwrap();
        wal.rotate_segment_for_test().unwrap();
        wal.begin().unwrap();
        let second = wal.commit().unwrap();
        let sealed = super::super::super::scan::segments(&dir.join(NAME))
            .unwrap()
            .into_iter()
            .find(|segment| !segment.active)
            .unwrap()
            .path;
        assert!(sealed.exists());
        wal.request_checkpoint(first.lsn()).unwrap();
        finish(&mut wal).unwrap();
        assert!(!sealed.exists());
        assert_eq!(inspect(dir.join(NAME)).unwrap().last_lsn, second.lsn());
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn replication_slot_pins_then_releases_a_sealed_segment() {
        let dir = super::super::tests::directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        wal.begin().unwrap();
        let first = wal.commit().unwrap();
        wal.rotate_segment_for_test().unwrap();
        let sealed = super::super::super::scan::segments(&dir.join(NAME))
            .unwrap()
            .into_iter()
            .find(|segment| !segment.active)
            .unwrap()
            .path;
        super::super::super::set_replication_slot(&dir, "standby", first.lsn() - 1).unwrap();
        wal.request_checkpoint(first.lsn()).unwrap();
        finish(&mut wal).unwrap();
        assert!(sealed.exists());
        super::super::super::set_replication_slot(&dir, "standby", first.lsn()).unwrap();
        wal.request_checkpoint(first.lsn()).unwrap();
        finish(&mut wal).unwrap();
        assert!(!sealed.exists());
        eprintln!("G3_RETENTION pinned_segments=1 released_segments=1");
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn only_the_active_segment_may_have_a_torn_tail() {
        let dir = super::super::tests::directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        wal.begin().unwrap();
        wal.commit().unwrap();
        wal.rotate_segment_for_test().unwrap();
        drop(wal);
        let segments = super::super::super::scan::segments(&dir.join(NAME)).unwrap();
        let sealed = segments.iter().find(|segment| !segment.active).unwrap();
        let mut bytes = fs::read(&sealed.path).unwrap();
        *bytes.last_mut().unwrap() ^= 1;
        fs::write(&sealed.path, bytes).unwrap();
        fs::OpenOptions::new()
            .append(true)
            .open(dir.join(NAME))
            .unwrap()
            .write_all(b"PHW")
            .unwrap();
        assert!(inspect(dir.join(NAME)).is_err());
        fs::remove_dir_all(dir).unwrap();
    }
}
