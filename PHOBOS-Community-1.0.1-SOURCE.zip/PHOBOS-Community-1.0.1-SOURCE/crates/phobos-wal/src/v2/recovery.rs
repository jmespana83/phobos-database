//! Forced, idempotent redo. WAL retention/checkpoint remains a separate step.
use super::{Body, FileId, ScanReport, visit_committed};
use phobos_error::{ErrorCode, PhobosError};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::{self, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
};

type Result<T> = std::result::Result<T, PhobosError>;
const PAGE_BYTES: u64 = 8192;

/// Restore committed changes and force them before returning. The caller must
/// own the database exclusively, with all heap/index handles closed. Neither WAL
/// truncation nor retirement cleanup happens here: on failure the unchanged WAL
/// remains the source for another recovery attempt.
///
/// Allocation records follow their initialized page images. They validate an
/// extent, never create holes. Retired paged files are retained until checkpoint
/// so historical redo can still address an immutable file ID after a later DROP.
pub fn redo(directory: impl AsRef<Path>) -> Result<ScanReport> {
    let directory = directory.as_ref();
    let wal_path = directory.join("phobos.wal");
    // A complete COMMIT recovered from an unsynchronized process must become
    // durable before any base-page write, just like an ordinary commit.
    let wal = OpenOptions::new().read(true).write(true).open(&wal_path)?;
    wal.sync_all()?;
    drop(wal);
    let mut paged = BTreeMap::<FileId, fs::File>::new();
    let mut dirty = BTreeSet::<FileId>::new();
    let mut directory_dirty = false;
    // 0.2-D: pages whose on-disk image could not serve as a delta base (torn,
    // missing, or not the logged base). A later full image of the same page
    // resolves them; any left at the end fail recovery closed.
    let mut unresolved = BTreeSet::<(FileId, u64)>::new();
    let mut cache = RedoCache::default();
    let report = visit_committed(&wal_path, |_, record| {
        match &record.body {
            Body::Page {
                file, page, image, ..
            } => {
                if !paged.contains_key(file) {
                    let path = paged_path(directory, *file)?;
                    let target = OpenOptions::new().read(true).write(true).open(path)?;
                    paged.insert(*file, target);
                }
                let target = paged.get_mut(file).expect("opened redo target");
                let offset = page
                    .checked_mul(PAGE_BYTES)
                    .ok_or_else(|| invalid("page offset overflow"))?;
                match on_disk(target, &mut cache, (*file, *page), offset)? {
                    // A torn final page can be repaired; missing earlier pages
                    // cannot be invented by extending a sparse file to this offset.
                    OnDisk::Hole => {
                        return Err(invalid("redo page would leave uninitialized pages"));
                    }
                    OnDisk::Page(current)
                        if super::page_format::lsn(*file, *page, &current)
                            .is_ok_and(|lsn| lsn >= record.lsn) =>
                    {
                        phobos_observability::event("recovery.page_lsn_skips", 1);
                        dirty.insert(*file);
                        unresolved.remove(&(*file, *page));
                        return Ok(());
                    }
                    _ => {}
                }
                target.seek(SeekFrom::Start(offset))?;
                phobos_observability::certification_crash("v2_before_redo_page");
                cache.forget((*file, *page));
                target.write_all(image.as_ref())?;
                cache.put((*file, *page), image);
                phobos_observability::event("recovery.page_redo", 1);
                dirty.insert(*file);
                unresolved.remove(&(*file, *page));
                phobos_observability::certification_crash("v2_after_redo_page");
            }
            Body::PageDelta {
                file,
                page,
                base_lsn,
                base_checksum,
                result_checksum,
                ops,
                ..
            } => {
                if !paged.contains_key(file) {
                    let path = paged_path(directory, *file)?;
                    let target = OpenOptions::new().read(true).write(true).open(path)?;
                    paged.insert(*file, target);
                }
                let target = paged.get_mut(file).expect("opened redo target");
                let offset = page
                    .checked_mul(PAGE_BYTES)
                    .ok_or_else(|| invalid("page offset overflow"))?;
                let OnDisk::Page(mut current) =
                    on_disk(target, &mut cache, (*file, *page), offset)?
                else {
                    phobos_observability::event("recovery.delta_unresolved", 1);
                    unresolved.insert((*file, *page));
                    return Ok(());
                };
                let on_disk = super::page_format::lsn(*file, *page, &current).ok();
                if on_disk.is_some_and(|lsn| lsn >= record.lsn) {
                    phobos_observability::event("recovery.delta_lsn_skips", 1);
                    dirty.insert(*file);
                    unresolved.remove(&(*file, *page));
                    return Ok(());
                }
                if on_disk != Some(*base_lsn)
                    || super::page_format::stored_checksum(*file, *page, &current)?
                        != *base_checksum
                {
                    // Torn or foreign base: only a later full image can repair it.
                    phobos_observability::event("recovery.delta_unresolved", 1);
                    unresolved.insert((*file, *page));
                    return Ok(());
                }
                super::delta::apply(&mut current, ops)?;
                let checksum = super::page_format::restamp(*file, *page, &mut current, record.lsn)?;
                if checksum != *result_checksum
                    || super::page_format::lsn(*file, *page, &current).ok() != Some(record.lsn)
                {
                    return Err(invalid(
                        "compact redo did not reproduce the logged page image",
                    ));
                }
                target.seek(SeekFrom::Start(offset))?;
                phobos_observability::certification_crash("v2_before_redo_page");
                cache.forget((*file, *page));
                target.write_all(current.as_ref())?;
                cache.put((*file, *page), &current);
                phobos_observability::event("recovery.delta_redo", 1);
                dirty.insert(*file);
                unresolved.remove(&(*file, *page));
                phobos_observability::certification_crash("v2_after_redo_page");
            }
            Body::Allocate { file, pages } => {
                let length = pages
                    .checked_mul(PAGE_BYTES)
                    .ok_or_else(|| invalid("allocation overflow"))?;
                let actual = fs::metadata(paged_path(directory, *file)?)?.len();
                // A later committed transaction may already have extended this
                // file; replay of the earlier extent must not truncate it.
                if actual < length || actual % PAGE_BYTES != 0 {
                    return Err(invalid("redo allocation lacks complete page images"));
                }
            }
            Body::Create(file) => {
                let path = if file.is_paged() {
                    paged_path(directory, *file)?
                } else {
                    directory.join(file.name())
                };
                let target = OpenOptions::new()
                    .write(true)
                    .create(true)
                    .truncate(false)
                    .open(path)?;
                target.sync_all()?;
                drop(target);
                directory_dirty = true;
            }
            Body::Delete(file) => {
                cache.forget_file(*file);
                if let Some(target) = paged.remove(file) {
                    if dirty.remove(file) {
                        target.sync_all()?;
                        phobos_observability::event("recovery.data_file_forces", 1);
                    }
                }
                let live = directory.join(file.name());
                if file.is_paged() {
                    let retired = retired_path(directory, *file);
                    if live.exists() && retired.exists() {
                        return Err(invalid("both live and retired files exist for one ID"));
                    }
                    if live.exists() {
                        fs::rename(live, retired)?;
                    }
                } else {
                    match fs::remove_file(live) {
                        Ok(()) => {}
                        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                        Err(error) => return Err(error.into()),
                    }
                }
                directory_dirty = true;
            }
            Body::Metadata {
                file,
                offset,
                total_len,
                bytes,
            } => {
                let temporary = directory.join(format!(".phobos-redo-{}", file.name()));
                let mut target = OpenOptions::new()
                    .write(true)
                    .create(*offset == 0)
                    .truncate(*offset == 0)
                    .open(&temporary)?;
                if target.metadata()?.len() != *offset {
                    return Err(invalid("redo metadata scratch extent mismatch"));
                }
                target.seek(SeekFrom::Start(*offset))?;
                target.write_all(bytes)?;
                if offset.checked_add(bytes.len() as u64) == Some(*total_len) {
                    target.sync_all()?;
                    // Windows replacement requires closing the temporary handle.
                    drop(target);
                    fs::rename(temporary, directory.join(file.name()))?;
                    sync_directory(directory)?;
                }
            }
            Body::Begin | Body::Commit | Body::MvccIdentity(_) => {}
            _ => return Err(invalid("unexpected record in committed redo")),
        }
        Ok(())
    })?;
    if let Some((file, page)) = unresolved.first() {
        return Err(invalid(&format!(
            "compact redo has no valid base or full image for {} page(s) (first: {} page {page})",
            unresolved.len(),
            file.name()
        )));
    }
    let mut forced = 0u64;
    for file in dirty {
        paged
            .get(&file)
            .ok_or_else(|| invalid("redo target disappeared before force"))?
            .sync_all()?;
        forced += 1;
    }
    if forced != 0 {
        phobos_observability::event("recovery.data_file_forces", forced);
        phobos_observability::event("recovery.redo_force_batches", 1);
    }
    if directory_dirty {
        sync_directory(directory)?;
    }
    Ok(report)
}

/// 0.2-D: the current on-disk bytes of pages redo has already read or
/// written, so the many records of a hot page do not each pay a length check
/// and a read. It mirrors the files exactly: an entry is dropped before each
/// redo write and re-inserted only after the write succeeded.
#[derive(Default)]
struct RedoCache {
    pages: std::collections::HashMap<(FileId, u64), Box<[u8; 8192]>>,
}
const REDO_CACHE_PAGES: usize = 8192;
impl RedoCache {
    fn put(&mut self, key: (FileId, u64), bytes: &[u8; 8192]) {
        if self.pages.len() >= REDO_CACHE_PAGES && !self.pages.contains_key(&key) {
            self.pages.clear();
        }
        self.pages.insert(key, Box::new(*bytes));
    }
    fn forget(&mut self, key: (FileId, u64)) {
        self.pages.remove(&key);
    }
    fn forget_file(&mut self, file: FileId) {
        self.pages.retain(|(cached, _), _| *cached != file);
    }
}
enum OnDisk {
    Page(Box<[u8; 8192]>),
    /// The file ends inside this page (a torn final page).
    Short,
    /// The file ends before this page.
    Hole,
}
fn on_disk(
    target: &mut fs::File,
    cache: &mut RedoCache,
    key: (FileId, u64),
    offset: u64,
) -> Result<OnDisk> {
    if let Some(bytes) = cache.pages.get(&key) {
        return Ok(OnDisk::Page(bytes.clone()));
    }
    let length = target.metadata()?.len();
    if offset > length {
        return Ok(OnDisk::Hole);
    }
    if length - offset < PAGE_BYTES {
        return Ok(OnDisk::Short);
    }
    let mut bytes = Box::new([0; 8192]);
    target.seek(SeekFrom::Start(offset))?;
    target.read_exact(bytes.as_mut())?;
    cache.put(key, &bytes);
    Ok(OnDisk::Page(bytes))
}

fn retired_path(directory: &Path, file: FileId) -> PathBuf {
    directory.join(format!(".phobos-retired-{}", file.name()))
}
fn paged_path(directory: &Path, file: FileId) -> Result<PathBuf> {
    if !file.is_paged() {
        return Err(invalid("nonpaged file in page redo"));
    }
    let live = directory.join(file.name());
    let retired = retired_path(directory, file);
    match (live.exists(), retired.exists()) {
        (true, true) => Err(invalid("both live and retired files exist for one ID")),
        (false, true) => Ok(retired),
        _ => Ok(live),
    }
}
fn sync_directory(directory: &Path) -> Result<()> {
    #[cfg(unix)]
    fs::File::open(directory)?.sync_all()?;
    #[cfg(not(unix))]
    let _ = directory;
    Ok(())
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidWal, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v2::{PageAction, Wal};
    use std::sync::atomic::{AtomicU64, Ordering};
    fn directory() -> PathBuf {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "phobos-v2-redo-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ))
    }
    fn page(wal: &mut Wal, file: FileId, page: u64, value: u8) {
        wal.append(Body::Page {
            action: PageAction::Initialize,
            file,
            page,
            image: Box::new([value; 8192]),
        })
        .unwrap();
    }

    #[cfg(feature = "certification")]
    #[test]
    fn partial_records_and_redo_only_sync_never_commit() {
        if let Ok(dir) = std::env::var("PHOBOS_V2_PARTIAL_TEST_DIR") {
            let mut wal = Wal::open(&dir).unwrap();
            wal.begin().unwrap();
            page(&mut wal, FileId::Heap(1), 0, 9);
            wal.commit().unwrap();
            std::process::exit(74);
        }
        for point in [
            "v2_partial_page_record",
            "v2_partial_commit_record",
            "v2_after_redo_sync_before_commit",
        ] {
            let dir = directory();
            drop(Wal::create(&dir).unwrap());
            let target = dir.join(FileId::Heap(1).name());
            fs::write(&target, [7; 8192]).unwrap();
            let child = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "v2::recovery::tests::partial_records_and_redo_only_sync_never_commit",
                    "--nocapture",
                ])
                .env("PHOBOS_V2_PARTIAL_TEST_DIR", &dir)
                .env("PHOBOS_BETA_CRASH_POINT", point)
                .output()
                .unwrap();
            assert!(!child.status.success());
            assert_ne!(child.status.code(), Some(74));
            assert_ne!(child.status.code(), Some(101));
            assert!(
                String::from_utf8_lossy(&child.stderr)
                    .contains(&format!("BETA_CRASH_REACHED {point}"))
            );
            for _ in 0..2 {
                drop(Wal::recover(&dir).unwrap());
                assert_eq!(fs::read(&target).unwrap(), [7; 8192]);
            }
            fs::remove_dir_all(dir).unwrap();
        }
    }

    #[cfg(feature = "certification")]
    #[test]
    fn interrupted_redo_remains_repeatable() {
        if let Ok(dir) = std::env::var("PHOBOS_V2_REDO_TEST_DIR") {
            Wal::recover(dir).unwrap();
            std::process::exit(74);
        }
        for point in [
            "v2_before_redo_page",
            "v2_after_redo_page",
            "v2_checkpoint_prepared",
            "v2_checkpoint_replaced",
        ] {
            let dir = directory();
            let mut wal = Wal::create(&dir).unwrap();
            let heap = FileId::Heap(1);
            wal.begin().unwrap();
            wal.append(Body::Create(heap)).unwrap();
            page(&mut wal, heap, 0, 17);
            page(&mut wal, heap, 1, 23);
            wal.commit().unwrap();
            drop(wal);
            let before = fs::read(dir.join("phobos.wal")).unwrap();
            let child = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "v2::recovery::tests::interrupted_redo_remains_repeatable",
                    "--nocapture",
                ])
                .env("PHOBOS_V2_REDO_TEST_DIR", &dir)
                .env("PHOBOS_BETA_CRASH_POINT", point)
                .output()
                .unwrap();
            assert!(!child.status.success());
            assert_ne!(child.status.code(), Some(74), "crash hook did not fire");
            assert_ne!(child.status.code(), Some(101), "child panicked");
            assert!(
                String::from_utf8_lossy(&child.stderr)
                    .contains(&format!("BETA_CRASH_REACHED {point}"))
            );
            for _ in 0..2 {
                drop(Wal::recover(&dir).unwrap());
                let actual = fs::read(dir.join(heap.name())).unwrap();
                assert_eq!(&actual[..8192], &[17; 8192]);
                assert_eq!(&actual[8192..], &[23; 8192]);
            }
            assert_ne!(fs::read(dir.join("phobos.wal")).unwrap(), before);
            assert!(!dir.join("phobos.wal.v2-checkpoint.tmp").exists());
            fs::remove_dir_all(dir).unwrap();
        }
    }
    #[test]
    fn repairs_torn_pages_and_metadata_without_replaying_uncommitted_changes() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        let heap = FileId::Heap(1);
        wal.begin().unwrap();
        wal.append(Body::Create(heap)).unwrap();
        page(&mut wal, heap, 0, 17);
        page(&mut wal, heap, 1, 23);
        wal.append(Body::Allocate {
            file: heap,
            pages: 2,
        })
        .unwrap();
        for (offset, bytes) in [(0, vec![1, 2]), (2, vec![3, 4])] {
            wal.append(Body::Metadata {
                file: FileId::Tables,
                offset,
                total_len: 4,
                bytes,
            })
            .unwrap();
        }
        wal.commit().unwrap();
        wal.begin().unwrap();
        page(&mut wal, heap, 0, 99);
        drop(wal);
        let wal_before = fs::read(dir.join("phobos.wal")).unwrap();
        fs::write(dir.join(heap.name()), vec![255; 8201]).unwrap();
        fs::write(dir.join(FileId::Tables.name()), [9]).unwrap();
        for _ in 0..2 {
            redo(&dir).unwrap();
            let actual = fs::read(dir.join(heap.name())).unwrap();
            assert_eq!(&actual[..8192], &[17; 8192]);
            assert_eq!(&actual[8192..], &[23; 8192]);
            assert_eq!(
                fs::read(dir.join(FileId::Tables.name())).unwrap(),
                [1, 2, 3, 4]
            );
            assert_eq!(fs::read(dir.join("phobos.wal")).unwrap(), wal_before);
        }
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn historical_updates_survive_later_retirement_and_missing_pages_fail_closed() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        let index = FileId::Index(1);
        wal.begin().unwrap();
        wal.append(Body::Create(index)).unwrap();
        page(&mut wal, index, 0, 1);
        wal.commit().unwrap();
        wal.begin().unwrap();
        wal.append(Body::Delete(index)).unwrap();
        wal.commit().unwrap();
        drop(wal);
        for _ in 0..2 {
            redo(&dir).unwrap();
            assert!(!dir.join(index.name()).exists());
            assert_eq!(fs::read(retired_path(&dir, index)).unwrap(), [1; 8192]);
        }
        fs::remove_dir_all(dir).unwrap();

        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        wal.append(Body::Create(index)).unwrap();
        page(&mut wal, index, 1000, 1);
        wal.commit().unwrap();
        drop(wal);
        assert!(redo(&dir).is_err());
        assert_eq!(fs::metadata(dir.join(index.name())).unwrap().len(), 0);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn recovery_replays_commits_across_sealed_and_active_segments() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        wal.append(Body::Metadata {
            file: FileId::Tables,
            offset: 0,
            total_len: 3,
            bytes: b"one".to_vec(),
        })
        .unwrap();
        wal.commit().unwrap();
        wal.rotate_segment_for_test().unwrap();
        wal.begin().unwrap();
        wal.append(Body::Metadata {
            file: FileId::Tables,
            offset: 0,
            total_len: 3,
            bytes: b"two".to_vec(),
        })
        .unwrap();
        wal.commit().unwrap();
        drop(wal);
        redo(&dir).unwrap();
        assert_eq!(fs::read(dir.join(FileId::Tables.name())).unwrap(), b"two");
        fs::remove_dir_all(dir).unwrap();
    }
}
