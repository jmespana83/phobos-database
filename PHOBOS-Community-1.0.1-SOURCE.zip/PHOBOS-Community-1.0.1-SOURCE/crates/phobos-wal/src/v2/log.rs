//! Serialized WAL writer. A durable receipt is constructed only after fsync;
//! any partial/unexpected physical write fences the writer until recovery.
use super::scan::Transaction;
use super::{Body, FileId, PageAction, Record, Tail, inspect};
use phobos_error::{ErrorCode, PhobosError};
use std::{
    fs::{self, File, OpenOptions},
    io::{Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::{Arc, atomic::Ordering},
};

mod checkpoint;

type Result<T> = std::result::Result<T, PhobosError>;
const NAME: &str = "phobos.wal";
const TEMP: &str = "phobos.wal.v2-checkpoint.tmp";
const SEGMENT_BYTES: u64 = 64 * 1024 * 1024;
const WRITE_BATCH_BYTES: usize = 1024 * 1024;
/// 0.2-E: preallocation granularity of a write-through segment. Each extent
/// is zero-filled and flushed before any record is written into it.
const EXTENT_BYTES: u64 = 4 * 1024 * 1024;
use super::scan::WRITE_PIECE;

/// 0.2-E WAL durability mode (docs/wal_v3_windows_durable_wal.md).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DurabilityMode {
    /// Mode A, the 0.2-D path: the active file grows by appends, Stage A
    /// writes into the OS cache and the force is `FlushFileBuffers` /
    /// `fdatasync`.
    Flush,
    /// Mode E: preallocated zero-filled extents opened write-through
    /// (Windows `FILE_FLAG_WRITE_THROUGH`, Linux `O_DSYNC`). Stage A performs
    /// no I/O; the force leader's positional write is the durable event.
    WriteThrough,
}
static MODE_OVERRIDE: std::sync::atomic::AtomicU8 = std::sync::atomic::AtomicU8::new(0);
#[cfg(any(test, feature = "test-hooks"))]
thread_local! {
    static THREAD_MODE: std::cell::Cell<Option<DurabilityMode>> = const { std::cell::Cell::new(None) };
}
/// Test-only: writers opened by this thread use `mode` (None: configured).
#[cfg(any(test, feature = "test-hooks"))]
pub fn set_thread_mode_for_test(mode: Option<DurabilityMode>) {
    THREAD_MODE.with(|cell| cell.set(mode));
}
impl DurabilityMode {
    /// True where a write-through handle is implemented.
    #[must_use]
    pub fn write_through_supported() -> bool {
        cfg!(any(
            windows,
            all(
                target_os = "linux",
                any(
                    target_arch = "x86_64",
                    target_arch = "x86",
                    target_arch = "aarch64",
                    target_arch = "arm",
                    target_arch = "riscv64"
                )
            )
        ))
    }
    /// The mode for writers opened from now on: an explicit process setting,
    /// else `PHOBOS_WAL_MODE` (`flush` | `write-through`), else write-through
    /// where supported.
    #[must_use]
    pub fn configured() -> Self {
        #[cfg(any(test, feature = "test-hooks"))]
        if let Some(mode) = THREAD_MODE.with(std::cell::Cell::get) {
            return mode;
        }
        let requested = match MODE_OVERRIDE.load(Ordering::Acquire) {
            1 => Some(Self::Flush),
            2 => Some(Self::WriteThrough),
            _ => std::env::var("PHOBOS_WAL_MODE")
                .ok()
                .and_then(|value| Self::parse(&value)),
        };
        match requested {
            Some(Self::Flush) => Self::Flush,
            _ if Self::write_through_supported() => Self::WriteThrough,
            _ => Self::Flush,
        }
    }
    #[must_use]
    pub fn parse(value: &str) -> Option<Self> {
        match value.trim().to_ascii_lowercase().as_str() {
            "flush" | "a" | "append-flush" => Some(Self::Flush),
            "write-through" | "writethrough" | "e" | "prealloc-write-through" => {
                Some(Self::WriteThrough)
            }
            _ => None,
        }
    }
    /// Process-wide setting for writers opened afterwards (server start-up).
    pub fn set_process_default(mode: Self) {
        MODE_OVERRIDE.store(
            match mode {
                Self::Flush => 1,
                Self::WriteThrough => 2,
            },
            Ordering::Release,
        );
    }
    #[must_use]
    pub fn name(self) -> &'static str {
        match self {
            Self::Flush => "flush (A: append + FlushFileBuffers/fdatasync)",
            Self::WriteThrough => "write-through (E: preallocated + write-through)",
        }
    }
}

#[cfg(windows)]
fn write_through(options: &mut OpenOptions) {
    use std::os::windows::fs::OpenOptionsExt;
    const FILE_FLAG_WRITE_THROUGH: u32 = 0x8000_0000;
    options.custom_flags(FILE_FLAG_WRITE_THROUGH);
}
#[cfg(all(
    target_os = "linux",
    any(
        target_arch = "x86_64",
        target_arch = "x86",
        target_arch = "aarch64",
        target_arch = "arm",
        target_arch = "riscv64"
    )
))]
fn write_through(options: &mut OpenOptions) {
    use std::os::unix::fs::OpenOptionsExt;
    // O_DSYNC on the generic Linux ABI (x86, x86_64, arm, aarch64, riscv64).
    const O_DSYNC: i32 = 0o10000;
    options.custom_flags(O_DSYNC);
}
#[cfg(not(any(
    windows,
    all(
        target_os = "linux",
        any(
            target_arch = "x86_64",
            target_arch = "x86",
            target_arch = "aarch64",
            target_arch = "arm",
            target_arch = "riscv64"
        )
    )
)))]
fn write_through(_options: &mut OpenOptions) {}

/// Open the active WAL for the writer in `mode`.
fn open_active(path: &Path, mode: DurabilityMode) -> std::io::Result<File> {
    let mut options = OpenOptions::new();
    options.read(true).write(true);
    if mode == DurabilityMode::WriteThrough {
        write_through(&mut options);
    }
    options.open(path)
}

/// Positional write of the whole buffer (short writes are continued).
fn write_all_at(file: &File, bytes: &[u8], offset: u64) -> std::io::Result<()> {
    #[cfg(unix)]
    {
        std::os::unix::fs::FileExt::write_all_at(file, bytes, offset)
    }
    #[cfg(windows)]
    {
        let (mut bytes, mut offset) = (bytes, offset);
        while !bytes.is_empty() {
            match std::os::windows::fs::FileExt::seek_write(file, bytes, offset) {
                Ok(0) => {
                    return Err(std::io::Error::new(
                        std::io::ErrorKind::WriteZero,
                        "WAL write returned zero bytes",
                    ));
                }
                Ok(written) => {
                    bytes = &bytes[written..];
                    offset += written as u64;
                }
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => {}
                Err(error) => return Err(error),
            }
        }
        Ok(())
    }
}

/// 0.2-E: write `bytes` at `offset` in order, at most `WRITE_PIECE` bytes per
/// call, each call completing before the next starts. On a write-through
/// handle each completed piece is durable (the torn-window bound).
fn write_pieces(file: &File, bytes: &[u8], offset: u64) -> std::io::Result<()> {
    write_pieces_observed(file, bytes, offset, Path::new(""))
}
fn write_pieces_observed(
    file: &File,
    bytes: &[u8],
    offset: u64,
    directory: &Path,
) -> std::io::Result<()> {
    let mut position = offset;
    for piece in bytes.chunks(WRITE_PIECE) {
        #[cfg(any(test, feature = "test-hooks"))]
        if let Some(limit) = test_short_write::take(piece.len()) {
            write_all_at(file, &piece[..limit], position)?;
            physical_written(limit);
            return Err(std::io::Error::other("injected short WAL write"));
        }
        write_all_at(file, piece, position)?;
        physical_written(piece.len());
        position += piece.len() as u64;
        if position < offset + bytes.len() as u64 {
            // Test hook: a crash between two pieces of one durable write.
            phobos_observability::synchronization_boundary("wal.e_piece_written", directory);
        }
    }
    phobos_observability::event("wal.write_through_writes", 1);
    Ok(())
}

/// Test-only fault injection: the next WAL piece write persists only a prefix
/// and then fails (short write followed by an error, e.g. disk full).
#[cfg(any(test, feature = "test-hooks"))]
pub mod test_short_write {
    use std::sync::atomic::{AtomicUsize, Ordering};
    static NEXT: AtomicUsize = AtomicUsize::new(usize::MAX);
    pub fn arm(bytes: usize) {
        NEXT.store(bytes, Ordering::SeqCst);
    }
    pub(super) fn take(len: usize) -> Option<usize> {
        let limit = NEXT.swap(usize::MAX, Ordering::SeqCst);
        (limit != usize::MAX).then(|| limit.min(len))
    }
}

/// Build a complete new active WAL file at `path` (a temporary name, or the
/// WAL of a fresh database): anchor, plus one zero-filled extent in
/// write-through mode, flushed. Returns the file capacity.
fn build_active_file(path: &Path, anchor: &[u8], mode: DurabilityMode) -> Result<u64> {
    let mut file = OpenOptions::new().write(true).create_new(true).open(path)?;
    file.write_all(anchor)?;
    let capacity = match mode {
        DurabilityMode::Flush => anchor.len() as u64,
        DurabilityMode::WriteThrough => {
            zero_fill(&file, anchor.len() as u64, EXTENT_BYTES)?;
            EXTENT_BYTES
        }
    };
    phobos_observability::measure("wal.fsync", || file.sync_all())?;
    Ok(capacity)
}

/// Write zeros over `[from, to)` (no SetFileValidData: real zero data).
fn zero_fill(file: &File, from: u64, to: u64) -> std::io::Result<()> {
    let zeros = vec![0u8; 1 << 20];
    let mut position = from;
    while position < to {
        let length = usize::try_from((to - position).min(zeros.len() as u64)).expect("bounded");
        write_all_at(file, &zeros[..length], position)?;
        position += length as u64;
    }
    Ok(())
}

/// An appended COMMIT is not a durability authorization. Tickets are tied to
/// this writer lifetime, including when a directory is closed and reopened.
#[derive(Debug)]
pub struct PendingCommit {
    mvcc_id: Option<u64>,
    txn_id: u64,
    lsn: u64,
    writer: Arc<()>,
}
impl PendingCommit {
    #[must_use]
    pub fn txn_id(&self) -> u64 {
        self.txn_id
    }
    #[must_use]
    pub fn lsn(&self) -> u64 {
        self.lsn
    }
}

/// 0.2-C: the first half of a WAL force whose physical sync runs outside the
/// writer lock. Every byte up to `target` was written (and length-checked)
/// before the intent was issued; only `complete_force` may advance the
/// durable frontier, and only after the sync of this handle succeeded.
#[derive(Debug)]
pub struct ForceIntent {
    file: File,
    target: u64,
    writer: Arc<()>,
    /// Test-only injected failure at the force I/O boundary.
    injected_failure: bool,
    /// 0.2-E write-through: the exact byte range `[offset, offset+len)`
    /// reserved for this force; writing it is the durability operation.
    write: Option<(Arc<Vec<u8>>, u64)>,
    #[cfg(feature = "test-hooks")]
    directory: PathBuf,
}
impl ForceIntent {
    #[must_use]
    pub fn target(&self) -> u64 {
        self.target
    }
    /// The durability I/O itself: Mode A `fdatasync` / `FlushFileBuffers`;
    /// Mode E the positional write-through write of the reserved range.
    pub fn sync(&self) -> std::io::Result<()> {
        if self.injected_failure {
            return Err(std::io::Error::other("injected WAL force failure"));
        }
        match &self.write {
            None => self.file.sync_data(),
            Some((bytes, offset)) => {
                #[cfg(feature = "test-hooks")]
                let directory = self.directory.as_path();
                #[cfg(not(feature = "test-hooks"))]
                let directory = Path::new("");
                write_pieces_observed(&self.file, bytes, *offset, directory)
            }
        }
    }
    /// Bytes this force writes (Mode E), 0 for a flush.
    #[must_use]
    pub fn write_len(&self) -> usize {
        self.write.as_ref().map_or(0, |(bytes, _)| bytes.len())
    }
}

#[derive(Debug)]
pub struct DurableCommit {
    mvcc_id: Option<u64>,
    txn_id: u64,
    lsn: u64,
    directory: PathBuf,
    page_format: u16,
}
impl DurableCommit {
    #[must_use]
    pub fn mvcc_id(&self) -> Option<u64> {
        self.mvcc_id
    }
    #[must_use]
    pub fn txn_id(&self) -> u64 {
        self.txn_id
    }
    #[must_use]
    pub fn lsn(&self) -> u64 {
        self.lsn
    }
    /// Canonical database identity carried by the writer, not supplied at commit.
    #[must_use]
    pub fn directory(&self) -> &Path {
        &self.directory
    }
    #[must_use]
    pub fn page_format(&self) -> u16 {
        self.page_format
    }
}

pub struct Wal {
    #[cfg(any(test, feature = "test-hooks"))]
    fail_next_sync: bool,
    checkpoint_task: Option<checkpoint::Task>,
    checkpoint_bytes: u64,
    writer: Arc<()>,
    pending: Vec<(u64, u64)>,
    directory: PathBuf,
    page_format: u16,
    checkpoint_lsn: u64,
    segment_start_lsn: u64,
    file: Option<File>,
    /// Encoded records waiting for one ordered physical append. Logical LSNs
    /// and record bytes are fixed before entering this bounded buffer.
    write_buffer: Vec<u8>,
    physical_len: u64,
    written_len: u64,
    next_lsn: u64,
    next_txn_id: u64,
    durable_lsn: u64,
    last_commit_lsn: u64,
    commits_since_checkpoint: u64,
    active: Option<Transaction>,
    transaction_failed: bool,
    fenced: bool,
    /// 0.2-D compact redo state (segment-scoped page chain, encoder).
    compact: Compact,
    /// 0.2-E durability mode of this writer lifetime.
    mode: DurabilityMode,
    /// Mode E: zero-filled, flushed file length (records never pass it).
    capacity: u64,
    /// Mode E: the range reserved by the outstanding force, starting at the
    /// durable offset `physical_len`; `write_buffer` holds the bytes after it.
    inflight: Option<Arc<Vec<u8>>>,
    /// Mode E: recycled buffer for the next batch.
    spare: Vec<u8>,
    /// 0.2-F Mode E: the one background extender preparing the next extent.
    extender: Option<Extender>,
    /// 0.2-F Mode E: the largest physical length an unadopted background
    /// extension may have produced (`capacity` when none is outstanding).
    extend_limit: u64,
    /// 0.2-F: background extent preparation enabled for this writer.
    background_extend: bool,
    /// 0.2-F: extents this writer had to prepare on the commit path.
    foreground_extends: u64,
    /// 0.2-G: bytes the next background extension prepares (a multiple of
    /// `EXTENT_BYTES`). Doubles, up to `MAX_EXTEND_STEP`, whenever the commit
    /// path had to wait for or perform an extension (the extender fell
    /// behind, e.g. during bulk ingest); reset when the active file is
    /// replaced.
    extend_step: u64,
    /// 0.2-G: (file, page, LSN, stored checksum) of the image this writer
    /// stamped last. The append that consumes that image (same file, page
    /// and still-unassigned LSN, fields unchanged) need not recompute the
    /// CRC it just computed; anything else takes the full check.
    last_stamp: Option<(FileId, u64, u64, u32)>,
}

/// 0.2-F (Part N): background preparation of the next WAL extent. The worker
/// zero-fills `[base, target)` through its own handle and flushes it; the
/// writer adopts `target` as capacity only after the worker returned success.
/// Until then no record is ever written at or past `base` (`capacity`).
struct Extender {
    base: u64,
    target: u64,
    handle: std::thread::JoinHandle<std::io::Result<()>>,
}

/// Start background preparation when less than this much prepared capacity
/// remains after the logical end.
const EXTEND_AHEAD_BYTES: u64 = 1024 * 1024;
/// 0.2-G: largest background extension (eight 4 MiB extents).
const MAX_EXTEND_STEP: u64 = 32 * 1024 * 1024;

/// Test hook: delay every background extender (simulates a slow device).
#[cfg(test)]
pub(super) static EXTENDER_DELAY_MS_FOR_TEST: std::sync::atomic::AtomicU64 =
    std::sync::atomic::AtomicU64::new(0);

fn background_extend_configured() -> bool {
    !matches!(
        std::env::var("PHOBOS_WAL_BACKGROUND_EXTEND")
            .ok()
            .as_deref()
            .map(str::trim),
        Some("0" | "off" | "false" | "no")
    )
}

/// Maximum pages tracked for delta eligibility in one segment. Clearing the
/// map is always safe: an untracked page's next change is a full image.
const COMPACT_TRACKED_PAGES: usize = 262_144;
/// A delta whose ops exceed this is never smaller than a useful image.
const DELTA_LIMIT: usize = 4096;

/// For every page logged in the active segment: the LSN and embedded page
/// checksum of its last logged image. A delta is written only against exactly
/// that image, so its base record is in the same segment, after the page's
/// first full image in that segment (the torn-page repair source).
#[derive(Default)]
struct Compact {
    pages: std::collections::HashMap<(FileId, u64), (u64, u32)>,
    /// Pages logged by the active transaction (forgotten if it aborts).
    transaction: Vec<(FileId, u64)>,
    encoder: super::delta::Encoder,
    ops: Vec<u8>,
}
impl Compact {
    fn reset_segment(&mut self) {
        self.pages.clear();
        self.transaction.clear();
    }
    fn logged(&mut self, file: FileId, page: u64, lsn: u64, checksum: u32) {
        if self.pages.len() >= COMPACT_TRACKED_PAGES {
            self.pages.clear();
            phobos_observability::event("wal.compact_map_resets", 1);
        }
        self.pages.insert((file, page), (lsn, checksum));
        self.transaction.push((file, page));
    }
    fn forget_transaction(&mut self) {
        for key in self.transaction.drain(..) {
            self.pages.remove(&key);
        }
    }
}
impl Wal {
    /// Deterministic test-only failure at the existing force I/O error boundary.
    #[cfg(any(test, feature = "test-hooks"))]
    pub fn fail_next_force_for_test(&mut self) {
        self.fail_next_sync = true;
    }
    /// Explicit offline conversion after the caller has preserved a backup and
    /// acquired exclusive ownership. Page formats remain unchanged in W1.
    pub fn migrate_legacy(directory: &Path, next_txn_id: u64) -> Result<Self> {
        if next_txn_id == 0 {
            return Err(state("migration transaction cursor is zero"));
        }
        let path = directory.join(NAME);
        let records = if path.exists() {
            crate::scan_records(&path, true)?.0
        } else {
            Vec::new()
        };
        let last_lsn = records.iter().map(|record| record.lsn).max().unwrap_or(0);
        let recorded_next = records
            .iter()
            .map(|record| record.txn_id)
            .max()
            .unwrap_or(0)
            .checked_add(1)
            .ok_or_else(|| state("migration transaction IDs exhausted"))?;
        drop(records);
        crate::recover(directory)?;
        for entry in fs::read_dir(directory)? {
            let entry = entry?;
            let path = entry.path();
            if entry.file_type()?.is_file()
                && matches!(
                    path.extension().and_then(|s| s.to_str()),
                    Some("heap" | "idx" | "phc" | "stats" | "txn")
                )
            {
                OpenOptions::new().write(true).open(path)?.sync_all()?;
            }
        }
        sync_directory(directory)?;
        let anchor = Record {
            txn_id: 0,
            lsn: last_lsn
                .checked_add(1)
                .ok_or_else(|| state("migration LSNs exhausted"))?,
            prev_lsn: 0,
            body: Body::Anchor {
                checkpoint_lsn: last_lsn,
                next_txn_id: next_txn_id.max(recorded_next),
                page_format: 1,
            },
        }
        .encode()?;
        let temporary = directory.join(TEMP);
        match fs::remove_file(&temporary) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error.into()),
        }
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)?;
        file.write_all(&anchor)?;
        file.sync_all()?;
        drop(file);
        phobos_observability::certification_crash("v2_migration_prepared");
        fs::rename(temporary, path)?;
        OpenOptions::new()
            .write(true)
            .open(directory.join(NAME))?
            .sync_all()?;
        sync_directory(directory)?;
        phobos_observability::certification_crash("v2_migration_installed");
        Self::open(directory)
    }

    /// Exclusive offline recovery, followed by a forced complete anchor. All
    /// data handles must be closed. A failure leaves the caller unable to open a
    /// writer until recovery succeeds; it must not continue using cached data.
    pub fn recover(directory: impl AsRef<Path>) -> Result<Self> {
        Self::recover_with_visibility(directory, |_| {
            Err(state(
                "MVCC recovery requires durable visibility reconciliation",
            ))
        })
    }
    /// Reconcile visibility before any WAL retirement, under exclusive ownership.
    pub fn recover_with_visibility(
        directory: impl AsRef<Path>,
        reconcile: impl FnOnce(&Path) -> Result<()>,
    ) -> Result<Self> {
        let directory = directory.as_ref();
        repair_interrupted_rotation(directory)?;
        let prior = inspect(directory.join(NAME))?;
        if prior.page_format >= 3 {
            reconcile(directory)?;
        }
        if prior.tail == Tail::Clean
            && prior.committed_transactions == 0
            && prior.incomplete_transactions == 0
        {
            // A complete checkpoint already covers every committed page. Open
            // validates and synchronizes this prefix; rewriting another anchor
            // would add needless fsync/rename work on every clean startup.
            // 0.2-E: a leftover temporary (an interrupted rotation/checkpoint
            // preparation) is discarded first; open may build a new one.
            match fs::remove_file(directory.join(TEMP)) {
                Ok(()) => {}
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error.into()),
            }
            let wal = Self::open(directory)?;
            cleanup_retired(directory)?;
            return Ok(wal);
        }
        let report = super::redo(directory)?;
        // Preflight and redo succeeded using the authoritative WAL. A leftover
        // replacement temporary can now be discarded and regenerated from it.
        match fs::remove_file(directory.join(TEMP)) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error.into()),
        }
        let next_lsn = report
            .last_lsn
            .checked_add(1)
            .ok_or_else(|| state("V2 WAL LSNs exhausted"))?;
        let mode = DurabilityMode::configured();
        let file = open_active(&directory.join(NAME), mode)?;
        let capacity = file.metadata()?.len();
        // Keep any torn suffix until atomic replacement, never expose an empty
        // WAL or append behind it. checkpoint_all is the only next operation.
        let mut wal = Self {
            #[cfg(any(test, feature = "test-hooks"))]
            fail_next_sync: false,
            checkpoint_task: None,
            checkpoint_bytes: 0,
            writer: Arc::new(()),
            pending: Vec::new(),
            directory: fs::canonicalize(directory)?,
            page_format: report.page_format,
            checkpoint_lsn: report.checkpoint_lsn,
            segment_start_lsn: active_anchor_lsn(directory)?,
            file: Some(file),
            write_buffer: Vec::with_capacity(WRITE_BATCH_BYTES + 8192 + 128),
            physical_len: fs::metadata(directory.join(NAME))?.len(),
            written_len: fs::metadata(directory.join(NAME))?.len(),
            next_lsn,
            next_txn_id: report.next_txn_id,
            durable_lsn: report.last_lsn,
            last_commit_lsn: report.last_lsn,
            commits_since_checkpoint: 0,
            active: None,
            transaction_failed: false,
            fenced: false,
            compact: Compact::default(),
            mode,
            capacity,
            inflight: None,
            spare: Vec::new(),
            extender: None,
            extend_limit: capacity,
            background_extend: background_extend_configured(),
            foreground_extends: 0,
            extend_step: EXTENT_BYTES,
            last_stamp: None,
        };
        wal.checkpoint_all_inner(report.last_lsn)?;
        Ok(wal)
    }

    /// Only for a fresh database directory (the directory lock may exist).
    /// Existing databases require the explicit offline migration path.
    pub fn create(directory: impl AsRef<Path>) -> Result<Self> {
        Self::create_format(directory.as_ref(), 1)
    }
    /// Fresh database with explicit page-LSN capability. Old V2 readers reject
    /// its retained anchor flag before recovery or any data-file modification.
    pub fn create_with_page_lsn(directory: impl AsRef<Path>) -> Result<Self> {
        Self::create_format(directory.as_ref(), 2)
    }
    /// Fresh MVCC-capable WAL. SQL integration must explicitly opt in.
    pub fn create_with_mvcc(directory: impl AsRef<Path>) -> Result<Self> {
        Self::create_format(directory.as_ref(), 3)
    }
    /// Fresh database with stable identities and versioned heap tuples.
    pub fn create_with_versioned_heap(directory: impl AsRef<Path>) -> Result<Self> {
        Self::create_format(directory.as_ref(), 4)
    }
    fn create_format(directory: &Path, page_format: u16) -> Result<Self> {
        fs::create_dir_all(directory)?;
        for entry in fs::read_dir(directory)? {
            if entry?.file_name() != "phobos.lock" {
                return Err(state(
                    "V2 creation requires a fresh database; migrate existing data explicitly",
                ));
            }
        }
        let path = directory.join(NAME);
        let mode = DurabilityMode::configured();
        let anchor = super::format::encode_anchor(
            &Record {
                txn_id: 0,
                lsn: 1,
                prev_lsn: 0,
                body: Body::Anchor {
                    checkpoint_lsn: 0,
                    next_txn_id: 1,
                    page_format,
                },
            },
            mode == DurabilityMode::WriteThrough,
        )?;
        let capacity = build_active_file(&path, &anchor, mode)?;
        let file = open_active(&path, mode)?;
        sync_directory(directory)?;
        written(anchor.len());
        Ok(Self {
            #[cfg(any(test, feature = "test-hooks"))]
            fail_next_sync: false,
            checkpoint_task: None,
            checkpoint_bytes: 0,
            writer: Arc::new(()),
            pending: Vec::new(),
            directory: fs::canonicalize(directory)?,
            page_format,
            checkpoint_lsn: 0,
            segment_start_lsn: 1,
            file: Some(file),
            write_buffer: Vec::with_capacity(WRITE_BATCH_BYTES + 8192 + 128),
            physical_len: anchor.len() as u64,
            written_len: anchor.len() as u64,
            next_lsn: 2,
            next_txn_id: 1,
            durable_lsn: 1,
            last_commit_lsn: 0,
            commits_since_checkpoint: 0,
            active: None,
            transaction_failed: false,
            fenced: false,
            compact: Compact::default(),
            mode,
            capacity,
            inflight: None,
            spare: Vec::new(),
            extender: None,
            extend_limit: capacity,
            background_extend: background_extend_configured(),
            foreground_extends: 0,
            extend_step: EXTENT_BYTES,
            last_stamp: None,
        })
    }
    /// The caller must finish recovery and checkpoint before opening a writer.
    pub fn open(directory: impl AsRef<Path>) -> Result<Self> {
        let directory = directory.as_ref();
        let report = inspect(directory.join(NAME))?;
        if report.tail != Tail::Clean
            || report.incomplete_transactions != 0
            || report.committed_transactions != 0
        {
            return Err(state(
                "V2 WAL requires recovery/checkpoint before writer open",
            ));
        }
        let mode = DurabilityMode::configured();
        let file = open_active(&directory.join(NAME), mode)?;
        // Establish durability even if a previous process left an unsynced ABORT.
        file.sync_data()?;
        let capacity = file.metadata()?.len();
        // 0.2-E: a preallocated active file ends at its valid prefix, not EOF.
        let active_len = if active_anchor_is_prealloc(directory)? {
            super::scan::inspect_file(&directory.join(NAME), true)?.valid_len
        } else {
            capacity
        };
        let next_lsn = report
            .last_lsn
            .checked_add(1)
            .ok_or_else(|| state("V2 WAL LSNs exhausted"))?;
        let mut wal = Self {
            #[cfg(any(test, feature = "test-hooks"))]
            fail_next_sync: false,
            checkpoint_task: None,
            checkpoint_bytes: 0,
            writer: Arc::new(()),
            pending: Vec::new(),
            directory: fs::canonicalize(directory)?,
            page_format: report.page_format,
            checkpoint_lsn: report.checkpoint_lsn,
            segment_start_lsn: active_anchor_lsn(directory)?,
            file: Some(file),
            write_buffer: Vec::with_capacity(WRITE_BATCH_BYTES + 8192 + 128),
            physical_len: active_len,
            written_len: active_len,
            next_lsn,
            next_txn_id: report.next_txn_id,
            durable_lsn: report.last_lsn,
            last_commit_lsn: report.checkpoint_lsn,
            commits_since_checkpoint: 0,
            active: None,
            transaction_failed: false,
            fenced: false,
            compact: Compact::default(),
            mode,
            capacity,
            inflight: None,
            spare: Vec::new(),
            extender: None,
            extend_limit: capacity,
            background_extend: background_extend_configured(),
            foreground_extends: 0,
            extend_step: EXTENT_BYTES,
            last_stamp: None,
        };
        // 0.2-D: V3 records may only follow a V3 anchor. A writer opened on a
        // cleanly shut down older WAL (no committed records remain) rewrites
        // its anchor first, so older binaries refuse this WAL from now on.
        if !active_anchor_is_v3(directory)? {
            wal.checkpoint_all_inner(wal.checkpoint_lsn)?;
            phobos_observability::event("wal.v3_anchor_upgrades", 1);
        } else if active_anchor_is_prealloc(directory)? != (mode == DurabilityMode::WriteThrough) {
            // 0.2-E: the active file is rebuilt in this writer's mode format
            // (0.2-D -> 0.2-E upgrade, or an explicit A/E switch).
            wal.checkpoint_all_inner(wal.checkpoint_lsn)?;
            phobos_observability::event("wal.mode_format_rewrites", 1);
        }
        Ok(wal)
    }
    #[must_use]
    pub fn durable_lsn(&self) -> u64 {
        self.durable_lsn
    }
    #[must_use]
    pub fn written_len(&self) -> u64 {
        self.written_len
    }
    /// The exclusive writer owner may assign a bounded ordered preparation
    /// range starting here. BEGIN still validates/advances every consumed ID.
    #[must_use]
    pub fn next_transaction_id(&self) -> u64 {
        self.next_txn_id
    }
    #[must_use]
    pub fn page_format(&self) -> u16 {
        self.page_format
    }
    #[must_use]
    pub fn checkpoint_due(&self) -> bool {
        self.commits_since_checkpoint >= 64
            || self.written_len.saturating_sub(self.checkpoint_bytes) >= 16 * 1024 * 1024
    }
    /// Offline, backup-first capability migration after complete recovery. No
    /// historical COMMIT may remain: all old-format effects must already be forced.
    pub fn enable_page_lsn(&mut self) -> Result<()> {
        self.available()?;
        let report = inspect(self.directory.join(NAME))?;
        if self.active.is_some()
            || self.page_format != 1
            || report.tail != Tail::Clean
            || report.committed_transactions != 0
            || report.incomplete_transactions != 0
        {
            return Err(state(
                "page-LSN migration requires a recovered legacy-page V2 anchor",
            ));
        }
        self.page_format = 2;
        let result = self.checkpoint_all(self.last_commit_lsn);
        if result.is_err() {
            self.fenced = true;
        }
        result
    }
    #[must_use]
    pub fn last_commit_lsn(&self) -> u64 {
        self.last_commit_lsn
    }
    #[must_use]
    pub fn is_fenced(&self) -> bool {
        self.fenced
    }

    pub fn begin_mvcc(&mut self, stable_id: u64) -> Result<u64> {
        if self.page_format < 3 || stable_id == 0 {
            return Err(state("MVCC identity requires capability 3"));
        }
        let id = self.begin_with_id_inner(self.next_txn_id, false)?;
        self.append(Body::MvccIdentity(stable_id))?;
        // The identity is part of the durable reservation evidence used to
        // prevent a stable transaction ID from being reissued after a crash.
        // Coalesce it with BEGIN in one physical write. (0.2-E Mode E: it is
        // written with the batch by the force leader; status reservations are
        // lazily written and recover as aborted, see StatusFile::reserve.)
        self.stage_flush()?;
        Ok(id)
    }
    pub fn begin(&mut self) -> Result<u64> {
        self.begin_with_id(self.next_txn_id)
    }
    pub fn begin_with_id(&mut self, id: u64) -> Result<u64> {
        self.begin_with_id_inner(id, true)
    }

    fn begin_with_id_inner(&mut self, id: u64, flush: bool) -> Result<u64> {
        self.rotate_segment_if_needed()?;
        self.available()?;
        self.check_physical_len()?;
        if self.active.is_some() || id < self.next_txn_id {
            return Err(state("active or reused V2 transaction ID"));
        }
        let next = id
            .checked_add(1)
            .ok_or_else(|| state("V2 transaction IDs exhausted"))?;
        let record = Record {
            txn_id: id,
            lsn: self.next_lsn,
            prev_lsn: 0,
            body: Body::Begin,
        };
        self.emit(&record)?;
        if flush {
            // Preserve the existing incomplete-transaction recovery evidence
            // for callers using the non-MVCC transaction API.
            self.stage_flush()?;
        }
        self.next_txn_id = next;
        self.compact.transaction.clear();
        self.active = Some(Transaction::new(id, record.lsn));
        self.transaction_failed = false;
        Ok(id)
    }
    pub fn append(&mut self, body: Body) -> Result<u64> {
        if matches!(body, Body::PageDelta { .. }) {
            // Only the writer may decide that a delta's base is safe.
            self.transaction_failed = true;
            return Err(state(
                "page deltas are only appended by append_prepared_page_with_base",
            ));
        }
        self.append_inner(body)
    }
    fn append_inner(&mut self, body: Body) -> Result<u64> {
        if self.page_format >= 3
            && !matches!(body, Body::MvccIdentity(_))
            && self
                .active
                .as_ref()
                .is_some_and(|tx| tx.mvcc_id().is_none())
        {
            return Err(state("MVCC data requires a preceding identity mapping"));
        }
        if matches!(body, Body::MvccIdentity(_)) && self.page_format < 3 {
            return Err(state("MVCC mapping requires capability 3"));
        }
        if self.page_format >= 2 {
            if let Body::Page {
                file, page, image, ..
            } = &body
            {
                super::page_format::validate_capability(self.page_format, *file, image)?;
                if !self.carries_next_lsn(*file, *page, image) {
                    self.transaction_failed = true;
                    return Err(state("page image does not carry its WAL record LSN"));
                }
            }
        }
        if matches!(
            body,
            Body::Anchor { .. }
                | Body::Begin
                | Body::Commit
                | Body::Abort
                | Body::Checkpoint { .. }
        ) {
            self.transaction_failed = true;
            return Err(state(
                "use V2 transaction control methods for control records",
            ));
        }
        let result = self.append_transaction(body, false);
        if result.is_err() {
            self.transaction_failed = true;
        }
        result
    }
    /// Stamp and append exactly the image returned to the private page owner.
    /// The owner must freeze it until durable installation or rollback.
    pub fn append_page(
        &mut self,
        action: PageAction,
        file: FileId,
        page: u64,
        image: &mut [u8; 8192],
    ) -> Result<u64> {
        self.stamp_next_page(file, page, image)?;
        self.append_prepared_page(action, file, page, image)
    }

    /// Assign the LSN of the next WAL record and refresh the page checksum
    /// without appending it. The caller retains exclusive writer ownership
    /// until `append_prepared_page` consumes that exact image.
    pub fn stamp_next_page(
        &mut self,
        file: FileId,
        page: u64,
        image: &mut [u8; 8192],
    ) -> Result<u64> {
        if self.page_format >= 2 {
            if let Err(error) = super::page_format::stamp(file, page, image, self.next_lsn) {
                self.transaction_failed = true;
                return Err(error);
            }
            self.last_stamp = super::page_format::stored_checksum(file, page, image)
                .ok()
                .map(|crc| (file, page, self.next_lsn, crc));
        }
        Ok(self.next_lsn)
    }

    /// The page image carries this record's LSN with a valid checksum. 0.2-G:
    /// for the image this writer stamped for exactly this record (same file,
    /// page and LSN; the stamped LSN, scheme and checksum fields unchanged)
    /// the CRC computed by `stamp` is not recomputed. Every other image takes
    /// the complete check. Installation verifies the full checksum again
    /// before the image can enter the committed store.
    fn carries_next_lsn(&self, file: FileId, page: u64, image: &[u8; 8192]) -> bool {
        if let Some((stamped_file, stamped_page, lsn, crc)) = self.last_stamp {
            if stamped_file == file
                && stamped_page == page
                && lsn == self.next_lsn
                && image[7] == crate::page_checksum::CRC32C
                && super::page_format::stored_lsn(file, page, image).ok() == Some(lsn)
                && super::page_format::stored_checksum(file, page, image).ok() == Some(crc)
            {
                phobos_observability::event("wal.stamp_token_hits", 1);
                return true;
            }
        }
        super::page_format::lsn(file, page, image).ok() == Some(self.next_lsn)
    }

    /// Append a page already stamped with this record's final LSN.
    pub fn append_prepared_page(
        &mut self,
        action: PageAction,
        file: FileId,
        page: u64,
        image: &[u8; 8192],
    ) -> Result<u64> {
        self.append(Body::Page {
            action,
            file,
            page,
            image: Box::new(*image),
        })
    }

    /// 0.2-D: append a stamped page image, as a compact delta against `base`
    /// when that is safe and smaller, otherwise as a full image. `base` must be
    /// the page's current committed-or-pending image (the one this change was
    /// made to); `None` for a page this transaction allocated. The writer, not
    /// the caller, decides: a delta is written only if `base` is exactly the
    /// last image this segment logged for the page (LSN and validated page
    /// checksum), and only after the delta reproduced `image` from `base`.
    pub fn append_prepared_page_with_base(
        &mut self,
        action: PageAction,
        file: FileId,
        page: u64,
        image: &[u8; 8192],
        base: Option<&[u8; 8192]>,
    ) -> Result<u64> {
        let Some(base) = base.filter(|_| self.page_format >= 2 && action != PageAction::Initialize)
        else {
            phobos_observability::event("wal.fpi_no_base", 1);
            return self.append_prepared_page(action, file, page, image);
        };
        let encode = phobos_observability::span("wal.delta_encode");
        let Some((base_lsn, base_checksum)) = self.delta_base(file, page, base) else {
            drop(encode);
            return self.append_prepared_page(action, file, page, image);
        };
        let (lsn_at, checksum_at) = super::page_format::stamped_fields(file, page)?;
        let result_checksum = super::page_format::stored_checksum(file, page, image)?;
        let masked = [(7, 1), (lsn_at, 8), (checksum_at, 4)];
        let mut ops = std::mem::take(&mut self.compact.ops);
        ops.clear();
        let encoded = self
            .compact
            .encoder
            .encode(base, image, &masked, DELTA_LIMIT, &mut ops);
        // Small programs always beat an image; only large ones are compared.
        if !encoded
            || (ops.len() > 256 && 1 + ops.len() >= super::delta::sparse_len(image).min(8192))
        {
            self.compact.ops = ops;
            phobos_observability::event("wal.fpi_not_smaller", 1);
            drop(encode);
            return self.append_prepared_page(action, file, page, image);
        }
        drop(encode);
        if self.page_format >= 2 && !self.carries_next_lsn(file, page, image) {
            self.compact.ops = ops;
            self.transaction_failed = true;
            return Err(state("page image does not carry its WAL record LSN"));
        }
        if let Err(error) = super::page_format::validate_capability(self.page_format, file, image) {
            self.compact.ops = ops;
            self.transaction_failed = true;
            return Err(error);
        }
        let body = Body::PageDelta {
            action,
            file,
            page,
            base_lsn,
            base_checksum,
            result_checksum,
            ops,
        };
        let result = self.append_inner(body);
        if result.is_ok() {
            phobos_observability::event("wal.page_deltas", 1);
        }
        result
    }

    /// The (LSN, page checksum) of `base` when it is exactly the last image
    /// this segment logged for the page; `None` (full image) otherwise.
    fn delta_base(&self, file: FileId, page: u64, base: &[u8; 8192]) -> Option<(u64, u32)> {
        let Some(&(lsn, checksum)) = self.compact.pages.get(&(file, page)) else {
            phobos_observability::event("wal.fpi_first_touch", 1);
            return None;
        };
        // Validates the complete base page checksum and identity.
        let base_lsn = super::page_format::lsn(file, page, base).ok();
        let base_checksum = super::page_format::stored_checksum(file, page, base).ok();
        if base[7] != crate::page_checksum::CRC32C
            || base_lsn != Some(lsn)
            || base_checksum != Some(checksum)
            || lsn < self.segment_start_lsn
            || lsn >= self.next_lsn
        {
            phobos_observability::event("wal.fpi_base_mismatch", 1);
            return None;
        }
        Some((lsn, checksum))
    }
    pub fn commit(&mut self) -> Result<DurableCommit> {
        let _span = phobos_observability::span("wal.commit_latency");
        if !self.pending.is_empty() {
            return Err(state(
                "pending commits must be forced before synchronous COMMIT",
            ));
        }
        let ticket = self.append_commit()?;
        Ok(self.force_commits(&[ticket])?.remove(0))
    }

    /// Finish a transaction chain without forcing it or permitting page writes.
    /// The owner must retain all tickets and freeze their private page images.
    pub fn append_commit(&mut self) -> Result<PendingCommit> {
        self.available()?;
        let id = self
            .active
            .as_ref()
            .ok_or_else(|| state("V2 COMMIT without BEGIN"))?
            .id();
        let mvcc_id = self.active.as_ref().and_then(Transaction::mvcc_id);
        if self.page_format >= 3 && mvcc_id.is_none() {
            return Err(state("MVCC COMMIT requires identity mapping"));
        }
        phobos_observability::certification_crash("v2_before_commit_record");
        phobos_observability::certification_crash("before_commit_record");
        if phobos_observability::certification_requested("v2_after_redo_sync_before_commit") {
            self.sync_prefix()?;
            phobos_observability::certification_crash("v2_after_redo_sync_before_commit");
        }
        let lsn = match self.append_transaction(Body::Commit, false) {
            Ok(lsn) => lsn,
            Err(error) => {
                self.transaction_failed = true;
                return Err(error);
            }
        };
        // Preserve the established process-crash contract: once a complete
        // COMMIT record has been appended, the complete transaction prefix is
        // visible to recovery even before the later durability force. The
        // bounded buffer still coalesces all records of this transaction.
        // 0.2-E Mode E: no I/O here; the force leader writes the batch
        // (a process crash before that loses only unacknowledged commits).
        if let Err(error) = self.stage_flush() {
            self.transaction_failed = true;
            return Err(error);
        }
        self.active = None;
        self.compact.transaction.clear();
        self.last_commit_lsn = lsn;
        self.commits_since_checkpoint = self.commits_since_checkpoint.saturating_add(1);
        phobos_observability::certification_crash("v2_after_commit_record");
        phobos_observability::certification_crash("after_commit_record");
        self.pending.push((id, lsn));
        Ok(PendingCommit {
            mvcc_id,
            txn_id: id,
            lsn,
            writer: Arc::clone(&self.writer),
        })
    }

    /// Force exactly the currently submitted batch under exclusive writer
    /// ownership. Validate the whole batch before I/O; a failed force fences
    /// every ticket and yields no receipt. An active successor's written prefix
    /// can become durable incidentally, but never earns a COMMIT receipt.
    pub fn force_commits(&mut self, tickets: &[PendingCommit]) -> Result<Vec<DurableCommit>> {
        self.available()?;
        if tickets.len() != self.pending.len()
            || tickets.iter().zip(&self.pending).any(|(ticket, expected)| {
                !Arc::ptr_eq(&ticket.writer, &self.writer)
                    || (ticket.txn_id, ticket.lsn) != *expected
            })
        {
            return Err(state(
                "WAL force requires the complete ordered pending batch",
            ));
        }
        if tickets.is_empty() {
            return Ok(Vec::new());
        }
        phobos_observability::certification_crash("before_wal_sync");
        phobos_observability::synchronization_boundary("wal.before_force", &self.directory);
        self.sync_prefix()?;
        phobos_observability::synchronization_boundary("wal.after_force", &self.directory);
        phobos_observability::certification_crash("after_wal_sync");
        let receipts = tickets
            .iter()
            .map(|ticket| DurableCommit {
                mvcc_id: ticket.mvcc_id,
                txn_id: ticket.txn_id,
                lsn: ticket.lsn,
                directory: self.directory.clone(),
                page_format: self.page_format,
            })
            .collect();
        phobos_observability::event("wal.group_commits", tickets.len() as u64);
        phobos_observability::event("wal.group_forces", 1);
        phobos_observability::event(
            match tickets.len() {
                1 => "wal.group_size_1",
                2 => "wal.group_size_2",
                3..=4 => "wal.group_size_3_4",
                5..=8 => "wal.group_size_5_8",
                9..=16 => "wal.group_size_9_16",
                _ => "wal.group_size_17_plus",
            },
            1,
        );
        self.pending.clear();
        Ok(receipts)
    }
    /// 0.2-C group commit: capture a force of the complete written prefix.
    /// `None` when the prefix is already durable. The caller performs
    /// `ForceIntent::sync` without holding this writer and then calls
    /// `complete_force`; appends by later transactions may proceed meanwhile.
    pub fn begin_force(&mut self) -> Result<Option<ForceIntent>> {
        if self.mode == DurabilityMode::WriteThrough {
            return self.begin_write_through();
        }
        self.available()?;
        self.flush_buffer()?;
        let target = self.next_lsn - 1;
        if target <= self.durable_lsn {
            return Ok(None);
        }
        let file = self.file.as_ref().expect("available WAL file");
        let consistent = file.metadata().map(|metadata| {
            metadata.len() == self.written_len && self.physical_len == self.written_len
        });
        let duplicate = match consistent {
            Ok(true) => file.try_clone(),
            Ok(false) => Err(std::io::Error::other(
                "WAL physical length changed before force",
            )),
            Err(error) => Err(error),
        };
        #[cfg(any(test, feature = "test-hooks"))]
        let injected_failure = std::mem::take(&mut self.fail_next_sync);
        #[cfg(not(any(test, feature = "test-hooks")))]
        let injected_failure = false;
        match duplicate {
            Ok(file) => Ok(Some(ForceIntent {
                file,
                target,
                writer: Arc::clone(&self.writer),
                injected_failure,
                write: None,
                #[cfg(feature = "test-hooks")]
                directory: self.directory.clone(),
            })),
            Err(error) => {
                self.fenced = true;
                Err(error.into())
            }
        }
    }

    /// Record the outcome of an out-of-lock force. A failed sync fences the
    /// writer: every not-yet-receipted commit is durability-uncertain.
    pub fn complete_force(
        &mut self,
        intent: ForceIntent,
        result: std::io::Result<()>,
    ) -> Result<()> {
        if !Arc::ptr_eq(&intent.writer, &self.writer) {
            self.fenced = true;
            return Err(state("WAL force intent from another writer lifetime"));
        }
        if let Err(error) = result {
            self.fenced = true;
            return Err(error.into());
        }
        self.available()?;
        if let Some((bytes, offset)) = intent.write {
            // The range began at the durable offset when it was reserved; an
            // in-lock durable advance may since have rewritten it (identical
            // bytes) and moved past it, never the other way round.
            let end = offset + bytes.len() as u64;
            if offset > self.physical_len {
                self.fenced = true;
                return Err(state(
                    "WAL write-through range does not follow the durable prefix",
                ));
            }
            if self
                .inflight
                .as_ref()
                .is_some_and(|inflight| Arc::ptr_eq(inflight, &bytes))
            {
                self.inflight = None;
            }
            self.physical_len = self.physical_len.max(end);
            if let Ok(mut recycled) = Arc::try_unwrap(bytes) {
                recycled.clear();
                if recycled.capacity() > self.spare.capacity() {
                    self.spare = recycled;
                }
            }
        }
        self.durable_lsn = self.durable_lsn.max(intent.target);
        Ok(())
    }

    /// 0.2-E Mode E half of `begin_force`: reserve every buffered byte as the
    /// one in-flight range `[physical_len, written_len)`, inside the durable,
    /// zero-filled capacity. No I/O on the commit path except a rare extent.
    fn begin_write_through(&mut self) -> Result<Option<ForceIntent>> {
        self.available()?;
        let target = self.next_lsn - 1;
        if target <= self.durable_lsn {
            return Ok(None);
        }
        if self.inflight.is_some() {
            return Err(state("a WAL write-through range is already in flight"));
        }
        self.check_physical_len()?;
        self.ensure_capacity(self.written_len)?;
        self.maybe_start_extender();
        let duplicate = self.file.as_ref().expect("available WAL file").try_clone();
        let file = match duplicate {
            Ok(file) => file,
            Err(error) => {
                self.fenced = true;
                return Err(error.into());
            }
        };
        let fresh = if self.spare.capacity() > 0 {
            std::mem::take(&mut self.spare)
        } else {
            Vec::with_capacity(256 * 1024)
        };
        let bytes = Arc::new(std::mem::replace(&mut self.write_buffer, fresh));
        if self.physical_len + bytes.len() as u64 != self.written_len {
            self.fenced = true;
            return Err(state("WAL buffer does not match the logical WAL length"));
        }
        self.inflight = Some(Arc::clone(&bytes));
        phobos_observability::synchronization_boundary("wal.e_reserved", &self.directory);
        #[cfg(any(test, feature = "test-hooks"))]
        let injected_failure = std::mem::take(&mut self.fail_next_sync);
        #[cfg(not(any(test, feature = "test-hooks")))]
        let injected_failure = false;
        Ok(Some(ForceIntent {
            file,
            target,
            writer: Arc::clone(&self.writer),
            injected_failure,
            write: Some((bytes, self.physical_len)),
            #[cfg(feature = "test-hooks")]
            directory: self.directory.clone(),
        }))
    }

    /// Mode A: buffered bytes go to the OS cache now (0.2-D). Mode E: they
    /// stay in the batch buffer for the force leader.
    fn stage_flush(&mut self) -> Result<()> {
        match self.mode {
            DurabilityMode::Flush => self.flush_buffer(),
            DurabilityMode::WriteThrough => self.available(),
        }
    }

    /// Mode E: grow the zero-filled capacity (whole extents) so that `end`
    /// fits, flushing the new size before any record is written into it.
    /// 0.2-F: a finished background extent is adopted first; a running one
    /// is waited for (never a second concurrent extender); the foreground
    /// extension remains the always-correct fallback.
    fn ensure_capacity(&mut self, end: u64) -> Result<()> {
        if end <= self.capacity {
            self.poll_extender(false);
            if end <= self.capacity {
                return Ok(());
            }
        }
        if self.extender.is_some() {
            let _span = phobos_observability::span("wal.extend_wait");
            self.grow_extend_step();
            self.poll_extender(true);
            if end <= self.capacity {
                return Ok(());
            }
        }
        let _span = phobos_observability::span("wal.extend");
        phobos_observability::event("wal.extends_foreground", 1);
        self.foreground_extends += 1;
        if self.background_extend {
            self.grow_extend_step();
        }
        let target = end.div_ceil(EXTENT_BYTES) * EXTENT_BYTES;
        let (capacity, limit) = (self.capacity, self.extend_limit);
        let result = (|| -> std::io::Result<u64> {
            // A separate ordinary handle: one flush for the whole extent.
            let file = OpenOptions::new()
                .write(true)
                .open(self.directory.join(NAME))?;
            // A failed background extension may have left zeros past the
            // capacity, never past its bound.
            let actual = file.metadata()?.len();
            if actual < capacity || actual > limit {
                return Err(std::io::Error::other("WAL capacity changed unexpectedly"));
            }
            let target = target.max(actual);
            zero_fill(&file, capacity, target)?;
            phobos_observability::synchronization_boundary("wal.extent_zeroed", &self.directory);
            file.sync_all()?;
            Ok(target)
        })();
        let target = match result {
            Ok(target) => target,
            Err(error) => {
                self.fenced = true;
                return Err(error.into());
            }
        };
        phobos_observability::event("wal.extents", (target - self.capacity) / EXTENT_BYTES);
        self.capacity = target;
        self.extend_limit = target;
        Ok(())
    }

    /// 0.2-F: adopt a finished background extension (or, with `wait`, the
    /// running one). Capacity advances only after the worker's zero fill and
    /// flush both succeeded; a failure leaves capacity unchanged (the next
    /// foreground extension rewrites the range).
    fn poll_extender(&mut self, wait: bool) {
        let finished = self
            .extender
            .as_ref()
            .is_some_and(|extender| wait || extender.handle.is_finished());
        if !finished {
            return;
        }
        let extender = self.extender.take().expect("checked above");
        match extender.handle.join() {
            Ok(Ok(())) if extender.base == self.capacity => {
                phobos_observability::event("wal.extents_background", 1);
                self.capacity = extender.target;
                self.extend_limit = extender.target;
            }
            _ => phobos_observability::event("wal.extend_background_failures", 1),
        }
    }

    /// 0.2-F: when less than `EXTEND_AHEAD_BYTES` of prepared capacity is
    /// left, start the one background extender for the next extent. It runs
    /// outside the writer lock and outside every commit's critical path; no
    /// acknowledgement ever depends on it.
    fn maybe_start_extender(&mut self) {
        if self.mode != DurabilityMode::WriteThrough
            || !self.background_extend
            || self.fenced
            || self.extender.is_some()
            || self.capacity.saturating_sub(self.written_len)
                >= EXTEND_AHEAD_BYTES.max(self.extend_step / 2)
            || self.extend_limit != self.capacity
        {
            return;
        }
        let base = self.capacity;
        let target = base + self.extend_step;
        let path = self.directory.join(NAME);
        #[cfg(feature = "test-hooks")]
        let directory = self.directory.clone();
        let spawned = std::thread::Builder::new()
            .name("phobos-wal-extend".into())
            .spawn(move || -> std::io::Result<()> {
                let _span = phobos_observability::span("wal.extend_background");
                // 0.2-H slow-request trace: background extent activity.
                let _activity = phobos_observability::trace::activity(
                    &phobos_observability::trace::EXTENT_ACTIVITY,
                );
                #[cfg(test)]
                std::thread::sleep(std::time::Duration::from_millis(
                    EXTENDER_DELAY_MS_FOR_TEST.load(std::sync::atomic::Ordering::Relaxed),
                ));
                let file = OpenOptions::new().write(true).open(&path)?;
                if file.metadata()?.len() != base {
                    return Err(std::io::Error::other("WAL capacity changed unexpectedly"));
                }
                zero_fill(&file, base, target)?;
                #[cfg(feature = "test-hooks")]
                phobos_observability::synchronization_boundary(
                    "wal.extent_background_zeroed",
                    &directory,
                );
                file.sync_all()
            });
        if let Ok(handle) = spawned {
            phobos_observability::event("wal.extender_starts", 1);
            self.extend_limit = target;
            self.extender = Some(Extender {
                base,
                target,
                handle,
            });
        }
    }

    /// 0.2-G: the extender fell behind the commit path: prepare larger
    /// extensions (fewer zero-fill flushes) until the file is replaced.
    fn grow_extend_step(&mut self) {
        if self.extend_step < MAX_EXTEND_STEP {
            self.extend_step = (self.extend_step * 2).min(MAX_EXTEND_STEP);
            phobos_observability::event("wal.extend_step_grow", 1);
        }
    }

    /// 0.2-F: the active file is about to be replaced or closed; the
    /// extender (which holds its own handle to it) finishes first.
    fn join_extender(&mut self) {
        self.poll_extender(true);
    }

    /// Mode E in-lock durable advance: write-through every byte from the
    /// durable offset (including an in-flight range, whose bytes are
    /// identical) to the logical end, then advance the durable frontier.
    fn durable_advance(&mut self) -> Result<()> {
        self.available()?;
        let _span = phobos_observability::span("wal.fsync");
        phobos_observability::certification_crash("v2_before_sync");
        #[cfg(any(test, feature = "test-hooks"))]
        let injected_failure = std::mem::take(&mut self.fail_next_sync);
        #[cfg(not(any(test, feature = "test-hooks")))]
        let injected_failure = false;
        let start = self.physical_len;
        let end = self.written_len;
        let result = (|| -> Result<()> {
            if injected_failure {
                return Err(std::io::Error::other("injected WAL force failure").into());
            }
            if end > start {
                self.check_physical_len()?;
                self.ensure_capacity(end)?;
                let file = self.file.as_ref().expect("available WAL file");
                let mut position = start;
                if let Some(inflight) = &self.inflight {
                    write_pieces(file, inflight, position)?;
                    position += inflight.len() as u64;
                }
                write_pieces(file, &self.write_buffer, position)?;
                if position + self.write_buffer.len() as u64 != end {
                    return Err(state("WAL buffer does not match the logical WAL length"));
                }
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.fenced = true;
            return Err(error);
        }
        self.physical_len = end;
        self.inflight = None;
        self.write_buffer.clear();
        self.durable_lsn = self.next_lsn - 1;
        phobos_observability::certification_crash("v2_after_sync");
        self.maybe_start_extender();
        Ok(())
    }

    /// Receipts for the oldest pending COMMITs, in order, once the durable
    /// frontier covers them. Later appended commits stay pending.
    pub fn receipts_for(&mut self, tickets: &[PendingCommit]) -> Result<Vec<DurableCommit>> {
        self.available()?;
        if tickets.len() > self.pending.len()
            || tickets.iter().zip(&self.pending).any(|(ticket, expected)| {
                !Arc::ptr_eq(&ticket.writer, &self.writer)
                    || (ticket.txn_id, ticket.lsn) != *expected
                    || ticket.lsn > self.durable_lsn
            })
        {
            return Err(state(
                "WAL receipts require the oldest durable pending commits in order",
            ));
        }
        let receipts = tickets
            .iter()
            .map(|ticket| DurableCommit {
                mvcc_id: ticket.mvcc_id,
                txn_id: ticket.txn_id,
                lsn: ticket.lsn,
                directory: self.directory.clone(),
                page_format: self.page_format,
            })
            .collect();
        self.pending.drain(..tickets.len());
        Ok(receipts)
    }

    #[must_use]
    pub fn has_pending_commits(&self) -> bool {
        !self.pending.is_empty()
    }

    /// Segment rotation or checkpoint completion needs a quiescent writer.
    #[must_use]
    pub fn maintenance_due(&self) -> bool {
        self.written_len >= SEGMENT_BYTES || self.checkpoint_task_finished()
    }

    pub fn abort(&mut self) -> Result<()> {
        // Images of an aborted chain are never replayed: never a delta base.
        self.compact.forget_transaction();
        self.append_transaction(Body::Abort, true)?;
        self.stage_flush()?;
        self.active = None;
        self.transaction_failed = false;
        Ok(())
    }

    /// Rotate only after the caller has forced every committed data/metadata
    /// change through `applied_lsn`. The retained anchor preserves version and IDs.
    pub fn checkpoint_all(&mut self, applied_lsn: u64) -> Result<()> {
        if self.page_format >= 3 {
            return Err(state("MVCC checkpoint requires visibility drain"));
        }
        self.checkpoint_all_inner(applied_lsn)
    }
    /// Status owner forces its records and returns its durable publication frontier.
    pub fn checkpoint_with_visibility(
        &mut self,
        applied_lsn: u64,
        drain: impl FnOnce(&Path) -> Result<u64>,
    ) -> Result<()> {
        if self.page_format < 3 {
            return Err(state("visibility barrier requires MVCC capability"));
        }
        let durable = drain(&self.directory)?;
        if durable < self.last_commit_lsn {
            return Err(state("visibility state is behind WAL retirement"));
        }
        self.checkpoint_all_inner(applied_lsn)
    }
    fn checkpoint_all_inner(&mut self, applied_lsn: u64) -> Result<()> {
        let _span = phobos_observability::span("checkpoint.wal_rotation");
        let _activity = phobos_observability::trace::activity(
            &phobos_observability::trace::CHECKPOINT_ACTIVITY,
        );
        self.available()?;
        if self.active.is_some()
            || !self.pending.is_empty()
            || self.inflight.is_some()
            || applied_lsn < self.last_commit_lsn
            || applied_lsn > self.durable_lsn
        {
            return Err(state(
                "V2 checkpoint would discard unapplied or unsynced commits",
            ));
        }
        if let Err(error) = self.cancel_checkpoint() {
            self.fenced = true;
            return Err(error);
        }
        let next = self
            .next_lsn
            .checked_add(1)
            .ok_or_else(|| state("V2 WAL LSNs exhausted"))?;
        let anchor = super::format::encode_anchor(
            &Record {
                txn_id: 0,
                lsn: self.next_lsn,
                prev_lsn: 0,
                body: Body::Anchor {
                    checkpoint_lsn: applied_lsn,
                    next_txn_id: self.next_txn_id,
                    page_format: self.page_format,
                },
            },
            self.mode == DurabilityMode::WriteThrough,
        )?;
        let temporary = self.directory.join(TEMP);
        let mode = self.mode;
        let prepared = (|| -> Result<u64> {
            let capacity = phobos_observability::measure("checkpoint.wal_force", || {
                build_active_file(&temporary, &anchor, mode)
            })?;
            phobos_observability::certification_crash("v2_checkpoint_prepared");
            Ok(capacity)
        })();
        let capacity = match prepared {
            Ok(capacity) => capacity,
            Err(error) => {
                self.fenced = true;
                let _ = fs::remove_file(&temporary);
                return Err(error);
            }
        };
        // Close our Windows WAL handle; replacement must never remove the target
        // first. A crash must leave either the old WAL or the complete new anchor.
        self.join_extender();
        drop(self.file.take());
        let replaced_start = self.segment_start_lsn;
        let replaced = (|| -> Result<File> {
            // 0.2-I.2: the checkpoint frontier is local; a replication slot may
            // still need records it covers. Keep them (outside the recovery
            // path) before the replacement makes the active file unreachable.
            let frontier = super::retention::frontier(&self.directory)?;
            let kept = super::retention::preserve_active(&self.directory, frontier)?;
            fs::rename(&temporary, self.directory.join(NAME))?;
            phobos_observability::certification_crash("v2_checkpoint_replaced");
            let file = open_active(&self.directory.join(NAME), mode)?;
            phobos_observability::measure("checkpoint.wal_force", || {
                phobos_observability::measure("wal.fsync", || file.sync_all())
            })?;
            sync_directory(&self.directory)?;
            super::retention::finish_preserve(kept)?;
            super::retention::retire_sealed(&self.directory, frontier, replaced_start)?;
            let prunable = super::retention::prunable(&self.directory, frontier)?;
            super::retention::prune(&self.directory, &prunable)?;
            cleanup_retired(&self.directory)?;
            Ok(file)
        })();
        match replaced {
            Ok(file) => {
                self.file = Some(file);
                self.write_buffer.clear();
                self.capacity = capacity;
                self.extend_limit = capacity;
                self.extend_step = EXTENT_BYTES;
                self.written_len = anchor.len() as u64;
                self.physical_len = self.written_len;
                self.durable_lsn = self.next_lsn;
                self.next_lsn = next;
                self.commits_since_checkpoint = 0;
                self.checkpoint_bytes = self.written_len;
                self.checkpoint_lsn = applied_lsn;
                self.segment_start_lsn = self.next_lsn - 1;
                self.compact.reset_segment();
                written(anchor.len());
                Ok(())
            }
            Err(error) => {
                self.fenced = true;
                Err(error)
            }
        }
    }

    fn rotate_segment_if_needed(&mut self) -> Result<()> {
        if self.written_len < SEGMENT_BYTES || !self.pending.is_empty() {
            return Ok(());
        }
        self.rotate_segment()
    }

    fn rotate_segment(&mut self) -> Result<()> {
        let _span = phobos_observability::span("wal.segment_rotate");
        self.available()?;
        if self.active.is_some() || !self.pending.is_empty() || self.inflight.is_some() {
            return Err(state(
                "WAL segment rotation requires a transaction boundary",
            ));
        }
        self.sync_prefix()?;
        let anchor_lsn = self.next_lsn;
        let anchor = super::format::encode_anchor(
            &Record {
                txn_id: 0,
                lsn: anchor_lsn,
                prev_lsn: 0,
                body: Body::Anchor {
                    checkpoint_lsn: self.checkpoint_lsn,
                    next_txn_id: self.next_txn_id,
                    page_format: self.page_format,
                },
            },
            self.mode == DurabilityMode::WriteThrough,
        )?;
        let segment = self
            .directory
            .join(format!("phobos.wal.{:016x}.seg", self.segment_start_lsn));
        // 0.2-E: the new active file is complete (anchor + zero extent,
        // flushed) under a temporary name before the old one is sealed, so a
        // crash leaves either the old active file, no active file (repaired
        // from the newest sealed segment) or the complete new one.
        let temporary = self.directory.join(TEMP);
        let mode = self.mode;
        let capacity = match build_active_file(&temporary, &anchor, mode) {
            Ok(capacity) => capacity,
            Err(error) => {
                self.fenced = true;
                let _ = fs::remove_file(&temporary);
                return Err(error);
            }
        };
        phobos_observability::certification_crash("v2_rotation_prepared");
        phobos_observability::synchronization_boundary("wal.rotation_prepared", &self.directory);
        self.join_extender();
        drop(self.file.take());
        let rotated = (|| -> Result<File> {
            fs::rename(self.directory.join(NAME), &segment)?;
            phobos_observability::certification_crash("v2_rotation_sealed");
            phobos_observability::synchronization_boundary("wal.rotation_sealed", &self.directory);
            fs::rename(&temporary, self.directory.join(NAME))?;
            let file = open_active(&self.directory.join(NAME), mode)?;
            // Windows: commits both renames in the NTFS log; POSIX: directory.
            file.sync_all()?;
            sync_directory(&self.directory)?;
            Ok(file)
        })();
        match rotated {
            Ok(file) => {
                self.file = Some(file);
                self.capacity = capacity;
                self.extend_limit = capacity;
                self.extend_step = EXTENT_BYTES;
                self.write_buffer.clear();
                self.written_len = anchor.len() as u64;
                self.physical_len = self.written_len;
                self.segment_start_lsn = anchor_lsn;
                self.compact.reset_segment();
                self.next_lsn = anchor_lsn
                    .checked_add(1)
                    .ok_or_else(|| state("V2 WAL LSNs exhausted"))?;
                self.durable_lsn = anchor_lsn;
                self.checkpoint_bytes = self.written_len;
                phobos_observability::event("wal.segment_rotations", 1);
                written(anchor.len());
                Ok(())
            }
            Err(error) => {
                self.fenced = true;
                Err(error)
            }
        }
    }

    /// Test-only: make every buffered byte durable now (in-lock force).
    #[cfg(any(test, feature = "test-hooks"))]
    pub fn sync_for_test(&mut self) -> Result<()> {
        self.sync_prefix()
    }
    #[must_use]
    pub fn durability_mode(&self) -> DurabilityMode {
        self.mode
    }

    /// 0.2-F test view: (capacity, extension bound, extender outstanding,
    /// foreground extensions so far).
    #[cfg(test)]
    pub(super) fn extension_state_for_test(&self) -> (u64, u64, bool, u64) {
        (
            self.capacity,
            self.extend_limit,
            self.extender.is_some(),
            self.foreground_extends,
        )
    }
    #[cfg(test)]
    pub(super) fn extend_step_for_test(&self) -> u64 {
        self.extend_step
    }
    #[cfg(test)]
    pub(super) fn grow_extend_step_for_test(&mut self) {
        self.grow_extend_step();
    }
    /// Test: the commit path needs capacity through `end` now.
    #[cfg(test)]
    pub(super) fn ensure_capacity_for_test(&mut self, end: u64) -> Result<()> {
        self.ensure_capacity(end)
    }
    #[cfg(test)]
    pub(super) fn wait_for_extender_for_test(&mut self) {
        self.join_extender();
    }
    #[cfg(test)]
    pub(super) fn set_background_extend_for_test(&mut self, enabled: bool) {
        self.background_extend = enabled;
    }
    /// 0.2-F test: the state a failed background extension leaves behind —
    /// `zeros` bytes written past the capacity, never adopted.
    #[cfg(test)]
    pub(super) fn simulate_failed_extension_for_test(&mut self, zeros: u64) {
        self.join_extender();
        let file = OpenOptions::new()
            .write(true)
            .open(self.directory.join(NAME))
            .unwrap();
        zero_fill(&file, self.capacity, self.capacity + zeros).unwrap();
        self.extend_limit = self.capacity + EXTENT_BYTES;
    }

    #[cfg(any(test, feature = "test-hooks"))]
    pub fn rotate_segment_for_test(&mut self) -> Result<()> {
        self.rotate_segment()
    }

    fn available(&self) -> Result<()> {
        if self.fenced || self.file.is_none() {
            Err(state(
                "V2 WAL writer fenced; close and recover before further use",
            ))
        } else {
            Ok(())
        }
    }
    fn append_transaction(&mut self, body: Body, allow_failed: bool) -> Result<u64> {
        self.available()?;
        if self.transaction_failed && !allow_failed {
            return Err(state("V2 transaction failed; ABORT required"));
        }
        let mut candidate = self
            .active
            .clone()
            .ok_or_else(|| state("V2 data record without BEGIN"))?;
        let record = Record {
            txn_id: candidate.id(),
            lsn: self.next_lsn,
            prev_lsn: candidate.last_lsn(),
            body,
        };
        candidate.accept(&record)?;
        self.emit(&record)?;
        self.active = Some(candidate);
        match &record.body {
            Body::Page {
                file, page, image, ..
            } if file.is_paged() => {
                phobos_observability::event("wal.page_images", 1);
                if let Ok(checksum) = super::page_format::stored_checksum(*file, *page, image) {
                    self.compact.logged(*file, *page, record.lsn, checksum);
                }
            }
            Body::PageDelta {
                file,
                page,
                result_checksum,
                ..
            } => self
                .compact
                .logged(*file, *page, record.lsn, *result_checksum),
            _ => {}
        }
        if let Body::PageDelta { ops, .. } = record.body {
            self.compact.ops = ops;
        }
        Ok(record.lsn)
    }
    fn emit(&mut self, record: &Record) -> Result<()> {
        self.available()?;
        let next = self
            .next_lsn
            .checked_add(1)
            .ok_or_else(|| state("V2 WAL LSNs exhausted"))?;
        let _span = phobos_observability::span("wal.write_record");
        let partial = match &record.body {
            Body::Commit => Some("v2_partial_commit_record"),
            Body::Page { .. } | Body::PageDelta { .. } => Some("v2_partial_page_record"),
            _ => None,
        };
        let diagnostic_boundary = phobos_observability::certification_requested("v2_before_record")
            || phobos_observability::certification_requested("v2_after_record")
            || partial.is_some_and(phobos_observability::certification_requested);
        if !diagnostic_boundary {
            // 0.2-D: encode straight into the batch buffer (no per-record Vec).
            let encoded = record.encode_into(&mut self.write_buffer)?;
            let end = self
                .written_len
                .checked_add(encoded as u64)
                .ok_or_else(|| state("V2 WAL length overflow"))?;
            self.written_len = end;
            self.next_lsn = next;
            if self.write_buffer.len() >= WRITE_BATCH_BYTES {
                if let Err(error) = self.flush_buffer() {
                    self.fenced = true;
                    return Err(error);
                }
            }
            phobos_observability::event("wal_record_count", 1);
            written(encoded);
            return Ok(());
        }
        let bytes = record.encode()?;
        let end = self
            .written_len
            .checked_add(bytes.len() as u64)
            .ok_or_else(|| state("V2 WAL length overflow"))?;
        let result = if diagnostic_boundary {
            self.flush_buffer().and_then(|()| {
                self.check_physical_len()?;
                phobos_observability::certification_crash("v2_before_record");
                if self.mode == DurabilityMode::WriteThrough {
                    self.ensure_capacity(end)?;
                }
                let file = self.file.as_mut().expect("available WAL file");
                file.seek(SeekFrom::Start(self.physical_len))?;
                if let Some(point) =
                    partial.filter(|point| phobos_observability::certification_requested(point))
                {
                    let half = &bytes[..bytes.len() / 2];
                    file.write_all(half)?;
                    physical_written(half.len());
                    file.sync_data()?;
                    phobos_observability::certification_crash(point);
                }
                file.write_all(&bytes)?;
                physical_written(bytes.len());
                self.physical_len = end;
                phobos_observability::certification_crash("v2_after_record");
                Ok(())
            })
        } else {
            self.write_buffer.extend_from_slice(&bytes);
            if self.write_buffer.len() >= WRITE_BATCH_BYTES {
                self.flush_buffer()
            } else {
                Ok(())
            }
        };
        if let Err(error) = result {
            self.fenced = true;
            return Err(error);
        }
        self.written_len = end;
        self.next_lsn = next;
        phobos_observability::event("wal_record_count", 1);
        written(bytes.len());
        Ok(())
    }
    fn check_physical_len(&mut self) -> Result<()> {
        let actual = self
            .file
            .as_ref()
            .expect("available WAL file")
            .metadata()?
            .len();
        let (low, high) = match self.mode {
            DurabilityMode::Flush => (self.physical_len, self.physical_len),
            // 0.2-F: an outstanding background extension may have grown the
            // file past the capacity, never past its bound.
            DurabilityMode::WriteThrough => (self.capacity, self.extend_limit),
        };
        if actual < low || actual > high {
            self.fenced = true;
            return Err(state("V2 WAL physical length changed unexpectedly"));
        }
        Ok(())
    }
    /// Mode A physical append into the OS cache (Mode E: durable advance).
    fn flush_buffer(&mut self) -> Result<()> {
        if self.mode == DurabilityMode::WriteThrough {
            return self.durable_advance();
        }
        if self.write_buffer.is_empty() {
            return Ok(());
        }
        self.check_physical_len()?;
        let result = (|| -> Result<()> {
            let file = self.file.as_mut().expect("available WAL file");
            file.seek(SeekFrom::Start(self.physical_len))?;
            file.write_all(&self.write_buffer)?;
            physical_written(self.write_buffer.len());
            Ok(())
        })();
        if let Err(error) = result {
            self.fenced = true;
            return Err(error);
        }
        self.physical_len = self
            .physical_len
            .checked_add(self.write_buffer.len() as u64)
            .ok_or_else(|| state("V2 WAL physical length overflow"))?;
        self.write_buffer.clear();
        Ok(())
    }
    fn sync_prefix(&mut self) -> Result<()> {
        if self.mode == DurabilityMode::WriteThrough {
            return self.durable_advance();
        }
        self.available()?;
        self.flush_buffer()?;
        let _span = phobos_observability::span("wal.fsync");
        phobos_observability::certification_crash("v2_before_sync");
        #[cfg(any(test, feature = "test-hooks"))]
        let injected_failure = std::mem::take(&mut self.fail_next_sync);
        #[cfg(not(any(test, feature = "test-hooks")))]
        let injected_failure = false;
        let result = if injected_failure {
            Err(std::io::Error::other("injected WAL force failure"))
        } else {
            let file = self.file.as_mut().expect("available WAL file");
            file.metadata().and_then(|metadata| {
                if metadata.len() != self.written_len || self.physical_len != self.written_len {
                    Err(std::io::Error::other(
                        "WAL physical length changed before force",
                    ))
                } else {
                    file.sync_data()
                }
            })
        };
        if let Err(error) = result {
            self.fenced = true;
            return Err(error.into());
        }
        self.durable_lsn = self.next_lsn - 1;
        phobos_observability::certification_crash("v2_after_sync");
        Ok(())
    }
}

fn active_anchor_lsn(directory: &Path) -> Result<u64> {
    let mut file = File::open(directory.join(NAME))?;
    let record =
        super::read_record(&mut file)?.ok_or_else(|| state("missing active WAL anchor"))?;
    if !matches!(record.body, Body::Anchor { .. }) {
        return Err(state("active WAL does not begin with an anchor"));
    }
    Ok(record.lsn)
}

/// 0.2-D: undo a segment rotation that was interrupted after its rename and
/// before its new active file held a complete anchor (process or power loss).
/// The newest sealed segment, forced before the rename, becomes the active
/// WAL again; nothing was ever appended to the incomplete new file.
fn repair_interrupted_rotation(directory: &Path) -> Result<()> {
    let active = directory.join(NAME);
    let segments = super::scan::segments(&active)?;
    if segments.iter().any(|segment| segment.active) {
        return Ok(());
    }
    let Some(newest) = segments.last() else {
        return Ok(());
    };
    if active.exists() {
        fs::remove_file(&active)?;
    }
    fs::rename(&newest.path, &active)?;
    sync_directory(directory)?;
    phobos_observability::event("wal.interrupted_rotation_repaired", 1);
    Ok(())
}

fn active_anchor_is_v3(directory: &Path) -> Result<bool> {
    let mut header = [0; super::format::HEADER_LEN];
    std::io::Read::read_exact(&mut File::open(directory.join(NAME))?, &mut header)?;
    Ok(super::format::anchor_is_v3(&header))
}

fn active_anchor_is_prealloc(directory: &Path) -> Result<bool> {
    let mut header = [0; super::format::HEADER_LEN];
    std::io::Read::read_exact(&mut File::open(directory.join(NAME))?, &mut header)?;
    Ok(super::format::anchor_is_prealloc(&header))
}

// Only a durable replacement anchor makes these historical page targets
// unnecessary. Never perform this cleanup before successful checkpoint force.
fn cleanup_retired(directory: &Path) -> Result<()> {
    for entry in fs::read_dir(directory)? {
        let entry = entry?;
        let name = entry.file_name();
        let Some(name) = name.to_str() else {
            continue;
        };
        let Some(rest) = name.strip_prefix(".phobos-retired-") else {
            continue;
        };
        let identity = rest
            .strip_prefix("table-")
            .and_then(|s| s.strip_suffix(".heap"))
            .or_else(|| {
                rest.strip_prefix("index-")
                    .and_then(|s| s.strip_suffix(".idx"))
            });
        if identity
            .is_some_and(|id| id.len() == 16 && u64::from_str_radix(id, 16).is_ok_and(|id| id != 0))
        {
            if !entry.file_type()?.is_file() {
                return Err(state("retired page target is not a regular file"));
            }
            fs::remove_file(entry.path())?;
        }
    }
    sync_directory(directory)
}
fn written(bytes: usize) {
    super::super::WRITTEN_BYTES.fetch_add(bytes as u64, Ordering::Relaxed);
    phobos_observability::event("wal.bytes", bytes as u64);
    phobos_observability::event("wal.v2_records", 1);
}
fn physical_written(bytes: usize) {
    phobos_observability::event("wal_physical_write_calls", 1);
    phobos_observability::event("wal_bytes_written", bytes as u64);
}
fn state(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::Recovery, message)
}
fn sync_directory(path: &Path) -> Result<()> {
    #[cfg(unix)]
    File::open(path)?.sync_all()?;
    #[cfg(not(unix))]
    let _ = path;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::super::FileId;
    use super::*;
    pub(super) fn directory() -> PathBuf {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "phobos-v2-writer-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ))
    }
    #[test]
    fn forcing_predecessor_never_authorizes_active_successor() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        let first = wal.append_commit().unwrap();
        let second = wal.begin().unwrap();
        let receipts = wal.force_commits(&[first]).unwrap();
        assert_eq!(receipts.len(), 1);
        assert_ne!(receipts[0].txn_id(), second);
        assert!(wal.checkpoint_all(receipts[0].lsn()).is_err());
        let pending = wal.append_commit().unwrap();
        assert!(pending.lsn() > wal.durable_lsn());
        assert!(wal.checkpoint_all(pending.lsn()).is_err());
        let second_receipt = wal.force_commits(&[pending]).unwrap();
        assert_eq!(second_receipt[0].txn_id(), second);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn d4_unused_prepared_page_lsn_keeps_record_order_monotonic() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        let mut image = [0u8; 8192];
        let prepared = wal.stamp_next_page(FileId::Heap(1), 0, &mut image).unwrap();
        assert_eq!(prepared, wal.next_lsn);
        wal.abort().unwrap();
        assert_eq!(wal.next_lsn, prepared + 1);
        wal.begin().unwrap();
        let receipt = wal.commit().unwrap();
        assert!(receipt.lsn() > prepared);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn pending_batch_requires_complete_order_and_blocks_checkpoint() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        let before = wal.durable_lsn();
        wal.begin().unwrap();
        let first = wal.append_commit().unwrap();
        wal.begin().unwrap();
        let second = wal.append_commit().unwrap();
        assert_eq!(wal.durable_lsn(), before);
        assert!(wal.checkpoint_all(second.lsn()).is_err());
        assert!(wal.force_commits(std::slice::from_ref(&first)).is_err());
        let mut tickets = [second, first];
        assert!(wal.force_commits(&tickets).is_err());
        assert_eq!(wal.durable_lsn(), before);
        tickets.swap(0, 1);
        let receipts = wal.force_commits(&tickets).unwrap();
        assert_eq!(receipts.len(), 2);
        assert_eq!(receipts[0].txn_id(), tickets[0].txn_id());
        assert_eq!(wal.durable_lsn(), tickets[1].lsn());
        assert!(wal.force_commits(&tickets).is_err());
        wal.checkpoint_all(receipts[1].lsn()).unwrap();
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn ticket_from_prior_writer_lifetime_cannot_authorize_reused_lsn() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        let anchor = fs::read(dir.join(NAME)).unwrap();
        wal.begin().unwrap();
        let stale = wal.append_commit().unwrap();
        drop(wal);
        fs::write(dir.join(NAME), anchor).unwrap();
        let mut wal = Wal::open(&dir).unwrap();
        wal.begin().unwrap();
        let current = wal.append_commit().unwrap();
        assert_eq!(stale.lsn(), current.lsn());
        assert_eq!(stale.txn_id(), current.txn_id());
        assert!(wal.force_commits(&[stale]).is_err());
        wal.force_commits(&[current]).unwrap();
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn failed_force_fences_entire_pending_batch_without_receipts() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        let before = wal.durable_lsn();
        wal.begin().unwrap();
        let first = wal.append_commit().unwrap();
        wal.begin().unwrap();
        let second = wal.append_commit().unwrap();
        // Test-only I/O fault; identical failure path on every platform.
        wal.fail_next_sync = true;
        let tickets = [first, second];
        assert!(wal.force_commits(&tickets).is_err());
        assert_eq!(wal.durable_lsn(), before);
        assert!(wal.is_fenced());
        assert!(wal.force_commits(&tickets).is_err());
        assert!(wal.begin().is_err());
        assert!(wal.checkpoint_all(before).is_err());
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn durable_receipt_checkpoint_retains_anchor_and_monotonic_identity() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        assert_eq!(wal.begin().unwrap(), 1);
        wal.append(Body::Metadata {
            file: FileId::Tables,
            offset: 0,
            total_len: 2,
            bytes: vec![1, 2],
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        assert_eq!(receipt.txn_id(), 1);
        assert_eq!(receipt.lsn(), wal.durable_lsn());
        assert_eq!(inspect(dir.join(NAME)).unwrap().committed_transactions, 1);
        assert!(Wal::open(&dir).is_err());
        assert!(wal.checkpoint_all(receipt.lsn() - 1).is_err());
        wal.checkpoint_all(receipt.lsn()).unwrap();
        assert!(fs::metadata(dir.join(NAME)).unwrap().len() > 44);
        let before = fs::read(dir.join(NAME)).unwrap();
        assert!(super::super::super::recover(&dir).is_err());
        assert_eq!(fs::read(dir.join(NAME)).unwrap(), before);
        drop(wal);
        let mut wal = Wal::open(&dir).unwrap();
        assert_eq!(wal.begin().unwrap(), 2);
        let next = wal.commit().unwrap();
        assert!(next.lsn() > receipt.lsn());
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn failed_metadata_transaction_requires_abort_and_incomplete_wal_requires_recovery() {
        // 0.2-D file-layout test (EOF = end of log): Mode A writer.
        crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        wal.append(Body::Metadata {
            file: FileId::Tables,
            offset: 0,
            total_len: 2,
            bytes: vec![1],
        })
        .unwrap();
        assert!(wal.commit().is_err());
        assert!(wal.append(Body::Create(FileId::Heap(1))).is_err());
        wal.abort().unwrap();
        assert_eq!(inspect(dir.join(NAME)).unwrap().aborted_transactions, 1);
        wal.begin().unwrap();
        drop(wal);
        assert!(Wal::open(&dir).is_err());
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn unexpected_physical_write_fences_all_further_use() {
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        let mut other = OpenOptions::new()
            .append(true)
            .open(dir.join(NAME))
            .unwrap();
        other.write_all(b"bad").unwrap();
        drop(other);
        assert!(wal.begin().is_err());
        assert!(wal.is_fenced());
        assert!(wal.begin().is_err());
        assert!(wal.checkpoint_all(0).is_err());
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn perf1_buffers_many_logical_records_into_one_forced_prefix() {
        // 0.2-D file-layout test (EOF = end of log): Mode A writer.
        crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        let after_begin = fs::metadata(dir.join(NAME)).unwrap().len();
        for offset in 0..128u64 {
            wal.append(Body::Metadata {
                file: FileId::Tables,
                offset,
                total_len: 128,
                bytes: vec![offset as u8],
            })
            .unwrap();
        }
        assert_eq!(
            fs::metadata(dir.join(NAME)).unwrap().len(),
            after_begin,
            "sub-megabyte records should remain in the bounded append batch"
        );
        let receipt = wal.commit().unwrap();
        assert_eq!(
            fs::metadata(dir.join(NAME)).unwrap().len(),
            wal.written_len()
        );
        assert_eq!(inspect(dir.join(NAME)).unwrap().committed_transactions, 1);
        wal.checkpoint_all(receipt.lsn()).unwrap();
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
}
