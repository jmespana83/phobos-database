//! Read-only, bounded preflight. No truncation or data-file effects are allowed
//! until this pass has validated the complete WAL prefix and transaction chains.
use super::format::{HEADER_LEN, header_len};
use super::{Body, FileId, Record, read_record};
use phobos_error::{ErrorCode, PhobosError};
use std::{
    fs::File,
    io::{BufReader, Read, Seek},
    path::{Path, PathBuf},
};

pub(super) const SCAN_BUFFER: usize = 1 << 20;

type Result<T> = std::result::Result<T, PhobosError>;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Tail {
    Clean,
    PartialHeader,
    PartialRecord,
    Checksum,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScanReport {
    pub valid_len: u64,
    pub physical_len: u64,
    pub last_lsn: u64,
    pub checkpoint_lsn: u64,
    pub next_txn_id: u64,
    pub page_format: u16,
    pub committed_transactions: u64,
    pub aborted_transactions: u64,
    pub incomplete_transactions: u64,
    pub tail: Tail,
}

#[derive(Debug, Clone)]
pub(super) struct Segment {
    pub path: PathBuf,
    pub active: bool,
}

#[derive(Debug, Clone, Copy)]
pub(super) struct CommittedSpan {
    pub start: u64,
    pub end: u64,
    pub commit_lsn: u64,
    pub txn_id: u64,
}

pub(super) struct AnalyzedSegment {
    pub segment: Segment,
    pub report: ScanReport,
    pub committed: Vec<CommittedSpan>,
}

/// Return sealed segments in sequence order followed by the active segment.
/// A database containing only `phobos.wal` is the legacy single-file layout.
pub(super) fn segments(path: &Path) -> Result<Vec<Segment>> {
    let directory = path
        .parent()
        .ok_or_else(|| invalid("WAL path has no database directory"))?;
    let mut sealed = Vec::new();
    for entry in std::fs::read_dir(directory)? {
        let entry = entry?;
        let name = entry.file_name();
        let Some(name) = name.to_str() else { continue };
        let Some(sequence) = name
            .strip_prefix("phobos.wal.")
            .and_then(|value| value.strip_suffix(".seg"))
        else {
            continue;
        };
        if sequence.len() != 16 || !sequence.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return Err(invalid("invalid V2 WAL segment name"));
        }
        let sequence = u64::from_str_radix(sequence, 16)
            .map_err(|_| invalid("invalid V2 WAL segment sequence"))?;
        if !entry.file_type()?.is_file() {
            return Err(invalid("V2 WAL segment is not a regular file"));
        }
        sealed.push((sequence, entry.path()));
    }
    sealed.sort_by_key(|(sequence, _)| *sequence);
    if sealed.windows(2).any(|pair| pair[0].0 == pair[1].0) {
        return Err(invalid("duplicate V2 WAL segment sequence"));
    }
    let mut result: Vec<_> = sealed
        .into_iter()
        .map(|(_, path)| Segment {
            path,
            active: false,
        })
        .collect();
    // 0.2-D: while sealed segments exist, an active file that is not even a
    // complete format anchor can only be the new file of an interrupted
    // segment rotation (rename, then create + anchor + sync). It holds no
    // record; the newest sealed segment is the real end of the log.
    if path.exists() && (result.is_empty() || !interrupted_rotation_file(path)?) {
        result.push(Segment {
            path: path.to_path_buf(),
            active: true,
        });
    }
    if result.is_empty() {
        return Err(invalid("missing V2 WAL"));
    }
    Ok(result)
}

/// Length of a complete anchor record (header + checkpoint LSN + next ID).
pub(super) const ANCHOR_RECORD_LEN: u64 = HEADER_LEN as u64 + 16;

/// 0.2-I.3: whether a data directory's V2 WAL is in the state an interrupted
/// segment rotation leaves: at least one sealed segment named
/// `phobos.wal.<16 hex digits>.seg`, and the active `phobos.wal` either absent
/// (crash between "seal" and "install") or not yet holding a complete format
/// anchor (the same test `segments` applies; an active file whose header names
/// another WAL version, i.e. legacy V1, never qualifies). Detection only, and
/// it reads no segment content: callers must validate the history with [`inspect`] (which
/// then reports the newest sealed segment's format) and fail closed on error.
/// The repair itself stays in WAL recovery (`repair_interrupted_rotation`).
///
/// One shape is refused as ambiguous: an active file shorter than a WAL
/// header (empty or torn) next to `phobos.wal.gen`. That is what the legacy
/// V1 WAL open leaves when an older binary misrouted an interrupted page-LSN
/// rotation (it creates both), and V1-engine writes may have followed;
/// replaying the sealed V2 history over them could be wrong. A crash under a
/// pre-0.2-E binary (new active file created in place) in a V1-migrated
/// database looks the same. The operator decides.
pub fn interrupted_rotation(directory: &Path) -> Result<bool> {
    let mut sealed = false;
    let entries = match std::fs::read_dir(directory) {
        Ok(entries) => entries,
        // A directory that does not exist yet holds no WAL at all.
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(false),
        Err(error) => return Err(error.into()),
    };
    for entry in entries {
        let entry = entry?;
        let name = entry.file_name();
        let Some(name) = name.to_str() else { continue };
        if name
            .strip_prefix("phobos.wal.")
            .and_then(|rest| rest.strip_suffix(".seg"))
            .is_some_and(|hex| hex.len() == 16 && hex.bytes().all(|byte| byte.is_ascii_hexdigit()))
            && entry.file_type()?.is_file()
        {
            sealed = true;
            break;
        }
    }
    if !sealed {
        return Ok(false);
    }
    let active = directory.join("phobos.wal");
    if !active.exists() {
        return Ok(true);
    }
    // A WAL that identifies itself as another format version (a legacy V1
    // `PHWL` + 1 header) is never an unfinished V2 rotation file.
    let mut header = [0u8; 6];
    let read = std::io::Read::read(&mut File::open(&active)?, &mut header)?;
    if read == header.len() && &header[..4] == b"PHWL" && header[4..] != [2, 0] {
        return Ok(false);
    }
    if read < header.len() && directory.join("phobos.wal.gen").exists() {
        return Err(invalid(
            "ambiguous WAL layout: sealed V2 WAL segments next to an empty or torn phobos.wal and \
             phobos.wal.gen; refusing to guess. Either an older binary opened an interrupted V2 segment \
             rotation through the legacy V1 WAL path (which creates both files), or a pre-0.2-E binary \
             crashed while creating the new active file. If no legacy V1-engine writes happened since \
             the crash, remove phobos.wal (and phobos.wal.gen if this database never used the V1 WAL) and \
             open again; WAL recovery then repairs the rotation",
        ));
    }
    interrupted_rotation_file(&active)
}

/// True when `path` is at most one anchor long and is not a valid anchor,
/// or (0.2-E) holds only zero bytes: a file that never received an anchor.
pub(super) fn interrupted_rotation_file(path: &Path) -> Result<bool> {
    let length = std::fs::metadata(path)?.len();
    if length > ANCHOR_RECORD_LEN {
        let mut file = File::open(path)?;
        let mut buffer = vec![0u8; SCAN_BUFFER];
        loop {
            let read = file.read(&mut buffer)?;
            if read == 0 {
                return Ok(true);
            }
            if buffer[..read].iter().any(|byte| *byte != 0) {
                return Ok(false);
            }
        }
    }
    let bytes = std::fs::read(path)?;
    Ok(!Record::decode(&bytes).is_ok_and(|record| matches!(record.body, Body::Anchor { .. })))
}

#[derive(Clone, Copy)]
struct Extent {
    total: u64,
    next: u64,
}
#[derive(Clone)]
pub(super) struct Transaction {
    id: u64,
    last_lsn: u64,
    metadata: [Option<Extent>; 3],
    mvcc_id: Option<u64>,
    first_record: bool,
}
impl Transaction {
    pub(super) fn new(id: u64, last_lsn: u64) -> Self {
        Self {
            id,
            last_lsn,
            metadata: [None; 3],
            mvcc_id: None,
            first_record: true,
        }
    }
    pub(super) fn id(&self) -> u64 {
        self.id
    }
    pub(super) fn last_lsn(&self) -> u64 {
        self.last_lsn
    }
    pub(super) fn mvcc_id(&self) -> Option<u64> {
        self.mvcc_id
    }
    pub(super) fn accept(&mut self, record: &Record) -> Result<()> {
        if record.txn_id != self.id || record.prev_lsn != self.last_lsn {
            return Err(invalid("broken V2 transaction record chain"));
        }
        if let Body::MvccIdentity(id) = record.body {
            if !self.first_record || self.mvcc_id.is_some() {
                return Err(invalid("MVCC mapping must immediately follow BEGIN"));
            }
            self.mvcc_id = Some(id);
        }
        self.first_record = false;
        if let Body::Metadata {
            file,
            offset,
            total_len,
            bytes,
        } = &record.body
        {
            let index = match file {
                FileId::Tables => 0,
                FileId::Indexes => 1,
                FileId::Statistics => 2,
                _ => return Err(invalid("invalid metadata file kind")),
            };
            let next = offset
                .checked_add(bytes.len() as u64)
                .ok_or_else(|| invalid("metadata extent overflow"))?;
            match self.metadata[index] {
                None if *offset == 0 => {
                    self.metadata[index] = Some(Extent {
                        total: *total_len,
                        next,
                    })
                }
                Some(old)
                    if old.next < old.total && old.total == *total_len && old.next == *offset =>
                {
                    self.metadata[index] = Some(Extent {
                        total: *total_len,
                        next,
                    })
                }
                _ => return Err(invalid("noncontiguous or duplicate V2 metadata image")),
            }
        }
        if matches!(record.body, Body::Commit)
            && self
                .metadata
                .iter()
                .flatten()
                .any(|extent| extent.next != extent.total)
        {
            return Err(invalid("V2 COMMIT has an incomplete metadata image"));
        }
        self.last_lsn = record.lsn;
        Ok(())
    }
}

/// Inspect without modifying the WAL or database. Recovery must hold exclusive
/// database ownership across this pass and any subsequent redo/truncation.
pub fn inspect(path: impl AsRef<Path>) -> Result<ScanReport> {
    inspect_segments(path.as_ref()).map(|(report, _)| report)
}

pub(super) fn inspect_segments(path: &Path) -> Result<(ScanReport, Vec<AnalyzedSegment>)> {
    let segments = segments(path)?;
    let mut aggregate: Option<ScanReport> = None;
    let mut reports = Vec::with_capacity(segments.len());
    for segment in segments {
        let (report, committed) = inspect_file_analysis(&segment.path, segment.active)?;
        if let Some(total) = aggregate.as_mut() {
            if report.last_lsn <= total.last_lsn || report.checkpoint_lsn < total.checkpoint_lsn {
                return Err(invalid("nonmonotonic V2 WAL segment sequence"));
            }
            total.valid_len = total.valid_len.saturating_add(report.valid_len);
            total.physical_len = total.physical_len.saturating_add(report.physical_len);
            total.last_lsn = report.last_lsn;
            total.checkpoint_lsn = report.checkpoint_lsn;
            total.next_txn_id = report.next_txn_id;
            total.page_format = report.page_format;
            total.committed_transactions += report.committed_transactions;
            total.aborted_transactions += report.aborted_transactions;
            total.incomplete_transactions += report.incomplete_transactions;
            total.tail = report.tail;
        } else {
            aggregate = Some(report.clone());
        }
        reports.push(AnalyzedSegment {
            segment,
            report,
            committed,
        });
    }
    Ok((aggregate.ok_or_else(|| invalid("missing V2 WAL"))?, reports))
}

pub(super) fn inspect_file(path: &Path, tolerate_torn_tail: bool) -> Result<ScanReport> {
    inspect_file_analysis(path, tolerate_torn_tail).map(|(report, _)| report)
}

fn inspect_file_analysis(
    path: &Path,
    tolerate_torn_tail: bool,
) -> Result<(ScanReport, Vec<CommittedSpan>)> {
    let file = File::open(path)?;
    let physical_len = file.metadata()?.len();
    // 0.2-D: compact redo puts many more (small) records in a segment; read
    // them through one buffer instead of two system calls per record.
    let mut file = BufReader::with_capacity(SCAN_BUFFER, file);
    let mut bytes = Vec::new();
    let mut report = ScanReport {
        valid_len: 0,
        physical_len,
        last_lsn: 0,
        checkpoint_lsn: 0,
        next_txn_id: 1,
        page_format: 1,
        committed_transactions: 0,
        aborted_transactions: 0,
        incomplete_transactions: 0,
        tail: Tail::Clean,
    };
    let mut active: Option<Transaction> = None;
    let mut active_start = None;
    let mut committed = Vec::new();
    let mut offset = 0;
    let mut prealloc = false;
    while offset < physical_len {
        let remaining = physical_len - offset;
        if prealloc {
            // 0.2-E preallocated segment: the logical end is the first record
            // that cannot be decoded; the rest must be a zero tail (§5 of
            // docs/wal_v3_windows_durable_wal.md). A record that decodes is
            // still validated exactly as below.
            let next = next_prealloc_record(&mut file, &mut bytes, offset, physical_len)?;
            let Some((record, end)) = next else {
                report.tail = prealloc_tail(path, offset, physical_len, tolerate_torn_tail)?;
                break;
            };
            if Some(record.lsn) != report.last_lsn.checked_add(1) {
                return Err(invalid("noncontiguous V2 WAL LSN sequence"));
            }
            account(
                &record,
                offset,
                end,
                &mut report,
                &mut active,
                &mut active_start,
                &mut committed,
            )?;
            report.last_lsn = record.lsn;
            offset = end;
            report.valid_len = end;
            continue;
        }
        if remaining < HEADER_LEN as u64 {
            let mut prefix = vec![0; remaining as usize];
            file.read_exact(&mut prefix)?;
            // Even a short last header must not silently discard a recognizable
            // unsupported format. The initial V2 anchor must always be complete.
            if prefix.len() >= 6
                && &prefix[..4] == b"PHWL"
                && u16::from_le_bytes([prefix[4], prefix[5]]) != 2
            {
                return Err(invalid("unsupported WAL version in partial header"));
            }
            if offset == 0 {
                return Err(invalid("missing or incomplete V2 format anchor"));
            }
            if !tolerate_torn_tail {
                return Err(invalid("truncated header in sealed V2 WAL segment"));
            }
            report.tail = Tail::PartialHeader;
            break;
        }
        let mut header = [0; HEADER_LEN];
        file.read_exact(&mut header)?;
        let size = header_len(&header)?;
        let end = offset
            .checked_add(size as u64)
            .ok_or_else(|| invalid("V2 WAL offset overflow"))?;
        if end > physical_len {
            if offset == 0 {
                return Err(invalid("incomplete V2 format anchor"));
            }
            if !tolerate_torn_tail {
                return Err(invalid("truncated record in sealed V2 WAL segment"));
            }
            report.tail = Tail::PartialRecord;
            break;
        }
        bytes.clear();
        bytes.resize(size, 0);
        bytes[..HEADER_LEN].copy_from_slice(&header);
        file.read_exact(&mut bytes[HEADER_LEN..])?;
        let record = match Record::decode(&bytes) {
            Ok(record) => record,
            Err(error)
                if error.code == ErrorCode::ChecksumMismatch
                    && end == physical_len
                    && offset > 0 =>
            {
                if !tolerate_torn_tail {
                    return Err(error);
                }
                report.tail = Tail::Checksum;
                break;
            }
            Err(error) => return Err(error),
        };
        if offset == 0 {
            let Body::Anchor {
                checkpoint_lsn,
                next_txn_id,
                page_format,
            } = record.body
            else {
                return Err(invalid("V2 WAL must begin with a format anchor"));
            };
            report.checkpoint_lsn = checkpoint_lsn;
            report.next_txn_id = next_txn_id;
            report.page_format = page_format;
            prealloc = super::format::anchor_is_prealloc(&header);
        } else {
            if Some(record.lsn) != report.last_lsn.checked_add(1) {
                return Err(invalid("noncontiguous V2 WAL LSN sequence"));
            }
            account(
                &record,
                offset,
                end,
                &mut report,
                &mut active,
                &mut active_start,
                &mut committed,
            )?;
        }
        report.last_lsn = record.lsn;
        offset = end;
        report.valid_len = end;
    }
    if report.valid_len == 0 {
        return Err(invalid("missing V2 format anchor"));
    }
    report.incomplete_transactions = u64::from(active.is_some());
    Ok((report, committed))
}

/// Validate one non-anchor record against the scan state (shared by the
/// 0.2-D end-of-file scan and the 0.2-E preallocated scan).
fn account(
    record: &Record,
    offset: u64,
    end: u64,
    report: &mut ScanReport,
    active: &mut Option<Transaction>,
    active_start: &mut Option<u64>,
    committed: &mut Vec<CommittedSpan>,
) -> Result<()> {
    {
        {
            if report.page_format >= 2 {
                if let Body::Page {
                    file, page, image, ..
                } = &record.body
                {
                    super::page_format::validate_capability(report.page_format, *file, image)?;
                    if super::page_format::lsn(*file, *page, image).ok() != Some(record.lsn) {
                        return Err(invalid(
                            "WAL image has an invalid checksum, identity, or page LSN",
                        ));
                    }
                }
            } else if matches!(record.body, Body::PageDelta { .. }) {
                return Err(invalid("compact page redo requires page LSNs"));
            }
            match &record.body {
                Body::Anchor { .. } => return Err(invalid("duplicate V2 WAL format anchor")),
                Body::Begin => {
                    if active.is_some() || record.txn_id < report.next_txn_id {
                        return Err(invalid(
                            "interleaved transaction or reused V2 transaction ID",
                        ));
                    }
                    report.next_txn_id = record
                        .txn_id
                        .checked_add(1)
                        .ok_or_else(|| invalid("V2 transaction IDs exhausted"))?;
                    *active = Some(Transaction {
                        id: record.txn_id,
                        last_lsn: record.lsn,
                        metadata: [None; 3],
                        mvcc_id: None,
                        first_record: true,
                    });
                    *active_start = Some(offset);
                }
                Body::Checkpoint {
                    checkpoint_lsn,
                    next_txn_id,
                } => {
                    if active.is_some()
                        || *checkpoint_lsn < report.checkpoint_lsn
                        || *next_txn_id < report.next_txn_id
                    {
                        return Err(invalid(
                            "invalid V2 checkpoint horizon or transaction state",
                        ));
                    }
                    report.checkpoint_lsn = *checkpoint_lsn;
                    report.next_txn_id = *next_txn_id;
                }
                _ => {
                    if matches!(record.body, Body::MvccIdentity(_)) && report.page_format < 3 {
                        return Err(invalid("MVCC mapping requires capability 3"));
                    }
                    if report.page_format >= 3
                        && !matches!(record.body, Body::MvccIdentity(_) | Body::Abort)
                        && active.as_ref().is_some_and(|tx| tx.mvcc_id.is_none())
                    {
                        return Err(invalid("MVCC chain is missing its identity mapping"));
                    }
                    active
                        .as_mut()
                        .ok_or_else(|| invalid("V2 transaction record without BEGIN"))?
                        .accept(record)?;
                    if matches!(record.body, Body::Commit) {
                        report.committed_transactions += 1;
                        committed.push(CommittedSpan {
                            start: active_start
                                .take()
                                .ok_or_else(|| invalid("committed transaction lacks BEGIN"))?,
                            end,
                            commit_lsn: record.lsn,
                            txn_id: record.txn_id,
                        });
                        *active = None;
                    } else if matches!(record.body, Body::Abort) {
                        report.aborted_transactions += 1;
                        *active = None;
                        *active_start = None;
                    }
                }
            }
        }
    }
    Ok(())
}

/// 0.2-E: the largest physical write the WAL writer issues at once. A crash
/// can leave at most one such piece indeterminate (see `TORN_WINDOW`).
pub(super) const WRITE_PIECE: usize = 256 * 1024;
/// Non-zero bytes after the valid prefix of a preallocated active segment
/// are a torn final write only if they all lie within this distance of the
/// prefix end: one in-flight piece plus the record straddling its start.
pub(super) const TORN_WINDOW: u64 = (WRITE_PIECE + super::MAX_RECORD_BYTES) as u64;

/// The next complete, checksum-valid record at `offset`, or `None` when the
/// bytes there cannot be one (zero tail, torn write). A record whose checksum
/// verifies but whose body is invalid is an error, never an end of log.
fn next_prealloc_record(
    file: &mut BufReader<File>,
    bytes: &mut Vec<u8>,
    offset: u64,
    physical_len: u64,
) -> Result<Option<(Record, u64)>> {
    if physical_len - offset < HEADER_LEN as u64 {
        return Ok(None);
    }
    let mut header = [0; HEADER_LEN];
    file.read_exact(&mut header)?;
    let Ok(size) = header_len(&header) else {
        return Ok(None);
    };
    let end = offset + size as u64;
    if end > physical_len {
        return Ok(None);
    }
    bytes.clear();
    bytes.resize(size, 0);
    bytes[..HEADER_LEN].copy_from_slice(&header);
    file.read_exact(&mut bytes[HEADER_LEN..])?;
    match Record::decode(bytes) {
        Ok(record) => Ok(Some((record, end))),
        Err(error) if error.code == ErrorCode::ChecksumMismatch => Ok(None),
        Err(error) => Err(error),
    }
}

/// Classify the bytes after the valid prefix `[0, start)` of a preallocated
/// segment: all zero (clean end), a torn final write (active segment only,
/// confined to `TORN_WINDOW`), or corruption (hard error).
pub(super) fn prealloc_tail(
    path: &Path,
    start: u64,
    physical_len: u64,
    tolerate_torn_tail: bool,
) -> Result<Tail> {
    let mut file = File::open(path)?;
    file.seek(std::io::SeekFrom::Start(start))?;
    let mut buffer = vec![0u8; SCAN_BUFFER];
    let mut position = start;
    let mut last_nonzero = None;
    while position < physical_len {
        let want = usize::try_from((physical_len - position).min(SCAN_BUFFER as u64))
            .expect("bounded read");
        file.read_exact(&mut buffer[..want])?;
        if let Some(index) = buffer[..want].iter().rposition(|byte| *byte != 0) {
            last_nonzero = Some(position + index as u64);
        }
        position += want as u64;
    }
    let Some(last) = last_nonzero else {
        return Ok(Tail::Clean);
    };
    if !tolerate_torn_tail {
        return Err(invalid(
            "non-zero bytes after the valid prefix of a sealed preallocated WAL segment",
        ));
    }
    if last >= start.saturating_add(TORN_WINDOW) {
        return Err(invalid(
            "WAL corruption: non-zero bytes beyond the torn-write window of a preallocated segment",
        ));
    }
    Ok(Tail::PartialRecord)
}

/// Preflight the entire input before invoking any visitor. A visitor can perform
/// a second bounded pass to identify committed ranges; no record list is retained.
pub fn visit_validated(
    path: impl AsRef<Path>,
    mut visitor: impl FnMut(u64, &Record) -> Result<()>,
) -> Result<ScanReport> {
    let path = path.as_ref();
    let report = inspect(path)?;
    let mut logical_offset = 0;
    for analyzed in inspect_segments(path)?.1 {
        let mut file = BufReader::with_capacity(SCAN_BUFFER, File::open(&analyzed.segment.path)?);
        while file.stream_position()? < analyzed.report.valid_len {
            let start = file.stream_position()?;
            let record =
                read_record(&mut file)?.ok_or_else(|| invalid("WAL changed after V2 preflight"))?;
            visitor(logical_offset, &record)?;
            // The stored length, not a re-encoding (encodings may differ).
            logical_offset = logical_offset.saturating_add(file.stream_position()? - start);
        }
        if file.stream_position()? != analyzed.report.valid_len {
            return Err(invalid("WAL changed after V2 preflight"));
        }
    }
    Ok(report)
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidWal, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{fs, io::Write};
    fn path() -> std::path::PathBuf {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "phobos-v2-scan-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        ))
    }
    /// 0.2-I.3: detection of the interrupted-rotation layout (names and the
    /// active header only; content is validated by `inspect`).
    #[test]
    fn i1_3_interrupted_rotation_detection() {
        let dir = path();
        fs::create_dir_all(&dir).unwrap();
        let seg = dir.join("phobos.wal.0000000000000001.seg");
        // No sealed segment: never an interrupted rotation.
        assert!(!interrupted_rotation(&dir).unwrap());
        fs::write(dir.join("phobos.wal.junk.seg"), b"x").unwrap();
        fs::write(dir.join("phobos.wal.0000000000000001.seg.bak"), b"x").unwrap();
        assert!(!interrupted_rotation(&dir).unwrap());
        // A well-formed sealed name and no active WAL.
        fs::write(&seg, b"x").unwrap();
        assert!(interrupted_rotation(&dir).unwrap());
        // An empty or zero-filled active file (unfinished rotation file).
        fs::write(dir.join("phobos.wal"), b"").unwrap();
        assert!(interrupted_rotation(&dir).unwrap());
        fs::write(dir.join("phobos.wal"), [0u8; 4096]).unwrap();
        assert!(interrupted_rotation(&dir).unwrap());
        // Empty or torn (< header) active file + phobos.wal.gen: the residue
        // of a legacy V1 open of an interrupted rotation. Ambiguous: refused.
        fs::write(dir.join("phobos.wal.gen"), b"PHWG\x01\x00").unwrap();
        fs::write(dir.join("phobos.wal"), b"").unwrap();
        assert!(interrupted_rotation(&dir).is_err());
        fs::write(dir.join("phobos.wal"), b"PHW").unwrap();
        assert!(interrupted_rotation(&dir).is_err());
        // phobos.wal.gen alone (a V1->V2 migrated database) with no active
        // file is an ordinary interrupted rotation.
        fs::remove_file(dir.join("phobos.wal")).unwrap();
        assert!(interrupted_rotation(&dir).unwrap());
        fs::remove_file(dir.join("phobos.wal.gen")).unwrap();
        // A missing directory has no WAL.
        assert!(!interrupted_rotation(&dir.join("absent")).unwrap());
        // A header naming another WAL version (legacy V1) never qualifies.
        fs::write(dir.join("phobos.wal"), b"PHWL\x01\x00rest").unwrap();
        assert!(!interrupted_rotation(&dir).unwrap());
        // A complete V2 active file is the normal layout.
        let anchor = base()[0].encode().unwrap();
        fs::write(dir.join("phobos.wal"), &anchor).unwrap();
        assert!(!interrupted_rotation(&dir).unwrap());
        fs::remove_dir_all(dir).unwrap();
    }

    fn base() -> Vec<Record> {
        vec![
            Record {
                txn_id: 0,
                lsn: 1,
                prev_lsn: 0,
                body: Body::Anchor {
                    checkpoint_lsn: 0,
                    next_txn_id: 1,
                    page_format: 1,
                },
            },
            Record {
                txn_id: 1,
                lsn: 2,
                prev_lsn: 0,
                body: Body::Begin,
            },
            Record {
                txn_id: 1,
                lsn: 3,
                prev_lsn: 2,
                body: Body::Metadata {
                    file: FileId::Tables,
                    offset: 0,
                    total_len: 2,
                    bytes: vec![1, 2],
                },
            },
            Record {
                txn_id: 1,
                lsn: 4,
                prev_lsn: 3,
                body: Body::Commit,
            },
        ]
    }
    fn bytes(records: &[Record]) -> Vec<u8> {
        records
            .iter()
            .flat_map(|record| record.encode().unwrap())
            .collect()
    }
    fn check(data: &[u8], test: impl FnOnce(&Path)) {
        let path = path();
        let mut file = File::create_new(&path).unwrap();
        file.write_all(data).unwrap();
        drop(file);
        test(&path);
        assert_eq!(fs::read(&path).unwrap(), data, "inspection changed the WAL");
        fs::remove_file(path).unwrap();
    }
    #[test]
    fn scanner_tracks_committed_aborted_and_incomplete_chains_without_writes() {
        let mut records = base();
        records.extend([
            Record {
                txn_id: 2,
                lsn: 5,
                prev_lsn: 0,
                body: Body::Begin,
            },
            Record {
                txn_id: 2,
                lsn: 6,
                prev_lsn: 5,
                body: Body::Abort,
            },
            Record {
                txn_id: 3,
                lsn: 7,
                prev_lsn: 0,
                body: Body::Begin,
            },
        ]);
        check(&bytes(&records), |path| {
            let report = inspect(path).unwrap();
            assert_eq!(
                (
                    report.committed_transactions,
                    report.aborted_transactions,
                    report.incomplete_transactions
                ),
                (1, 1, 1)
            );
            assert_eq!(report.next_txn_id, 4);
            assert_eq!(report.tail, Tail::Clean);
            let mut seen = 0;
            visit_validated(path, |_, _| {
                seen += 1;
                Ok(())
            })
            .unwrap();
            assert_eq!(seen, 7);
        });
    }
    #[test]
    fn scanner_rejects_versions_and_bad_chains_before_any_visitor() {
        let good = bytes(&base());
        let next = Record {
            txn_id: 2,
            lsn: 5,
            prev_lsn: 0,
            body: Body::Begin,
        }
        .encode()
        .unwrap();
        for short in [false, true] {
            let mut invalid_tail = next.clone();
            invalid_tail[4] = 99;
            if short {
                invalid_tail.truncate(6);
            }
            let mut data = good.clone();
            data.extend_from_slice(&invalid_tail);
            check(&data, |path| {
                let mut called = false;
                assert!(
                    visit_validated(path, |_, _| {
                        called = true;
                        Ok(())
                    })
                    .is_err()
                );
                assert!(!called);
            });
        }
        for change in ["chain", "gap", "reuse", "interleave", "metadata"] {
            let mut records = base();
            match change {
                "chain" => records[2].prev_lsn = 1,
                "gap" => records[2].lsn = 4,
                "reuse" => records.push(Record {
                    txn_id: 1,
                    lsn: 5,
                    prev_lsn: 0,
                    body: Body::Begin,
                }),
                "interleave" => {
                    records[2] = Record {
                        txn_id: 2,
                        lsn: 3,
                        prev_lsn: 0,
                        body: Body::Begin,
                    }
                }
                _ => {
                    records[2].body = Body::Metadata {
                        file: FileId::Tables,
                        offset: 0,
                        total_len: 3,
                        bytes: vec![1, 2],
                    }
                }
            }
            check(&bytes(&records), |path| {
                assert!(inspect(path).is_err(), "{change}")
            });
        }
    }
    #[test]
    fn scanner_reports_only_final_torn_tails_and_never_discards_anchor() {
        let good = bytes(&base());
        let next = Record {
            txn_id: 2,
            lsn: 5,
            prev_lsn: 0,
            body: Body::Begin,
        }
        .encode()
        .unwrap();
        for length in [1, 6, HEADER_LEN - 1] {
            let mut data = good.clone();
            data.extend_from_slice(&next[..length]);
            check(&data, |path| {
                let report = inspect(path).unwrap();
                assert_eq!(report.valid_len, good.len() as u64);
                assert_eq!(report.tail, Tail::PartialHeader);
            });
        }
        let mut record = Record {
            txn_id: 2,
            lsn: 6,
            prev_lsn: 5,
            body: Body::Metadata {
                file: FileId::Tables,
                offset: 0,
                total_len: 2,
                bytes: vec![3, 4],
            },
        }
        .encode()
        .unwrap();
        let mut prefix = good.clone();
        prefix.extend_from_slice(&next);
        let mut partial = prefix.clone();
        partial.extend_from_slice(&record[..record.len() - 1]);
        check(&partial, |path| {
            assert_eq!(inspect(path).unwrap().tail, Tail::PartialRecord)
        });
        *record.last_mut().unwrap() ^= 1;
        let mut torn = prefix.clone();
        torn.extend_from_slice(&record);
        check(&torn, |path| {
            assert_eq!(inspect(path).unwrap().tail, Tail::Checksum)
        });
        torn.push(0);
        check(&torn, |path| assert!(inspect(path).is_err()));
        for length in [0, 6, HEADER_LEN] {
            check(&good[..length], |path| assert!(inspect(path).is_err()));
        }
    }
}
