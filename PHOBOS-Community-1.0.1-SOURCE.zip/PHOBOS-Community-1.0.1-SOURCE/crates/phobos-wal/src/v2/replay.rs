//! Bounded selection of committed redo ranges after complete read-only preflight.
use super::scan::inspect_segments;
use super::{Record, ScanReport, read_record};
use phobos_error::{ErrorCode, PhobosError};
use std::{
    fs::File,
    io::{BufReader, Seek},
    path::Path,
};

type Result<T> = std::result::Result<T, PhobosError>;

/// Deliver BEGIN, data records, and COMMIT only for committed transactions, in
/// commit order. The first argument is the transaction's COMMIT LSN, including
/// for its preceding data records. No transaction-sized collection is retained.
///
/// The caller must hold exclusive database ownership throughout this operation.
/// This does not truncate the WAL, install pages, force data, or checkpoint. If a
/// visitor fails after partial redo, recovery must be repeated before opening the
/// database; the original WAL remains available for idempotent replay.
pub fn visit_committed(
    path: impl AsRef<Path>,
    mut visitor: impl FnMut(u64, &Record) -> Result<()>,
) -> Result<ScanReport> {
    let path = path.as_ref();
    let (report, segments) = inspect_segments(path)?;
    phobos_observability::event("recovery.wal_scan_passes", 1);
    for analyzed in segments {
        let mut redo = BufReader::with_capacity(
            super::scan::SCAN_BUFFER,
            File::open(&analyzed.segment.path)?,
        );
        for span in analyzed.committed {
            // Consecutive committed spans need no seek; others stay buffered
            // when the gap is small (seek_relative keeps the buffer).
            let position = redo.stream_position()?;
            if position != span.start {
                let offset = i64::try_from(span.start).map_err(|_| changed())?
                    - i64::try_from(position).map_err(|_| changed())?;
                redo.seek_relative(offset)?;
            }
            while redo.stream_position()? < span.end {
                let item = required(&mut redo)?;
                if item.txn_id != span.txn_id || item.lsn > span.commit_lsn {
                    return Err(changed());
                }
                visitor(span.commit_lsn, &item)?;
            }
            if redo.stream_position()? != span.end {
                return Err(changed());
            }
        }
    }
    Ok(report)
}

fn required(file: &mut impl std::io::Read) -> Result<Record> {
    read_record(file)?.ok_or_else(changed)
}
fn changed() -> PhobosError {
    PhobosError::new(
        ErrorCode::InvalidWal,
        "WAL changed after V2 replay preflight",
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v2::{Body, FileId, Wal};
    use std::{
        fs,
        io::Write,
        sync::atomic::{AtomicU64, Ordering},
    };

    fn directory() -> std::path::PathBuf {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "phobos-v2-replay-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ))
    }

    #[test]
    fn replay_selects_only_committed_ranges_and_is_repeatable_after_failure() {
        // 0.2-D file-layout test (EOF = end of log): Mode A writer.
        crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        wal.append(Body::Create(FileId::Heap(1))).unwrap();
        wal.abort().unwrap();
        let id = wal.begin().unwrap();
        for page in 0..200 {
            wal.append(Body::Page {
                action: super::super::PageAction::Initialize,
                file: FileId::Heap(2),
                page,
                image: Box::new([page as u8; 8192]),
            })
            .unwrap();
        }
        let receipt = wal.commit().unwrap();
        wal.begin().unwrap();
        wal.append(Body::Create(FileId::Heap(3))).unwrap();
        drop(wal);
        let path = dir.join("phobos.wal");
        let before = fs::read(&path).unwrap();
        let mut calls = 0;
        assert!(
            visit_committed(&path, |_, _| {
                calls += 1;
                if calls == 12 {
                    return Err(changed());
                }
                Ok(())
            })
            .is_err()
        );
        assert_eq!(calls, 12);
        for _ in 0..2 {
            let mut seen = 0;
            let report = visit_committed(&path, |commit_lsn, record| {
                assert_eq!(commit_lsn, receipt.lsn());
                assert_eq!(record.txn_id, id);
                seen += 1;
                Ok(())
            })
            .unwrap();
            assert_eq!(seen, 202);
            assert_eq!(report.incomplete_transactions, 1);
        }
        assert_eq!(fs::read(&path).unwrap(), before);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn unsupported_suffix_prevents_all_redo_and_torn_tail_is_ignored() {
        // 0.2-D file-layout test (EOF = end of log): Mode A writer.
        crate::v2::set_thread_mode_for_test(Some(crate::v2::DurabilityMode::Flush));
        let dir = directory();
        let mut wal = Wal::create(&dir).unwrap();
        wal.begin().unwrap();
        wal.commit().unwrap();
        drop(wal);
        let path = dir.join("phobos.wal");
        let original = fs::read(&path).unwrap();
        let mut file = fs::OpenOptions::new().append(true).open(&path).unwrap();
        file.write_all(b"PHWL\x03\x00").unwrap();
        drop(file);
        let mut calls = 0;
        assert!(
            visit_committed(&path, |_, _| {
                calls += 1;
                Ok(())
            })
            .is_err()
        );
        assert_eq!(calls, 0);
        let mut torn = original;
        torn.extend_from_slice(b"PHW");
        fs::write(&path, &torn).unwrap();
        let report = visit_committed(&path, |_, _| {
            calls += 1;
            Ok(())
        })
        .unwrap();
        assert_eq!(calls, 2);
        assert_eq!(report.tail, super::super::Tail::PartialHeader);
        assert_eq!(fs::read(&path).unwrap(), torn);
        fs::remove_dir_all(dir).unwrap();
    }
}
