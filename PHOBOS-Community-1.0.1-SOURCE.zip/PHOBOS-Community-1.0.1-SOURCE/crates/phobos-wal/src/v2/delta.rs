//! 0.2-D compact page redo: a page delta is a short program over one 8 KB
//! page image. `WRITE(offset, bytes)` stores bytes; `MOVE(dst, src, len)` is a
//! memmove within the page (the shifted tail of a packed B+tree leaf after a
//! mid-page insert or delete). Ops are applied in order. The encoder is
//! generic: it knows nothing about heap or index layouts, and it only emits a
//! program after replaying it against the base and reproducing the target
//! image exactly.
use phobos_error::{ErrorCode, PhobosError};

pub(super) const PAGE: usize = 8192;
pub(super) const OP_WRITE: u8 = 1;
pub(super) const OP_MOVE: u8 = 2;
/// Fixed bytes of one WRITE op before its data.
const WRITE_HEAD: usize = 5;
/// Two changed runs separated by at most this many equal bytes become one
/// WRITE (a new op costs `WRITE_HEAD` bytes).
const MERGE_GAP: usize = WRITE_HEAD;
/// Only the page body is searched for shifted runs.
const BODY_START: usize = 64;
const PROBE: usize = 16;
const MIN_MOVE: usize = 32;
const MAX_MOVES: usize = 3;
/// Largest shift found by outward search (bytes); larger shifts are found
/// through the packed-data-end candidate.
const MAX_SHIFT: usize = 512;
/// Below this many changed bytes a plain WRITE program is already small.
const MOVE_WORTHWHILE: usize = 128;

type Result<T> = std::result::Result<T, PhobosError>;

fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidWal, message)
}

fn u16_at(ops: &[u8], at: usize) -> usize {
    usize::from(u16::from_le_bytes([ops[at], ops[at + 1]]))
}

/// Validate op framing and bounds without applying. `moves` is false for a
/// zero-elided full image, which may only contain ascending, disjoint WRITEs.
pub(super) fn validate(ops: &[u8], moves: bool) -> Result<()> {
    let mut at = 0;
    let mut floor = 0;
    while at < ops.len() {
        match ops[at] {
            OP_WRITE => {
                if ops.len() - at < WRITE_HEAD {
                    return Err(invalid("truncated page-delta WRITE"));
                }
                let offset = u16_at(ops, at + 1);
                let len = u16_at(ops, at + 3);
                if len == 0 || offset + len > PAGE || ops.len() - at - WRITE_HEAD < len {
                    return Err(invalid("page-delta WRITE out of bounds"));
                }
                if !moves {
                    if offset < floor {
                        return Err(invalid("page-image WRITEs are not ascending"));
                    }
                    floor = offset + len;
                }
                at += WRITE_HEAD + len;
            }
            OP_MOVE if moves => {
                if ops.len() - at < 7 {
                    return Err(invalid("truncated page-delta MOVE"));
                }
                let dst = u16_at(ops, at + 1);
                let src = u16_at(ops, at + 3);
                let len = u16_at(ops, at + 5);
                if len == 0 || dst == src || dst + len > PAGE || src + len > PAGE {
                    return Err(invalid("page-delta MOVE out of bounds"));
                }
                at += 7;
            }
            _ => return Err(invalid("unknown page-delta op")),
        }
    }
    Ok(())
}

/// Apply validated ops in order.
pub(super) fn apply(page: &mut [u8; PAGE], ops: &[u8]) -> Result<()> {
    validate(ops, true)?;
    let mut at = 0;
    while at < ops.len() {
        if ops[at] == OP_WRITE {
            let offset = u16_at(ops, at + 1);
            let len = u16_at(ops, at + 3);
            page[offset..offset + len].copy_from_slice(&ops[at + 5..at + 5 + len]);
            at += WRITE_HEAD + len;
        } else {
            let dst = u16_at(ops, at + 1);
            let src = u16_at(ops, at + 3);
            let len = u16_at(ops, at + 5);
            page.copy_within(src..src + len, dst);
            at += 7;
        }
    }
    Ok(())
}

/// Changed byte runs of `a` vs `b`, merged across short equal gaps. Equal
/// 64-byte blocks (most of a page) are skipped with one slice comparison.
fn spans(a: &[u8; PAGE], b: &[u8; PAGE], out: &mut Vec<(usize, usize)>) {
    out.clear();
    let mut current: Option<(usize, usize)> = None;
    for block in 0..PAGE / 64 {
        let at = block * 64;
        if a[at..at + 64] == b[at..at + 64] {
            continue;
        }
        for word in at / 8..at / 8 + 8 {
            let x = u64::from_le_bytes(a[word * 8..word * 8 + 8].try_into().expect("word"));
            let y = u64::from_le_bytes(b[word * 8..word * 8 + 8].try_into().expect("word"));
            let diff = x ^ y;
            if diff == 0 {
                continue;
            }
            // Little-endian: the lowest set byte is the first differing byte.
            let first = word * 8 + (diff.trailing_zeros() / 8) as usize;
            let last = word * 8 + 7 - (diff.leading_zeros() / 8) as usize;
            current = match current {
                Some((start, end)) if first <= end + MERGE_GAP => Some((start, last + 1)),
                Some(done) => {
                    out.push(done);
                    Some((first, last + 1))
                }
                None => Some((first, last + 1)),
            };
        }
    }
    if let Some(done) = current {
        out.push(done);
    }
}

fn probe_at(page: &[u8; PAGE], at: usize) -> u128 {
    u128::from_le_bytes(page[at..at + PROBE].try_into().expect("probe"))
}

/// Index just past the last non-zero byte (0 for an all-zero page).
fn data_end(page: &[u8; PAGE]) -> usize {
    const ZERO: [u8; 64] = [0; 64];
    let mut block = PAGE / 64;
    while block > 0 && page[(block - 1) * 64..block * 64] == ZERO {
        block -= 1;
    }
    let mut end = block * 64;
    while end > 0 && page[end - 1] == 0 {
        end -= 1;
    }
    end
}

/// Explain target bytes [start, end) as a shifted copy of `base`: returns
/// (shift, run start, run end) with target[j] == base[j - shift] on the run.
/// The first candidate shift is the change in the page's packed-data end
/// (one insert or delete in a packed leaf); otherwise a short outward search
/// from each end of the changed region.
fn find_move(
    base: &[u8; PAGE],
    target: &[u8; PAGE],
    start: usize,
    end: usize,
) -> Option<(isize, usize, usize)> {
    let extend = |at: usize, shift: isize| -> (usize, usize) {
        let index = |j: usize| (j as isize - shift) as usize;
        let floor = start.max(if shift > 0 { shift as usize } else { 0 });
        let mut low = at;
        while low >= floor + 8 && target[low - 8..low] == base[index(low - 8)..index(low)] {
            low -= 8;
        }
        while low > floor && target[low - 1] == base[index(low - 1)] {
            low -= 1;
        }
        let ceiling = end.min(if shift < 0 {
            PAGE - (-shift) as usize
        } else {
            PAGE
        });
        let mut high = at + PROBE;
        while high + 8 <= ceiling && target[high..high + 8] == base[index(high)..index(high + 8)] {
            high += 8;
        }
        while high < ceiling && target[high] == base[index(high)] {
            high += 1;
        }
        (low, high)
    };
    let fits = |source: isize| source >= 0 && source as usize <= PAGE - PROBE;
    let mut best: Option<(isize, usize, usize)> = None;
    let consider = |shift: isize, at: usize, best: &mut Option<(isize, usize, usize)>| {
        let (low, high) = extend(at, shift);
        if best.is_none_or(|(_, l, h)| high - low > h - l) {
            *best = Some((shift, low, high));
        }
    };
    let packed = data_end(target) as isize - data_end(base) as isize;
    for at in [end - PROBE, start] {
        let probe = probe_at(target, at);
        if probe == 0 {
            continue;
        }
        if packed != 0
            && fits(at as isize - packed)
            && probe_at(base, (at as isize - packed) as usize) == probe
        {
            consider(packed, at, &mut best);
            if best.is_some_and(|(_, low, high)| 2 * (high - low) >= end - start) {
                break;
            }
            continue;
        }
        for distance in 1..=MAX_SHIFT {
            let below = at
                .checked_sub(distance)
                .filter(|s| probe_at(base, *s) == probe);
            let above =
                Some(at + distance).filter(|s| *s <= PAGE - PROBE && probe_at(base, *s) == probe);
            if let Some(source) = below.or(above) {
                consider(at as isize - source as isize, at, &mut best);
                break;
            }
            if distance > at && at + distance > PAGE - PROBE {
                break;
            }
        }
        if best.is_some_and(|(_, low, high)| 2 * (high - low) >= end - start) {
            break;
        }
    }
    best.filter(|(_, low, high)| high - low >= MIN_MOVE)
}

fn push_u16(out: &mut Vec<u8>, value: usize) {
    out.extend_from_slice(&(value as u16).to_le_bytes());
}

/// Reusable encoder state (two page buffers and a span list).
pub(super) struct Encoder {
    work: Box<[u8; PAGE]>,
    target: Box<[u8; PAGE]>,
    spans: Vec<(usize, usize)>,
}
impl Default for Encoder {
    fn default() -> Self {
        Self {
            work: Box::new([0; PAGE]),
            target: Box::new([0; PAGE]),
            spans: Vec::with_capacity(64),
        }
    }
}
impl Encoder {
    /// Append a delta turning `base` into `image` to `out`, ignoring the
    /// stamped fields in `masked` (copied from `base`; redo re-stamps them).
    /// Returns false, leaving `out` unchanged, if no delta of at most `limit`
    /// op bytes reproduces the image.
    pub(super) fn encode(
        &mut self,
        base: &[u8; PAGE],
        image: &[u8; PAGE],
        masked: &[(usize, usize)],
        limit: usize,
        out: &mut Vec<u8>,
    ) -> bool {
        let start_len = out.len();
        self.target.copy_from_slice(image);
        for &(offset, len) in masked {
            self.target[offset..offset + len].copy_from_slice(&base[offset..offset + len]);
        }
        self.work.copy_from_slice(base);
        for _ in 0..MAX_MOVES {
            spans(&self.work, &self.target, &mut self.spans);
            let changed: usize = self.spans.iter().map(|(low, high)| high - low).sum();
            if changed < MOVE_WORTHWHILE {
                break;
            }
            let Some(&(first, _)) = self.spans.iter().find(|(_, end)| *end > BODY_START) else {
                break;
            };
            let last = self.spans.last().expect("nonempty spans").1;
            let low = first.max(BODY_START);
            if last < low + 3 * PROBE {
                break;
            }
            let Some((shift, run_low, run_high)) = find_move(&self.work, &self.target, low, last)
            else {
                break;
            };
            let source = (run_low as isize - shift) as usize;
            self.work
                .copy_within(source..source + (run_high - run_low), run_low);
            out.push(OP_MOVE);
            push_u16(out, run_low);
            push_u16(out, source);
            push_u16(out, run_high - run_low);
        }
        spans(&self.work, &self.target, &mut self.spans);
        for &(low, high) in &self.spans {
            if out.len() - start_len + WRITE_HEAD + (high - low) > limit {
                out.truncate(start_len);
                return false;
            }
            out.push(OP_WRITE);
            push_u16(out, low);
            push_u16(out, high - low);
            out.extend_from_slice(&self.target[low..high]);
        }
        // Self-check: the program must reproduce the masked target exactly.
        self.work.copy_from_slice(base);
        if apply(&mut self.work, &out[start_len..]).is_err() || self.work[..] != self.target[..] {
            phobos_observability::event("wal.delta_selfcheck_failures", 1);
            out.truncate(start_len);
            return false;
        }
        true
    }
}

/// Bytes a zero-elided image of `image` needs (ops only).
pub(super) fn sparse_len(image: &[u8; PAGE]) -> usize {
    let mut total = 0;
    sparse_runs(image, |low, high| total += WRITE_HEAD + high - low);
    total
}

/// Ascending non-zero runs, merged across short zero gaps.
fn sparse_runs(image: &[u8; PAGE], mut visit: impl FnMut(usize, usize)) {
    const ZERO: [u8; 64] = [0; 64];
    let mut current: Option<(usize, usize)> = None;
    for block in 0..PAGE / 64 {
        let at = block * 64;
        if image[at..at + 64] == ZERO {
            continue;
        }
        for word in at / 8..at / 8 + 8 {
            let value = u64::from_le_bytes(image[word * 8..word * 8 + 8].try_into().expect("word"));
            if value == 0 {
                continue;
            }
            let first = word * 8 + (value.trailing_zeros() / 8) as usize;
            let last = word * 8 + 7 - (value.leading_zeros() / 8) as usize;
            current = match current {
                Some((low, high)) if first <= high + MERGE_GAP => Some((low, last + 1)),
                Some((low, high)) => {
                    visit(low, high);
                    Some((first, last + 1))
                }
                None => Some((first, last + 1)),
            };
        }
    }
    if let Some((low, high)) = current {
        visit(low, high);
    }
}

pub(super) fn encode_sparse(image: &[u8; PAGE], out: &mut Vec<u8>) {
    sparse_runs(image, |low, high| {
        out.push(OP_WRITE);
        push_u16(out, low);
        push_u16(out, high - low);
        out.extend_from_slice(&image[low..high]);
    });
}

pub(super) fn decode_sparse(ops: &[u8]) -> Result<Box<[u8; PAGE]>> {
    validate(ops, false)?;
    let mut image = Box::new([0; PAGE]);
    apply(&mut image, ops)?;
    Ok(image)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn page(seed: u64) -> [u8; PAGE] {
        let mut bytes = [0; PAGE];
        let mut x = seed | 1;
        for byte in bytes.iter_mut().take(6000) {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            *byte = x as u8;
        }
        bytes
    }

    fn roundtrip(base: &[u8; PAGE], image: &[u8; PAGE]) -> usize {
        let mut encoder = Encoder::default();
        let mut ops = Vec::new();
        assert!(encoder.encode(base, image, &[], PAGE, &mut ops));
        let mut replay = *base;
        apply(&mut replay, &ops).unwrap();
        assert_eq!(&replay[..], &image[..]);
        ops.len()
    }

    #[test]
    fn identical_pages_need_no_ops_and_small_writes_stay_small() {
        let base = page(3);
        assert_eq!(roundtrip(&base, &base), 0);
        let mut image = base;
        image[100] ^= 1;
        image[7000..7040].fill(9);
        assert!(roundtrip(&base, &image) < 60);
    }

    #[test]
    fn mid_page_insert_and_delete_are_one_move_plus_the_entry() {
        let base = page(5);
        // Insert 37 bytes at 2000 within a packed region ending at 6000.
        let mut inserted = base;
        inserted.copy_within(2000..6000, 2037);
        inserted[2000..2037].fill(0xab);
        let size = roundtrip(&base, &inserted);
        assert!(size < 64, "insert delta {size}");
        // Delete 29 bytes at 3000; the freed tail is zeroed.
        let mut deleted = base;
        deleted.copy_within(3029..6000, 3000);
        deleted[5971..6000].fill(0);
        let size = roundtrip(&base, &deleted);
        assert!(size < 64, "delete delta {size}");
    }

    #[test]
    fn random_rewrites_roundtrip_and_respect_the_limit() {
        for seed in 1..40u64 {
            let base = page(seed);
            let image = page(seed * 7919);
            let mut encoder = Encoder::default();
            let mut ops = vec![42];
            assert!(!encoder.encode(&base, &image, &[], 512, &mut ops));
            assert_eq!(ops, vec![42]);
            roundtrip(&base, &image);
        }
    }

    #[test]
    fn masked_fields_are_ignored_and_sparse_images_roundtrip() {
        let base = page(11);
        let mut image = base;
        image[16..24].copy_from_slice(&99u64.to_le_bytes());
        let mut encoder = Encoder::default();
        let mut ops = Vec::new();
        assert!(encoder.encode(&base, &image, &[(16, 8)], PAGE, &mut ops));
        assert!(ops.is_empty());
        let mut sparse = [0; PAGE];
        sparse[0..40].fill(1);
        sparse[7000..7100].fill(2);
        let mut ops = Vec::new();
        encode_sparse(&sparse, &mut ops);
        assert_eq!(ops.len(), sparse_len(&sparse));
        assert_eq!(&decode_sparse(&ops).unwrap()[..], &sparse[..]);
    }

    #[test]
    fn malformed_programs_are_rejected() {
        for ops in [
            vec![OP_WRITE, 0, 0],
            vec![OP_WRITE, 0xff, 0x1f, 2, 0, 1, 2],
            vec![OP_WRITE, 0, 0, 0, 0],
            vec![OP_MOVE, 0, 0, 0, 0, 1, 0],
            vec![OP_MOVE, 0, 0x20, 1, 0, 1, 0],
            vec![9],
        ] {
            assert!(validate(&ops, true).is_err(), "{ops:?}");
        }
        // Zero-elided images: no MOVE, ascending disjoint WRITEs only.
        assert!(validate(&[OP_MOVE, 1, 0, 0, 0, 1, 0], false).is_err());
        let descending = [OP_WRITE, 10, 0, 1, 0, 5, OP_WRITE, 2, 0, 1, 0, 6];
        assert!(validate(&descending, false).is_err());
        assert!(validate(&descending, true).is_ok());
    }
}

/// Encoder cost on real 0.2-C page pairs (base, next image), release mode:
/// `PHOBOS_DELTA_PAIRS=pairs.bin cargo test --release -p phobos-wal -- --ignored delta_bench --nocapture`
#[cfg(test)]
#[test]
#[ignore = "benchmark: needs PHOBOS_DELTA_PAIRS"]
fn delta_bench() {
    let Ok(path) = std::env::var("PHOBOS_DELTA_PAIRS") else {
        return;
    };
    let bytes = std::fs::read(path).unwrap();
    let mut pairs = Vec::new();
    for chunk in bytes.chunks_exact(9 + 2 * PAGE) {
        let base: [u8; PAGE] = chunk[9..9 + PAGE].try_into().unwrap();
        let image: [u8; PAGE] = chunk[9 + PAGE..].try_into().unwrap();
        let (lsn, checksum) = if chunk[0] == 1 {
            (16, 32)
        } else if u64::from_le_bytes(chunk[1..9].try_into().unwrap()) == 0 {
            (32, 28)
        } else {
            (40, 36)
        };
        pairs.push((base, image, [(7, 1), (lsn, 8), (checksum, 4)]));
    }
    let mut encoder = Encoder::default();
    let mut ops = Vec::new();
    for round in 0..3 {
        let (mut total, mut sizes) = (std::time::Duration::ZERO, 0usize);
        let mut sparse = std::time::Duration::ZERO;
        let mut crc = std::time::Duration::ZERO;
        for (base, image, masked) in &pairs {
            // Warm the pair first: in the writer both pages are cache-hot.
            ops.clear();
            encoder.encode(base, image, masked, 4096, &mut ops);
            std::hint::black_box(crc32c::crc32c(base));
            std::hint::black_box(sparse_len(image));
            ops.clear();
            let start = std::time::Instant::now();
            assert!(encoder.encode(base, image, masked, 4096, &mut ops) || ops.is_empty());
            total += start.elapsed();
            sizes += ops.len();
            let start = std::time::Instant::now();
            std::hint::black_box(sparse_len(image));
            sparse += start.elapsed();
            let start = std::time::Instant::now();
            std::hint::black_box(crc32c::crc32c(base));
            crc += start.elapsed();
        }
        let mut by_kind =
            std::collections::BTreeMap::<(bool, bool), (std::time::Duration, u32)>::new();
        for (base, image, masked) in &pairs {
            ops.clear();
            encoder.encode(base, image, masked, 4096, &mut ops);
            ops.clear();
            let start = std::time::Instant::now();
            encoder.encode(base, image, masked, 4096, &mut ops);
            let took = start.elapsed();
            let entry = by_kind
                .entry((masked[1].0 == 16, ops.first() == Some(&OP_MOVE)))
                .or_default();
            entry.0 += took;
            entry.1 += 1;
        }
        for ((heap, moved), (time, count)) in by_kind {
            eprintln!(
                "  heap={heap} move={moved} n={count} avg={:?}",
                time / count
            );
        }
        let n = pairs.len() as u32;
        eprintln!(
            "round {round}: pairs={n} encode avg={:?} ops avg={}B sparse_len avg={:?} crc8k avg={:?}",
            total / n,
            sizes / pairs.len(),
            sparse / n,
            crc / n
        );
    }
}
