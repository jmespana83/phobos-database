//! 0.2-I.2: replication-aware retention of WAL history across full checkpoints.
//!
//! A full checkpoint (clean shutdown, `CHECKPOINT`, online backup, crash
//! recovery, anchor upgrade) replaces the active WAL with a single anchor and,
//! before 0.2-I.2, deleted every sealed segment. Local recovery no longer needs
//! those records, but a registered replication slot may: its LSN is the last
//! WAL record its consumer has *replayed*, so every record after it must remain
//! readable until the slot advances or is dropped.
//!
//! Records still protected by a slot are moved (never rewritten) into
//! `phobos.wal-retained/`, a subdirectory that local recovery, segment
//! scanning, backups and data-file listings never read. File contents and
//! names are byte-for-byte the existing V2 segment format
//! (`phobos.wal.<first LSN as 16 hex digits>.seg`). Only replication / PITR
//! readers ([`visit_history`]) consult it. Without slots nothing is retained
//! and behaviour is identical to 0.2-I.1.
use super::{Record, Tail, read_record, scan};
use phobos_error::{ErrorCode, PhobosError};
use std::{
    fs::{self, File, OpenOptions},
    io::{BufReader, Seek},
    path::{Path, PathBuf},
};

type Result<T> = std::result::Result<T, PhobosError>;

/// Subdirectory of a data directory (or WAL archive) holding retained history.
pub const RETAINED_DIR: &str = "phobos.wal-retained";
const NAME: &str = "phobos.wal";
const TEMP: &str = "phobos.wal.retaining.tmp";

/// The oldest LSN any registered consumer still has to read *after*:
/// `min(slot replay LSN)`. `None` when no slot exists.
/// An unreadable slot file must neither lose protected WAL nor stop a
/// shutdown or crash recovery: retain everything (frontier 0) and prune
/// nothing until it is readable again.
pub(super) fn frontier(directory: &Path) -> Result<Option<u64>> {
    match super::replication_retention_lsn(directory) {
        Ok(frontier) => Ok(frontier),
        Err(_) => {
            phobos_observability::event("wal.retention_slot_file_unreadable", 1);
            Ok(Some(0))
        }
    }
}

/// A hard link (or copy) of the active WAL made before a checkpoint replaces it.
pub(super) struct Kept {
    path: PathBuf,
    valid_len: u64,
}

/// Before the active WAL is replaced by a checkpoint anchor: if a slot still
/// needs any of its records, keep the file under `phobos.wal-retained/`.
/// A hard link costs no copy; the file stops being the active WAL only when
/// the caller renames the new anchor over `phobos.wal`.
pub(super) fn preserve_active(directory: &Path, frontier: Option<u64>) -> Result<Option<Kept>> {
    let Some(frontier) = frontier else {
        return Ok(None);
    };
    let active = directory.join(NAME);
    // Tolerates the torn tail a crash may leave (recovery checkpoint).
    let report = scan::inspect_file(&active, true)?;
    if report.last_lsn <= frontier || !has_transaction_after(&active, report.valid_len, frontier)? {
        // Nothing, or only format anchors, after the frontier. Discarding
        // anchors leaves a gap no transaction began in, which readers
        // verify (equal transaction cursors) and bridge; retaining them would
        // keep one tiny file per idle restart.
        return Ok(None);
    }
    let first = first_lsn(&active)?;
    let retained = directory.join(RETAINED_DIR);
    fs::create_dir_all(&retained)?;
    let temporary = retained.join(TEMP);
    remove_if_exists(&temporary)?;
    if fs::hard_link(&active, &temporary).is_err() {
        copy_prefix(&active, &temporary, report.valid_len)?;
    }
    OpenOptions::new()
        .write(true)
        .open(&temporary)?
        .sync_all()?;
    // A file that ends torn or inside a transaction can only be the active
    // file of a crash-recovery checkpoint. It is marked so that readers alone
    // may treat its tail (and only its tail) leniently.
    let recovered = report.tail != Tail::Clean || report.incomplete_transactions != 0;
    let target = retained.join(retained_name(first, report.last_lsn, recovered));
    // A file with the same first LSN can only be an earlier link of this same
    // active file (a checkpoint interrupted before its replacement, then crash
    // recovery); this one is a superset.
    for (start, _, _, path) in retained_files(directory)? {
        if start == first && path != target {
            remove_if_exists(&path)?;
        }
    }
    fs::rename(&temporary, &target)?;
    sync_directory(&retained)?;
    sync_directory(directory)?;
    phobos_observability::event("wal.retained_active_files", 1);
    Ok(Some(Kept {
        path: target,
        valid_len: report.valid_len,
    }))
}

/// After the active WAL was replaced: drop the preallocated zero tail or torn
/// suffix of the kept file. It is no longer linked as `phobos.wal`.
pub(super) fn finish_preserve(kept: Option<Kept>) -> Result<()> {
    let Some(kept) = kept else {
        return Ok(());
    };
    let file = OpenOptions::new().write(true).open(&kept.path)?;
    if file.metadata()?.len() > kept.valid_len {
        file.set_len(kept.valid_len)?;
        file.sync_all()?;
    }
    Ok(())
}

/// Replaces the former "remove every sealed segment" step of a full
/// checkpoint: segments with records after the frontier move to retained
/// history, the rest are deleted exactly as before.
/// `replaced_start` is the first LSN of the active file this checkpoint just
/// replaced: the successor of the newest sealed segment.
pub(super) fn retire_sealed(
    directory: &Path,
    frontier: Option<u64>,
    replaced_start: u64,
) -> Result<()> {
    let segments = scan::segments(&directory.join(NAME))?;
    let mut starts = Vec::new();
    for segment in &segments {
        if !segment.active {
            starts.push(parse_segment(&segment.path)?.0);
        }
    }
    starts.push(replaced_start);
    let mut moved = 0u64;
    for segment in segments {
        if segment.active {
            continue;
        }
        let start = parse_segment(&segment.path)?.0;
        // The successor's first LSN bounds this segment's last LSN from above
        // (exact unless an interrupted checkpoint already moved the successor
        // away). Below the frontier the bound suffices; otherwise the exact
        // last LSN, which the retained name must record, comes from a strict
        // scan of this sealed (fsynced) segment.
        let bound = last_lsn_bound(&starts, start);
        let needed = frontier.is_some_and(|frontier| bound > frontier);
        let last = if needed {
            scan::inspect_file(&segment.path, false)?.last_lsn
        } else {
            bound
        };
        let needed = needed && frontier.is_some_and(|frontier| last > frontier);
        if needed {
            let retained = directory.join(RETAINED_DIR);
            fs::create_dir_all(&retained)?;
            // A stale same-start link of this file (an interrupted checkpoint
            // of its time as the active file) is superseded.
            for (other, _, _, path) in retained_files(directory)? {
                if other == start {
                    remove_if_exists(&path)?;
                }
            }
            fs::rename(
                &segment.path,
                retained.join(retained_name(start, last, false)),
            )?;
            moved += 1;
        } else {
            fs::remove_file(&segment.path)?;
        }
    }
    if moved != 0 {
        sync_directory(&directory.join(RETAINED_DIR))?;
        phobos_observability::event("wal.retained_sealed_segments", moved);
    }
    sync_directory(directory)
}

/// Retained files no consumer needs any more: every record is at or below the
/// frontier, or no slot exists at all (the explicit drop of the last slot).
/// Decided from file names only, so pruning never scans retained bytes.
pub(super) fn prunable(directory: &Path, frontier: Option<u64>) -> Result<Vec<PathBuf>> {
    let retained = directory.join(RETAINED_DIR);
    if !retained.exists() {
        return Ok(Vec::new());
    }
    let starts = history_starts(directory)?;
    let mut prune = Vec::new();
    for (start, last, _, path) in retained_files(directory)? {
        let last = last.unwrap_or_else(|| last_lsn_bound(&starts, start));
        if frontier.is_none_or(|frontier| last <= frontier) {
            prune.push(path);
        }
    }
    Ok(prune)
}

pub(super) fn prune(directory: &Path, paths: &[PathBuf]) -> Result<()> {
    if paths.is_empty() {
        return Ok(());
    }
    for path in paths {
        remove_if_exists(path)?;
    }
    let retained = directory.join(RETAINED_DIR);
    sync_directory(&retained)?;
    if fs::read_dir(&retained)?.next().is_none() {
        fs::remove_dir(&retained)?;
        sync_directory(directory)?;
    }
    phobos_observability::event("wal.retained_files_pruned", paths.len() as u64);
    Ok(())
}

/// One file of the WAL history of a data directory or WAL archive.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HistoryFile {
    pub path: PathBuf,
    /// LSN of the file's format anchor (its first record).
    pub start_lsn: u64,
    /// Last LSN recorded in a retained file's name (verified when read).
    pub last_lsn: Option<u64>,
    /// The data directory's active `phobos.wal`.
    pub active: bool,
    /// Under `phobos.wal-retained/`.
    pub retained: bool,
    /// Retained former active file of a crash-recovery checkpoint
    /// (`.recovered.seg`): it may end torn or inside a dead transaction.
    pub recovered: bool,
    pub bytes: u64,
}

/// Retained files, sealed segments and the active file, in LSN order. A
/// duplicate start LSN (a link left by an interrupted checkpoint) keeps the
/// data-directory file.
pub fn history_files(directory: &Path) -> Result<Vec<HistoryFile>> {
    let mut files = Vec::new();
    for segment in scan::segments(&directory.join(NAME))? {
        let start = if segment.active {
            first_lsn(&segment.path)?
        } else {
            parse_segment(&segment.path)?.0
        };
        files.push(HistoryFile {
            bytes: fs::metadata(&segment.path)?.len(),
            path: segment.path,
            start_lsn: start,
            last_lsn: None,
            active: segment.active,
            retained: false,
            recovered: false,
        });
    }
    // Several retained files with one first LSN (copy fallback interrupted by
    // a crash) keep the one with the highest recorded last LSN.
    let mut retained = retained_files(directory)?;
    retained.sort_by_key(|(start, last, _, _)| (*start, std::cmp::Reverse(*last)));
    for (start, last, recovered, path) in retained {
        if files.iter().any(|file| file.start_lsn == start) {
            continue;
        }
        files.push(HistoryFile {
            bytes: fs::metadata(&path)?.len(),
            path,
            start_lsn: start,
            last_lsn: last,
            active: false,
            retained: true,
            recovered,
        });
    }
    files.sort_by_key(|file| (file.start_lsn, file.active));
    Ok(files)
}

/// Visit every validated record with `after < lsn <= through` of the WAL
/// history (retained files, sealed segments, active file) once, in LSN order.
///
/// The second visitor argument is true for records of a *dead* transaction:
/// one that was still incomplete when its file stopped being the active WAL
/// (a crash), so it can never commit. Callers decide how to bridge it.
/// Continuity is not assumed: callers must check that LSNs are contiguous.
pub fn visit_history(
    directory: &Path,
    after: u64,
    through: u64,
    mut visitor: impl FnMut(&Record, bool) -> Result<()>,
) -> Result<()> {
    let files = history_files(directory)?;
    let mut emitted = after;
    for (index, file) in files.iter().enumerate() {
        // No let-chains: the pinned toolchain (1.85) predates them.
        if files
            .get(index + 1)
            .is_some_and(|next| next.start_lsn.saturating_sub(1) <= emitted)
        {
            continue;
        }
        if file.start_lsn > through {
            break;
        }
        let last = index + 1 == files.len();
        // Only the live active file and a retained crash-recovery file may end
        // torn; every other file (sealed segments, retained or not) is read
        // strictly, so damage is an error, never a shorter file.
        let report = scan::inspect_file(&file.path, file.active || file.recovered)?;
        if file
            .last_lsn
            .is_some_and(|recorded| recorded != report.last_lsn)
        {
            return Err(invalid(
                "retained WAL file does not end at the LSN recorded in its name",
            ));
        }
        // Only a crash-recovery file can hold a transaction that never ends
        // (it can no longer commit); anywhere else an unfinished transaction
        // before a later file is damage.
        let dead = if report.incomplete_transactions == 0 {
            None
        } else if file.recovered && !last {
            Some(report.next_txn_id.saturating_sub(1))
        } else if !last {
            return Err(invalid("sealed WAL file ends inside a transaction"));
        } else {
            None
        };
        let mut reader = BufReader::with_capacity(scan::SCAN_BUFFER, File::open(&file.path)?);
        while reader.stream_position()? < report.valid_len {
            let record = read_record(&mut reader)?
                .ok_or_else(|| invalid("WAL history changed while it was read"))?;
            if record.lsn <= emitted {
                continue;
            }
            if record.lsn > through {
                return Ok(());
            }
            emitted = record.lsn;
            let is_dead = dead.is_some_and(|id| record.txn_id == id && record.txn_id != 0);
            visitor(&record, is_dead)?;
        }
        if report.tail != Tail::Clean && !last {
            phobos_observability::event("wal.history_torn_retained_tail", 1);
        }
    }
    Ok(())
}

/// Summary of the WAL history used by diagnostics.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct RetentionReport {
    pub files: usize,
    pub bytes: u64,
    pub retained_files: usize,
    pub retained_bytes: u64,
    pub oldest_lsn: u64,
    pub slots: Vec<(String, u64)>,
}

pub fn retention_report(directory: &Path) -> Result<RetentionReport> {
    let files = history_files(directory)?;
    Ok(RetentionReport {
        files: files.len(),
        bytes: files.iter().map(|file| file.bytes).sum(),
        retained_files: files.iter().filter(|file| file.retained).count(),
        retained_bytes: files
            .iter()
            .filter(|file| file.retained)
            .map(|file| file.bytes)
            .sum(),
        oldest_lsn: files.first().map_or(0, |file| file.start_lsn),
        slots: super::replication_slots(directory)?,
    })
}

/// Upper bound of a file's last LSN: one below the next file's first LSN.
fn last_lsn_bound(starts: &[u64], start: u64) -> u64 {
    starts
        .iter()
        .copied()
        .filter(|next| *next > start)
        .min()
        .map_or(u64::MAX, |next| next - 1)
}

fn history_starts(directory: &Path) -> Result<Vec<u64>> {
    Ok(history_files(directory)?
        .into_iter()
        .map(|file| file.start_lsn)
        .collect())
}

/// Retained files: (first LSN, last LSN when recorded in the name, path).
/// A retained file: (first LSN, recorded last LSN, crash-recovery marker, path).
type RetainedFile = (u64, Option<u64>, bool, PathBuf);

fn retained_files(directory: &Path) -> Result<Vec<RetainedFile>> {
    let retained = directory.join(RETAINED_DIR);
    let mut files = Vec::new();
    if !retained.exists() {
        return Ok(files);
    }
    for entry in fs::read_dir(&retained)? {
        let entry = entry?;
        let path = entry.path();
        if entry.file_name() == TEMP {
            continue;
        }
        if !entry.file_type()?.is_file() {
            return Err(invalid("retained WAL entry is not a regular file"));
        }
        let (start, last) = parse_segment(&path)?;
        let recovered = path
            .file_name()
            .and_then(|name| name.to_str())
            .is_some_and(|name| name.ends_with(RECOVERED_SUFFIX));
        files.push((start, last, recovered, path));
    }
    files.sort();
    Ok(files)
}

/// Retained files are named by their first and last LSN, so pruning never
/// has to read them: `phobos.wal.<first>.<last>.seg` (16 hex digits each).
/// The file contents are the unchanged V2 segment format.
fn retained_name(start: u64, last: u64, recovered: bool) -> String {
    if recovered {
        format!("phobos.wal.{start:016x}.{last:016x}{RECOVERED_SUFFIX}")
    } else {
        format!("phobos.wal.{start:016x}.{last:016x}.seg")
    }
}
const RECOVERED_SUFFIX: &str = ".recovered.seg";

/// `phobos.wal.<first>.seg` (data-directory sealed segment) or
/// `phobos.wal.<first>.<last>.seg` (retained history).
fn parse_segment(path: &Path) -> Result<(u64, Option<u64>)> {
    let name = path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| invalid("invalid WAL segment name"))?;
    let rest = name
        .strip_prefix("phobos.wal.")
        .and_then(|rest| {
            rest.strip_suffix(RECOVERED_SUFFIX)
                .or_else(|| rest.strip_suffix(".seg"))
        })
        .ok_or_else(|| invalid("invalid WAL segment name"))?;
    let hex = |text: &str| {
        (text.len() == 16 && text.bytes().all(|byte| byte.is_ascii_hexdigit()))
            .then(|| u64::from_str_radix(text, 16).ok())
            .flatten()
            .ok_or_else(|| invalid("invalid WAL segment name"))
    };
    match rest.split_once('.') {
        None => Ok((hex(rest)?, None)),
        Some((first, last)) => {
            let (first, last) = (hex(first)?, hex(last)?);
            if last < first {
                return Err(invalid("invalid WAL segment name"));
            }
            Ok((first, Some(last)))
        }
    }
}

/// Whether any record after `frontier` belongs to a transaction (committed,
/// aborted, or left incomplete by a crash).
fn has_transaction_after(path: &Path, valid_len: u64, frontier: u64) -> Result<bool> {
    let mut reader = BufReader::with_capacity(scan::SCAN_BUFFER, File::open(path)?);
    while reader.stream_position()? < valid_len {
        let Some(record) = read_record(&mut reader)? else {
            break;
        };
        if record.lsn > frontier && record.txn_id != 0 {
            return Ok(true);
        }
    }
    Ok(false)
}

fn first_lsn(path: &Path) -> Result<u64> {
    let mut file = File::open(path)?;
    Ok(read_record(&mut file)?
        .ok_or_else(|| invalid("WAL file has no anchor"))?
        .lsn)
}

fn copy_prefix(source: &Path, destination: &Path, length: u64) -> Result<()> {
    let mut input = std::io::Read::take(File::open(source)?, length);
    let mut output = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(destination)?;
    std::io::copy(&mut input, &mut output)?;
    Ok(())
}

fn remove_if_exists(path: &Path) -> Result<()> {
    match fs::remove_file(path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
    }
}

fn sync_directory(path: &Path) -> Result<()> {
    #[cfg(unix)]
    File::open(path)?.sync_all()?;
    #[cfg(not(unix))]
    let _ = path;
    Ok(())
}

fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidWal, message)
}

#[cfg(test)]
mod tests {
    use super::super::{Body, Wal, remove_replication_slot, set_replication_slot};
    use super::*;

    fn directory() -> PathBuf {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        std::env::temp_dir().join(format!(
            "phobos-i2-retention-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        ))
    }

    fn commit(wal: &mut Wal) -> u64 {
        wal.begin().unwrap();
        wal.commit().unwrap().lsn()
    }

    fn history(dir: &Path, after: u64) -> Vec<(u64, bool, bool)> {
        let mut records = Vec::new();
        visit_history(dir, after, u64::MAX, |record, dead| {
            records.push((record.lsn, matches!(record.body, Body::Commit), dead));
            Ok(())
        })
        .unwrap();
        records
    }

    fn contiguous(records: &[(u64, bool, bool)], from: u64) -> bool {
        records
            .iter()
            .enumerate()
            .all(|(index, (lsn, _, _))| *lsn == from + index as u64)
    }

    #[test]
    fn i2_full_checkpoint_without_slot_is_unchanged() {
        let dir = directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        let last = commit(&mut wal);
        wal.checkpoint_all(last).unwrap();
        assert!(!dir.join(RETAINED_DIR).exists());
        assert_eq!(history_files(&dir).unwrap().len(), 1);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn i2_full_checkpoint_keeps_slot_protected_records_until_slot_advances() {
        let dir = directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        let first = commit(&mut wal);
        set_replication_slot(&dir, "standby", first).unwrap();
        let second = commit(&mut wal);
        let third = commit(&mut wal);
        // A clean shutdown / CHECKPOINT: the active WAL becomes one anchor.
        wal.checkpoint_all(third).unwrap();
        assert_eq!(inspect_file_report(&dir).committed_transactions, 0);
        let records = history(&dir, first);
        assert!(contiguous(&records, first + 1), "{records:?}");
        assert!(
            records
                .iter()
                .any(|(lsn, commit, _)| *lsn == second && *commit)
        );
        assert!(
            records
                .iter()
                .any(|(lsn, commit, _)| *lsn == third && *commit)
        );
        // A second restart while the consumer is still behind keeps both files.
        let fourth = commit(&mut wal);
        wal.checkpoint_all(fourth).unwrap();
        let records = history(&dir, first);
        assert!(contiguous(&records, first + 1), "{records:?}");
        assert!(records.iter().any(|(lsn, _, _)| *lsn == fourth));
        assert_eq!(retained_files(&dir).unwrap().len(), 2);
        // Advancing the slot is the act that releases history.
        set_replication_slot(&dir, "standby", fourth).unwrap();
        let fifth = commit(&mut wal);
        wal.checkpoint_all(fifth).unwrap();
        let kept = retained_files(&dir).unwrap();
        assert_eq!(kept.len(), 1, "{kept:?}");
        assert!(
            history(&dir, fourth)
                .iter()
                .any(|(lsn, _, _)| *lsn == fifth)
        );
        eprintln!("I2_RETENTION retained_after_advance={}", kept.len());
        // Dropping the last slot releases everything at the next checkpoint.
        assert!(remove_replication_slot(&dir, "standby").unwrap());
        let sixth = commit(&mut wal);
        wal.checkpoint_all(sixth).unwrap();
        assert!(!dir.join(RETAINED_DIR).exists());
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn i2_sealed_segments_move_to_retained_history_on_full_checkpoint() {
        let dir = directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        let first = commit(&mut wal);
        set_replication_slot(&dir, "standby", first).unwrap();
        let second = commit(&mut wal);
        wal.rotate_segment_for_test().unwrap();
        let third = commit(&mut wal);
        wal.checkpoint_all(third).unwrap();
        // Local recovery sees no sealed segment; the retained history has both.
        assert!(
            scan::segments(&dir.join(NAME))
                .unwrap()
                .iter()
                .all(|segment| segment.active)
        );
        let records = history(&dir, first);
        assert!(contiguous(&records, first + 1), "{records:?}");
        assert!(records.iter().any(|(lsn, _, _)| *lsn == second));
        assert!(records.iter().any(|(lsn, _, _)| *lsn == third));
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn i2_recovery_checkpoint_keeps_history_and_marks_the_dead_transaction() {
        let dir = directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        let first = commit(&mut wal);
        set_replication_slot(&dir, "standby", first).unwrap();
        let second = commit(&mut wal);
        // A crash in the middle of a transaction: BEGIN is durable, no COMMIT.
        let dead = wal.begin().unwrap();
        wal.sync_for_test().unwrap();
        drop(wal);
        let wal = Wal::recover(&dir).unwrap();
        let records = history(&dir, first);
        assert!(contiguous(&records, first + 1), "{records:?}");
        assert!(
            records
                .iter()
                .any(|(lsn, commit, _)| *lsn == second && *commit)
        );
        assert_eq!(records.iter().filter(|(_, _, dead)| *dead).count(), 1);
        let mut dead_ids = Vec::new();
        visit_history(&dir, first, u64::MAX, |record, is_dead| {
            if is_dead {
                dead_ids.push(record.txn_id);
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(dead_ids, vec![dead]);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    /// Independent-review probe: a crash after the anchor replacement but
    /// before `retire_sealed` leaves a sealed segment in the data directory
    /// while its successor is already retained. The next full checkpoint must
    /// still record the segment's exact last LSN, keeping history readable.
    #[test]
    fn i2_crash_before_sealed_segments_moved_keeps_history_readable() {
        let dir = directory();
        let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
        let first = commit(&mut wal);
        set_replication_slot(&dir, "standby", first).unwrap();
        commit(&mut wal);
        wal.rotate_segment_for_test().unwrap();
        let third = commit(&mut wal);
        wal.checkpoint_all(third).unwrap();
        drop(wal);
        let mut kept = retained_files(&dir).unwrap();
        kept.sort();
        let (start, _, _, path) = kept[0].clone();
        fs::rename(&path, dir.join(format!("phobos.wal.{start:016x}.seg"))).unwrap();
        let mut wal = Wal::recover(&dir).unwrap();
        let fourth = commit(&mut wal);
        wal.rotate_segment_for_test().unwrap();
        let last = commit(&mut wal);
        wal.checkpoint_all(last).unwrap();
        // Readable (0.2-I.2 before the review fix: "does not end at the LSN
        // recorded in its name"), and every commit after the slot is present.
        // The one gap is the recovery checkpoint's anchor-only active file,
        // which readers bridge by transaction cursor.
        let records = history(&dir, first);
        let commits: Vec<u64> = records
            .iter()
            .filter(|(_, commit, _)| *commit)
            .map(|(lsn, _, _)| *lsn)
            .collect();
        assert_eq!(commits, vec![first + 2, third, fourth, last], "{records:?}");
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }

    fn inspect_file_report(dir: &Path) -> super::super::ScanReport {
        super::super::inspect(dir.join(NAME)).unwrap()
    }
}
