//! Persistent authenticated shell; no history or password persistence.
use phobos_error::{ErrorCode, PhobosError};
use std::io::{self, IsTerminal, Write};

fn prompt(label: &str) -> Result<String, PhobosError> {
    print!("{label}");
    io::stdout().flush()?;
    let mut line = String::new();
    if io::stdin().read_line(&mut line)? == 0 {
        return Err(PhobosError::new(ErrorCode::Io, "input closed"));
    }
    Ok(line.trim_end_matches(['\r', '\n']).to_string())
}

fn password() -> Result<String, PhobosError> {
    if !io::stdin().is_terminal() {
        // Trusted redirected stdin is never echoed or retained as command history.
        return prompt("Password: ");
    }
    #[cfg(windows)]
    {
        use std::process::{Command, Stdio};
        print!("Password: ");
        io::stdout().flush()?;
        // PowerShell owns console echo handling; plaintext travels only through an
        // anonymous pipe to this process, never through argv, files or environment.
        let script = "$ErrorActionPreference='Stop'; $s=Read-Host -AsSecureString; $p=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try { [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); [Console]::Out.Write([char]0); [Console]::Out.Write([Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)); [Console]::Out.Write([char]0) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p); $s.Dispose() }";
        let output = Command::new("powershell.exe")
            .args(["-NoProfile", "-Command", script])
            .stdin(Stdio::inherit())
            .stderr(Stdio::inherit())
            .output()?;
        if !output.status.success() {
            return Err(PhobosError::new(
                ErrorCode::Authentication,
                "password prompt cancelled",
            ));
        }
        let start = output
            .stdout
            .iter()
            .position(|byte| *byte == 0)
            .ok_or_else(|| {
                PhobosError::new(
                    ErrorCode::Authentication,
                    "password prompt returned no credential",
                )
            })?;
        let end = output
            .stdout
            .iter()
            .rposition(|byte| *byte == 0)
            .filter(|end| *end > start)
            .ok_or_else(|| {
                PhobosError::new(ErrorCode::Authentication, "incomplete password input")
            })?;
        String::from_utf8(output.stdout[start + 1..end].to_vec())
            .map_err(|_| PhobosError::new(ErrorCode::Authentication, "invalid password input"))
    }
    #[cfg(not(windows))]
    Err(PhobosError::new(
        ErrorCode::Unsupported,
        "hidden interactive password input requires Windows",
    ))
}

pub(super) fn run(args: Vec<String>) -> Result<(), PhobosError> {
    let mut address = std::env::var("PHOBOS_ADDR").ok();
    let mut user = std::env::var("PHOBOS_USER").ok();
    let mut args = args.into_iter();
    while let Some(arg) = args.next() {
        let value = args.next().ok_or_else(|| {
            PhobosError::new(
                ErrorCode::Semantic,
                "shell expects --addr HOST:PORT or --user USER",
            )
        })?;
        match arg.as_str() {
            "--addr" => address = Some(value),
            "--user" => user = Some(value),
            _ => {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "unknown shell option",
                ));
            }
        }
    }
    let address = match address {
        Some(value) => value,
        None => {
            let value = prompt("Server [127.0.0.1:54321]: ")?;
            if value.is_empty() {
                "127.0.0.1:54321".into()
            } else {
                value
            }
        }
    };
    let user = match user {
        Some(value) => value,
        None => prompt("Username: ")?,
    };
    let mut client = super::connect_transport(&address)?;
    let mut secret = password()?;
    let authenticated = client.authenticate(&user, &secret);
    // Overwrite the owned UTF-8 allocation safely after the single auth exchange.
    secret.replace_range(.., &"\0".repeat(secret.len()));
    drop(secret);
    authenticated?;
    println!("Authenticated. End SQL with ';'. Use \\q to quit.");
    let mut pending = String::new();
    loop {
        print!(
            "{}",
            if pending.trim().is_empty() {
                "phobos> "
            } else {
                "    -> "
            }
        );
        io::stdout().flush()?;
        let mut line = String::new();
        if io::stdin().read_line(&mut line)? == 0 || line.trim() == "\\q" {
            // End any open transaction on this same session before disconnecting.
            let _ = client.query("ROLLBACK");
            println!("Bye.");
            return Ok(());
        }
        pending.push_str(&line);
        if pending.len() > phobos_client_limit() {
            pending.clear();
            eprintln!("Statement exceeds 1 MiB; discarded.");
            continue;
        }
        while let Some(end) = statement_end(&pending) {
            let statement: String = pending.drain(..=end).collect();
            let sql = statement[..statement.len() - 1].trim();
            if sql.is_empty() {
                continue;
            }
            match client.query(sql) {
                Ok(result) => println!("{result}"),
                Err(error)
                    if matches!(
                        error.code,
                        ErrorCode::Io | ErrorCode::Tls | ErrorCode::InvalidProtocol
                    ) =>
                {
                    return Err(error);
                }
                Err(error) => eprintln!("{error}"),
            }
        }
    }
}

fn phobos_client_limit() -> usize {
    1024 * 1024
}

// Delimit outside quoted literals/identifiers and comments; doubled quotes escape.
fn statement_end(sql: &str) -> Option<usize> {
    let bytes = sql.as_bytes();
    let (mut i, mut quote, mut block, mut line) = (0, 0u8, false, false);
    while i < bytes.len() {
        let b = bytes[i];
        let next = bytes.get(i + 1).copied();
        if line {
            if b == b'\n' {
                line = false;
            }
        } else if block {
            if b == b'*' && next == Some(b'/') {
                block = false;
                i += 1;
            }
        } else if quote != 0 {
            if b == quote {
                if next == Some(quote) {
                    i += 1;
                } else {
                    quote = 0;
                }
            }
        } else if b == b'\'' || b == b'"' {
            quote = b;
        } else if b == b'-' && next == Some(b'-') {
            line = true;
            i += 1;
        } else if b == b'/' && next == Some(b'*') {
            block = true;
            i += 1;
        } else if b == b';' {
            return Some(i);
        }
        i += 1;
    }
    None
}

#[cfg(test)]
mod tests {
    use super::statement_end;
    #[test]
    fn shell_delimits_multiline_without_splitting_literals_or_comments() {
        assert_eq!(statement_end("SELECT\n'can''t;split'; tail"), Some(21));
        assert_eq!(statement_end("SELECT 'unfinished;"), None);
        assert_eq!(statement_end("-- ;\nSELECT 1 /* ; */;"), Some(21));
    }
}
