//! Client-local typed TSV: \N, i:123, f:1.5, b:true, t:text (no escapes).
use phobos_error::{ErrorCode, PhobosError};
use phobos_types::{Row, Value};
use std::io::{BufRead, Read};

fn invalid() -> PhobosError {
    PhobosError::new(
        ErrorCode::Semantic,
        "invalid ingest input; use typed TSV fields: \\N, i:, f:, b:, t:",
    )
}
fn read_row(reader: &mut impl BufRead) -> Option<Result<Row, PhobosError>> {
    let mut bytes = Vec::new();
    let read = reader.take(8193).read_until(b'\n', &mut bytes);
    match read {
        Ok(0) => return None,
        Err(error) => return Some(Err(error.into())),
        _ => {}
    }
    Some((|| {
        if bytes.len() > 8192 {
            return Err(invalid());
        }
        if bytes.last() == Some(&b'\n') {
            bytes.pop();
        }
        if bytes.last() == Some(&b'\r') {
            bytes.pop();
        }
        let line = std::str::from_utf8(&bytes).map_err(|_| invalid())?;
        let values = line
            .split('\t')
            .map(|field| {
                if field == "\\N" {
                    return Ok(Value::Null);
                }
                let (kind, value) = field.split_once(':').ok_or_else(invalid)?;
                match kind {
                    "i" => value.parse().map(Value::Int64).map_err(|_| invalid()),
                    "f" => value.parse().map(Value::Float64).map_err(|_| invalid()),
                    "b" => value.parse().map(Value::Boolean).map_err(|_| invalid()),
                    "t" => Ok(Value::Text(value.into())),
                    _ => Err(invalid()),
                }
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Row::new(values))
    })())
}

pub fn run(addr: &str, args: &[String]) -> Result<String, PhobosError> {
    if args.len() != 2 {
        return Err(invalid());
    }
    let mut client = super::connect_configured(addr)?;
    let mut input: Box<dyn BufRead> = if args[1] == "-" {
        Box::new(std::io::BufReader::new(std::io::stdin()))
    } else {
        Box::new(std::io::BufReader::new(std::fs::File::open(&args[1])?))
    };
    let rows = client.bulk_load(&args[0], std::iter::from_fn(|| read_row(&mut input)))?;
    Ok(format!("IMPORTED {rows} (committed)"))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn typed_ingest_preserves_null_and_rejects_malformed_or_unbounded_lines() {
        let mut input = &b"i:1\tt:text\t\\N\tb:true\ninvalid\n"[..];
        assert_eq!(
            read_row(&mut input).unwrap().unwrap().values,
            vec![
                Value::Int64(1),
                Value::Text("text".into()),
                Value::Null,
                Value::Boolean(true)
            ]
        );
        assert!(read_row(&mut input).unwrap().is_err());
        assert!(read_row(&mut input).is_none());
        assert!(read_row(&mut vec![b'x'; 8193].as_slice()).unwrap().is_err());
    }
}
