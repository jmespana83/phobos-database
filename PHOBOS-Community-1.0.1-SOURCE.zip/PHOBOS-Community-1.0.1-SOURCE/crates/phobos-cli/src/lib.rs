#![forbid(unsafe_code)]
//! phobos-cli subsystem.

/// Current implementation milestone for this subsystem.
pub const MILESTONE: &str = "Phase 0 foundation";
