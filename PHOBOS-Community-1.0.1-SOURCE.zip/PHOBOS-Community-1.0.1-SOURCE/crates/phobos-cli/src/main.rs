#![forbid(unsafe_code)]

use std::{env, process};
mod ingest;
mod shell;

fn main() {
    if env::args().nth(1).as_deref() == Some("--version") {
        println!("PHOBOS Cli {} Community Edition", env!("CARGO_PKG_VERSION"));
        return;
    }

    let mut args = env::args().skip(1);
    let command = args.next().unwrap_or_else(|| "shell".to_string());
    if command == "shell" {
        if let Err(error) = shell::run(args.collect()) {
            eprintln!("shell failed: {error}");
            process::exit(1);
        }
        return;
    }
    let mut addr = "127.0.0.1:54321".to_string();
    let mut sql_parts = Vec::new();
    while let Some(argument) = args.next() {
        if argument == "--addr" {
            addr = args.next().unwrap_or_else(|| usage());
        } else {
            sql_parts.push(argument);
        }
    }

    if command == "stream" && !sql_parts.is_empty() {
        if let Err(error) = stream_query(&addr, &sql_parts.join(" ")) {
            eprintln!("stream failed (any preceding rows are incomplete): {error}");
            process::exit(1);
        }
        return;
    }
    let result = match command.as_str() {
        "ingest" => ingest::run(&addr, &sql_parts),
        "ping" if sql_parts.is_empty() => connect_configured(&addr).and_then(|mut c| c.handshake()),
        "query" if !sql_parts.is_empty() => {
            connect_configured(&addr).and_then(|mut c| c.query(&sql_parts.join(" ")))
        }
        "session" if !sql_parts.is_empty() => run_session(&addr, &sql_parts.join(" ")),
        _ => usage(),
    };
    match result {
        Ok(output) => println!("{output}"),
        Err(error) => {
            eprintln!("command failed: {error}");
            process::exit(1);
        }
    }
}

fn stream_query(addr: &str, sql: &str) -> Result<(), phobos_error::PhobosError> {
    use phobos_client::StreamEvent;
    use std::io::Write;
    let mut client = connect_configured(addr)?;
    client.negotiate_streaming()?;
    let mut output = std::io::BufWriter::new(std::io::stdout().lock());
    client.query_stream(sql, |event| {
        match event {
            StreamEvent::Start(columns) => writeln!(output, "{}", columns.join("\t"))?,
            StreamEvent::Rows { rows, .. } => {
                for row in rows {
                    for (index, value) in row.values.iter().enumerate() {
                        if index != 0 {
                            write!(output, "\t")?;
                        }
                        write!(output, "{value}")?;
                    }
                    writeln!(output)?;
                }
            }
            StreamEvent::Command { tag, rows_affected } => {
                writeln!(output, "{tag} {rows_affected}")?
            }
            StreamEvent::End { .. } => output.flush()?,
            StreamEvent::Error { .. } => {}
        }
        Ok(())
    })?;
    output.flush()?;
    Ok(())
}

fn run_session(addr: &str, script: &str) -> Result<String, phobos_error::PhobosError> {
    let mut client = connect_configured(addr)?;
    let mut output = String::new();
    for statement in script
        .split(';')
        .map(str::trim)
        .filter(|value| !value.is_empty())
    {
        let result = client.query(statement)?;
        output.push_str(&result);
        if !result.ends_with('\n') {
            output.push('\n');
        }
    }
    Ok(output.trim_end().to_string())
}

fn usage() -> ! {
    eprintln!(
        "phobos-cli ingest [--addr HOST:PORT] TABLE FILE|- (typed TSV; optional PHOBOS_USER/PHOBOS_PASSWORD, PHOBOS_TLS_SERVER_NAME/PHOBOS_TLS_CA)"
    );
    eprintln!("phobos-cli ping [--addr HOST:PORT]");
    eprintln!("phobos-cli query [--addr HOST:PORT] SQL...");
    eprintln!("phobos-cli stream [--addr HOST:PORT] SQL...");
    eprintln!("phobos-cli session [--addr HOST:PORT] \"BEGIN; ...; COMMIT\"");
    process::exit(2)
}

fn connect_configured(addr: &str) -> Result<phobos_client::Client, phobos_error::PhobosError> {
    use phobos_error::{ErrorCode, PhobosError};
    let mut client = connect_transport(addr)?;
    if let Ok(user) = env::var("PHOBOS_USER") {
        let password = env::var("PHOBOS_PASSWORD")
            .map_err(|_| PhobosError::new(ErrorCode::Authentication, "PHOBOS_PASSWORD required"))?;
        client.authenticate(&user, &password)?;
    }
    Ok(client)
}

fn connect_transport(addr: &str) -> Result<phobos_client::Client, phobos_error::PhobosError> {
    use phobos_error::{ErrorCode, PhobosError};
    let client = match (
        env::var("PHOBOS_TLS_SERVER_NAME"),
        env::var("PHOBOS_TLS_CA"),
    ) {
        (Ok(name), Ok(ca)) => phobos_client::Client::connect_tls(addr, &name, ca)?,
        (Err(_), Err(_)) => phobos_client::Client::connect(addr)?,
        _ => {
            return Err(PhobosError::new(
                ErrorCode::Tls,
                "set both TLS server name and CA",
            ));
        }
    };
    client.set_io_timeout(std::time::Duration::from_secs(900))?;
    Ok(client)
}
