#![forbid(unsafe_code)]
//! Phase 3 durable transaction identifier lifecycle for the single-user engine.

use phobos_error::{ErrorCode, PhobosError};

pub mod mvcc;
use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
};

pub type TransactionId = u64;
const MAGIC: [u8; 4] = *b"PHTX";
const VERSION: u16 = 1;
const HEADER_LEN: u64 = 6;
const RECORD_LEN: u64 = 12;
const CONTROL_FILE: &str = "phobos.txn";

pub struct TransactionManager {
    path: PathBuf,
    file: File,
    next_id: TransactionId,
}

impl TransactionManager {
    pub fn open(data_dir: impl AsRef<Path>) -> Result<Self, PhobosError> {
        phobos_observability::measure("fs.create_dir_all", || {
            fs::create_dir_all(data_dir.as_ref())
        })?;
        let path = data_dir.as_ref().join(CONTROL_FILE);
        if !path.exists() {
            let mut file = OpenOptions::new()
                .create_new(true)
                .read(true)
                .write(true)
                .open(&path)?;
            file.write_all(&MAGIC)?;
            file.write_all(&VERSION.to_le_bytes())?;
            phobos_observability::measure("fs.sync_data", || file.sync_data())?;
        }
        let mut file = OpenOptions::new().read(true).write(true).open(&path)?;
        let (next_id, valid_len) = scan_control(&mut file)?;
        let physical_len =
            phobos_observability::measure("fs.file_metadata", || file.metadata())?.len();
        if valid_len < physical_len {
            file.set_len(valid_len)?;
            phobos_observability::measure("fs.sync_data", || file.sync_data())?;
        }
        file.seek(SeekFrom::End(0))?;
        Ok(Self {
            path,
            file,
            next_id,
        })
    }

    pub fn allocate(&mut self) -> Result<TransactionId, PhobosError> {
        let id = self.next_id;
        let next_id = id.checked_add(1).ok_or_else(|| {
            PhobosError::new(
                ErrorCode::TransactionState,
                "transaction identifier exhausted",
            )
        })?;
        let id_bytes = id.to_le_bytes();
        self.file.seek(SeekFrom::End(0))?;
        self.file.write_all(&id_bytes)?;
        self.file.write_all(&checksum(&id_bytes).to_le_bytes())?;
        phobos_observability::measure("txn.id_fsync", || self.file.sync_data())?;
        self.next_id = next_id;
        Ok(id)
    }

    #[must_use]
    pub fn path(&self) -> &Path {
        &self.path
    }
    #[must_use]
    pub fn next_id(&self) -> TransactionId {
        self.next_id
    }
}

fn scan_control(file: &mut File) -> Result<(TransactionId, u64), PhobosError> {
    file.seek(SeekFrom::Start(0))?;
    let len = phobos_observability::measure("fs.file_metadata", || file.metadata())?.len();
    if len < HEADER_LEN {
        return Err(PhobosError::new(
            ErrorCode::TransactionState,
            "truncated transaction control header",
        ));
    }
    let mut header = [0u8; HEADER_LEN as usize];
    file.read_exact(&mut header)?;
    if header[0..4] != MAGIC {
        return Err(PhobosError::new(
            ErrorCode::TransactionState,
            "invalid transaction control magic",
        ));
    }
    if u16::from_le_bytes([header[4], header[5]]) != VERSION {
        return Err(PhobosError::new(
            ErrorCode::TransactionState,
            "unsupported transaction control version",
        ));
    }
    let mut offset = HEADER_LEN;
    let mut last_id = 0u64;
    while len - offset >= RECORD_LEN {
        let mut record = [0u8; RECORD_LEN as usize];
        file.read_exact(&mut record)?;
        let id_bytes: [u8; 8] = record[0..8].try_into().expect("transaction id bytes");
        let expected = u32::from_le_bytes(record[8..12].try_into().expect("transaction checksum"));
        if checksum(&id_bytes) != expected {
            if offset + RECORD_LEN == len {
                break;
            }
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "transaction control checksum mismatch",
            ));
        }
        let id = u64::from_le_bytes(id_bytes);
        if id == 0 || id <= last_id {
            return Err(PhobosError::new(
                ErrorCode::TransactionState,
                "transaction IDs are not strictly increasing",
            ));
        }
        last_id = id;
        offset += RECORD_LEN;
    }
    let next_id = last_id.checked_add(1).ok_or_else(|| {
        PhobosError::new(
            ErrorCode::TransactionState,
            "transaction identifier exhausted",
        )
    })?;
    Ok((next_id, offset))
}

fn checksum(bytes: &[u8]) -> u32 {
    let mut hash = 0x811c_9dc5u32;
    for byte in bytes {
        hash ^= u32::from(*byte);
        hash = hash.wrapping_mul(0x0100_0193);
    }
    hash
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_dir() -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-txn-{n}"))
    }

    #[test]
    fn transaction_ids_survive_restart() {
        let dir = temp_dir();
        let first = {
            let mut manager = TransactionManager::open(&dir).unwrap();
            manager.allocate().unwrap()
        };
        let second = {
            let mut manager = TransactionManager::open(&dir).unwrap();
            manager.allocate().unwrap()
        };
        assert_eq!(first, 1);
        assert_eq!(second, 2);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn truncated_tail_is_trimmed_without_reusing_committed_id() {
        let dir = temp_dir();
        {
            let mut manager = TransactionManager::open(&dir).unwrap();
            assert_eq!(manager.allocate().unwrap(), 1);
        }
        let path = dir.join(CONTROL_FILE);
        let mut file = OpenOptions::new().append(true).open(&path).unwrap();
        file.write_all(&2u64.to_le_bytes()[..3]).unwrap();
        drop(file);
        let mut manager = TransactionManager::open(&dir).unwrap();
        assert_eq!(manager.allocate().unwrap(), 2);
        let _ = fs::remove_dir_all(dir);
    }
}
