//! C5 transaction visibility primitives for explicitly migrated databases.
//!
//! The caller owns database admission and ordered publication. Durable status must
//! be installed before a checkpoint may retire the corresponding COMMIT record.
//! Recovery must reconcile statuses before the existing WAL recovery checkpoints.
#[cfg(test)]
mod commit_path_tests;
mod freeze_file;
#[cfg(test)]
mod growth_tests;
#[cfg(test)]
mod hint_cache_tests;
pub mod sessions;
mod status_file;
pub use status_file::{DEFAULT_GROWTH_EXTENT, DEFAULT_TRIM_RECORDS, StatusFile};

use crate::TransactionId;
use phobos_error::{ErrorCode, PhobosError};
use std::collections::{BTreeMap, BTreeSet};
use std::sync::Arc;

type Result<T> = std::result::Result<T, PhobosError>;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Status {
    InProgress,
    Committed { sequence: u64 },
    Aborted,
}

/// Missing durable status is not evidence of an abort until WAL reconciliation
/// has completed. Implementations must fail closed for unknown/corrupt state.
pub trait StatusLookup {
    fn status(&mut self, transaction: TransactionId) -> Result<Status>;
    /// 0.1.9-B1: commit sequences at or below this bound are visible to every
    /// live and future snapshot of this database, so a tuple whose creator or
    /// deleter committed at or below it may carry a settled hint. `None`
    /// forbids setting hints (default for non-statement lookups).
    fn hint_bound(&self) -> Option<u64> {
        None
    }
    /// Called instead of `status` when a settled hint answers visibility.
    /// Implementations keep their fencing checks here; the default is free.
    fn use_hint(&mut self) -> Result<()> {
        Ok(())
    }
}

/// 0.1.9-B1 settled-visibility hints for one tuple version. Two spare
/// envelope flag bits: `CREATOR_COMMITTED` means the creator committed at or
/// below a hint bound (created for every snapshot); `DELETER_COMMITTED` means
/// the deleter did (dead for every snapshot). Hints are an optimization only:
/// they are never set for InProgress or Aborted transactions, never change a
/// visibility result, and losing them costs only status lookups.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Hints(u8);
impl Hints {
    pub const CREATOR_COMMITTED: u8 = 0b01;
    pub const DELETER_COMMITTED: u8 = 0b10;
    pub const MASK: u8 = 0b11;
    #[must_use]
    pub fn from_bits(bits: u8) -> Self {
        Self(bits & Self::MASK)
    }
    #[must_use]
    pub fn bits(self) -> u8 {
        self.0
    }
    #[must_use]
    pub fn creator_committed(self) -> bool {
        self.0 & Self::CREATOR_COMMITTED != 0
    }
    #[must_use]
    pub fn deleter_committed(self) -> bool {
        self.0 & Self::DELETER_COMMITTED != 0
    }
    #[must_use]
    pub fn union(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

/// Bounded live state over fixed-address durable storage. Transaction IDs are
/// allocated externally, never reused, and admitted before any private mutation.
/// Committed statuses are fetched on demand; no historical RAM map accumulates.
pub struct TransactionRegistry {
    statuses: StatusFile,
    active: BTreeSet<TransactionId>,
    next_transaction: u64,
    limit: usize,
}

impl TransactionRegistry {
    pub fn new(statuses: StatusFile, limit: usize) -> Result<Self> {
        if limit == 0 {
            return Err(invalid("active transaction limit must be nonzero"));
        }
        let next_transaction = statuses.next_transaction;
        Ok(Self {
            statuses,
            active: BTreeSet::new(),
            next_transaction,
            limit,
        })
    }

    pub fn allocate(&mut self) -> Result<TransactionId> {
        let id = self.next_transaction;
        self.begin(id)?;
        Ok(id)
    }

    pub fn begin(&mut self, transaction: TransactionId) -> Result<()> {
        self.statuses.ensure_available()?;
        if transaction < self.next_transaction || transaction == u64::MAX {
            return Err(invalid("transaction ID reused or exhausted"));
        }
        // Status capacity grows on demand (A3); only live-transaction memory
        // is a fixed bound here.
        if self.active.len() == self.limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC active transaction limit exhausted",
            ));
        }
        self.statuses.reserve(transaction)?;
        self.active.insert(transaction);
        self.next_transaction = transaction + 1;
        Ok(())
    }

    /// Ordered publisher calls this only after private versions have installed.
    /// Failure leaves the transaction unresolved; caller must fence and recover,
    /// never report a successful rollback of a durable transaction.
    pub fn commit(&mut self, receipt: &phobos_wal::v2::DurableCommit) -> Result<()> {
        self.validate_commit(receipt)?;
        let transaction = receipt.mvcc_id().unwrap_or(receipt.txn_id());
        if !self.active.contains(&transaction) {
            return Err(invalid("commit requires an active transaction"));
        }
        self.statuses.install(receipt)?;
        self.active.remove(&transaction);
        Ok(())
    }

    pub fn validate_commit(&self, receipt: &phobos_wal::v2::DurableCommit) -> Result<()> {
        self.statuses.ensure_available()?;
        let transaction = receipt.mvcc_id().unwrap_or(receipt.txn_id());
        if !self.active.contains(&transaction)
            || !self.statuses.matches_directory(receipt.directory())
            || receipt.lsn() <= self.statuses.durable_frontier()
        {
            return Err(invalid("foreign, inactive or out-of-order commit receipt"));
        }
        Ok(())
    }

    /// Caller first discards the transaction's private changes and conflict locks.
    pub fn abort(&mut self, transaction: TransactionId) -> Result<()> {
        self.statuses.ensure_available()?;
        if !self.active.contains(&transaction) {
            return Err(invalid("abort requires an active transaction"));
        }
        self.statuses.abort(transaction)?;
        self.active.remove(&transaction);
        Ok(())
    }

    pub fn checkpoint(&mut self, wal: &mut phobos_wal::v2::Wal) -> Result<()> {
        self.statuses.checkpoint(wal)
    }

    #[must_use]
    pub fn durable_frontier(&self) -> u64 {
        self.statuses.durable_frontier()
    }
}

impl StatusLookup for TransactionRegistry {
    fn status(&mut self, transaction: TransactionId) -> Result<Status> {
        phobos_observability::assert_no_structural_scope();
        self.statuses.ensure_available()?;
        if transaction == 0 || transaction >= self.next_transaction {
            return Err(invalid("unknown transaction status"));
        }
        if self.active.contains(&transaction) {
            return Ok(Status::InProgress);
        }
        self.statuses
            .read_status(transaction)?
            .ok_or_else(|| invalid("missing durable transaction status"))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Version {
    pub creator: TransactionId,
    pub deleter: Option<TransactionId>,
}

/// One statement's published frontier. Registry pins, rather than this value,
/// keep versions alive for the entire statement/stream lifetime.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Snapshot {
    sequence: u64,
    own: Option<TransactionId>,
}

impl Snapshot {
    #[must_use]
    pub fn sequence(self) -> u64 {
        self.sequence
    }

    #[must_use]
    pub fn own_transaction(self) -> Option<TransactionId> {
        self.own
    }

    pub fn visible(self, version: Version, statuses: &mut impl StatusLookup) -> Result<bool> {
        self.visible_hinted(version, Hints::default(), statuses)
            .map(|(visible, _)| visible)
    }

    /// Visibility with 0.1.9-B1 settled hints. Returns the result and the
    /// hints the caller may retain for this tuple (the input hints plus any
    /// newly settled ones). A settled hint answers without a status lookup;
    /// a hint is only added when the lookup returned `Committed` with a
    /// sequence at or below `statuses.hint_bound()`, which every live and
    /// future snapshot already covers, so the result equals the unhinted one.
    pub fn visible_hinted(
        self,
        version: Version,
        hints: Hints,
        statuses: &mut impl StatusLookup,
    ) -> Result<(bool, Hints)> {
        let _span = phobos_observability::span("mvcc.visibility");
        if version.creator == 0 || version.deleter == Some(0) {
            return Err(invalid("zero transaction in tuple version"));
        }
        let bound = statuses.hint_bound();
        let settled = |sequence: u64| bound.is_some_and(|bound| sequence <= bound);
        if hints.deleter_committed() && version.deleter.is_some() {
            // Dead for every snapshot; the creator no longer matters.
            statuses.use_hint()?;
            return Ok((false, hints));
        }
        let mut retained = hints;
        // Even own versions must resolve their status: a failed/aborted context
        // cannot resurrect tuples just because it retained a snapshot value.
        // (Own versions are InProgress and therefore never hinted.)
        let created = if hints.creator_committed() {
            statuses.use_hint()?;
            true
        } else {
            match statuses.status(version.creator)? {
                Status::Aborted => false,
                Status::InProgress => self.own == Some(version.creator),
                Status::Committed { sequence } => {
                    if settled(sequence) {
                        retained = retained.union(Hints(Hints::CREATOR_COMMITTED));
                    }
                    sequence <= self.sequence
                }
            }
        };
        if !created {
            return Ok((false, retained));
        }
        let Some(deleter) = version.deleter else {
            return Ok((true, retained));
        };
        let visible = match statuses.status(deleter)? {
            Status::Aborted => true,
            Status::InProgress => self.own != Some(deleter),
            Status::Committed { sequence } => {
                if settled(sequence) {
                    retained = retained.union(Hints(Hints::DELETER_COMMITTED));
                }
                sequence > self.sequence
            }
        };
        Ok((visible, retained))
    }
}

/// RAII statement/stream pin. Drop releases only this pin. Forgetting a pin
/// retains its horizon and consumes bounded capacity; it never permits reuse.
#[derive(Debug)]
pub struct SnapshotPin {
    state: Arc<std::sync::Mutex<SnapshotState>>,
    id: u64,
    snapshot: Snapshot,
}
impl SnapshotPin {
    #[must_use]
    pub fn snapshot(&self) -> Snapshot {
        self.snapshot
    }
}
impl Drop for SnapshotPin {
    fn drop(&mut self) {
        // Poisoning fails closed: leave retention in place rather than guessing
        // which mutation completed. Snapshot creation subsequently returns error.
        if let Ok(mut state) = self.state.lock() {
            if state.pins.get(&self.id) == Some(&self.snapshot) {
                state.pins.remove(&self.id);
            }
        }
    }
}

#[derive(Debug)]
struct SnapshotState {
    published: u64,
    next_pin: u64,
    limit: usize,
    pins: BTreeMap<u64, Snapshot>,
}

/// Cloneable registry handle; all clones share one frontier and bounded pin set.
/// No registry mutex is held while executing a statement or delivering rows.
#[derive(Clone)]
pub struct SnapshotRegistry {
    state: Arc<std::sync::Mutex<SnapshotState>>,
}
impl SnapshotRegistry {
    pub fn new(published: u64, limit: usize) -> Result<Self> {
        if limit == 0 {
            return Err(invalid("snapshot capacity must be nonzero"));
        }
        Ok(Self {
            state: Arc::new(std::sync::Mutex::new(SnapshotState {
                published,
                next_pin: 1,
                limit,
                pins: BTreeMap::new(),
            })),
        })
    }
    /// Ordered publisher calls only after page/index and durable status installation.
    pub fn advance_publication(&mut self, sequence: u64) -> Result<()> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?;
        if sequence <= state.published {
            return Err(invalid("MVCC publication must advance in commit order"));
        }
        state.published = sequence;
        Ok(())
    }
    pub fn pin(&mut self, own: Option<TransactionId>) -> Result<SnapshotPin> {
        let _span = phobos_observability::span("mvcc.snapshot");
        if own == Some(0) {
            return Err(invalid("zero snapshot transaction"));
        }
        let mut state = self
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?;
        if state.pins.len() == state.limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "active statement snapshot limit",
            ));
        }
        let id = state.next_pin;
        state.next_pin = id
            .checked_add(1)
            .ok_or_else(|| invalid("snapshot ID exhausted"))?;
        let snapshot = Snapshot {
            sequence: state.published,
            own,
        };
        state.pins.insert(id, snapshot);
        Ok(SnapshotPin {
            state: self.state.clone(),
            id,
            snapshot,
        })
    }
    /// Pins an already-established committed frontier. Used by Snapshot
    /// Isolation statements; the transaction's long-lived pin keeps this
    /// sequence inside the reclamation horizon.
    pub fn pin_at(&mut self, sequence: u64, own: Option<TransactionId>) -> Result<SnapshotPin> {
        if own == Some(0) {
            return Err(invalid("zero snapshot transaction"));
        }
        let mut state = self
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?;
        if sequence > state.published {
            return Err(invalid("snapshot frontier is not published"));
        }
        if state.pins.len() == state.limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "active statement snapshot limit",
            ));
        }
        let id = state.next_pin;
        state.next_pin = id
            .checked_add(1)
            .ok_or_else(|| invalid("snapshot ID exhausted"))?;
        let snapshot = Snapshot { sequence, own };
        state.pins.insert(id, snapshot);
        Ok(SnapshotPin {
            state: self.state.clone(),
            id,
            snapshot,
        })
    }
    /// Explicit release remains available; ordinary callers can simply drop.
    pub fn release(&mut self, pin: SnapshotPin) -> Result<()> {
        if !Arc::ptr_eq(&pin.state, &self.state) {
            return Err(invalid("foreign statement snapshot pin"));
        }
        drop(pin);
        Ok(())
    }
    fn horizon(&self) -> Result<u64> {
        let state = self
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?;
        Ok(state
            .pins
            .values()
            .map(|pin| pin.sequence)
            .min()
            .unwrap_or(state.published))
    }
    #[must_use]
    pub fn reclamation_horizon(&self) -> u64 {
        self.horizon().unwrap_or(0)
    }
    /// 0.2-K: the published frontier (the sequence a statement pinned now
    /// would receive). Every later commit publishes a larger sequence.
    pub fn published(&self) -> Result<u64> {
        Ok(self
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?
            .published)
    }
    /// 0.2-K diagnostics: live statement/transaction pins.
    pub fn pin_count(&self) -> Result<usize> {
        Ok(self
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?
            .pins
            .len())
    }
    /// Necessary visibility condition only. Structural/index pins and ownership
    /// must also be checked before physically reclaiming or reusing a slot.
    pub fn may_reclaim(&self, version: Version, statuses: &mut impl StatusLookup) -> Result<bool> {
        let horizon = self.horizon()?;
        globally_dead(horizon, version, statuses)
    }
}

/// 0.1.9-C1 safe-dead rule. `horizon` is a reclamation horizon observed
/// earlier (the minimum live pin sequence, else the published frontier); it
/// never moves backwards, so every current and future snapshot has a sequence
/// at or above it. A version is globally dead when its creator aborted, or
/// its creator committed and its deleter committed at or before `horizon`
/// (invisible to every snapshot that exists or can still be created).
/// InProgress creators or deleters, live versions and deletions newer than
/// the horizon are never dead.
pub fn globally_dead(
    horizon: u64,
    version: Version,
    statuses: &mut impl StatusLookup,
) -> Result<bool> {
    if version.creator == 0 || version.deleter == Some(0) {
        return Err(invalid("zero transaction in tuple version"));
    }
    match statuses.status(version.creator)? {
        Status::Aborted => return Ok(true),
        Status::InProgress => return Ok(false),
        Status::Committed { .. } => {}
    }
    let Some(deleter) = version.deleter else {
        return Ok(false);
    };
    Ok(matches!(statuses.status(deleter)?, Status::Committed { sequence } if sequence <= horizon))
}

fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::TransactionState, message)
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod freeze_tests;
