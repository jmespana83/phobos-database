//! 0.1.9-A3: growable transaction-status file. Tiny capacities keep the
//! suite fast; the production initial capacity is only a starting extent.
use super::*;
use phobos_wal::v2::Wal;
use std::{
    fs,
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    time::{SystemTime, UNIX_EPOCH},
};

const NAME: &str = "phobos.mvcc-status";
const HEADER: u64 = 32;
const RECORD: u64 = 32;

fn directory(label: &str) -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let sequence = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    std::env::temp_dir().join(format!(
        "phobos-a3-{label}-{}-{}-{sequence}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}

fn header_bytes(dir: &Path) -> [u8; 32] {
    let mut header = [0; 32];
    fs::File::open(dir.join(NAME))
        .unwrap()
        .read_exact(&mut header)
        .unwrap();
    header
}
fn header_capacity(dir: &Path) -> u64 {
    u64::from_le_bytes(header_bytes(dir)[8..16].try_into().unwrap())
}
fn header_boundary(dir: &Path) -> u64 {
    u64::from_le_bytes(header_bytes(dir)[16..24].try_into().unwrap())
}
fn file_len(dir: &Path) -> u64 {
    fs::metadata(dir.join(NAME)).unwrap().len()
}
/// Rewrites header fields with a fresh checksum, exactly as the engine would.
fn rewrite_header(dir: &Path, capacity: Option<u64>, boundary: Option<u64>) {
    let mut header = header_bytes(dir);
    if let Some(capacity) = capacity {
        header[8..16].copy_from_slice(&capacity.to_le_bytes());
    }
    if let Some(boundary) = boundary {
        header[16..24].copy_from_slice(&boundary.to_le_bytes());
    }
    let checksum = crate::checksum(&header[..28]);
    header[28..].copy_from_slice(&checksum.to_le_bytes());
    let mut file = fs::OpenOptions::new()
        .write(true)
        .open(dir.join(NAME))
        .unwrap();
    file.write_all(&header).unwrap();
    file.sync_all().unwrap();
}
fn record_bytes(dir: &Path, first: u64, last: u64) -> Vec<u8> {
    let mut file = fs::File::open(dir.join(NAME)).unwrap();
    file.seek(SeekFrom::Start(HEADER + (first - 1) * RECORD))
        .unwrap();
    let mut bytes = vec![0; ((last - first + 1) * RECORD) as usize];
    file.read_exact(&mut bytes).unwrap();
    bytes
}

/// The pre-A3 defect: the header capacity was a lifetime ceiling. With
/// capacity 4 the fifth BEGIN returned ResourceLimit forever.
#[test]
fn a3_exhausting_the_initial_capacity_grows_instead_of_failing() {
    let dir = directory("first-growth");
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let store = StatusFile::create(&dir, 4).unwrap();
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    let mut ids = Vec::new();
    for _ in 0..4 {
        ids.push(registry.allocate().unwrap());
    }
    assert_eq!(ids, [1, 2, 3, 4]);
    assert_eq!(header_capacity(&dir), 4);
    // Fifth transaction: pre-A3 -> Err(ResourceLimit "MVCC transaction/status capacity exhausted").
    let fifth = registry.allocate();
    assert!(
        fifth.is_ok(),
        "capacity must grow, not fail: {:?}",
        fifth.as_ref().err()
    );
    assert_eq!(fifth.unwrap(), 5);
    assert_eq!(header_capacity(&dir), 4 + DEFAULT_GROWTH_EXTENT);
    for id in [1u64, 5] {
        wal.begin_mvcc(id).unwrap();
        let receipt = wal.commit().unwrap();
        registry.commit(&receipt).unwrap();
    }
    for id in [2u64, 3, 4] {
        registry.abort(id).unwrap();
    }
    drop(registry);
    drop(wal);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert!(statuses.capacity() >= 5);
    assert!(matches!(
        statuses.status(1).unwrap(),
        Status::Committed { .. }
    ));
    assert!(matches!(
        statuses.status(5).unwrap(),
        Status::Committed { .. }
    ));
    assert_eq!(statuses.status(4).unwrap(), Status::Aborted);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// Capacity 4, extent 4, 120 transactions with commits and aborts, reopened
/// every few transactions: 30 consecutive growths, every status readable,
/// identities monotonic across restarts, earlier extents byte-identical.
#[test]
fn a3_many_consecutive_extents_survive_reopens() {
    let dir = directory("extents");
    let mut expected: BTreeMap<u64, Status> = BTreeMap::new();
    let mut next_expected = 1u64;
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let store = StatusFile::create(&dir, 4).unwrap();
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    let mut earlier_extents: Option<(u64, Vec<u8>)> = None;
    for round in 0..24u64 {
        if round > 0 {
            drop(registry);
            drop(wal);
            let (mut statuses, reopened) = StatusFile::recover_database(&dir).unwrap();
            for (id, status) in &expected {
                assert_eq!(
                    statuses.status(*id).unwrap(),
                    *status,
                    "id {id} after reopen {round}"
                );
            }
            assert_eq!(statuses.next_transaction, next_expected, "reopen {round}");
            assert_eq!(header_boundary(&dir), next_expected);
            statuses.set_growth_extent(4).unwrap();
            wal = reopened;
            registry = TransactionRegistry::new(statuses, 16).unwrap();
        } else {
            registry.statuses.set_growth_extent(4).unwrap();
        }
        let batch = 3 + (round % 5);
        for step in 0..batch {
            let id = registry.allocate().unwrap();
            assert_eq!(id, next_expected, "identities are contiguous and monotonic");
            next_expected += 1;
            let capacity = header_capacity(&dir);
            assert!(
                capacity >= id && capacity % 4 == 0,
                "grant {capacity} covers {id}"
            );
            assert!(file_len(&dir) <= HEADER + capacity * RECORD);
            if step % 2 == 0 {
                wal.begin_mvcc(id).unwrap();
                let receipt = wal.commit().unwrap();
                registry.commit(&receipt).unwrap();
                expected.insert(
                    id,
                    Status::Committed {
                        sequence: receipt.lsn(),
                    },
                );
            } else {
                registry.abort(id).unwrap();
                expected.insert(id, Status::Aborted);
            }
        }
        // Records of earlier extents never change once their statuses are final.
        if let Some((through, bytes)) = &earlier_extents {
            assert_eq!(
                &record_bytes(&dir, 1, *through),
                bytes,
                "earlier extents rewritten"
            );
        }
        let through = next_expected - 1;
        earlier_extents = Some((through, record_bytes(&dir, 1, through)));
    }
    assert!(next_expected > 100, "{next_expected}");
    assert_eq!(header_capacity(&dir), (next_expected - 1).div_ceil(4) * 4);
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// The first identities of a new extent commit, abort, or are still open at
/// the crash; all three survive restart with the right status.
#[test]
fn a3_commit_and_abort_across_the_extent_boundary_survive_restart() {
    let dir = directory("boundary");
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let mut store = StatusFile::create(&dir, 4).unwrap();
    store.set_growth_extent(4).unwrap();
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    let mut sequences = BTreeMap::new();
    for id in 1..=4 {
        assert_eq!(registry.allocate().unwrap(), id);
        wal.begin_mvcc(id).unwrap();
        let receipt = wal.commit().unwrap();
        registry.commit(&receipt).unwrap();
        sequences.insert(id, receipt.lsn());
    }
    assert_eq!(header_capacity(&dir), 4);
    assert_eq!(registry.allocate().unwrap(), 5); // grows to 8
    assert_eq!(header_capacity(&dir), 8);
    wal.begin_mvcc(5).unwrap();
    let receipt = wal.commit().unwrap();
    registry.commit(&receipt).unwrap();
    sequences.insert(5, receipt.lsn());
    assert_eq!(registry.allocate().unwrap(), 6);
    registry.abort(6).unwrap();
    assert_eq!(registry.allocate().unwrap(), 7); // open at the "crash"
    assert_eq!(registry.allocate().unwrap(), 8);
    assert_eq!(registry.allocate().unwrap(), 9); // grows to 12, open at the "crash"
    assert_eq!(header_capacity(&dir), 12);
    std::mem::forget(registry); // no clean shutdown
    drop(wal);
    for _ in 0..2 {
        let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
        for (id, sequence) in &sequences {
            assert_eq!(
                statuses.status(*id).unwrap(),
                Status::Committed {
                    sequence: *sequence
                }
            );
        }
        for id in [6, 7, 8, 9] {
            assert_eq!(statuses.status(id).unwrap(), Status::Aborted, "id {id}");
        }
        assert_eq!(statuses.next_transaction, 10);
        assert_eq!(statuses.capacity(), 12);
        assert!(
            statuses.status(10).is_err(),
            "unreserved identity is unknown"
        );
        drop(wal);
    }
    fs::remove_dir_all(dir).unwrap();
}

/// Eight sessions race BEGIN/ROLLBACK and BEGIN/COMMIT through eleven
/// consecutive four-record extents: identities unique and dense, one growth
/// at a time, no ResourceLimit, no deadlock.
#[test]
fn a3_concurrent_reservations_cross_extents_with_unique_identities() {
    use std::sync::{Arc, Barrier, Mutex};
    let dir = directory("concurrent");
    let wal = Arc::new(Mutex::new(Wal::create_with_mvcc(&dir).unwrap()));
    let mut store = StatusFile::create(&dir, 4).unwrap();
    store.set_growth_extent(4).unwrap();
    let manager = sessions::SessionManager::new(store, 16, 16, 64).unwrap();
    let threads = 8usize;
    let per_thread = 6u64;
    let barrier = Arc::new(Barrier::new(threads));
    let mut workers = Vec::new();
    for worker in 0..threads as u64 {
        let manager = manager.clone();
        let wal = wal.clone();
        let barrier = barrier.clone();
        workers.push(std::thread::spawn(move || {
            let session = manager.connect(worker + 1).unwrap();
            barrier.wait();
            let mut ids = Vec::new();
            for step in 0..per_thread {
                let id = session.begin().unwrap();
                ids.push(id);
                if (worker + step) % 2 == 0 {
                    session.rollback().unwrap();
                } else {
                    let permit = session.submit_commit().unwrap();
                    // Publication is ordered by commit LSN, as the coordinator
                    // guarantees; hold the WAL across commit and publish.
                    let mut wal = wal.lock().unwrap();
                    wal.begin_mvcc(id).unwrap();
                    let receipt = wal.commit().unwrap();
                    permit.publish(&receipt, || Ok(())).unwrap();
                }
            }
            ids
        }));
    }
    let mut all: Vec<u64> = workers
        .into_iter()
        .flat_map(|worker| worker.join().unwrap())
        .collect();
    all.sort_unstable();
    let total = threads as u64 * per_thread;
    assert_eq!(
        all,
        (1..=total).collect::<Vec<_>>(),
        "unique, dense, monotonic identities"
    );
    assert_eq!(header_capacity(&dir), total.div_ceil(4) * 4);
    drop(manager);
    let wal = Arc::try_unwrap(wal).ok().unwrap().into_inner().unwrap();
    drop(wal);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    let mut committed = 0;
    for id in 1..=total {
        match statuses.status(id).unwrap() {
            Status::Committed { .. } => committed += 1,
            Status::Aborted => {}
            Status::InProgress => panic!("id {id} still in progress after restart"),
        }
    }
    assert_eq!(committed, total / 2);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// Injected failures of the extension protocol fence the store, leave the
/// previous extent intact, and recover cleanly; the failed identity is never
/// reported as allocated.
#[test]
fn a3_failed_extension_fences_and_recovers_without_losing_the_previous_extent() {
    for fault in [
        status_file::GrowthFault::BeforeHeaderWrite,
        status_file::GrowthFault::HeaderWrite,
        status_file::GrowthFault::HeaderSync,
    ] {
        for lose_unsynced_header in [false, true] {
            let dir = directory("fault");
            let mut wal = Wal::create_with_mvcc(&dir).unwrap();
            let mut store = StatusFile::create(&dir, 4).unwrap();
            store.set_growth_extent(4).unwrap();
            let mut registry = TransactionRegistry::new(store, 16).unwrap();
            let mut sequences = BTreeMap::new();
            for id in 1..=4 {
                assert_eq!(registry.allocate().unwrap(), id);
                wal.begin_mvcc(id).unwrap();
                let receipt = wal.commit().unwrap();
                registry.commit(&receipt).unwrap();
                sequences.insert(id, receipt.lsn());
            }
            let before = record_bytes(&dir, 1, 4);
            registry.statuses.growth_fault = Some(fault);
            let failed = registry.allocate();
            assert_eq!(failed.unwrap_err().code, ErrorCode::Io, "{fault:?}");
            // Fenced until recovery, and the failure is visible to readers.
            assert!(registry.statuses.ensure_available().is_err());
            assert!(
                registry
                    .statuses
                    .failure_flag()
                    .load(std::sync::atomic::Ordering::Acquire)
            );
            assert!(
                registry.allocate().is_err(),
                "{fault:?}: fenced store handed out an identity"
            );
            assert_eq!(
                file_len(&dir),
                HEADER + 4 * RECORD,
                "no record past the grant"
            );
            assert_eq!(record_bytes(&dir, 1, 4), before, "previous extent intact");
            drop(registry);
            drop(wal);
            if fault == status_file::GrowthFault::HeaderSync && lose_unsynced_header {
                // Model the unforced header write never reaching the disk.
                rewrite_header(&dir, Some(4), None);
            }
            let expected_capacity = match (fault, lose_unsynced_header) {
                (status_file::GrowthFault::HeaderSync, false) => 8,
                _ => 4,
            };
            assert_eq!(header_capacity(&dir), expected_capacity, "{fault:?}");
            let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
            assert_eq!(statuses.capacity(), expected_capacity);
            assert_eq!(
                statuses.next_transaction, 5,
                "the failed identity was never reserved"
            );
            for (id, sequence) in &sequences {
                assert_eq!(
                    statuses.status(*id).unwrap(),
                    Status::Committed {
                        sequence: *sequence
                    }
                );
            }
            statuses.set_growth_extent(4).unwrap();
            let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
            assert_eq!(
                registry.allocate().unwrap(),
                5,
                "{fault:?}: growth resumes after recovery"
            );
            assert_eq!(header_capacity(&dir), 8);
            registry.abort(5).unwrap();
            drop(registry);
            drop(wal);
            fs::remove_dir_all(dir).unwrap();
        }
    }
}

/// A record write failing right after a successful extension (the first
/// record of the new extent) behaves like any reservation write failure.
#[test]
fn a3_record_write_failure_after_growth_leaves_a_recoverable_store() {
    let dir = directory("record-fault");
    let wal = Wal::create_with_mvcc(&dir).unwrap();
    let mut store = StatusFile::create(&dir, 4).unwrap();
    store.set_growth_extent(4).unwrap();
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    for id in 1..=4 {
        assert_eq!(registry.allocate().unwrap(), id);
        registry.abort(id).unwrap();
    }
    // Growth succeeds (header rewritten through the writable handle) and
    // then the record write hits a real OS error on a read-only handle.
    registry
        .statuses
        .replace_file_for_test(fs::File::open(dir.join(NAME)).unwrap());
    let failed = registry.allocate();
    assert!(failed.is_err());
    assert!(registry.statuses.ensure_available().is_err());
    drop(registry);
    drop(wal);
    // Whether or not the grant reached the disk, recovery accepts the file:
    // no record exists past the old grant.
    assert!(file_len(&dir) <= HEADER + 4 * RECORD);
    let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.next_transaction, 5);
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 5);
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// Every plausible interrupted or malformed tail state has a defined rule.
#[test]
fn a3_partial_and_malformed_extension_states_are_repaired_or_rejected() {
    let build = |label: &str| {
        let dir = directory(label);
        let mut wal = Wal::create_with_mvcc(&dir).unwrap();
        let mut store = StatusFile::create(&dir, 4).unwrap();
        store.set_growth_extent(4).unwrap();
        let mut registry = TransactionRegistry::new(store, 16).unwrap();
        for id in 1..=6 {
            assert_eq!(registry.allocate().unwrap(), id);
            if id % 2 == 0 {
                wal.begin_mvcc(id).unwrap();
                let receipt = wal.commit().unwrap();
                registry.commit(&receipt).unwrap();
            } else {
                registry.abort(id).unwrap();
            }
        }
        assert_eq!(header_capacity(&dir), 8);
        drop(registry);
        drop(wal);
        dir
    };
    let append = |dir: &Path, bytes: &[u8]| {
        let mut file = fs::OpenOptions::new()
            .append(true)
            .open(dir.join(NAME))
            .unwrap();
        file.write_all(bytes).unwrap();
        file.sync_all().unwrap();
    };

    // 1. Length ends partway through a record at or beyond the durable
    //    reservation boundary (D1: reservations are written lazily, so a
    //    crash can tear the last one): the torn tail is dropped and the
    //    identity was never durable anywhere, so recovery proceeds with the
    //    whole records only. Below the boundary the same tail is a lost
    //    reservation extent and is refused.
    let dir = build("torn-record");
    append(&dir, &[0x11; 16]);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.next_transaction, 7);
    assert!(statuses.status(7).is_err());
    assert_eq!(file_len(&dir), HEADER + 6 * RECORD);
    drop(statuses);
    drop(wal);
    append(&dir, &[0x11; 16]);
    rewrite_header(&dir, None, Some(8));
    let error = StatusFile::recover(&dir)
        .err()
        .expect("recovery must refuse this file");
    assert!(
        error.message.contains("lost MVCC reservation extent"),
        "{error:?}"
    );
    fs::remove_dir_all(dir).unwrap();

    // 2. Records exist past the durable grant (stale capacity after physical
    //    growth): impossible under the protocol, so it is corruption.
    let dir = build("past-grant");
    let record = record_bytes(&dir, 6, 6);
    append(&dir, &record);
    append(&dir, &record);
    append(&dir, &record); // 9 records, grant 8
    let error = StatusFile::recover(&dir)
        .err()
        .expect("recovery must refuse this file");
    assert!(
        error.message.contains("invalid MVCC status extent"),
        "{error:?}"
    );
    fs::remove_dir_all(dir).unwrap();

    // 3. Grant larger than the physical file (the normal state after growth):
    //    accepted; unwritten slots are simply not reserved.
    let dir = build("grant-ahead");
    rewrite_header(&dir, Some(64), None);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.capacity(), 64);
    assert_eq!(statuses.next_transaction, 7);
    assert!(statuses.status(7).is_err());
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 7);
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();

    // 4. Stale reservation boundary behind the physical records (crash after
    //    the record force, before the boundary force): the physical length
    //    is authoritative; the boundary is repaired forward.
    let dir = build("stale-boundary");
    rewrite_header(&dir, None, Some(3));
    let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.next_transaction, 7);
    drop(statuses);
    drop(wal);
    assert_eq!(header_boundary(&dir), 7);
    fs::remove_dir_all(dir).unwrap();

    // 5. Boundary ahead of the physical records: a reservation was advertised
    //    whose record is gone. Fail closed rather than reuse identities.
    let dir = build("lost-reservation");
    rewrite_header(&dir, None, Some(9));
    let error = StatusFile::recover(&dir)
        .err()
        .expect("recovery must refuse this file");
    assert!(
        error.message.contains("lost MVCC reservation extent"),
        "{error:?}"
    );
    fs::remove_dir_all(dir).unwrap();

    // 6. A zero slot below the file length (never written but allocated by
    //    the filesystem). D1: at or beyond the durable boundary it is a
    //    lazily written reservation the crash lost; nothing durable can name
    //    it, so it resolves as Aborted (and the identity is not re-issued).
    //    Below the boundary it is a lost reservation and is refused.
    let dir = build("zero-slot");
    append(&dir, &[0; RECORD as usize]);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.next_transaction, 8);
    assert_eq!(statuses.status(7).unwrap(), Status::Aborted);
    drop(statuses);
    drop(wal);
    append(&dir, &[0; RECORD as usize]);
    rewrite_header(&dir, None, Some(9));
    let error = StatusFile::recover(&dir)
        .err()
        .expect("recovery must refuse this file");
    assert!(
        error.message.contains("lost reserved MVCC status"),
        "{error:?}"
    );
    fs::remove_dir_all(dir).unwrap();

    // 7. Interior corruption in the first extent after a later growth is a
    //    hard error, never reinterpreted.
    let dir = build("interior");
    let mut file = fs::OpenOptions::new()
        .write(true)
        .open(dir.join(NAME))
        .unwrap();
    file.seek(SeekFrom::Start(HEADER + 2 * RECORD + 16))
        .unwrap();
    file.write_all(&[9]).unwrap(); // status tag of id 3
    file.sync_all().unwrap();
    drop(file);
    let error = StatusFile::recover(&dir)
        .err()
        .expect("recovery must refuse this file");
    assert!(error.message.contains("corrupt"), "{error:?}");
    fs::remove_dir_all(dir).unwrap();

    // 8. A torn header (bad checksum) is refused, whatever the capacity says.
    let dir = build("torn-header");
    let mut header = header_bytes(&dir);
    header[8..16].copy_from_slice(&12u64.to_le_bytes()); // no reseal
    let mut file = fs::OpenOptions::new()
        .write(true)
        .open(dir.join(NAME))
        .unwrap();
    file.write_all(&header).unwrap();
    file.sync_all().unwrap();
    drop(file);
    let error = StatusFile::recover(&dir)
        .err()
        .expect("recovery must refuse this file");
    assert!(
        error.message.contains("corrupt MVCC status header"),
        "{error:?}"
    );
    fs::remove_dir_all(dir).unwrap();
}

/// A status file written by the pre-A3 engine is byte-for-byte what `create`
/// writes today: it opens unchanged, becomes the first extent, and grows.
#[test]
fn a3_pre_a3_status_file_opens_unchanged_and_becomes_the_first_extent() {
    let dir = directory("compat");
    let wal = Wal::create_with_mvcc(&dir).unwrap();
    // Hand-built pre-A3 header: magic, version 2, record size 32, capacity 4,
    // reservation boundary 1, reserved zeros, checksum.
    let mut expected = [0u8; 32];
    expected[..4].copy_from_slice(b"PHMS");
    expected[4..6].copy_from_slice(&2u16.to_le_bytes());
    expected[6..8].copy_from_slice(&32u16.to_le_bytes());
    expected[8..16].copy_from_slice(&4u64.to_le_bytes());
    expected[16..24].copy_from_slice(&1u64.to_le_bytes());
    let checksum = crate::checksum(&expected[..28]);
    expected[28..].copy_from_slice(&checksum.to_le_bytes());
    let store = StatusFile::create(&dir, 4).unwrap();
    drop(store);
    assert_eq!(header_bytes(&dir), expected, "format unchanged");
    // Fill the "old" file exactly as the old engine would have (same code path).
    drop(wal);
    let (statuses, mut wal) = StatusFile::recover_database(&dir).unwrap();
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    for id in 1..=4 {
        assert_eq!(registry.allocate().unwrap(), id);
        wal.begin_mvcc(id).unwrap();
        let receipt = wal.commit().unwrap();
        registry.commit(&receipt).unwrap();
    }
    assert_eq!(header_capacity(&dir), 4);
    assert_eq!(file_len(&dir), HEADER + 4 * RECORD);
    drop(registry);
    drop(wal);
    // No migration step: reopen and keep going.
    let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.capacity(), 4);
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 5);
    assert_eq!(header_capacity(&dir), 4 + DEFAULT_GROWTH_EXTENT);
    registry.abort(5).unwrap();
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// Growth arithmetic is checked: a grant already at the file-offset limit
/// reports ResourceLimit instead of wrapping, and the extent knob is validated.
#[test]
fn a3_growth_arithmetic_is_checked_at_the_offset_limit() {
    let dir = directory("limit");
    let wal = Wal::create_with_mvcc(&dir).unwrap();
    let max_capacity = (u64::MAX - HEADER) / RECORD;
    assert!(StatusFile::create(&dir, max_capacity + 1).is_err());
    let mut store = StatusFile::create(&dir, 4).unwrap();
    assert!(store.set_growth_extent(0).is_err());
    assert!(store.set_growth_extent(max_capacity + 1).is_err());
    store.set_growth_extent(max_capacity).unwrap(); // one growth saturates the grant
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    for id in 1..=5 {
        assert_eq!(registry.allocate().unwrap(), id);
        registry.abort(id).unwrap();
    }
    assert_eq!(
        header_capacity(&dir),
        max_capacity,
        "saturated, not wrapped"
    );
    // Simulate a store whose grant is exhausted: the next extension must fail
    // with ResourceLimit rather than overflow.
    registry.statuses.set_growth_extent(4).unwrap();
    drop(registry);
    drop(wal);
    // Reopening a saturated grant is fine; the header is still consistent.
    let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.capacity(), max_capacity);
    drop(statuses);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// Process-crash points around extension and the first reservations of the
/// new extent, in the style of the existing certification campaigns: a child
/// process exits without destructors at the requested boundary; the parent
/// recovers twice and checks every invariant.
#[test]
fn a3_crash_points_around_extension_recover_without_reuse_or_loss() {
    use std::process::{Command, exit};
    const POINT: &str = "PHOBOS_A3_CRASH_POINT";
    const ROOT: &str = "PHOBOS_A3_ROOT";
    const TEST: &str =
        "mvcc::growth_tests::a3_crash_points_around_extension_recover_without_reuse_or_loss";
    if let Ok(point) = std::env::var(POINT) {
        let dir = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let (mut statuses, mut wal) = StatusFile::recover_database(&dir).unwrap();
        statuses.set_growth_extent(4).unwrap();
        let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
        let marker = dir.join("crash.marker");
        let target = point.clone();
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            std::sync::Arc::new(move |observed| {
                if observed == target {
                    let mut file = fs::File::create(&marker).unwrap();
                    file.write_all(observed.as_bytes()).unwrap();
                    file.sync_all().unwrap();
                    exit(86); // No Rust destructors, no graceful shutdown.
                }
            }),
        );
        // Identity 5 is the first of the new extent; the hook fires inside it.
        let id = registry.allocate().unwrap();
        assert_eq!(id, 5);
        match point.as_str() {
            "after_first_commit" => {
                wal.begin_mvcc(id).unwrap();
                let receipt = wal.commit().unwrap();
                registry.commit(&receipt).unwrap();
                exit(86);
            }
            "after_first_abort" => {
                registry.abort(id).unwrap();
                exit(86);
            }
            _ => panic!("crash boundary not reached: {point}"),
        }
    }
    // D1: reservations are no longer forced individually, so the former
    // `a3_reserve_record_synced`/`a3_reserve_boundary_persisted` points no
    // longer exist; the record write itself is the last reservation step.
    let points = [
        "a3_grow_before_header",
        "a3_grow_header_written",
        "a3_grow_header_synced",
        "a3_reserve_record_written",
        "after_first_commit",
        "after_first_abort",
    ];
    for point in points {
        let dir = directory("crash");
        let mut wal = Wal::create_with_mvcc(&dir).unwrap();
        let mut store = StatusFile::create(&dir, 4).unwrap();
        store.set_growth_extent(4).unwrap();
        let mut registry = TransactionRegistry::new(store, 16).unwrap();
        let mut sequences = BTreeMap::new();
        for id in 1..=4 {
            assert_eq!(registry.allocate().unwrap(), id);
            wal.begin_mvcc(id).unwrap();
            let receipt = wal.commit().unwrap();
            registry.commit(&receipt).unwrap();
            sequences.insert(id, receipt.lsn());
        }
        drop(registry);
        drop(wal);
        let dir = fs::canonicalize(&dir).unwrap();
        let output = Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env(POINT, point)
            .env(ROOT, &dir)
            .output()
            .unwrap();
        assert_eq!(
            output.status.code(),
            Some(86),
            "{point}: child did not crash at the boundary\n{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let marker_present = dir.join("crash.marker").exists();
        assert!(marker_present || point.starts_with("after_"), "{point}");
        let previous = record_bytes(&dir, 1, 4);
        for round in 0..2 {
            let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
            // Invariant: identity 5 is either not reserved at all (crash before
            // its record was forced) or reserved and resolved; never reused.
            let reserved_5 = statuses.next_transaction >= 6;
            match point {
                "a3_grow_before_header" | "a3_grow_header_written" | "a3_grow_header_synced" => {
                    assert!(
                        !reserved_5,
                        "{point}: no record may exist before the grant is forced"
                    );
                    assert!(
                        statuses.capacity() == 4 || statuses.capacity() == 8,
                        "{point}"
                    );
                }
                "a3_reserve_record_written" | "after_first_abort" => {
                    // The lazily written record may or may not have reached
                    // the disk (D1); both are legal, and a surviving record
                    // resolves as Aborted below.
                    assert_eq!(statuses.capacity(), 8, "{point}");
                }
                _ => {
                    // The forced WAL COMMIT names identity 5: recovery
                    // re-reserves it from the WAL even if its status record
                    // was lost.
                    assert!(reserved_5, "{point}: durable identity lost");
                    assert_eq!(statuses.capacity(), 8, "{point}");
                }
            }
            assert_eq!(
                header_boundary(&dir),
                statuses.next_transaction,
                "{point} round {round}"
            );
            assert!(file_len(&dir) <= HEADER + statuses.capacity() * RECORD);
            for (id, sequence) in &sequences {
                assert_eq!(
                    statuses.status(*id).unwrap(),
                    Status::Committed {
                        sequence: *sequence
                    }
                );
            }
            assert_eq!(
                record_bytes(&dir, 1, 4),
                previous,
                "{point}: first extent rewritten"
            );
            if reserved_5 {
                let status = statuses.status(5).unwrap();
                match point {
                    "after_first_commit" => {
                        assert!(matches!(status, Status::Committed { .. }), "{point}")
                    }
                    _ => assert_eq!(status, Status::Aborted, "{point}"),
                }
            } else {
                assert!(statuses.status(5).is_err());
            }
            if round == 1 {
                // The store keeps allocating past the crash: fresh identities,
                // never one that was reserved before.
                let next = statuses.next_transaction;
                statuses.set_growth_extent(4).unwrap();
                let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
                for offset in 0..8 {
                    let id = registry.allocate().unwrap();
                    assert_eq!(id, next + offset, "{point}");
                    registry.abort(id).unwrap();
                }
                drop(registry);
            } else {
                drop(statuses);
            }
            drop(wal);
        }
        fs::remove_dir_all(dir).unwrap();
    }
}

/// Legacy (non-stable) stores take identities from the WAL and write their
/// first record at the final status; the grant extends there and during
/// recovery of retained BEGIN records.
#[test]
fn a3_legacy_store_grows_at_final_status_and_during_recovery() {
    let dir = directory("legacy");
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let mut store = StatusFile::create(&dir, 2).unwrap();
    assert!(!store.uses_stable_identity());
    store.set_growth_extent(2).unwrap();
    let mut registry = TransactionRegistry::new(store, 8).unwrap();
    let mut sequences = BTreeMap::new();
    for step in 1..=6u64 {
        let id = wal.begin().unwrap();
        registry.begin(id).unwrap();
        if step % 2 == 0 {
            let receipt = wal.commit().unwrap();
            registry.commit(&receipt).unwrap();
            sequences.insert(id, receipt.lsn());
        } else {
            wal.abort().unwrap();
            registry.abort(id).unwrap();
        }
    }
    assert_eq!(header_capacity(&dir), 6);
    // A BEGIN past the grant, left open at the crash, is aborted by recovery
    // after the grant has grown to cover it.
    let open = wal.begin().unwrap();
    registry.begin(open).unwrap();
    // 0.2-E Mode E: the open BEGIN reaches the WAL file only with a force.
    wal.sync_for_test().unwrap();
    std::mem::forget(registry);
    drop(wal);
    let mut statuses = StatusFile::recover(&dir).unwrap();
    assert!(statuses.capacity() >= open);
    for (id, sequence) in &sequences {
        assert_eq!(
            statuses.read_status(*id).unwrap(),
            Some(Status::Committed {
                sequence: *sequence
            })
        );
    }
    assert_eq!(statuses.read_status(open).unwrap(), Some(Status::Aborted));
    drop(statuses);
    fs::remove_dir_all(dir).unwrap();
}
