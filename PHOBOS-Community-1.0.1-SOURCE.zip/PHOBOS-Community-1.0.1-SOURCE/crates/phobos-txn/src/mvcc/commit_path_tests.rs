//! 0.1.9-D1: lazy identity allocation and lazy status persistence.
//!
//! The WAL is the durability boundary of a commit; the status file is written
//! through the page cache and forced only by checkpoint/freeze/recovery.
//! These tests simulate the loss of unforced status bytes by truncating the
//! file behind the store's back and prove that recovery reconstructs every
//! acknowledged commit from the retained WAL.
use super::*;
use crate::mvcc::sessions::SessionManager;
use phobos_wal::v2::Wal;
use std::{fs, path::PathBuf};

fn directory(label: &str) -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let sequence = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    std::env::temp_dir().join(format!(
        "phobos-d1-{label}-{}-{}-{sequence}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}

/// Truncates the status file to `records` whole records: exactly what a
/// crash may leave when later records were written but never forced.
fn lose_status_tail(dir: &std::path::Path, records: u64) {
    let file = fs::OpenOptions::new()
        .write(true)
        .open(dir.join("phobos.mvcc-status"))
        .unwrap();
    file.set_len(32 + records * 32).unwrap();
    file.sync_all().unwrap();
}

#[test]
fn d1_read_only_transactions_allocate_no_identity_and_force_nothing() {
    let dir = directory("read-only");
    let wal = Wal::create_with_versioned_heap(&dir).unwrap();
    let manager = SessionManager::new(StatusFile::create(&dir, 16).unwrap(), 8, 8, 8).unwrap();
    let before = manager.commit_metrics();
    let session = manager.connect(1).unwrap();
    // BEGIN; SELECT; COMMIT
    session.begin_deferred().unwrap();
    assert_eq!(session.transaction_id().unwrap(), None);
    {
        let statement = session.statement().unwrap();
        assert_eq!(statement.snapshot().own_transaction(), None);
    }
    session.finish_read_only().unwrap();
    // BEGIN; SELECT; ROLLBACK
    session.begin_deferred().unwrap();
    drop(session.statement().unwrap());
    session.rollback().unwrap();
    // A failed read-only transaction still needs ROLLBACK, without an identity.
    session.begin_deferred().unwrap();
    session.fail_statement().unwrap();
    assert!(session.finish_read_only().is_err());
    assert!(session.statement().is_err());
    session.rollback().unwrap();
    let after = manager.commit_metrics();
    assert_eq!(after.ids_allocated, before.ids_allocated);
    assert_eq!(after.status_writes, before.status_writes);
    assert_eq!(after.status_forces, before.status_forces);
    assert!(manager.is_idle().unwrap());
    // The next writer gets identity 1: nothing was consumed.
    session.begin_deferred().unwrap();
    assert_eq!(session.ensure_transaction_id().unwrap(), 1);
    assert_eq!(session.ensure_transaction_id().unwrap(), 1);
    assert_eq!(session.transaction_id().unwrap(), Some(1));
    session.rollback().unwrap();
    assert_eq!(manager.commit_metrics().ids_allocated, 1);
    drop(session);
    drop(manager);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn d1_commit_costs_one_wal_force_and_no_status_force() {
    let dir = directory("one-force");
    let mut wal = Wal::create_with_versioned_heap(&dir).unwrap();
    let manager = SessionManager::new(StatusFile::create(&dir, 16).unwrap(), 8, 8, 8).unwrap();
    let session = manager.connect(1).unwrap();
    let before = manager.commit_metrics();
    session.begin_deferred().unwrap();
    let stable = session.ensure_transaction_id().unwrap();
    wal.begin_mvcc(stable).unwrap();
    let receipt = wal.commit().unwrap();
    let permit = session.submit_commit().unwrap();
    permit.publish(&receipt, || Ok(())).unwrap();
    let after = manager.commit_metrics();
    assert_eq!(after.ids_allocated - before.ids_allocated, 1);
    // Reserve + commit records, zero status-file forces: the WAL force is
    // the durability boundary.
    assert_eq!(after.status_writes - before.status_writes, 2);
    assert_eq!(after.status_forces, before.status_forces);
    assert_eq!(
        manager.lookup(stable).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    drop(session);
    drop(manager);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn d1_recovery_reconstructs_committed_status_lost_before_any_status_force() {
    let dir = directory("reconstruct");
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let store = StatusFile::create(&dir, 4).unwrap();
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    let mut sequences = BTreeMap::new();
    // 1 commits, 2 aborts, 3 commits, 4 is left in progress, 5 commits.
    for id in 1..=5u64 {
        assert_eq!(registry.allocate().unwrap(), id);
        match id {
            2 => registry.abort(id).unwrap(),
            4 => {}
            _ => {
                wal.begin_mvcc(id).unwrap();
                let receipt = wal.commit().unwrap();
                registry.commit(&receipt).unwrap();
                sequences.insert(id, receipt.lsn());
            }
        }
    }
    std::mem::forget(registry);
    drop(wal);
    // The crash lost every status record after the first: only the WAL knows.
    lose_status_tail(&dir, 1);
    for round in 0..2 {
        let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
        assert_eq!(statuses.next_transaction, 6, "round {round}");
        for (id, sequence) in &sequences {
            assert_eq!(
                statuses.status(*id).unwrap(),
                Status::Committed {
                    sequence: *sequence
                },
                "round {round} id {id}"
            );
        }
        assert_eq!(statuses.status(2).unwrap(), Status::Aborted);
        assert_eq!(statuses.status(4).unwrap(), Status::Aborted);
        assert!(statuses.status(6).is_err());
        drop(statuses);
        drop(wal);
    }
    // A checkpoint forces the records and the boundary; the WAL may then be
    // retired and the statuses still resolve from the file alone.
    let (statuses, mut wal) = StatusFile::recover_database(&dir).unwrap();
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    registry.checkpoint(&mut wal).unwrap();
    drop(registry);
    drop(wal);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    for (id, sequence) in &sequences {
        assert_eq!(
            statuses.status(*id).unwrap(),
            Status::Committed {
                sequence: *sequence
            }
        );
    }
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 6);
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// An identity that never reached any durable structure may be re-issued
/// after a crash; one named by a durable WAL record never is.
#[test]
fn d1_lost_unforced_reservation_is_reissued_only_when_nothing_durable_names_it() {
    let dir = directory("reissue");
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let store = StatusFile::create(&dir, 4).unwrap();
    let mut registry = TransactionRegistry::new(store, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 1);
    wal.begin_mvcc(1).unwrap();
    let receipt = wal.commit().unwrap();
    registry.commit(&receipt).unwrap();
    // 2 was allocated but wrote nothing durable; 3 wrote a WAL record and
    // was left open.
    assert_eq!(registry.allocate().unwrap(), 2);
    assert_eq!(registry.allocate().unwrap(), 3);
    wal.begin_mvcc(3).unwrap();
    // 0.2-E Mode E: a BEGIN reaches the WAL file with the next force (Mode A
    // wrote it to the OS cache at once); force it so the WAL names 3.
    wal.sync_for_test().unwrap();
    std::mem::forget(registry);
    drop(wal);
    lose_status_tail(&dir, 1);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    // The WAL names 3, so 2 and 3 are re-reserved and resolved as aborted.
    assert_eq!(statuses.next_transaction, 4);
    assert_eq!(statuses.status(2).unwrap(), Status::Aborted);
    assert_eq!(statuses.status(3).unwrap(), Status::Aborted);
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 4);
    std::mem::forget(registry);
    drop(wal);
    // Nothing durable names 4: after this crash it is re-issued, which no
    // durable structure can observe.
    lose_status_tail(&dir, 3);
    let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.next_transaction, 4);
    let mut registry = TransactionRegistry::new(statuses, 16).unwrap();
    assert_eq!(registry.allocate().unwrap(), 4);
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}
