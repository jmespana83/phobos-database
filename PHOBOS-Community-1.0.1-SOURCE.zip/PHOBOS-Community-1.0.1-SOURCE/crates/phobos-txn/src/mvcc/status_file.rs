//! Fixed-address durable commit-status storage. A COMMIT's WAL LSN
//! is its commit sequence. Aborts have explicit records; zero slots are unknown. Live IDs
//! must be resolved by the coordinator's bounded active-transaction registry.
//!
//! Ordinary open never creates this file. Explicit capability migration creates
//! it; recovery reconciles visibility before page redo and WAL retirement.
//!
//! Durability (0.1.9-D1). Status records are written through the page cache
//! and are **not** forced individually: the WAL is the durability boundary
//! of every commit (its force precedes the ack, and its COMMIT records are
//! retained until a checkpoint has first forced this file), so a committed
//! status is always reconstructible from the retained WAL. The header's
//! reservation boundary is forced only at checkpoint/recovery; records at or
//! beyond it may be lost by a crash, in which case recovery treats them as
//! never reserved (identities that never reached any durable structure may be
//! re-issued; identities named by a durable WAL record are re-reserved and
//! resolved). Records below the boundary are durable and still validated
//! strictly.
//!
//! Capacity (0.1.9-A3). The header's capacity field is a durable *grant* of
//! record slots, not a lifetime ceiling. Records are written at fixed offsets
//! as identities are reserved, so the file itself grows one record at a time
//! and never contains uninitialised slots below its length. When a reservation
//! would exceed the granted capacity the grant is extended by one bounded
//! extent: the new capacity is written into the header and forced to disk
//! *before* any record beyond the old grant is written. Recovery keeps
//! rejecting a file whose length exceeds its granted capacity, so a crash at
//! any point of the extension leaves either the old grant (with no record past
//! it) or the new grant, never a record the durable header cannot account for.
use super::{Result, Status, StatusLookup, invalid};
use phobos_error::{ErrorCode, PhobosError};
use phobos_wal::v2::{Body, DurableCommit, inspect, visit_validated};
use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

const NAME: &str = "phobos.mvcc-status";
const HEADER: u64 = 32;
const RECORD: u64 = 32;
/// Largest record count whose byte offset fits a file offset.
const MAX_CAPACITY: u64 = (u64::MAX - HEADER) / RECORD;
/// Records granted per extension (1,048,576 records = 32 MiB of eventual
/// record space). Granting costs one header write and force, never disk
/// space, so the extent only sets how often that force recurs.
pub const DEFAULT_GROWTH_EXTENT: u64 = 1 << 20;
/// 0.1.9-B2: status records are read through 4 KiB pages (128 records) held
/// in a small direct-mapped cache instead of one seek+read per record.
const STATUS_PAGE: u64 = 4096;
/// 0.2-K Part M: temporary name of a status-file rewrite (never a database
/// file: not copied by backups, removed by recovery).
const COMPACT_NAME: &str = "phobos.mvcc-status.compact";
/// 0.2-K Part M: a frozen prefix is released physically once at least this
/// many records (32 B each; 4 MiB) became releasable since the last rewrite.
pub const DEFAULT_TRIM_RECORDS: u64 = 1 << 17;
const STATUS_PAGE_SLOTS: usize = 16;

/// One cached 4 KiB window of the status file. `valid` is how many bytes of
/// the window existed when it was read; later record writes patch the copy
/// in place (extending `valid`), so a cached page never lags a write made
/// through this handle.
struct StatusPage {
    index: u64,
    valid: usize,
    bytes: Box<[u8; STATUS_PAGE as usize]>,
}

/// Test-only fault injection for the extension protocol.
#[cfg(test)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum GrowthFault {
    /// The extension fails before the header is rewritten (e.g. ENOSPC on the
    /// metadata write is reported before any byte changes).
    BeforeHeaderWrite,
    /// The header write itself fails.
    HeaderWrite,
    /// The header was written but forcing it fails.
    HeaderSync,
}

// Readers of immutable terminal statuses can bypass in-flight status I/O, but
// must still observe any failed persistence operation (including unwinding).
struct Failure {
    flag: Arc<AtomicBool>,
    complete: bool,
}
impl Failure {
    fn new(flag: Arc<AtomicBool>) -> Self {
        Self {
            flag,
            complete: false,
        }
    }
}
impl Drop for Failure {
    fn drop(&mut self) {
        if !self.complete {
            self.flag.store(true, Ordering::Release);
        }
    }
}

/// Fixed disk bound and O(1) memory regardless of the number of committed IDs.
/// Capacity exhaustion is explicit backpressure, never implicit status loss.
/// File handles/cursors must be protected by the calling registry's mutex.
pub struct StatusFile {
    file: File,
    directory: PathBuf,
    capacity: u64,
    growth_extent: u64,
    pub(super) next_transaction: u64,
    frontier: u64,
    fenced: bool,
    failed: Arc<AtomicBool>,
    stable: bool,
    pages: Vec<Option<StatusPage>>,
    /// Number of 4 KiB status pages read from the file (B2 evidence).
    page_reads: u64,
    frozen: super::freeze_file::Frozen,
    /// 0.2-K Part M: records below this identity are known to be physically
    /// released (sparse) in the current file. 1 after open (unknown).
    trimmed_below: u64,
    /// 0.2-K Part M: minimum released prefix (records) worth one rewrite.
    trim_threshold: u64,
    startup_ids: u64,
    /// D1 evidence: identities reserved, records written, file forces.
    reservations: u64,
    record_writes: u64,
    forces: u64,
    #[cfg(test)]
    pub(super) growth_fault: Option<GrowthFault>,
}

impl StatusFile {
    pub(super) fn failure_flag(&self) -> Arc<AtomicBool> {
        self.failed.clone()
    }
    /// Swaps the handle so a later write hits a real OS error (tests only).
    #[cfg(test)]
    pub(super) fn replace_file_for_test(&mut self, file: File) {
        self.file = file;
        self.invalidate_pages();
    }
    /// 4 KiB status pages read from the file so far.
    #[must_use]
    pub fn page_reads(&self) -> u64 {
        self.page_reads
    }
    /// D1 evidence: `(identities reserved, status records written, status
    /// file forces)` through this handle.
    #[must_use]
    pub fn commit_counters(&self) -> (u64, u64, u64) {
        (self.reservations, self.record_writes, self.forces)
    }
    /// One `sync_all` of the status file, counted.
    fn force(&mut self, name: &'static str) -> Result<()> {
        self.forces += 1;
        phobos_observability::measure(name, || self.file.sync_all())?;
        Ok(())
    }
    #[cfg(test)]
    pub(super) fn cached_page_count(&self) -> usize {
        self.pages.iter().filter(|page| page.is_some()).count()
    }
    fn invalidate_pages(&mut self) {
        for page in &mut self.pages {
            *page = None;
        }
    }
    /// Drops the cached window holding `offset` (header rewrites: growth
    /// grant and reservation boundary live in the first window).
    fn invalidate_page(&mut self, offset: u64) {
        let index = offset / STATUS_PAGE;
        let slot = (index % STATUS_PAGE_SLOTS as u64) as usize;
        if matches!(&self.pages[slot], Some(page) if page.index == index) {
            self.pages[slot] = None;
        }
    }
    pub(super) fn directory(&self) -> &Path {
        &self.directory
    }
    /// Exclusive database startup ordering: visibility reconciliation precedes
    /// data redo and full WAL retirement, including on every repeated recovery.
    pub fn recover_database(directory: &Path) -> Result<(Self, phobos_wal::v2::Wal)> {
        if inspect(directory.join("phobos.wal"))?.page_format < 3 {
            return Err(invalid(
                "stable visibility recovery requires MVCC capability",
            ));
        }
        let mut statuses = None;
        let wal = phobos_wal::v2::Wal::recover_with_visibility(directory, |path| {
            statuses = Some(Self::recover(path)?);
            Ok(())
        })?;
        let statuses = match statuses {
            Some(value) => value,
            None => Self::recover(directory)?,
        };
        Ok((statuses, wal))
    }
    /// Only for a fresh, exclusively owned database before any MVCC transaction.
    /// Does not migrate an existing database or advertise MVCC to old binaries.
    /// `capacity` is the initial grant only; the store grows past it on demand.
    pub fn create(directory: &Path, capacity: u64) -> Result<Self> {
        if capacity == 0 || capacity > MAX_CAPACITY {
            return Err(invalid("invalid MVCC status capacity"));
        }
        let directory = fs::canonicalize(directory)?;
        let report = inspect(directory.join("phobos.wal"))?;
        if report.next_txn_id != 1 || report.committed_transactions != 0 {
            return Err(invalid(
                "status creation requires a fresh WAL; use offline migration",
            ));
        }
        let mut file = OpenOptions::new()
            .read(true)
            .write(true)
            .create_new(true)
            .open(directory.join(NAME))?;
        let mut header = [0; HEADER as usize];
        header[..4].copy_from_slice(b"PHMS");
        header[4..6]
            .copy_from_slice(&(if report.page_format >= 3 { 2u16 } else { 1u16 }).to_le_bytes());
        header[6..8].copy_from_slice(&(RECORD as u16).to_le_bytes());
        header[8..16].copy_from_slice(&capacity.to_le_bytes());
        if report.page_format >= 3 {
            header[16..24].copy_from_slice(&1u64.to_le_bytes());
        }
        seal(&mut header);
        file.write_all(&header)?;
        file.sync_all()?;
        #[cfg(unix)]
        File::open(&directory)?.sync_all()?;
        Ok(Self {
            file,
            directory,
            capacity,
            growth_extent: DEFAULT_GROWTH_EXTENT,
            next_transaction: 1,
            frontier: 0,
            fenced: false,
            failed: Arc::new(AtomicBool::new(false)),
            stable: report.page_format >= 3,
            pages: (0..STATUS_PAGE_SLOTS).map(|_| None).collect(),
            page_reads: 0,
            frozen: super::freeze_file::Frozen::default(),
            trimmed_below: 1,
            trim_threshold: DEFAULT_TRIM_RECORDS,
            startup_ids: 0,
            reservations: 0,
            record_writes: 0,
            forces: 0,
            #[cfg(test)]
            growth_fault: None,
        })
    }

    /// Must run before WAL recovery/checkpoint retirement under exclusive database
    /// ownership. Forces the validated WAL before deriving durable statuses, and
    /// repairs committed slots from retained COMMIT records before validating the
    /// entire status file. Unknown status lookups fail closed, including after
    /// aligned truncation or loss of a complete historical slot.
    pub fn recover(directory: &Path) -> Result<Self> {
        let directory = fs::canonicalize(directory)?;
        // 0.2-K Part M: an interrupted prefix release left its temporary
        // copy; the live file is authoritative (the rename is atomic).
        match fs::remove_file(directory.join(COMPACT_NAME)) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error.into()),
        }
        let path = directory.join("phobos.wal");
        let report = inspect(&path)?;
        let mut file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(directory.join(NAME))?;
        let mut header = [0; HEADER as usize];
        file.read_exact(&mut header)?;
        if &header[..4] != b"PHMS"
            || !matches!(header[4], 1 | 2)
            || header[5..8] != [0, RECORD as u8, 0]
            || header[24..28] != [0; 4]
            || (header[4] == 1 && header[16..24] != [0; 8])
            || !valid(&header)
        {
            return Err(invalid("unsupported or corrupt MVCC status header"));
        }
        if (header[4] == 2) != (report.page_format >= 3) {
            return Err(invalid("MVCC status/WAL capability mismatch"));
        }
        // The granted capacity bounds the physical file: a record past the
        // grant can only come from corruption or a foreign writer, because the
        // grant is forced before such a record is ever written.
        let capacity = number(&header[8..16]);
        if capacity == 0
            || capacity > MAX_CAPACITY
            || file.metadata()?.len() > HEADER + capacity * RECORD
        {
            return Err(invalid("invalid MVCC status extent"));
        }
        // A complete COMMIT found after restart may not have been acknowledged.
        // Its required WAL is forced before writing the derived status.
        OpenOptions::new()
            .read(true)
            .write(true)
            .open(&path)?
            .sync_all()?;
        let mut store = Self {
            file,
            directory,
            capacity,
            growth_extent: DEFAULT_GROWTH_EXTENT,
            next_transaction: report.next_txn_id,
            frontier: 0,
            fenced: false,
            failed: Arc::new(AtomicBool::new(false)),
            stable: report.page_format >= 3,
            pages: (0..STATUS_PAGE_SLOTS).map(|_| None).collect(),
            page_reads: 0,
            frozen: super::freeze_file::Frozen::default(),
            trimmed_below: 1,
            trim_threshold: DEFAULT_TRIM_RECORDS,
            startup_ids: 0,
            reservations: 0,
            record_writes: 0,
            forces: 0,
            #[cfg(test)]
            growth_fault: None,
        };
        // D1: the durable reservation boundary from the header. Every record
        // below it was forced before the boundary was; records at or beyond
        // it were written lazily and may be torn or missing after a crash.
        let mut durable_boundary = 1;
        if store.stable {
            let length = store.file.metadata()?.len() - HEADER;
            let whole = length / RECORD;
            let reserved = number(&header[16..24]);
            if reserved == 0 || reserved > capacity + 1 || whole + 1 < reserved {
                return Err(invalid(
                    "lost MVCC reservation extent; refusing identity reuse",
                ));
            }
            if length % RECORD != 0 {
                // A torn record at or beyond the boundary was never
                // acknowledged as reserved: drop it (a durable WAL identity
                // re-reserves it below). Below the boundary it is impossible
                // (the boundary check above already refused that file).
                store.file.set_len(HEADER + whole * RECORD)?;
                store.force("mvcc.status_force")?;
            }
            durable_boundary = reserved;
            store.next_transaction = whole + 1;
        }
        store.frozen = super::freeze_file::read(&store.directory)?;
        if (!store.stable && store.frozen.before != 1)
            || store.frozen.reserved > store.next_transaction
            || store.frozen.frontier > report.last_lsn
        {
            return Err(invalid(
                "freezing watermark exceeds durable status/WAL extent",
            ));
        }
        store.frontier = store.frozen.frontier;
        let mut mapped = None;
        visit_validated(&path, |_, record| {
            match record.body {
                Body::Begin => {
                    mapped = None;
                    if !store.stable {
                        // Legacy stores take identities from the WAL, so a
                        // retained BEGIN may lie past the current grant.
                        store.ensure_capacity(record.txn_id)?;
                        store.write_status(record.txn_id, Status::Aborted)?;
                    }
                }
                Body::MvccIdentity(id) => {
                    if !store.stable || id == 0 {
                        return Err(invalid("WAL references an unreserved MVCC identity"));
                    }
                    if id >= store.next_transaction {
                        // D1: the WAL record outlived the lazily written
                        // reservation. Re-reserve every identity up to it;
                        // unresolved ones become Aborted below.
                        if id < durable_boundary {
                            return Err(invalid("WAL references an unreserved MVCC identity"));
                        }
                        for gap in store.next_transaction..=id {
                            store.ensure_capacity(gap)?;
                            store.write_status(gap, Status::InProgress)?;
                        }
                        store.next_transaction = id + 1;
                    }
                    mapped = Some(id);
                }
                Body::Commit => {
                    let id = if store.stable {
                        mapped.ok_or_else(|| invalid("missing stable identity"))?
                    } else {
                        record.txn_id
                    };
                    if id < store.frozen.before {
                        if record.lsn > store.frozen.frontier {
                            return Err(invalid("retained commit exceeds frozen frontier"));
                        }
                        return Ok(());
                    }
                    store.ensure_capacity(id)?;
                    if store.stable
                        && matches!(store.read_status(id), Ok(Some(Status::Committed { sequence })) if sequence != record.lsn)
                    {
                        return Err(invalid("MVCC identity committed more than once"));
                    }
                    store.write_status(
                        id,
                        Status::Committed {
                            sequence: record.lsn,
                        },
                    )?;
                }
                _ => {}
            }
            Ok(())
        })?;
        let bytes = store.file.metadata()?.len() - HEADER;
        if bytes % RECORD != 0 {
            return Err(invalid("torn status not covered by retained WAL"));
        }
        for id in store.frozen.before..=bytes / RECORD {
            store.startup_ids += 1;
            let mut status = store.read_status(id)?;
            if store.stable && status.is_none() {
                if id < durable_boundary {
                    return Err(invalid("lost reserved MVCC status"));
                }
                // D1: a zero slot at or beyond the durable boundary is a
                // reservation whose lazily written record never reached the
                // disk; nothing durable can reference it, so it resolves as
                // aborted (the identity itself is not re-issued).
                store.write_status(id, Status::Aborted)?;
                status = Some(Status::Aborted);
            }
            if store.stable && status == Some(Status::InProgress) {
                store.write_status(id, Status::Aborted)?;
            }
            if let Some(status) = status {
                let sequence = match status {
                    Status::Committed { sequence } => sequence,
                    _ => 0,
                };
                if (!store.stable && id >= report.next_txn_id) || sequence > report.last_lsn {
                    return Err(invalid("status is ahead of its authoritative WAL"));
                }
                store.frontier = store.frontier.max(sequence);
            }
        }
        // Records first, then the boundary that vouches for them (D1).
        store.force("mvcc.status_force")?;
        if store.stable {
            store.persist_reservation_boundary()?;
        }
        Ok(store)
    }

    /// A receipt proves WAL durability, not publication. The caller still has to
    /// install all heap/index versions atomically before advancing snapshots.
    /// D1: the record is written, not forced; the forced WAL COMMIT record is
    /// the durable truth until the next checkpoint forces this file.
    pub fn install(&mut self, receipt: &DurableCommit) -> Result<()> {
        self.ensure_available()?;
        if receipt.directory() != self.directory || receipt.lsn() <= self.frontier {
            return Err(invalid("foreign or out-of-order MVCC durable receipt"));
        }
        let transaction = if self.stable {
            receipt
                .mvcc_id()
                .ok_or_else(|| invalid("receipt has no stable identity"))?
        } else {
            receipt.txn_id()
        };
        self.ensure_capacity(transaction)?;
        self.offset(transaction)?;
        let existing = self.read_status(transaction)?;
        if (self.stable && existing != Some(Status::InProgress))
            || (!self.stable && existing.is_some())
        {
            return Err(invalid(
                "transaction already has an immutable commit status",
            ));
        }
        let next = transaction
            .checked_add(1)
            .ok_or_else(|| invalid("transaction ID exhausted"))?;
        let mut failure = Failure::new(self.failed.clone());
        self.fenced = true;
        self.write_status(
            transaction,
            Status::Committed {
                sequence: receipt.lsn(),
            },
        )?;
        self.frontier = receipt.lsn();
        self.next_transaction = self.next_transaction.max(next);
        self.fenced = false;
        failure.complete = true;
        Ok(())
    }

    /// Internal to the active registry: never legal after a durable COMMIT.
    /// D1: written lazily; an unforced abort lost by a crash recovers as
    /// aborted anyway (unresolved reservations always do).
    pub(super) fn abort(&mut self, transaction: u64) -> Result<()> {
        self.ensure_available()?;
        self.ensure_capacity(transaction)?;
        if matches!(
            self.read_status(transaction)?,
            Some(Status::Committed { .. } | Status::Aborted)
        ) {
            return Err(invalid(
                "cannot abort a transaction with durable final status",
            ));
        }
        let next = transaction
            .checked_add(1)
            .ok_or_else(|| invalid("transaction ID exhausted"))?;
        let mut failure = Failure::new(self.failed.clone());
        self.fenced = true;
        self.write_status(transaction, Status::Aborted)?;
        self.next_transaction = self.next_transaction.max(next);
        self.fenced = false;
        failure.complete = true;
        Ok(())
    }

    pub(super) fn reserve(&mut self, id: u64) -> Result<()> {
        if !self.stable {
            return Ok(());
        }
        self.ensure_available()?;
        if id != self.next_transaction {
            return Err(invalid("stable identity reservation must be contiguous"));
        }
        // Growth is durable before the record that needs it exists.
        self.ensure_capacity(id)?;
        self.offset(id)?;
        let mut failure = Failure::new(self.failed.clone());
        self.fenced = true;
        // D1: the reservation record is written, not forced, and the header
        // boundary is left for the next checkpoint. Before its first WAL
        // record the identity exists nowhere durable, so losing it costs
        // nothing; from its first durable WAL record on, recovery re-reserves
        // it from that record.
        self.write_status(id, Status::InProgress)?;
        phobos_observability::synchronization_boundary(
            "a3_reserve_record_written",
            &self.directory,
        );
        self.next_transaction = id
            .checked_add(1)
            .ok_or_else(|| invalid("identity exhausted"))?;
        self.reservations += 1;
        self.fenced = false;
        failure.complete = true;
        Ok(())
    }

    /// Records granted per extension. Local knob for tests and migration;
    /// not persisted (recovery reopens with the default).
    pub fn set_growth_extent(&mut self, records: u64) -> Result<()> {
        if records == 0 || records > MAX_CAPACITY {
            return Err(invalid("invalid MVCC status growth extent"));
        }
        self.growth_extent = records;
        Ok(())
    }

    /// Extends the durable capacity grant so that record `id` is inside it.
    ///
    /// Ordering: (1) the new capacity is written into the header, (2) the
    /// header is forced, (3) only then does the in-memory grant advance and
    /// the caller write record `id`. A crash before (2) completes leaves
    /// either the old header (no record past the old grant exists yet) or the
    /// new header (harmless: capacity is a grant, not a promise of records);
    /// a torn header fails the checksum and recovery refuses the file rather
    /// than guessing. No record region is pre-extended or zero-filled: slots
    /// are created by the reservation writes themselves, and a zero slot below
    /// the file length is exactly what recovery treats as a lost reservation.
    fn ensure_capacity(&mut self, id: u64) -> Result<()> {
        if id <= self.capacity {
            return Ok(());
        }
        self.ensure_available()?;
        if self.capacity >= MAX_CAPACITY {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC status file offset space exhausted",
            ));
        }
        let extent = self.growth_extent.max(1);
        let target = self
            .capacity
            .checked_add(extent)
            .map_or(MAX_CAPACITY, |grown| grown.min(MAX_CAPACITY))
            .max(id);
        if target > MAX_CAPACITY {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC status file offset space exhausted",
            ));
        }
        let _span = phobos_observability::span("mvcc.status_grow");
        phobos_observability::synchronization_boundary("a3_grow_before_header", &self.directory);
        // Any failure from here on fences the store, like a failed
        // reservation: the caller must reopen to re-derive durable state.
        let mut failure = Failure::new(self.failed.clone());
        self.fenced = true;
        #[cfg(test)]
        if self.growth_fault == Some(GrowthFault::BeforeHeaderWrite) {
            return Err(PhobosError::new(
                ErrorCode::Io,
                "injected: no space left for status extension",
            ));
        }
        let mut header = [0; HEADER as usize];
        self.file.seek(SeekFrom::Start(0))?;
        self.file.read_exact(&mut header)?;
        if !valid(&header) || number(&header[8..16]) != self.capacity {
            return Err(invalid("MVCC status header changed underneath the store"));
        }
        header[8..16].copy_from_slice(&target.to_le_bytes());
        seal(&mut header);
        #[cfg(test)]
        if self.growth_fault == Some(GrowthFault::HeaderWrite) {
            return Err(PhobosError::new(
                ErrorCode::Io,
                "injected: status header write failed",
            ));
        }
        self.file.seek(SeekFrom::Start(0))?;
        self.invalidate_page(0);
        self.file.write_all(&header)?;
        phobos_observability::synchronization_boundary("a3_grow_header_written", &self.directory);
        #[cfg(test)]
        if self.growth_fault == Some(GrowthFault::HeaderSync) {
            return Err(PhobosError::new(
                ErrorCode::Io,
                "injected: status header force failed",
            ));
        }
        self.force("mvcc.status_grow_force")?;
        phobos_observability::synchronization_boundary("a3_grow_header_synced", &self.directory);
        self.capacity = target;
        self.fenced = false;
        failure.complete = true;
        Ok(())
    }

    fn persist_reservation_boundary(&mut self) -> Result<()> {
        let mut header = [0; HEADER as usize];
        self.file.seek(SeekFrom::Start(0))?;
        self.file.read_exact(&mut header)?;
        header[16..24].copy_from_slice(&self.next_transaction.to_le_bytes());
        seal(&mut header);
        self.file.seek(SeekFrom::Start(0))?;
        self.invalidate_page(0);
        self.file.write_all(&header)?;
        self.force("mvcc.reservation_force")?;
        Ok(())
    }

    pub(super) fn checkpoint(&mut self, wal: &mut phobos_wal::v2::Wal) -> Result<()> {
        self.ensure_available()?;
        wal.checkpoint_with_visibility(wal.last_commit_lsn(), |directory| {
            if directory != self.directory {
                return Err(invalid("foreign WAL visibility barrier"));
            }
            self.persist_before_retirement()?;
            Ok(self.frontier)
        })
    }
    /// D1: the only regular status-file force. Every lazily written record is
    /// forced, then the header boundary that vouches for them, before the WAL
    /// that could otherwise reconstruct them is retired.
    fn persist_before_retirement(&mut self) -> Result<()> {
        let mut failure = Failure::new(self.failed.clone());
        self.fenced = true;
        self.force("mvcc.status_force")?;
        if self.stable {
            self.persist_reservation_boundary()?;
        }
        phobos_observability::synchronization_boundary(
            "c5_visibility_before_retirement",
            &self.directory,
        );
        self.fenced = false;
        failure.complete = true;
        Ok(())
    }
    pub(super) fn request_checkpoint(
        &mut self,
        wal: &mut phobos_wal::v2::Wal,
        safe: u64,
    ) -> Result<()> {
        self.ensure_available()?;
        wal.request_checkpoint_with_visibility(safe, |directory| {
            if directory != self.directory {
                return Err(invalid("foreign incremental visibility barrier"));
            }
            self.persist_before_retirement()?;
            Ok(self.frontier)
        })
    }

    #[must_use]
    pub fn durable_frontier(&self) -> u64 {
        self.frontier
    }

    /// Exclusive ID boundary; older records have no surviving tuple references.
    pub fn frozen_before(&self) -> u64 {
        self.frozen.before
    }
    /// Per-ID startup validation work, excluding the logically frozen prefix.
    pub fn startup_ids_examined(&self) -> u64 {
        self.startup_ids
    }

    /// Caller has proved all heap references >= bound while admission is idle.
    /// Independently refuses InProgress/newer-than-horizon records; no status is
    /// guessed to be committed, and old bytes remain available for old-slot recovery.
    pub(super) fn freeze_unreferenced(
        &mut self,
        bound: u64,
        horizon: u64,
        limit: u64,
    ) -> Result<u64> {
        self.ensure_available()?;
        if !self.stable {
            return Err(invalid("freezing requires stable identities"));
        }
        let end = bound
            .min(self.next_transaction)
            .min(self.frozen.before.saturating_add(limit));
        let mut before = self.frozen.before;
        let mut frontier = self.frozen.frontier;
        while before < end {
            match self.read_status(before)? {
                Some(Status::Aborted) => {}
                Some(Status::Committed { sequence }) if sequence <= horizon => {
                    frontier = frontier.max(sequence);
                }
                Some(Status::InProgress | Status::Committed { .. }) => break,
                None => return Err(invalid("cannot freeze missing transaction status")),
            }
            before += 1;
        }
        if before > self.frozen.before {
            let mut failure = Failure::new(self.failed.clone());
            self.fenced = true;
            self.force("mvcc.status_force")?;
            let previous = self.frozen;
            self.frozen = super::freeze_file::write(
                &self.directory,
                self.frozen,
                before,
                frontier,
                self.next_transaction,
            )?;
            self.invalidate_pages();
            self.fenced = false;
            failure.complete = true;
            // 0.2-K Part M: release the prefix that BOTH valid watermark
            // slots have frozen (the older slot's boundary): recovery falling
            // back to the previous slot still finds every record it reads.
            self.release_frozen_prefix(previous.before.min(self.frozen.before))?;
        }
        Ok(self.frozen.before)
    }

    /// 0.2-K Part M: test knob for the release threshold (records).
    pub fn set_trim_threshold(&mut self, records: u64) {
        self.trim_threshold = records.max(1);
    }
    /// 0.2-K Part M: records below this identity were physically released.
    #[must_use]
    pub fn trimmed_below(&self) -> u64 {
        self.trimmed_below
    }

    /// 0.2-K Part M: physical trimming of the frozen prefix without any
    /// format change. The status file is fixed-address (record `id` lives at
    /// `HEADER + (id - 1) * RECORD`), so the prefix cannot be cut off; it is
    /// released instead by rewriting the file sparse: a temporary file gets
    /// the identical header and every record at or above `below` at its
    /// original offset (the never-written prefix is a hole on file systems
    /// with sparse files), is forced, and atomically replaces the live file;
    /// the directory is synced. A crash before the rename leaves the old
    /// file (the temporary copy is removed by recovery); after it, the new
    /// file holds every byte any reader can still read: records below the
    /// frozen boundary are never read (`read_status` refuses them, recovery
    /// validates from the boundary and skips frozen WAL commits).
    ///
    /// Unix only: elsewhere a never-written region is zero-filled, so the
    /// rewrite would cost I/O and release nothing (see
    /// `docs/storage_lifecycle_0_2_k.md`).
    fn release_frozen_prefix(&mut self, below: u64) -> Result<()> {
        if !cfg!(unix) || below <= self.trimmed_below {
            return Ok(());
        }
        if below - self.trimmed_below < self.trim_threshold {
            return Ok(());
        }
        let _span = phobos_observability::span("mvcc.status_prefix_release");
        let length = self.file.metadata()?.len();
        let start = HEADER
            .checked_add((below - 1).saturating_mul(RECORD))
            .ok_or_else(|| invalid("MVCC status offset overflow"))?
            .min(length);
        let temporary = self.directory.join(COMPACT_NAME);
        // Building the copy never touches the live file: a failure here
        // (e.g. no space for the copy) only skips this release.
        let built = (|| -> Result<()> {
            match fs::remove_file(&temporary) {
                Ok(()) => {}
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error.into()),
            }
            let mut output = OpenOptions::new()
                .read(true)
                .write(true)
                .create_new(true)
                .open(&temporary)?;
            let mut header = [0; HEADER as usize];
            self.file.seek(SeekFrom::Start(0))?;
            self.file.read_exact(&mut header)?;
            output.write_all(&header)?;
            output.set_len(length)?;
            let mut buffer = vec![0u8; 1 << 16];
            let mut offset = start;
            output.seek(SeekFrom::Start(offset))?;
            self.file.seek(SeekFrom::Start(offset))?;
            while offset < length {
                let chunk = usize::try_from((length - offset).min(buffer.len() as u64))
                    .map_err(|_| invalid("status chunk"))?;
                self.file.read_exact(&mut buffer[..chunk])?;
                output.write_all(&buffer[..chunk])?;
                offset += chunk as u64;
            }
            phobos_observability::synchronization_boundary(
                "k_status_release_before_sync",
                &self.directory,
            );
            output.sync_all()?;
            Ok(())
        })();
        if built.is_err() {
            let _ = fs::remove_file(&temporary);
            phobos_observability::event("mvcc.status_prefix_release_skipped", 1);
            return Ok(());
        }
        phobos_observability::synchronization_boundary(
            "k_status_release_before_rename",
            &self.directory,
        );
        // From the rename on, a failure leaves this handle on the replaced
        // inode: fence (recovery reopens the authoritative file).
        let mut failure = Failure::new(self.failed.clone());
        self.fenced = true;
        fs::rename(&temporary, self.directory.join(NAME))?;
        #[cfg(unix)]
        File::open(&self.directory)?.sync_all()?;
        self.file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(self.directory.join(NAME))?;
        self.invalidate_pages();
        self.trimmed_below = below;
        phobos_observability::event("mvcc.status_prefix_released", below - 1);
        self.fenced = false;
        failure.complete = true;
        Ok(())
    }

    #[must_use]
    pub fn capacity(&self) -> u64 {
        self.capacity
    }

    #[must_use]
    pub fn uses_stable_identity(&self) -> bool {
        self.stable
    }

    pub(super) fn matches_directory(&self, directory: &Path) -> bool {
        self.directory == directory
    }

    pub(super) fn ensure_available(&self) -> Result<()> {
        if self.fenced {
            return Err(invalid("MVCC status store requires recovery"));
        }
        Ok(())
    }

    fn offset(&self, id: u64) -> Result<u64> {
        if id == 0 {
            return Err(invalid("zero status transaction"));
        }
        if id > self.capacity {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC status record is outside the granted capacity",
            ));
        }
        // id <= capacity <= MAX_CAPACITY, so this cannot overflow.
        (id - 1)
            .checked_mul(RECORD)
            .and_then(|bytes| bytes.checked_add(HEADER))
            .ok_or_else(|| invalid("MVCC status offset overflow"))
    }

    fn write_status(&mut self, id: u64, status: Status) -> Result<()> {
        let _span = phobos_observability::span("mvcc.status_write");
        let offset = self.offset(id)?;
        let (tag, sequence) = match status {
            Status::Committed { sequence } if sequence != 0 => (1, sequence),
            Status::Aborted => (2, 0),
            Status::InProgress if self.stable => (3, 0),
            _ => return Err(invalid("invalid final status")),
        };
        let mut record = [0; RECORD as usize];
        record[..8].copy_from_slice(&id.to_le_bytes());
        record[8..16].copy_from_slice(&sequence.to_le_bytes());
        record[16] = tag;
        seal(&mut record);
        self.file.seek(SeekFrom::Start(offset))?;
        let written = self.file.write_all(&record);
        self.record_writes += 1;
        // Update rule: a page cached for this window takes the record as
        // written (the file has zero bytes between its old end and the
        // record, exactly like the zero-initialised window); a failed write
        // drops the window so nothing torn can be served.
        let index = offset / STATUS_PAGE;
        let slot = (index % STATUS_PAGE_SLOTS as u64) as usize;
        match &mut self.pages[slot] {
            Some(page) if page.index == index => {
                if written.is_ok() {
                    let at = (offset % STATUS_PAGE) as usize;
                    page.bytes[at..at + RECORD as usize].copy_from_slice(&record);
                    page.valid = page.valid.max(at + RECORD as usize);
                } else {
                    self.pages[slot] = None;
                }
            }
            _ => {}
        }
        written?;
        Ok(())
    }

    /// The 4 KiB window holding `offset`, from the cache or one file read.
    fn status_page(&mut self, offset: u64) -> Result<&StatusPage> {
        let index = offset / STATUS_PAGE;
        let slot = (index % STATUS_PAGE_SLOTS as u64) as usize;
        if !matches!(&self.pages[slot], Some(page) if page.index == index) {
            let _span = phobos_observability::span("mvcc.status_page_read");
            let mut bytes = Box::new([0u8; STATUS_PAGE as usize]);
            self.file.seek(SeekFrom::Start(index * STATUS_PAGE))?;
            let mut valid = 0;
            while valid < bytes.len() {
                let read = self.file.read(&mut bytes[valid..])?;
                if read == 0 {
                    break;
                }
                valid += read;
            }
            self.page_reads += 1;
            self.pages[slot] = Some(StatusPage {
                index,
                valid,
                bytes,
            });
        }
        Ok(self.pages[slot].as_ref().expect("cached status page"))
    }

    pub(super) fn read_status(&mut self, id: u64) -> Result<Option<Status>> {
        if id < self.frozen.before {
            return Err(invalid(
                "status history was frozen after proving no tuple references",
            ));
        }
        let _span = phobos_observability::span("mvcc.status_lookup");
        let offset = self.offset(id)?;
        let page = self.status_page(offset)?;
        let at = (offset % STATUS_PAGE) as usize;
        if at + RECORD as usize > page.valid {
            return Ok(None);
        }
        let record: [u8; RECORD as usize] = page.bytes[at..at + RECORD as usize]
            .try_into()
            .expect("record window");
        if record == [0; RECORD as usize] {
            return Ok(None);
        }
        if !valid(&record) || number(&record[..8]) != id || record[17..28] != [0; 11] {
            return Err(invalid("corrupt MVCC status record"));
        }
        match (record[16], number(&record[8..16])) {
            (1, sequence) if sequence != 0 => Ok(Some(Status::Committed { sequence })),
            (2, 0) => Ok(Some(Status::Aborted)),
            (3, 0) if self.stable => Ok(Some(Status::InProgress)),
            _ => Err(invalid("corrupt final transaction status")),
        }
    }
}

impl StatusLookup for StatusFile {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.ensure_available()?;
        if transaction >= self.next_transaction {
            return Err(invalid(
                "unresolved live/future transaction requires active registry",
            ));
        }
        self.read_status(transaction)?
            .ok_or_else(|| invalid("missing durable transaction status"))
    }
}

fn number(bytes: &[u8]) -> u64 {
    u64::from_le_bytes(bytes.try_into().expect("eight bytes"))
}
fn seal(bytes: &mut [u8; 32]) {
    let checksum = crate::checksum(&bytes[..28]);
    bytes[28..].copy_from_slice(&checksum.to_le_bytes());
}
fn valid(bytes: &[u8; 32]) -> bool {
    crate::checksum(&bytes[..28]) == u32::from_le_bytes(bytes[28..].try_into().expect("four bytes"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn c6_status_write_failure_is_visible_without_the_io_mutex() {
        let root = std::env::temp_dir().join(format!(
            "phobos-c6-status-failure-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let wal = phobos_wal::v2::Wal::create_with_versioned_heap(&root).unwrap();
        let mut statuses = StatusFile::create(&root, 16).unwrap();
        let failure = statuses.failure_flag();
        // A real OS write error, after the persistence operation is armed.
        statuses.file = File::open(root.join(NAME)).unwrap();
        assert!(statuses.reserve(1).is_err());
        assert!(failure.load(Ordering::Acquire));
        assert!(statuses.ensure_available().is_err());
        assert!(statuses.reserve(1).is_err());
        drop(statuses);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }
}
