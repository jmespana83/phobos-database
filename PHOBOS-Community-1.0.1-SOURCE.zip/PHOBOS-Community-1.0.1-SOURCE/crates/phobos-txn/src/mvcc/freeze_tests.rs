use super::*;
use phobos_wal::v2::Wal;
use std::{fs, path::PathBuf, sync::Arc};
fn directory() -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    std::env::temp_dir().join(format!(
        "phobos-c4-{}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos(),
        NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
    ))
}
#[test]
fn c4_prefix_reopen_cache_growth_and_bounded_startup() {
    let dir = directory();
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let mut statuses = StatusFile::create(&dir, 4).unwrap();
    statuses.set_growth_extent(4).unwrap();
    let mut registry = TransactionRegistry::new(statuses, 8).unwrap();
    for id in 1..=64 {
        assert_eq!(registry.allocate().unwrap(), id);
        if id % 2 == 0 {
            registry.abort(id).unwrap();
        } else {
            wal.begin_mvcc(id).unwrap();
            registry.commit(&wal.commit().unwrap()).unwrap();
        }
    }
    drop(registry);
    let statuses = StatusFile::recover(&dir).unwrap();
    assert_eq!(statuses.frozen_before(), 1);
    assert_eq!(statuses.startup_ids_examined(), 64);
    let manager = sessions::SessionManager::new(statuses, 8, 8, 8).unwrap();
    assert!(matches!(
        manager.lookup(1).unwrap(),
        Status::Committed { .. }
    ));
    assert_eq!(manager.lookup(2).unwrap(), Status::Aborted);
    assert!(manager.cache().contains(1));
    assert!(manager.cache().contains(2));
    // Empty database: no tuple references any of these status-only transactions.
    assert_eq!(
        manager
            .freeze_if_idle(4096, |next, _| Ok(Some(next - 1)))
            .unwrap(),
        Some((1, 64))
    );
    assert!(!manager.cache().contains(1));
    assert!(!manager.cache().contains(2));
    let reads = manager.status_metrics().status_page_reads;
    assert!(manager.lookup(1).is_err());
    assert!(manager.lookup(2).is_err());
    assert_eq!(manager.status_metrics().status_page_reads, reads);
    assert_eq!(manager.lookup(64).unwrap(), Status::Aborted);
    drop(manager);
    drop(wal);
    let (mut statuses, mut wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.frozen_before(), 64);
    assert_eq!(statuses.startup_ids_examined(), 1);
    eprintln!(
        "C4 startup status IDs: 64 -> {}; frozen boundary {}",
        statuses.startup_ids_examined(),
        statuses.frozen_before()
    );
    statuses.set_growth_extent(4).unwrap();
    let old_capacity = statuses.capacity();
    let mut registry = TransactionRegistry::new(statuses, 8).unwrap();
    assert_eq!(registry.allocate().unwrap(), 65);
    assert!(registry.statuses.capacity() > old_capacity);
    wal.begin_mvcc(65).unwrap();
    let receipt = wal.commit().unwrap();
    registry.commit(&receipt).unwrap();
    assert_eq!(
        registry.status(65).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    drop(registry);
    drop(wal);
    let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(statuses.next_transaction, 66);
    assert_eq!(statuses.startup_ids_examined(), 2);
    drop(statuses);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn c4_inprogress_pins_and_horizon_prevent_advancement() {
    let dir = directory();
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let mut statuses = StatusFile::create(&dir, 4).unwrap();
    statuses.reserve(1).unwrap();
    assert_eq!(statuses.freeze_unreferenced(2, u64::MAX, 4).unwrap(), 1);
    statuses.abort(1).unwrap();
    statuses.reserve(2).unwrap();
    wal.begin_mvcc(2).unwrap();
    let receipt = wal.commit().unwrap();
    statuses.install(&receipt).unwrap();
    assert_eq!(
        statuses
            .freeze_unreferenced(3, receipt.lsn() - 1, 4)
            .unwrap(),
        2
    );
    let manager = sessions::SessionManager::new(statuses, 8, 8, 8).unwrap();
    let session = manager.connect(1).unwrap();
    let pin = session.statement().unwrap();
    assert!(
        manager
            .freeze_if_idle(4, |_, _| panic!("pinned proof must not run"))
            .unwrap()
            .is_none()
    );
    drop(pin);
    let stable = session.begin().unwrap();
    assert_eq!(stable, 3);
    assert!(
        manager
            .freeze_if_idle(4, |_, _| panic!("active proof must not run"))
            .unwrap()
            .is_none()
    );
    session.rollback().unwrap();
    assert_eq!(
        manager.freeze_if_idle(4, |next, _| Ok(Some(next))).unwrap(),
        Some((2, 4))
    );
    drop(session);
    drop(manager);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn c4_crash_slots_recover_old_or_new_watermark() {
    const TEST: &str = "mvcc::freeze_tests::c4_crash_slots_recover_old_or_new_watermark";
    if let Ok(point) = std::env::var("PHOBOS_C4_CRASH_POINT") {
        let dir = PathBuf::from(std::env::var_os("PHOBOS_C4_CRASH_ROOT").unwrap());
        let (mut statuses, _wal) = StatusFile::recover_database(&dir).unwrap();
        let _hook = phobos_observability::test_hooks::register(
            &dir,
            Arc::new(move |observed| {
                if observed == point {
                    std::process::exit(86);
                }
            }),
        );
        statuses.freeze_unreferenced(5, u64::MAX, 4).unwrap();
        panic!("crash hook not reached");
    }
    for point in [
        "c4_freeze_before_write",
        "c4_freeze_after_write",
        "c4_freeze_after_sync",
    ] {
        let dir = directory();
        let wal = Wal::create_with_mvcc(&dir).unwrap();
        let mut statuses = StatusFile::create(&dir, 4).unwrap();
        for id in 1..=4 {
            statuses.reserve(id).unwrap();
            statuses.abort(id).unwrap();
        }
        statuses.freeze_unreferenced(3, 0, 4).unwrap();
        drop(statuses);
        drop(wal);
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env("PHOBOS_C4_CRASH_POINT", point)
            .env("PHOBOS_C4_CRASH_ROOT", &dir)
            .output()
            .unwrap();
        assert_eq!(
            output.status.code(),
            Some(86),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        for _ in 0..2 {
            let (statuses, wal) = StatusFile::recover_database(&dir).unwrap();
            assert!([3, 5].contains(&statuses.frozen_before()));
            assert_eq!(statuses.next_transaction, 5);
            if point == "c4_freeze_after_sync" {
                assert_eq!(statuses.frozen_before(), 5);
            }
            drop(statuses);
            drop(wal);
        }
        // A torn newest slot must retain the older valid boundary.
        let path = dir.join(freeze_file::NAME);
        let mut bytes = fs::read(&path).unwrap();
        bytes[..32].fill(0xff);
        fs::write(path, bytes).unwrap();
        assert_eq!(freeze_file::read(&dir).unwrap().before, 3);
        fs::remove_dir_all(dir).unwrap();
    }
}
