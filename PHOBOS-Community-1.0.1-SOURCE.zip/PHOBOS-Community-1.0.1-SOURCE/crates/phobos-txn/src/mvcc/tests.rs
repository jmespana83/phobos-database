use super::*;
use phobos_wal::v2::Wal;
use std::{
    fs,
    path::PathBuf,
    time::{SystemTime, UNIX_EPOCH},
};

struct States(BTreeMap<u64, Status>);
impl StatusLookup for States {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.0
            .get(&transaction)
            .copied()
            .ok_or_else(|| invalid("unknown transaction"))
    }
}

#[test]
fn stable_identity_reverse_commit_order_group_force_and_abort_after_commit() {
    let dir = directory();
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let store = StatusFile::create(&dir, 128).unwrap();
    let mut registry = TransactionRegistry::new(store, 4).unwrap();
    let a = registry.allocate().unwrap();
    let b = registry.allocate().unwrap();
    assert_eq!((a, b), (1, 2));
    assert_eq!(wal.begin_mvcc(b).unwrap(), 1);
    let b_ticket = wal.append_commit().unwrap();
    assert_eq!(wal.begin_mvcc(a).unwrap(), 2);
    let a_ticket = wal.append_commit().unwrap();
    assert_eq!(registry.status(a).unwrap(), Status::InProgress);
    assert_eq!(registry.status(b).unwrap(), Status::InProgress);
    let receipts = wal.force_commits(&[b_ticket, a_ticket]).unwrap();
    assert!(wal.checkpoint_all(receipts[1].lsn()).is_err());
    assert!(registry.checkpoint(&mut wal).is_err());
    assert_eq!(receipts[0].mvcc_id(), Some(b));
    assert_eq!(receipts[1].mvcc_id(), Some(a));
    for receipt in &receipts {
        registry.commit(receipt).unwrap();
    }
    let c = registry.allocate().unwrap();
    let d = registry.allocate().unwrap();
    wal.begin_mvcc(d).unwrap();
    let d_receipt = wal.commit().unwrap();
    registry.commit(&d_receipt).unwrap();
    registry.abort(c).unwrap();
    registry.checkpoint(&mut wal).unwrap();
    drop(registry);
    drop(wal);
    for _ in 0..2 {
        let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
        assert_eq!(
            statuses.status(a).unwrap(),
            Status::Committed {
                sequence: receipts[1].lsn()
            }
        );
        assert_eq!(
            statuses.status(b).unwrap(),
            Status::Committed {
                sequence: receipts[0].lsn()
            }
        );
        assert_eq!(statuses.status(c).unwrap(), Status::Aborted);
        assert_eq!(
            statuses.status(d).unwrap(),
            Status::Committed {
                sequence: d_receipt.lsn()
            }
        );
        drop(wal);
        let mut registry = TransactionRegistry::new(statuses, 4).unwrap();
        assert!(registry.allocate().unwrap() > d);
    }
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn mvcc_mapping_requires_capability_and_first_chain_position() {
    use phobos_wal::v2::Body;
    let legacy_dir = directory();
    let mut legacy = Wal::create_with_page_lsn(&legacy_dir).unwrap();
    assert!(legacy.begin_mvcc(9).is_err());
    legacy.begin().unwrap();
    assert!(legacy.append(Body::MvccIdentity(9)).is_err());
    legacy.abort().unwrap();
    drop(legacy);
    fs::remove_dir_all(legacy_dir).unwrap();
    let dir = directory();
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    wal.begin().unwrap();
    assert!(wal.append_commit().is_err());
    wal.abort().unwrap();
    wal.begin_mvcc(9).unwrap();
    assert!(wal.append(Body::MvccIdentity(10)).is_err());
    wal.abort().unwrap();
    drop(wal);
    assert_eq!(
        phobos_wal::v2::inspect(dir.join("phobos.wal"))
            .unwrap()
            .page_format,
        3
    );
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn stable_reservation_never_reuses_truncated_identity_and_retained_wal_repairs_status() {
    use std::io::{Seek, SeekFrom, Write};
    let dir = directory();
    let mut wal = Wal::create_with_mvcc(&dir).unwrap();
    let mut registry = TransactionRegistry::new(StatusFile::create(&dir, 128).unwrap(), 4).unwrap();
    let id = registry.allocate().unwrap();
    wal.begin_mvcc(id).unwrap();
    let receipt = wal.commit().unwrap();
    registry.commit(&receipt).unwrap();
    drop(registry);
    drop(wal);
    let path = dir.join("phobos.mvcc-status");
    let mut file = fs::OpenOptions::new().write(true).open(&path).unwrap();
    file.seek(SeekFrom::Start(32)).unwrap();
    file.write_all(&[0xff; 8]).unwrap();
    drop(file);
    let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
    assert_eq!(
        statuses.status(id).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    drop(statuses);
    drop(wal);
    fs::OpenOptions::new()
        .write(true)
        .open(&path)
        .unwrap()
        .set_len(32)
        .unwrap();
    assert!(StatusFile::recover_database(&dir).is_err());
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn stable_identity_crash_recovery_twenty_cycles() {
    use std::{
        io::Write,
        process::{Command, exit},
    };
    const MODE: &str = "PHOBOS_C5_IDENTITY_CRASH";
    const ROOT: &str = "PHOBOS_C5_IDENTITY_DIRECTORY";
    if let Ok(mode) = std::env::var(MODE) {
        let dir = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let mut wal = Wal::create_with_mvcc(&dir).unwrap();
        let mut registry =
            TransactionRegistry::new(StatusFile::create(&dir, 128).unwrap(), 4).unwrap();
        let a = registry.allocate().unwrap();
        let b = registry.allocate().unwrap();
        wal.begin_mvcc(b).unwrap();
        let b_receipt = wal.commit().unwrap();
        let mut a_sequence = 0;
        if mode != "wal_only" {
            registry.commit(&b_receipt).unwrap();
        }
        if mode == "before_retirement" || mode == "after_retirement" {
            wal.begin_mvcc(a).unwrap();
            let a_receipt = wal.commit().unwrap();
            registry.commit(&a_receipt).unwrap();
            a_sequence = a_receipt.lsn();
            if mode == "after_retirement" {
                registry.checkpoint(&mut wal).unwrap();
            }
        }
        let mut marker = fs::File::create(dir.join("identity.marker")).unwrap();
        write!(marker, "{a_sequence} {}", b_receipt.lsn()).unwrap();
        marker.sync_all().unwrap();
        exit(87);
    }
    for mode in [
        "wal_only",
        "status_persisted",
        "before_retirement",
        "after_retirement",
    ] {
        for round in 0..5 {
            let dir = directory();
            let child = Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "mvcc::tests::stable_identity_crash_recovery_twenty_cycles",
                    "--nocapture",
                ])
                .env(MODE, mode)
                .env(ROOT, &dir)
                .output()
                .unwrap();
            assert_eq!(
                child.status.code(),
                Some(87),
                "{mode}/{round}: {}",
                String::from_utf8_lossy(&child.stderr)
            );
            let marker = fs::read_to_string(dir.join("identity.marker")).unwrap();
            let sequences: Vec<u64> = marker
                .split_whitespace()
                .map(|value| value.parse().unwrap())
                .collect();
            let expected_a = if sequences[0] == 0 {
                Status::Aborted
            } else {
                Status::Committed {
                    sequence: sequences[0],
                }
            };
            let before = fs::read(dir.join("phobos.wal")).unwrap();
            assert!(Wal::recover(&dir).is_err());
            assert_eq!(fs::read(dir.join("phobos.wal")).unwrap(), before);
            for _ in 0..2 {
                let (mut statuses, wal) = StatusFile::recover_database(&dir).unwrap();
                assert_eq!(statuses.status(1).unwrap(), expected_a, "{mode}/{round}");
                assert_eq!(
                    statuses.status(2).unwrap(),
                    Status::Committed {
                        sequence: sequences[1]
                    }
                );
                drop(wal);
            }
            fs::remove_dir_all(dir).unwrap();
        }
    }
}

fn directory() -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let sequence = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    std::env::temp_dir().join(format!(
        "phobos-mvcc-status-{}-{}-{sequence}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}

#[test]
fn active_status_registry_bounds_memory_and_reserves_disk_before_mutation() {
    let dir = directory();
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let store = StatusFile::create(&dir, 2).unwrap();
    let mut registry = TransactionRegistry::new(store, 1).unwrap();
    let id = wal.begin().unwrap();
    registry.begin(id).unwrap();
    assert_eq!(registry.status(id).unwrap(), Status::InProgress);
    assert_eq!(
        registry.begin(2).unwrap_err().code,
        ErrorCode::ResourceLimit
    );
    wal.abort().unwrap();
    registry.abort(id).unwrap();
    assert_eq!(registry.status(id).unwrap(), Status::Aborted);
    assert!(registry.begin(id).is_err());
    let id = wal.begin().unwrap();
    registry.begin(id).unwrap();
    let receipt = wal.commit().unwrap();
    registry.commit(&receipt).unwrap();
    assert_eq!(
        registry.status(id).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    assert!(registry.abort(id).is_err());
    // A3: the initial capacity (2) is a starting grant, not a ceiling. The
    // third identity extends the grant instead of returning ResourceLimit.
    registry.begin(3).unwrap();
    assert_eq!(registry.status(3).unwrap(), Status::InProgress);
    // This legacy (non-stable) store writes its first record for an identity
    // at its final status, which is where the grant extends.
    registry.abort(3).unwrap();
    assert_eq!(registry.status(3).unwrap(), Status::Aborted);
    assert!(registry.statuses.capacity() >= 3);
    drop(registry);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn status_crash_reconciliation() {
    use std::{
        io::Write,
        process::{Command, exit},
    };
    const MODE: &str = "PHOBOS_C5_STATUS_COMPONENT_CRASH";
    const ROOT: &str = "PHOBOS_C5_STATUS_COMPONENT_DIRECTORY";
    if let Ok(mode) = std::env::var(MODE) {
        let dir = PathBuf::from(std::env::var_os(ROOT).unwrap());
        let mut statuses = StatusFile::recover(&dir).unwrap();
        let mut wal = Wal::open(&dir).unwrap();
        let id = wal.begin().unwrap();
        let sequence = if mode == "unfinished" {
            // 0.2-E Mode E: the open BEGIN reaches the WAL file only with a
            // force (Mode A wrote it to the OS cache at once).
            wal.sync_for_test().unwrap();
            0
        } else {
            let receipt = wal.commit().unwrap();
            if mode != "wal_only" {
                statuses.install(&receipt).unwrap();
            }
            if mode == "checkpointed" {
                wal.checkpoint_all(receipt.lsn()).unwrap();
            }
            receipt.lsn()
        };
        let mut marker = fs::File::create(dir.join("component-crash.marker")).unwrap();
        write!(marker, "{id} {sequence}").unwrap();
        marker.sync_all().unwrap();
        exit(87); // Deliberately bypass every Rust destructor.
    }
    let rounds = std::env::var("PHOBOS_C5_STATUS_CRASH_ROUNDS").map_or(5, |value| {
        value.parse::<usize>().expect("crash rounds integer")
    });
    assert!((1..=12).contains(&rounds));
    for mode in ["wal_only", "status_installed", "checkpointed", "unfinished"] {
        for cycle in 0..rounds {
            let dir = directory();
            let seed_sequence = {
                let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
                let mut statuses = StatusFile::create(&dir, 128).unwrap();
                wal.begin().unwrap();
                let receipt = wal.commit().unwrap();
                statuses.install(&receipt).unwrap();
                wal.checkpoint_all(receipt.lsn()).unwrap();
                receipt.lsn()
            };
            let child = Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "mvcc::tests::status_crash_reconciliation",
                    "--nocapture",
                ])
                .env(MODE, mode)
                .env(ROOT, &dir)
                .output()
                .unwrap();
            assert_eq!(
                child.status.code(),
                Some(87),
                "{mode}/{cycle}: {}",
                String::from_utf8_lossy(&child.stderr)
            );
            let marker = fs::read_to_string(dir.join("component-crash.marker")).unwrap();
            let fields: Vec<u64> = marker
                .split_whitespace()
                .map(|part| part.parse().unwrap())
                .collect();
            assert_eq!(fields[0], 2);
            let expected = if fields[1] == 0 {
                Status::Aborted
            } else {
                Status::Committed {
                    sequence: fields[1],
                }
            };
            for _ in 0..2 {
                // Required integration order: status reconciliation before WAL
                // recovery is permitted to retire COMMIT history.
                let mut statuses = StatusFile::recover(&dir).unwrap();
                let wal = Wal::recover(&dir).unwrap();
                assert_eq!(
                    statuses.status(1).unwrap(),
                    Status::Committed {
                        sequence: seed_sequence
                    }
                );
                assert_eq!(statuses.status(2).unwrap(), expected, "{mode}/{cycle}");
                drop(wal);
                drop(statuses);
            }
            fs::remove_dir_all(dir).unwrap();
        }
    }
}

#[test]
fn statement_refresh_own_writes_aborts_and_old_snapshot() {
    let mut registry = SnapshotRegistry::new(10, 4).unwrap();
    let old = registry.pin(None).unwrap();
    let own = registry.pin(Some(2)).unwrap();
    let mut states = States(BTreeMap::from([
        (1, Status::Committed { sequence: 10 }),
        (2, Status::InProgress),
        (3, Status::Aborted),
    ]));
    let inserted = Version {
        creator: 2,
        deleter: None,
    };
    let deleted = Version {
        creator: 1,
        deleter: Some(2),
    };
    assert!(!old.snapshot().visible(inserted, &mut states).unwrap());
    assert!(own.snapshot().visible(inserted, &mut states).unwrap());
    assert!(old.snapshot().visible(deleted, &mut states).unwrap());
    assert!(!own.snapshot().visible(deleted, &mut states).unwrap());
    states.0.insert(2, Status::Committed { sequence: 11 });
    registry.advance_publication(11).unwrap();
    let fresh = registry.pin(None).unwrap();
    assert!(fresh.snapshot().visible(inserted, &mut states).unwrap());
    assert!(!fresh.snapshot().visible(deleted, &mut states).unwrap());
    assert!(!old.snapshot().visible(inserted, &mut states).unwrap());
    assert!(old.snapshot().visible(deleted, &mut states).unwrap());
    assert!(!registry.may_reclaim(deleted, &mut states).unwrap());
    registry.release(old).unwrap();
    registry.release(own).unwrap();
    assert!(registry.may_reclaim(deleted, &mut states).unwrap());
    assert!(
        !fresh
            .snapshot()
            .visible(
                Version {
                    creator: 3,
                    deleter: None
                },
                &mut states
            )
            .unwrap()
    );
    assert!(
        fresh
            .snapshot()
            .visible(
                Version {
                    creator: 1,
                    deleter: Some(3)
                },
                &mut states
            )
            .unwrap()
    );
    assert!(
        registry
            .may_reclaim(
                Version {
                    creator: 3,
                    deleter: None
                },
                &mut states
            )
            .unwrap()
    );
    registry.release(fresh).unwrap();
}

#[test]
fn snapshot_backpressure_foreign_pin_unknown_status_and_failed_own_context() {
    let mut registry = SnapshotRegistry::new(1, 1).unwrap();
    let pin = registry.pin(Some(7)).unwrap();
    assert_eq!(
        registry.pin(None).unwrap_err().code,
        ErrorCode::ResourceLimit
    );
    let mut other = SnapshotRegistry::new(1, 1).unwrap();
    let foreign = other.pin(Some(7)).unwrap();
    assert!(registry.release(foreign).is_err());
    assert_eq!(
        registry.pin(None).unwrap_err().code,
        ErrorCode::ResourceLimit
    );
    let mut states = States(BTreeMap::from([(7, Status::Aborted)]));
    assert!(
        !pin.snapshot()
            .visible(
                Version {
                    creator: 7,
                    deleter: None
                },
                &mut states
            )
            .unwrap()
    );
    assert!(
        pin.snapshot()
            .visible(
                Version {
                    creator: 8,
                    deleter: None
                },
                &mut states
            )
            .is_err()
    );
    assert!(registry.advance_publication(1).is_err());
    registry.release(pin).unwrap();
    assert!(registry.pin(None).is_ok());
}

#[test]
fn raii_statement_pins_release_on_unwind_and_leaks_remain_conservative() {
    let mut registry = SnapshotRegistry::new(10, 1).unwrap();
    let pin = registry.pin(None).unwrap();
    let mut other_thread = registry.clone();
    std::thread::spawn(move || {
        other_thread.advance_publication(20).unwrap();
        assert_eq!(
            other_thread.pin(None).unwrap_err().code,
            ErrorCode::ResourceLimit
        );
    })
    .join()
    .unwrap();
    assert_eq!(registry.reclamation_horizon(), 10);
    drop(pin);
    assert_eq!(registry.reclamation_horizon(), 20);
    let mut shared = registry.clone();
    let unwind = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let _statement = shared.pin(None).unwrap();
        panic!("simulate failed streaming sink");
    }));
    assert!(unwind.is_err());
    let leaked = registry.pin(None).unwrap();
    std::mem::forget(leaked);
    registry.advance_publication(30).unwrap();
    assert_eq!(registry.reclamation_horizon(), 20);
    assert_eq!(
        registry.pin(None).unwrap_err().code,
        ErrorCode::ResourceLimit
    );
}

#[test]
fn durable_status_survives_full_wal_retirement_and_aborts_recover() {
    let dir = directory();
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let mut statuses = StatusFile::create(&dir, 128).unwrap();
    let aborted = wal.begin().unwrap();
    wal.abort().unwrap();
    statuses.abort(aborted).unwrap();
    let committed = wal.begin().unwrap();
    let receipt = wal.commit().unwrap();
    statuses.install(&receipt).unwrap();
    assert_eq!(
        statuses.status(committed).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    wal.checkpoint_all(receipt.lsn()).unwrap();
    drop(statuses);
    drop(wal);
    let mut statuses = StatusFile::recover(&dir).unwrap();
    assert_eq!(statuses.status(aborted).unwrap(), Status::Aborted);
    assert_eq!(
        statuses.status(committed).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    assert!(statuses.status(committed + 1).is_err());
    drop(statuses);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn recovery_restores_commit_missing_status_and_repairs_torn_status() {
    use std::io::{Seek, SeekFrom, Write};
    let dir = directory();
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let statuses = StatusFile::create(&dir, 128).unwrap();
    let id = wal.begin().unwrap();
    let receipt = wal.commit().unwrap();
    drop(statuses);
    drop(wal);
    for _ in 0..2 {
        let mut statuses = StatusFile::recover(&dir).unwrap();
        assert_eq!(
            statuses.status(id).unwrap(),
            Status::Committed {
                sequence: receipt.lsn()
            }
        );
    }
    let mut file = fs::OpenOptions::new()
        .write(true)
        .open(dir.join("phobos.mvcc-status"))
        .unwrap();
    file.seek(SeekFrom::Start(32)).unwrap();
    file.write_all(&[0xff; 7]).unwrap();
    file.set_len(39).unwrap();
    drop(file);
    let mut statuses = StatusFile::recover(&dir).unwrap();
    assert_eq!(
        statuses.status(id).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    drop(statuses);
    fs::remove_dir_all(dir).unwrap();
}

#[test]
fn corrupt_retired_status_fails_closed_and_foreign_receipt_cannot_publish() {
    use std::io::{Seek, SeekFrom, Write};
    let dir = directory();
    let foreign = directory();
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let mut statuses = StatusFile::create(&dir, 1).unwrap();
    let mut other = Wal::create_with_page_lsn(&foreign).unwrap();
    other.begin().unwrap();
    assert!(statuses.install(&other.commit().unwrap()).is_err());
    wal.begin().unwrap();
    let receipt = wal.commit().unwrap();
    statuses.install(&receipt).unwrap();
    assert!(statuses.install(&receipt).is_err());
    wal.checkpoint_all(receipt.lsn()).unwrap();
    drop(statuses);
    drop(wal);
    drop(other);
    let mut file = fs::OpenOptions::new()
        .write(true)
        .open(dir.join("phobos.mvcc-status"))
        .unwrap();
    file.seek(SeekFrom::Start(32)).unwrap();
    file.write_all(&[0xff]).unwrap();
    drop(file);
    assert!(StatusFile::recover(&dir).is_err());
    fs::remove_dir_all(dir).unwrap();
    fs::remove_dir_all(foreign).unwrap();
}

#[test]
fn missing_retired_status_is_never_inferred_to_be_aborted() {
    let dir = directory();
    let mut wal = Wal::create_with_page_lsn(&dir).unwrap();
    let mut statuses = StatusFile::create(&dir, 128).unwrap();
    let id = wal.begin().unwrap();
    let receipt = wal.commit().unwrap();
    statuses.install(&receipt).unwrap();
    wal.checkpoint_all(receipt.lsn()).unwrap();
    drop(statuses);
    drop(wal);
    fs::OpenOptions::new()
        .write(true)
        .open(dir.join("phobos.mvcc-status"))
        .unwrap()
        .set_len(32)
        .unwrap();
    let mut statuses = StatusFile::recover(&dir).unwrap();
    assert!(statuses.status(id).is_err());
    drop(statuses);
    fs::remove_dir_all(dir).unwrap();
}
