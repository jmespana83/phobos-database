//! 0.1.9-B1/B2: settled-visibility hints, the shared sharded final-status
//! cache and paged status-file reads.
use super::*;
use phobos_wal::v2::Wal;
use sessions::SessionManager;
use std::{fs, path::PathBuf};

/// Counting fake lookup with a configurable hint bound.
struct Counted {
    states: BTreeMap<u64, Status>,
    bound: Option<u64>,
    lookups: u64,
    hint_hits: u64,
}
impl StatusLookup for Counted {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.lookups += 1;
        self.states
            .get(&transaction)
            .copied()
            .ok_or_else(|| invalid("unknown transaction"))
    }
    fn hint_bound(&self) -> Option<u64> {
        self.bound
    }
    fn use_hint(&mut self) -> Result<()> {
        self.hint_hits += 1;
        Ok(())
    }
}
fn snapshot(sequence: u64, own: Option<u64>) -> Snapshot {
    Snapshot { sequence, own }
}
fn directory(tag: &str) -> PathBuf {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let root = std::env::temp_dir().join(format!(
        "phobos-b12-{tag}-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
    ));
    fs::create_dir_all(&root).unwrap();
    root
}
fn setup(tag: &str) -> (PathBuf, Wal, Arc<SessionManager>) {
    let root = directory(tag);
    let wal = Wal::create_with_versioned_heap(&root).unwrap();
    let manager = SessionManager::new(StatusFile::create(&root, 64).unwrap(), 16, 16, 16).unwrap();
    (root, wal, manager)
}
fn commit(wal: &mut Wal, manager: &Arc<SessionManager>, session: &sessions::Session) -> u64 {
    let stable = session.begin().unwrap();
    let permit = session.submit_commit().unwrap();
    wal.begin_mvcc(stable).unwrap();
    let receipt = wal.commit().unwrap();
    permit.publish(&receipt, || Ok(())).unwrap();
    let _ = manager;
    stable
}

/// Tests 1–4: a settled hint is learned from an ordinary lookup, answers the
/// next read without a lookup, and is never learned for InProgress, Aborted
/// or a commit above the bound; own-transaction and zero-ID rules unchanged.
#[test]
fn b1_hints_learned_only_for_settled_commits_and_never_change_results() {
    let mut statuses = Counted {
        states: BTreeMap::from([
            (1, Status::Committed { sequence: 10 }),
            (2, Status::Committed { sequence: 20 }),
            (3, Status::InProgress),
            (4, Status::Aborted),
            (5, Status::Committed { sequence: 40 }),
        ]),
        bound: Some(25),
        lookups: 0,
        hint_hits: 0,
    };
    let reader = snapshot(30, None);
    let created = Version {
        creator: 1,
        deleter: None,
    };
    // Test 1: first read resolves normally and learns the creator hint.
    let (visible, hints) = reader
        .visible_hinted(created, Hints::default(), &mut statuses)
        .unwrap();
    assert!(visible && hints.creator_committed() && !hints.deleter_committed());
    assert_eq!((statuses.lookups, statuses.hint_hits), (1, 0));
    // Test 2: the hint answers without the creator lookup.
    let (visible, again) = reader
        .visible_hinted(created, hints, &mut statuses)
        .unwrap();
    assert!(visible);
    assert_eq!(again, hints);
    assert_eq!((statuses.lookups, statuses.hint_hits), (1, 1));
    // Test 3: committed delete learns the deleter hint; dead for every snapshot.
    let deleted = Version {
        creator: 1,
        deleter: Some(2),
    };
    let (visible, hints) = reader
        .visible_hinted(deleted, hints, &mut statuses)
        .unwrap();
    assert!(!visible && hints.creator_committed() && hints.deleter_committed());
    assert_eq!((statuses.lookups, statuses.hint_hits), (2, 2));
    let (visible, _) = reader
        .visible_hinted(deleted, hints, &mut statuses)
        .unwrap();
    assert!(!visible);
    assert_eq!((statuses.lookups, statuses.hint_hits), (2, 3));
    // The hinted answers equal the unhinted ones for every snapshot that can
    // exist once a hint was learned (sequence >= bound).
    for sequence in [25, 30, 100] {
        let plain = snapshot(sequence, None);
        assert_eq!(
            plain.visible(created, &mut statuses).unwrap(),
            plain
                .visible_hinted(
                    created,
                    Hints::from_bits(Hints::CREATOR_COMMITTED),
                    &mut statuses
                )
                .unwrap()
                .0
        );
        assert_eq!(
            plain.visible(deleted, &mut statuses).unwrap(),
            plain
                .visible_hinted(deleted, Hints::from_bits(Hints::MASK), &mut statuses)
                .unwrap()
                .0
        );
    }
    // Test 4: InProgress (foreign and own), Aborted and above-bound commits
    // never produce a committed hint; own-transaction visibility unchanged.
    for (version, own, expected) in [
        (
            Version {
                creator: 3,
                deleter: None,
            },
            None,
            false,
        ),
        (
            Version {
                creator: 3,
                deleter: None,
            },
            Some(3),
            true,
        ),
        (
            Version {
                creator: 4,
                deleter: None,
            },
            None,
            false,
        ),
        (
            Version {
                creator: 5,
                deleter: None,
            },
            None,
            false,
        ),
        (
            Version {
                creator: 1,
                deleter: Some(3),
            },
            None,
            true,
        ),
        (
            Version {
                creator: 1,
                deleter: Some(3),
            },
            Some(3),
            false,
        ),
        (
            Version {
                creator: 1,
                deleter: Some(4),
            },
            None,
            true,
        ),
        (
            Version {
                creator: 1,
                deleter: Some(5),
            },
            None,
            true,
        ),
    ] {
        let reader = snapshot(30, own);
        let (visible, hints) = reader
            .visible_hinted(version, Hints::default(), &mut statuses)
            .unwrap();
        assert_eq!(visible, expected, "{version:?} own={own:?}");
        assert_eq!(
            visible,
            reader.visible(version, &mut statuses).unwrap(),
            "{version:?}"
        );
        assert!(!hints.deleter_committed(), "{version:?}");
        assert_eq!(
            hints.creator_committed(),
            version.creator == 1,
            "{version:?}"
        );
    }
    // No bound: nothing is ever learned.
    statuses.bound = None;
    let (_, hints) = reader
        .visible_hinted(created, Hints::default(), &mut statuses)
        .unwrap();
    assert_eq!(hints, Hints::default());
    // Zero IDs stay rejected even with hints present.
    assert!(
        reader
            .visible_hinted(
                Version {
                    creator: 0,
                    deleter: None
                },
                Hints::from_bits(Hints::MASK),
                &mut statuses
            )
            .is_err()
    );
    assert_eq!(Hints::from_bits(0xff).bits(), Hints::MASK);
}

/// Tests 6–7: the shared cache serves Committed/Aborted, never InProgress,
/// and a transaction that resolves later is not stale.
#[test]
fn b2_shared_cache_serves_final_statuses_and_never_retains_in_progress() {
    let (root, mut wal, manager) = setup("shared-cache");
    let writer = manager.connect(1).unwrap();
    let reader = manager.connect(2).unwrap();
    let active = writer.begin().unwrap();
    let mut statement = reader.statement().unwrap();
    let before = manager.status_metrics();
    assert_eq!(statement.status(active).unwrap(), Status::InProgress);
    assert_eq!(statement.status(active).unwrap(), Status::InProgress);
    assert!(!manager.cache().contains(active));
    let after = manager.status_metrics();
    assert_eq!(after.status_lookups - before.status_lookups, 2);
    assert_eq!(after.shared_cache_hits, before.shared_cache_hits);
    writer.rollback().unwrap();
    // The abort is observed on the very next lookup (nothing stale).
    assert_eq!(statement.status(active).unwrap(), Status::Aborted);
    assert!(manager.cache().contains(active));
    let hits = manager.status_metrics().shared_cache_hits;
    assert_eq!(statement.status(active).unwrap(), Status::Aborted);
    assert_eq!(manager.status_metrics().shared_cache_hits, hits + 1);
    // Commit path: InProgress while active, Committed after publication,
    // cached from the first post-commit resolution on.
    let stable = writer.begin().unwrap();
    assert_eq!(statement.status(stable).unwrap(), Status::InProgress);
    let permit = writer.submit_commit().unwrap();
    wal.begin_mvcc(stable).unwrap();
    let receipt = wal.commit().unwrap();
    assert!(!manager.cache().contains(stable));
    permit.publish(&receipt, || Ok(())).unwrap();
    assert_eq!(
        statement.status(stable).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    assert!(manager.cache().contains(stable));
    // Manager-level lookups (admission rechecks) share the same cache.
    let hits = manager.status_metrics().shared_cache_hits;
    assert_eq!(
        manager.lookup(stable).unwrap(),
        Status::Committed {
            sequence: receipt.lsn()
        }
    );
    assert_eq!(manager.status_metrics().shared_cache_hits, hits + 1);
    assert!(statement.status(9999).is_err());
    drop(statement);
    drop(writer);
    drop(reader);
    drop(manager);
    drop(wal);
    fs::remove_dir_all(root).unwrap();
}

/// Test 8: paged status reads stay correct after reserve, commit, abort,
/// growth and recovery, and cost 4 KiB page reads instead of record reads.
#[test]
fn b2_status_page_cache_reflects_every_status_change() {
    let root = directory("status-pages");
    let mut wal = Wal::create_with_mvcc(&root).unwrap();
    let mut store = StatusFile::create(&root, 4).unwrap();
    store.set_growth_extent(4).unwrap();
    assert_eq!(store.page_reads(), 0);
    assert_eq!(store.read_status(1).unwrap(), None);
    assert_eq!(store.page_reads(), 1, "first record read loads its page");
    assert_eq!(store.read_status(2).unwrap(), None);
    assert_eq!(store.page_reads(), 1, "same page, no read");
    // reserve: the cached page sees the reservation without a re-read.
    store.reserve(1).unwrap();
    store.reserve(2).unwrap();
    store.reserve(3).unwrap();
    assert_eq!(store.read_status(1).unwrap(), Some(Status::InProgress));
    assert_eq!(store.read_status(3).unwrap(), Some(Status::InProgress));
    assert_eq!(store.read_status(4).unwrap(), None);
    // commit/install and abort.
    wal.begin_mvcc(2).unwrap();
    let receipt = wal.commit().unwrap();
    store.install(&receipt).unwrap();
    store.abort(3).unwrap();
    assert_eq!(
        store.read_status(2).unwrap(),
        Some(Status::Committed {
            sequence: receipt.lsn()
        })
    );
    assert_eq!(store.read_status(3).unwrap(), Some(Status::Aborted));
    assert_eq!(store.read_status(1).unwrap(), Some(Status::InProgress));
    // growth past the initial grant of 4: the header rewrite drops the first
    // window; records keep resolving correctly afterwards.
    for id in 4..=9 {
        store.reserve(id).unwrap();
    }
    assert!(store.capacity() >= 9);
    assert_eq!(store.read_status(9).unwrap(), Some(Status::InProgress));
    assert_eq!(
        store.read_status(2).unwrap().map(|s| s == Status::Aborted),
        Some(false)
    );
    assert_eq!(store.read_status(3).unwrap(), Some(Status::Aborted));
    assert_eq!(store.read_status(10).unwrap(), None);
    let reads = store.page_reads();
    for id in 1..=9 {
        store.read_status(id).unwrap();
    }
    assert_eq!(
        store.page_reads(),
        reads,
        "nine records, zero extra page reads"
    );
    // A far record lands on another window; the direct-mapped cache is bounded.
    store.set_growth_extent(1 << 12).unwrap();
    for id in 10..=200 {
        store.reserve(id).unwrap();
    }
    assert_eq!(store.read_status(200).unwrap(), Some(Status::InProgress));
    assert!(store.cached_page_count() <= 16);
    // Recovery reopens with an empty page cache and the same answers.
    drop(store);
    drop(wal);
    let (mut recovered, wal) = StatusFile::recover_database(&root).unwrap();
    let reads = recovered.page_reads();
    assert_eq!(
        recovered.read_status(2).unwrap(),
        Some(Status::Committed {
            sequence: receipt.lsn()
        })
    );
    assert_eq!(recovered.read_status(3).unwrap(), Some(Status::Aborted));
    // Unfinished reservations are reconciled to Aborted by recovery.
    assert_eq!(recovered.read_status(200).unwrap(), Some(Status::Aborted));
    assert!(recovered.page_reads() >= reads);
    drop(recovered);
    drop(wal);
    fs::remove_dir_all(root).unwrap();
}

/// Test 9 and the multi-reader smoke: readers on several threads resolve
/// through the shards with correct results while both the session-state
/// mutex and the status I/O mutex are held by someone else — the hot path
/// does not depend on a single global lock.
#[test]
fn b2_concurrent_readers_resolve_through_shards_without_global_locks() {
    let (root, mut wal, manager) = setup("shards");
    let writer = manager.connect(1).unwrap();
    let mut committed = Vec::new();
    let mut aborted = Vec::new();
    for round in 0..48u64 {
        if round % 3 == 2 {
            let stable = writer.begin().unwrap();
            writer.rollback().unwrap();
            aborted.push(stable);
        } else {
            let stable = commit(&mut wal, &manager, &writer);
            committed.push(stable);
        }
    }
    // Warm the shared cache with one reader.
    let warm = manager.connect(2).unwrap();
    let mut statement = warm.statement().unwrap();
    for id in committed.iter().chain(&aborted) {
        statement.status(*id).unwrap();
    }
    drop(statement);
    let readers = (3..=8u64)
        .map(|id| {
            let session = manager.connect(id).unwrap();
            let statement = session.statement().unwrap();
            (session, statement)
        })
        .collect::<Vec<_>>();
    let hits_before = manager.status_metrics().shared_cache_hits;
    // Freeze both global mutexes while the readers run.
    let io = manager.transaction_io().unwrap();
    let done = manager.with_state_held(|| {
        let workers = readers
            .into_iter()
            .map(|(session, mut statement)| {
                let committed = committed.clone();
                let aborted = aborted.clone();
                std::thread::spawn(move || {
                    for _ in 0..20 {
                        for id in &committed {
                            assert!(matches!(
                                statement.status(*id).unwrap(),
                                Status::Committed { .. }
                            ));
                        }
                        for id in &aborted {
                            assert_eq!(statement.status(*id).unwrap(), Status::Aborted);
                        }
                    }
                    // Statement release takes the session mutex by design;
                    // only the lookups above must be lock-free.
                    (session, statement)
                })
            })
            .collect::<Vec<_>>();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(20);
        let mut done = Vec::new();
        for worker in workers {
            while !worker.is_finished() {
                assert!(
                    std::time::Instant::now() < deadline,
                    "reader blocked on a global lock"
                );
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            done.push(worker.join().unwrap());
        }
        done
    });
    drop(io);
    let hits = manager.status_metrics().shared_cache_hits - hits_before;
    assert_eq!(hits, 6 * 20 * 48);
    drop(done);
    drop(warm);
    drop(writer);
    drop(manager);
    drop(wal);
    fs::remove_dir_all(root).unwrap();
}

/// Fencing is preserved on the lock-free hit path: after a fence, cached
/// statuses and hints are refused exactly like fresh lookups.
#[test]
fn b2_cache_and_hint_hits_still_observe_fencing() {
    let (root, mut wal, manager) = setup("fencing");
    let writer = manager.connect(1).unwrap();
    let reader = manager.connect(2).unwrap();
    let stable = commit(&mut wal, &manager, &writer);
    let mut statement = reader.statement().unwrap();
    assert!(matches!(
        statement.status(stable).unwrap(),
        Status::Committed { .. }
    ));
    assert_eq!(
        statement.hint_bound(),
        manager.reclamation_horizon().unwrap()
    );
    assert!(statement.use_hint().is_ok());
    // Abandoning a commit permit fences the sessions.
    let abandoned = writer.begin().unwrap();
    wal.begin_mvcc(abandoned).unwrap();
    let _receipt = wal.commit().unwrap();
    drop(writer.submit_commit().unwrap());
    assert!(
        statement.status(stable).is_err(),
        "cached hit must observe the fence"
    );
    assert!(
        statement.use_hint().is_err(),
        "hint hit must observe the fence"
    );
    drop(statement);
    drop(writer);
    drop(reader);
    drop(manager);
    drop(wal);
    fs::remove_dir_all(root).unwrap();
}
