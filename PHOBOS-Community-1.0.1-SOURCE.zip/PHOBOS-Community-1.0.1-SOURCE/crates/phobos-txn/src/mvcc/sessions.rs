//! Session control and RAII statement/commit lifetimes for the future SQL route.
//! No mutex guard is retained during execution, WAL force or stream delivery.
use super::*;
use phobos_wal::v2::DurableCommit;
use std::sync::{
    Mutex, MutexGuard,
    atomic::{AtomicBool, AtomicU64, Ordering},
};

/// 0.1.9-B2: one bounded, sharded cache of *final* transaction statuses
/// shared by every statement of a database. Only `Committed`/`Aborted` are
/// stored (immutable, so never stale); `InProgress` is always re-resolved.
/// Each shard is a direct-mapped table under its own mutex, so the visibility
/// hot path never takes the session-state mutex or the status-file mutex on
/// a hit. Eviction is overwrite of the colliding slot.
const STATUS_CACHE_SHARDS: usize = 16;
const STATUS_CACHE_SLOTS: usize = 4096;
struct StatusShard {
    keys: Vec<u64>,
    values: Vec<Status>,
}
pub struct StatusCache {
    shards: Vec<Mutex<StatusShard>>,
}
impl StatusCache {
    fn new() -> Self {
        Self {
            shards: (0..STATUS_CACHE_SHARDS)
                .map(|_| {
                    Mutex::new(StatusShard {
                        keys: vec![0; STATUS_CACHE_SLOTS],
                        values: vec![Status::Aborted; STATUS_CACHE_SLOTS],
                    })
                })
                .collect(),
        }
    }
    fn place(transaction: u64) -> (usize, usize) {
        (
            (transaction % STATUS_CACHE_SHARDS as u64) as usize,
            ((transaction / STATUS_CACHE_SHARDS as u64) % STATUS_CACHE_SLOTS as u64) as usize,
        )
    }
    fn get(&self, transaction: u64) -> Option<Status> {
        let (shard, slot) = Self::place(transaction);
        let shard = self.shards[shard].lock().ok()?;
        (shard.keys[slot] == transaction).then(|| shard.values[slot])
    }
    fn insert(&self, transaction: u64, status: Status) {
        if transaction == 0 || status == Status::InProgress {
            return;
        }
        let (shard, slot) = Self::place(transaction);
        if let Ok(mut shard) = self.shards[shard].lock() {
            shard.keys[slot] = transaction;
            shard.values[slot] = status;
        }
    }
    fn clear(&self) {
        for shard in &self.shards {
            if let Ok(mut shard) = shard.lock() {
                shard.keys.fill(0);
            }
        }
    }
    #[cfg(test)]
    pub(super) fn contains(&self, transaction: u64) -> bool {
        self.get(transaction).is_some()
    }
}

/// B1/B2 evidence counters for one database (relaxed atomics).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct StatusMetrics {
    /// Visibility/admission status resolutions requested (hits and misses).
    pub status_lookups: u64,
    /// Resolutions answered by the shared final-status cache.
    pub shared_cache_hits: u64,
    /// 4 KiB status-file page reads.
    pub status_page_reads: u64,
    /// Tuple visibility decisions answered by a settled hint, no lookup.
    pub hint_hits: u64,
}

/// D1 evidence counters for the commit path of one database.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct CommitMetrics {
    /// Stable transaction identities reserved (allocated).
    pub ids_allocated: u64,
    /// Status records written (reserve/commit/abort), forced or not.
    pub status_writes: u64,
    /// `sync_all` calls on the status file (checkpoint, growth, freeze, recovery).
    pub status_forces: u64,
}

#[derive(Clone, Copy)]
enum Phase {
    Idle,
    Starting,
    /// D1: a transaction that has not written yet holds no identity; its
    /// first write allocates one (`Active`). Read-only COMMIT/ROLLBACK
    /// return to `Idle` without any status-store traffic.
    Deferred,
    Active(u64),
    Aborting(u64),
    Committing(u64),
    Failed,
}
struct Context {
    identity: Arc<()>,
    phase: Phase,
    statement: bool,
    failed: bool,
    connected: bool,
}
struct State {
    snapshots: SnapshotRegistry,
    contexts: BTreeMap<u64, Context>,
    limit: usize,
    fenced: bool,
    schema_owner: Option<u64>,
}

pub struct SessionManager {
    directory: std::path::PathBuf,
    status_failed: Arc<AtomicBool>,
    /// Mirror of `State::fenced` for lock-free availability checks.
    fenced: AtomicBool,
    state: Mutex<State>,
    transactions: Mutex<TransactionRegistry>,
    cache: StatusCache,
    lookups: AtomicU64,
    cache_hits: AtomicU64,
    hint_hits: AtomicU64,
    frozen_before: AtomicU64,
}
impl SessionManager {
    pub fn new(
        statuses: StatusFile,
        session_limit: usize,
        transaction_limit: usize,
        snapshot_limit: usize,
    ) -> Result<Arc<Self>> {
        if session_limit == 0 {
            return Err(invalid("session limit must be nonzero"));
        }
        if !statuses.uses_stable_identity() {
            return Err(invalid("MVCC sessions require stable identity storage"));
        }
        let snapshots = SnapshotRegistry::new(statuses.durable_frontier(), snapshot_limit)?;
        Ok(Arc::new(Self {
            directory: statuses.directory().to_path_buf(),
            status_failed: statuses.failure_flag(),
            fenced: AtomicBool::new(false),
            cache: StatusCache::new(),
            frozen_before: AtomicU64::new(statuses.frozen_before()),
            lookups: AtomicU64::new(0),
            cache_hits: AtomicU64::new(0),
            hint_hits: AtomicU64::new(0),
            transactions: Mutex::new(TransactionRegistry::new(statuses, transaction_limit)?),
            state: Mutex::new(State {
                snapshots,
                contexts: BTreeMap::new(),
                limit: session_limit,
                fenced: false,
                schema_owner: None,
            }),
        }))
    }

    fn lock(&self) -> Result<MutexGuard<'_, State>> {
        let state = self
            .state
            .lock()
            .map_err(|_| invalid("session registry poisoned"))?;
        if state.fenced || self.status_failed.load(Ordering::Acquire) {
            return Err(invalid("MVCC sessions require database recovery"));
        }
        Ok(state)
    }
    /// Fences the sessions; `state` is the caller's held guard.
    fn fence(&self, state: &mut State) {
        state.fenced = true;
        self.fenced.store(true, Ordering::Release);
    }
    /// Lock-free availability check (session fencing and status-store
    /// failure), for cache and hint hits on the visibility hot path.
    fn check_available(&self) -> Result<()> {
        if self.fenced.load(Ordering::Acquire) || self.status_failed.load(Ordering::Acquire) {
            return Err(invalid("MVCC sessions require database recovery"));
        }
        Ok(())
    }
    /// Shared-cache-first resolution: hits touch one shard mutex only;
    /// misses take the status I/O domain and cache a final result.
    fn resolve(&self, transaction: u64) -> Result<Status> {
        self.lookups.fetch_add(1, Ordering::Relaxed);
        self.check_available()?;
        if transaction < self.frozen_before.load(Ordering::Acquire) {
            return Err(invalid(
                "transaction status is below the unreferenced freeze boundary",
            ));
        }
        if let Some(status) = self.cache.get(transaction) {
            self.check_available()?;
            self.cache_hits.fetch_add(1, Ordering::Relaxed);
            phobos_observability::event("mvcc.shared_status_hit", 1);
            return Ok(status);
        }
        let status = self.transaction_io()?.status(transaction)?;
        self.cache.insert(transaction, status);
        Ok(status)
    }
    #[must_use]
    pub fn status_metrics(&self) -> StatusMetrics {
        StatusMetrics {
            status_lookups: self.lookups.load(Ordering::Relaxed),
            shared_cache_hits: self.cache_hits.load(Ordering::Relaxed),
            status_page_reads: self
                .transactions
                .lock()
                .map(|io| io.statuses.page_reads())
                .unwrap_or(0),
            hint_hits: self.hint_hits.load(Ordering::Relaxed),
        }
    }
    /// D1 evidence: identities allocated, status records written and status
    /// file forces for this database.
    #[must_use]
    pub fn commit_metrics(&self) -> CommitMetrics {
        let (ids_allocated, status_writes, status_forces) = self
            .transactions
            .lock()
            .map(|io| io.statuses.commit_counters())
            .unwrap_or_default();
        CommitMetrics {
            ids_allocated,
            status_writes,
            status_forces,
        }
    }
    #[cfg(test)]
    pub(super) fn cache(&self) -> &StatusCache {
        &self.cache
    }
    /// Runs `f` while the session-state mutex is held (tests only).
    #[cfg(test)]
    pub(super) fn with_state_held<T>(&self, f: impl FnOnce() -> T) -> T {
        let _state = self.state.lock().unwrap();
        f()
    }
    pub(super) fn transaction_io(&self) -> Result<MutexGuard<'_, TransactionRegistry>> {
        // Callers release context/snapshot bookkeeping before taking the I/O
        // domain. No status-file read or force retains the session directory.
        self.ensure_available()?;
        self.transactions
            .lock()
            .map_err(|_| invalid("transaction registry poisoned"))
    }

    pub fn connect(self: &Arc<Self>, session: u64) -> Result<Session> {
        let mut state = self.lock()?;
        if session == 0 || state.contexts.contains_key(&session) {
            return Err(invalid("invalid or reused live session identity"));
        }
        if state.contexts.len() == state.limit {
            return Err(PhobosError::new(
                ErrorCode::ResourceLimit,
                "MVCC session limit",
            ));
        }
        let identity = Arc::new(());
        state.contexts.insert(
            session,
            Context {
                identity: identity.clone(),
                phase: Phase::Idle,
                statement: false,
                failed: false,
                connected: true,
            },
        );
        Ok(Session {
            manager: self.clone(),
            id: session,
            identity,
        })
    }

    /// DDL is an exclusive schema transaction, separate from ordinary MVCC DML.
    /// Upgrade succeeds only without other transactions or statement pins.
    pub fn acquire_schema(self: &Arc<Self>, stable: u64) -> Result<SchemaLease> {
        let _cost = phobos_observability::span("mvcc.schema_admission");
        let mut state = self.lock()?;
        if state.schema_owner.is_some()
            || state.contexts.values().any(|context| {
                context.statement
                    || match context.phase {
                        Phase::Idle => false,
                        Phase::Active(id) => id != stable,
                        Phase::Committing(_)
                        | Phase::Starting
                        | Phase::Deferred
                        | Phase::Aborting(_) => true,
                        Phase::Failed => false,
                    }
            })
            || !state
                .snapshots
                .state
                .lock()
                .map_err(|_| invalid("snapshot registry poisoned"))?
                .pins
                .is_empty()
        {
            phobos_observability::event("mvcc.schema_rejected", 1);
            return Err(invalid(
                "schema change conflicts with active transactions or statements; retry transaction",
            ));
        }
        if !state
            .contexts
            .values()
            .any(|context| matches!(context.phase, Phase::Active(id) if id == stable))
        {
            return Err(invalid("schema owner must be active"));
        }
        state.schema_owner = Some(stable);
        phobos_observability::event("mvcc.schema_immediate", 1);
        Ok(SchemaLease {
            manager: self.clone(),
            stable,
        })
    }
    pub fn lookup(&self, transaction: u64) -> Result<Status> {
        self.resolve(transaction)
    }
    /// Constraint rechecks use the latest published frontier after ownership
    /// wait, independently of the original statement's Read Committed snapshot.
    pub fn validation_snapshot(&self, stable: u64) -> Result<SnapshotPin> {
        if self.resolve(stable)? != Status::InProgress {
            return Err(invalid(
                "constraint validation requires an active transaction",
            ));
        }
        let mut state = self.lock()?;
        state.snapshots.pin(Some(stable))
    }
    pub fn checkpoint(&self, wal: &mut phobos_wal::v2::Wal) -> Result<()> {
        self.transaction_io()?.checkpoint(wal)
    }
    pub fn request_checkpoint(&self, wal: &mut phobos_wal::v2::Wal, safe: u64) -> Result<()> {
        self.transaction_io()?
            .statuses
            .request_checkpoint(wal, safe)
    }

    /// 0.2-K Part M: physical release threshold of the frozen status prefix.
    pub fn set_status_trim_threshold(&self, records: u64) -> Result<()> {
        self.transaction_io()?.statuses.set_trim_threshold(records);
        Ok(())
    }

    /// (exclusive frozen ID boundary, startup IDs examined). Physical bytes remain.
    pub fn freeze_metrics(&self) -> Result<(u64, u64)> {
        let io = self.transaction_io()?;
        Ok((
            io.statuses.frozen_before(),
            io.statuses.startup_ids_examined(),
        ))
    }

    /// Maintenance caller owns commit/database serialization. The callback scans
    /// committed heaps and certifies that no tuple refers below its returned bound.
    /// Admission stays idle while inspecting/persisting. No active transaction,
    /// copied statement tuple or pinned snapshot may outlive this boundary change.
    /// `next_transaction` also identifies a multi-call sweep: any allocation resets it.
    pub fn freeze_if_idle(
        &self,
        status_limit: u64,
        certify: impl FnOnce(u64, u64) -> Result<Option<u64>>,
    ) -> Result<Option<(u64, u64)>> {
        let state = self.lock()?;
        let pins = state
            .snapshots
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?;
        if !pins.pins.is_empty()
            || state.schema_owner.is_some()
            || !state
                .contexts
                .values()
                .all(|c| matches!(c.phase, Phase::Idle) && !c.statement)
        {
            return Ok(None);
        }
        drop(pins);
        // Never wait for the I/O domain while retaining session bookkeeping.
        let mut io = match self.transactions.try_lock() {
            Ok(io) => io,
            Err(std::sync::TryLockError::WouldBlock) => return Ok(None),
            Err(_) => return Err(invalid("transaction registry poisoned")),
        };
        if !io.active.is_empty() {
            return Ok(None);
        }
        let before = io.statuses.frozen_before();
        if let Some(bound) = certify(io.next_transaction, before)? {
            let horizon = state.snapshots.reclamation_horizon();
            let after = io
                .statuses
                .freeze_unreferenced(bound, horizon, status_limit)?;
            if after != before {
                self.frozen_before.store(after, Ordering::Release);
                self.cache.clear();
            }
            return Ok(Some((before, after)));
        }
        Ok(Some((before, before)))
    }

    pub fn reclamation_horizon(&self) -> Result<u64> {
        Ok(self.lock()?.snapshots.reclamation_horizon())
    }
    /// 0.2-K: (published frontier, reclamation horizon, live pins), observed
    /// together under the session-state lock.
    pub fn publication_state(&self) -> Result<(u64, u64, usize)> {
        let state = self.lock()?;
        Ok((
            state.snapshots.published()?,
            state.snapshots.reclamation_horizon(),
            state.snapshots.pin_count()?,
        ))
    }

    pub fn ensure_available(&self) -> Result<()> {
        drop(self.lock()?);
        Ok(())
    }
    pub fn is_idle(&self) -> Result<bool> {
        let state = self.lock()?;
        let pins = state
            .snapshots
            .state
            .lock()
            .map_err(|_| invalid("snapshot registry poisoned"))?;
        Ok(pins.pins.is_empty()
            && state
                .contexts
                .values()
                .all(|context| matches!(context.phase, Phase::Idle) && !context.statement))
    }
}
impl StatusLookup for &SessionManager {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.lookup(transaction)
    }
}

pub struct SchemaLease {
    manager: Arc<SessionManager>,
    stable: u64,
}
impl Drop for SchemaLease {
    fn drop(&mut self) {
        if let Ok(mut state) = self.manager.state.lock() {
            if state.schema_owner == Some(self.stable) {
                state.schema_owner = None;
            }
        }
    }
}

/// Connection owner. Disconnect aborts only an unsubmitted transaction. A
/// submitted commit stays owned by its permit until publication or fencing.
pub struct Session {
    manager: Arc<SessionManager>,
    id: u64,
    identity: Arc<()>,
}
impl Session {
    /// Begins a transaction and allocates its identity at once (maintenance,
    /// bulk import and callers that will certainly write).
    pub fn begin(&self) -> Result<u64> {
        self.begin_deferred()?;
        self.ensure_transaction_id()
    }

    /// D1: begins a transaction without allocating an identity. `SELECT`s run
    /// against the committed state; the first write calls
    /// `ensure_transaction_id`, and a read-only COMMIT/ROLLBACK costs no
    /// status-store traffic at all.
    pub fn begin_deferred(&self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if !matches!(context.phase, Phase::Idle) || context.statement {
            return Err(invalid("session already executing or in transaction"));
        }
        if state.schema_owner.is_some() {
            return Err(invalid("schema transaction active; retry transaction"));
        }
        let context = state.contexts.get_mut(&self.id).expect("locked context");
        context.phase = Phase::Deferred;
        context.failed = false;
        Ok(())
    }

    /// Whether a transaction (with or without identity, failed or not) is
    /// open on this session.
    pub fn in_transaction(&self) -> Result<bool> {
        let state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        Ok(!matches!(context.phase, Phase::Idle))
    }

    /// The transaction's stable identity, if one has been allocated.
    pub fn transaction_id(&self) -> Result<Option<u64>> {
        let state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        Ok(match context.phase {
            Phase::Active(id) | Phase::Committing(id) | Phase::Aborting(id) => Some(id),
            Phase::Idle | Phase::Starting | Phase::Deferred | Phase::Failed => None,
        })
    }

    /// Allocates the identity of the current transaction on its first write;
    /// later calls return the same identity. Exactly one identity per
    /// writing transaction, monotonic and never reused (A3/C4 unchanged).
    pub fn ensure_transaction_id(&self) -> Result<u64> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        match context.phase {
            Phase::Active(stable) => return Ok(stable),
            Phase::Deferred => {}
            Phase::Idle => return Err(invalid("no active transaction")),
            Phase::Failed => return Err(invalid("transaction requires rollback")),
            Phase::Committing(_) => return Err(invalid("transaction commit already submitted")),
            Phase::Starting | Phase::Aborting(_) => {
                return Err(invalid("transaction control in progress"));
            }
        }
        if context.statement {
            return Err(invalid("identity allocation inside a live statement"));
        }
        if context.failed {
            return Err(invalid("transaction failed; ROLLBACK required"));
        }
        if state.schema_owner.is_some() {
            return Err(invalid("schema transaction active; retry transaction"));
        }
        state
            .contexts
            .get_mut(&self.id)
            .expect("locked context")
            .phase = Phase::Starting;
        drop(state);
        let allocation = self.manager.transaction_io()?.allocate();
        let mut state = self.manager.lock()?;
        let stable = match allocation {
            Ok(stable) => stable,
            Err(error) => {
                state
                    .contexts
                    .get_mut(&self.id)
                    .expect("starting context")
                    .phase = Phase::Deferred;
                return Err(error);
            }
        };
        let context = state.contexts.get_mut(&self.id).expect("locked context");
        context.phase = Phase::Active(stable);
        Ok(stable)
    }

    /// COMMIT of a transaction that never allocated an identity: nothing to
    /// publish, nothing to persist. A failed read-only transaction still
    /// requires ROLLBACK.
    pub fn finish_read_only(&self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get_mut(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if context.statement {
            return Err(invalid("cannot commit a live statement"));
        }
        match context.phase {
            Phase::Deferred if !context.failed => {
                context.phase = Phase::Idle;
                Ok(())
            }
            Phase::Deferred | Phase::Failed => {
                context.phase = Phase::Failed;
                context.failed = true;
                Err(invalid("transaction failed; ROLLBACK required"))
            }
            Phase::Active(_) => Err(invalid("transaction has writes; submit its commit")),
            Phase::Idle => Err(invalid("COMMIT without active transaction")),
            Phase::Committing(_) => Err(invalid("transaction commit already submitted")),
            Phase::Starting | Phase::Aborting(_) => Err(invalid("transaction control in progress")),
        }
    }

    pub fn statement(&self) -> Result<Statement> {
        self.statement_at(None)
    }

    /// Establishes the long-lived pin for an explicit Snapshot transaction.
    /// This does not allocate a transaction identity or mark a statement live.
    pub fn pin_transaction_snapshot(&self) -> Result<SnapshotPin> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if !matches!(context.phase, Phase::Deferred) || context.statement || context.failed {
            return Err(invalid("snapshot pin requires a new deferred transaction"));
        }
        state.snapshots.pin(None)
    }

    /// Starts a statement at a retained transaction frontier. `None` keeps
    /// Read Committed's fresh-statement behavior.
    pub fn statement_at(&self, sequence: Option<u64>) -> Result<Statement> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if context.statement || context.failed {
            return Err(invalid("statement active or transaction failed"));
        }
        let own = match context.phase {
            Phase::Idle | Phase::Deferred => None,
            Phase::Active(id) => Some(id),
            Phase::Committing(_) => return Err(invalid("transaction commit already submitted")),
            Phase::Starting | Phase::Aborting(_) => {
                return Err(invalid("transaction control in progress"));
            }
            Phase::Failed => return Err(invalid("transaction requires rollback")),
        };
        if state.schema_owner.is_some() && state.schema_owner != own {
            return Err(invalid("schema transaction active; retry statement"));
        }
        let pin = match sequence {
            Some(sequence) => state.snapshots.pin_at(sequence, own)?,
            None => state.snapshots.pin(own)?,
        };
        // B1 hint bound: the reclamation horizon (minimum live pin sequence,
        // else the published frontier) only moves forward, so a commit at
        // or below it is visible to this and every later snapshot.
        let hint_bound = state.snapshots.horizon()?;
        state
            .contexts
            .get_mut(&self.id)
            .expect("locked context")
            .statement = true;
        Ok(Statement {
            manager: self.manager.clone(),
            session: self.id,
            pin,
            hint_bound,
            identity: self.identity.clone(),
        })
    }

    pub fn fail_statement(&self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get_mut(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if matches!(context.phase, Phase::Active(_) | Phase::Deferred) {
            context.failed = true;
        }
        Ok(())
    }

    /// Clears an ordinary failed-statement marker after ROLLBACK TO. Hard
    /// transaction aborts remain unrecoverable and still require ROLLBACK.
    pub fn recover_to_savepoint(&self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get_mut(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if context.statement {
            return Err(invalid("cannot recover a live statement"));
        }
        match context.phase {
            Phase::Deferred | Phase::Active(_) => {
                context.failed = false;
                Ok(())
            }
            Phase::Failed => Err(invalid("aborted transaction requires ROLLBACK")),
            _ => Err(invalid("ROLLBACK TO requires an active transaction")),
        }
    }

    /// Call before WAL submission. The stable ID is unchanged by queue order.
    pub fn submit_commit(&self) -> Result<CommitPermit> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get_mut(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if context.statement || context.failed {
            return Err(invalid(
                "cannot commit active statement or failed transaction",
            ));
        }
        let Phase::Active(stable) = context.phase else {
            return Err(invalid("COMMIT without active transaction"));
        };
        context.phase = Phase::Committing(stable);
        Ok(CommitPermit {
            manager: self.manager.clone(),
            session: self.id,
            stable,
            complete: false,
        })
    }

    /// Abort an unsubmitted conflict victim after execution discards its writes.
    /// Keep SQL failed-transaction state until ROLLBACK, without retaining locks.
    pub fn abort_failed(&self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if context.statement {
            return Err(invalid("cannot abort a live statement"));
        }
        if matches!(context.phase, Phase::Failed) {
            return Ok(());
        }
        if matches!(context.phase, Phase::Deferred) {
            let context = state.contexts.get_mut(&self.id).expect("locked context");
            context.phase = Phase::Failed;
            context.failed = true;
            return Ok(());
        }
        let Phase::Active(stable) = context.phase else {
            return Err(invalid("only unsubmitted transactions can be aborted"));
        };
        state
            .contexts
            .get_mut(&self.id)
            .expect("locked context")
            .phase = Phase::Aborting(stable);
        drop(state);
        self.manager.transaction_io()?.abort(stable)?;
        let mut state = self.manager.lock()?;
        let context = state.contexts.get_mut(&self.id).expect("locked context");
        context.phase = Phase::Failed;
        context.failed = true;
        Ok(())
    }

    /// Execution must discard private changes before calling this control step.
    pub fn rollback(&self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.id)
            .ok_or_else(|| invalid("session disconnected"))?;
        if context.statement {
            return Err(invalid("cannot rollback a live statement"));
        }
        if matches!(context.phase, Phase::Failed | Phase::Deferred) {
            let context = state.contexts.get_mut(&self.id).expect("locked context");
            context.phase = Phase::Idle;
            context.failed = false;
            return Ok(());
        }
        let Phase::Active(stable) = context.phase else {
            return Err(invalid("ROLLBACK requires an unsubmitted transaction"));
        };
        state
            .contexts
            .get_mut(&self.id)
            .expect("locked context")
            .phase = Phase::Aborting(stable);
        drop(state);
        self.manager.transaction_io()?.abort(stable)?;
        let mut state = self.manager.lock()?;
        let context = state.contexts.get_mut(&self.id).expect("locked context");
        context.phase = Phase::Idle;
        context.failed = false;
        Ok(())
    }
}
impl Drop for Session {
    fn drop(&mut self) {
        if let Ok(mut state) = self.manager.state.lock() {
            let Some(context) = state.contexts.get_mut(&self.id) else {
                return;
            };
            context.connected = false;
            match context.phase {
                Phase::Committing(_) => return,
                Phase::Active(stable) | Phase::Aborting(stable) => {
                    context.phase = Phase::Aborting(stable);
                    drop(state);
                    let result = self
                        .manager
                        .transaction_io()
                        .and_then(|mut transactions| transactions.abort(stable));
                    let Ok(mut next) = self.manager.state.lock() else {
                        return;
                    };
                    if result.is_err() {
                        self.manager.fence(&mut next);
                    }
                    state = next;
                }
                Phase::Starting => {
                    self.manager.fence(&mut state);
                }
                Phase::Idle | Phase::Deferred | Phase::Failed => {}
            }
            state.contexts.remove(&self.id);
        }
    }
}

/// Retain this across the entire result stream, including error delivery. Row
/// status lookups take short locks; retaining this object does not hold one.
pub struct Statement {
    manager: Arc<SessionManager>,
    session: u64,
    pin: SnapshotPin,
    /// B1: commits at or below this sequence are visible to every snapshot.
    hint_bound: u64,
    identity: Arc<()>,
}
impl Statement {
    fn lookup(&self, transaction: u64) -> Result<Status> {
        phobos_observability::assert_no_structural_scope();
        // B2: the shared final-status cache replaces the per-statement map.
        // Stable identities are never reused and terminal states never
        // change; in-progress (including own-write) status is always
        // re-resolved through the registry. Session and status-store fencing
        // are preserved on hits through the lock-free check in `resolve`.
        self.manager.resolve(transaction)
    }
    /// Sequence bound under which this statement may record settled hints.
    #[must_use]
    pub fn hint_bound(&self) -> u64 {
        self.hint_bound
    }
    #[must_use]
    pub fn status_metrics(&self) -> StatusMetrics {
        self.manager.status_metrics()
    }
    pub fn check_database(&self, directory: &std::path::Path) -> Result<()> {
        self.manager.ensure_available()?;
        if self.manager.directory != directory {
            return Err(invalid("statement belongs to another database"));
        }
        Ok(())
    }
    #[must_use]
    pub fn snapshot(&self) -> Snapshot {
        self.pin.snapshot()
    }
}
impl StatusLookup for Statement {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.lookup(transaction)
    }
    fn hint_bound(&self) -> Option<u64> {
        Some(self.hint_bound)
    }
    fn use_hint(&mut self) -> Result<()> {
        self.manager.check_available()?;
        self.manager.hint_hits.fetch_add(1, Ordering::Relaxed);
        Ok(())
    }
}
/// 0.2-B: statement lookup for one scan. Identical fencing and resolution to
/// `&Statement`; settled-hint uses are counted locally and published to the
/// shared diagnostic counter once, instead of one contended atomic per tuple.
pub struct StatementLookup<'a> {
    statement: &'a Statement,
    hint_hits: u64,
}
impl Statement {
    #[must_use]
    pub fn lookup_scope(&self) -> StatementLookup<'_> {
        StatementLookup {
            statement: self,
            hint_hits: 0,
        }
    }
}
impl StatusLookup for StatementLookup<'_> {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.statement.lookup(transaction)
    }
    fn hint_bound(&self) -> Option<u64> {
        Some(self.statement.hint_bound)
    }
    fn use_hint(&mut self) -> Result<()> {
        self.statement.manager.check_available()?;
        self.hint_hits += 1;
        Ok(())
    }
}
impl Drop for StatementLookup<'_> {
    fn drop(&mut self) {
        if self.hint_hits != 0 {
            self.statement
                .manager
                .hint_hits
                .fetch_add(self.hint_hits, Ordering::Relaxed);
        }
    }
}
impl StatusLookup for &Statement {
    fn status(&mut self, transaction: u64) -> Result<Status> {
        self.lookup(transaction)
    }
    fn hint_bound(&self) -> Option<u64> {
        Some(self.hint_bound)
    }
    fn use_hint(&mut self) -> Result<()> {
        self.manager.check_available()?;
        self.manager.hint_hits.fetch_add(1, Ordering::Relaxed);
        Ok(())
    }
}
impl Drop for Statement {
    fn drop(&mut self) {
        if let Ok(mut state) = self.manager.state.lock() {
            if let Some(context) = state.contexts.get_mut(&self.session) {
                if Arc::ptr_eq(&self.identity, &context.identity) {
                    context.statement = false;
                }
            }
        }
        // pin drops after the session mutex guard is released.
    }
}

/// Owned by the commit worker, not by the connection. Abandonment is fenced;
/// COMMIT must never be translated into rollback after a durable WAL receipt.
pub struct CommitPermit {
    manager: Arc<SessionManager>,
    session: u64,
    stable: u64,
    complete: bool,
}
impl CommitPermit {
    #[must_use]
    pub fn stable_id(&self) -> u64 {
        self.stable
    }

    /// Caller holds ordered publication ownership across this operation. The
    /// callback atomically installs heap/index changes before status publication.
    pub fn publish(
        mut self,
        receipt: &DurableCommit,
        install: impl FnOnce() -> Result<()>,
    ) -> Result<()> {
        if receipt.mvcc_id() != Some(self.stable) {
            return Err(invalid("commit permit/receipt stable identity mismatch"));
        }
        self.manager.transaction_io()?.validate_commit(receipt)?;
        install()?;
        let state = self.manager.lock()?;
        let context = state
            .contexts
            .get(&self.session)
            .ok_or_else(|| invalid("commit context missing"))?;
        if !matches!(context.phase, Phase::Committing(id) if id == self.stable) {
            return Err(invalid("commit context changed"));
        }
        drop(state);
        self.manager.transaction_io()?.commit(receipt)?;
        phobos_observability::synchronization_boundary(
            "c6_status_persisted_before_frontier",
            &self.manager.directory,
        );
        let mut state = self.manager.lock()?;
        state.snapshots.advance_publication(receipt.lsn())?;
        let context = state
            .contexts
            .get_mut(&self.session)
            .expect("locked context");
        context.phase = Phase::Idle;
        if !context.connected {
            state.contexts.remove(&self.session);
        }
        self.complete = true;
        Ok(())
    }
}
impl CommitPermit {
    /// D2: the batch member failed before anything of it became durable (no
    /// WAL record forced, no page installed). The transaction aborts like an
    /// unsubmitted one and the session returns to `Idle`; nothing is fenced.
    /// Only the publisher, which knows that nothing durable exists, may call
    /// this; an abort I/O failure fences like any status failure.
    pub fn abort(mut self) -> Result<()> {
        let mut state = self.manager.lock()?;
        let context = state
            .contexts
            .get_mut(&self.session)
            .ok_or_else(|| invalid("commit context missing"))?;
        if !matches!(context.phase, Phase::Committing(id) if id == self.stable) {
            return Err(invalid("commit context changed"));
        }
        context.phase = Phase::Aborting(self.stable);
        drop(state);
        let result = self
            .manager
            .transaction_io()
            .and_then(|mut transactions| transactions.abort(self.stable));
        let mut state = self
            .manager
            .state
            .lock()
            .map_err(|_| invalid("session registry poisoned"))?;
        if result.is_err() {
            self.manager.fence(&mut state);
            self.complete = true;
            return result;
        }
        if let Some(context) = state.contexts.get_mut(&self.session) {
            context.phase = Phase::Idle;
            context.failed = false;
            if !context.connected {
                state.contexts.remove(&self.session);
            }
        }
        self.complete = true;
        Ok(())
    }
}
impl Drop for CommitPermit {
    fn drop(&mut self) {
        if !self.complete {
            if let Ok(mut state) = self.manager.state.lock() {
                self.manager.fence(&mut state);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_wal::v2::Wal;
    use std::{fs, path::PathBuf};

    fn setup() -> (PathBuf, Wal, Arc<SessionManager>) {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let sequence = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let root = std::env::temp_dir().join(format!(
            "phobos-session-control-{}-{}-{sequence}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let wal = Wal::create_with_versioned_heap(&root).unwrap();
        let manager =
            SessionManager::new(StatusFile::create(&root, 128).unwrap(), 8, 8, 8).unwrap();
        (root, wal, manager)
    }

    #[test]
    fn c6_cached_terminal_visibility_progresses_while_status_writer_is_paused() {
        let (root, wal, manager) = setup();
        let owner = manager.connect(1).unwrap();
        let aborted = owner.begin().unwrap();
        owner.rollback().unwrap();
        let reader = manager.connect(2).unwrap();
        let mut statement = reader.statement().unwrap();
        assert_eq!(statement.status(aborted).unwrap(), Status::Aborted);
        let io = manager.transaction_io().unwrap();
        let (send, receive) = std::sync::mpsc::channel();
        let worker = std::thread::spawn(move || {
            send.send(statement.status(aborted)).unwrap();
        });
        let result = receive.recv_timeout(std::time::Duration::from_secs(10));
        drop(io);
        worker.join().unwrap();
        assert_eq!(result.unwrap().unwrap(), Status::Aborted);
        drop(owner);
        drop(reader);
        drop(manager);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn c6_snapshot_creation_does_not_wait_for_transaction_status_io() {
        let (root, wal, manager) = setup();
        let reader = manager.connect(1).unwrap();
        let io = manager.transaction_io().unwrap();
        let (send, receive) = std::sync::mpsc::channel();
        let directory = manager.directory.clone();
        let worker = std::thread::spawn(move || {
            let statement = reader.statement().unwrap();
            statement.check_database(&directory).unwrap();
            send.send(statement.snapshot()).unwrap();
        });
        let result = receive.recv_timeout(std::time::Duration::from_secs(10));
        drop(io);
        worker.join().unwrap();
        result.unwrap();
        assert!(manager.is_idle().unwrap());
        drop(manager);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn statement_terminal_cache_preserves_active_abort_and_fencing() {
        let (root, mut wal, manager) = setup();
        let owner = manager.connect(1).unwrap();
        let reader = manager.connect(2).unwrap();
        let aborted = owner.begin().unwrap();
        let mut statement = reader.statement().unwrap();
        assert_eq!(statement.status(aborted).unwrap(), Status::InProgress);
        assert!(!manager.cache().contains(aborted));
        owner.rollback().unwrap();
        assert_eq!(statement.status(aborted).unwrap(), Status::Aborted);
        assert_eq!(statement.status(aborted).unwrap(), Status::Aborted);
        assert!(manager.cache().contains(aborted));
        assert!(statement.status(127).is_err());
        let stable = owner.begin().unwrap();
        wal.begin_mvcc(stable).unwrap();
        let _receipt = wal.commit().unwrap();
        drop(owner.submit_commit().unwrap());
        assert!(statement.status(aborted).is_err());
        drop(statement);
        drop(owner);
        drop(reader);
        drop(manager);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn statement_lifetimes_allow_other_sessions_and_refresh_visibility() {
        let (root, mut wal, manager) = setup();
        let writer = manager.connect(1).unwrap();
        let later = manager.connect(2).unwrap();
        let reader = manager.connect(3).unwrap();
        let a = writer.begin().unwrap();
        let b = later.begin().unwrap();
        let mut paused = writer.statement().unwrap();
        let own_snapshot = paused.snapshot();
        let own_version = Version {
            creator: a,
            deleter: None,
        };
        assert!(own_snapshot.visible(own_version, &mut paused).unwrap());
        let mut old = reader.statement().unwrap();
        let old_snapshot = old.snapshot();
        assert!(!old_snapshot.visible(own_version, &mut old).unwrap());
        let permit = later.submit_commit().unwrap();
        assert_eq!(permit.stable_id(), b);
        wal.begin_mvcc(b).unwrap();
        let receipt = wal.commit().unwrap();
        permit.publish(&receipt, || Ok(())).unwrap();
        let later_version = Version {
            creator: b,
            deleter: None,
        };
        assert!(!old_snapshot.visible(later_version, &mut old).unwrap());
        drop(old);
        let mut fresh = reader.statement().unwrap();
        assert!(fresh.snapshot().visible(later_version, &mut fresh).unwrap());
        assert!(!fresh.snapshot().visible(own_version, &mut fresh).unwrap());
        drop(paused);
        writer.rollback().unwrap();
        assert!(!own_snapshot.visible(own_version, &mut fresh).unwrap());
        drop(fresh);
        drop(writer);
        drop(later);
        drop(reader);
        drop(manager);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn disconnected_commit_still_publishes_and_stale_statement_cannot_release_new_session() {
        let (root, mut wal, manager) = setup();
        let owner = manager.connect(1).unwrap();
        let stable = owner.begin().unwrap();
        let permit = owner.submit_commit().unwrap();
        wal.begin_mvcc(stable).unwrap();
        let receipt = wal.commit().unwrap();
        drop(owner);
        assert_eq!(manager.lookup(stable).unwrap(), Status::InProgress);
        permit.publish(&receipt, || Ok(())).unwrap();
        assert_eq!(
            manager.lookup(stable).unwrap(),
            Status::Committed {
                sequence: receipt.lsn()
            }
        );
        let owner = manager.connect(1).unwrap();
        let old_statement = owner.statement().unwrap();
        drop(owner);
        let new_owner = manager.connect(1).unwrap();
        let new_statement = new_owner.statement().unwrap();
        drop(old_statement);
        assert!(new_owner.statement().is_err());
        drop(new_statement);
        drop(new_owner.statement().unwrap());
        drop(new_owner);
        drop(manager);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn failed_or_abandoned_durable_commit_fences_without_false_abort() {
        for fail_install in [false, true] {
            let (root, mut wal, manager) = setup();
            let owner = manager.connect(1).unwrap();
            let stable = owner.begin().unwrap();
            let permit = owner.submit_commit().unwrap();
            wal.begin_mvcc(stable).unwrap();
            let receipt = wal.commit().unwrap();
            if fail_install {
                assert!(
                    permit
                        .publish(&receipt, || Err(PhobosError::new(
                            ErrorCode::Io,
                            "injected install failure"
                        )))
                        .is_err()
                );
            } else {
                drop(permit);
            }
            assert!(manager.ensure_available().is_err());
            assert!(owner.rollback().is_err());
            drop(owner);
            drop(manager);
            drop(wal);
            let (mut statuses, wal) = StatusFile::recover_database(&root).unwrap();
            assert_eq!(
                statuses.status(stable).unwrap(),
                Status::Committed {
                    sequence: receipt.lsn()
                }
            );
            drop(statuses);
            drop(wal);
            fs::remove_dir_all(root).unwrap();
        }
    }
    #[test]
    fn incremental_visibility_retirement_keeps_later_reverse_order_chain_and_recovers_twice() {
        let (root, mut wal, manager) = setup();
        let a = manager.connect(1).unwrap();
        let b = manager.connect(2).unwrap();
        let a_id = a.begin().unwrap();
        let b_id = b.begin().unwrap();
        wal.begin_mvcc(b_id).unwrap();
        let first = wal.commit().unwrap();
        b.submit_commit()
            .unwrap()
            .publish(&first, || Ok(()))
            .unwrap();
        assert!(wal.request_checkpoint(first.lsn()).is_err());
        assert!(
            wal.request_checkpoint_with_visibility(first.lsn(), |_| Ok(first.lsn() - 1))
                .is_err()
        );
        assert!(!wal.checkpoint_pending());
        manager.request_checkpoint(&mut wal, first.lsn()).unwrap();
        wal.begin_mvcc(a_id).unwrap();
        let tail = wal.commit().unwrap();
        a.submit_commit()
            .unwrap()
            .publish(&tail, || Ok(()))
            .unwrap();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
        while wal.checkpoint_pending() {
            wal.poll_checkpoint().unwrap();
            assert!(std::time::Instant::now() < deadline);
            std::thread::yield_now();
        }
        let report = phobos_wal::v2::inspect(root.join("phobos.wal")).unwrap();
        assert_eq!(report.page_format, 4);
        assert_eq!(report.committed_transactions, 1);
        assert_eq!(report.last_lsn, tail.lsn());
        let abandoned = a.begin().unwrap();
        drop(a);
        drop(b);
        drop(manager);
        drop(wal);
        for _ in 0..2 {
            let (mut statuses, wal) = StatusFile::recover_database(&root).unwrap();
            assert_eq!(
                statuses.status(a_id).unwrap(),
                Status::Committed {
                    sequence: tail.lsn()
                }
            );
            assert_eq!(
                statuses.status(b_id).unwrap(),
                Status::Committed {
                    sequence: first.lsn()
                }
            );
            assert_eq!(statuses.status(abandoned).unwrap(), Status::Aborted);
            drop(statuses);
            drop(wal);
        }
        fs::remove_dir_all(root).unwrap();
    }
}
