//! Two alternating, checksummed watermark slots. Old status bytes are retained.
//! A failed/torn inactive-slot write leaves the prior slot usable; no rename or
//! new WAL record type is needed. Missing metadata means the legacy boundary 1.
use super::{Result, invalid};
use std::{
    fs::{File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::Path,
};

pub const NAME: &str = "phobos.mvcc-freeze";
const SLOT: usize = 64;
#[derive(Clone, Copy, Debug)]
pub(super) struct Frozen {
    pub generation: u64,
    pub before: u64,
    pub frontier: u64,
    pub reserved: u64,
}
impl Default for Frozen {
    fn default() -> Self {
        Self {
            generation: 0,
            before: 1,
            frontier: 0,
            reserved: 1,
        }
    }
}
fn decode(b: &[u8]) -> Option<Frozen> {
    if b.len() != SLOT
        || &b[..8] != b"PHFR\x01\x00\x40\x00"
        || b[40..60] != [0; 20]
        || phobos_wal::page_checksum::scratch_checksum(&b[..60])
            != u32::from_le_bytes(b[60..64].try_into().ok()?)
    {
        return None;
    }
    let n = |at| u64::from_le_bytes(b[at..at + 8].try_into().expect("metadata field"));
    let f = Frozen {
        generation: n(8),
        before: n(16),
        frontier: n(24),
        reserved: n(32),
    };
    (f.generation != 0 && f.before > 1 && f.before <= f.reserved).then_some(f)
}
pub(super) fn read(directory: &Path) -> Result<Frozen> {
    let mut file = match File::open(directory.join(NAME)) {
        Ok(file) => file,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Frozen::default()),
        Err(e) => return Err(e.into()),
    };
    if file.metadata()?.len() > (2 * SLOT) as u64 {
        return Err(invalid("invalid freeze metadata extent"));
    }
    let mut bytes = Vec::new();
    file.read_to_end(&mut bytes)?;
    let mut valid = bytes.chunks(SLOT).filter_map(decode).collect::<Vec<_>>();
    valid.sort_by_key(|f| f.generation);
    if let Some(last) = valid.last() {
        return Ok(*last);
    }
    // The first write targets slot 1. A partial initial write has no previous
    // boundary; falling back to all-history validation is safe (bytes retained).
    if bytes.len() <= 2 * SLOT && bytes.iter().take(SLOT).all(|b| *b == 0) {
        return Ok(Frozen::default());
    }
    Err(invalid("no valid freezing watermark slot"))
}
pub(super) fn write(
    directory: &Path,
    previous: Frozen,
    before: u64,
    frontier: u64,
    reserved: u64,
) -> Result<Frozen> {
    let next = Frozen {
        generation: previous
            .generation
            .checked_add(1)
            .ok_or_else(|| invalid("freeze generation exhausted"))?,
        before,
        frontier,
        reserved,
    };
    let mut file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(directory.join(NAME))?;
    if previous.generation == 0 {
        file.set_len((2 * SLOT) as u64)?;
        file.sync_all()?;
        #[cfg(unix)]
        File::open(directory)?.sync_all()?;
    }
    let mut b = [0; SLOT];
    b[..8].copy_from_slice(b"PHFR\x01\x00\x40\x00");
    for (at, n) in [
        (8, next.generation),
        (16, before),
        (24, frontier),
        (32, reserved),
    ] {
        b[at..at + 8].copy_from_slice(&n.to_le_bytes());
    }
    let crc = phobos_wal::page_checksum::scratch_checksum(&b[..60]);
    b[60..].copy_from_slice(&crc.to_le_bytes());
    phobos_observability::synchronization_boundary("c4_freeze_before_write", directory);
    file.seek(SeekFrom::Start((next.generation % 2) * SLOT as u64))?;
    file.write_all(&b)?;
    phobos_observability::synchronization_boundary("c4_freeze_after_write", directory);
    file.sync_all()?;
    phobos_observability::synchronization_boundary("c4_freeze_after_sync", directory);
    Ok(next)
}
