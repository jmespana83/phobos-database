//! Diagnostic component timings, not a database throughput benchmark.
use phobos_catalog::{Catalog, CheckDefinition, SchemaDefinitions};
use phobos_types::{ColumnSchema, DataType, Row, Value};
use std::{hint::black_box, time::Instant};
fn measure(name: &str, n: usize, mut f: impl FnMut()) {
    for _ in 0..10000 {
        f();
    }
    for sample in 0..7 {
        let start = Instant::now();
        for _ in 0..n {
            f();
        }
        println!("{name},{sample},{n},{}", start.elapsed().as_nanos());
    }
}
fn main() {
    let root = std::env::args()
        .nth(1)
        .expect("fresh fixture directory required");
    assert!(!std::path::Path::new(&root).exists());
    std::fs::create_dir_all(&root).unwrap();
    let mut catalog = Catalog::open(&root).unwrap();
    let table = catalog
        .create_table(
            "profile_table".into(),
            vec![ColumnSchema {
                name: "id".into(),
                data_type: DataType::Int64,
                nullable: false,
            }],
        )
        .unwrap();
    let row = Row::new(vec![Value::Int64(1)]);
    let n = 2_000_000;
    println!("component,sample,operations,elapsed_ns");
    measure("loop_control", n, || {
        black_box(&row);
    });
    measure("empty_definition_lookup", n, || {
        let _ = black_box(black_box(&catalog).definitions(black_box(table.id)));
    });
    measure("unconstrained_row_validation", n, || {
        black_box(
            black_box(&catalog).validate_row_definitions(black_box(table.id), black_box(&row)),
        )
        .unwrap();
    });
    measure("catalog_clone_drop", n, || {
        black_box(black_box(&catalog).clone());
    });
    let map = std::sync::Arc::new(std::collections::BTreeMap::<u64, SchemaDefinitions>::new());
    measure("extra_arc_clone_drop", n, || {
        black_box(black_box(&map).clone());
    });
    let mut definitions = SchemaDefinitions::default();
    definitions.defaults.insert(0, Value::Int64(1));
    definitions.checks.push(CheckDefinition {
        column: 0,
        operator: 5,
        value: Value::Int64(0),
    });
    catalog.set_definitions(table.id, definitions).unwrap();
    measure("nonempty_missing_table_lookup", n, || {
        let _ = black_box(black_box(&catalog).definitions(black_box(table.id + 1)));
    });
    measure("default_lookup", n, || {
        let _ = black_box(
            black_box(&catalog)
                .definitions(black_box(table.id))
                .unwrap()
                .defaults
                .get(black_box(&0)),
        );
    });
    measure("primary_metadata_lookup", n, || {
        let _ = black_box(
            black_box(&catalog)
                .definitions(black_box(table.id))
                .unwrap()
                .primary_index,
        );
    });
    measure("check_pass", n, || {
        black_box(
            black_box(&catalog).validate_row_definitions(black_box(table.id), black_box(&row)),
        )
        .unwrap();
    });
    let bad = Row::new(vec![Value::Int64(-1)]);
    measure("check_reject", 100_000, || {
        assert!(
            black_box(
                black_box(&catalog).validate_row_definitions(black_box(table.id), black_box(&bad))
            )
            .is_err()
        );
    });
}
