#![forbid(unsafe_code)]
//! Durable catalog bootstrap for Phase 1.

use phobos_error::{ErrorCode, PhobosError};
use phobos_types::{ColumnSchema, DataType, IndexId, IndexSchema, TableId, TableSchema, Value};
use std::sync::Arc;
use std::{
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
};

const MAGIC: [u8; 4] = *b"PHOC";
const VERSION: u16 = 2;
/// 0.2-K.4: catalog format carrying a capability bitmask. Written only once a
/// capability is enabled, so a database stays readable by older binaries
/// (which accept versions 1 and 2 and refuse 3) until then.
const VERSION_CAPABILITIES: u16 = 3;
const VERSION_DEFINITIONS: u16 = 4;
const VERSION_IDENTITY: u16 = 5;
mod definitions;
mod views;
pub use definitions::{
    CheckDefinition, ForeignKeyDefinition, IdentityDefinition, SchemaDefinitions,
};
pub use views::ViewDefinition;
/// 0.2-K.4 capability: non-unique index entries may be stale at rest (lazy
/// index pruning V1). Index readers revalidate every entry (RID lifecycle
/// state, key, MVCC visibility); stale entries are removed by the
/// background sweeper. Older binaries must not open such a database.
pub const CAPABILITY_LAZY_INDEX_PRUNING_V1: u32 = 1;
/// Capability bits this binary understands.
pub const SUPPORTED_CAPABILITIES: u32 = CAPABILITY_LAZY_INDEX_PRUNING_V1;
const INDEX_MAGIC: [u8; 4] = *b"PHCI";
const INDEX_VERSION: u16 = 1;

fn checksum(bytes: &[u8]) -> u32 {
    let mut hash = 0x811c_9dc5u32;
    for byte in bytes {
        hash ^= u32::from(*byte);
        hash = hash.wrapping_mul(0x0100_0193);
    }
    hash
}

/// Durable table catalog. Names are compared case-insensitively and persisted canonically.
#[derive(Debug, Clone)]
pub struct Catalog {
    path: PathBuf,
    index_path: PathBuf,
    next_table_id: TableId,
    next_index_id: IndexId,
    // 0.2-F: copy-on-write maps. Every statement view and commit domain
    // clones the catalog; sharing the immutable maps makes that clone O(1).
    // Mutation goes through `Arc::make_mut` (unique owner: in place).
    tables: std::sync::Arc<BTreeMap<String, TableSchema>>,
    indexes: std::sync::Arc<BTreeMap<String, IndexSchema>>,
    partition_keys: std::sync::Arc<BTreeMap<String, String>>,
    partitions: std::sync::Arc<BTreeMap<String, RangePartition>>,
    /// 0.2-K.4: persistent capability bits (0 = none; catalog version 2).
    capabilities: u32,
    minimum_version: u16,
    definitions: Arc<BTreeMap<TableId, SchemaDefinitions>>,
    views: Arc<BTreeMap<String, ViewDefinition>>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RangePartition {
    pub parent: String,
    pub child: String,
    pub key_column: String,
    pub lower: Value,
    pub upper: Value,
}

impl Catalog {
    /// Redirect subsequent metadata persistence while retaining the in-memory
    /// catalog. The transaction owner handles WAL, publication, and rollback.
    pub fn redirect_persistence(&mut self, directory: &Path) -> Result<(), PhobosError> {
        if !directory.is_dir() {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "catalog persistence directory is missing",
            ));
        }
        self.path = directory.join("catalog.phc");
        self.index_path = directory.join("indexes.phc");
        Ok(())
    }
    pub fn open(data_dir: impl AsRef<Path>) -> Result<Self, PhobosError> {
        phobos_observability::measure("fs.create_dir_all", || {
            fs::create_dir_all(data_dir.as_ref())
        })?;
        let path = data_dir.as_ref().join("catalog.phc");
        let index_path = data_dir.as_ref().join("indexes.phc");
        let mut catalog = if !path.exists() {
            let catalog = Self {
                path,
                index_path,
                next_table_id: 1,
                next_index_id: 1,
                tables: Default::default(),
                indexes: Default::default(),
                partition_keys: Default::default(),
                partitions: Default::default(),
                capabilities: 0,
                minimum_version: VERSION,
                definitions: Default::default(),
                views: Default::default(),
            };
            catalog.persist()?;
            catalog
        } else {
            Self::load(path, index_path)?
        };
        catalog.load_indexes()?;
        if !catalog.index_path.exists() {
            catalog.persist_indexes()?;
        }
        catalog.validate_definitions()?;
        catalog.validate_views()?;
        Ok(catalog)
    }

    fn load(path: PathBuf, index_path: PathBuf) -> Result<Self, PhobosError> {
        let mut bytes = Vec::new();
        File::open(&path)?.read_to_end(&mut bytes)?;
        if bytes.len() < 18 || bytes[0..4] != MAGIC {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "invalid catalog header",
            ));
        }
        let version = u16::from_le_bytes([bytes[4], bytes[5]]);
        if version != 1
            && version != VERSION
            && version != VERSION_CAPABILITIES
            && version != VERSION_DEFINITIONS
            && version != VERSION_IDENTITY
        {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "unsupported catalog format",
            ));
        }
        let payload_end = bytes.len() - 4;
        let expected = u32::from_le_bytes(bytes[payload_end..].try_into().expect("checksum"));
        if checksum(&bytes[..payload_end]) != expected {
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "catalog checksum mismatch",
            ));
        }
        let mut cursor = 6usize;
        let next_table_id = take_u64(&bytes, &mut cursor, payload_end)?;
        let count = take_u32(&bytes, &mut cursor, payload_end)?;
        let mut tables = BTreeMap::new();
        for _ in 0..count {
            let id = take_u64(&bytes, &mut cursor, payload_end)?;
            let name = take_string(&bytes, &mut cursor, payload_end)?;
            let column_count = take_u16(&bytes, &mut cursor, payload_end)?;
            let mut columns = Vec::with_capacity(usize::from(column_count));
            for _ in 0..column_count {
                let column_name = take_string(&bytes, &mut cursor, payload_end)?;
                let data_type = take_data_type(&bytes, &mut cursor, payload_end)?;
                let nullable = take_u8(&bytes, &mut cursor, payload_end)? != 0;
                columns.push(ColumnSchema {
                    name: column_name,
                    data_type,
                    nullable,
                });
            }
            tables.insert(name.to_ascii_lowercase(), TableSchema { id, name, columns });
        }
        let mut partitions = BTreeMap::new();
        let mut partition_keys = BTreeMap::new();
        if version >= 2 {
            let parent_count = take_u32(&bytes, &mut cursor, payload_end)?;
            for _ in 0..parent_count {
                let parent = take_string(&bytes, &mut cursor, payload_end)?;
                let key = take_string(&bytes, &mut cursor, payload_end)?;
                partition_keys.insert(parent.to_ascii_lowercase(), key);
            }
            let partition_count = take_u32(&bytes, &mut cursor, payload_end)?;
            for _ in 0..partition_count {
                let parent = take_string(&bytes, &mut cursor, payload_end)?;
                let child = take_string(&bytes, &mut cursor, payload_end)?;
                let key_column = take_string(&bytes, &mut cursor, payload_end)?;
                let lower = take_value(&bytes, &mut cursor, payload_end)?;
                let upper = take_value(&bytes, &mut cursor, payload_end)?;
                partitions.insert(
                    child.to_ascii_lowercase(),
                    RangePartition {
                        parent,
                        child,
                        key_column,
                        lower,
                        upper,
                    },
                );
            }
        }
        let mut capabilities = 0;
        if version >= VERSION_CAPABILITIES {
            capabilities = take_u32(&bytes, &mut cursor, payload_end)?;
            let unknown = capabilities & !SUPPORTED_CAPABILITIES;
            if unknown != 0 {
                return Err(PhobosError::new(
                    ErrorCode::Unsupported,
                    format!(
                        "database requires storage capabilities this PHOBOS binary does not support (bits {unknown:#x}); open it with a newer release"
                    ),
                ));
            }
        }
        let definitions = if version >= VERSION_DEFINITIONS {
            definitions::decode(
                &bytes,
                &mut cursor,
                payload_end,
                version >= VERSION_IDENTITY,
            )?
        } else {
            BTreeMap::new()
        };
        let views = if version >= VERSION_IDENTITY {
            views::decode(&bytes, &mut cursor, payload_end)?
        } else {
            BTreeMap::new()
        };
        if cursor != payload_end {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "catalog contains trailing bytes",
            ));
        }
        Ok(Self {
            path,
            index_path,
            next_table_id,
            next_index_id: 1,
            tables: tables.into(),
            indexes: Default::default(),
            partition_keys: partition_keys.into(),
            partitions: partitions.into(),
            capabilities,
            minimum_version: version,
            definitions: definitions.into(),
            views: views.into(),
        })
    }

    /// 0.2-K.4: persistent capability bits.
    #[must_use]
    pub fn capabilities(&self) -> u32 {
        self.capabilities
    }
    /// 0.2-K.4: whether lazy index pruning V1 semantics are enabled.
    #[must_use]
    pub fn lazy_index_pruning(&self) -> bool {
        self.capabilities & CAPABILITY_LAZY_INDEX_PRUNING_V1 != 0
    }
    /// 0.2-K.4: enable capability bits and persist (catalog version 3). The
    /// caller makes this durable/replicated through a schema publication
    /// (WAL metadata image), exactly like DDL.
    pub fn enable_capabilities(&mut self, bits: u32) -> Result<(), PhobosError> {
        if bits & !SUPPORTED_CAPABILITIES != 0 {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "unknown storage capability",
            ));
        }
        self.capabilities |= bits;
        self.persist()
    }

    pub fn tables(&self) -> impl Iterator<Item = &TableSchema> {
        self.tables.values()
    }

    #[must_use]
    pub fn table(&self, name: &str) -> Option<&TableSchema> {
        self.tables.get(&name.to_ascii_lowercase())
    }

    pub fn indexes(&self) -> impl Iterator<Item = &IndexSchema> {
        self.indexes.values()
    }

    #[must_use]
    pub fn index(&self, name: &str) -> Option<&IndexSchema> {
        self.indexes.get(&name.to_ascii_lowercase())
    }

    pub fn indexes_for_table(&self, table_id: TableId) -> impl Iterator<Item = &IndexSchema> {
        self.indexes
            .values()
            .filter(move |index| index.table_id == table_id)
    }

    pub fn partitions_for_parent<'a>(
        &'a self,
        parent: &'a str,
    ) -> impl Iterator<Item = &'a RangePartition> {
        self.partitions
            .values()
            .filter(move |part| part.parent.eq_ignore_ascii_case(parent))
    }
    pub fn partition_key(&self, parent: &str) -> Option<&str> {
        self.partition_keys
            .get(&parent.to_ascii_lowercase())
            .map(String::as_str)
    }
    pub fn mark_partitioned(&mut self, parent: &str, key: &str) -> Result<(), PhobosError> {
        let table = self
            .table(parent)
            .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "partitioned table is missing"))?;
        if table.column_index(key).is_none() {
            return Err(PhobosError::new(
                ErrorCode::NotFound,
                "partition key column is missing",
            ));
        }
        std::sync::Arc::make_mut(&mut self.partition_keys)
            .insert(parent.to_ascii_lowercase(), key.to_string());
        self.persist()
    }
    pub fn partition(&self, child: &str) -> Option<&RangePartition> {
        self.partitions.get(&child.to_ascii_lowercase())
    }
    pub fn add_range_partition(&mut self, partition: RangePartition) -> Result<(), PhobosError> {
        if self.table(&partition.parent).is_none() || self.table(&partition.child).is_none() {
            return Err(PhobosError::new(
                ErrorCode::NotFound,
                "partition table is missing",
            ));
        }
        if partition.lower.canonical_cmp(&partition.upper) != Some(std::cmp::Ordering::Less) {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "partition range must be non-empty",
            ));
        }
        for existing in self.partitions_for_parent(&partition.parent) {
            let disjoint = partition
                .upper
                .canonical_cmp(&existing.lower)
                .is_some_and(|o| o != std::cmp::Ordering::Greater)
                || partition
                    .lower
                    .canonical_cmp(&existing.upper)
                    .is_some_and(|o| o != std::cmp::Ordering::Less);
            if !disjoint {
                return Err(PhobosError::new(
                    ErrorCode::ConstraintViolation,
                    "partition ranges overlap",
                ));
            }
        }
        std::sync::Arc::make_mut(&mut self.partitions)
            .insert(partition.child.to_ascii_lowercase(), partition);
        self.persist()
    }

    pub fn create_index(
        &mut self,
        name: String,
        table_id: TableId,
        columns: Vec<String>,
        unique: bool,
    ) -> Result<IndexSchema, PhobosError> {
        validate_identifier(&name)?;
        if columns.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "index requires at least one column",
            ));
        }
        if !self.tables.values().any(|table| table.id == table_id) {
            return Err(PhobosError::new(
                ErrorCode::NotFound,
                "indexed table does not exist",
            ));
        }
        let table = self
            .tables
            .values()
            .find(|table| table.id == table_id)
            .expect("table checked");
        let mut seen = BTreeMap::<String, ()>::new();
        for column in &columns {
            validate_identifier(column)?;
            if table.column_index(column).is_none() {
                return Err(PhobosError::new(
                    ErrorCode::NotFound,
                    format!("column {column} does not exist"),
                ));
            }
            if seen.insert(column.to_ascii_lowercase(), ()).is_some() {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "duplicate index column",
                ));
            }
        }
        let key = name.to_ascii_lowercase();
        if self.indexes.contains_key(&key) {
            return Err(PhobosError::new(
                ErrorCode::AlreadyExists,
                "index already exists",
            ));
        }
        let schema = IndexSchema {
            id: self.next_index_id,
            name,
            table_id,
            columns,
            unique,
        };
        self.next_index_id = self.next_index_id.checked_add(1).ok_or_else(|| {
            PhobosError::new(ErrorCode::InvalidCatalog, "index identifier exhausted")
        })?;
        std::sync::Arc::make_mut(&mut self.indexes).insert(key.clone(), schema.clone());
        if let Err(error) = self.persist_indexes() {
            std::sync::Arc::make_mut(&mut self.indexes).remove(&key);
            self.next_index_id -= 1;
            return Err(error);
        }
        Ok(schema)
    }

    pub fn drop_index(&mut self, name: &str) -> Result<IndexSchema, PhobosError> {
        if self.index(name).is_some_and(|index| {
            self.definitions.values().any(|d| {
                d.primary_index == Some(index.id)
                    || d.foreign_keys.iter().any(|f| f.parent_index == index.id)
            })
        }) {
            return Err(PhobosError::new(
                ErrorCode::ConstraintViolation,
                "cannot drop an index backing a primary or foreign key",
            ));
        }
        let key = name.to_ascii_lowercase();
        let schema = std::sync::Arc::make_mut(&mut self.indexes)
            .remove(&key)
            .ok_or_else(|| {
                PhobosError::new(ErrorCode::NotFound, format!("index {name} does not exist"))
            })?;
        if let Err(error) = self.persist_indexes() {
            std::sync::Arc::make_mut(&mut self.indexes).insert(key, schema.clone());
            return Err(error);
        }
        Ok(schema)
    }

    /// Rename metadata in a transaction-private catalog. The owner must publish
    /// both catalog files together through its existing schema WAL transaction.
    /// Physical table/index IDs and column ordinals remain unchanged.
    pub fn rename_staged(
        &mut self,
        table: &str,
        column: Option<&str>,
        new_name: &str,
    ) -> Result<TableId, PhobosError> {
        validate_identifier(new_name)?;
        let old = self
            .table(table)
            .cloned()
            .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "table does not exist"))?;
        if self.partition_key(table).is_some() || self.partition(table).is_some() {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "partition renaming is not supported",
            ));
        }
        self.ensure_no_view_dependents(old.id)?;
        let mut renamed = old.clone();
        if let Some(column) = column {
            let ordinal = old
                .column_index(column)
                .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "column does not exist"))?;
            if old.column_index(new_name).is_some() {
                return Err(PhobosError::new(
                    ErrorCode::AlreadyExists,
                    "column already exists",
                ));
            }
            renamed.columns[ordinal].name = new_name.to_owned();
        } else {
            if self.table(new_name).is_some() || self.view(new_name).is_some() {
                return Err(PhobosError::new(
                    ErrorCode::AlreadyExists,
                    "table already exists",
                ));
            }
            renamed.name = new_name.to_owned();
        }
        let before = self.clone();
        let tables = std::sync::Arc::make_mut(&mut self.tables);
        tables.remove(&old.name.to_ascii_lowercase());
        tables.insert(renamed.name.to_ascii_lowercase(), renamed);
        if let Some(column) = column {
            for index in std::sync::Arc::make_mut(&mut self.indexes)
                .values_mut()
                .filter(|i| i.table_id == old.id)
            {
                for name in &mut index.columns {
                    if name.eq_ignore_ascii_case(column) {
                        *name = new_name.to_owned();
                    }
                }
            }
        }
        if let Err(error) = self.persist().and_then(|()| self.persist_indexes()) {
            *self = before;
            return Err(error);
        }
        Ok(old.id)
    }

    pub fn create_table(
        &mut self,
        name: String,
        columns: Vec<ColumnSchema>,
    ) -> Result<TableSchema, PhobosError> {
        validate_identifier(&name)?;
        if columns.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "table must have at least one column",
            ));
        }
        let key = name.to_ascii_lowercase();
        if self.tables.contains_key(&key) || self.views.contains_key(&key) {
            return Err(PhobosError::new(
                ErrorCode::AlreadyExists,
                "table already exists",
            ));
        }
        let mut seen = BTreeMap::<String, ()>::new();
        for column in &columns {
            validate_identifier(&column.name)?;
            let column_key = column.name.to_ascii_lowercase();
            if seen.insert(column_key, ()).is_some() {
                return Err(PhobosError::new(
                    ErrorCode::Semantic,
                    "duplicate column name",
                ));
            }
            if let DataType::Decimal { precision, scale } = &column.data_type {
                if *precision == 0 || *precision > 38 || *scale > *precision {
                    return Err(PhobosError::new(
                        ErrorCode::Semantic,
                        "invalid DECIMAL precision/scale",
                    ));
                }
            }
        }
        let schema = TableSchema {
            id: self.next_table_id,
            name,
            columns,
        };
        self.next_table_id = self.next_table_id.checked_add(1).ok_or_else(|| {
            PhobosError::new(ErrorCode::InvalidCatalog, "table identifier exhausted")
        })?;
        std::sync::Arc::make_mut(&mut self.tables).insert(key.clone(), schema.clone());
        if let Err(error) = self.persist() {
            std::sync::Arc::make_mut(&mut self.tables).remove(&key);
            self.next_table_id -= 1;
            return Err(error);
        }
        Ok(schema)
    }

    fn load_indexes(&mut self) -> Result<(), PhobosError> {
        if !self.index_path.exists() {
            self.next_index_id = 1;
            std::sync::Arc::make_mut(&mut self.indexes).clear();
            return Ok(());
        }
        let mut bytes = Vec::new();
        File::open(&self.index_path)?.read_to_end(&mut bytes)?;
        if bytes.len() < 18 || bytes[0..4] != INDEX_MAGIC {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "invalid index catalog header",
            ));
        }
        if u16::from_le_bytes([bytes[4], bytes[5]]) != INDEX_VERSION {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "unsupported index catalog format",
            ));
        }
        let payload_end = bytes.len() - 4;
        let expected = u32::from_le_bytes(bytes[payload_end..].try_into().expect("checksum"));
        if checksum(&bytes[..payload_end]) != expected {
            return Err(PhobosError::new(
                ErrorCode::ChecksumMismatch,
                "index catalog checksum mismatch",
            ));
        }
        let mut cursor = 6usize;
        self.next_index_id = take_u64(&bytes, &mut cursor, payload_end)?;
        let count = take_u32(&bytes, &mut cursor, payload_end)?;
        std::sync::Arc::make_mut(&mut self.indexes).clear();
        for _ in 0..count {
            let id = take_u64(&bytes, &mut cursor, payload_end)?;
            let name = take_string(&bytes, &mut cursor, payload_end)?;
            let table_id = take_u64(&bytes, &mut cursor, payload_end)?;
            let unique = take_u8(&bytes, &mut cursor, payload_end)? != 0;
            let column_count = take_u16(&bytes, &mut cursor, payload_end)?;
            let mut columns = Vec::with_capacity(usize::from(column_count));
            for _ in 0..column_count {
                columns.push(take_string(&bytes, &mut cursor, payload_end)?);
            }
            std::sync::Arc::make_mut(&mut self.indexes).insert(
                name.to_ascii_lowercase(),
                IndexSchema {
                    id,
                    name,
                    table_id,
                    columns,
                    unique,
                },
            );
        }
        if cursor != payload_end {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "index catalog contains trailing bytes",
            ));
        }
        Ok(())
    }

    fn persist_indexes(&self) -> Result<(), PhobosError> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&INDEX_MAGIC);
        bytes.extend_from_slice(&INDEX_VERSION.to_le_bytes());
        bytes.extend_from_slice(&self.next_index_id.to_le_bytes());
        bytes.extend_from_slice(&(self.indexes.len() as u32).to_le_bytes());
        for index in self.indexes.values() {
            bytes.extend_from_slice(&index.id.to_le_bytes());
            put_string(&mut bytes, &index.name)?;
            bytes.extend_from_slice(&index.table_id.to_le_bytes());
            bytes.push(u8::from(index.unique));
            let count = u16::try_from(index.columns.len()).map_err(|_| {
                PhobosError::new(ErrorCode::InvalidCatalog, "too many index columns")
            })?;
            bytes.extend_from_slice(&count.to_le_bytes());
            for column in &index.columns {
                put_string(&mut bytes, column)?;
            }
        }
        let value = checksum(&bytes);
        bytes.extend_from_slice(&value.to_le_bytes());
        let temp = self.index_path.with_extension("phc.tmp");
        {
            let mut file = OpenOptions::new()
                .create(true)
                .truncate(true)
                .write(true)
                .open(&temp)?;
            file.write_all(&bytes)?;
            phobos_observability::measure("fs.sync_all", || file.sync_all())?;
        }
        if self.index_path.exists() {
            phobos_observability::measure("fs.remove_file", || fs::remove_file(&self.index_path))?;
        }
        phobos_observability::measure("fs.rename", || fs::rename(temp, &self.index_path))?;
        Ok(())
    }

    pub fn format_version(&self) -> u16 {
        let version = if !self.views.is_empty()
            || self
                .definitions
                .values()
                .any(|d| d.identity.is_some() || !d.foreign_keys.is_empty())
        {
            VERSION_IDENTITY
        } else if !self.definitions.is_empty() {
            VERSION_DEFINITIONS
        } else if self.capabilities == 0 {
            VERSION
        } else {
            VERSION_CAPABILITIES
        };
        version.max(self.minimum_version)
    }
    pub fn upgrade_format_staged(&mut self) -> Result<(), PhobosError> {
        let old = self.minimum_version;
        self.minimum_version = VERSION_IDENTITY;
        if let Err(e) = self
            .validate_definitions()
            .and_then(|()| self.validate_views())
            .and_then(|()| self.persist())
        {
            self.minimum_version = old;
            return Err(e);
        }
        Ok(())
    }
    fn persist(&self) -> Result<(), PhobosError> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&MAGIC);
        let version = self.format_version();
        bytes.extend_from_slice(&version.to_le_bytes());
        bytes.extend_from_slice(&self.next_table_id.to_le_bytes());
        bytes.extend_from_slice(&(self.tables.len() as u32).to_le_bytes());
        for schema in self.tables.values() {
            bytes.extend_from_slice(&schema.id.to_le_bytes());
            put_string(&mut bytes, &schema.name)?;
            let count = u16::try_from(schema.columns.len())
                .map_err(|_| PhobosError::new(ErrorCode::InvalidCatalog, "too many columns"))?;
            bytes.extend_from_slice(&count.to_le_bytes());
            for column in &schema.columns {
                put_string(&mut bytes, &column.name)?;
                put_data_type(&mut bytes, &column.data_type);
                bytes.push(u8::from(column.nullable));
            }
        }
        bytes.extend_from_slice(&(self.partition_keys.len() as u32).to_le_bytes());
        for (parent, key) in self.partition_keys.iter() {
            put_string(&mut bytes, parent)?;
            put_string(&mut bytes, key)?;
        }
        bytes.extend_from_slice(&(self.partitions.len() as u32).to_le_bytes());
        for partition in self.partitions.values() {
            put_string(&mut bytes, &partition.parent)?;
            put_string(&mut bytes, &partition.child)?;
            put_string(&mut bytes, &partition.key_column)?;
            put_value(&mut bytes, &partition.lower)?;
            put_value(&mut bytes, &partition.upper)?;
        }
        if version >= VERSION_CAPABILITIES {
            bytes.extend_from_slice(&self.capabilities.to_le_bytes());
        }
        if version >= VERSION_DEFINITIONS {
            definitions::encode(&mut bytes, &self.definitions, version >= VERSION_IDENTITY)?;
        }
        if version >= VERSION_IDENTITY {
            views::encode(&mut bytes, &self.views)?;
        }
        let value = checksum(&bytes);
        bytes.extend_from_slice(&value.to_le_bytes());
        let temp = self.path.with_extension("phc.tmp");
        {
            let mut file = OpenOptions::new()
                .create(true)
                .truncate(true)
                .write(true)
                .open(&temp)?;
            file.write_all(&bytes)?;
            phobos_observability::measure("fs.sync_all", || file.sync_all())?;
        }
        if self.path.exists() {
            phobos_observability::measure("fs.remove_file", || fs::remove_file(&self.path))?;
        }
        phobos_observability::measure("fs.rename", || fs::rename(temp, &self.path))?;
        Ok(())
    }
}

fn validate_identifier(value: &str) -> Result<(), PhobosError> {
    let mut chars = value.chars();
    let Some(first) = chars.next() else {
        return Err(PhobosError::new(ErrorCode::Semantic, "empty identifier"));
    };
    if !(first.is_ascii_alphabetic() || first == '_')
        || !chars.all(|ch| ch.is_ascii_alphanumeric() || ch == '_')
    {
        return Err(PhobosError::new(
            ErrorCode::Semantic,
            "invalid unquoted identifier",
        ));
    }
    Ok(())
}

fn put_string(out: &mut Vec<u8>, value: &str) -> Result<(), PhobosError> {
    let len = u16::try_from(value.len())
        .map_err(|_| PhobosError::new(ErrorCode::InvalidCatalog, "catalog string too long"))?;
    out.extend_from_slice(&len.to_le_bytes());
    out.extend_from_slice(value.as_bytes());
    Ok(())
}

fn put_value(out: &mut Vec<u8>, value: &Value) -> Result<(), PhobosError> {
    match value {
        Value::Null => {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "NULL partition bound",
            ));
        }
        Value::Int64(v) => {
            out.push(1);
            out.extend_from_slice(&v.to_le_bytes());
        }
        Value::Boolean(v) => {
            out.push(2);
            out.push(u8::from(*v));
        }
        Value::Float64(v) => {
            out.push(3);
            out.extend_from_slice(&v.to_bits().to_le_bytes());
        }
        Value::Text(v) => {
            out.push(4);
            put_string(out, v)?;
        }
        Value::Binary(v) => {
            out.push(5);
            let len = u32::try_from(v.len()).map_err(|_| {
                PhobosError::new(ErrorCode::InvalidCatalog, "partition bound too large")
            })?;
            out.extend_from_slice(&len.to_le_bytes());
            out.extend_from_slice(v);
        }
        Value::Date(v) => {
            out.push(6);
            out.extend_from_slice(&v.to_le_bytes());
        }
        Value::Timestamp(v) => {
            out.push(7);
            out.extend_from_slice(&v.to_le_bytes());
        }
        Value::Decimal { unscaled, scale } => {
            out.push(8);
            out.extend_from_slice(&unscaled.to_le_bytes());
            out.push(*scale);
        }
    }
    Ok(())
}

fn take_value(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<Value, PhobosError> {
    Ok(match take_u8(bytes, cursor, end)? {
        1 => Value::Int64(i64::from_le_bytes(take_bytes::<8>(bytes, cursor, end)?)),
        2 => Value::Boolean(take_u8(bytes, cursor, end)? != 0),
        3 => Value::Float64(f64::from_bits(u64::from_le_bytes(take_bytes::<8>(
            bytes, cursor, end,
        )?))),
        4 => Value::Text(take_string(bytes, cursor, end)?),
        5 => {
            let len = take_u32(bytes, cursor, end)? as usize;
            let stop = cursor
                .checked_add(len)
                .filter(|stop| *stop <= end)
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::InvalidCatalog, "truncated partition bound")
                })?;
            let value = bytes[*cursor..stop].to_vec();
            *cursor = stop;
            Value::Binary(value)
        }
        6 => Value::Date(i32::from_le_bytes(take_bytes::<4>(bytes, cursor, end)?)),
        7 => Value::Timestamp(i64::from_le_bytes(take_bytes::<8>(bytes, cursor, end)?)),
        8 => Value::Decimal {
            unscaled: i128::from_le_bytes(take_bytes::<16>(bytes, cursor, end)?),
            scale: take_u8(bytes, cursor, end)?,
        },
        _ => {
            return Err(PhobosError::new(
                ErrorCode::InvalidCatalog,
                "invalid partition bound",
            ));
        }
    })
}

fn take_bytes<const N: usize>(
    bytes: &[u8],
    cursor: &mut usize,
    end: usize,
) -> Result<[u8; N], PhobosError> {
    let stop = cursor
        .checked_add(N)
        .filter(|stop| *stop <= end)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "truncated catalog"))?;
    let value = bytes[*cursor..stop].try_into().expect("sized");
    *cursor = stop;
    Ok(value)
}

fn put_data_type(out: &mut Vec<u8>, data_type: &DataType) {
    match data_type {
        DataType::Int64 => out.push(1),
        DataType::Boolean => out.push(2),
        DataType::Float64 => out.push(3),
        DataType::Text => out.push(4),
        DataType::Binary => out.push(5),
        DataType::Date => out.push(6),
        DataType::Timestamp => out.push(7),
        DataType::Decimal { precision, scale } => {
            out.push(8);
            out.push(*precision);
            out.push(*scale);
        }
    }
}

fn take_data_type(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<DataType, PhobosError> {
    match take_u8(bytes, cursor, end)? {
        1 => Ok(DataType::Int64),
        2 => Ok(DataType::Boolean),
        3 => Ok(DataType::Float64),
        4 => Ok(DataType::Text),
        5 => Ok(DataType::Binary),
        6 => Ok(DataType::Date),
        7 => Ok(DataType::Timestamp),
        8 => Ok(DataType::Decimal {
            precision: take_u8(bytes, cursor, end)?,
            scale: take_u8(bytes, cursor, end)?,
        }),
        _ => Err(PhobosError::new(
            ErrorCode::InvalidCatalog,
            "unknown catalog data type",
        )),
    }
}

fn take_u8(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<u8, PhobosError> {
    if *cursor >= end {
        return Err(PhobosError::new(
            ErrorCode::InvalidCatalog,
            "truncated catalog",
        ));
    }
    let value = bytes[*cursor];
    *cursor += 1;
    Ok(value)
}

fn take_u16(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<u16, PhobosError> {
    let slice = take(bytes, cursor, 2, end)?;
    Ok(u16::from_le_bytes(slice.try_into().expect("u16")))
}

fn take_u32(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<u32, PhobosError> {
    let slice = take(bytes, cursor, 4, end)?;
    Ok(u32::from_le_bytes(slice.try_into().expect("u32")))
}

fn take_u64(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<u64, PhobosError> {
    let slice = take(bytes, cursor, 8, end)?;
    Ok(u64::from_le_bytes(slice.try_into().expect("u64")))
}

fn take_string(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<String, PhobosError> {
    let len = usize::from(take_u16(bytes, cursor, end)?);
    let slice = take(bytes, cursor, len, end)?;
    String::from_utf8(slice.to_vec())
        .map_err(|_| PhobosError::new(ErrorCode::InvalidCatalog, "catalog text is not UTF-8"))
}

fn take<'a>(
    bytes: &'a [u8],
    cursor: &mut usize,
    len: usize,
    end: usize,
) -> Result<&'a [u8], PhobosError> {
    let next = cursor
        .checked_add(len)
        .ok_or_else(|| PhobosError::new(ErrorCode::InvalidCatalog, "catalog offset overflow"))?;
    if next > end {
        return Err(PhobosError::new(
            ErrorCode::InvalidCatalog,
            "truncated catalog",
        ));
    }
    let slice = &bytes[*cursor..next];
    *cursor = next;
    Ok(slice)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_dir() -> PathBuf {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let value = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let sequence = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        std::env::temp_dir().join(format!(
            "phobos-catalog-{}-{value}-{sequence}",
            std::process::id()
        ))
    }

    #[test]
    fn parallel_test_directories_are_unique() {
        let barrier = std::sync::Barrier::new(8);
        let paths = std::thread::scope(|scope| {
            let workers: Vec<_> = (0..8)
                .map(|_| {
                    scope.spawn(|| {
                        barrier.wait();
                        (0..1000).map(|_| temp_dir()).collect::<Vec<_>>()
                    })
                })
                .collect();
            workers
                .into_iter()
                .flat_map(|worker| worker.join().unwrap())
                .collect::<Vec<_>>()
        });
        let unique: std::collections::BTreeSet<_> = paths.iter().collect();
        assert_eq!(
            unique.len(),
            paths.len(),
            "parallel tests must never share a directory"
        );
    }

    #[test]
    fn catalog_survives_restart() {
        let dir = temp_dir();
        {
            let mut catalog = Catalog::open(&dir).unwrap();
            catalog
                .create_table(
                    "people".to_string(),
                    vec![ColumnSchema {
                        name: "id".to_string(),
                        data_type: DataType::Int64,
                        nullable: false,
                    }],
                )
                .unwrap();
        }
        let catalog = Catalog::open(&dir).unwrap();
        assert_eq!(catalog.table("PEOPLE").unwrap().columns.len(), 1);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn catalog_detects_corruption() {
        let dir = temp_dir();
        let path = dir.join("catalog.phc");
        let _catalog = Catalog::open(&dir).unwrap();
        let mut bytes = fs::read(&path).unwrap();
        bytes[7] ^= 0x20;
        fs::write(&path, bytes).unwrap();
        assert_eq!(
            Catalog::open(&dir).unwrap_err().code,
            ErrorCode::ChecksumMismatch
        );
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn index_catalog_survives_restart() {
        let dir = temp_dir();
        let table_id;
        {
            let mut catalog = Catalog::open(&dir).unwrap();
            let table = catalog
                .create_table(
                    "people".to_string(),
                    vec![ColumnSchema {
                        name: "id".to_string(),
                        data_type: DataType::Int64,
                        nullable: false,
                    }],
                )
                .unwrap();
            table_id = table.id;
            catalog
                .create_index("ix_people_id".into(), table.id, vec!["id".into()], true)
                .unwrap();
        }
        let mut catalog = Catalog::open(&dir).unwrap();
        let index = catalog.index("IX_PEOPLE_ID").unwrap();
        assert_eq!(index.table_id, table_id);
        assert!(index.unique);
        catalog.drop_index("ix_people_id").unwrap();
        assert!(catalog.index("ix_people_id").is_none());
        let _ = fs::remove_dir_all(dir);
    }
}

#[cfg(test)]
mod capability_tests {
    use super::*;

    fn dir(tag: &str) -> PathBuf {
        let path = std::env::temp_dir().join(format!("phobos-k4-cap-{tag}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&path);
        path
    }

    #[test]
    fn k4_capability_round_trips_and_unknown_bits_are_refused() {
        let root = dir("rt");
        let mut catalog = Catalog::open(&root).unwrap();
        assert_eq!(catalog.capabilities(), 0);
        let bytes = fs::read(root.join("catalog.phc")).unwrap();
        assert_eq!(
            u16::from_le_bytes([bytes[4], bytes[5]]),
            VERSION,
            "old-compatible until enabled"
        );
        catalog
            .enable_capabilities(CAPABILITY_LAZY_INDEX_PRUNING_V1)
            .unwrap();
        let bytes = fs::read(root.join("catalog.phc")).unwrap();
        assert_eq!(
            u16::from_le_bytes([bytes[4], bytes[5]]),
            VERSION_CAPABILITIES
        );
        let reopened = Catalog::open(&root).unwrap();
        assert!(reopened.lazy_index_pruning());
        // A future capability bit this binary does not know: explicit refusal.
        let mut future = bytes.clone();
        let flags = future.len() - 8;
        future[flags..flags + 4]
            .copy_from_slice(&(CAPABILITY_LAZY_INDEX_PRUNING_V1 | 0x8).to_le_bytes());
        let end = future.len() - 4;
        let sum = checksum(&future[..end]);
        future[end..].copy_from_slice(&sum.to_le_bytes());
        fs::write(root.join("catalog.phc"), &future).unwrap();
        let error = Catalog::open(&root).unwrap_err();
        assert_eq!(error.code, ErrorCode::Unsupported);
        assert!(
            error.message.contains("does not support"),
            "{}",
            error.message
        );
        // What a pre-0.2-K.4 binary sees: a version it does not accept.
        let version = u16::from_le_bytes([bytes[4], bytes[5]]);
        assert!(version != 1 && version != 2);
        assert!(catalog.enable_capabilities(0x8).is_err());
        fs::remove_dir_all(root).unwrap();
    }
}
