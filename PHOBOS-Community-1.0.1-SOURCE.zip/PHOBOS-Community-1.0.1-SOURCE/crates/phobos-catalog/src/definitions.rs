//! Version 4 schema definitions. Column ordinals survive table/column rename.
//! Future definition kinds require an explicit format version; unknown tags fail closed.
use super::*;
use phobos_types::Row;

#[derive(Debug, Clone, Default, PartialEq)]
pub struct SchemaDefinitions {
    pub defaults: BTreeMap<usize, Value>,
    pub checks: Vec<CheckDefinition>,
    pub primary_index: Option<IndexId>,
    pub identity: Option<IdentityDefinition>,
    pub foreign_keys: Vec<ForeignKeyDefinition>,
}
#[derive(Debug, Clone, PartialEq)]
pub struct ForeignKeyDefinition {
    pub columns: Vec<usize>,
    pub parent_table: TableId,
    pub parent_columns: Vec<usize>,
    pub parent_index: IndexId,
}
#[derive(Debug, Clone, PartialEq)]
pub struct IdentityDefinition {
    pub column: usize,
    pub sequence_table: TableId,
    pub always: bool,
}
#[derive(Debug, Clone, PartialEq)]
pub struct CheckDefinition {
    pub column: usize,
    /// 0 =, 1 <>, 2 <, 3 <=, 4 >, 5 >=, 6 IS NULL, 7 IS NOT NULL.
    pub operator: u8,
    pub value: Value,
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidCatalog, message)
}
impl SchemaDefinitions {
    pub fn validate_row(&self, row: &Row) -> Result<(), PhobosError> {
        for (i, check) in self.checks.iter().enumerate() {
            let value = row
                .values
                .get(check.column)
                .ok_or_else(|| invalid("CHECK column out of bounds"))?;
            let passes = match check.operator {
                6 => value.is_null(),
                7 => !value.is_null(),
                0..=5 if value.is_null() || check.value.is_null() => true,
                op @ 0..=5 => {
                    let cmp = value
                        .canonical_cmp(&check.value)
                        .ok_or_else(|| invalid("incomparable CHECK operands"))?;
                    use std::cmp::Ordering::*;
                    match op {
                        0 => cmp == Equal,
                        1 => cmp != Equal,
                        2 => cmp == Less,
                        3 => cmp != Greater,
                        4 => cmp == Greater,
                        _ => cmp != Less,
                    }
                }
                _ => return Err(invalid("unknown CHECK operator")),
            };
            if !passes {
                return Err(PhobosError::new(
                    ErrorCode::ConstraintViolation,
                    format!("CHECK constraint {} violated", i + 1),
                ));
            }
        }
        Ok(())
    }
}
impl Catalog {
    pub fn definitions(&self, table: TableId) -> Option<&SchemaDefinitions> {
        self.definitions.get(&table)
    }
    pub fn set_definitions(
        &mut self,
        table: TableId,
        definition: SchemaDefinitions,
    ) -> Result<(), PhobosError> {
        let before = self.definitions.clone();
        Arc::make_mut(&mut self.definitions).insert(table, definition);
        if let Err(error) = self.validate_definitions().and_then(|()| self.persist()) {
            self.definitions = before;
            return Err(error);
        }
        Ok(())
    }
    pub fn validate_row_definitions(&self, table: TableId, row: &Row) -> Result<(), PhobosError> {
        if let Some(definition) = self.definitions(table) {
            definition.validate_row(row)?;
        }
        Ok(())
    }
    pub fn validate_definitions(&self) -> Result<(), PhobosError> {
        for (id, definition) in self.definitions.iter() {
            let table = self
                .tables()
                .find(|t| t.id == *id)
                .ok_or_else(|| invalid("schema definition table missing"))?;
            if self.partition_key(&table.name).is_some() || self.partition(&table.name).is_some() {
                return Err(invalid("partition schema definitions unsupported"));
            }
            for (ordinal, value) in &definition.defaults {
                let column = table
                    .columns
                    .get(*ordinal)
                    .ok_or_else(|| invalid("default column missing"))?;
                if value.is_null() {
                    if !column.nullable {
                        return Err(invalid("NULL default on NOT NULL column"));
                    }
                } else if !value_matches_type(value, &column.data_type) {
                    return Err(invalid("default type mismatch"));
                }
            }
            for check in &definition.checks {
                let column = table
                    .columns
                    .get(check.column)
                    .ok_or_else(|| invalid("CHECK column missing"))?;
                if check.operator > 7 {
                    return Err(invalid("unknown CHECK operator"));
                }
                if !check.value.is_null()
                    && check.value.key_class() != Some(column.data_type.key_class())
                {
                    return Err(invalid("CHECK type mismatch"));
                }
                if check.operator >= 6 && !check.value.is_null() {
                    return Err(invalid("invalid NULL CHECK operand"));
                }
            }
            if let Some(identity) = &definition.identity {
                let col = table
                    .columns
                    .get(identity.column)
                    .ok_or_else(|| invalid("identity column missing"))?;
                if col.data_type != DataType::Int64
                    || col.nullable
                    || definition.defaults.contains_key(&identity.column)
                {
                    return Err(invalid("invalid identity column"));
                }
                let seq = self
                    .tables()
                    .find(|t| t.id == identity.sequence_table)
                    .ok_or_else(|| invalid("identity allocator missing"))?;
                if seq.name != format!("__phobos_sequence_{}", table.id)
                    || seq.columns.len() != 2
                    || seq.columns[0].name != "singleton"
                    || seq.columns[1].name != "next_value"
                    || seq
                        .columns
                        .iter()
                        .any(|c| c.data_type != DataType::Int64 || c.nullable)
                    || !self
                        .indexes_for_table(seq.id)
                        .any(|i| i.unique && i.columns == vec!["singleton".to_string()])
                {
                    return Err(invalid("invalid identity allocator schema"));
                }
            }
            for fk in &definition.foreign_keys {
                let parent = self
                    .tables()
                    .find(|t| t.id == fk.parent_table)
                    .ok_or_else(|| invalid("FK parent missing"))?;
                let index = self
                    .indexes()
                    .find(|i| i.id == fk.parent_index)
                    .ok_or_else(|| invalid("FK parent index missing"))?;
                if fk.columns.is_empty()
                    || fk.columns.len() != fk.parent_columns.len()
                    || !index.unique
                    || index.table_id != parent.id
                    || self.partition_key(&parent.name).is_some()
                    || self.partition(&parent.name).is_some()
                {
                    return Err(invalid("invalid FK definition"));
                }
                let mut seen = std::collections::BTreeSet::new();
                for (&c, &p) in fk.columns.iter().zip(&fk.parent_columns) {
                    let child = table
                        .columns
                        .get(c)
                        .ok_or_else(|| invalid("FK child column missing"))?;
                    let parent = parent
                        .columns
                        .get(p)
                        .ok_or_else(|| invalid("FK parent column missing"))?;
                    if !seen.insert(c) || child.data_type != parent.data_type {
                        return Err(invalid("FK column type mismatch or duplicate"));
                    }
                }
                if index
                    .columns
                    .iter()
                    .map(|n| parent.column_index(n))
                    .collect::<Option<Vec<_>>>()
                    .as_ref()
                    != Some(&fk.parent_columns)
                {
                    return Err(invalid("FK parent key differs from backing index"));
                }
            }
            if let Some(index_id) = definition.primary_index {
                let index = self
                    .indexes()
                    .find(|i| i.id == index_id)
                    .ok_or_else(|| invalid("primary key backing index missing"))?;
                if index.table_id != *id
                    || !index.unique
                    || index.columns.is_empty()
                    || index.columns.iter().any(|c| {
                        table
                            .column_index(c)
                            .is_none_or(|p| table.columns[p].nullable)
                    })
                {
                    return Err(invalid("invalid primary key backing index"));
                }
            }
        }
        Ok(())
    }
}
fn put_optional_value(out: &mut Vec<u8>, value: &Value) -> Result<(), PhobosError> {
    out.push(u8::from(!value.is_null()));
    if !value.is_null() {
        put_value(out, value)?;
    }
    Ok(())
}
fn take_optional_value(bytes: &[u8], cursor: &mut usize, end: usize) -> Result<Value, PhobosError> {
    match take_u8(bytes, cursor, end)? {
        0 => Ok(Value::Null),
        1 => take_value(bytes, cursor, end),
        _ => Err(invalid("invalid nullable value tag")),
    }
}
pub(super) fn encode(
    out: &mut Vec<u8>,
    definitions: &BTreeMap<TableId, SchemaDefinitions>,
    identity_format: bool,
) -> Result<(), PhobosError> {
    out.extend_from_slice(&(definitions.len() as u32).to_le_bytes());
    for (id, d) in definitions {
        out.extend_from_slice(&id.to_le_bytes());
        out.extend_from_slice(&(d.defaults.len() as u32).to_le_bytes());
        for (col, val) in &d.defaults {
            out.extend_from_slice(&(*col as u32).to_le_bytes());
            put_optional_value(out, val)?;
        }
        out.extend_from_slice(&(d.checks.len() as u32).to_le_bytes());
        for c in &d.checks {
            out.extend_from_slice(&(c.column as u32).to_le_bytes());
            out.push(c.operator);
            put_optional_value(out, &c.value)?;
        }
        out.extend_from_slice(&d.primary_index.unwrap_or(0).to_le_bytes());
        if identity_format {
            out.extend_from_slice(&(d.foreign_keys.len() as u32).to_le_bytes());
            for fk in &d.foreign_keys {
                out.extend_from_slice(&fk.parent_table.to_le_bytes());
                out.extend_from_slice(&fk.parent_index.to_le_bytes());
                out.extend_from_slice(&(fk.columns.len() as u32).to_le_bytes());
                for (&c, &p) in fk.columns.iter().zip(&fk.parent_columns) {
                    out.extend_from_slice(&(c as u32).to_le_bytes());
                    out.extend_from_slice(&(p as u32).to_le_bytes());
                }
            }
            out.push(u8::from(d.identity.is_some()));
            if let Some(i) = &d.identity {
                out.extend_from_slice(&(i.column as u32).to_le_bytes());
                out.extend_from_slice(&i.sequence_table.to_le_bytes());
                out.push(u8::from(i.always));
            }
        }
    }
    Ok(())
}
pub(super) fn decode(
    bytes: &[u8],
    cursor: &mut usize,
    end: usize,
    identity_format: bool,
) -> Result<BTreeMap<TableId, SchemaDefinitions>, PhobosError> {
    let count = take_u32(bytes, cursor, end)?;
    let mut definitions = BTreeMap::new();
    for _ in 0..count {
        let id = take_u64(bytes, cursor, end)?;
        let mut d = SchemaDefinitions::default();
        let n = take_u32(bytes, cursor, end)?;
        for _ in 0..n {
            let col = take_u32(bytes, cursor, end)? as usize;
            let value = take_optional_value(bytes, cursor, end)?;
            if d.defaults.insert(col, value).is_some() {
                return Err(invalid("duplicate default"));
            }
        }
        let n = take_u32(bytes, cursor, end)?;
        for _ in 0..n {
            let column = take_u32(bytes, cursor, end)? as usize;
            let operator = take_u8(bytes, cursor, end)?;
            let value = take_optional_value(bytes, cursor, end)?;
            d.checks.push(CheckDefinition {
                column,
                operator,
                value,
            });
        }
        let index = take_u64(bytes, cursor, end)?;
        d.primary_index = if index == 0 { None } else { Some(index) };
        if identity_format {
            let count = take_u32(bytes, cursor, end)?;
            for _ in 0..count {
                let parent_table = take_u64(bytes, cursor, end)?;
                let parent_index = take_u64(bytes, cursor, end)?;
                let width = take_u32(bytes, cursor, end)?;
                let mut columns = Vec::new();
                let mut parent_columns = Vec::new();
                for _ in 0..width {
                    columns.push(take_u32(bytes, cursor, end)? as usize);
                    parent_columns.push(take_u32(bytes, cursor, end)? as usize);
                }
                d.foreign_keys.push(ForeignKeyDefinition {
                    columns,
                    parent_table,
                    parent_columns,
                    parent_index,
                });
            }
            match take_u8(bytes, cursor, end)? {
                0 => {}
                1 => {
                    let column = take_u32(bytes, cursor, end)? as usize;
                    let sequence_table = take_u64(bytes, cursor, end)?;
                    let always = match take_u8(bytes, cursor, end)? {
                        0 => false,
                        1 => true,
                        _ => return Err(invalid("invalid identity mode")),
                    };
                    d.identity = Some(IdentityDefinition {
                        column,
                        sequence_table,
                        always,
                    });
                }
                _ => return Err(invalid("invalid identity tag")),
            }
        }
        if definitions.insert(id, d).is_some() {
            return Err(invalid("duplicate schema definition"));
        }
    }
    Ok(definitions)
}

fn value_matches_type(value: &Value, ty: &DataType) -> bool {
    match (value, ty) {
        (Value::Int64(_), DataType::Int64)
        | (Value::Boolean(_), DataType::Boolean)
        | (Value::Float64(_), DataType::Float64)
        | (Value::Text(_), DataType::Text)
        | (Value::Binary(_), DataType::Binary)
        | (Value::Date(_), DataType::Date)
        | (Value::Timestamp(_), DataType::Timestamp) => true,
        (
            Value::Decimal { unscaled, scale },
            DataType::Decimal {
                precision,
                scale: target,
            },
        ) => {
            (1..=38).contains(precision)
                && scale <= precision
                && scale == target
                && unscaled.unsigned_abs() < 10u128.pow(u32::from(*precision))
        }
        _ => false,
    }
}

impl Catalog {
    pub fn has_foreign_keys(&self) -> bool {
        self.definitions
            .values()
            .any(|d| !d.foreign_keys.is_empty())
    }
    pub fn validate_foreign_key_rows(
        &self,
        mut read: impl FnMut(TableId) -> Result<Vec<Row>, PhobosError>,
    ) -> Result<(), PhobosError> {
        let key = |row: &Row, columns: &[usize]| -> Option<Vec<Vec<u8>>> {
            columns
                .iter()
                .map(|i| {
                    row.values
                        .get(*i)
                        .filter(|v| !v.is_null())
                        .map(Value::canonical_key)
                })
                .collect()
        };
        for (&table, d) in self.definitions.iter() {
            for fk in &d.foreign_keys {
                let parents = read(fk.parent_table)?
                    .iter()
                    .filter_map(|r| key(r, &fk.parent_columns))
                    .collect::<std::collections::HashSet<_>>();
                for row in read(table)? {
                    phobos_error::cancellation::check_now()?;
                    if key(&row, &fk.columns).is_some_and(|k| !parents.contains(&k)) {
                        return Err(PhobosError::new(
                            ErrorCode::ConstraintViolation,
                            format!(
                                "FOREIGN KEY on table {table} requires parent {} (RESTRICT)",
                                fk.parent_table
                            ),
                        ));
                    }
                }
            }
        }
        Ok(())
    }
}

impl Catalog {
    pub fn alter_nullable_staged(
        &mut self,
        table: &str,
        column: &str,
        nullable: bool,
    ) -> Result<TableId, PhobosError> {
        let before = self.clone();
        let key = table.to_ascii_lowercase();
        let t = Arc::make_mut(&mut self.tables)
            .get_mut(&key)
            .ok_or_else(|| invalid("table missing"))?;
        let ordinal = t
            .column_index(column)
            .ok_or_else(|| invalid("column missing"))?;
        let id = t.id;
        t.columns[ordinal].nullable = nullable;
        if let Err(e) = self.validate_definitions().and_then(|()| self.persist()) {
            *self = before;
            return Err(e);
        }
        Ok(id)
    }
    pub fn add_column_staged(
        &mut self,
        table: &str,
        column: ColumnSchema,
        default: Option<Value>,
    ) -> Result<TableId, PhobosError> {
        validate_identifier(&column.name)?;
        let existing = self.table(table).ok_or_else(|| invalid("table missing"))?;
        self.ensure_no_view_dependents(existing.id)?;
        let before = self.clone();
        let key = table.to_ascii_lowercase();
        let t = Arc::make_mut(&mut self.tables)
            .get_mut(&key)
            .ok_or_else(|| invalid("table missing"))?;
        if t.column_index(&column.name).is_some() {
            return Err(PhobosError::new(ErrorCode::AlreadyExists, "column exists"));
        }
        let id = t.id;
        let ordinal = t.columns.len();
        t.columns.push(column);
        if let Some(value) = default {
            Arc::make_mut(&mut self.definitions)
                .entry(id)
                .or_default()
                .defaults
                .insert(ordinal, value);
        }
        if let Err(e) = self.validate_definitions().and_then(|()| self.persist()) {
            *self = before;
            return Err(e);
        }
        Ok(id)
    }
}

impl Catalog {
    /// Integrity validation for hidden transactional identity allocators.
    pub fn validate_identity_rows(
        &self,
        mut rows: impl FnMut(u64) -> Result<Vec<Row>, PhobosError>,
    ) -> Result<(), PhobosError> {
        for table in self.tables() {
            let Some(identity) = self.definitions(table.id).and_then(|d| d.identity.as_ref())
            else {
                continue;
            };
            let counter = rows(identity.sequence_table)?;
            let next = match counter.as_slice() {
                [] => 1,
                [row] => match row.values.as_slice() {
                    [Value::Int64(1), Value::Int64(n)] if *n > 0 => *n,
                    _ => return Err(invalid("invalid identity allocator contents")),
                },
                _ => return Err(invalid("multiple identity allocator rows")),
            };
            if identity.always && rows(table.id)?.iter().any(|r|!matches!(r.values.get(identity.column),Some(Value::Int64(n)) if *n>0 && *n<next)) {return Err(invalid("ALWAYS identity row exceeds committed allocator state"));}
        }
        Ok(())
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn schema_v2_catalog_migration_corruption_and_unknown_versions() {
        let root = std::env::temp_dir().join(format!(
            "phobos-definitions-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut catalog = Catalog::open(&root).unwrap();
        let table = catalog
            .create_table(
                "t".into(),
                vec![ColumnSchema {
                    name: "n".into(),
                    data_type: DataType::Int64,
                    nullable: true,
                }],
            )
            .unwrap();
        let old = fs::read(root.join("catalog.phc")).unwrap();
        assert_eq!(old[4], 2);
        let mut d = SchemaDefinitions::default();
        d.defaults.insert(0, Value::Int64(7));
        d.checks.push(CheckDefinition {
            column: 0,
            operator: 5,
            value: Value::Int64(0),
        });
        catalog.set_definitions(table.id, d.clone()).unwrap();
        drop(catalog);
        let mut catalog = Catalog::open(&root).unwrap();
        assert_eq!(catalog.definitions(table.id), Some(&d));
        let mut bad = d.clone();
        bad.primary_index = Some(99);
        assert!(catalog.set_definitions(table.id, bad).is_err());
        let mut bad = d.clone();
        bad.defaults.insert(1, Value::Int64(1));
        assert!(catalog.set_definitions(table.id, bad).is_err());
        let mut bad = d.clone();
        bad.defaults.insert(0, Value::Float64(1.0));
        assert!(catalog.set_definitions(table.id, bad).is_err());
        let mut bad = d.clone();
        bad.checks[0].operator = 99;
        assert!(catalog.set_definitions(table.id, bad).is_err());
        let mut bad = d.clone();
        bad.checks[0].column = 1;
        assert!(catalog.set_definitions(table.id, bad).is_err());
        assert_eq!(catalog.definitions(table.id), Some(&d));
        drop(catalog);
        let valid = fs::read(root.join("catalog.phc")).unwrap();
        // Valid checksums do not excuse malformed semantic references.
        for kind in 0..3 {
            let mut corrupt = Catalog::open(&root).unwrap();
            let d = Arc::make_mut(&mut corrupt.definitions)
                .get_mut(&table.id)
                .unwrap();
            match kind {
                0 => d.checks[0].column = 999,
                1 => d.checks[0].operator = 255,
                _ => d.primary_index = Some(999),
            }
            corrupt.persist().unwrap();
            drop(corrupt);
            assert!(Catalog::open(&root).is_err());
            fs::write(root.join("catalog.phc"), &valid).unwrap();
        }

        for version in [5u16, 65535] {
            let mut bad = valid.clone();
            bad[4..6].copy_from_slice(&version.to_le_bytes());
            let n = bad.len() - 4;
            let sum = checksum(&bad[..n]);
            bad[n..].copy_from_slice(&sum.to_le_bytes());
            fs::write(root.join("catalog.phc"), bad).unwrap();
            assert!(Catalog::open(&root).is_err());
        }
        for n in 0..valid.len() {
            fs::write(root.join("catalog.phc"), &valid[..n]).unwrap();
            assert!(Catalog::open(&root).is_err());
        }
        fs::write(root.join("catalog.phc"), &valid).unwrap();
        assert!(Catalog::open(&root).is_ok());
        fs::remove_dir_all(root).unwrap();
    }
}
