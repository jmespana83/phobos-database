//! Durable read-only view definitions. Physical table IDs are never reused.
use super::*;
#[derive(Debug, Clone, PartialEq)]
pub struct ViewDefinition {
    pub id: TableId,
    pub name: String,
    pub sql: String,
    pub columns: Vec<ColumnSchema>,
    pub dependencies: Vec<TableId>,
}
fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidCatalog, message)
}
impl Catalog {
    pub fn views(&self) -> impl Iterator<Item = &ViewDefinition> {
        self.views.values()
    }
    pub fn view(&self, name: &str) -> Option<&ViewDefinition> {
        self.views.get(&name.to_ascii_lowercase())
    }
    pub fn ensure_no_view_dependents(&self, id: TableId) -> Result<(), PhobosError> {
        if self.views().any(|v| v.dependencies.contains(&id)) {
            return Err(PhobosError::new(
                ErrorCode::ConstraintViolation,
                "dependent view must be dropped before changing this object",
            ));
        }
        Ok(())
    }
    pub fn create_view_staged(
        &mut self,
        name: String,
        sql: String,
        columns: Vec<ColumnSchema>,
        dependencies: Vec<TableId>,
    ) -> Result<(), PhobosError> {
        validate_identifier(&name)?;
        if self.table(&name).is_some() || self.view(&name).is_some() {
            return Err(PhobosError::new(
                ErrorCode::AlreadyExists,
                "table or view exists",
            ));
        }
        let before = self.clone();
        let id = self.next_table_id;
        self.next_table_id = id
            .checked_add(1)
            .ok_or_else(|| invalid("object id exhausted"))?;
        Arc::make_mut(&mut self.views).insert(
            name.to_ascii_lowercase(),
            ViewDefinition {
                id,
                name,
                sql,
                columns,
                dependencies,
            },
        );
        if let Err(e) = self.validate_views().and_then(|()| self.persist()) {
            *self = before;
            return Err(e);
        }
        Ok(())
    }
    pub fn drop_view_staged(&mut self, name: &str) -> Result<(), PhobosError> {
        let view = self
            .view(name)
            .ok_or_else(|| PhobosError::new(ErrorCode::NotFound, "view does not exist"))?;
        self.ensure_no_view_dependents(view.id)?;
        let before = self.clone();
        Arc::make_mut(&mut self.views).remove(&name.to_ascii_lowercase());
        if let Err(e) = self.persist() {
            *self = before;
            return Err(e);
        }
        Ok(())
    }
    pub fn validate_views(&self) -> Result<(), PhobosError> {
        let mut ids = self
            .tables()
            .map(|t| t.id)
            .collect::<std::collections::BTreeSet<_>>();
        for v in self.views() {
            validate_identifier(&v.name)?;
            if self.table(&v.name).is_some()
                || !ids.insert(v.id)
                || v.id == 0
                || v.id >= self.next_table_id
                || v.columns.is_empty()
                || v.sql.is_empty()
                || v.sql.len() > 1024 * 1024
            {
                return Err(invalid("invalid view definition"));
            }
            let mut columns = std::collections::BTreeSet::new();
            for c in &v.columns {
                validate_identifier(&c.name)?;
                if !columns.insert(c.name.to_ascii_lowercase()) {
                    return Err(invalid("duplicate view column; use AS"));
                }
            }
        }
        fn visit(
            c: &Catalog,
            id: TableId,
            path: &mut Vec<TableId>,
            memo: &mut BTreeMap<TableId, usize>,
        ) -> Result<usize, PhobosError> {
            if let Some(depth) = memo.get(&id) {
                return Ok(*depth);
            }
            if path.contains(&id) {
                return Err(invalid("view dependency cycle"));
            }
            let mut depth = 0;
            if let Some(v) = c.views().find(|v| v.id == id) {
                path.push(id);
                for d in &v.dependencies {
                    depth = depth.max(visit(c, *d, path, memo)?);
                }
                path.pop();
                depth += 1;
            }
            if depth > 32 {
                return Err(invalid("view dependency depth exceeds 32"));
            }
            memo.insert(id, depth);
            Ok(depth)
        }
        let mut memo = BTreeMap::new();
        for v in self.views() {
            let mut seen = std::collections::BTreeSet::new();
            for d in &v.dependencies {
                if !ids.contains(d) || !seen.insert(*d) {
                    return Err(invalid("missing or duplicate view dependency"));
                }
            }
            visit(self, v.id, &mut Vec::new(), &mut memo)?;
        }
        Ok(())
    }
}
pub(super) fn encode(
    out: &mut Vec<u8>,
    views: &BTreeMap<String, ViewDefinition>,
) -> Result<(), PhobosError> {
    out.extend_from_slice(&(views.len() as u32).to_le_bytes());
    for v in views.values() {
        out.extend_from_slice(&v.id.to_le_bytes());
        put_string(out, &v.name)?;
        put_string(out, &v.sql)?;
        out.extend_from_slice(&(v.columns.len() as u32).to_le_bytes());
        for c in &v.columns {
            put_string(out, &c.name)?;
            put_data_type(out, &c.data_type);
            out.push(u8::from(c.nullable));
        }
        out.extend_from_slice(&(v.dependencies.len() as u32).to_le_bytes());
        for d in &v.dependencies {
            out.extend_from_slice(&d.to_le_bytes());
        }
    }
    Ok(())
}
pub(super) fn decode(
    bytes: &[u8],
    cursor: &mut usize,
    end: usize,
) -> Result<BTreeMap<String, ViewDefinition>, PhobosError> {
    let count = take_u32(bytes, cursor, end)?;
    let mut views = BTreeMap::new();
    for _ in 0..count {
        let id = take_u64(bytes, cursor, end)?;
        let name = take_string(bytes, cursor, end)?;
        let sql = take_string(bytes, cursor, end)?;
        let width = take_u32(bytes, cursor, end)?;
        let mut columns = Vec::new();
        for _ in 0..width {
            let name = take_string(bytes, cursor, end)?;
            let data_type = take_data_type(bytes, cursor, end)?;
            let nullable = match take_u8(bytes, cursor, end)? {
                0 => false,
                1 => true,
                _ => return Err(invalid("invalid view nullability")),
            };
            columns.push(ColumnSchema {
                name,
                data_type,
                nullable,
            });
        }
        let count = take_u32(bytes, cursor, end)?;
        let mut dependencies = Vec::new();
        for _ in 0..count {
            dependencies.push(take_u64(bytes, cursor, end)?);
        }
        if views
            .insert(
                name.to_ascii_lowercase(),
                ViewDefinition {
                    id,
                    name,
                    sql,
                    columns,
                    dependencies,
                },
            )
            .is_some()
        {
            return Err(invalid("duplicate view"));
        }
    }
    Ok(views)
}
