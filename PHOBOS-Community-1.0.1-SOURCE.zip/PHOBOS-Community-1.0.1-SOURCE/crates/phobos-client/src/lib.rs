#![forbid(unsafe_code)]
//! Official Rust client with Phase 7 authentication, metrics, and TLS certificate validation.

use phobos_error::{ErrorCode, PhobosError};
pub use phobos_protocol::streaming::Event as StreamEvent;
use phobos_protocol::streaming::{CAPABILITY, State};
use phobos_protocol::{Frame, MessageType};
use rustls::{
    ClientConfig, ClientConnection, RootCertStore, StreamOwned,
    pki_types::{CertificateDer, PrivateKeyDer, ServerName},
};
use std::{
    fs::File,
    io::{BufReader, Read, Write},
    net::{TcpStream, ToSocketAddrs},
    path::Path,
    sync::Arc,
    time::Duration,
};

enum Transport {
    Plain(TcpStream),
    Tls(Box<StreamOwned<ClientConnection, TcpStream>>),
}

impl Read for Transport {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        match self {
            Self::Plain(s) => s.read(buf),
            Self::Tls(s) => s.read(buf),
        }
    }
}
impl Write for Transport {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        match self {
            Self::Plain(s) => s.write(buf),
            Self::Tls(s) => s.write(buf),
        }
    }
    fn flush(&mut self) -> std::io::Result<()> {
        match self {
            Self::Plain(s) => s.flush(),
            Self::Tls(s) => s.flush(),
        }
    }
}

pub struct Client {
    stream: Transport,
    next_request_id: u32,
    streaming: bool,
    poisoned: bool,
}

impl Client {
    /// One atomic import over bounded acknowledged chunks. Iterator/encoding
    /// errors roll back; a lost COMMIT response retains ordinary uncertain-outcome semantics.
    pub fn bulk_load(
        &mut self,
        table: &str,
        rows: impl IntoIterator<Item = Result<phobos_types::Row, PhobosError>>,
    ) -> Result<u64, PhobosError> {
        let hello = self.handshake()?;
        if !hello.split(';').any(|part| part == "bulk=1") {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "bulk capability unavailable",
            ));
        }
        self.bulk_begin(table)?;
        let result = (|| {
            let mut batch = Vec::new();
            let mut count = 0;
            for row in rows {
                let row = row?;
                let size = row.values.iter().fold(0usize, |size, value| {
                    size.saturating_add(std::mem::size_of_val(value))
                        .saturating_add(match value {
                            phobos_types::Value::Text(text) => text.len(),
                            phobos_types::Value::Binary(bytes) => bytes.len(),
                            _ => 0,
                        })
                });
                if size > 64 * 1024 {
                    return Err(PhobosError::new(
                        ErrorCode::ResourceLimit,
                        "bulk input row limit",
                    ));
                }
                batch.push(row);
                if batch.len() == 64 {
                    count = self.bulk_batch(&batch)?;
                    batch.clear();
                }
            }
            if !batch.is_empty() {
                count = self.bulk_batch(&batch)?;
            }
            self.query("COMMIT")?;
            Ok(count)
        })();
        if result.is_err() {
            let _ = self.query("ROLLBACK");
        }
        result
    }
    pub fn bulk_begin(&mut self, table: &str) -> Result<(), PhobosError> {
        self.request_text(
            MessageType::BulkBegin,
            MessageType::QueryResult,
            table.as_bytes().to_vec(),
        )
        .map(|_| ())
    }
    pub fn bulk_batch(&mut self, rows: &[phobos_types::Row]) -> Result<u64, PhobosError> {
        let result = (|| {
            if rows.is_empty() || rows.len() > phobos_protocol::streaming::BATCH_ROWS {
                return Err(PhobosError::new(
                    ErrorCode::ResourceLimit,
                    "bulk chunk row limit",
                ));
            }
            let bytes = rows
                .iter()
                .flat_map(|row| &row.values)
                .fold(0usize, |size, value| {
                    size.saturating_add(std::mem::size_of_val(value))
                        .saturating_add(match value {
                            phobos_types::Value::Text(text) => text.len(),
                            phobos_types::Value::Binary(bytes) => bytes.len(),
                            _ => 0,
                        })
                });
            if bytes > phobos_protocol::MAX_PAYLOAD {
                return Err(PhobosError::new(
                    ErrorCode::ResourceLimit,
                    "bulk chunk memory limit",
                ));
            }
            let frame = StreamEvent::Rows {
                sequence: 0,
                rows: rows.to_vec(),
            }
            .frame(0)?;
            self.request_text(
                MessageType::BulkRows,
                MessageType::QueryResult,
                frame.payload,
            )?
            .parse()
            .map_err(|_| PhobosError::new(ErrorCode::InvalidProtocol, "invalid bulk count"))
        })();
        if result.is_err() {
            let _ = self.query("ROLLBACK");
        }
        result
    }
    pub fn connect(addr: impl ToSocketAddrs) -> Result<Self, PhobosError> {
        Ok(Self {
            stream: Transport::Plain(connect_tcp(addr)?),
            next_request_id: 1,
            streaming: false,
            poisoned: false,
        })
    }

    pub fn connect_tls(
        addr: impl ToSocketAddrs,
        server_name: &str,
        ca_pem: impl AsRef<Path>,
    ) -> Result<Self, PhobosError> {
        Self::connect_tls_identity(addr, server_name, ca_pem, None)
    }

    pub fn connect_mtls(
        addr: impl ToSocketAddrs,
        server_name: &str,
        ca_pem: impl AsRef<Path>,
        client_cert_pem: impl AsRef<Path>,
        client_key_pem: impl AsRef<Path>,
    ) -> Result<Self, PhobosError> {
        Self::connect_tls_identity(
            addr,
            server_name,
            ca_pem,
            Some((client_cert_pem.as_ref(), client_key_pem.as_ref())),
        )
    }

    fn connect_tls_identity(
        addr: impl ToSocketAddrs,
        server_name: &str,
        ca_pem: impl AsRef<Path>,
        identity: Option<(&Path, &Path)>,
    ) -> Result<Self, PhobosError> {
        let tcp = connect_tcp(addr)?;
        let mut roots = RootCertStore::empty();
        let mut reader = BufReader::new(File::open(ca_pem)?);
        let certs: Vec<CertificateDer<'static>> = rustls_pemfile::certs(&mut reader)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
        if certs.is_empty() {
            return Err(PhobosError::new(
                ErrorCode::Tls,
                "CA file contained no certificates",
            ));
        }
        for cert in certs {
            roots
                .add(cert)
                .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
        }
        let builder = ClientConfig::builder().with_root_certificates(roots);
        let config = if let Some((certificate, key)) = identity {
            let mut cert_reader = BufReader::new(File::open(certificate)?);
            let client_certs: Vec<CertificateDer<'static>> =
                rustls_pemfile::certs(&mut cert_reader)
                    .collect::<Result<Vec<_>, _>>()
                    .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
            let mut key_reader = BufReader::new(File::open(key)?);
            let key: PrivateKeyDer<'static> = rustls_pemfile::private_key(&mut key_reader)
                .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?
                .ok_or_else(|| {
                    PhobosError::new(ErrorCode::Tls, "client key file contained no private key")
                })?;
            builder
                .with_client_auth_cert(client_certs, key)
                .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?
        } else {
            builder.with_no_client_auth()
        };
        let server_name = ServerName::try_from(server_name.to_string())
            .map_err(|_| PhobosError::new(ErrorCode::Tls, "invalid TLS server name"))?;
        let connection = ClientConnection::new(Arc::new(config), server_name)
            .map_err(|error| PhobosError::new(ErrorCode::Tls, error.to_string()))?;
        Ok(Self {
            stream: Transport::Tls(Box::new(StreamOwned::new(connection, tcp))),
            next_request_id: 1,
            streaming: false,
            poisoned: false,
        })
    }

    /// Sets socket idle timeouts explicitly; the default remains five seconds.
    pub fn set_io_timeout(&self, timeout: Duration) -> Result<(), PhobosError> {
        let socket = match &self.stream {
            Transport::Plain(socket) => socket,
            Transport::Tls(stream) => &stream.sock,
        };
        socket.set_read_timeout(Some(timeout))?;
        socket.set_write_timeout(Some(timeout))?;
        Ok(())
    }

    pub fn handshake(&mut self) -> Result<String, PhobosError> {
        self.ensure_usable()?;
        self.streaming = false;
        let request_id = self.request_id();
        Frame::new(MessageType::Hello, request_id, b"phobos-client".to_vec())
            .write_to(&mut self.stream)?;
        let response = Frame::read_from(&mut self.stream)?;
        if response.message_type != MessageType::HelloAck || response.request_id != request_id {
            return Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "expected matching HelloAck",
            ));
        }
        String::from_utf8(response.payload).map_err(|_| {
            PhobosError::new(
                ErrorCode::InvalidProtocol,
                "handshake payload was not UTF-8",
            )
        })
    }

    pub fn authenticate(&mut self, username: &str, password: &str) -> Result<String, PhobosError> {
        if username.as_bytes().contains(&0) {
            return Err(PhobosError::new(
                ErrorCode::Semantic,
                "username may not contain NUL",
            ));
        }
        let mut payload = username.as_bytes().to_vec();
        payload.push(0);
        payload.extend_from_slice(password.as_bytes());
        self.request_text(MessageType::Auth, MessageType::AuthOk, payload)
    }

    /// Reserves a single-use handle for this connection's next SQL/bulk request.
    /// Send `cancel` through a SECOND authenticated connection with the same user.
    /// A target that has not started or has finished returns CancellationTarget.
    pub fn cancellation_handle(&mut self) -> Result<String, PhobosError> {
        self.request_text(
            MessageType::CancelHandle,
            MessageType::CancelHandleResult,
            Vec::new(),
        )
    }
    pub fn cancel(&mut self, handle: &str) -> Result<(), PhobosError> {
        self.request_text(
            MessageType::Cancel,
            MessageType::CancelResult,
            handle.as_bytes().to_vec(),
        )
        .map(|_| ())
    }
    pub fn query(&mut self, sql: &str) -> Result<String, PhobosError> {
        self.request_text(
            MessageType::Query,
            MessageType::QueryResult,
            sql.as_bytes().to_vec(),
        )
    }

    /// Explicit negotiation preserves the legacy single-frame API.
    pub fn negotiate_streaming(&mut self) -> Result<(), PhobosError> {
        let hello = self.request_text(
            MessageType::Hello,
            MessageType::HelloAck,
            b"phobos-client;stream=1".to_vec(),
        )?;
        self.streaming = hello.split(';').any(|part| part == CAPABILITY);
        if !self.streaming {
            return Err(PhobosError::new(
                ErrorCode::Unsupported,
                "server does not support stream=1",
            ));
        }
        Ok(())
    }

    /// Consumes one bounded event at a time. A late error means preceding rows are incomplete.
    pub fn query_stream<F>(&mut self, sql: &str, mut consume: F) -> Result<(), PhobosError>
    where
        F: FnMut(StreamEvent) -> Result<(), PhobosError>,
    {
        self.ensure_usable()?;
        if !self.streaming {
            return Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "stream capability not negotiated",
            ));
        }
        let request_id = self.request_id();
        let result = (|| {
            Frame::new(
                MessageType::QueryStream,
                request_id,
                sql.as_bytes().to_vec(),
            )
            .write_to(&mut self.stream)?;
            let mut state = State::default();
            loop {
                let frame = Frame::read_from(&mut self.stream)?;
                if frame.request_id != request_id {
                    return Err(PhobosError::new(
                        ErrorCode::InvalidProtocol,
                        "stream request ID mismatch",
                    ));
                }
                let event = StreamEvent::decode(&frame)?;
                let finished = state.accept(&event)?;
                let remote_error = if let StreamEvent::Error { code, message } = &event {
                    Some(format!("{code}: {message}"))
                } else {
                    None
                };
                consume(event)?;
                if let Some(message) = remote_error {
                    return Err(decode_remote_error(message));
                }
                if finished {
                    return Ok(());
                }
            }
        })();
        if result.is_err() {
            self.poisoned = true;
            let tcp = match &self.stream {
                Transport::Plain(s) => s,
                Transport::Tls(s) => &s.sock,
            };
            let _ = tcp.shutdown(std::net::Shutdown::Both);
        }
        result
    }

    fn ensure_usable(&self) -> Result<(), PhobosError> {
        if self.poisoned {
            Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "connection closed after incomplete or failed stream",
            ))
        } else {
            Ok(())
        }
    }

    pub fn metrics(&mut self) -> Result<String, PhobosError> {
        self.request_text(MessageType::Metrics, MessageType::MetricsResult, Vec::new())
    }

    fn request_text(
        &mut self,
        request_type: MessageType,
        expected: MessageType,
        payload: Vec<u8>,
    ) -> Result<String, PhobosError> {
        self.ensure_usable()?;
        let request_id = self.request_id();
        Frame::new(request_type, request_id, payload).write_to(&mut self.stream)?;
        let response = Frame::read_from(&mut self.stream)?;
        if response.request_id != request_id {
            return Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "response request id did not match request",
            ));
        }
        let payload = String::from_utf8(response.payload)
            .map_err(|_| PhobosError::new(ErrorCode::InvalidProtocol, "response was not UTF-8"))?;
        if response.message_type == expected {
            return Ok(payload);
        }
        if response.message_type == MessageType::Error {
            return Err(decode_remote_error(payload));
        }
        Err(PhobosError::new(
            ErrorCode::InvalidProtocol,
            "unexpected response type",
        ))
    }

    fn request_id(&mut self) -> u32 {
        let id = self.next_request_id;
        self.next_request_id = self.next_request_id.wrapping_add(1).max(1);
        id
    }
}

pub fn handshake(addr: impl ToSocketAddrs) -> Result<String, PhobosError> {
    let mut client = Client::connect(addr)?;
    client.handshake()
}

pub fn query(addr: impl ToSocketAddrs, sql: &str) -> Result<String, PhobosError> {
    let mut client = Client::connect(addr)?;
    client.query(sql)
}

fn connect_tcp(addr: impl ToSocketAddrs) -> Result<TcpStream, PhobosError> {
    let stream = TcpStream::connect(addr)?;
    // 0.2-B: strict request/response framing; never let Nagle delay a request.
    // Failure to set it is an optimization loss only, never a correctness issue.
    let _ = stream.set_nodelay(true);
    stream.set_read_timeout(Some(Duration::from_secs(5)))?;
    stream.set_write_timeout(Some(Duration::from_secs(5)))?;
    Ok(stream)
}

fn decode_remote_error(message: String) -> PhobosError {
    let code = match message.split(':').next().unwrap_or("") {
        "StatementCancelled" => ErrorCode::StatementCancelled,
        "StatementTimeout" => ErrorCode::StatementTimeout,
        "IdleTimeout" => ErrorCode::IdleTimeout,
        "CancellationTarget" => ErrorCode::CancellationTarget,
        "Authorization" => ErrorCode::Authorization,
        "Authentication" => ErrorCode::Authentication,
        "ParserDepth" => ErrorCode::ParserDepth,
        _ => ErrorCode::Semantic,
    };
    PhobosError::new(code, message)
}

#[cfg(test)]
mod streaming_tests {
    use super::*;
    use std::{net::TcpListener, thread};

    #[test]
    fn streaming_rejects_bad_peer_and_prevents_connection_reuse() {
        for scenario in 0..5 {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let addr = listener.local_addr().unwrap();
            let peer = thread::spawn(move || {
                let (mut socket, _) = listener.accept().unwrap();
                let hello = Frame::read_from(&mut socket).unwrap();
                Frame::new(
                    MessageType::HelloAck,
                    hello.request_id,
                    b"test;stream=1".to_vec(),
                )
                .write_to(&mut socket)
                .unwrap();
                let query = Frame::read_from(&mut socket).unwrap();
                let id = query.request_id;
                if scenario == 0 {
                    return;
                } // Premature EOF is not an empty successful result.
                let start = StreamEvent::Start(vec!["id".into()]);
                start
                    .frame(if scenario == 1 { id + 1 } else { id })
                    .unwrap()
                    .write_to(&mut socket)
                    .unwrap();
                if scenario == 1 {
                    return;
                }
                let next = match scenario {
                    2 => start,
                    3 => StreamEvent::End {
                        rows: 1,
                        batches: 0,
                    },
                    _ => StreamEvent::Error {
                        code: "ConstraintViolation".into(),
                        message: "late failure".into(),
                    },
                };
                next.frame(id).unwrap().write_to(&mut socket).unwrap();
            });
            let mut client = Client::connect(addr).unwrap();
            client.negotiate_streaming().unwrap();
            assert!(client.query_stream("SELECT id FROM t", |_| Ok(())).is_err());
            assert_eq!(
                client.query("SELECT id FROM t").unwrap_err().code,
                ErrorCode::InvalidProtocol
            );
            assert!(client.handshake().is_err());
            drop(client);
            peer.join().unwrap();
        }
    }

    #[test]
    fn streaming_is_never_assumed_for_legacy_peer() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let peer = thread::spawn(move || {
            let (mut socket, _) = listener.accept().unwrap();
            let hello = Frame::read_from(&mut socket).unwrap();
            Frame::new(MessageType::HelloAck, hello.request_id, b"legacy".to_vec())
                .write_to(&mut socket)
                .unwrap();
        });
        let mut client = Client::connect(addr).unwrap();
        assert_eq!(
            client.negotiate_streaming().unwrap_err().code,
            ErrorCode::Unsupported
        );
        assert!(client.query_stream("SELECT id FROM t", |_| Ok(())).is_err());
        drop(client);
        peer.join().unwrap();
    }
}
