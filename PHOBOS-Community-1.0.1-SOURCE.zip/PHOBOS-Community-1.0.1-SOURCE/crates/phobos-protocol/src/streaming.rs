//! Negotiated stream payload version 1. Values carry explicit type tags.
use crate::{Frame, MAX_PAYLOAD, MessageType};
use phobos_error::{ErrorCode, PhobosError};
use phobos_types::{Row, Value};

pub const CAPABILITY: &str = "stream=1";
pub const BATCH_ROWS: usize = 256;
pub const TARGET_BATCH_BYTES: usize = 64 * 1024;

#[derive(Debug, Clone, PartialEq)]
pub enum Event {
    Start(Vec<String>),
    Rows { sequence: u64, rows: Vec<Row> },
    End { rows: u64, batches: u64 },
    Command { tag: String, rows_affected: u64 },
    Error { code: String, message: String },
}

fn invalid(message: &str) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidProtocol, message)
}

fn bytes(out: &mut Vec<u8>, value: &[u8]) -> Result<(), PhobosError> {
    let length = u32::try_from(value.len()).map_err(|_| invalid("stream value too large"))?;
    if out.len().saturating_add(4).saturating_add(value.len()) > MAX_PAYLOAD {
        return Err(PhobosError::new(
            ErrorCode::FrameTooLarge,
            "stream payload too large",
        ));
    }
    out.extend_from_slice(&length.to_be_bytes());
    out.extend_from_slice(value);
    Ok(())
}

pub fn encode_row(row: &Row) -> Result<Vec<u8>, PhobosError> {
    let mut out = Vec::new();
    out.extend_from_slice(
        &u32::try_from(row.values.len())
            .map_err(|_| invalid("too many columns"))?
            .to_be_bytes(),
    );
    for value in &row.values {
        match value {
            Value::Null => out.push(0),
            Value::Int64(v) => {
                out.push(1);
                out.extend_from_slice(&v.to_be_bytes());
            }
            Value::Boolean(v) => {
                out.push(2);
                out.push(u8::from(*v));
            }
            Value::Float64(v) => {
                out.push(3);
                out.extend_from_slice(&v.to_bits().to_be_bytes());
            }
            Value::Text(v) => {
                out.push(4);
                bytes(&mut out, v.as_bytes())?;
            }
            Value::Binary(v) => {
                out.push(5);
                bytes(&mut out, v)?;
            }
            Value::Date(v) => {
                out.push(6);
                out.extend_from_slice(&v.to_be_bytes());
            }
            Value::Timestamp(v) => {
                out.push(7);
                out.extend_from_slice(&v.to_be_bytes());
            }
            Value::Decimal { unscaled, scale } => {
                out.push(8);
                out.extend_from_slice(&unscaled.to_be_bytes());
                out.push(*scale);
            }
        }
        if out.len() > MAX_PAYLOAD - 13 {
            return Err(PhobosError::new(
                ErrorCode::FrameTooLarge,
                "individual stream row exceeds frame budget",
            ));
        }
    }
    Ok(out)
}

impl Event {
    pub fn frame(&self, request_id: u32) -> Result<Frame, PhobosError> {
        let mut payload = vec![1];
        let kind = match self {
            Self::Start(columns) => {
                payload.extend_from_slice(
                    &u32::try_from(columns.len())
                        .map_err(|_| invalid("too many columns"))?
                        .to_be_bytes(),
                );
                for column in columns {
                    bytes(&mut payload, column.as_bytes())?;
                }
                MessageType::QueryResultStart
            }
            Self::Rows { sequence, rows } => {
                if rows.is_empty() || rows.len() > BATCH_ROWS {
                    return Err(invalid("invalid stream batch count"));
                }
                payload.extend_from_slice(&sequence.to_be_bytes());
                payload.extend_from_slice(&(rows.len() as u32).to_be_bytes());
                for row in rows {
                    let encoded = encode_row(row)?;
                    if payload.len() + encoded.len() > MAX_PAYLOAD {
                        return Err(PhobosError::new(
                            ErrorCode::FrameTooLarge,
                            "stream batch too large",
                        ));
                    }
                    payload.extend_from_slice(&encoded);
                }
                MessageType::QueryRows
            }
            Self::End { rows, batches } => {
                payload.extend_from_slice(&rows.to_be_bytes());
                payload.extend_from_slice(&batches.to_be_bytes());
                MessageType::QueryResultEnd
            }
            Self::Command { tag, rows_affected } => {
                bytes(&mut payload, tag.as_bytes())?;
                payload.extend_from_slice(&rows_affected.to_be_bytes());
                MessageType::CommandResult
            }
            Self::Error { code, message } => {
                bytes(&mut payload, code.as_bytes())?;
                bytes(&mut payload, message.as_bytes())?;
                MessageType::StreamError
            }
        };
        Ok(Frame::new(kind, request_id, payload))
    }

    pub fn decode(frame: &Frame) -> Result<Self, PhobosError> {
        if frame.flags != 0 || frame.payload.len() > MAX_PAYLOAD {
            return Err(invalid("invalid stream frame"));
        }
        let mut input = Decoder(&frame.payload);
        if input.take(1)? != [1] {
            return Err(invalid("unsupported stream payload version"));
        }
        let result = match frame.message_type {
            MessageType::QueryResultStart => {
                let count = input.count(4)?;
                let mut columns = Vec::new();
                for _ in 0..count {
                    columns.push(input.text()?);
                }
                Self::Start(columns)
            }
            MessageType::QueryRows => {
                let sequence = u64::from_be_bytes(input.array()?);
                let count = input.count(4)?;
                if count == 0 || count > BATCH_ROWS {
                    return Err(invalid("invalid stream batch count"));
                }
                let mut rows = Vec::new();
                for _ in 0..count {
                    let columns = input.count(1)?;
                    let mut values = Vec::new();
                    for _ in 0..columns {
                        values.push(match input.take(1)?[0] {
                            0 => Value::Null,
                            1 => Value::Int64(i64::from_be_bytes(input.array()?)),
                            2 => Value::Boolean(match input.take(1)?[0] {
                                0 => false,
                                1 => true,
                                _ => return Err(invalid("invalid Boolean")),
                            }),
                            3 => Value::Float64(f64::from_bits(u64::from_be_bytes(input.array()?))),
                            4 => Value::Text(input.text()?),
                            5 => Value::Binary(input.blob()?.to_vec()),
                            6 => Value::Date(i32::from_be_bytes(input.array()?)),
                            7 => Value::Timestamp(i64::from_be_bytes(input.array()?)),
                            8 => Value::Decimal {
                                unscaled: i128::from_be_bytes(input.array()?),
                                scale: input.take(1)?[0],
                            },
                            _ => return Err(invalid("unknown stream value tag")),
                        });
                    }
                    rows.push(Row { values });
                }
                Self::Rows { sequence, rows }
            }
            MessageType::QueryResultEnd => Self::End {
                rows: u64::from_be_bytes(input.array()?),
                batches: u64::from_be_bytes(input.array()?),
            },
            MessageType::CommandResult => Self::Command {
                tag: input.text()?,
                rows_affected: u64::from_be_bytes(input.array()?),
            },
            MessageType::StreamError => Self::Error {
                code: input.text()?,
                message: input.text()?,
            },
            _ => return Err(invalid("unexpected stream message")),
        };
        if !input.0.is_empty() {
            return Err(invalid("trailing stream bytes"));
        }
        Ok(result)
    }
}

struct Decoder<'a>(&'a [u8]);
impl<'a> Decoder<'a> {
    fn take(&mut self, count: usize) -> Result<&'a [u8], PhobosError> {
        if count > self.0.len() {
            return Err(invalid("truncated stream payload"));
        }
        let (value, rest) = self.0.split_at(count);
        self.0 = rest;
        Ok(value)
    }
    fn array<const N: usize>(&mut self) -> Result<[u8; N], PhobosError> {
        Ok(self.take(N)?.try_into().expect("validated length"))
    }
    fn count(&mut self, minimum: usize) -> Result<usize, PhobosError> {
        let count = u32::from_be_bytes(self.array()?) as usize;
        if count > self.0.len() / minimum {
            return Err(invalid("stream count exceeds remaining payload"));
        }
        Ok(count)
    }
    fn blob(&mut self) -> Result<&'a [u8], PhobosError> {
        let count = self.count(1)?;
        self.take(count)
    }
    fn text(&mut self) -> Result<String, PhobosError> {
        String::from_utf8(self.blob()?.to_vec()).map_err(|_| invalid("invalid stream UTF-8"))
    }
}

/// Validates one result; the connection owner must reject reuse after a protocol failure.
#[derive(Default)]
pub struct State {
    columns: Option<usize>,
    rows: u64,
    batches: u64,
    finished: bool,
}
impl State {
    pub fn accept(&mut self, event: &Event) -> Result<bool, PhobosError> {
        if self.finished {
            return Err(invalid("stream already finished"));
        }
        match event {
            Event::Start(columns) if self.columns.is_none() => self.columns = Some(columns.len()),
            Event::Rows { sequence, rows } if self.columns.is_some() => {
                if rows.is_empty()
                    || rows.len() > BATCH_ROWS
                    || *sequence != self.batches
                    || rows.iter().any(|r| Some(r.values.len()) != self.columns)
                {
                    return Err(invalid("stream sequence or column mismatch"));
                }
                self.rows = self
                    .rows
                    .checked_add(rows.len() as u64)
                    .ok_or_else(|| invalid("row count overflow"))?;
                self.batches = self
                    .batches
                    .checked_add(1)
                    .ok_or_else(|| invalid("batch count overflow"))?;
            }
            Event::End { rows, batches }
                if self.columns.is_some() && *rows == self.rows && *batches == self.batches =>
            {
                self.finished = true
            }
            Event::Command { .. } if self.columns.is_none() => self.finished = true,
            Event::Error { .. } => self.finished = true,
            _ => return Err(invalid("invalid result stream state")),
        }
        Ok(self.finished)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stream_typed_roundtrip_and_empty_command() {
        let values = vec![
            Value::Null,
            Value::Int64(i64::MIN),
            Value::Boolean(true),
            Value::Float64(-1.25),
            Value::Text("NULL\t\n\0\u{1f680}".into()),
            Value::Binary(vec![0, 255, 10]),
            Value::Date(-4),
            Value::Timestamp(i64::MAX),
            Value::Decimal {
                unscaled: i128::MIN,
                scale: 12,
            },
        ];
        let events = [
            Event::Start((0..values.len()).map(|i| format!("c{i}")).collect()),
            Event::Rows {
                sequence: 0,
                rows: vec![Row { values }],
            },
            Event::End {
                rows: 1,
                batches: 1,
            },
        ];
        let mut state = State::default();
        for (i, event) in events.iter().enumerate() {
            let decoded = Event::decode(&event.frame(7).unwrap()).unwrap();
            assert_eq!(&decoded, event);
            assert_eq!(state.accept(&decoded).unwrap(), i == 2);
        }
        assert!(state.accept(&events[2]).is_err());
        let mut empty = State::default();
        assert!(!empty.accept(&Event::Start(vec!["x".into()])).unwrap());
        assert!(
            empty
                .accept(&Event::End {
                    rows: 0,
                    batches: 0
                })
                .unwrap()
        );
        for event in [
            Event::Command {
                tag: "INSERT".into(),
                rows_affected: 9,
            },
            Event::Error {
                code: "Semantic".into(),
                message: "bad\nquery".into(),
            },
        ] {
            assert_eq!(Event::decode(&event.frame(8).unwrap()).unwrap(), event);
            assert!(State::default().accept(&event).unwrap());
        }
    }

    #[test]
    fn stream_rejects_malformed_lengths_versions_and_state() {
        let original = Event::Rows {
            sequence: 0,
            rows: vec![Row {
                values: vec![Value::Text("test".into())],
            }],
        }
        .frame(1)
        .unwrap();
        for length in 0..original.payload.len() {
            let mut frame = original.clone();
            frame.payload.truncate(length);
            assert!(Event::decode(&frame).is_err(), "truncation {length}");
        }
        let mut frame = original.clone();
        frame.payload.push(0);
        assert!(Event::decode(&frame).is_err());
        let mut frame = original.clone();
        frame.payload[0] = 2;
        assert!(Event::decode(&frame).is_err());
        let mut frame = original.clone();
        frame.flags = 1;
        assert!(Event::decode(&frame).is_err());
        let mut frame = original.clone();
        frame.payload[9..13].copy_from_slice(&u32::MAX.to_be_bytes());
        assert!(Event::decode(&frame).is_err());
        let rows = Event::decode(&original).unwrap();
        assert!(State::default().accept(&rows).is_err());
        let mut state = State::default();
        state.accept(&Event::Start(vec!["x".into()])).unwrap();
        assert!(state.accept(&Event::Start(vec![])).is_err());
        assert!(
            state
                .accept(&Event::Rows {
                    sequence: 1,
                    rows: vec![Row {
                        values: vec![Value::Null]
                    }]
                })
                .is_err()
        );
        assert!(
            state
                .accept(&Event::Rows {
                    sequence: 0,
                    rows: vec![Row { values: vec![] }]
                })
                .is_err()
        );
        assert!(
            state
                .accept(&Event::End {
                    rows: 1,
                    batches: 0
                })
                .is_err()
        );
        assert!(
            encode_row(&Row {
                values: vec![Value::Text("x".repeat(MAX_PAYLOAD))]
            })
            .is_err()
        );
    }
}
