#![forbid(unsafe_code)]
//! Binary wire framing for the Phobos protocol.

use phobos_error::{ErrorCode, PhobosError};
use std::io::{Read, Write};

pub mod streaming;

pub const MAGIC: [u8; 4] = *b"PHOB";
pub const VERSION: u8 = 1;
pub const HEADER_LEN: usize = 16;
pub const MAX_PAYLOAD: usize = 1024 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum MessageType {
    Hello = 1,
    HelloAck = 2,
    Ping = 3,
    Pong = 4,
    Auth = 5,
    AuthOk = 6,
    Query = 10,
    QueryResult = 11,
    QueryStream = 12,
    QueryResultStart = 13,
    QueryRows = 14,
    QueryResultEnd = 15,
    CommandResult = 16,
    StreamError = 17,
    Metrics = 20,
    MetricsResult = 21,
    BulkBegin = 30,
    BulkRows = 31,
    CancelHandle = 40,
    CancelHandleResult = 41,
    Cancel = 42,
    CancelResult = 43,
    Error = 255,
}
impl TryFrom<u8> for MessageType {
    type Error = PhobosError;
    fn try_from(value: u8) -> Result<Self, PhobosError> {
        match value {
            1 => Ok(Self::Hello),
            2 => Ok(Self::HelloAck),
            3 => Ok(Self::Ping),
            4 => Ok(Self::Pong),
            5 => Ok(Self::Auth),
            6 => Ok(Self::AuthOk),
            10 => Ok(Self::Query),
            11 => Ok(Self::QueryResult),
            12 => Ok(Self::QueryStream),
            13 => Ok(Self::QueryResultStart),
            14 => Ok(Self::QueryRows),
            15 => Ok(Self::QueryResultEnd),
            16 => Ok(Self::CommandResult),
            17 => Ok(Self::StreamError),
            20 => Ok(Self::Metrics),
            21 => Ok(Self::MetricsResult),
            30 => Ok(Self::BulkBegin),
            31 => Ok(Self::BulkRows),
            40 => Ok(Self::CancelHandle),
            41 => Ok(Self::CancelHandleResult),
            42 => Ok(Self::Cancel),
            43 => Ok(Self::CancelResult),
            255 => Ok(Self::Error),
            _ => Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "unknown message type",
            )),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Frame {
    pub message_type: MessageType,
    pub flags: u16,
    pub request_id: u32,
    pub payload: Vec<u8>,
}
impl Frame {
    #[must_use]
    pub fn new(message_type: MessageType, request_id: u32, payload: Vec<u8>) -> Self {
        Self {
            message_type,
            flags: 0,
            request_id,
            payload,
        }
    }
    pub fn write_to(&self, mut w: impl Write) -> Result<(), PhobosError> {
        let _profile = phobos_observability::span("protocol.write_to");
        if self.payload.len() > MAX_PAYLOAD {
            return Err(PhobosError::new(
                ErrorCode::FrameTooLarge,
                "payload exceeds protocol limit",
            ));
        }
        let mut h = [0u8; HEADER_LEN];
        h[0..4].copy_from_slice(&MAGIC);
        h[4] = VERSION;
        h[5] = self.message_type as u8;
        h[6..8].copy_from_slice(&self.flags.to_be_bytes());
        h[8..12].copy_from_slice(&self.request_id.to_be_bytes());
        h[12..16].copy_from_slice(&(self.payload.len() as u32).to_be_bytes());
        // 0.2-B: one write per frame. Writing the 16-byte header and the
        // payload separately on an unbuffered socket lets Nagle hold the
        // payload until the peer's delayed ACK (~40 ms on Linux) whenever the
        // writer has not set TCP_NODELAY. The bytes on the wire are identical.
        let mut frame = Vec::with_capacity(HEADER_LEN + self.payload.len());
        frame.extend_from_slice(&h);
        frame.extend_from_slice(&self.payload);
        w.write_all(&frame)?;
        Ok(())
    }
    pub fn read_from(mut r: impl Read) -> Result<Self, PhobosError> {
        let _profile = phobos_observability::span("protocol.read_from");
        let mut h = [0u8; HEADER_LEN];
        r.read_exact(&mut h)?;
        if h[0..4] != MAGIC {
            return Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "invalid protocol magic",
            ));
        }
        if h[4] != VERSION {
            return Err(PhobosError::new(
                ErrorCode::InvalidProtocol,
                "unsupported protocol version",
            ));
        }
        let message_type = MessageType::try_from(h[5])?;
        let flags = u16::from_be_bytes([h[6], h[7]]);
        let request_id = u32::from_be_bytes([h[8], h[9], h[10], h[11]]);
        let len = u32::from_be_bytes([h[12], h[13], h[14], h[15]]) as usize;
        if len > MAX_PAYLOAD {
            return Err(PhobosError::new(
                ErrorCode::FrameTooLarge,
                "payload exceeds protocol limit",
            ));
        }
        let mut payload = vec![0; len];
        r.read_exact(&mut payload)?;
        Ok(Self {
            message_type,
            flags,
            request_id,
            payload,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn round_trip() {
        let f = Frame::new(MessageType::Hello, 42, b"phobos-client".to_vec());
        let mut b = Vec::new();
        f.write_to(&mut b).unwrap();
        assert_eq!(Frame::read_from(&b[..]).unwrap(), f);
    }
    #[test]
    fn rejects_bad_magic() {
        let mut b = [0; HEADER_LEN];
        b[4] = VERSION;
        assert_eq!(
            Frame::read_from(&b[..]).unwrap_err().code,
            ErrorCode::InvalidProtocol
        );
    }
    #[test]
    fn rejects_oversized_declared_payload_before_allocation() {
        let mut b = [0; HEADER_LEN];
        b[0..4].copy_from_slice(&MAGIC);
        b[4] = VERSION;
        b[5] = MessageType::Hello as u8;
        b[12..16].copy_from_slice(&((MAX_PAYLOAD as u32) + 1).to_be_bytes());
        assert_eq!(
            Frame::read_from(&b[..]).unwrap_err().code,
            ErrorCode::FrameTooLarge
        );
    }
}
