#![forbid(unsafe_code)]
//! Stable error model shared across Phobos crates.

use std::{error::Error, fmt};

/// Error severity exposed to local callers and, later, remote clients.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Severity {
    Error,
    Fatal,
}

/// Stable machine-readable error codes for the implemented subset.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrorCode {
    InvalidProtocol,
    FrameTooLarge,
    InvalidPage,
    ChecksumMismatch,
    InvalidCatalog,
    InvalidWal,
    TransactionState,
    LockTimeout,
    Authentication,
    Authorization,
    ResourceLimit,
    DataDirectoryLocked,
    Tls,
    Recovery,
    SqlSyntax,
    ParserDepth,
    StatementCancelled,
    StatementTimeout,
    IdleTimeout,
    CancellationTarget,
    Semantic,
    TypeMismatch,
    NotFound,
    AlreadyExists,
    ConstraintViolation,
    Io,
    Unsupported,
}

/// Structured public error. Internal source chains are intentionally not serialized here.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PhobosError {
    pub code: ErrorCode,
    pub severity: Severity,
    pub message: String,
    pub detail: Option<String>,
    pub hint: Option<String>,
    pub position: Option<u32>,
}

impl PhobosError {
    #[must_use]
    pub fn new(code: ErrorCode, message: impl Into<String>) -> Self {
        Self {
            code,
            severity: Severity::Error,
            message: message.into(),
            detail: None,
            hint: None,
            position: None,
        }
    }

    #[must_use]
    pub fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }

    #[must_use]
    pub fn with_position(mut self, position: u32) -> Self {
        self.position = Some(position);
        self
    }
}

impl fmt::Display for PhobosError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?}: {}", self.code, self.message)
    }
}

impl Error for PhobosError {}

impl From<std::io::Error> for PhobosError {
    fn from(error: std::io::Error) -> Self {
        Self::new(ErrorCode::Io, error.to_string())
    }
}
pub mod cancellation;
