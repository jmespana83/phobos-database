//! Cooperative statement cancellation. No background timer and no shared lock
//! in operator polling. A scoped thread-local context follows synchronous work.
use crate::{ErrorCode, PhobosError};
use std::{
    cell::{Cell, RefCell},
    marker::PhantomData,
    rc::Rc,
    sync::{
        Arc,
        atomic::{AtomicU8, Ordering},
    },
    time::{Duration, Instant},
};

const RUNNING: u8 = 0;
const CANCELLED: u8 = 1;
const TIMED_OUT: u8 = 2;
const COMMITTED: u8 = 3;
pub const POLL_INTERVAL: u16 = 512;
#[derive(Clone, Debug)]
pub struct CancellationToken(Arc<AtomicU8>);
impl Default for CancellationToken {
    fn default() -> Self {
        Self(Arc::new(AtomicU8::new(RUNNING)))
    }
}
impl CancellationToken {
    pub fn cancel(&self) {
        let _ = self
            .0
            .compare_exchange(RUNNING, CANCELLED, Ordering::AcqRel, Ordering::Acquire);
    }
    pub fn is_cancelled(&self) -> bool {
        matches!(self.0.load(Ordering::Acquire), CANCELLED | TIMED_OUT)
    }
    pub fn check(&self) -> Result<(), PhobosError> {
        match self.0.load(Ordering::Acquire) {
            CANCELLED => Err(PhobosError::new(
                ErrorCode::StatementCancelled,
                "statement cancelled",
            )),
            TIMED_OUT => Err(PhobosError::new(
                ErrorCode::StatementTimeout,
                "statement deadline exceeded",
            )),
            _ => Ok(()),
        }
    }
}
#[derive(Clone, Debug)]
pub struct StatementContext {
    pub token: CancellationToken,
    pub deadline: Option<Instant>,
    pub identity: String,
}
impl StatementContext {
    pub fn new(identity: String, timeout: Option<Duration>) -> Self {
        Self {
            token: CancellationToken::default(),
            deadline: timeout.map(|value| Instant::now() + value),
            identity,
        }
    }
    pub fn check(&self) -> Result<(), PhobosError> {
        if self
            .deadline
            .is_some_and(|deadline| Instant::now() >= deadline)
        {
            let _ = self.token.0.compare_exchange(
                RUNNING,
                TIMED_OUT,
                Ordering::AcqRel,
                Ordering::Acquire,
            );
        }
        self.token.check()
    }
    /// Atomically arbitrate cancel versus irrevocable commit admission.
    pub fn commit(&self) -> Result<(), PhobosError> {
        self.check()?;
        match self
            .token
            .0
            .compare_exchange(RUNNING, COMMITTED, Ordering::AcqRel, Ordering::Acquire)
        {
            Ok(_) | Err(COMMITTED) => Ok(()),
            Err(_) => self.token.check(),
        }
    }
    pub fn enter(&self) -> Scope {
        Scope::install(Some(self.clone()))
    }
}
thread_local! {
    static CURRENT: RefCell<Option<StatementContext>> = const { RefCell::new(None) };
    static COUNT: Cell<u16> = const { Cell::new(0) };
}
/// Cannot move between threads. Drop restores the previous scope, including on unwind.
pub struct Scope {
    previous: Option<StatementContext>,
    count: u16,
    _local: PhantomData<Rc<()>>,
}
impl Scope {
    fn install(next: Option<StatementContext>) -> Self {
        Self {
            previous: CURRENT.with(|current| current.replace(next)),
            count: COUNT.with(|count| count.replace(0)),
            _local: PhantomData,
        }
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        CURRENT.with(|current| *current.borrow_mut() = self.previous.take());
        COUNT.with(|count| count.set(self.count));
    }
}
pub fn current() -> Option<StatementContext> {
    CURRENT.with(|current| current.borrow().clone())
}
/// Used only for rollback/recovery and already-admitted durability work.
pub fn suspend() -> Scope {
    Scope::install(None)
}
pub fn check_now() -> Result<(), PhobosError> {
    CURRENT.with(|current| {
        current
            .borrow()
            .as_ref()
            .map_or(Ok(()), StatementContext::check)
    })
}
pub fn commit() -> Result<(), PhobosError> {
    CURRENT.with(|current| {
        current
            .borrow()
            .as_ref()
            .map_or(Ok(()), StatementContext::commit)
    })
}
/// Stack-local counter for operator loops. Only a polling boundary reads the
/// thread-local context; ordinary tuple iterations touch a register-sized counter.
#[derive(Default)]
pub struct Poller {
    count: u16,
}
impl Poller {
    #[inline]
    pub fn checkpoint_at(&mut self, point: &'static str) -> Result<(), PhobosError> {
        self.count += 1;
        if self.count == POLL_INTERVAL {
            self.count = 0;
            poll(point)
        } else {
            Ok(())
        }
    }
}
#[inline]
pub fn checkpoint_at(point: &'static str) -> Result<(), PhobosError> {
    if COUNT.with(|count| {
        let next = count.get() + 1;
        if next == POLL_INTERVAL {
            count.set(0);
            true
        } else {
            count.set(next);
            false
        }
    }) {
        poll(point)
    } else {
        Ok(())
    }
}
fn poll(point: &'static str) -> Result<(), PhobosError> {
    #[cfg(feature = "test-hooks")]
    test_hooks::run(point);
    #[cfg(not(feature = "test-hooks"))]
    let _ = point;
    check_now()
}

pub fn is_interrupted(error: &PhobosError) -> bool {
    matches!(
        error.code,
        ErrorCode::StatementCancelled | ErrorCode::StatementTimeout
    )
}

#[cfg(feature = "test-hooks")]
pub mod test_hooks {
    use super::*;
    pub type Callback = Arc<dyn Fn(&str) + Send + Sync>;
    thread_local! { static HOOK: RefCell<Option<Callback>> = const { RefCell::new(None) }; }
    pub struct Registration(Option<Callback>, PhantomData<Rc<()>>);
    pub fn register(hook: Callback) -> Registration {
        Registration(HOOK.with(|value| value.replace(Some(hook))), PhantomData)
    }
    impl Drop for Registration {
        fn drop(&mut self) {
            HOOK.with(|value| *value.borrow_mut() = self.0.take());
        }
    }
    pub(super) fn run(point: &str) {
        let callback = HOOK.with(|value| value.borrow().clone());
        if let Some(callback) = callback {
            callback(point);
        }
    }
    /// Deterministic test-clock boundary, compiled out of production builds.
    pub fn expire_current() {
        CURRENT.with(|value| {
            if let Some(context) = value.borrow_mut().as_mut() {
                context.deadline = Some(Instant::now());
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cancellation_deadline_scopes_and_commit_race() {
        let context = StatementContext::new("test".into(), None);
        {
            let _scope = context.enter();
            context.token.cancel();
            assert_eq!(check_now().unwrap_err().code, ErrorCode::StatementCancelled);
            {
                let _cleanup = suspend();
                check_now().unwrap();
            }
            assert!(commit().is_err());
        }
        check_now().unwrap();
        let context = StatementContext::new("committed".into(), None);
        {
            let _scope = context.enter();
            commit().unwrap();
            context.token.cancel();
            check_now().unwrap();
        }
        let timeout = StatementContext::new("timeout".into(), Some(Duration::ZERO));
        assert_eq!(
            timeout.check().unwrap_err().code,
            ErrorCode::StatementTimeout
        );
        for _ in 0..64 {
            let context = StatementContext::new("race".into(), None);
            let token = context.token.clone();
            let worker = std::thread::spawn(move || token.cancel());
            let admitted = context.commit().is_ok();
            worker.join().unwrap();
            assert_eq!(context.check().is_ok(), admitted);
        }
    }
}
