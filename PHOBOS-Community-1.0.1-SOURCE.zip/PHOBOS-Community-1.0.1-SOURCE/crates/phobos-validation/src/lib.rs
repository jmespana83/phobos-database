#![forbid(unsafe_code)]
//! Cross-phase validation harness for validated Phases 0–5 plus Phase 6 candidate coverage.
//!
//! This crate is test-only. It intentionally exercises public subsystem APIs together rather
//! than duplicating their implementation. Normal tests are designed for routine gating; ignored
//! tests are longer-running deterministic stress/soak workloads.

#[cfg(test)]
mod tests {
    use phobos_error::ErrorCode;
    use phobos_execution::{Database, QueryResult};
    use phobos_index::{BPlusTree, Bound, IndexKey};
    use phobos_server::Coordinator;
    use phobos_types::{RecordId, Row, Value};
    use phobos_wal::{Wal, recover};
    use std::{
        collections::{BTreeMap, BTreeSet},
        fs::{self, OpenOptions},
        io::Write,
        path::{Path, PathBuf},
        sync::{Arc, Barrier},
        thread,
        time::{SystemTime, UNIX_EPOCH},
    };

    fn temp_dir(label: &str) -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock after epoch")
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-validation-{label}-{nanos}"))
    }

    fn rows(result: QueryResult) -> Vec<Row> {
        match result {
            QueryResult::Rows { rows, .. } => rows,
            QueryResult::Command { tag, .. } => panic!("expected rows, got command {tag}"),
        }
    }

    fn rid(n: u64) -> RecordId {
        RecordId {
            page_id: n / 100,
            slot_id: (n % 100) as u16,
        }
    }

    fn cleanup(path: &Path) {
        let _ = fs::remove_dir_all(path);
        let _ = fs::remove_file(path);
    }

    #[test]
    fn phase0_to_5_end_to_end_restart_index_and_transactions() {
        let dir = temp_dir("e2e");
        {
            let mut db = Database::open_with_buffer_pages(&dir, 4).unwrap();
            db.execute("CREATE TABLE items (id BIGINT NOT NULL, grp BIGINT NOT NULL, name TEXT)")
                .unwrap();
            db.execute("CREATE UNIQUE INDEX ux_items_id ON items (id)")
                .unwrap();
            db.execute("CREATE INDEX ix_items_grp ON items (grp)")
                .unwrap();
            db.execute("BEGIN").unwrap();
            for chunk in 0..5i64 {
                let mut sql = String::from("INSERT INTO items VALUES ");
                for offset in 0..40i64 {
                    if offset > 0 {
                        sql.push(',');
                    }
                    let id = chunk * 40 + offset;
                    let grp = id % 7;
                    sql.push_str(&format!("({id},{grp},'item-{id}')"));
                }
                db.execute(&sql).unwrap();
            }
            db.execute("COMMIT").unwrap();

            let selected = rows(
                db.execute("SELECT id FROM items WHERE grp=3 ORDER BY id")
                    .unwrap(),
            );
            assert_eq!(selected.len(), 29);
            assert_eq!(db.last_access_path(), Some("INDEX ix_items_grp"));

            db.execute("BEGIN").unwrap();
            db.execute("UPDATE items SET name='rolled-back' WHERE id=5")
                .unwrap();
            db.execute("DELETE FROM items WHERE id=6").unwrap();
            db.execute("ROLLBACK").unwrap();
            assert_eq!(
                rows(db.execute("SELECT id FROM items WHERE id=6").unwrap()).len(),
                1
            );

            db.execute("BEGIN").unwrap();
            db.execute("UPDATE items SET name='committed' WHERE id=5")
                .unwrap();
            db.execute("DELETE FROM items WHERE id=6").unwrap();
            db.execute("COMMIT").unwrap();
            db.execute("CHECKPOINT").unwrap();
        }
        {
            let mut db = Database::open_with_buffer_pages(&dir, 2).unwrap();
            assert_eq!(
                rows(db.execute("SELECT name FROM items WHERE id=5").unwrap())[0].values,
                vec![Value::Text("committed".into())]
            );
            assert!(rows(db.execute("SELECT id FROM items WHERE id=6").unwrap()).is_empty());
            assert_eq!(
                rows(db.execute("SELECT id FROM items ORDER BY id").unwrap()).len(),
                199
            );
        }
        cleanup(&dir);
    }

    #[test]
    fn transaction_failure_is_atomic_across_restart() {
        let dir = temp_dir("atomicity");
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE accounts (id BIGINT NOT NULL, balance BIGINT NOT NULL)")
                .unwrap();
            db.execute("CREATE UNIQUE INDEX ux_accounts_id ON accounts (id)")
                .unwrap();
            db.execute("INSERT INTO accounts VALUES (1,100),(2,200)")
                .unwrap();
            db.execute("BEGIN").unwrap();
            db.execute("UPDATE accounts SET balance=75 WHERE id=1")
                .unwrap();
            let err = db
                .execute("INSERT INTO accounts VALUES (1,999)")
                .unwrap_err();
            assert_eq!(err.code, ErrorCode::ConstraintViolation);
            assert_eq!(
                db.execute("COMMIT").unwrap_err().code,
                ErrorCode::TransactionState
            );
            db.execute("ROLLBACK").unwrap();
        }
        {
            let mut db = Database::open(&dir).unwrap();
            let result = rows(
                db.execute("SELECT id,balance FROM accounts ORDER BY id")
                    .unwrap(),
            );
            assert_eq!(result[0].values, vec![Value::Int64(1), Value::Int64(100)]);
            assert_eq!(result[1].values, vec![Value::Int64(2), Value::Int64(200)]);
        }
        cleanup(&dir);
    }

    #[test]
    fn bplus_tree_randomized_model_restart_and_ranges() {
        let path = temp_dir("index").with_extension("idx");
        let mut model: BTreeMap<i64, BTreeSet<RecordId>> = BTreeMap::new();
        let mut seed = 0x1234_5678_9abc_def0u64;
        {
            let mut tree = BPlusTree::open(&path, false, 1).unwrap();
            for step in 0..12_000u64 {
                seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                let key_value = ((seed >> 20) % 500) as i64;
                let record = rid((seed ^ step) % 1_500);
                let key = IndexKey(vec![Value::Int64(key_value)]);
                if seed & 3 != 0 {
                    tree.insert(key, record).unwrap();
                    model.entry(key_value).or_default().insert(record);
                } else {
                    let actual = tree.delete(&key, record).unwrap();
                    let expected = model
                        .get_mut(&key_value)
                        .is_some_and(|set| set.remove(&record));
                    assert_eq!(actual, expected);
                }
                if step % 997 == 0 {
                    tree.validate().unwrap();
                }
            }
            tree.sync().unwrap();
            tree.validate().unwrap();
        }
        {
            let mut tree = BPlusTree::open(&path, false, 1).unwrap();
            tree.validate().unwrap();
            for key_value in [0, 1, 42, 250, 499] {
                let key = IndexKey(vec![Value::Int64(key_value)]);
                let mut actual = tree.point_lookup(&key).unwrap();
                actual.sort();
                let expected: Vec<_> = model
                    .get(&key_value)
                    .cloned()
                    .unwrap_or_default()
                    .into_iter()
                    .collect();
                assert_eq!(actual, expected);
            }
            let low = IndexKey(vec![Value::Int64(100)]);
            let high = IndexKey(vec![Value::Int64(199)]);
            let actual = tree
                .range(Bound::Included(&low), Bound::Included(&high))
                .unwrap();
            let expected: usize = model.range(100..=199).map(|(_, set)| set.len()).sum();
            assert_eq!(actual.len(), expected);
        }
        cleanup(&path);
    }

    #[test]
    fn wal_torn_tail_recovery_is_idempotent() {
        let base = temp_dir("wal");
        let snapshot = base.join("snapshot");
        let data = base.join("data");
        fs::create_dir_all(&snapshot).unwrap();
        fs::create_dir_all(&data).unwrap();
        fs::write(snapshot.join("catalog.phc"), b"catalog-v1").unwrap();
        fs::write(snapshot.join("table-0000000000000001.heap"), b"heap-v1").unwrap();
        fs::write(snapshot.join("index-0000000000000001.idx"), b"index-v1").unwrap();
        {
            let mut wal = Wal::open(&data).unwrap();
            wal.write_transaction_snapshot(17, &snapshot).unwrap();
        }
        let wal_path = data.join("phobos.wal");
        {
            let mut file = OpenOptions::new().append(true).open(&wal_path).unwrap();
            file.write_all(b"PHWL\x01").unwrap();
            file.sync_data().unwrap();
        }
        let first = recover(&data).unwrap();
        assert!(first.truncated_tail);
        assert_eq!(first.redone_transactions, 1);
        assert_eq!(fs::read(data.join("catalog.phc")).unwrap(), b"catalog-v1");
        assert_eq!(
            fs::read(data.join("index-0000000000000001.idx")).unwrap(),
            b"index-v1"
        );
        let second = recover(&data).unwrap();
        assert!(!second.truncated_tail);
        assert_eq!(second.redone_transactions, 1);
        cleanup(&base);
    }

    #[test]
    fn concurrent_autocommit_writers_preserve_all_rows() {
        let dir = temp_dir("writers");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let setup = coordinator.new_session();
        coordinator
            .execute(setup, "CREATE TABLE t (id BIGINT NOT NULL)")
            .unwrap();
        coordinator
            .execute(setup, "CREATE UNIQUE INDEX ux_t_id ON t (id)")
            .unwrap();

        let workers = 8usize;
        let inserts_per_worker = 20usize;
        let barrier = Arc::new(Barrier::new(workers + 1));
        let mut handles = Vec::new();
        for worker in 0..workers {
            let coordinator = Arc::clone(&coordinator);
            let barrier = Arc::clone(&barrier);
            handles.push(thread::spawn(move || {
                let session = coordinator.new_session();
                barrier.wait();
                for offset in 0..inserts_per_worker {
                    let id = worker * 10_000 + offset;
                    coordinator
                        .execute(session, &format!("INSERT INTO t VALUES ({id})"))
                        .unwrap();
                }
            }));
        }
        barrier.wait();
        for handle in handles {
            handle.join().unwrap();
        }
        let output = coordinator
            .execute(setup, "SELECT id FROM t ORDER BY id")
            .unwrap();
        assert_eq!(
            output
                .lines()
                .skip(1)
                .filter(|line| !line.is_empty())
                .count(),
            160
        );
        drop(coordinator);
        cleanup(&dir);
    }

    #[test]
    fn explicit_transaction_blocks_other_session_then_disconnect_rolls_back() {
        let dir = temp_dir("disconnect");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let owner = coordinator.new_session();
        let waiter = coordinator.new_session();
        coordinator
            .execute(owner, "CREATE TABLE t (id BIGINT NOT NULL)")
            .unwrap();
        coordinator.execute(owner, "BEGIN").unwrap();
        coordinator
            .execute(owner, "INSERT INTO t VALUES (9)")
            .unwrap();

        let start = Arc::new(Barrier::new(2));
        let other = Arc::clone(&coordinator);
        let other_start = Arc::clone(&start);
        let handle = thread::spawn(move || {
            other_start.wait();
            other.execute(waiter, "SELECT * FROM t")
        });
        start.wait();
        thread::sleep(std::time::Duration::from_millis(50));
        coordinator.disconnect(owner);
        let output = handle.join().unwrap().unwrap();
        assert!(!output.contains("\n9\n"));
        drop(coordinator);
        cleanup(&dir);
    }

    #[test]
    fn sql_null_order_limit_update_delete_semantics_survive_restart() {
        let dir = temp_dir("sql");
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE t (id BIGINT NOT NULL, v BIGINT, name TEXT)")
                .unwrap();
            db.execute("INSERT INTO t VALUES (1,NULL,'a'),(2,20,'b'),(3,10,'c'),(4,30,'d')")
                .unwrap();
            assert!(rows(db.execute("SELECT id FROM t WHERE v=NULL").unwrap()).is_empty());
            assert_eq!(
                rows(db.execute("SELECT id FROM t WHERE v IS NULL").unwrap()).len(),
                1
            );
            let ordered = rows(
                db.execute("SELECT id FROM t WHERE v IS NOT NULL ORDER BY v DESC LIMIT 2 OFFSET 1")
                    .unwrap(),
            );
            assert_eq!(ordered[0].values, vec![Value::Int64(2)]);
            assert_eq!(ordered[1].values, vec![Value::Int64(3)]);
            db.execute("UPDATE t SET v=v+5 WHERE id=3").unwrap();
            db.execute("DELETE FROM t WHERE id=2").unwrap();
        }
        {
            let mut db = Database::open(&dir).unwrap();
            assert_eq!(
                rows(db.execute("SELECT v FROM t WHERE id=3").unwrap())[0].values,
                vec![Value::Int64(15)]
            );
            assert!(rows(db.execute("SELECT id FROM t WHERE id=2").unwrap()).is_empty());
        }
        cleanup(&dir);
    }

    #[test]
    #[ignore = "longer deterministic restart/transaction soak; run from tools/full-validation.ps1"]
    fn deterministic_restart_soak() {
        let dir = temp_dir("restart-soak");
        let mut expected = BTreeMap::<i64, i64>::new();
        for cycle in 0..25i64 {
            {
                let mut db = Database::open_with_buffer_pages(&dir, 3).unwrap();
                if cycle == 0 {
                    db.execute("CREATE TABLE t (id BIGINT NOT NULL, value BIGINT NOT NULL)")
                        .unwrap();
                    db.execute("CREATE UNIQUE INDEX ux_t_id ON t (id)").unwrap();
                }
                db.execute("BEGIN").unwrap();
                for offset in 0..20i64 {
                    let id = cycle * 20 + offset;
                    db.execute(&format!("INSERT INTO t VALUES ({id},{id})"))
                        .unwrap();
                    expected.insert(id, id);
                }
                if cycle % 3 == 0 && cycle > 0 {
                    let id = cycle - 1;
                    db.execute(&format!("UPDATE t SET value=value+1000 WHERE id={id}"))
                        .unwrap();
                    if let Some(value) = expected.get_mut(&id) {
                        *value += 1000;
                    }
                }
                db.execute("COMMIT").unwrap();
            }
            {
                let mut db = Database::open_with_buffer_pages(&dir, 2).unwrap();
                let result = rows(db.execute("SELECT id,value FROM t ORDER BY id").unwrap());
                assert_eq!(result.len(), expected.len());
                for row in result {
                    let id = match row.values[0] {
                        Value::Int64(value) => value,
                        _ => panic!("id was not BIGINT"),
                    };
                    let value = match row.values[1] {
                        Value::Int64(value) => value,
                        _ => panic!("value was not BIGINT"),
                    };
                    assert_eq!(expected.get(&id), Some(&value));
                }
            }
        }
        cleanup(&dir);
    }

    #[test]
    #[ignore = "longer concurrent write soak; run from tools/full-validation.ps1"]
    fn concurrent_writer_soak() {
        let dir = temp_dir("writer-soak");
        let coordinator = Arc::new(Coordinator::open(&dir).unwrap());
        let setup = coordinator.new_session();
        coordinator
            .execute(
                setup,
                "CREATE TABLE t (id BIGINT NOT NULL, worker BIGINT NOT NULL)",
            )
            .unwrap();
        coordinator
            .execute(setup, "CREATE UNIQUE INDEX ux_t_id ON t (id)")
            .unwrap();
        let workers = 12usize;
        let per_worker = 50usize;
        let barrier = Arc::new(Barrier::new(workers + 1));
        let mut handles = Vec::new();
        for worker in 0..workers {
            let coordinator = Arc::clone(&coordinator);
            let barrier = Arc::clone(&barrier);
            handles.push(thread::spawn(move || {
                let session = coordinator.new_session();
                barrier.wait();
                for offset in 0..per_worker {
                    let id = worker * 1_000_000 + offset;
                    coordinator
                        .execute(session, &format!("INSERT INTO t VALUES ({id},{worker})"))
                        .unwrap();
                }
            }));
        }
        barrier.wait();
        for handle in handles {
            handle.join().unwrap();
        }
        let output = coordinator.execute(setup, "SELECT id FROM t").unwrap();
        assert_eq!(
            output
                .lines()
                .skip(1)
                .filter(|line| !line.is_empty())
                .count(),
            workers * per_worker
        );
        drop(coordinator);
        cleanup(&dir);
    }
    #[test]
    fn phase6_join_aggregate_statistics_and_explain_survive_restart() {
        let dir = temp_dir("phase6-relational");
        {
            let mut db = Database::open(&dir).unwrap();
            db.execute("CREATE TABLE customers (id BIGINT NOT NULL, name TEXT NOT NULL)")
                .unwrap();
            db.execute("CREATE TABLE orders (id BIGINT NOT NULL, customer_id BIGINT NOT NULL, amount BIGINT NOT NULL)")
                .unwrap();
            db.execute("INSERT INTO customers VALUES (1,'Ada'),(2,'Grace'),(3,'Linus')")
                .unwrap();
            db.execute("INSERT INTO orders VALUES (10,1,40),(11,1,60),(12,2,25)")
                .unwrap();
            db.execute("CREATE INDEX ix_orders_customer ON orders (customer_id)")
                .unwrap();
            db.execute("ANALYZE customers").unwrap();
            db.execute("ANALYZE orders").unwrap();
            let result = rows(
                db.execute("SELECT customers.name AS name, COUNT(*) AS n, SUM(orders.amount) AS total FROM customers LEFT JOIN orders ON customers.id=orders.customer_id GROUP BY customers.name ORDER BY name")
                    .unwrap(),
            );
            assert_eq!(result.len(), 3);
            assert_eq!(result[0].values[0], Value::Text("Ada".into()));
            assert_eq!(result[0].values[1], Value::Int64(2));
            assert_eq!(result[0].values[2], Value::Int64(100));
            let explained = rows(
                db.execute("EXPLAIN ANALYZE SELECT customers.name AS name, COUNT(*) AS n FROM customers LEFT JOIN orders ON customers.id=orders.customer_id GROUP BY customers.name")
                    .unwrap(),
            );
            assert!(explained.iter().any(|row| matches!(
                row.values.first(),
                Some(Value::Text(text)) if text.contains("actual rows=")
            )));
        }
        {
            let mut db = Database::open(&dir).unwrap();
            let result = rows(
                db.execute("SELECT customers.name AS name, COUNT(*) AS n FROM customers LEFT JOIN orders ON customers.id=orders.customer_id GROUP BY customers.name ORDER BY name")
                    .unwrap(),
            );
            assert_eq!(result.len(), 3);
        }
        cleanup(&dir);
    }

    #[test]
    #[ignore = "Phase 6 spill/aggregate soak; run explicitly after routine gates"]
    fn phase6_external_sort_and_grouping_soak() {
        let dir = temp_dir("phase6-spill");
        let mut db = Database::open(&dir).unwrap();
        db.execute(
            "CREATE TABLE events (id BIGINT NOT NULL, grp BIGINT NOT NULL, payload TEXT NOT NULL)",
        )
        .unwrap();
        db.execute("BEGIN").unwrap();
        for i in 0..5_000i64 {
            db.execute(&format!(
                "INSERT INTO events VALUES ({i},{},'payload-{i}')",
                i % 37
            ))
            .unwrap();
        }
        db.execute("COMMIT").unwrap();
        db.execute("ANALYZE events").unwrap();
        let grouped = rows(
            db.execute("SELECT grp AS grp, COUNT(*) AS n FROM events GROUP BY grp ORDER BY grp")
                .unwrap(),
        );
        assert_eq!(grouped.len(), 37);
        let sorted = rows(
            db.execute("SELECT id AS id FROM events ORDER BY id DESC LIMIT 10")
                .unwrap(),
        );
        assert_eq!(sorted[0].values[0], Value::Int64(4_999));
        cleanup(&dir);
    }

    #[test]
    fn phase7_auth_roles_backup_restore_and_integrity() {
        use phobos_admin::{backup_offline, check_integrity, restore_offline};
        use phobos_auth::{AuthStore, Role};

        let base = temp_dir("phase7-ops");
        let data = base.join("data");
        let backup = base.join("backup");
        let restored = base.join("restored");
        let auth_path = base.join("phobos.auth");
        {
            let mut auth = AuthStore::open(&auth_path).unwrap();
            auth.upsert_user("reader1", "reader-password-123", Role::Reader)
                .unwrap();
            auth.upsert_user("writer1", "writer-password-123", Role::Writer)
                .unwrap();
            auth.upsert_user("admin1", "admin-password-123", Role::Admin)
                .unwrap();
            assert_eq!(
                auth.authenticate("reader1", "reader-password-123").unwrap(),
                Role::Reader
            );
            assert!(auth.authenticate("reader1", "wrong-password").is_err());
        }
        {
            let mut db = Database::open(&data).unwrap();
            db.execute("CREATE TABLE ops (id BIGINT NOT NULL, value TEXT)")
                .unwrap();
            db.execute("CREATE UNIQUE INDEX ux_ops_id ON ops (id)")
                .unwrap();
            db.execute("INSERT INTO ops VALUES (1,'one'),(2,'two')")
                .unwrap();
            db.execute("ANALYZE ops").unwrap();
        }
        assert!(backup_offline(&data, &backup).unwrap() >= 3);
        restore_offline(&backup, &restored).unwrap();
        let report = check_integrity(&restored).unwrap();
        assert_eq!(report.tables, 1);
        assert_eq!(report.indexes, 1);
        {
            let mut db = Database::open(&restored).unwrap();
            assert_eq!(
                rows(db.execute("SELECT * FROM ops ORDER BY id").unwrap()).len(),
                2
            );
        }
        cleanup(&base);
    }
}
