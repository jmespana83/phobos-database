#![forbid(unsafe_code)]
//! Phase 4 disk-backed B+ tree indexes.
//!
//! The implementation stores fixed 8 KiB meta/node pages, supports unique and non-unique
//! composite keys, linked leaves, point/range lookup, node/root splits, deletion without
//! merge/rebalancing, checksums, and an integrity validator. Transactional crash safety is
//! supplied by the Phase 3 snapshot/WAL layer: `.idx` files are staged and WAL-protected.

use phobos_error::{ErrorCode, PhobosError};
use phobos_storage::page_io::PageIo;
use phobos_types::{RecordId, Value};
mod batch;
mod bulk;
mod committed_reader;
#[cfg(test)]
mod encoded_order_tests;
#[cfg(test)]
mod fast_path_tests;
mod node_view;
mod publication_epoch;
#[cfg(test)]
mod reclaim_prune_tests;
mod unique;
pub use bulk::{BulkBuildReport, compare_entries, decode_key_bytes, encode_key_bytes};
pub use committed_reader::IndexReader as IndexReadHandle;
use std::{
    cmp::Ordering,
    collections::HashSet,
    fs::OpenOptions,
    path::{Path, PathBuf},
};
pub use unique::LogicalUniqueKey;

pub const INDEX_PAGE_SIZE: usize = 8192;
const META_MAGIC: [u8; 4] = *b"PHIX";
const NODE_MAGIC: [u8; 4] = *b"PHIN";
const FORMAT_VERSION: u16 = 3;
const LEGACY_FORMAT_VERSIONS: std::ops::RangeInclusive<u16> = 1..=2;
const META_CHECKSUM_OFFSET: usize = 28;
const NODE_CHECKSUM_OFFSET: usize = 36;
const NODE_HEADER: usize = 48;
const NONE_PAGE: u64 = u64::MAX;
/// 0.1.9-C3: meta bytes 40..48 (after the meta page LSN at 32..40) hold the
/// head of the durable free-page list (0 = empty; page 0 is the meta page,
/// so older files read as "no free list"). Free pages keep the C9 FREE kind
/// and chain through their next-page field (bytes 24..32).
const META_FREE_HEAD: std::ops::Range<usize> = 40..48;

#[cfg(feature = "db1-diagnostics")]
mod db1_diagnostics {
    use std::sync::atomic::{AtomicU64, Ordering};
    pub static SPLITS: AtomicU64 = AtomicU64::new(0);
    pub static CHECKS: AtomicU64 = AtomicU64::new(0);
    pub static FAILURES: AtomicU64 = AtomicU64::new(0);
    pub static MAX_PENDING: AtomicU64 = AtomicU64::new(0);
    pub fn reset() {
        SPLITS.store(0, Ordering::Relaxed);
        CHECKS.store(0, Ordering::Relaxed);
        FAILURES.store(0, Ordering::Relaxed);
        MAX_PENDING.store(0, Ordering::Relaxed);
    }
}

#[cfg(feature = "db1-diagnostics")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Db1DiagnosticCounters {
    pub splits: u64,
    pub successor_checks: u64,
    pub failures: u64,
    pub maximum_pending_generations_at_split: u64,
}

#[cfg(feature = "db1-diagnostics")]
pub fn reset_db1_diagnostic_counters() {
    db1_diagnostics::reset();
}

#[cfg(feature = "db1-diagnostics")]
pub fn db1_diagnostic_counters() -> Db1DiagnosticCounters {
    use std::sync::atomic::Ordering;
    Db1DiagnosticCounters {
        splits: db1_diagnostics::SPLITS.load(Ordering::Relaxed),
        successor_checks: db1_diagnostics::CHECKS.load(Ordering::Relaxed),
        failures: db1_diagnostics::FAILURES.load(Ordering::Relaxed),
        maximum_pending_generations_at_split: db1_diagnostics::MAX_PENDING.load(Ordering::Relaxed),
    }
}
const MAX_KEY_BYTES: usize = 2048;

#[derive(Debug, Clone)]
pub struct IndexKey(pub Vec<Value>);

impl PartialEq for IndexKey {
    fn eq(&self, other: &Self) -> bool {
        compare_key(self, other) == Ordering::Equal
    }
}
impl Eq for IndexKey {}
impl PartialOrd for IndexKey {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}
impl Ord for IndexKey {
    fn cmp(&self, other: &Self) -> Ordering {
        compare_key(self, other)
    }
}

impl IndexKey {
    /// Apply the physical key contract before acquiring logical ownership or
    /// accepting an irrevocable commit. Tree insertion repeats this validation.
    pub fn validate_columns(&self, columns: usize) -> Result<(), PhobosError> {
        if self.0.len() != columns {
            return Err(index_error("index key column count mismatch"));
        }
        // 0.2-H: the encoded length without building the encoding
        // (`encoded_key_len` == `encode_key(..).len()`, test below).
        if encoded_key_len(self) > MAX_KEY_BYTES {
            return Err(PhobosError::new(
                ErrorCode::ConstraintViolation,
                "index key exceeds Phase 4 maximum encoded size",
            ));
        }
        Ok(())
    }
    #[must_use]
    pub fn contains_null(&self) -> bool {
        self.0.iter().any(Value::is_null)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Bound<'a> {
    Unbounded,
    Included(&'a IndexKey),
    Excluded(&'a IndexKey),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum NodeKind {
    Leaf,
    Internal,
}

#[derive(Debug, Clone)]
struct LeafEntry {
    key: IndexKey,
    rid: RecordId,
}

/// 0.2-K: a leaf of a duplicate run with its `(parent, child position)`
/// cursor and whether that cursor is known to be exact.
type RunPosition = (u64, Vec<(u64, usize)>, bool);

#[derive(Debug, Clone)]
struct InternalEntry {
    key: IndexKey,
    child: u64,
}

#[derive(Debug, Clone)]
struct Node {
    id: u64,
    parent: u64,
    next_leaf: u64,
    first_child: u64,
    kind: NodeKind,
    leaf: Vec<LeafEntry>,
    internal: Vec<InternalEntry>,
}

impl Node {
    fn new_leaf(id: u64, parent: u64) -> Self {
        Self {
            id,
            parent,
            next_leaf: NONE_PAGE,
            first_child: NONE_PAGE,
            kind: NodeKind::Leaf,
            leaf: Vec::new(),
            internal: Vec::new(),
        }
    }

    fn new_internal(id: u64, parent: u64, first_child: u64) -> Self {
        Self {
            id,
            parent,
            next_leaf: NONE_PAGE,
            first_child,
            kind: NodeKind::Internal,
            leaf: Vec::new(),
            internal: Vec::new(),
        }
    }

    fn encoded_len(&self) -> Result<usize, PhobosError> {
        let body = match self.kind {
            NodeKind::Leaf => self.leaf.iter().try_fold(0usize, |total, entry| {
                let key_len = encoded_key_len(&entry.key);
                total
                    .checked_add(2 + key_len + 8 + 2)
                    .ok_or_else(|| index_error("index node length overflow"))
            })?,
            NodeKind::Internal => self.internal.iter().try_fold(8usize, |total, entry| {
                let key_len = encoded_key_len(&entry.key);
                total
                    .checked_add(2 + key_len + 8)
                    .ok_or_else(|| index_error("index node length overflow"))
            })?,
        };
        NODE_HEADER
            .checked_add(body)
            .ok_or_else(|| index_error("index node length overflow"))
    }
}

#[derive(Debug)]
pub struct BPlusTree {
    batch: Option<batch::Cache>,
    publication: std::sync::Arc<publication_epoch::Epoch>,
    reader: Option<committed_reader::IndexReader>,
    path: PathBuf,
    file: PageIo,
    root_page: u64,
    next_page: u64,
    /// C3 free-list head (0 = none).
    free_head: u64,
    unique: bool,
    key_columns: u16,
    private_original: Option<(u64, u64, u64)>,
    meta_dirty: bool,
    write_counters: IndexWriteCounters,
    navigation: Option<committed_reader::Navigation>,
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct IndexWriteCounters {
    pub parent_pointer_rewrite_writes: u64,
    pub meta_page_writes: u64,
}

/// Diagnostic-only physical leaf entry used by the db1 forensic harness.
#[cfg(feature = "db1-diagnostics")]
#[derive(Debug, Clone, PartialEq)]
pub struct DiagnosticIndexEntry {
    pub key: IndexKey,
    pub rid: RecordId,
    pub leaf_page: u64,
    pub page_lsn: u64,
    pub next_leaf: u64,
    pub position: usize,
}

impl BPlusTree {
    pub fn attach_committed(
        &mut self,
        store: &std::sync::Arc<phobos_storage::committed_pages::CommittedStore>,
        identity: phobos_wal::v2::FileId,
    ) -> Result<(), PhobosError> {
        phobos_storage::committed_pages::set_index_page_validators(
            validate_index_page_image,
            validate_index_page_structure,
            validate_index_page_layout,
        );
        self.file.attach_committed(store, &self.path, identity)
    }
    pub fn open(
        path: impl AsRef<Path>,
        unique: bool,
        key_columns: usize,
    ) -> Result<Self, PhobosError> {
        Self::open_impl(path, unique, key_columns, false)
    }

    /// Offline migration reader. Legacy pages remain decoded under their old
    /// codec; normal engine open rejects them so they cannot be reinterpreted
    /// or mutated accidentally.
    pub fn open_legacy_for_reindex(
        path: impl AsRef<Path>,
        unique: bool,
        key_columns: usize,
    ) -> Result<Self, PhobosError> {
        Self::open_impl(path, unique, key_columns, true)
    }

    fn open_impl(
        path: impl AsRef<Path>,
        unique: bool,
        key_columns: usize,
        allow_legacy: bool,
    ) -> Result<Self, PhobosError> {
        if key_columns == 0 || key_columns > u16::MAX as usize {
            return Err(index_error(
                "index must have between 1 and 65535 key columns",
            ));
        }
        let path = path.as_ref().to_path_buf();
        let exists = path.exists();
        let file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .truncate(false)
            .open(&path)?;
        let mut file = PageIo::new(file);
        if !exists || file.is_empty()? {
            let mut tree = Self {
                batch: None,
                publication: std::sync::Arc::default(),
                reader: None,
                path,
                file,
                root_page: 1,
                next_page: 2,
                free_head: 0,
                unique,
                key_columns: key_columns as u16,
                private_original: None,
                meta_dirty: false,
                write_counters: IndexWriteCounters::default(),
                navigation: None,
            };
            tree.write_meta()?;
            tree.write_node(&Node::new_leaf(1, NONE_PAGE))?;
            tree.sync()?;
            return Ok(tree);
        }
        let meta = read_page(&mut file, 0)?;
        validate_meta_checksum(&meta)?;
        if meta[0..4] != META_MAGIC {
            return Err(index_error("invalid index meta magic"));
        }
        let version = u16::from_le_bytes([meta[4], meta[5]]);
        if version != FORMAT_VERSION && !(allow_legacy && LEGACY_FORMAT_VERSIONS.contains(&version))
        {
            return Err(index_error(if LEGACY_FORMAT_VERSIONS.contains(&version) {
                "legacy index format requires offline phobos-admin reindex"
            } else {
                "unsupported index format version"
            }));
        }
        let stored_unique = meta[6] != 0;
        let stored_columns = u16::from_le_bytes([meta[8], meta[9]]);
        if stored_unique != unique || stored_columns != key_columns as u16 {
            return Err(index_error(
                "index metadata does not match catalog definition",
            ));
        }
        let root_page = u64::from_le_bytes(meta[12..20].try_into().expect("root page"));
        let next_page = u64::from_le_bytes(meta[20..28].try_into().expect("next page"));
        if root_page == 0 || next_page <= root_page {
            return Err(index_error("invalid index meta page identifiers"));
        }
        let expected_len = next_page
            .checked_mul(INDEX_PAGE_SIZE as u64)
            .ok_or_else(|| index_error("index file length overflow"))?;
        if file.len()? != expected_len {
            return Err(index_error(
                "index file length does not match page metadata",
            ));
        }
        let free_head = u64::from_le_bytes(meta[META_FREE_HEAD].try_into().expect("free head"));
        if free_head >= next_page {
            return Err(index_error("index free-list head is out of range"));
        }
        Ok(Self {
            batch: None,
            publication: std::sync::Arc::default(),
            reader: None,
            path,
            file,
            root_page,
            next_page,
            free_head,
            unique,
            key_columns: stored_columns,
            private_original: None,
            meta_dirty: false,
            write_counters: IndexWriteCounters::default(),
            navigation: None,
        })
    }

    #[must_use]
    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn begin_private(
        &mut self,
        scratch: &Path,
        txn_id: u64,
        database: &Path,
    ) -> Result<(), PhobosError> {
        if self.private_original.is_some() {
            return Err(index_error("index already private"));
        }
        self.file.sync_before_private()?;
        self.file.begin_private(scratch, txn_id, database)?;
        self.private_original = Some((self.root_page, self.next_page, self.free_head));
        self.meta_dirty = false;
        Ok(())
    }
    pub fn prepare_private(
        &mut self,
        visitor: impl FnMut(u64, &[u8; INDEX_PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush_deferred_meta()?;
        self.file.prepare_private(visitor)
    }
    pub fn prepare_private_deferred(
        &mut self,
        visitor: impl FnMut(u64, &[u8; INDEX_PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush_deferred_meta()?;
        self.file.prepare_private_deferred(visitor)
    }
    pub fn install_private(
        &mut self,
        receipt: &phobos_wal::v2::DurableCommit,
    ) -> Result<(), PhobosError> {
        let publication = self.publication.clone();
        let guard = publication.begin()?;
        self.file.install_private(receipt)?;
        self.private_original = None;
        guard.complete();
        Ok(())
    }
    pub fn prepare_private_redo(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(u64, &mut [u8; INDEX_PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush_deferred_meta()?;
        self.file.prepare_private_redo(file, visitor)
    }
    pub fn prepare_private_redo_phased(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; INDEX_PAGE_SIZE],
            bool,
            phobos_storage::page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush_deferred_meta()?;
        self.file.prepare_private_redo_phased(file, visitor)
    }
    /// 0.2-D: `prepare_private_redo_phased` with each page's base image.
    pub fn prepare_private_redo_based(
        &mut self,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; INDEX_PAGE_SIZE],
            Option<&[u8; INDEX_PAGE_SIZE]>,
            bool,
            phobos_storage::page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.flush_deferred_meta()?;
        self.file.prepare_private_redo_based(file, visitor)
    }
    /// 0.2-D: `prepare_pending_redo_phased` with each page's base image.
    pub fn prepare_pending_redo_based(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; INDEX_PAGE_SIZE],
            Option<&[u8; INDEX_PAGE_SIZE]>,
            bool,
            phobos_storage::page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.file
            .prepare_pending_redo_based(transaction, file, visitor)
    }
    pub fn force_committed(&mut self) -> Result<(), PhobosError> {
        self.file.force_committed()
    }
    pub fn stage_private(&mut self) -> Result<(), PhobosError> {
        self.file.stage_private()?;
        self.private_original = None;
        Ok(())
    }
    pub fn private_page_count(&self) -> Result<u64, PhobosError> {
        let pages = self.file.private_page_count()?;
        Ok(pages.saturating_add(u64::from(self.meta_dirty)))
    }
    pub fn prepare_pending_redo(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(u64, &mut [u8; INDEX_PAGE_SIZE], bool) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.file.prepare_pending_redo(transaction, file, visitor)
    }
    pub fn prepare_pending_redo_phased(
        &mut self,
        transaction: u64,
        file: phobos_wal::v2::FileId,
        visitor: impl FnMut(
            u64,
            &mut [u8; INDEX_PAGE_SIZE],
            bool,
            phobos_storage::page_io::RedoPhase,
        ) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        self.file
            .prepare_pending_redo_phased(transaction, file, visitor)
    }
    pub fn install_pending(
        &mut self,
        receipt: &phobos_wal::v2::DurableCommit,
    ) -> Result<(), PhobosError> {
        let publication = self.publication.clone();
        let guard = publication.begin()?;
        self.file.install_pending(receipt)?;
        guard.complete();
        Ok(())
    }
    pub fn defer_private_cleanup(&mut self) -> Result<(), PhobosError> {
        self.file.defer_private_cleanup()
    }
    pub fn rollback_private(&mut self) -> Result<(), PhobosError> {
        let (root, next, free_head) = self
            .private_original
            .ok_or_else(|| index_error("index is not private"))?;
        self.file.rollback_private()?;
        self.root_page = root;
        self.next_page = next;
        self.free_head = free_head;
        self.private_original = None;
        self.meta_dirty = false;
        Ok(())
    }

    #[must_use]
    pub fn unique(&self) -> bool {
        self.unique
    }

    pub fn insert(&mut self, key: IndexKey, rid: RecordId) -> Result<(), PhobosError> {
        self.insert_entry(key, rid, true)
    }

    /// Offline reindex only: preserve every physical historical entry while
    /// rebuilding an index under the current encoding.
    pub fn insert_reindex_entry(
        &mut self,
        key: IndexKey,
        rid: RecordId,
    ) -> Result<(), PhobosError> {
        self.insert_entry(key, rid, false)
    }

    pub fn all_entries(&mut self) -> Result<Vec<(IndexKey, RecordId)>, PhobosError> {
        let mut entries = Vec::new();
        self.range_entry_visit(
            Bound::Unbounded,
            Bound::Unbounded,
            &mut |entry: &LeafEntry| {
                entries.push((entry.key.clone(), entry.rid));
                Ok(true)
            },
        )?;
        Ok(entries)
    }

    /// MVCC publisher only: logical uniqueness must already be protected and
    /// rechecked by the transaction owner. Historical entries are retained.
    pub fn insert_version(
        &mut self,
        key: IndexKey,
        rid: RecordId,
        stable: u64,
    ) -> Result<(), PhobosError> {
        if self.file.private_owner()? != stable {
            return Err(index_error("index version/private owner mismatch"));
        }
        self.insert_entry(key, rid, false)
    }

    fn insert_entry(
        &mut self,
        key: IndexKey,
        rid: RecordId,
        enforce_unique: bool,
    ) -> Result<(), PhobosError> {
        self.file.ensure_writable()?;
        self.validate_key(&key)?;
        if !enforce_unique && self.batch.is_none() && self.insert_entry_in_place(&key, rid)? {
            return Ok(());
        }
        self.insert_entry_generic(key, rid, enforce_unique)
    }

    /// 0.2-C: `insert_entry(key, rid, false)` without decoding or re-encoding
    /// nodes. Same descent (child rule), same duplicate probe along the leaf
    /// chain, same (key, rid) placement, and a byte-identical page image to
    /// `encode_node` of the updated node. Returns `false` (nothing written)
    /// whenever the generic path is needed: legacy node formats, a probe that
    /// spans more than two leaves, or a leaf that must split.
    fn insert_entry_in_place(
        &mut self,
        key: &IndexKey,
        rid: RecordId,
    ) -> Result<bool, PhobosError> {
        let encoded = encode_key(key)?;
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        let leaf = loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            if page_id == 0 || page_id >= self.next_page {
                return Err(index_error("index page identifier is out of range"));
            }
            // 0.2-F: committed images validated on store entry are shared and
            // viewed without re-validation; private images are validated.
            let (bytes, trusted) = read_page_ref(&mut self.file, page_id)?;
            let view = if trusted {
                node_view::NodeView::new_trusted(&bytes, page_id)?
            } else {
                node_view::NodeView::new(&bytes, page_id)?
            };
            if view.version() != FORMAT_VERSION {
                return Ok(false);
            }
            if view.kind == NodeKind::Leaf {
                break bytes;
            }
            // Generic rule: the last entry whose key is < target selects the
            // child; equality stops at the preceding child.
            page_id = view.child_at(view.lower_bound_bytes(&encoded));
        };
        let leaf_id = page_id;
        // Validated (or trusted) in the descent above: rebuild the offsets only.
        let view = node_view::NodeView::new_trusted(&leaf, leaf_id)?;
        let lower = view.lower_bound_bytes(&encoded);
        let mut position = lower;
        while position < view.count && view.key_bytes(position) == encoded.as_slice() {
            let existing = view.leaf_rid(position);
            if existing == rid {
                // The exact physical entry already exists.
                return Ok(true);
            }
            if existing > rid {
                break;
            }
            position += 1;
        }
        // The duplicate probe continues into the next leaf only when every
        // entry from the target onward is <= the key (as the generic probe).
        let mut scan = position;
        while scan < view.count && view.key_bytes(scan) == encoded.as_slice() {
            if view.leaf_rid(scan) == rid {
                return Ok(true);
            }
            scan += 1;
        }
        if scan == view.count && view.next != NONE_PAGE {
            let next_id = view.next;
            if next_id == 0 || next_id >= self.next_page {
                return Err(index_error("index page identifier is out of range"));
            }
            let (next, next_trusted) = read_page_ref(&mut self.file, next_id)?;
            let next_view = if next_trusted {
                node_view::NodeView::new_trusted(&next, next_id)?
            } else {
                node_view::NodeView::new(&next, next_id)?
            };
            if next_view.kind != NodeKind::Leaf {
                return Err(index_error("leaf chain points to an internal node"));
            }
            if next_view.version() != FORMAT_VERSION {
                return Ok(false);
            }
            let mut i = 0;
            while i < next_view.count && next_view.key_bytes(i) <= encoded.as_slice() {
                if next_view.key_bytes(i) == encoded.as_slice() && next_view.leaf_rid(i) == rid {
                    return Ok(true);
                }
                i += 1;
            }
            if i == next_view.count && next_view.next != NONE_PAGE {
                return Ok(false);
            }
        }
        let key_len =
            u16::try_from(encoded.len()).map_err(|_| index_error("index key too large"))?;
        let entry_len = 2 + encoded.len() + 10;
        let used = usize::from(u16::from_le_bytes([leaf[34], leaf[35]]));
        if used + entry_len > INDEX_PAGE_SIZE {
            return Ok(false);
        }
        let offset = if position < view.count {
            view.entry_offset(position)
        } else {
            used
        };
        let count = u16::try_from(view.count + 1)
            .map_err(|_| index_error("too many index node entries"))?;
        let _measurement = phobos_observability::span("index.in_place_insert");
        let mut page = *leaf;
        page.copy_within(offset..used, offset + entry_len);
        page[offset..offset + 2].copy_from_slice(&key_len.to_le_bytes());
        page[offset + 2..offset + 2 + encoded.len()].copy_from_slice(&encoded);
        let rid_at = offset + 2 + encoded.len();
        page[rid_at..rid_at + 8].copy_from_slice(&rid.page_id.to_le_bytes());
        page[rid_at + 8..rid_at + 10].copy_from_slice(&rid.slot_id.to_le_bytes());
        let new_used = used + entry_len;
        page[new_used..].fill(0);
        // Canonical header, as `encode_node` writes it.
        page[7] = phobos_wal::page_checksum::CRC32C;
        page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
        page[32..34].copy_from_slice(&count.to_le_bytes());
        page[34..36].copy_from_slice(&(new_used as u16).to_le_bytes());
        page[40..48].fill(0);
        let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
        page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4]
            .copy_from_slice(&checksum.to_le_bytes());
        phobos_observability::event("index.in_place_inserts", 1);
        write_page(&mut self.file, leaf_id, &page)?;
        phobos_observability::certification_crash("during_index_update");
        Ok(true)
    }

    fn insert_entry_generic(
        &mut self,
        key: IndexKey,
        rid: RecordId,
        enforce_unique: bool,
    ) -> Result<(), PhobosError> {
        // Retain the validated leaf from the first descent. Scan the same sibling
        // chain as point_lookup so duplicates spanning split leaves remain visible.
        let (mut leaf, path) = self.find_leaf_node_with_path(&key)?;
        let existing = {
            let _probe = phobos_observability::span("index.insert_probe");
            let mut existing = Vec::new();
            let mut following: Option<Node> = None;
            loop {
                let current = following.as_ref().unwrap_or(&leaf);
                if current.kind != NodeKind::Leaf {
                    return Err(index_error("leaf chain points to an internal node"));
                }
                let mut past_key = false;
                for entry in &current.leaf {
                    match entry.key.cmp(&key) {
                        Ordering::Less => {}
                        Ordering::Equal => existing.push(entry.rid),
                        Ordering::Greater => {
                            past_key = true;
                            break;
                        }
                    }
                }
                if past_key || current.next_leaf == NONE_PAGE {
                    break;
                }
                following = Some(self.read_node(current.next_leaf)?);
            }
            existing
        };

        // A physical index entry is identified by (key, RecordId).
        // Even non-unique indexes must not contain the exact same entry twice.
        if existing.contains(&rid) {
            return Ok(());
        }

        let mut conflict = !existing.is_empty();
        if enforce_unique && self.unique && !key.contains_null() && !conflict {
            self.unique_visit(&key, |_| {
                conflict = true;
                Ok(false)
            })?;
        }
        if enforce_unique && self.unique && !key.contains_null() && conflict {
            return Err(PhobosError::new(
                ErrorCode::ConstraintViolation,
                "duplicate key violates unique index",
            ));
        }

        if leaf
            .leaf
            .iter()
            .any(|entry| entry.key == key && entry.rid == rid)
        {
            return Ok(());
        }
        let position = leaf
            .leaf
            .binary_search_by(|entry| compare_entry(entry, &key, rid))
            .unwrap_or_else(|position| position);
        leaf.leaf.insert(position, LeafEntry { key, rid });
        if leaf.encoded_len()? <= INDEX_PAGE_SIZE {
            self.write_node(&leaf)?;
            phobos_observability::certification_crash("during_index_update");
            return Ok(());
        }
        self.split_leaf(leaf, path)
    }

    pub fn delete(&mut self, key: &IndexKey, rid: RecordId) -> Result<bool, PhobosError> {
        self.file.ensure_writable()?;
        self.validate_key(key)?;
        let mut leaf_id = self.find_leaf(key)?;
        loop {
            let mut leaf = self.read_node(leaf_id)?;
            if let Some(position) = leaf
                .leaf
                .iter()
                .position(|entry| entry.key == *key && entry.rid == rid)
            {
                leaf.leaf.remove(position);
                self.write_node(&leaf)?;
                // Phase 4 deletion deliberately leaves under-full nodes in place. Search correctness
                // and leaf linkage remain valid; merge/rebalancing is a documented follow-up.
                return Ok(true);
            }
            // An emptied leaf (C3 leaves a parent's first child in place)
            // owns no key: keep walking the chain past it.
            let may_continue = leaf.leaf.last().is_none_or(|entry| entry.key <= *key);
            if !may_continue || leaf.next_leaf == NONE_PAGE {
                return Ok(false);
            }
            leaf_id = leaf.next_leaf;
        }
    }

    /// 0.1.9-C3, MVCC reclaimer only: remove the exact `(key, rid)` entry of
    /// a globally dead heap version from the private image. Returns
    /// `(removed, freed_page)`. A leaf left empty is detached and placed on
    /// the durable free list when that keeps the tree valid without
    /// rebalancing: it must not be the root and must have a left sibling
    /// under the same parent (that sibling takes over its key range and its
    /// place in the leaf chain). Otherwise the empty leaf simply stays.
    pub fn delete_version(
        &mut self,
        key: &IndexKey,
        rid: RecordId,
        stable: u64,
    ) -> Result<(bool, bool), PhobosError> {
        if self.file.private_owner()? != stable {
            return Err(index_error("index version/private owner mismatch"));
        }
        self.file.ensure_writable()?;
        self.validate_key(key)?;
        // 0.2-K Part L. The duplicate run of `key` may span many leaves and is
        // ordered by `(key, rid)`. The previous implementation searched each
        // leaf linearly and, once it had walked right of its descent path,
        // computed a detach path by a whole-tree DFS (`find_path_to_page`)
        // for EVERY deleted entry, emptied leaf or not. Now:
        // * the descent records `(parent, child position)` pairs and walking
        //   right advances that cursor (classic B+tree iterator), so the
        //   parent path of every visited leaf is known without a DFS;
        // * a leaf is searched by binary search on `(key, rid)`, and a leaf
        //   whose last entry sorts before `(key, rid)` is skipped unsearched;
        // * the detach path is used only when the leaf actually becomes empty.
        // The DFS remains only as a fallback if the sibling chain and the
        // cursor ever disagree (never expected; it was the old behaviour).
        let (first_leaf, mut cursor) = self.find_leaf_with_cursor(key)?;
        let mut leaf = first_leaf;
        let mut cursor_valid = true;
        let mut remaining = self.next_page;
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index leaf walk exceeded page bound"))?;
            if leaf.kind != NodeKind::Leaf {
                return Err(index_error("leaf chain points to an internal node"));
            }
            // Binary search to the first entry of `key` (keys are ordered in
            // every leaf), then the exact RID within that leaf's run. RIDs of
            // equal keys are normally ordered too, but this does not rely on
            // it.
            let start = leaf.leaf.partition_point(|entry| entry.key < *key);
            let found = leaf.leaf[start..]
                .iter()
                .take_while(|entry| entry.key == *key)
                .position(|entry| entry.rid == rid)
                .map(|offset| start + offset);
            if let Some(position) = found {
                leaf.leaf.remove(position);
                if leaf.leaf.is_empty() && leaf.id != self.root_page {
                    let detach_path = if cursor_valid {
                        cursor.iter().map(|(parent, _)| *parent).collect::<Vec<_>>()
                    } else {
                        phobos_observability::event("index.reclaim_path_dfs", 1);
                        self.find_path_to_page(leaf.id)?.unwrap_or_default()
                    };
                    if self.detach_empty_leaf(&leaf, &detach_path)? {
                        return Ok((true, true));
                    }
                }
                self.write_node(&leaf)?;
                return Ok((true, false));
            }
            let may_continue = leaf.leaf.last().is_none_or(|entry| entry.key <= *key);
            if !may_continue || leaf.next_leaf == NONE_PAGE {
                return Ok((false, false));
            }
            let next = leaf.next_leaf;
            if cursor_valid {
                cursor_valid = self.advance_leaf_cursor(&mut cursor)? == Some(next);
            }
            leaf = self.read_node(next)?;
            phobos_observability::event("index.reclaim_leaf_walk", 1);
        }
    }

    /// 0.2-K Part L: reclaim pruning of many exact `(key, RID)` entries,
    /// sorted by `(key, RID)` (the order of the leaf entries). Same result as
    /// calling `delete_version` for each entry in order, but the walk along a
    /// duplicate run continues from the leaf of the previous deletion instead
    /// of restarting at the first leaf of the run, and leaves are searched
    /// through the zero-copy node view (only the leaf that changes is
    /// decoded). If an entry is not found ahead of the current position (a run
    /// whose RIDs are not ordered across leaves), the run is searched again
    /// from its first leaf, exactly as `delete_version` does. Returns, per
    /// entry, whether it was removed.
    pub fn delete_versions_sorted(
        &mut self,
        entries: &[(IndexKey, RecordId)],
        stable: u64,
    ) -> Result<Vec<bool>, PhobosError> {
        if self.file.private_owner()? != stable {
            return Err(index_error("index version/private owner mismatch"));
        }
        self.file.ensure_writable()?;
        // 0.2-K.3: leaf-grouped exact removal. Consecutive (sorted) entries
        // found in the same current-format leaf are removed with ONE page
        // rewrite (one copy, one checksum, one private write, one WAL
        // delta) instead of one per entry. Anything else (legacy leaf, a
        // run continuing into the next leaf, a leaf that would become empty,
        // an active batch) takes the per-entry path below, unchanged.
        let mut done = vec![false; entries.len()];
        let mut fallback = Vec::new();
        let mut i = 0;
        while i < entries.len() {
            if self.batch.is_some() {
                fallback.extend(i..entries.len());
                break;
            }
            self.validate_key(&entries[i].0)?;
            let (leaf_id, _) = self.find_leaf_id_with_cursor(&entries[i].0)?;
            let (bytes, trusted) = read_page_ref(&mut self.file, leaf_id)?;
            let view = if trusted {
                node_view::NodeView::new_trusted(&bytes, leaf_id)?
            } else {
                node_view::NodeView::new(&bytes, leaf_id)?
            };
            if view.kind != NodeKind::Leaf || view.version() != FORMAT_VERSION {
                fallback.push(i);
                i += 1;
                continue;
            }
            let mut positions = Vec::new();
            let mut j = i;
            while j < entries.len() {
                let encoded = encode_key(&entries[j].0)?;
                let mut at = view.lower_bound_bytes(&encoded);
                let mut hit = None;
                while at < view.count && view.key_bytes(at) == encoded.as_slice() {
                    if view.leaf_rid(at) == entries[j].1 {
                        hit = Some(at);
                        break;
                    }
                    at += 1;
                }
                match hit {
                    Some(at) if positions.last().is_none_or(|last| *last < at) => {
                        positions.push(at);
                        j += 1;
                    }
                    _ => break,
                }
            }
            if positions.is_empty() || positions.len() >= view.count {
                fallback.push(i);
                i += 1;
                continue;
            }
            let mut page: [u8; INDEX_PAGE_SIZE] = *bytes;
            let mut cursor = view.entry_offset(0);
            let mut skip = positions.iter().peekable();
            for at in 0..view.count {
                let start = view.entry_offset(at);
                let end = start + 2 + view.key_bytes(at).len() + 10;
                if skip.peek() == Some(&&at) {
                    skip.next();
                    continue;
                }
                page[cursor..cursor + (end - start)].copy_from_slice(&bytes[start..end]);
                cursor += end - start;
            }
            let count = (view.count - positions.len()) as u16;
            drop(bytes);
            page[cursor..].fill(0);
            page[32..34].copy_from_slice(&count.to_le_bytes());
            page[34..36].copy_from_slice(&(cursor as u16).to_le_bytes());
            page[7] = phobos_wal::page_checksum::CRC32C;
            page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
            page[40..48].fill(0);
            let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
            page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4]
                .copy_from_slice(&checksum.to_le_bytes());
            phobos_observability::event("index.reclaim_inplace_removals", positions.len() as u64);
            phobos_observability::event("index.reclaim_leaf_rewrites", 1);
            write_page(&mut self.file, leaf_id, &page)?;
            for flag in &mut done[i..j] {
                *flag = true;
            }
            i = j;
        }
        if fallback.is_empty() {
            return Ok(done);
        }
        let rest = fallback
            .iter()
            .map(|at| entries[*at].clone())
            .collect::<Vec<_>>();
        let removed_rest = self.delete_versions_sorted_each(&rest)?;
        for (at, removed) in fallback.into_iter().zip(removed_rest) {
            done[at] = removed;
        }
        Ok(done)
    }

    /// The per-entry exact removal (0.2-K Part L), used for entries the
    /// leaf-grouped path does not take.
    fn delete_versions_sorted_each(
        &mut self,
        entries: &[(IndexKey, RecordId)],
    ) -> Result<Vec<bool>, PhobosError> {
        let mut removed = Vec::with_capacity(entries.len());
        let mut start = 0;
        while start < entries.len() {
            let key = &entries[start].0;
            let mut end = start + 1;
            while end < entries.len() && entries[end].0 == *key {
                end += 1;
            }
            self.validate_key(key)?;
            let encoded = encode_key(key)?;
            // Position of the previous deletion of this run (leaf, cursor).
            let mut position: Option<RunPosition> = None;
            for (_, rid) in &entries[start..end] {
                let mut found = None;
                if let Some((leaf, cursor, valid)) = position.take() {
                    found = self.prune_run_from(key, &encoded, *rid, leaf, cursor, valid)?;
                }
                if found.is_none() {
                    let (first, cursor) = self.find_leaf_id_with_cursor(key)?;
                    found = self.prune_run_from(key, &encoded, *rid, first, cursor, true)?;
                }
                match found {
                    Some(next) => {
                        removed.push(true);
                        position = next;
                    }
                    None => removed.push(false),
                }
            }
            start = end;
        }
        Ok(removed)
    }

    /// Walks the run of `encoded` from `leaf` to the right and removes the
    /// exact `(key, rid)` entry. `None`: not found ahead. `Some(position)`:
    /// removed; `position` is where the next (larger) RID of the run should be
    /// searched from (`None` when the leaf was detached).
    fn prune_run_from(
        &mut self,
        key: &IndexKey,
        encoded: &[u8],
        rid: RecordId,
        mut leaf_id: u64,
        mut cursor: Vec<(u64, usize)>,
        mut cursor_valid: bool,
    ) -> Result<Option<Option<RunPosition>>, PhobosError> {
        let mut remaining = self.next_page;
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index leaf walk exceeded page bound"))?;
            if leaf_id == 0 || leaf_id >= self.next_page {
                return Err(index_error("index page identifier is out of range"));
            }
            let (bytes, trusted) = read_page_ref(&mut self.file, leaf_id)?;
            let view = if trusted {
                node_view::NodeView::new_trusted(&bytes, leaf_id)?
            } else {
                node_view::NodeView::new(&bytes, leaf_id)?
            };
            if view.kind != NodeKind::Leaf {
                return Err(index_error("leaf chain points to an internal node"));
            }
            if view.version() != FORMAT_VERSION {
                // Legacy node encoding: the typed, decoded path.
                let (removed, _) = self.delete_version(key, rid, self.file.private_owner()?)?;
                return Ok(removed.then_some(None));
            }
            let mut at = view.lower_bound_bytes(encoded);
            let mut hit = false;
            while at < view.count && view.key_bytes(at) == encoded {
                if view.leaf_rid(at) == rid {
                    hit = true;
                    break;
                }
                at += 1;
            }
            let continues = view.count == 0 || view.key_bytes(view.count - 1) <= encoded;
            let next = view.next;
            // 0.2-K Part L: remove the entry in place when the leaf keeps at
            // least one entry (no detach) and is in the current format: the
            // result is byte-identical to decoding, removing and re-encoding
            // (entries are stored in their canonical encoding, the tail
            // after `used` is zero, the reserved parent field and the page
            // LSN are zero; test `k_batch_pruning_equals_per_entry_pruning_page_for_page`).
            if hit && self.batch.is_none() && view.version() == FORMAT_VERSION && view.count > 1 {
                let start = view.entry_offset(at);
                let key_len = view.key_bytes(at).len();
                let end = start + 2 + key_len + 10;
                let mut page: [u8; INDEX_PAGE_SIZE] = *bytes;
                drop(bytes);
                let used = usize::from(u16::from_le_bytes([page[34], page[35]]));
                let count = u16::from_le_bytes([page[32], page[33]]) - 1;
                page.copy_within(end..used, start);
                let used = used - (end - start);
                page[used..].fill(0);
                page[32..34].copy_from_slice(&count.to_le_bytes());
                page[34..36].copy_from_slice(&(used as u16).to_le_bytes());
                page[7] = phobos_wal::page_checksum::CRC32C;
                page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
                // Page LSN: stamped by redo preparation, as for `encode_node`.
                page[40..48].fill(0);
                let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
                page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4]
                    .copy_from_slice(&checksum.to_le_bytes());
                phobos_observability::event("index.reclaim_inplace_removals", 1);
                write_page(&mut self.file, leaf_id, &page)?;
                return Ok(Some(Some((leaf_id, cursor, cursor_valid))));
            }
            drop(bytes);
            if hit {
                let mut leaf = self.read_node(leaf_id)?;
                let position = leaf
                    .leaf
                    .iter()
                    .position(|entry| entry.key == *key && entry.rid == rid)
                    .ok_or_else(|| index_error("index leaf view and node disagree"))?;
                leaf.leaf.remove(position);
                if leaf.leaf.is_empty() && leaf.id != self.root_page {
                    let detach_path = if cursor_valid {
                        cursor.iter().map(|(parent, _)| *parent).collect::<Vec<_>>()
                    } else {
                        phobos_observability::event("index.reclaim_path_dfs", 1);
                        self.find_path_to_page(leaf.id)?.unwrap_or_default()
                    };
                    if self.detach_empty_leaf(&leaf, &detach_path)? {
                        return Ok(Some(None));
                    }
                }
                self.write_node(&leaf)?;
                return Ok(Some(Some((leaf_id, cursor, cursor_valid))));
            }
            if !continues || next == NONE_PAGE {
                return Ok(None);
            }
            if cursor_valid {
                cursor_valid = self.advance_leaf_cursor(&mut cursor)? == Some(next);
            }
            leaf_id = next;
            phobos_observability::event("index.reclaim_leaf_walk", 1);
        }
    }

    /// 0.2-K: descent by `key` with the same child rule as
    /// `find_leaf_node_with_path`, recording `(internal node, child
    /// position)` per level (position 0 = `first_child`, `p` =
    /// `internal[p - 1].child`).
    fn find_leaf_with_cursor(
        &mut self,
        key: &IndexKey,
    ) -> Result<(Node, Vec<(u64, usize)>), PhobosError> {
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        let mut cursor = Vec::new();
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            let node = self.read_node(page_id)?;
            match node.kind {
                NodeKind::Leaf => return Ok((node, cursor)),
                NodeKind::Internal => {
                    let mut child = node.first_child;
                    let mut position = 0;
                    for entry in &node.internal {
                        if key <= &entry.key {
                            break;
                        }
                        child = entry.child;
                        position += 1;
                    }
                    cursor.push((node.id, position));
                    page_id = child;
                }
            }
        }
    }

    /// 0.2-K Part L: `find_leaf_with_cursor` through the zero-copy node view
    /// (internal nodes are never decoded; the same child rule: the position
    /// is the number of separators `< key`). Returns the leaf id.
    fn find_leaf_id_with_cursor(
        &mut self,
        key: &IndexKey,
    ) -> Result<(u64, Vec<(u64, usize)>), PhobosError> {
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        let mut cursor = Vec::new();
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            if page_id == 0 || page_id >= self.next_page {
                return Err(index_error("index page identifier is out of range"));
            }
            let (bytes, trusted) = read_page_ref(&mut self.file, page_id)?;
            let view = if trusted {
                node_view::NodeView::new_trusted(&bytes, page_id)?
            } else {
                node_view::NodeView::new(&bytes, page_id)?
            };
            match view.kind {
                NodeKind::Leaf => return Ok((page_id, cursor)),
                NodeKind::Internal => {
                    let position = view.lower_bound(key, false)?;
                    let child = view.child_at(position);
                    cursor.push((page_id, position));
                    page_id = child;
                }
            }
        }
    }

    /// 0.2-K: move a leaf cursor to the next leaf in tree order (ascend to the
    /// first ancestor with a right sibling child, then descend leftmost).
    /// Returns the new leaf id, or `None` past the last leaf. The cursor is
    /// left unchanged in that case.
    fn advance_leaf_cursor(
        &mut self,
        cursor: &mut Vec<(u64, usize)>,
    ) -> Result<Option<u64>, PhobosError> {
        let mut level = cursor.len();
        while level > 0 {
            let (parent_id, position) = cursor[level - 1];
            let parent = self.read_node(parent_id)?;
            if parent.kind != NodeKind::Internal {
                return Err(index_error("leaf cursor parent is not an internal node"));
            }
            if position < parent.internal.len() {
                let mut child = parent.internal[position].child;
                cursor.truncate(level - 1);
                cursor.push((parent_id, position + 1));
                let mut remaining = self.next_page;
                loop {
                    remaining = remaining
                        .checked_sub(1)
                        .ok_or_else(|| index_error("index descent exceeded page bound"))?;
                    let node = self.read_node(child)?;
                    match node.kind {
                        NodeKind::Leaf => return Ok(Some(node.id)),
                        NodeKind::Internal => {
                            cursor.push((node.id, 0));
                            child = node.first_child;
                        }
                    }
                }
            }
            level -= 1;
        }
        Ok(None)
    }

    /// Unlinks an empty, non-root leaf that has a left sibling under the same
    /// parent and frees its page. Returns false (nothing changed) when the
    /// leaf is its parent's first child.
    fn detach_empty_leaf(&mut self, leaf: &Node, path: &[u64]) -> Result<bool, PhobosError> {
        let Some(parent_id) = path.last().copied() else {
            return Ok(false);
        };
        let mut parent = self.read_node(parent_id)?;
        if parent.kind != NodeKind::Internal {
            return Err(index_error("leaf parent is not an internal node"));
        }
        let Some(entry) = parent
            .internal
            .iter()
            .position(|entry| entry.child == leaf.id)
        else {
            // First child (or not referenced): keep the empty leaf in place.
            return Ok(false);
        };
        let left_id = if entry == 0 {
            parent.first_child
        } else {
            parent.internal[entry - 1].child
        };
        let mut left = self.read_node(left_id)?;
        if left.kind != NodeKind::Leaf || left.next_leaf != leaf.id {
            return Err(index_error(
                "leaf sibling chain does not match parent order",
            ));
        }
        parent.internal.remove(entry);
        left.next_leaf = leaf.next_leaf;
        self.write_node(&left)?;
        self.write_node(&parent)?;
        self.free_page(leaf.id)?;
        Ok(true)
    }

    /// Writes `id` as a FREE page chained onto the free list and updates meta.
    fn free_page(&mut self, id: u64) -> Result<(), PhobosError> {
        let mut page = [0u8; INDEX_PAGE_SIZE];
        page[0..4].copy_from_slice(&NODE_MAGIC);
        page[4..6].copy_from_slice(&FORMAT_VERSION.to_le_bytes());
        page[6] = bulk::FREE_KIND;
        page[7] = phobos_wal::page_checksum::CRC32C;
        page[8..16].copy_from_slice(&id.to_le_bytes());
        page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
        page[24..32].copy_from_slice(&self.free_head.to_le_bytes());
        page[34..36].copy_from_slice(&(NODE_HEADER as u16).to_le_bytes());
        let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
        page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4]
            .copy_from_slice(&checksum.to_le_bytes());
        write_page(&mut self.file, id, &page)?;
        self.free_head = id;
        self.write_meta()
    }

    /// 0.2-K diagnostics: (pages including the meta page, free-list pages)
    /// of the committed tree for statement readers, of this tree otherwise.
    pub fn shape(&mut self) -> Result<(u64, usize), PhobosError> {
        if let Some(reader) = self.reader.clone() {
            return reader.shape();
        }
        Ok((self.next_page, self.free_list_len()?))
    }

    /// Pages currently on the C3 free list (bounded by the page count).
    pub fn free_list_len(&mut self) -> Result<usize, PhobosError> {
        let mut count = 0usize;
        let mut current = self.free_head;
        while current != 0 {
            if count as u64 >= self.next_page {
                return Err(index_error("index free list contains a cycle"));
            }
            let bytes = read_page(&mut self.file, current)?;
            if !bulk::is_free_page(&bytes, current) {
                return Err(index_error("index free list references a live page"));
            }
            count += 1;
            current = u64::from_le_bytes(bytes[24..32].try_into().expect("next free"));
        }
        Ok(count)
    }

    pub fn point_lookup(&mut self, key: &IndexKey) -> Result<Vec<RecordId>, PhobosError> {
        let _profile = phobos_observability::span("index.point_lookup");
        if let Some(reader) = self.reader.clone() {
            return reader.point_lookup(key);
        }
        self.range(Bound::Included(key), Bound::Included(key))
    }

    pub fn range(
        &mut self,
        lower: Bound<'_>,
        upper: Bound<'_>,
    ) -> Result<Vec<RecordId>, PhobosError> {
        let mut result = Vec::new();
        self.range_visit(lower, upper, |rid| {
            result.push(rid);
            Ok(true)
        })?;
        Ok(result)
    }

    /// Visits matching record IDs while retaining only the current leaf.
    /// Returning false stops before fetching another leaf; errors unwind immediately.
    pub fn range_visit<F>(
        &mut self,
        lower: Bound<'_>,
        upper: Bound<'_>,
        mut visitor: F,
    ) -> Result<(), PhobosError>
    where
        F: FnMut(RecordId) -> Result<bool, PhobosError>,
    {
        if let Some(reader) = self.reader.clone() {
            return reader.visit(lower, upper, visitor);
        }
        self.range_entry_visit(lower, upper, |entry| visitor(entry.rid))
    }

    /// 0.2-K: `range_visit` that also passes each entry's key, so the heap
    /// dereference can re-validate the RID's identity (a stale RID whose slot
    /// was reused names a tuple with another key).
    pub fn range_visit_keyed<F>(
        &mut self,
        lower: Bound<'_>,
        upper: Bound<'_>,
        mut visitor: F,
    ) -> Result<(), PhobosError>
    where
        F: FnMut(&IndexKey, RecordId) -> Result<bool, PhobosError>,
    {
        if let Some(reader) = self.reader.clone() {
            return reader.visit_entries(lower, upper, |entry| visitor(&entry.key, entry.rid));
        }
        self.range_entry_visit(lower, upper, |entry| visitor(&entry.key, entry.rid))
    }

    /// 0.2-K: `prefix_visit` that also passes each entry's key.
    pub fn prefix_visit_keyed<F>(
        &mut self,
        prefix: &IndexKey,
        mut visitor: F,
    ) -> Result<(), PhobosError>
    where
        F: FnMut(&IndexKey, RecordId) -> Result<bool, PhobosError>,
    {
        self.validate_prefix(prefix)?;
        if let Some(reader) = self.reader.clone() {
            return reader.visit_prefix_entries(prefix, |entry| visitor(&entry.key, entry.rid));
        }
        self.prefix_entry_visit_from(prefix, None, |entry| visitor(&entry.key, entry.rid))
    }

    /// Visits every full key whose leading columns equal `prefix` under the
    /// existing physical key comparison contract.
    pub fn prefix_visit<F>(&mut self, prefix: &IndexKey, mut visitor: F) -> Result<(), PhobosError>
    where
        F: FnMut(RecordId) -> Result<bool, PhobosError>,
    {
        self.validate_prefix(prefix)?;
        if let Some(reader) = self.reader.clone() {
            return reader.visit_prefix(prefix, visitor);
        }
        self.prefix_entry_visit_from(prefix, None, |entry| visitor(entry.rid))
    }

    /// Offline integrity traversal includes keys so dangling or mismatched heap
    /// references can be diagnosed. A live statement must use visibility scans.
    pub fn inspect_entries(
        &mut self,
        mut visitor: impl FnMut(&IndexKey, RecordId) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        if self.reader.is_some() {
            return Err(index_error("physical inspection requires an offline index"));
        }
        self.range_entry_visit(Bound::Unbounded, Bound::Unbounded, |entry| {
            visitor(&entry.key, entry.rid)
        })
    }

    /// Enumerate physical leaf entries with their page provenance. This is
    /// compiled only for the local db1 evidence investigation.
    #[cfg(feature = "db1-diagnostics")]
    pub fn diagnostic_entries(&mut self) -> Result<Vec<DiagnosticIndexEntry>, PhobosError> {
        let mut result = Vec::new();
        let mut id = self.leftmost_leaf()?;
        let mut remaining = self.next_page;
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("diagnostic leaf traversal exceeded page bound"))?;
            let (bytes, _) = self.read_view_page(id)?;
            let node = decode_node(&bytes, id)?;
            if node.kind != NodeKind::Leaf {
                return Err(index_error("diagnostic leaf chain reaches non-leaf"));
            }
            let page_lsn = u64::from_le_bytes(bytes[40..48].try_into().expect("page LSN"));
            for (position, entry) in node.leaf.iter().enumerate() {
                result.push(DiagnosticIndexEntry {
                    key: entry.key.clone(),
                    rid: entry.rid,
                    leaf_page: id,
                    page_lsn,
                    next_leaf: node.next_leaf,
                    position,
                });
            }
            if node.next_leaf == NONE_PAGE {
                break;
            }
            id = node.next_leaf;
        }
        Ok(result)
    }

    fn range_entry_visit(
        &mut self,
        lower: Bound<'_>,
        upper: Bound<'_>,
        mut visitor: impl FnMut(&LeafEntry) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        if let Bound::Included(key) | Bound::Excluded(key) = lower {
            self.validate_key(key)?;
        }
        if let Bound::Included(key) | Bound::Excluded(key) = upper {
            self.validate_key(key)?;
        }
        let key = match lower {
            Bound::Included(key) | Bound::Excluded(key) => Some(key),
            Bound::Unbounded => None,
        };
        let upper_encoded = match upper {
            Bound::Included(key) | Bound::Excluded(key) => Some(encode_key(key)?),
            Bound::Unbounded => None,
        };
        let (mut id, mut bytes, first) = self.find_leaf_view(key)?;
        let mut first = Some(first);
        let mut validated = true;
        let mut remaining = self.next_page;
        loop {
            phobos_error::cancellation::checkpoint_at("lib.range_entry_visit")?;
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index leaf traversal exceeded page bound"))?;
            let view = if let Some(layout) = first.take() {
                node_view::NodeView::with_layout(&bytes, id, &layout)?
            } else if validated {
                node_view::NodeView::new_trusted(&bytes, id)?
            } else {
                node_view::NodeView::new(&bytes, id)?
            };
            if view.kind != NodeKind::Leaf {
                return Err(index_error("leaf chain points to an internal node"));
            }
            let start = match lower {
                Bound::Included(key) => view.lower_bound(key, false)?,
                Bound::Excluded(key) => view.lower_bound(key, true)?,
                Bound::Unbounded => 0,
            };
            for i in start..view.count {
                phobos_error::cancellation::checkpoint_at("lib.range_entry_visit")?;
                // 0.2-F: current-format pages compare against the bound
                // encoded once (see `NodeView::compare_encoded`).
                let order = |key: &IndexKey| -> Result<Ordering, PhobosError> {
                    match (&upper_encoded, view.version() == FORMAT_VERSION) {
                        (Some(encoded), true) => Ok(view.compare_encoded(i, encoded)),
                        _ => view.compare(i, key),
                    }
                };
                let beyond = match upper {
                    Bound::Included(key) => order(key)? == Ordering::Greater,
                    Bound::Excluded(key) => order(key)? != Ordering::Less,
                    Bound::Unbounded => false,
                };
                if beyond {
                    return Ok(());
                }
                if !visitor(&view.entry(i)?)? {
                    return Ok(());
                }
            }
            id = view.next;
            if id == NONE_PAGE {
                break;
            }
            (bytes, validated) = self.read_view_page(id)?;
        }
        Ok(())
    }

    fn prefix_entry_visit_from(
        &mut self,
        prefix: &IndexKey,
        after: Option<&IndexKey>,
        mut visitor: impl FnMut(&LeafEntry) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        self.validate_prefix(prefix)?;
        if let Some(after) = after {
            self.validate_key(after)?;
        }
        let lower = after.unwrap_or(prefix);
        let (mut id, mut bytes, first) = self.find_leaf_view(Some(lower))?;
        let mut first = Some(first);
        let mut validated = true;
        let mut remaining = self.next_page;
        loop {
            phobos_error::cancellation::checkpoint_at("lib.prefix_entry_visit")?;
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index leaf traversal exceeded page bound"))?;
            let view = if let Some(layout) = first.take() {
                node_view::NodeView::with_layout(&bytes, id, &layout)?
            } else if validated {
                node_view::NodeView::new_trusted(&bytes, id)?
            } else {
                node_view::NodeView::new(&bytes, id)?
            };
            if view.kind != NodeKind::Leaf {
                return Err(index_error("leaf chain points to an internal node"));
            }
            let start = view.lower_bound(lower, false)?;
            for i in start..view.count {
                phobos_error::cancellation::checkpoint_at("lib.prefix_entry_visit")?;
                let entry = view.entry(i)?;
                if !key_has_prefix(&entry.key, prefix) {
                    return Ok(());
                }
                if !visitor(&entry)? {
                    return Ok(());
                }
            }
            id = view.next;
            if id == NONE_PAGE {
                break;
            }
            (bytes, validated) = self.read_view_page(id)?;
        }
        Ok(())
    }

    /// The image of page `id` as this handle sees it, and whether it is a
    /// committed-store image that was fully validated on entry (0.2-F: then
    /// shared, never copied, and a trusted view needs no re-validation).
    fn read_view_page(&mut self, id: u64) -> Result<(PageRef, bool), PhobosError> {
        if id == 0 || id >= self.next_page {
            return Err(index_error("index page identifier is out of range"));
        }
        // A mutation batch may contain unpublished nodes. Preserve its view.
        if let Some(node) = self.batch.as_ref().and_then(|batch| batch.nodes.get(&id)) {
            return Ok((std::sync::Arc::new(encode_node(&node.0)?), false));
        }
        read_page_ref(&mut self.file, id)
    }

    /// Descend to the leaf for `key`; returns the leaf image and the layout
    /// (entry offsets) of its validated view, so the caller can rebuild that
    /// view without walking the entries again.
    fn find_leaf_view(
        &mut self,
        key: Option<&IndexKey>,
    ) -> Result<(u64, PageRef, node_view::Layout), PhobosError> {
        let mut id = self.root_page;
        let mut remaining = self.next_page;
        loop {
            phobos_error::cancellation::check_now()?;
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            let cached = match &self.navigation {
                Some(navigation) => match navigation.internal(id)? {
                    Some(hit) => Some(hit),
                    None => navigation.leaf(id)?,
                },
                None => None,
            };
            let (bytes, layout) = match cached {
                Some((bytes, layout)) => {
                    phobos_observability::event("point_upper_cache_hits", 1);
                    (bytes, Some(layout))
                }
                None => {
                    if self.navigation.is_some() {
                        phobos_observability::event("point_upper_cache_misses", 1);
                    }
                    let (bytes, trusted) = self.read_view_page(id)?;
                    let layout = {
                        let view = if trusted {
                            node_view::NodeView::new_trusted(&bytes, id)?
                        } else {
                            node_view::NodeView::new(&bytes, id)?
                        };
                        view.layout()
                    };
                    let leaf = bytes[6] == 1;
                    if let Some(navigation) = &self.navigation {
                        if leaf {
                            navigation.remember_leaf(id, &bytes, &layout)?;
                        } else {
                            navigation.remember_internal(
                                id,
                                std::sync::Arc::clone(&bytes),
                                std::sync::Arc::clone(&layout),
                            )?;
                        }
                    }
                    (bytes, Some(layout))
                }
            };
            let layout = layout.expect("layout");
            let view = node_view::NodeView::with_layout(&bytes, id, &layout)?;
            if view.kind == NodeKind::Leaf {
                return Ok((id, bytes, layout));
            }
            id = view.child(key)?;
        }
    }

    pub fn validate(&mut self) -> Result<IndexValidation, PhobosError> {
        let mut visited = HashSet::new();
        let mut leaves = Vec::new();
        let mut entries = 0usize;
        let root = self.read_node(self.root_page)?;
        if root.parent != NONE_PAGE {
            return Err(index_error("root node has a parent"));
        }
        self.validate_subtree(
            self.root_page,
            NONE_PAGE,
            &mut visited,
            &mut leaves,
            &mut entries,
        )?;
        let mut free_pages = 0usize;
        if visited.len() as u64 != self.next_page - 1 {
            // C9 bulk merges retire pages they no longer need. Every page that
            // the tree does not reach must be an explicitly marked free page.
            for page_id in 1..self.next_page {
                if visited.contains(&page_id) {
                    continue;
                }
                let bytes = read_page(&mut self.file, page_id)?;
                if !bulk::is_free_page(&bytes, page_id) {
                    return Err(index_error("index contains unreachable pages"));
                }
                free_pages += 1;
            }
        }
        // C3: the free list must be a valid chain of free pages, never a
        // reachable one.
        let listed = self.free_list_len()?;
        if listed > free_pages {
            return Err(index_error("index free list references a live page"));
        }
        let mut linked = Vec::new();
        let mut current = self.leftmost_leaf()?;
        let mut seen_chain = HashSet::new();
        loop {
            if !seen_chain.insert(current) {
                return Err(index_error("leaf sibling chain contains a cycle"));
            }
            linked.push(current);
            let leaf = self.read_node(current)?;
            if leaf.next_leaf == NONE_PAGE {
                break;
            }
            current = leaf.next_leaf;
        }
        if linked != leaves {
            return Err(index_error("leaf sibling chain does not match tree order"));
        }
        Ok(IndexValidation {
            pages: visited.len() + free_pages,
            leaves: leaves.len(),
            entries,
            height: self.height()?,
            free_pages,
        })
    }

    pub fn sync(&mut self) -> Result<(), PhobosError> {
        if self.file.is_private() {
            return self.file.sync_data();
        }
        let _profile = phobos_observability::span("index.fsync");
        self.file.sync_data()?;
        Ok(())
    }

    fn validate_key(&self, key: &IndexKey) -> Result<(), PhobosError> {
        key.validate_columns(usize::from(self.key_columns))
    }

    fn validate_prefix(&self, prefix: &IndexKey) -> Result<(), PhobosError> {
        if prefix.0.is_empty() || prefix.0.len() >= usize::from(self.key_columns) {
            return Err(index_error("index prefix column count mismatch"));
        }
        if encode_key(prefix)?.len() > MAX_KEY_BYTES {
            return Err(index_error("index prefix exceeds maximum encoded size"));
        }
        Ok(())
    }

    fn split_leaf(&mut self, mut left: Node, path: Vec<u64>) -> Result<(), PhobosError> {
        #[cfg(feature = "db1-diagnostics")]
        {
            db1_diagnostics::SPLITS.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            self.check_split_successor(&left, &path)?;
        }
        if left.leaf.len() < 2 {
            return Err(index_error("single index entry is too large for a page"));
        }
        let split = left.leaf.len() / 2;
        let right_entries = left.leaf.split_off(split);
        let separator = right_entries
            .first()
            .ok_or_else(|| index_error("empty right leaf after split"))?
            .key
            .clone();
        let right_id = self.allocate_page()?;
        let mut right = Node::new_leaf(right_id, NONE_PAGE);
        right.leaf = right_entries;
        right.next_leaf = left.next_leaf;
        left.next_leaf = right_id;
        if left.encoded_len()? > INDEX_PAGE_SIZE || right.encoded_len()? > INDEX_PAGE_SIZE {
            return Err(index_error(
                "index leaf split could not fit entries into pages",
            ));
        }
        self.write_node(&left)?;
        self.write_node(&right)?;
        self.insert_into_parent(left.id, separator, right.id, path)
    }

    #[cfg(feature = "db1-diagnostics")]
    fn check_split_successor(&mut self, left: &Node, path: &[u64]) -> Result<(), PhobosError> {
        db1_diagnostics::CHECKS.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let direct_parent = path.last().copied().unwrap_or(NONE_PAGE);
        let mut child = left.id;
        let mut implied = NONE_PAGE;
        for parent_id in path.iter().rev().copied() {
            let parent = self.read_node_for_diagnostics(parent_id)?;
            let children = std::iter::once(parent.first_child)
                .chain(parent.internal.iter().map(|entry| entry.child))
                .collect::<Vec<_>>();
            let position = children
                .iter()
                .position(|candidate| *candidate == child)
                .ok_or_else(|| index_error("split child is absent from diagnostic parent path"))?;
            if let Some(next) = children.get(position + 1).copied() {
                let mut page = next;
                loop {
                    let node = self.read_node_for_diagnostics(page)?;
                    if node.kind == NodeKind::Leaf {
                        implied = page;
                        break;
                    }
                    page = node.first_child;
                }
                break;
            }
            child = parent_id;
        }
        let left_source = self.page_provenance_for_diagnostics(left.id)?;
        let parent_source = if direct_parent == NONE_PAGE {
            None
        } else {
            Some(self.page_provenance_for_diagnostics(direct_parent)?)
        };
        db1_diagnostics::MAX_PENDING.fetch_max(
            left_source.pending_generations.len() as u64,
            std::sync::atomic::Ordering::Relaxed,
        );
        if left.next_leaf != implied {
            db1_diagnostics::FAILURES.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            phobos_observability::event("index.split_successor_consistency_failure", 1);
            let detail = format!(
                "index.split_successor_consistency left={} left_lsn={} left_source={} left_owner={:?} stored_next={} parent={} parent_lsn={} parent_source={} parent_owner={:?} implied_next={} pending={:?}",
                left.id,
                left_source.page_lsn,
                left_source.source,
                left_source.owner,
                left.next_leaf,
                direct_parent,
                parent_source.as_ref().map_or(0, |source| source.page_lsn),
                parent_source
                    .as_ref()
                    .map_or("none", |source| source.source),
                parent_source.as_ref().and_then(|source| source.owner),
                implied,
                left_source.pending_generations,
            );
            if let Some(database) = self.path.parent() {
                let evidence = database.join(format!(".db1-trip-evidence-{}", std::process::id()));
                let _ = phobos_wal::v2::preserve_wal_for_test(database, &evidence.join("wal"));
                let _ = std::fs::write(evidence.join("tripwire.txt"), &detail);
            }
            return Err(index_error(detail));
        }
        phobos_observability::event("index.split_successor_consistency", 1);
        Ok(())
    }

    /// The tripwire is observational. In a bounded batch, diagnostic traversal
    /// must not admit clean nodes into or flush the mutation cache.
    #[cfg(feature = "db1-diagnostics")]
    fn read_node_for_diagnostics(&mut self, page_id: u64) -> Result<Node, PhobosError> {
        if page_id == 0 || page_id >= self.next_page {
            return Err(index_error("diagnostic index page is out of range"));
        }
        if let Some(node) = self
            .batch
            .as_ref()
            .and_then(|batch| batch.nodes.get(&page_id))
        {
            return Ok(node.0.clone());
        }
        let length = self.file.len()?;
        let bytes = read_page(&mut self.file, page_id).map_err(|error| {
            index_error(format!(
                "diagnostic page read failed page={page_id} next_page={} length={length}: {error}",
                self.next_page
            ))
        })?;
        decode_node(&bytes, page_id)
    }

    #[cfg(feature = "db1-diagnostics")]
    fn page_provenance_for_diagnostics(
        &mut self,
        page_id: u64,
    ) -> Result<phobos_storage::page_io::PageProvenance, PhobosError> {
        if self
            .batch
            .as_ref()
            .is_some_and(|batch| batch.nodes.contains_key(&page_id))
        {
            return Ok(phobos_storage::page_io::PageProvenance {
                source: "index-batch-cache",
                owner: self.file.private_owner().ok(),
                pending_generations: Vec::new(),
                // Batch pages receive their durable LSN during redo preparation.
                page_lsn: 0,
            });
        }
        self.file.page_provenance(page_id)
    }

    fn insert_into_parent(
        &mut self,
        left_id: u64,
        separator: IndexKey,
        right_id: u64,
        mut path: Vec<u64>,
    ) -> Result<(), PhobosError> {
        let Some(parent_id) = path.pop() else {
            let root_id = self.allocate_page()?;
            let mut root = Node::new_internal(root_id, NONE_PAGE, left_id);
            root.internal.push(InternalEntry {
                key: separator,
                child: right_id,
            });
            self.write_node(&root)?;
            self.root_page = root_id;
            self.write_meta()?;
            return Ok(());
        };
        let mut parent = self.read_node(parent_id)?;
        if parent.kind != NodeKind::Internal {
            return Err(index_error("child parent is not an internal node"));
        }
        let child_index = internal_child_position(&parent, left_id)
            .ok_or_else(|| index_error("parent does not reference split child"))?;
        parent.internal.insert(
            child_index,
            InternalEntry {
                key: separator,
                child: right_id,
            },
        );
        if parent.encoded_len()? <= INDEX_PAGE_SIZE {
            self.write_node(&parent)?;
            return Ok(());
        }
        self.split_internal(parent, path)
    }

    fn split_internal(&mut self, mut left: Node, path: Vec<u64>) -> Result<(), PhobosError> {
        if left.internal.len() < 3 {
            return Err(index_error("internal index node cannot be split safely"));
        }
        let median = left.internal.len() / 2;
        let promoted = left.internal[median].key.clone();
        let right_first_child = left.internal[median].child;
        let right_entries = left.internal.split_off(median + 1);
        left.internal.truncate(median);
        let right_id = self.allocate_page()?;
        let mut right = Node::new_internal(right_id, NONE_PAGE, right_first_child);
        right.internal = right_entries;
        if left.encoded_len()? > INDEX_PAGE_SIZE || right.encoded_len()? > INDEX_PAGE_SIZE {
            return Err(index_error(
                "internal index split could not fit entries into pages",
            ));
        }
        self.write_node(&left)?;
        self.write_node(&right)?;
        self.insert_into_parent(left.id, promoted, right.id, path)
    }

    fn find_leaf(&mut self, key: &IndexKey) -> Result<u64, PhobosError> {
        Ok(self.find_leaf_node(key)?.id)
    }

    fn find_leaf_node(&mut self, key: &IndexKey) -> Result<Node, PhobosError> {
        self.find_leaf_node_with_path(key).map(|(node, _)| node)
    }

    fn find_leaf_node_with_path(
        &mut self,
        key: &IndexKey,
    ) -> Result<(Node, Vec<u64>), PhobosError> {
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        let mut path = Vec::new();
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            let node = self.read_node(page_id)?;
            match node.kind {
                NodeKind::Leaf => return Ok((node, path)),
                NodeKind::Internal => {
                    let mut child = node.first_child;
                    for entry in &node.internal {
                        if key <= &entry.key {
                            break;
                        }
                        child = entry.child;
                    }
                    path.push(node.id);
                    page_id = child;
                }
            }
        }
    }

    /// Locate a page through child links only. This is used only when a
    /// duplicate-key delete followed the leaf chain beyond its original
    /// descent path and then emptied that later leaf.
    fn find_path_to_page(&mut self, target: u64) -> Result<Option<Vec<u64>>, PhobosError> {
        let mut stack = vec![(self.root_page, Vec::new())];
        let mut remaining = self.next_page;
        while let Some((page_id, path)) = stack.pop() {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index path search exceeded page bound"))?;
            let node = self.read_node(page_id)?;
            if node.id == target {
                return Ok(Some(path));
            }
            if node.kind == NodeKind::Internal {
                let mut child_path = path;
                child_path.push(node.id);
                for child in node
                    .internal
                    .iter()
                    .rev()
                    .map(|entry| entry.child)
                    .chain(std::iter::once(node.first_child))
                {
                    stack.push((child, child_path.clone()));
                }
            }
        }
        Ok(None)
    }

    fn leftmost_leaf(&mut self) -> Result<u64, PhobosError> {
        Ok(self.leftmost_leaf_node()?.id)
    }

    fn leftmost_leaf_node(&mut self) -> Result<Node, PhobosError> {
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            let node = self.read_node(page_id)?;
            if node.kind == NodeKind::Leaf {
                return Ok(node);
            }
            if node.first_child == NONE_PAGE {
                return Err(index_error("internal index node has no first child"));
            }
            page_id = node.first_child;
        }
    }

    fn allocate_page(&mut self) -> Result<u64, PhobosError> {
        // C3: reuse a freed page before growing the file.
        if self.free_head != 0 {
            let page = self.free_head;
            let bytes = read_page(&mut self.file, page)?;
            if !bulk::is_free_page(&bytes, page) {
                return Err(index_error("index free list references a live page"));
            }
            self.free_head = u64::from_le_bytes(bytes[24..32].try_into().expect("next free"));
            if self.free_head >= self.next_page {
                return Err(index_error("index free-list link is out of range"));
            }
            phobos_observability::event("index.free_page_reused", 1);
            self.write_meta()?;
            return Ok(page);
        }
        let page = self.next_page;
        self.next_page = self
            .next_page
            .checked_add(1)
            .ok_or_else(|| index_error("index page identifier exhausted"))?;
        self.write_meta()?;
        Ok(page)
    }

    fn read_node(&mut self, page_id: u64) -> Result<Node, PhobosError> {
        let _profile = phobos_observability::span("index.read_node");
        if page_id == 0 || page_id >= self.next_page {
            return Err(index_error("index page identifier is out of range"));
        }
        if let Some(node) = self
            .batch
            .as_ref()
            .and_then(|batch| batch.nodes.get(&page_id))
        {
            return Ok(node.0.clone());
        }
        let bytes = read_page(&mut self.file, page_id)?;
        let node = decode_node(&bytes, page_id)?;
        if self.batch.is_some() {
            self.cache_node(node.clone(), false)?;
        }
        Ok(node)
    }

    fn write_node(&mut self, node: &Node) -> Result<(), PhobosError> {
        let _profile = phobos_observability::span("index.write_node");
        if self.batch.is_some() {
            return self.cache_node(node.clone(), true);
        }
        let bytes = encode_node(node)?;
        write_page(&mut self.file, node.id, &bytes)
    }

    fn write_meta(&mut self) -> Result<(), PhobosError> {
        if let Some(batch) = &mut self.batch {
            batch.meta_dirty = true;
            return Ok(());
        }
        if self.file.is_private() {
            self.meta_dirty = true;
            return Ok(());
        }
        self.write_meta_now()
    }

    fn flush_deferred_meta(&mut self) -> Result<(), PhobosError> {
        if self.meta_dirty {
            self.write_meta_now()?;
            self.meta_dirty = false;
        }
        Ok(())
    }

    fn write_meta_now(&mut self) -> Result<(), PhobosError> {
        let mut page = [0u8; INDEX_PAGE_SIZE];
        page[0..4].copy_from_slice(&META_MAGIC);
        page[4..6].copy_from_slice(&FORMAT_VERSION.to_le_bytes());
        page[7] = phobos_wal::page_checksum::CRC32C;
        page[6] = u8::from(self.unique);
        page[8..10].copy_from_slice(&self.key_columns.to_le_bytes());
        page[12..20].copy_from_slice(&self.root_page.to_le_bytes());
        page[20..28].copy_from_slice(&self.next_page.to_le_bytes());
        page[META_FREE_HEAD].copy_from_slice(&self.free_head.to_le_bytes());
        let checksum = checksum_page(&page, META_CHECKSUM_OFFSET);
        page[META_CHECKSUM_OFFSET..META_CHECKSUM_OFFSET + 4]
            .copy_from_slice(&checksum.to_le_bytes());
        write_page(&mut self.file, 0, &page)?;
        self.write_counters.meta_page_writes += 1;
        phobos_observability::event("index.meta_page_writes", 1);
        Ok(())
    }

    pub fn take_write_counters(&mut self) -> IndexWriteCounters {
        std::mem::take(&mut self.write_counters)
    }

    fn validate_subtree(
        &mut self,
        page_id: u64,
        _parent: u64,
        visited: &mut HashSet<u64>,
        leaves: &mut Vec<u64>,
        entries: &mut usize,
    ) -> Result<(Option<IndexKey>, Option<IndexKey>), PhobosError> {
        if !visited.insert(page_id) {
            return Err(index_error("index tree contains a page cycle"));
        }
        let node = self.read_node(page_id)?;
        match node.kind {
            NodeKind::Leaf => {
                for window in node.leaf.windows(2) {
                    if compare_entry(&window[0], &window[1].key, window[1].rid) == Ordering::Greater
                    {
                        return Err(index_error("leaf entries are out of order"));
                    }
                }
                *entries += node.leaf.len();
                leaves.push(page_id);
                Ok((
                    node.leaf.first().map(|entry| entry.key.clone()),
                    node.leaf.last().map(|entry| entry.key.clone()),
                ))
            }
            NodeKind::Internal => {
                if node.first_child == NONE_PAGE {
                    return Err(index_error("internal node is missing its first child"));
                }
                for window in node.internal.windows(2) {
                    // Equal separators are valid when duplicate keys span leaves.
                    if window[0].key > window[1].key {
                        return Err(index_error("internal separators are out of order"));
                    }
                }
                let mut children = Vec::with_capacity(node.internal.len() + 1);
                children.push(node.first_child);
                children.extend(node.internal.iter().map(|entry| entry.child));
                let mut min: Option<IndexKey> = None;
                let mut max: Option<IndexKey> = None;
                for (index, child) in children.iter().enumerate() {
                    let (child_min, child_max) =
                        self.validate_subtree(*child, page_id, visited, leaves, entries)?;
                    if index == 0 {
                        min = child_min.clone();
                    }
                    if let Some(separator) = index.checked_sub(1).and_then(|i| node.internal.get(i))
                    {
                        if let Some(ref child_minimum) = child_min {
                            if child_minimum < &separator.key {
                                return Err(index_error("child minimum violates parent separator"));
                            }
                        }
                    }
                    max = child_max.or(max);
                }
                Ok((min, max))
            }
        }
    }

    fn height(&mut self) -> Result<usize, PhobosError> {
        let mut height = 1usize;
        let mut page_id = self.root_page;
        loop {
            let node = self.read_node(page_id)?;
            if node.kind == NodeKind::Leaf {
                return Ok(height);
            }
            height += 1;
            page_id = node.first_child;
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct IndexValidation {
    pub pages: usize,
    pub leaves: usize,
    pub entries: usize,
    pub height: usize,
    /// Retired pages left by C9 bulk merges; unreachable by design.
    pub free_pages: usize,
}

fn internal_child_position(node: &Node, child: u64) -> Option<usize> {
    if node.first_child == child {
        return Some(0);
    }
    node.internal
        .iter()
        .position(|entry| entry.child == child)
        .map(|position| position + 1)
}

fn compare_entry(entry: &LeafEntry, key: &IndexKey, rid: RecordId) -> Ordering {
    entry.key.cmp(key).then_with(|| entry.rid.cmp(&rid))
}

fn lower_allows(bound: &Bound<'_>, key: &IndexKey) -> bool {
    match bound {
        Bound::Unbounded => true,
        Bound::Included(value) => key >= *value,
        Bound::Excluded(value) => key > *value,
    }
}

fn compare_key(left: &IndexKey, right: &IndexKey) -> Ordering {
    for (a, b) in left.0.iter().zip(&right.0) {
        let ordering = compare_value(a, b);
        if ordering != Ordering::Equal {
            return ordering;
        }
    }
    left.0.len().cmp(&right.0.len())
}

fn key_has_prefix(key: &IndexKey, prefix: &IndexKey) -> bool {
    key.0.len() > prefix.0.len()
        && key
            .0
            .iter()
            .zip(&prefix.0)
            .all(|(value, expected)| compare_value(value, expected) == Ordering::Equal)
}

fn compare_value(left: &Value, right: &Value) -> Ordering {
    match (left, right) {
        (Value::Null, Value::Null) => Ordering::Equal,
        (Value::Null, _) => Ordering::Greater,
        (_, Value::Null) => Ordering::Less,
        (
            Value::Decimal {
                unscaled: a,
                scale: sa,
            },
            Value::Decimal {
                unscaled: b,
                scale: sb,
            },
        ) => sa.cmp(sb).then_with(|| a.cmp(b)),
        (Value::Int64(_), Value::Int64(_))
        | (Value::Float64(_), Value::Float64(_))
        | (Value::Boolean(_), Value::Boolean(_))
        | (Value::Text(_), Value::Text(_))
        | (Value::Binary(_), Value::Binary(_))
        | (Value::Date(_), Value::Date(_))
        | (Value::Timestamp(_), Value::Timestamp(_)) => left.canonical_cmp(right).unwrap(),
        _ => value_tag(left).cmp(&value_tag(right)),
    }
}

fn value_tag(value: &Value) -> u8 {
    match value {
        Value::Null => 0,
        Value::Boolean(_) => 1,
        Value::Int64(_) => 2,
        Value::Float64(_) => 3,
        Value::Text(_) => 4,
        Value::Binary(_) => 5,
        Value::Date(_) => 6,
        Value::Timestamp(_) => 7,
        Value::Decimal { .. } => 8,
    }
}

/// V3 order-preserving encoding. Bytewise comparison matches `IndexKey`
/// ordering for values coerced to their declared indexed column types.
fn encode_key(key: &IndexKey) -> Result<Vec<u8>, PhobosError> {
    let mut out = Vec::new();
    encode_key_into(key, &mut out)?;
    Ok(out)
}

/// 0.2-F: `encode_key` appending to a reusable buffer (no allocation per key
/// when encoding a whole node).
fn encode_key_into(key: &IndexKey, out: &mut Vec<u8>) -> Result<(), PhobosError> {
    for value in &key.0 {
        match value {
            Value::Boolean(value) => out.extend_from_slice(&[1, u8::from(*value)]),
            Value::Int64(value) => {
                out.push(2);
                out.extend_from_slice(&((*value as u64) ^ (1 << 63)).to_be_bytes());
            }
            Value::Float64(value) => {
                out.push(3);
                let bits = if value.is_nan() {
                    u64::MAX
                } else {
                    let bits = if *value == 0.0 { 0 } else { value.to_bits() };
                    if bits >> 63 == 1 {
                        !bits
                    } else {
                        bits ^ (1 << 63)
                    }
                };
                out.extend_from_slice(&bits.to_be_bytes());
            }
            Value::Text(value) => {
                out.push(4);
                put_mem_bytes(out, value.as_bytes());
            }
            Value::Binary(value) => {
                out.push(5);
                put_mem_bytes(out, value);
            }
            Value::Date(value) => {
                out.push(6);
                out.extend_from_slice(&((*value as u32) ^ (1 << 31)).to_be_bytes());
            }
            Value::Timestamp(value) => {
                out.push(7);
                out.extend_from_slice(&((*value as u64) ^ (1 << 63)).to_be_bytes());
            }
            Value::Decimal { unscaled, scale } => {
                out.extend_from_slice(&[8, *scale]);
                out.extend_from_slice(&((*unscaled as u128) ^ (1 << 127)).to_be_bytes());
            }
            Value::Null => out.push(0xff),
        }
    }
    Ok(())
}

/// 0.2-B: `encode_key(key).len()` without building the encoding (node size
/// checks ran a full allocation per key per insert).
fn encoded_key_len(key: &IndexKey) -> usize {
    key.0
        .iter()
        .map(|value| match value {
            Value::Boolean(_) => 2,
            Value::Int64(_) | Value::Float64(_) | Value::Timestamp(_) => 9,
            Value::Text(value) => 1 + mem_bytes_len(value.as_bytes()),
            Value::Binary(value) => 1 + mem_bytes_len(value),
            Value::Date(_) => 5,
            Value::Decimal { .. } => 18,
            Value::Null => 1,
        })
        .sum()
}

fn mem_bytes_len(bytes: &[u8]) -> usize {
    bytes.len() + bytes.iter().filter(|byte| **byte == 0).count() + 2
}

fn put_mem_bytes(out: &mut Vec<u8>, bytes: &[u8]) {
    for byte in bytes {
        if *byte == 0 {
            out.extend_from_slice(&[0, 0xff]);
        } else {
            out.push(*byte);
        }
    }
    out.extend_from_slice(&[0, 0]);
}

/// 0.2-C: exactly `decode_key`'s acceptance rules (tags, boolean domain,
/// fixed widths, memcomparable escapes, UTF-8 text) without allocating.
fn validate_key_v3(bytes: &[u8]) -> Result<(), PhobosError> {
    let mut cursor = 0usize;
    while cursor < bytes.len() {
        match take_u8(bytes, &mut cursor)? {
            1 => match take_u8(bytes, &mut cursor)? {
                0 | 1 => {}
                _ => return Err(index_error("invalid boolean index key")),
            },
            2 | 3 | 7 => {
                take_array::<8>(bytes, &mut cursor)?;
            }
            4 | 5 => {
                let text = bytes[cursor - 1] == 4;
                let mut segment = cursor;
                loop {
                    let byte = take_u8(bytes, &mut cursor)?;
                    if byte != 0 {
                        continue;
                    }
                    // A NUL never occurs inside a multi-byte UTF-8 sequence,
                    // so validating each escape-delimited run is equivalent.
                    if text && std::str::from_utf8(&bytes[segment..cursor - 1]).is_err() {
                        return Err(index_error("index text key is not UTF-8"));
                    }
                    match take_u8(bytes, &mut cursor)? {
                        0 => break,
                        0xff => segment = cursor,
                        _ => return Err(index_error("invalid memcomparable byte escape")),
                    }
                }
            }
            6 => {
                take_array::<4>(bytes, &mut cursor)?;
            }
            8 => {
                take_u8(bytes, &mut cursor)?;
                take_array::<16>(bytes, &mut cursor)?;
            }
            0xff => {}
            _ => return Err(index_error("unknown memcomparable index key tag")),
        }
    }
    Ok(())
}

fn take_mem_bytes(bytes: &[u8], cursor: &mut usize) -> Result<Vec<u8>, PhobosError> {
    let mut out = Vec::new();
    loop {
        let byte = take_u8(bytes, cursor)?;
        if byte != 0 {
            out.push(byte);
            continue;
        }
        match take_u8(bytes, cursor)? {
            0 => return Ok(out),
            0xff => out.push(0),
            _ => return Err(index_error("invalid memcomparable byte escape")),
        }
    }
}

fn decode_key(bytes: &[u8]) -> Result<IndexKey, PhobosError> {
    let mut cursor = 0usize;
    let mut values = Vec::new();
    while cursor < bytes.len() {
        let tag = take_u8(bytes, &mut cursor)?;
        let value = match tag {
            1 => Value::Boolean(match take_u8(bytes, &mut cursor)? {
                0 => false,
                1 => true,
                _ => return Err(index_error("invalid boolean index key")),
            }),
            2 => Value::Int64(
                (u64::from_be_bytes(take_array::<8>(bytes, &mut cursor)?) ^ (1 << 63)) as i64,
            ),
            3 => {
                let ordered = u64::from_be_bytes(take_array::<8>(bytes, &mut cursor)?);
                if ordered == u64::MAX {
                    Value::Float64(f64::NAN)
                } else {
                    let bits = if ordered >> 63 == 1 {
                        ordered ^ (1 << 63)
                    } else {
                        !ordered
                    };
                    Value::Float64(f64::from_bits(bits))
                }
            }
            4 => Value::Text(
                String::from_utf8(take_mem_bytes(bytes, &mut cursor)?)
                    .map_err(|_| index_error("index text key is not UTF-8"))?,
            ),
            5 => Value::Binary(take_mem_bytes(bytes, &mut cursor)?),
            6 => Value::Date(
                (u32::from_be_bytes(take_array::<4>(bytes, &mut cursor)?) ^ (1 << 31)) as i32,
            ),
            7 => Value::Timestamp(
                (u64::from_be_bytes(take_array::<8>(bytes, &mut cursor)?) ^ (1 << 63)) as i64,
            ),
            8 => {
                let scale = take_u8(bytes, &mut cursor)?;
                let unscaled = (u128::from_be_bytes(take_array::<16>(bytes, &mut cursor)?)
                    ^ (1 << 127)) as i128;
                Value::Decimal { unscaled, scale }
            }
            0xff => Value::Null,
            _ => return Err(index_error("unknown memcomparable index key tag")),
        };
        values.push(value);
    }
    Ok(IndexKey(values))
}

fn decode_key_legacy(bytes: &[u8]) -> Result<IndexKey, PhobosError> {
    let mut cursor = 0usize;
    let count = usize::from(take_u16(bytes, &mut cursor)?);
    let mut values = Vec::with_capacity(count);
    for _ in 0..count {
        let tag = take_u8(bytes, &mut cursor)?;
        let value = match tag {
            0 => Value::Null,
            1 => Value::Boolean(take_u8(bytes, &mut cursor)? != 0),
            2 => Value::Int64(i64::from_le_bytes(take_array::<8>(bytes, &mut cursor)?)),
            3 => Value::Float64(f64::from_bits(u64::from_le_bytes(take_array::<8>(
                bytes,
                &mut cursor,
            )?))),
            4 => Value::Text(
                String::from_utf8(take_sized(bytes, &mut cursor)?.to_vec())
                    .map_err(|_| index_error("index text key is not UTF-8"))?,
            ),
            5 => Value::Binary(take_sized(bytes, &mut cursor)?.to_vec()),
            6 => Value::Date(i32::from_le_bytes(take_array::<4>(bytes, &mut cursor)?)),
            7 => Value::Timestamp(i64::from_le_bytes(take_array::<8>(bytes, &mut cursor)?)),
            8 => Value::Decimal {
                unscaled: i128::from_le_bytes(take_array::<16>(bytes, &mut cursor)?),
                scale: take_u8(bytes, &mut cursor)?,
            },
            _ => return Err(index_error("unknown index key value tag")),
        };
        values.push(value);
    }
    if cursor != bytes.len() {
        return Err(index_error("index key contains trailing bytes"));
    }
    Ok(IndexKey(values))
}

fn decode_key_version(bytes: &[u8], version: u16) -> Result<IndexKey, PhobosError> {
    if version == FORMAT_VERSION {
        decode_key(bytes)
    } else if LEGACY_FORMAT_VERSIONS.contains(&version) {
        decode_key_legacy(bytes)
    } else {
        Err(index_error("unsupported index key version"))
    }
}

fn take_sized<'a>(bytes: &'a [u8], cursor: &mut usize) -> Result<&'a [u8], PhobosError> {
    let len = u32::from_le_bytes(take_array::<4>(bytes, cursor)?) as usize;
    take(bytes, cursor, len)
}

fn encode_node(node: &Node) -> Result<[u8; INDEX_PAGE_SIZE], PhobosError> {
    let _measurement = phobos_observability::span("index.encode_node");
    let mut page = [0u8; INDEX_PAGE_SIZE];
    page[0..4].copy_from_slice(&NODE_MAGIC);
    page[4..6].copy_from_slice(&FORMAT_VERSION.to_le_bytes());
    page[7] = phobos_wal::page_checksum::CRC32C;
    page[6] = match node.kind {
        NodeKind::Leaf => 1,
        NodeKind::Internal => 2,
    };
    page[8..16].copy_from_slice(&node.id.to_le_bytes());
    // D6 reserves the legacy parent field. Old values remain readable, while
    // mutation uses its descent path and every rewritten node stores zero.
    page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
    page[24..32].copy_from_slice(&node.next_leaf.to_le_bytes());
    let count = match node.kind {
        NodeKind::Leaf => node.leaf.len(),
        NodeKind::Internal => node.internal.len(),
    };
    let count = u16::try_from(count).map_err(|_| index_error("too many index node entries"))?;
    page[32..34].copy_from_slice(&count.to_le_bytes());
    let mut cursor = NODE_HEADER;
    if node.kind == NodeKind::Internal {
        page[cursor..cursor + 8].copy_from_slice(&node.first_child.to_le_bytes());
        cursor += 8;
    }
    let mut scratch = Vec::with_capacity(64);
    match node.kind {
        NodeKind::Leaf => {
            for entry in &node.leaf {
                scratch.clear();
                encode_key_into(&entry.key, &mut scratch)?;
                let key = &scratch;
                let key_len =
                    u16::try_from(key.len()).map_err(|_| index_error("index key too large"))?;
                let needed = 2 + key.len() + 8 + 2;
                if cursor + needed > INDEX_PAGE_SIZE {
                    return Err(index_error("index leaf node exceeds page size"));
                }
                page[cursor..cursor + 2].copy_from_slice(&key_len.to_le_bytes());
                cursor += 2;
                page[cursor..cursor + key.len()].copy_from_slice(key);
                cursor += key.len();
                page[cursor..cursor + 8].copy_from_slice(&entry.rid.page_id.to_le_bytes());
                cursor += 8;
                page[cursor..cursor + 2].copy_from_slice(&entry.rid.slot_id.to_le_bytes());
                cursor += 2;
            }
        }
        NodeKind::Internal => {
            for entry in &node.internal {
                scratch.clear();
                encode_key_into(&entry.key, &mut scratch)?;
                let key = &scratch;
                let key_len =
                    u16::try_from(key.len()).map_err(|_| index_error("index key too large"))?;
                let needed = 2 + key.len() + 8;
                if cursor + needed > INDEX_PAGE_SIZE {
                    return Err(index_error("index internal node exceeds page size"));
                }
                page[cursor..cursor + 2].copy_from_slice(&key_len.to_le_bytes());
                cursor += 2;
                page[cursor..cursor + key.len()].copy_from_slice(key);
                cursor += key.len();
                page[cursor..cursor + 8].copy_from_slice(&entry.child.to_le_bytes());
                cursor += 8;
            }
        }
    }
    page[34..36].copy_from_slice(&(cursor as u16).to_le_bytes());
    let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
    page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4].copy_from_slice(&checksum.to_le_bytes());
    Ok(page)
}

fn decode_node(page: &[u8; INDEX_PAGE_SIZE], expected_id: u64) -> Result<Node, PhobosError> {
    let _profile = phobos_observability::span("index.decode_node");
    if page[0..4] != NODE_MAGIC {
        return Err(index_error("invalid index node magic"));
    }
    let version = u16::from_le_bytes([page[4], page[5]]);
    if version != FORMAT_VERSION && !LEGACY_FORMAT_VERSIONS.contains(&version) {
        return Err(index_error("unsupported index node version"));
    }
    validate_node_checksum(page)?;
    let kind = match page[6] {
        1 => NodeKind::Leaf,
        2 => NodeKind::Internal,
        bulk::FREE_KIND => return Err(index_error("index page is free")),
        _ => return Err(index_error("unknown index node kind")),
    };
    let id = u64::from_le_bytes(page[8..16].try_into().expect("node id"));
    if id != expected_id {
        return Err(index_error("index node page identifier mismatch"));
    }
    let parent = u64::from_le_bytes(page[16..24].try_into().expect("parent"));
    let next_leaf = u64::from_le_bytes(page[24..32].try_into().expect("next leaf"));
    let count = usize::from(u16::from_le_bytes([page[32], page[33]]));
    let used = usize::from(u16::from_le_bytes([page[34], page[35]]));
    if !(NODE_HEADER..=INDEX_PAGE_SIZE).contains(&used) {
        return Err(index_error("invalid index node used-byte boundary"));
    }
    let mut cursor = NODE_HEADER;
    let mut node = Node {
        id,
        parent,
        next_leaf,
        first_child: NONE_PAGE,
        kind,
        leaf: Vec::new(),
        internal: Vec::new(),
    };
    if kind == NodeKind::Internal {
        node.first_child = u64::from_le_bytes(take_array_from_page::<8>(page, &mut cursor, used)?);
    }
    for _ in 0..count {
        let key_len = usize::from(u16::from_le_bytes(take_array_from_page::<2>(
            page,
            &mut cursor,
            used,
        )?));
        let key_bytes = take_page(page, &mut cursor, key_len, used)?;
        let key = decode_key_version(key_bytes, version)?;
        match kind {
            NodeKind::Leaf => {
                let page_id =
                    u64::from_le_bytes(take_array_from_page::<8>(page, &mut cursor, used)?);
                let slot_id =
                    u16::from_le_bytes(take_array_from_page::<2>(page, &mut cursor, used)?);
                node.leaf.push(LeafEntry {
                    key,
                    rid: RecordId { page_id, slot_id },
                });
            }
            NodeKind::Internal => {
                let child = u64::from_le_bytes(take_array_from_page::<8>(page, &mut cursor, used)?);
                node.internal.push(InternalEntry { key, child });
            }
        }
    }
    if cursor != used {
        return Err(index_error("index node contains trailing bytes"));
    }
    Ok(node)
}

/// 0.2-F: a shared, immutable index page image.
pub(crate) type PageRef = std::sync::Arc<[u8; INDEX_PAGE_SIZE]>;

/// 0.2-F: shared read; the flag is true only for an image that the committed
/// store validated with `validate_index_page_image` on entry.
fn read_page_ref(file: &mut PageIo, page_id: u64) -> Result<(PageRef, bool), PhobosError> {
    let _profile = phobos_observability::span("index.read_page");
    phobos_observability::event("point_pages_read", 1);
    let (image, trusted) = file.read_trusted(page_id)?;
    phobos_observability::event(
        if trusted {
            "index.page_reads_trusted"
        } else {
            "index.page_reads_validated"
        },
        1,
    );
    Ok((image, trusted))
}

/// 0.2-F: the committed store's validator for index files. Node pages get
/// exactly the checks `NodeView::new` performs (header, CRC32C, bounds and
/// every encoded key); the meta page its checksum; free pages the free-page
/// rule. Any other image (e.g. never written) cannot be used as a node or a
/// meta page, because every consumer checks magic, kind and page identity.
pub fn validate_index_page_image(page: &[u8; INDEX_PAGE_SIZE]) -> Result<(), PhobosError> {
    phobos_observability::event("index.store_validations", 1);
    if page[..4] == META_MAGIC {
        return validate_meta_checksum(page);
    }
    if page[..4] == NODE_MAGIC {
        let id = u64::from_le_bytes(page[8..16].try_into().expect("node id"));
        if page[6] == bulk::FREE_KIND {
            return if bulk::is_free_page(page, id) {
                Ok(())
            } else {
                Err(index_error("invalid free index page"))
            };
        }
        return node_view::NodeView::new(page, id).map(|_| ());
    }
    Ok(())
}

/// 0.2-G: `validate_index_page_image` for an image whose complete page
/// checksum (and LSN) the committed store has just verified on the same
/// borrow: every structural and key check still runs; the node CRC is not
/// recomputed a second time.
pub fn validate_index_page_structure(page: &[u8; INDEX_PAGE_SIZE]) -> Result<(), PhobosError> {
    phobos_observability::event("index.store_validations_checksum_verified", 1);
    if page[..4] == META_MAGIC {
        return validate_meta_checksum(page);
    }
    if page[..4] == NODE_MAGIC {
        let id = u64::from_le_bytes(page[8..16].try_into().expect("node id"));
        if page[6] == bulk::FREE_KIND {
            return if bulk::is_free_page(page, id) {
                Ok(())
            } else {
                Err(index_error("invalid free index page"))
            };
        }
        return node_view::NodeView::new_checksum_verified(page, id).map(|_| ());
    }
    Ok(())
}

/// 0.2-G: layout validation of an index image produced in this process
/// (header, kind, count, bounds and entry layout; no per-key decoding and no
/// CRC, which the caller verified on the same borrow).
pub fn validate_index_page_layout(page: &[u8; INDEX_PAGE_SIZE]) -> Result<(), PhobosError> {
    phobos_observability::event("index.store_validations_produced", 1);
    if page[..4] == NODE_MAGIC {
        let id = u64::from_le_bytes(page[8..16].try_into().expect("node id"));
        if page[6] == bulk::FREE_KIND {
            return validate_index_page_structure(page);
        }
        return node_view::NodeView::new_trusted(page, id).map(|_| ());
    }
    validate_index_page_structure(page)
}

fn read_page(file: &mut PageIo, page_id: u64) -> Result<[u8; INDEX_PAGE_SIZE], PhobosError> {
    let _profile = phobos_observability::span("index.read_page");
    phobos_observability::event("point_pages_read", 1);
    file.read(page_id)
}

fn write_page(
    file: &mut PageIo,
    page_id: u64,
    page: &[u8; INDEX_PAGE_SIZE],
) -> Result<(), PhobosError> {
    let _measurement = phobos_observability::span("index.write_page");
    file.write(page_id, page)
}

fn validate_meta_checksum(page: &[u8; INDEX_PAGE_SIZE]) -> Result<(), PhobosError> {
    phobos_observability::event("point_checksum_validations", 1);
    phobos_wal::page_checksum::validate_scheme(page)?;
    let expected = u32::from_le_bytes(
        page[META_CHECKSUM_OFFSET..META_CHECKSUM_OFFSET + 4]
            .try_into()
            .expect("meta checksum"),
    );
    if checksum_page(page, META_CHECKSUM_OFFSET) != expected {
        return Err(PhobosError::new(
            ErrorCode::ChecksumMismatch,
            "index meta checksum mismatch",
        ));
    }
    validate_page_lsn(page, 32)
}

fn validate_node_checksum(page: &[u8; INDEX_PAGE_SIZE]) -> Result<(), PhobosError> {
    phobos_observability::event("point_checksum_validations", 1);
    phobos_wal::page_checksum::validate_scheme(page)?;
    let expected = u32::from_le_bytes(
        page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4]
            .try_into()
            .expect("node checksum"),
    );
    if checksum_page(page, NODE_CHECKSUM_OFFSET) != expected {
        return Err(PhobosError::new(
            ErrorCode::ChecksumMismatch,
            "index node checksum mismatch",
        ));
    }
    validate_page_lsn(page, 40)
}

fn validate_page_lsn(page: &[u8; INDEX_PAGE_SIZE], offset: usize) -> Result<(), PhobosError> {
    if u16::from_le_bytes([page[4], page[5]]) == 2
        && u64::from_le_bytes(page[offset..offset + 8].try_into().expect("page LSN")) == 0
    {
        return Err(index_error("V2 index page has zero LSN"));
    }
    Ok(())
}

fn checksum_page(page: &[u8; INDEX_PAGE_SIZE], checksum_offset: usize) -> u32 {
    let _profile = phobos_observability::span("index.checksum_page");
    phobos_wal::page_checksum::checksum(page, checksum_offset)
}

fn take_u8(bytes: &[u8], cursor: &mut usize) -> Result<u8, PhobosError> {
    Ok(take(bytes, cursor, 1)?[0])
}

fn take_u16(bytes: &[u8], cursor: &mut usize) -> Result<u16, PhobosError> {
    Ok(u16::from_le_bytes(take_array::<2>(bytes, cursor)?))
}

fn take_array<const N: usize>(bytes: &[u8], cursor: &mut usize) -> Result<[u8; N], PhobosError> {
    take(bytes, cursor, N)?
        .try_into()
        .map_err(|_| index_error("truncated index key"))
}

fn take<'a>(bytes: &'a [u8], cursor: &mut usize, len: usize) -> Result<&'a [u8], PhobosError> {
    let end = cursor
        .checked_add(len)
        .ok_or_else(|| index_error("index decode offset overflow"))?;
    if end > bytes.len() {
        return Err(index_error("truncated index key"));
    }
    let value = &bytes[*cursor..end];
    *cursor = end;
    Ok(value)
}

fn take_array_from_page<const N: usize>(
    page: &[u8; INDEX_PAGE_SIZE],
    cursor: &mut usize,
    used: usize,
) -> Result<[u8; N], PhobosError> {
    take_page(page, cursor, N, used)?
        .try_into()
        .map_err(|_| index_error("truncated index node"))
}

fn take_page<'a>(
    page: &'a [u8; INDEX_PAGE_SIZE],
    cursor: &mut usize,
    len: usize,
    used: usize,
) -> Result<&'a [u8], PhobosError> {
    let end = cursor
        .checked_add(len)
        .ok_or_else(|| index_error("index node offset overflow"))?;
    if end > used {
        return Err(index_error("truncated index node"));
    }
    let value = &page[*cursor..end];
    *cursor = end;
    Ok(value)
}

fn index_error(message: impl Into<String>) -> PhobosError {
    PhobosError::new(ErrorCode::InvalidPage, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        collections::{BTreeMap, BTreeSet},
        fs,
        io::{Seek, SeekFrom, Write},
        time::{SystemTime, UNIX_EPOCH},
    };

    #[cfg(feature = "db1-diagnostics")]
    #[test]
    fn db1_tripwire_rejects_stale_pre_split_leaf_against_new_parent() {
        let dir = temp_path("db1-tripwire");
        fs::create_dir_all(&dir).unwrap();
        let path = dir.join("index");
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        let key = IndexKey(vec![Value::Int64(42)]);
        for id in 0..388 {
            tree.insert(key.clone(), rid(id)).unwrap();
        }
        tree.validate().unwrap();
        let mut stale = tree.read_node(1).unwrap();
        stale.next_leaf = NONE_PAGE;
        let error = tree
            .check_split_successor(&stale, &[tree.root_page])
            .unwrap_err();
        assert!(error.message.contains("index.split_successor_consistency"));
        assert!(error.message.contains("stored_next=18446744073709551615"));
        fs::remove_dir_all(dir).unwrap();
    }

    #[cfg(feature = "db1-diagnostics")]
    #[test]
    fn db1_pending_generations_validate_at_every_available_boundary() {
        use phobos_wal::v2::{FileId, PageAction, Wal};
        let dir = temp_path("db1-boundaries");
        let mut wal = Wal::create_with_versioned_heap(&dir).unwrap();
        let path = dir.join(FileId::Index(1).name());
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        let key = IndexKey(vec![Value::Int64(42)]);
        for id in 0..380 {
            tree.insert(key.clone(), rid(id)).unwrap();
        }
        let mut tickets = Vec::new();
        for (stable, ids) in [(1, 380..390), (2, 390..590)] {
            tree.begin_private(&dir.join(format!("private-{stable}")), stable, &dir)
                .unwrap();
            for id in ids {
                tree.insert_version(key.clone(), rid(id), stable).unwrap();
            }
            tree.validate().unwrap(); // after private/rebase preparation
            wal.begin_mvcc(stable).unwrap();
            tree.prepare_private_redo(FileId::Index(1), |page, bytes, allocated| {
                wal.append_page(
                    if allocated {
                        PageAction::Initialize
                    } else {
                        PageAction::Index
                    },
                    FileId::Index(1),
                    page,
                    bytes,
                )?;
                Ok(())
            })
            .unwrap();
            tree.validate().unwrap(); // immediately before commit-record append
            tree.stage_private().unwrap();
            tickets.push(wal.append_commit().unwrap());
            tree.validate().unwrap(); // appended, pending, not forced
        }
        let receipts = wal.force_commits(&tickets).unwrap();
        tree.validate().unwrap(); // forced, not installed
        for receipt in receipts {
            tree.install_pending(&receipt).unwrap();
            tree.validate().unwrap(); // each ordered installation
        }
        assert_eq!(tree.point_lookup(&key).unwrap().len(), 590);
        drop(tree);
        drop(wal);
        let mut reopened = BPlusTree::open(path, false, 1).unwrap();
        reopened.validate().unwrap();
        assert_eq!(reopened.point_lookup(&key).unwrap().len(), 590);
        drop(reopened);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn private_index_split_rollback_and_durable_install_preserve_tree() {
        use phobos_wal::v2::{Body, FileId, PageAction, Wal};
        let dir = temp_path("private");
        let mut wal = Wal::create(&dir).unwrap();
        let path = dir.join(FileId::Index(1).name());
        let mut tree = BPlusTree::open(&path, true, 1).unwrap();
        tree.insert(IndexKey(vec![Value::Int64(0)]), rid(0))
            .unwrap();
        let original = fs::read(&path).unwrap();
        let original_meta = (tree.root_page, tree.next_page);
        let scratch = dir.join("private");
        for commit in [false, true] {
            let id = wal.begin().unwrap();
            tree.begin_private(&scratch, id, &dir).unwrap();
            for i in 1..1200 {
                tree.insert(IndexKey(vec![Value::Int64(i)]), rid(i as u64))
                    .unwrap();
            }
            tree.validate().unwrap();
            assert_eq!(fs::read(&path).unwrap(), original);
            if commit {
                tree.prepare_private(|page, bytes, allocated| {
                    wal.append(Body::Page {
                        action: if allocated {
                            PageAction::Initialize
                        } else {
                            PageAction::Index
                        },
                        file: FileId::Index(1),
                        page,
                        image: Box::new(*bytes),
                    })?;
                    Ok(())
                })
                .unwrap();
                let receipt = wal.commit().unwrap();
                tree.install_private(&receipt).unwrap();
            } else {
                tree.rollback_private().unwrap();
                wal.abort().unwrap();
                assert_eq!((tree.root_page, tree.next_page), original_meta);
                assert!(
                    tree.point_lookup(&IndexKey(vec![Value::Int64(1000)]))
                        .unwrap()
                        .is_empty()
                );
            }
            tree.validate().unwrap();
            assert!(!scratch.exists());
        }
        drop(tree);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        let mut tree = BPlusTree::open(&path, true, 1).unwrap();
        tree.validate().unwrap();
        assert_eq!(
            tree.range(Bound::Unbounded, Bound::Unbounded)
                .unwrap()
                .len(),
            1200
        );
        drop(tree);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn d6_split_path_avoids_parent_rewrites_and_batches_private_meta() {
        let dir = temp_path("d6");
        fs::create_dir(&dir).unwrap();
        let path = dir.join("tree.idx");
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        tree.take_write_counters();
        tree.begin_private(&dir.join("private"), 1, &dir).unwrap();
        for i in 0..900i64 {
            tree.insert(
                IndexKey(vec![Value::Text(format!("{i:04}-{}", "x".repeat(180)))]),
                rid(i as u64),
            )
            .unwrap();
        }
        assert!(tree.validate().unwrap().height >= 3);
        let allocations = tree.next_page - 2;
        tree.prepare_private_deferred(|_, _, _| Ok(())).unwrap();
        let counters = tree.take_write_counters();
        assert_eq!(counters.parent_pointer_rewrite_writes, 0);
        assert_eq!(counters.meta_page_writes, 1);
        eprintln!(
            "D6_COUNTERS allocations={allocations} parent_pointer_rewrite_writes=0 meta_page_writes=1"
        );
        tree.rollback_private().unwrap();
        drop(tree);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn v2c_in_place_insert_is_byte_identical_to_generic_insert() {
        // Keys exercise every memcomparable tag, NUL escapes, duplicates with
        // different RIDs, exact re-inserts, chain probes and many splits.
        let key = |n: i64| {
            let text = match n % 5 {
                0 => format!("a\0b{n}"),
                1 => "é".repeat((n % 7) as usize),
                _ => format!("k{:04}", n % 97),
            };
            IndexKey(vec![
                Value::Int64(n % 113),
                Value::Text(text),
                match n % 4 {
                    0 => Value::Null,
                    1 => Value::Float64(-0.0),
                    2 => Value::Decimal {
                        unscaled: i128::from(n) - 50,
                        scale: 2,
                    },
                    _ => Value::Binary(vec![0, n as u8, 0]),
                },
            ])
        };
        for unique_layout in [false, true] {
            let fast_path = temp_path("v2c-fast");
            let generic_path = temp_path("v2c-generic");
            let mut fast = BPlusTree::open(&fast_path, unique_layout, 3).unwrap();
            let mut generic = BPlusTree::open(&generic_path, unique_layout, 3).unwrap();
            for n in 0..4000i64 {
                let k = (n * 7919) % 1500;
                let entry = (key(k), rid(n as u64 % 2900));
                fast.insert_entry(entry.0.clone(), entry.1, false).unwrap();
                generic
                    .insert_entry_generic(entry.0.clone(), entry.1, false)
                    .unwrap();
                if n % 5 == 0 {
                    // Exact duplicate: a no-op on both paths.
                    fast.insert_entry(entry.0.clone(), entry.1, false).unwrap();
                    generic
                        .insert_entry_generic(entry.0, entry.1, false)
                        .unwrap();
                }
            }
            // The fast path really is taken for a fitting leaf insert.
            assert!(
                fast.insert_entry_in_place(&key(1), rid(4_000_000)).unwrap(),
                "in-place path declined a fitting insert"
            );
            generic
                .insert_entry_generic(key(1), rid(4_000_000), false)
                .unwrap();
            fast.validate().unwrap();
            generic.validate().unwrap();
            fast.sync().unwrap();
            generic.sync().unwrap();
            drop((fast, generic));
            let (a, b) = (
                fs::read(&fast_path).unwrap(),
                fs::read(&generic_path).unwrap(),
            );
            assert_eq!(a.len(), b.len());
            assert!(a == b, "in-place insert produced different page images");
            fs::remove_file(fast_path).unwrap();
            fs::remove_file(generic_path).unwrap();
        }
        // The non-allocating validator accepts and rejects exactly as decode_key.
        for bytes in [
            encode_key(&key(3)).unwrap(),
            vec![1, 2],
            vec![4, b'a', 0, 7],
            vec![4, 0xc3, 0, 0],
            vec![4, 0xc3, 0xa9, 0, 0xff, 0x80, 0, 0],
            vec![5, 0x80, 0, 0],
            vec![2, 1, 2],
            vec![9],
            vec![0xff, 8, 1],
        ] {
            assert_eq!(
                validate_key_v3(&bytes).is_ok(),
                decode_key(&bytes).is_ok(),
                "{bytes:?}"
            );
        }
    }

    fn temp_path(label: &str) -> PathBuf {
        let n = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("phobos-index-{label}-{n}.idx"))
    }

    fn rid(n: u64) -> RecordId {
        RecordId {
            page_id: n / 100,
            slot_id: (n % 100) as u16,
        }
    }

    #[test]
    fn range_visitor_stops_before_later_corrupt_leaf() {
        let path = temp_path("visitor");
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        for i in 0..1200i64 {
            tree.insert(IndexKey(vec![Value::Int64(i)]), rid(i as u64))
                .unwrap();
        }
        tree.sync().unwrap();
        let first_id = tree.leftmost_leaf().unwrap();
        let first = tree.read_node(first_id).unwrap();
        assert_ne!(first.next_leaf, NONE_PAGE);
        let mut damaged = OpenOptions::new().write(true).open(&path).unwrap();
        damaged
            .seek(SeekFrom::Start(first.next_leaf * INDEX_PAGE_SIZE as u64))
            .unwrap();
        damaged.write_all(&[0; INDEX_PAGE_SIZE]).unwrap();
        drop(damaged);
        let mut count = 0;
        tree.range_visit(Bound::Unbounded, Bound::Unbounded, |_| {
            count += 1;
            Ok(false)
        })
        .unwrap();
        assert_eq!(count, 1);
        assert!(tree.range(Bound::Unbounded, Bound::Unbounded).is_err());
        drop(tree);
        fs::remove_file(path).unwrap();
    }

    #[test]
    fn point_range_split_and_restart() {
        let path = temp_path("range");
        {
            let mut tree = BPlusTree::open(&path, false, 1).unwrap();
            for i in 0..1200i64 {
                tree.insert(IndexKey(vec![Value::Int64(i)]), rid(i as u64))
                    .unwrap();
            }
            assert_eq!(
                tree.point_lookup(&IndexKey(vec![Value::Int64(777)]))
                    .unwrap(),
                vec![rid(777)]
            );
            let lower = IndexKey(vec![Value::Int64(100)]);
            let upper = IndexKey(vec![Value::Int64(109)]);
            assert_eq!(
                tree.range(Bound::Included(&lower), Bound::Included(&upper))
                    .unwrap()
                    .len(),
                10
            );
            let report = tree.validate().unwrap();
            assert!(report.height >= 2);
            tree.sync().unwrap();
        }
        {
            let mut tree = BPlusTree::open(&path, false, 1).unwrap();
            assert_eq!(
                tree.point_lookup(&IndexKey(vec![Value::Int64(777)]))
                    .unwrap(),
                vec![rid(777)]
            );
            tree.validate().unwrap();
        }
        let _ = fs::remove_file(path);
    }

    #[test]
    fn composite_unique_and_null_semantics() {
        let path = temp_path("composite");
        let mut tree = BPlusTree::open(&path, true, 2).unwrap();
        let key = IndexKey(vec![Value::Text("a".into()), Value::Int64(1)]);
        tree.insert(key.clone(), rid(1)).unwrap();
        assert_eq!(
            tree.insert(key, rid(2)).unwrap_err().code,
            ErrorCode::ConstraintViolation
        );
        let null_key = IndexKey(vec![Value::Text("a".into()), Value::Null]);
        tree.insert(null_key.clone(), rid(3)).unwrap();
        tree.insert(null_key.clone(), rid(4)).unwrap();
        assert_eq!(tree.point_lookup(&null_key).unwrap().len(), 2);
        tree.validate().unwrap();
        let _ = fs::remove_file(path);
    }

    #[test]
    fn randomized_mutations_match_model() {
        let path = temp_path("random");
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        let mut model: BTreeMap<i64, BTreeSet<RecordId>> = BTreeMap::new();
        let mut seed = 0x5eed_cafe_d00d_beefu64;
        for step in 0..5000u64 {
            seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
            let key_value = ((seed >> 16) % 300) as i64;
            let record = rid(step % 700);
            let key = IndexKey(vec![Value::Int64(key_value)]);
            if seed & 1 == 0 {
                tree.insert(key.clone(), record).unwrap();
                model.entry(key_value).or_default().insert(record);
            } else {
                let removed_tree = tree.delete(&key, record).unwrap();
                let removed_model = model
                    .get_mut(&key_value)
                    .is_some_and(|set| set.remove(&record));
                assert_eq!(removed_tree, removed_model);
            }
            if step % 251 == 0 {
                tree.validate().unwrap();
            }
        }
        for (key_value, expected) in model {
            let mut actual = tree
                .point_lookup(&IndexKey(vec![Value::Int64(key_value)]))
                .unwrap();
            actual.sort();
            let expected: Vec<_> = expected.into_iter().collect();
            assert_eq!(actual, expected);
        }
        tree.validate().unwrap();
        let _ = fs::remove_file(path);
    }

    #[test]
    fn corruption_is_detected() {
        let path = temp_path("corrupt");
        {
            let mut tree = BPlusTree::open(&path, false, 1).unwrap();
            tree.insert(IndexKey(vec![Value::Int64(1)]), rid(1))
                .unwrap();
            tree.sync().unwrap();
        }
        let mut bytes = fs::read(&path).unwrap();
        bytes[INDEX_PAGE_SIZE + 100] ^= 0x40;
        fs::write(&path, bytes).unwrap();
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        assert_eq!(
            tree.validate().unwrap_err().code,
            ErrorCode::ChecksumMismatch
        );
        let _ = fs::remove_file(path);
    }
    #[test]
    fn repeated_entries_across_split_leaves_remain_idempotent() {
        for unique in [false, true] {
            let path = temp_path("split-duplicates");
            let key = IndexKey(vec![if unique { Value::Null } else { Value::Int64(7) }]);
            {
                let mut tree = BPlusTree::open(&path, unique, 1).unwrap();
                for id in 0..1500 {
                    tree.insert(key.clone(), rid(id)).unwrap();
                }
                assert!(tree.validate().unwrap().leaves > 2);
                // A descending separator remains corruption even with valid checksums.
                let root = tree.read_node(tree.root_page).unwrap();
                assert!(root.internal.len() > 1);
                let mut corrupt = root.clone();
                corrupt.internal[1].key = IndexKey(vec![Value::Int64(-1)]);
                tree.write_node(&corrupt).unwrap();
                assert!(tree.validate().is_err());
                tree.write_node(&root).unwrap();
                tree.validate().unwrap();
                for id in [0, 750, 1499] {
                    tree.insert(key.clone(), rid(id)).unwrap();
                }
                assert_eq!(tree.point_lookup(&key).unwrap().len(), 1500);
                tree.sync().unwrap();
            }
            {
                let mut tree = BPlusTree::open(&path, unique, 1).unwrap();
                let actual: std::collections::BTreeSet<_> =
                    tree.point_lookup(&key).unwrap().into_iter().collect();
                assert_eq!(
                    actual,
                    (0..1500)
                        .map(rid)
                        .collect::<std::collections::BTreeSet<_>>()
                );
                tree.validate().unwrap();
            }
            fs::remove_file(path).unwrap();
        }
    }
}

#[cfg(test)]
mod phase_b_tests;
#[cfg(test)]
mod phase_e_tests;
