//! Validate bounded traversal batches against this index's publication epoch.
//! Readers copy immutable committed images and release every frame pin before
//! visibility evaluation. They never retain a structural guard across a visitor.
use super::*;
use std::sync::{Condvar, Mutex, RwLock, RwLockWriteGuard};

#[derive(Debug, Default)]
pub(super) struct Epoch {
    state: Mutex<State>,
    changed: Condvar,
    fairness: RwLock<()>,
}
#[derive(Debug, Default)]
struct State {
    generation: u64,
    failed: bool,
}
pub(super) struct Publication<'a> {
    epoch: &'a Epoch,
    _writer: RwLockWriteGuard<'a, ()>,
    complete: bool,
    _scope: phobos_observability::StructuralScope,
}
impl Epoch {
    pub fn begin(&self) -> Result<Publication<'_>, PhobosError> {
        let wait = phobos_observability::span("index.publication_acquire");
        let writer = self
            .fairness
            .write()
            .map_err(|_| index_error("index publication poisoned"))?;
        drop(wait);
        let mut state = self
            .state
            .lock()
            .map_err(|_| index_error("index epoch poisoned"))?;
        if state.failed || state.generation % 2 != 0 || state.generation.checked_add(2).is_none() {
            return Err(index_error("index publication requires recovery"));
        }
        state.generation += 1;
        Ok(Publication {
            epoch: self,
            _writer: writer,
            complete: false,
            _scope: phobos_observability::structural_scope(),
        })
    }
    fn token(&self) -> Result<u64, PhobosError> {
        let _wait = phobos_observability::span("index.epoch_wait");
        let mut state = self
            .state
            .lock()
            .map_err(|_| index_error("index epoch poisoned"))?;
        while !state.failed && state.generation % 2 != 0 {
            state = self
                .changed
                .wait(state)
                .map_err(|_| index_error("index epoch poisoned"))?;
        }
        if state.failed {
            return Err(index_error("index publication requires recovery"));
        }
        Ok(state.generation)
    }
    fn unchanged(&self, token: u64) -> Result<bool, PhobosError> {
        let state = self
            .state
            .lock()
            .map_err(|_| index_error("index epoch poisoned"))?;
        if state.failed {
            return Err(index_error("index publication requires recovery"));
        }
        Ok(state.generation == token)
    }
    pub fn read_with_token<T>(
        &self,
        mut operation: impl FnMut(u64) -> Result<T, PhobosError>,
    ) -> Result<T, PhobosError> {
        for _ in 0..8 {
            let token = self.token()?;
            let result = operation(token);
            // Even a traversal error may be a transient mixed split generation.
            // A stable-generation error is corruption and is never suppressed.
            if self.unchanged(token)? {
                return result;
            }
            phobos_observability::event("index.epoch_restart", 1);
        }
        // Prevent reader starvation under continuous publication. This fallback
        // reserves just one bounded index batch, never a query or status lookup.
        phobos_observability::event("index.epoch_fair_batch", 1);
        let wait = phobos_observability::span("index.fair_read_acquire");
        let _fair = self
            .fairness
            .read()
            .map_err(|_| index_error("index publication poisoned"))?;
        drop(wait);
        let _scope = phobos_observability::structural_scope();
        let token = self.token()?;
        operation(token)
    }
}
impl Publication<'_> {
    pub fn complete(mut self) {
        self.complete = true;
    }
}
impl Drop for Publication<'_> {
    fn drop(&mut self) {
        if let Ok(mut state) = self.epoch.state.lock() {
            state.failed |= !self.complete;
            state.generation += 1;
            self.epoch.changed.notify_all();
        }
    }
}
