use super::*;

#[test]
fn borrowed_view_matches_owned_decoder_for_all_key_types_and_bounds() {
    let values = vec![
        Value::Null,
        Value::Boolean(false),
        Value::Boolean(true),
        Value::Int64(-1),
        Value::Int64(1),
        Value::Float64(-0.0),
        Value::Float64(0.0),
        Value::Float64(f64::NAN),
        Value::Float64(f64::from_bits(0xfff8_0000_0000_0001)),
        Value::Float64(f64::INFINITY),
        Value::Text("a".into()),
        Value::Text("é".into()),
        Value::Binary(vec![0, 255]),
        Value::Date(-5),
        Value::Timestamp(42),
        Value::Decimal {
            unscaled: -77,
            scale: 2,
        },
    ];
    let mut keys: Vec<_> = values.into_iter().map(|v| IndexKey(vec![v])).collect();
    keys.push(IndexKey(vec![]));
    keys.push(IndexKey(vec![Value::Text("a".into()), Value::Int64(2)]));
    keys.sort();
    let mut node = Node::new_leaf(1, NONE_PAGE);
    for (i, key) in keys.iter().enumerate() {
        node.leaf.push(LeafEntry {
            key: key.clone(),
            rid: RecordId {
                page_id: i as u64,
                slot_id: 0,
            },
        });
    }
    let page = encode_node(&node).unwrap();
    let owned = decode_node(&page, 1).unwrap();
    let view = node_view::NodeView::new(&page, 1).unwrap();
    for target in &keys {
        for i in 0..keys.len() {
            assert_eq!(
                view.compare(i, target).unwrap(),
                owned.leaf[i].key.cmp(target)
            );
            assert_eq!(view.entry(i).unwrap().key, owned.leaf[i].key);
            assert_eq!(view.entry(i).unwrap().rid, owned.leaf[i].rid);
        }
        for excluded in [false, true] {
            let expected = owned.leaf.partition_point(|e| {
                if excluded {
                    e.key <= *target
                } else {
                    e.key < *target
                }
            });
            assert_eq!(view.lower_bound(target, excluded).unwrap(), expected);
        }
    }
    let mut corrupt = page;
    corrupt[4000] ^= 1;
    assert!(node_view::NodeView::new(&corrupt, 1).is_err());
    let mut one = Node::new_leaf(1, NONE_PAGE);
    one.leaf.push(LeafEntry {
        key: IndexKey(vec![Value::Text("validated even when skipped".into())]),
        rid: RecordId {
            page_id: 0,
            slot_id: 0,
        },
    });
    corrupt = encode_node(&one).unwrap();
    corrupt[NODE_HEADER + 4] = 255; // invalid value tag, with a valid checksum
    let crc = checksum_page(&corrupt, NODE_CHECKSUM_OFFSET);
    corrupt[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4].copy_from_slice(&crc.to_le_bytes());
    assert!(node_view::NodeView::new(&corrupt, 1).is_err());
    assert!(decode_node(&corrupt, 1).is_err());
}

#[test]
fn legacy_fnv_index_reopens_then_crc_rewrite_preserves_lookup_and_integrity() {
    let path = std::env::temp_dir().join(format!("phobos-b3-index-{}.idx", std::process::id()));
    {
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        for i in 0..400 {
            tree.insert(
                IndexKey(vec![Value::Int64(i)]),
                RecordId {
                    page_id: i as u64,
                    slot_id: 0,
                },
            )
            .unwrap();
        }
        tree.sync().unwrap();
    }
    let mut bytes = std::fs::read(&path).unwrap();
    for page in bytes.chunks_exact_mut(INDEX_PAGE_SIZE) {
        page[7] = 0;
        let offset = if page[..4] == META_MAGIC {
            META_CHECKSUM_OFFSET
        } else {
            NODE_CHECKSUM_OFFSET
        };
        page[offset..offset + 4].fill(0);
        let hash = page.iter().fold(0x811c_9dc5u32, |h, b| {
            (h ^ u32::from(*b)).wrapping_mul(0x0100_0193)
        });
        page[offset..offset + 4].copy_from_slice(&hash.to_le_bytes());
    }
    std::fs::write(&path, bytes).unwrap();
    {
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        assert_eq!(
            tree.point_lookup(&IndexKey(vec![Value::Int64(177)]))
                .unwrap()[0]
                .page_id,
            177
        );
        tree.insert(
            IndexKey(vec![Value::Int64(401)]),
            RecordId {
                page_id: 401,
                slot_id: 0,
            },
        )
        .unwrap();
        assert_eq!(tree.validate().unwrap().entries, 401);
        tree.sync().unwrap();
    }
    {
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        let lo = IndexKey(vec![Value::Int64(170)]);
        let hi = IndexKey(vec![Value::Int64(179)]);
        assert_eq!(
            tree.range(Bound::Included(&lo), Bound::Included(&hi))
                .unwrap()
                .len(),
            10
        );
        assert_eq!(tree.validate().unwrap().entries, 401);
    }
    std::fs::remove_file(path).unwrap();
}
