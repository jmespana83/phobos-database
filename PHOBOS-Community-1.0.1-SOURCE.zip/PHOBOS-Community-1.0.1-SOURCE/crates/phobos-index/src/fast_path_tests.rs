//! 0.2-F: store-validated shared index images, view layout reuse and
//! encode-once comparisons. Every test checks the conservative direction:
//! nothing unvalidated is ever trusted, and a changed page is never served
//! from an older image or layout.
use super::*;
use phobos_storage::committed_pages::{CommittedStore, FlushConfig};
use phobos_wal::v2::{FileId, PageAction, Wal};
use std::{fs, path::Path, sync::Arc};

fn root(name: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "phobos-0-2-f-{name}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}
fn key(id: u64, width: usize) -> IndexKey {
    IndexKey(vec![Value::Text(format!("{id:06}{}", "x".repeat(width)))])
}
fn rid(id: u64) -> RecordId {
    RecordId {
        page_id: id,
        slot_id: 0,
    }
}
/// One committed MVCC publication of `ids` (insert) through the private /
/// WAL / install path, like the engine's commit.
fn publish(
    tree: &mut BPlusTree,
    wal: &mut Wal,
    root: &Path,
    stable: u64,
    ids: impl IntoIterator<Item = u64>,
    width: usize,
) {
    tree.begin_private(&root.join(format!("private-{stable}")), stable, root)
        .unwrap();
    for id in ids {
        tree.insert_version(key(id, width), rid(id), stable)
            .unwrap();
    }
    wal.begin_mvcc(stable).unwrap();
    tree.prepare_private_redo(FileId::Index(1), |page, bytes, allocated| {
        wal.append_page(
            if allocated {
                PageAction::Initialize
            } else {
                PageAction::Index
            },
            FileId::Index(1),
            page,
            bytes,
        )?;
        Ok(())
    })
    .unwrap();
    tree.stage_private().unwrap();
    let receipt = wal.commit().unwrap();
    tree.install_pending(&receipt).unwrap();
}
fn setup(name: &str) -> (PathBuf, Wal, Arc<CommittedStore>, BPlusTree) {
    let dir = root(name);
    let wal = Wal::create_with_versioned_heap(&dir).unwrap();
    let dir = fs::canonicalize(dir).unwrap();
    let store = CommittedStore::new(&dir, FlushConfig::default()).unwrap();
    let mut tree = BPlusTree::open(dir.join(FileId::Index(1).name()), false, 1).unwrap();
    tree.attach_committed(&store, FileId::Index(1)).unwrap();
    (dir, wal, store, tree)
}
fn finish(dir: PathBuf, wal: Wal, store: Arc<CommittedStore>, mut tree: BPlusTree) {
    tree.force_committed().unwrap();
    store.stop().unwrap();
    drop(tree);
    drop(store);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}
fn lookup_all(handle: &committed_reader::IndexReader, ids: &[u64], width: usize) {
    for id in ids {
        let mut reader = handle.statement_reader().unwrap();
        assert_eq!(
            reader.point_lookup(&key(*id, width)).unwrap(),
            vec![rid(*id)],
            "key {id}"
        );
    }
}

/// L1: the same committed image is shared (one immutable allocation) and
/// trusted only because the store validated it on entry.
#[test]
fn f1_committed_image_is_validated_once_and_shared() {
    let (dir, mut wal, store, mut tree) = setup("shared");
    publish(&mut tree, &mut wal, &dir, 1, 0..40, 200);
    let leaf = tree.leftmost_leaf().unwrap();
    let (first, trusted) = tree.file.read_trusted(leaf).unwrap();
    let (second, again) = tree.file.read_trusted(leaf).unwrap();
    assert!(trusted && again);
    assert!(Arc::ptr_eq(&first, &second), "same version, same image");
    // A trusted view equals a fully validated view of the same bytes.
    let checked = node_view::NodeView::new(&first, leaf).unwrap();
    let trusted_view = node_view::NodeView::new_trusted(&first, leaf).unwrap();
    assert_eq!(checked.layout()[..], trusted_view.layout()[..]);
    finish(dir, wal, store, tree);
}

/// L2: a publication replaces the image; the old shared image is never
/// returned again and readers see the new entry (no stale decoded node).
#[test]
fn f2_publication_changes_the_image_and_rejects_the_old_one() {
    let (dir, mut wal, store, mut tree) = setup("publish");
    publish(&mut tree, &mut wal, &dir, 1, (0..40).map(|i| i * 2), 200);
    let handle = tree.read_handle().unwrap();
    lookup_all(&handle, &[0, 2, 78], 200);
    let leaf = tree.leftmost_leaf().unwrap();
    let (before, _) = tree.file.read_trusted(leaf).unwrap();
    publish(&mut tree, &mut wal, &dir, 2, [1, 3], 200);
    let (after, trusted) = tree.file.read_trusted(leaf).unwrap();
    assert!(trusted);
    assert!(
        !Arc::ptr_eq(&before, &after),
        "a new version is a new image"
    );
    assert_ne!(before[..], after[..]);
    lookup_all(&handle, &[0, 1, 2, 3, 78], 200);
    finish(dir, wal, store, tree);
}

/// L3-L5: leaf, internal and root splits between reads. Every probe after
/// each publication finds exactly the committed keys.
#[test]
fn f3_leaf_internal_and_root_splits_never_serve_stale_paths() {
    let (dir, mut wal, store, mut tree) = setup("splits");
    let handle = tree.read_handle().unwrap();
    let mut committed = Vec::new();
    let mut height = 0;
    for round in 0..12u64 {
        let ids: Vec<u64> = (0..8).map(|i| i * 100 + round).collect();
        publish(&mut tree, &mut wal, &dir, round + 1, ids.clone(), 1500);
        committed.extend(ids);
        let shape = tree.validate().unwrap();
        height = height.max(shape.height);
        lookup_all(&handle, &committed, 1500);
        // A key that was never inserted is never found via a cached path.
        let mut reader = handle.statement_reader().unwrap();
        assert!(reader.point_lookup(&key(99_999, 1500)).unwrap().is_empty());
    }
    assert!(
        height >= 3,
        "the workload must split the root at least twice"
    );
    finish(dir, wal, store, tree);
}

/// L6: private (uncommitted) images are never trusted, even when they are
/// byte-identical to a committed one; the committed image stays trusted.
#[test]
fn f4_private_images_are_never_trusted() {
    let (dir, mut wal, store, mut tree) = setup("private");
    publish(&mut tree, &mut wal, &dir, 1, 0..20, 200);
    let leaf = tree.leftmost_leaf().unwrap();
    tree.begin_private(&dir.join("private-2"), 2, &dir).unwrap();
    let (_, untouched) = tree.file.read_trusted(leaf).unwrap();
    assert!(
        untouched,
        "an unmodified page still reads the committed image"
    );
    tree.insert_version(key(5_000, 200), rid(5_000), 2).unwrap();
    let modified = (1..tree.next_page)
        .filter(|page| !tree.file.read_trusted(*page).unwrap().1)
        .count();
    assert!(modified >= 1, "the private leaf is read as unvalidated");
    tree.rollback_private().unwrap();
    assert!(tree.file.read_trusted(leaf).unwrap().1);
    finish(dir, wal, store, tree);
}

/// L7: an index image that fails validation is never admitted from disk.
#[test]
fn f5_corrupt_disk_image_is_rejected_on_store_entry() {
    let (dir, mut wal, store, mut tree) = setup("corrupt");
    publish(&mut tree, &mut wal, &dir, 1, 0..40, 200);
    tree.force_committed().unwrap();
    let leaf = tree.leftmost_leaf().unwrap();
    store.stop().unwrap();
    drop(tree);
    drop(store);
    // Flip one key byte of the leaf on disk (the stored CRC no longer matches).
    let path = dir.join(FileId::Index(1).name());
    let mut bytes = fs::read(&path).unwrap();
    let at = leaf as usize * INDEX_PAGE_SIZE + NODE_HEADER + 4;
    bytes[at] ^= 0x01;
    fs::write(&path, &bytes).unwrap();
    let store = CommittedStore::new(&dir, FlushConfig::default()).unwrap();
    let mut tree = BPlusTree::open(&path, false, 1).unwrap();
    tree.attach_committed(&store, FileId::Index(1)).unwrap();
    assert!(tree.file.read_trusted(leaf).is_err());
    let handle = tree.read_handle().unwrap();
    let mut reader = handle.statement_reader().unwrap();
    assert!(reader.point_lookup(&key(0, 200)).is_err());
    store.stop().unwrap();
    drop(reader);
    drop(handle);
    drop(tree);
    drop(store);
    drop(wal);
    fs::remove_dir_all(dir).unwrap();
}

/// L8: encode-once comparison is exactly the decoding comparison, for every
/// position of a node, for present and absent targets of mixed types.
#[test]
fn f6_encoded_lower_bound_equals_decoding_comparison() {
    let mut node = Node {
        id: 7,
        parent: NONE_PAGE,
        next_leaf: NONE_PAGE,
        first_child: NONE_PAGE,
        kind: NodeKind::Leaf,
        leaf: Vec::new(),
        internal: Vec::new(),
    };
    let mut keys: Vec<IndexKey> = Vec::new();
    for i in 0..60i64 {
        keys.push(IndexKey(vec![
            Value::Int64(i * 3 - 90),
            Value::Text(format!("k{:03}", i % 7)),
        ]));
    }
    keys.sort();
    for (i, key) in keys.iter().enumerate() {
        node.leaf.push(LeafEntry {
            key: key.clone(),
            rid: rid(i as u64),
        });
    }
    let page = encode_node(&node).unwrap();
    let view = node_view::NodeView::new(&page, 7).unwrap();
    let mut targets = keys.clone();
    for i in -100..100i64 {
        targets.push(IndexKey(vec![Value::Int64(i), Value::Text("k003".into())]));
        targets.push(IndexKey(vec![Value::Int64(i)]));
    }
    for target in &targets {
        for excluded in [false, true] {
            let expected = (0..view.count)
                .find(|i| {
                    let order = view.compare(*i, target).unwrap();
                    order == Ordering::Greater || !excluded && order == Ordering::Equal
                })
                .unwrap_or(view.count);
            assert_eq!(view.lower_bound(target, excluded).unwrap(), expected);
        }
        let encoded = encode_key(target).unwrap();
        for i in 0..view.count {
            assert_eq!(
                view.compare_encoded(i, &encoded),
                view.compare(i, target).unwrap()
            );
        }
    }
    // A layout is only accepted for the image it came from.
    let layout = view.layout();
    assert!(node_view::NodeView::with_layout(&page, 7, &layout).is_ok());
    assert!(node_view::NodeView::with_layout(&page, 8, &layout).is_err());
    assert!(node_view::NodeView::with_layout(&page, 7, &layout[1..]).is_err());
}

/// L9: batched inserts keep the leaf length exactly (debug-asserted per
/// insert) across splits, and the tree stays valid and complete.
#[test]
fn f7_batched_inserts_track_leaf_length_across_splits() {
    let (dir, mut wal, store, mut tree) = setup("batch");
    tree.begin_private(&dir.join("private-1"), 1, &dir).unwrap();
    let entries: Vec<(IndexKey, RecordId)> = (0..900).map(|i| (key(i, 120), rid(i))).collect();
    tree.insert_versions_batch(entries, 1).unwrap();
    wal.begin_mvcc(1).unwrap();
    tree.prepare_private_redo(FileId::Index(1), |page, bytes, allocated| {
        wal.append_page(
            if allocated {
                PageAction::Initialize
            } else {
                PageAction::Index
            },
            FileId::Index(1),
            page,
            bytes,
        )?;
        Ok(())
    })
    .unwrap();
    tree.stage_private().unwrap();
    let receipt = wal.commit().unwrap();
    tree.install_pending(&receipt).unwrap();
    let shape = tree.validate().unwrap();
    assert_eq!(shape.entries, 900);
    let handle = tree.read_handle().unwrap();
    lookup_all(&handle, &[0, 1, 450, 899], 120);
    finish(dir, wal, store, tree);
}
