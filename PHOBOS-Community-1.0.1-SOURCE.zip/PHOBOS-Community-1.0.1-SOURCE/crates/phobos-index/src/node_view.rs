//! Borrowed reads of the existing packed node encoding. Offsets are derived on
//! the stack; neither page bytes nor every key are copied into owned nodes.
use super::*;

// Even an empty encoded key needs 2 length + 2 count + 8 child bytes.
const MAX_ENTRIES: usize = (INDEX_PAGE_SIZE - NODE_HEADER) / 12;
pub(super) struct NodeView<'a> {
    page: &'a [u8; INDEX_PAGE_SIZE],
    offsets: [u16; MAX_ENTRIES],
    pub count: usize,
    pub kind: NodeKind,
    pub next: u64,
    version: u16,
}
/// 0.2-F: the entry offsets of a node view, memoized next to the immutable
/// page image they were computed from (navigation cache). Rebuilding a view
/// from them skips the per-entry walk; they are only ever paired with the
/// same shared image (`PageRef`) they came from.
pub(super) type Layout = std::sync::Arc<[u16]>;

impl<'a> NodeView<'a> {
    /// The offsets of this view, for `with_layout` over the same image.
    pub fn layout(&self) -> Layout {
        std::sync::Arc::from(&self.offsets[..self.count])
    }
    /// A view of `page` (already validated, with `layout` computed from this
    /// exact image) without walking the entries again. Header, identity,
    /// kind, count and bounds are still checked.
    pub fn with_layout(
        page: &'a [u8; INDEX_PAGE_SIZE],
        id: u64,
        layout: &[u16],
    ) -> Result<Self, PhobosError> {
        let version = u16::from_le_bytes([page[4], page[5]]);
        if page[..4] != NODE_MAGIC
            || !(version == FORMAT_VERSION || LEGACY_FORMAT_VERSIONS.contains(&version))
            || u64::from_le_bytes(page[8..16].try_into().expect("id")) != id
        {
            return Err(index_error("invalid index node header"));
        }
        let kind = match page[6] {
            1 => NodeKind::Leaf,
            2 => NodeKind::Internal,
            _ => return Err(index_error("invalid index node kind")),
        };
        let count = usize::from(u16::from_le_bytes([page[32], page[33]]));
        let used = usize::from(u16::from_le_bytes([page[34], page[35]]));
        if count > MAX_ENTRIES
            || layout.len() != count
            || !(NODE_HEADER..=INDEX_PAGE_SIZE).contains(&used)
            || layout.iter().any(|offset| usize::from(*offset) >= used)
        {
            return Err(index_error("invalid index node layout"));
        }
        phobos_observability::event("index.view_layout_reuse", 1);
        let mut offsets = [0; MAX_ENTRIES];
        offsets[..count].copy_from_slice(layout);
        Ok(Self {
            page,
            offsets,
            count,
            kind,
            next: u64::from_le_bytes(page[24..32].try_into().expect("next")),
            version,
        })
    }
    pub fn new(page: &'a [u8; INDEX_PAGE_SIZE], id: u64) -> Result<Self, PhobosError> {
        Self::build(page, id, false)
    }
    /// 0.2-G: full structural and per-key validation of an image whose
    /// complete checksum the caller has just verified on the same borrow
    /// (`CommittedFile::publish_verified`); only the CRC is not recomputed.
    pub(crate) fn new_checksum_verified(
        page: &'a [u8; INDEX_PAGE_SIZE],
        id: u64,
    ) -> Result<Self, PhobosError> {
        Self::build_mode(page, id, false, true)
    }
    pub fn new_trusted(page: &'a [u8; INDEX_PAGE_SIZE], id: u64) -> Result<Self, PhobosError> {
        Self::build(page, id, true)
    }
    fn build(page: &'a [u8; INDEX_PAGE_SIZE], id: u64, trusted: bool) -> Result<Self, PhobosError> {
        Self::build_mode(page, id, !trusted, !trusted)
    }
    fn build_mode(
        page: &'a [u8; INDEX_PAGE_SIZE],
        id: u64,
        checksum: bool,
        keys: bool,
    ) -> Result<Self, PhobosError> {
        let trusted = !keys;
        phobos_observability::event(
            if trusted {
                "index.view_builds_trusted"
            } else {
                "index.view_builds_validated"
            },
            1,
        );
        let version = u16::from_le_bytes([page[4], page[5]]);
        if page[..4] != NODE_MAGIC
            || !(version == FORMAT_VERSION || LEGACY_FORMAT_VERSIONS.contains(&version))
            || u64::from_le_bytes(page[8..16].try_into().expect("id")) != id
        {
            return Err(index_error("invalid index node header"));
        }
        if checksum {
            validate_node_checksum(page)?;
        }
        let kind = match page[6] {
            1 => NodeKind::Leaf,
            2 => NodeKind::Internal,
            _ => return Err(index_error("invalid index node kind")),
        };
        let count = usize::from(u16::from_le_bytes([page[32], page[33]]));
        let used = usize::from(u16::from_le_bytes([page[34], page[35]]));
        if count > MAX_ENTRIES || !(NODE_HEADER..=INDEX_PAGE_SIZE).contains(&used) {
            return Err(index_error("invalid index node bounds"));
        }
        let mut view = Self {
            page,
            offsets: [0; MAX_ENTRIES],
            count,
            kind,
            next: u64::from_le_bytes(page[24..32].try_into().expect("next")),
            version,
        };
        let mut cursor = NODE_HEADER;
        if kind == NodeKind::Internal {
            take_page(page, &mut cursor, 8, used)?;
        }
        for i in 0..count {
            view.offsets[i] = cursor as u16;
            let len = usize::from(u16::from_le_bytes(take_array_from_page::<2>(
                page,
                &mut cursor,
                used,
            )?));
            let key = take_page(page, &mut cursor, len, used)?;
            // Validate all encoded keys, including entries a binary search skips.
            if !trusted {
                if version == FORMAT_VERSION {
                    // 0.2-C: the same acceptance rules as `decode_key`
                    // without materializing every key.
                    validate_key_v3(key)?;
                } else {
                    visit_key(key, None, version)?;
                }
            }
            take_page(
                page,
                &mut cursor,
                if kind == NodeKind::Leaf { 10 } else { 8 },
                used,
            )?;
        }
        if cursor != used {
            return Err(index_error("index node contains trailing bytes"));
        }
        Ok(view)
    }
    fn key_end(&self, i: usize) -> (usize, usize) {
        let start = usize::from(self.offsets[i]);
        let len = usize::from(u16::from_le_bytes([self.page[start], self.page[start + 1]]));
        (start + 2, start + 2 + len)
    }
    pub fn compare(&self, i: usize, key: &IndexKey) -> Result<Ordering, PhobosError> {
        let (start, end) = self.key_end(i);
        visit_key(&self.page[start..end], Some(key), self.version)
    }
    /// 0.2-F: `compare` for the current (memcomparable) format against a key
    /// encoded once by the caller. Every key of a current-format view was
    /// validated with `validate_key_v3` when the view (or, for a trusted
    /// view, the store image) was built, so `compare`'s per-call decode can
    /// never fail and the result is exactly the byte order it returns.
    pub fn compare_encoded(&self, i: usize, encoded: &[u8]) -> Ordering {
        debug_assert_eq!(self.version, FORMAT_VERSION);
        self.key_bytes(i).cmp(encoded)
    }
    /// First key >= target (or > target for an excluded lower bound).
    pub fn lower_bound(&self, key: &IndexKey, excluded: bool) -> Result<usize, PhobosError> {
        if self.version == FORMAT_VERSION {
            // 0.2-F: encode the target once instead of once per comparison.
            let encoded = encode_key(key)?;
            let (mut lo, mut hi) = (0, self.count);
            while lo < hi {
                let mid = lo + (hi - lo) / 2;
                let order = self.compare_encoded(mid, &encoded);
                if order == Ordering::Less || excluded && order == Ordering::Equal {
                    lo = mid + 1;
                } else {
                    hi = mid;
                }
            }
            return Ok(lo);
        }
        let (mut lo, mut hi) = (0, self.count);
        while lo < hi {
            let mid = lo + (hi - lo) / 2;
            let order = self.compare(mid, key)?;
            if order == Ordering::Less || excluded && order == Ordering::Equal {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        Ok(lo)
    }
    pub fn child(&self, key: Option<&IndexKey>) -> Result<u64, PhobosError> {
        let i = match key {
            Some(key) => self.lower_bound(key, false)?,
            None => 0,
        };
        let offset = if i == 0 {
            NODE_HEADER
        } else {
            self.key_end(i - 1).1
        };
        Ok(u64::from_le_bytes(
            self.page[offset..offset + 8].try_into().expect("child"),
        ))
    }
    #[must_use]
    pub fn version(&self) -> u16 {
        self.version
    }
    /// Raw encoded key bytes of entry `i` (current format: memcomparable).
    pub fn key_bytes(&self, i: usize) -> &'a [u8] {
        let (start, end) = self.key_end(i);
        &self.page[start..end]
    }
    /// Byte offset of entry `i` (its key-length prefix).
    pub fn entry_offset(&self, i: usize) -> usize {
        usize::from(self.offsets[i])
    }
    /// RecordId of leaf entry `i`.
    pub fn leaf_rid(&self, i: usize) -> RecordId {
        let (_, end) = self.key_end(i);
        RecordId {
            page_id: u64::from_le_bytes(self.page[end..end + 8].try_into().expect("rid")),
            slot_id: u16::from_le_bytes(self.page[end + 8..end + 10].try_into().expect("slot")),
        }
    }
    /// Child pointer following entry `i - 1` (`first_child` for 0).
    pub fn child_at(&self, i: usize) -> u64 {
        let offset = if i == 0 {
            NODE_HEADER
        } else {
            self.key_end(i - 1).1
        };
        u64::from_le_bytes(self.page[offset..offset + 8].try_into().expect("child"))
    }
    /// First entry whose key bytes are >= `encoded` (memcomparable order,
    /// current format only; the view must have been built validated).
    pub fn lower_bound_bytes(&self, encoded: &[u8]) -> usize {
        let (mut lo, mut hi) = (0, self.count);
        while lo < hi {
            let mid = lo + (hi - lo) / 2;
            if self.key_bytes(mid) < encoded {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        lo
    }
    pub fn entry(&self, i: usize) -> Result<LeafEntry, PhobosError> {
        let (start, end) = self.key_end(i);
        Ok(LeafEntry {
            key: decode_key_version(&self.page[start..end], self.version)?,
            rid: RecordId {
                page_id: u64::from_le_bytes(self.page[end..end + 8].try_into().expect("rid")),
                slot_id: u16::from_le_bytes(self.page[end + 8..end + 10].try_into().expect("slot")),
            },
        })
    }
}

// Scalars use the original comparator; variable-length values remain borrowed.
// Parsing the entire key also retains the old decoder's malformed-key checks.
fn visit_key(
    bytes: &[u8],
    target: Option<&IndexKey>,
    version: u16,
) -> Result<Ordering, PhobosError> {
    if version == FORMAT_VERSION {
        let decoded = decode_key(bytes)?;
        return match target {
            Some(target) => Ok(bytes.cmp(&encode_key(target)?)),
            None => Ok({
                drop(decoded);
                Ordering::Equal
            }),
        };
    }
    let mut cursor = 0;
    let count = usize::from(take_u16(bytes, &mut cursor)?);
    let mut order = Ordering::Equal;
    for i in 0..count {
        let tag = take_u8(bytes, &mut cursor)?;
        let right = target.and_then(|key| key.0.get(i));
        let cmp = if tag == 4 || tag == 5 {
            let data = take_sized(bytes, &mut cursor)?;
            if tag == 4 {
                std::str::from_utf8(data)
                    .map_err(|_| index_error("index text key is not UTF-8"))?;
            }
            match right {
                Some(Value::Null) => Ordering::Less,
                Some(Value::Text(text)) if tag == 4 => data.cmp(text.as_bytes()),
                Some(Value::Binary(binary)) if tag == 5 => data.cmp(binary),
                Some(other) => tag.cmp(&value_tag(other)),
                None => Ordering::Equal,
            }
        } else {
            let left = match tag {
                0 => Value::Null,
                1 => Value::Boolean(take_u8(bytes, &mut cursor)? != 0),
                2 => Value::Int64(i64::from_le_bytes(take_array(bytes, &mut cursor)?)),
                3 => Value::Float64(f64::from_bits(u64::from_le_bytes(take_array(
                    bytes,
                    &mut cursor,
                )?))),
                6 => Value::Date(i32::from_le_bytes(take_array(bytes, &mut cursor)?)),
                7 => Value::Timestamp(i64::from_le_bytes(take_array(bytes, &mut cursor)?)),
                8 => Value::Decimal {
                    unscaled: i128::from_le_bytes(take_array(bytes, &mut cursor)?),
                    scale: take_u8(bytes, &mut cursor)?,
                },
                _ => return Err(index_error("unknown index key value tag")),
            };
            right.map_or(Ordering::Equal, |right| compare_value(&left, right))
        };
        if order == Ordering::Equal {
            order = cmp;
        }
    }
    if cursor != bytes.len() {
        return Err(index_error("index key contains trailing bytes"));
    }
    Ok(order.then_with(|| target.map_or(Ordering::Equal, |key| count.cmp(&key.0.len()))))
}
