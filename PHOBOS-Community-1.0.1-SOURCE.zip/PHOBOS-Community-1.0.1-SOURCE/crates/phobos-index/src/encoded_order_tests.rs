//! 0.2-H Part J: the V3 key encoding is memcomparable. For every pair of keys
//! the typed comparator (`IndexKey::cmp` → `compare_key`) and the byte order
//! of the encodings agree. Batch DML V2 sorts and merges encoded keys, so
//! this equivalence is its correctness precondition.
use super::*;

/// Small deterministic generator (no dependency).
struct Lcg(u64);
impl Lcg {
    fn next(&mut self) -> u64 {
        self.0 = self
            .0
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        self.0 >> 11
    }
    fn pick<T: Clone>(&mut self, items: &[T]) -> T {
        items[(self.next() % items.len() as u64) as usize].clone()
    }
}

fn int_value(rng: &mut Lcg) -> Value {
    let edge = [
        i64::MIN,
        i64::MIN + 1,
        -1,
        0,
        1,
        i64::MAX - 1,
        i64::MAX,
        -256,
        255,
        256,
    ];
    if rng.next() % 3 == 0 {
        Value::Int64(rng.pick(&edge))
    } else {
        Value::Int64(rng.next() as i64 - (1 << 52))
    }
}
fn text_value(rng: &mut Lcg) -> Value {
    let edge = [
        "", "a", "ab", "abc", "a\0", "a\0b", "\0", "\0\0", "b", "aa", "a\u{ff}", "é", "z", "A",
    ];
    if rng.next() % 2 == 0 {
        return Value::Text(rng.pick(&edge).to_string());
    }
    let len = (rng.next() % 6) as usize;
    let alphabet = ['\0', 'a', 'b', 'é', '\u{7f}', 'Z'];
    Value::Text((0..len).map(|_| rng.pick(&alphabet)).collect())
}
fn value_of(kind: u8, rng: &mut Lcg) -> Value {
    if rng.next() % 9 == 0 {
        return Value::Null;
    }
    match kind {
        0 => int_value(rng),
        1 => text_value(rng),
        2 => Value::Boolean(rng.next() % 2 == 0),
        3 => {
            let edge = [
                0.0,
                -0.0,
                1.5,
                -1.5,
                f64::MIN,
                f64::MAX,
                f64::INFINITY,
                f64::NEG_INFINITY,
                1e-300,
                -1e-300,
            ];
            Value::Float64(if rng.next() % 2 == 0 {
                rng.pick(&edge)
            } else {
                (rng.next() as f64 - 1e15) / 7.0
            })
        }
        4 => Value::Date(rng.pick(&[i32::MIN, -1, 0, 1, i32::MAX]) ^ (rng.next() as i32 & 0xff)),
        5 => Value::Timestamp(
            rng.pick(&[i64::MIN, -1, 0, 1, i64::MAX]) ^ (rng.next() as i64 & 0xffff),
        ),
        6 => Value::Decimal {
            unscaled: rng.pick(&[i128::MIN, -1, 0, 1, i128::MAX]) ^ i128::from(rng.next() as u16),
            scale: 2,
        },
        _ => {
            let len = (rng.next() % 5) as usize;
            Value::Binary((0..len).map(|_| rng.pick(&[0u8, 1, 0xff, 0x80])).collect())
        }
    }
}

fn agree(a: &IndexKey, b: &IndexKey) {
    let typed = a.cmp(b);
    let encoded = encode_key(a).unwrap().cmp(&encode_key(b).unwrap());
    assert_eq!(
        typed, encoded,
        "typed vs encoded order differ for {a:?} / {b:?}"
    );
}

#[test]
fn h_encoded_order_matches_typed_order_for_every_declared_key_type() {
    let mut rng = Lcg(0x5eed_0002_0048);
    // Single-column keys of each declared type, composite keys of mixed
    // declared types (as an index declares them), equal keys and prefixes.
    let layouts: [&[u8]; 12] = [
        &[0],
        &[1],
        &[2],
        &[3],
        &[4],
        &[5],
        &[6],
        &[7],
        &[0, 0],
        &[0, 1],
        &[1, 0, 2],
        &[1, 1],
    ];
    for layout in layouts {
        let keys: Vec<IndexKey> = (0..300)
            .map(|_| {
                IndexKey(
                    layout
                        .iter()
                        .map(|kind| value_of(*kind, &mut rng))
                        .collect(),
                )
            })
            .collect();
        for a in &keys {
            agree(a, a);
            for _ in 0..20 {
                agree(a, &keys[(rng.next() % keys.len() as u64) as usize]);
            }
        }
        // Sorting by bytes and by type yields the same sequence.
        let mut typed = keys.clone();
        typed.sort();
        let mut encoded = keys.clone();
        encoded.sort_by_key(|key| encode_key(key).unwrap());
        for (x, y) in typed.iter().zip(&encoded) {
            assert_eq!(x.cmp(y), Ordering::Equal);
        }
    }
}

#[test]
fn h_encoded_order_edge_cases() {
    let k = |values: Vec<Value>| IndexKey(values);
    let cases = vec![
        k(vec![Value::Int64(i64::MIN)]),
        k(vec![Value::Int64(-1)]),
        k(vec![Value::Int64(0)]),
        k(vec![Value::Int64(i64::MAX)]),
        k(vec![Value::Null]),
        k(vec![Value::Text(String::new())]),
        k(vec![Value::Text("a".into())]),
        k(vec![Value::Text("a\0".into())]),
        k(vec![Value::Text("a\0\0".into())]),
        k(vec![Value::Text("ab".into())]),
        k(vec![Value::Text("a".into()), Value::Int64(5)]),
        k(vec![Value::Text("a".into()), Value::Null]),
        k(vec![Value::Text("ab".into()), Value::Int64(i64::MIN)]),
        k(vec![Value::Float64(-0.0)]),
        k(vec![Value::Float64(0.0)]),
        k(vec![Value::Float64(f64::NEG_INFINITY)]),
        k(vec![Value::Float64(f64::INFINITY)]),
        k(vec![Value::Decimal {
            unscaled: -5,
            scale: 2,
        }]),
        k(vec![Value::Decimal {
            unscaled: 5,
            scale: 2,
        }]),
    ];
    for a in &cases {
        for b in &cases {
            // Mixed declared types (e.g. Int64 vs Text in one column) are
            // compared by type tag in both orders; included here as well.
            agree(a, b);
        }
    }
}

#[test]
fn h_encoded_key_len_equals_encoding_length() {
    let mut rng = Lcg(77);
    for kind in 0..8u8 {
        for _ in 0..500 {
            let key = IndexKey(vec![
                value_of(kind, &mut rng),
                value_of((kind + 1) % 8, &mut rng),
            ]);
            assert_eq!(encoded_key_len(&key), encode_key(&key).unwrap().len());
        }
    }
}
