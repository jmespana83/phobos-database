//! 0.2-K Part L: batch reclaim pruning (`delete_versions_sorted`, cursor
//! descent through the zero-copy view, in-place leaf removal) produces
//! exactly the pages the per-entry decoded path (`delete_version`) produces.
use super::*;
use phobos_storage::committed_pages::{CommittedStore, FlushConfig};
use phobos_wal::v2::{FileId, PageAction, Wal};
use std::{fs, path::Path, sync::Arc};

fn root(name: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "phobos-0-2-k-prune-{name}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ))
}
fn key(id: u64) -> IndexKey {
    // Even ids share 5 keys (long duplicate runs across leaves); odd ids are
    // distinct keys.
    let value = if id % 2 == 0 { id % 5 } else { 1_000_000 + id };
    IndexKey(vec![Value::Text(format!("{value:08}{}", "x".repeat(24)))])
}
fn rid(id: u64) -> RecordId {
    RecordId {
        page_id: id / 50 + 1,
        slot_id: (id % 50) as u16,
    }
}
fn setup(name: &str) -> (PathBuf, Wal, Arc<CommittedStore>, BPlusTree) {
    let dir = root(name);
    let wal = Wal::create_with_versioned_heap(&dir).unwrap();
    let dir = fs::canonicalize(dir).unwrap();
    let store = CommittedStore::new(&dir, FlushConfig::default()).unwrap();
    let mut tree = BPlusTree::open(dir.join(FileId::Index(1).name()), false, 1).unwrap();
    tree.attach_committed(&store, FileId::Index(1)).unwrap();
    (dir, wal, store, tree)
}
fn publish(tree: &mut BPlusTree, wal: &mut Wal, root: &Path, stable: u64, ids: &[u64]) {
    tree.begin_private(&root.join(format!("private-{stable}")), stable, root)
        .unwrap();
    for id in ids {
        tree.insert_version(key(*id), rid(*id), stable).unwrap();
    }
    wal.begin_mvcc(stable).unwrap();
    tree.prepare_private_redo(FileId::Index(1), |page, bytes, allocated| {
        wal.append_page(
            if allocated {
                PageAction::Initialize
            } else {
                PageAction::Index
            },
            FileId::Index(1),
            page,
            bytes,
        )?;
        Ok(())
    })
    .unwrap();
    tree.stage_private().unwrap();
    let receipt = wal.commit().unwrap();
    tree.install_pending(&receipt).unwrap();
}

#[test]
fn k_batch_pruning_equals_per_entry_pruning_page_for_page() {
    let ids = (0..6000u64).collect::<Vec<_>>();
    let mut trees = Vec::new();
    for name in ["batch", "single"] {
        let (dir, mut wal, store, mut tree) = setup(name);
        publish(&mut tree, &mut wal, &dir, 1, &ids);
        trees.push((dir, wal, store, tree));
    }
    // Every third version is dead, plus whole runs of some leaves (empty
    // leaves are detached through the cursor path).
    let mut dead = ids
        .iter()
        .filter(|id| *id % 3 == 0 || (2000..2600).contains(*id))
        .map(|id| (key(*id), rid(*id)))
        .collect::<Vec<_>>();
    dead.sort();
    let mut results = Vec::new();
    for (index, (dir, _, _, tree)) in trees.iter_mut().enumerate() {
        tree.begin_private(&dir.join("private-2"), 2, dir).unwrap();
        let removed = if index == 0 {
            tree.delete_versions_sorted(&dead, 2).unwrap()
        } else {
            dead.iter()
                .map(|(k, r)| tree.delete_version(k, *r, 2).unwrap().0)
                .collect()
        };
        assert!(
            removed.iter().all(|removed| *removed),
            "every dead entry is found"
        );
        results.push(tree.next_page);
    }
    assert_eq!(results[0], results[1]);
    let (left, right) = trees.split_at_mut(1);
    let (a, b) = (&mut left[0].3, &mut right[0].3);
    assert_eq!(a.root_page, b.root_page);
    assert_eq!(a.free_head, b.free_head);
    for page in 1..a.next_page {
        let (x, _) = a.file.read_trusted(page).unwrap();
        let (y, _) = b.file.read_trusted(page).unwrap();
        let diff = (0..INDEX_PAGE_SIZE)
            .filter(|i| x[*i] != y[*i])
            .take(12)
            .map(|i| (i, x[i], y[i]))
            .collect::<Vec<_>>();
        assert!(
            diff.is_empty(),
            "page {page} kind {} differs at {diff:?}",
            x[6]
        );
    }
    // The surviving entries are exactly the live versions.
    let survivors = a
        .range(Bound::Unbounded, Bound::Unbounded)
        .unwrap()
        .into_iter()
        .collect::<std::collections::BTreeSet<_>>();
    let expected = ids
        .iter()
        .filter(|id| !(*id % 3 == 0 || (2000..2600).contains(*id)))
        .map(|id| rid(*id))
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(survivors, expected);
    for (dir, wal, store, mut tree) in trees {
        tree.rollback_private().unwrap();
        tree.force_committed().unwrap();
        store.stop().unwrap();
        drop(tree);
        drop(store);
        drop(wal);
        fs::remove_dir_all(dir).unwrap();
    }
}
