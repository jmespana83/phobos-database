//! C8 bulk-only page coalescing; existing entry/split semantics and page format.
use super::*;
use crate::node_view::NodeView;
use std::collections::BTreeMap;

#[derive(Debug, Default)]
pub(super) struct Cache {
    pub nodes: BTreeMap<u64, (Node, bool)>,
    pub meta_dirty: bool,
    /// 0.2-F: encoded length of cached leaves maintained by
    /// `insert_cached_entry` (entry removed whenever the node is replaced),
    /// instead of re-summing every entry after each insert.
    pub lengths: BTreeMap<u64, usize>,
}
impl BPlusTree {
    /// Bounded batch for scratch uniqueness trees. On error the owning import
    /// must abort; like repeated insert, a prefix may exist in private/scratch state.
    pub fn insert_batch(&mut self, entries: Vec<(IndexKey, RecordId)>) -> Result<(), PhobosError> {
        self.batch_entries(entries, true)
    }
    /// MVCC bulk publisher only; caller retains C7 table ownership and has checked
    /// logical uniqueness. Only the matching private page owner may use this API.
    pub fn insert_versions_batch(
        &mut self,
        entries: Vec<(IndexKey, RecordId)>,
        stable: u64,
    ) -> Result<(), PhobosError> {
        if self.file.private_owner()? != stable {
            return Err(index_error("index batch/private owner mismatch"));
        }
        if encoded_batch_enabled() {
            return self.batch_entries_encoded(entries);
        }
        self.batch_entries(entries, false)
    }
    /// 0.2-H Batch DML V2 (MVCC index maintenance, no uniqueness enforcement
    /// here — the final UNIQUE recheck is the authority, as before).
    ///
    /// Same result as `batch_entries(entries, false)` — the same sorted
    /// order, the same target leaf per key, the same duplicate-chain rule,
    /// the same positions, the same split points and page images — but:
    /// * every key is encoded once (one arena), validated from its encoding,
    ///   and sorted by its memcomparable bytes (equal to `IndexKey` order,
    ///   `encoded_order_tests`);
    /// * consecutive keys that fall into one leaf are merged into that leaf's
    ///   encoded entries in one pass (no decode of the leaf's existing keys,
    ///   no per-key `Vec::insert`, one page encode + checksum per leaf);
    /// * validated internal pages are reused while no structural change
    ///   happened inside this batch (descent prefix reuse; never across
    ///   batches or publications).
    ///
    /// Any key that could involve a split, a duplicate chain crossing a leaf
    /// boundary, or a legacy-format page takes the typed path
    /// (`insert_cached_entry`) for that key only, after the merged leaf was
    /// written; the typed cache is flushed before the next merge.
    fn batch_entries_encoded(
        &mut self,
        entries: Vec<(IndexKey, RecordId)>,
    ) -> Result<(), PhobosError> {
        self.file.ensure_writable()?;
        if entries.len() > 1024 || self.batch.is_some() {
            return Err(index_error("index batch limit or nested batch"));
        }
        let columns = usize::from(self.key_columns);
        let mut arena = Vec::with_capacity(entries.len() * 24);
        let mut spans = Vec::with_capacity(entries.len());
        {
            let _encode = phobos_observability::span("index.batch_v2_encode");
            for (key, _) in &entries {
                if key.0.len() != columns {
                    return Err(index_error("index key column count mismatch"));
                }
                let start = arena.len();
                encode_key_into(key, &mut arena)?;
                if arena.len() - start > MAX_KEY_BYTES {
                    return Err(PhobosError::new(
                        ErrorCode::ConstraintViolation,
                        "index key exceeds Phase 4 maximum encoded size",
                    ));
                }
                spans.push((start, arena.len()));
            }
        }
        let key = |index: usize| &arena[spans[index].0..spans[index].1];
        let mut order = (0..entries.len()).collect::<Vec<_>>();
        order.sort_by(|a, b| {
            key(*a)
                .cmp(key(*b))
                .then_with(|| entries[*a].1.cmp(&entries[*b].1))
        });
        self.batch = Some(Cache::default());
        let mut internals: BTreeMap<u64, PageRef> = BTreeMap::new();
        let result = (|| {
            let mut i = 0;
            while i < order.len() {
                if !self.batch.as_ref().expect("active batch").nodes.is_empty() {
                    self.flush_batch_nodes()?;
                }
                let Some((leaf_id, leaf, trusted, fence)) =
                    self.encoded_descent(key(order[i]), &mut internals)?
                else {
                    // Legacy-format node on the path: typed path for this key.
                    let (typed_key, rid) = &entries[order[i]];
                    self.insert_cached_entry(typed_key.clone(), *rid)?;
                    internals.clear();
                    i += 1;
                    continue;
                };
                let view = if trusted {
                    NodeView::new_trusted(&leaf, leaf_id)?
                } else {
                    NodeView::new(&leaf, leaf_id)?
                };
                let mut used = usize::from(u16::from_le_bytes([leaf[34], leaf[35]]));
                let last = view.count.checked_sub(1).map(|index| view.key_bytes(index));
                let mut merged: Vec<usize> = Vec::new();
                let mut typed = None;
                let mut j = i;
                while j < order.len() {
                    let index = order[j];
                    let bytes = key(index);
                    let rid = entries[index].1;
                    match fence.as_deref().map(|fence| bytes.cmp(fence)) {
                        Some(Ordering::Greater) => break,
                        Some(Ordering::Equal) => {
                            // A duplicate chain may continue in the next leaf.
                            typed = Some(j);
                            break;
                        }
                        _ => {}
                    }
                    if fence.is_none()
                        && view.next != NONE_PAGE
                        && last.is_none_or(|last| bytes >= last)
                    {
                        typed = Some(j);
                        break;
                    }
                    // The exact physical entry may already exist (repeat).
                    let mut exact = false;
                    let mut at = view.lower_bound_bytes(bytes);
                    while at < view.count && view.key_bytes(at) == bytes {
                        if view.leaf_rid(at) == rid {
                            exact = true;
                            break;
                        }
                        at += 1;
                    }
                    let duplicate_in_batch = merged.last().is_some_and(|previous| {
                        key(order[*previous]) == bytes && entries[order[*previous]].1 == rid
                    });
                    if exact || duplicate_in_batch {
                        j += 1;
                        continue;
                    }
                    let needed = 2 + bytes.len() + 10;
                    if used + needed > INDEX_PAGE_SIZE {
                        typed = Some(j);
                        break;
                    }
                    used += needed;
                    merged.push(j);
                    j += 1;
                }
                if !merged.is_empty() {
                    let page = merge_leaf(
                        &leaf,
                        &view,
                        leaf_id,
                        used,
                        merged.iter().map(|j| {
                            let index = order[*j];
                            (key(index), entries[index].1)
                        }),
                    )?;
                    write_page(&mut self.file, leaf_id, &page)?;
                    phobos_observability::event("index.batch_v2_leaf_merges", 1);
                    phobos_observability::event(
                        "index.batch_v2_merged_entries",
                        merged.len() as u64,
                    );
                    phobos_observability::certification_crash("during_index_update");
                }
                i = j;
                if let Some(position) = typed {
                    let (typed_key, rid) = &entries[order[position]];
                    phobos_observability::event("index.batch_v2_typed_entries", 1);
                    self.insert_cached_entry(typed_key.clone(), *rid)?;
                    // A split may have rewritten internal nodes.
                    internals.clear();
                    i = position + 1;
                }
            }
            Ok(())
        })();
        let flush = self.flush_batch_nodes();
        let cache = self.batch.take().expect("active batch");
        let meta = if cache.meta_dirty {
            self.write_meta()
        } else {
            Ok(())
        };
        result.and(flush).and(meta)
    }
    /// Root-to-leaf descent over validated encoded pages for `key`: the leaf
    /// id, its image, and the tightest separator >= key on the path (the
    /// leaf receives keys <= that fence). `None` for a legacy-format node.
    ///
    /// Committed-store images were fully validated when they entered the
    /// store and are read shared and trusted (0.2-F rule); private and pending
    /// images are fully validated here.
    #[allow(clippy::type_complexity)]
    fn encoded_descent(
        &mut self,
        key: &[u8],
        internals: &mut BTreeMap<u64, PageRef>,
    ) -> Result<Option<(u64, PageRef, bool, Option<Vec<u8>>)>, PhobosError> {
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        let mut fence: Option<Vec<u8>> = None;
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            if page_id == 0 || page_id >= self.next_page {
                return Err(index_error("index page identifier is out of range"));
            }
            if let Some(image) = internals.get(&page_id) {
                // Validated when first read in this batch; unchanged since.
                let view = NodeView::new_trusted(image, page_id)?;
                let below = view.lower_bound_bytes(key);
                if below < view.count {
                    fence = Some(view.key_bytes(below).to_vec());
                }
                page_id = view.child_at(below);
                continue;
            }
            let (image, trusted) = read_page_ref(&mut self.file, page_id)?;
            let view = if trusted {
                NodeView::new_trusted(&image, page_id)?
            } else {
                NodeView::new(&image, page_id)?
            };
            if view.version() != FORMAT_VERSION {
                return Ok(None);
            }
            if view.kind == NodeKind::Leaf {
                return Ok(Some((page_id, image, trusted, fence)));
            }
            let below = view.lower_bound_bytes(key);
            if below < view.count {
                fence = Some(view.key_bytes(below).to_vec());
            }
            let child = view.child_at(below);
            internals.insert(page_id, image);
            page_id = child;
        }
    }
    fn batch_entries(
        &mut self,
        mut entries: Vec<(IndexKey, RecordId)>,
        enforce_unique: bool,
    ) -> Result<(), PhobosError> {
        self.file.ensure_writable()?;
        if entries.len() > 1024 || self.batch.is_some() {
            return Err(index_error("index batch limit or nested batch"));
        }
        for (key, _) in &entries {
            self.validate_key(key)?;
        }
        entries.sort_by(|(a, ar), (b, br)| {
            a.cmp(b)
                .then_with(|| ar.page_id.cmp(&br.page_id))
                .then_with(|| ar.slot_id.cmp(&br.slot_id))
        });
        self.batch = Some(Cache::default());
        let result = entries.into_iter().try_for_each(|(key, rid)| {
            if enforce_unique {
                self.insert_entry(key, rid, true)
            } else {
                self.insert_cached_entry(key, rid)
            }
        });
        // Always close the batch, including constraint errors. Physical writes
        // stay in the existing private PageIo or disposable uniqueness scratch.
        let flush = self.flush_batch_nodes();
        let cache = self.batch.take().expect("active batch");
        let meta = if cache.meta_dirty {
            self.write_meta()
        } else {
            Ok(())
        };
        result.and(flush).and(meta)
    }
    /// Decode `page_id` into the batch cache if absent. References into the
    /// cache must not be held across this call (it may flush the cache).
    fn ensure_cached(&mut self, page_id: u64) -> Result<(), PhobosError> {
        if page_id == 0 || page_id >= self.next_page {
            return Err(index_error("index page identifier is out of range"));
        }
        if self
            .batch
            .as_ref()
            .expect("active batch")
            .nodes
            .contains_key(&page_id)
        {
            return Ok(());
        }
        let bytes = read_page(&mut self.file, page_id)?;
        let node = decode_node(&bytes, page_id)?;
        self.cache_node(node, false)
    }

    fn cached(&self, page_id: u64) -> &Node {
        &self.batch.as_ref().expect("active batch").nodes[&page_id].0
    }

    /// 0.2-B: `insert_entry(key, rid, false)` performed on the batch cache in
    /// place. Same descent, same duplicate-chain probe, same placement and
    /// page-size rule; nodes are not cloned per row. Splits use the generic
    /// `split_leaf`.
    fn insert_cached_entry(&mut self, key: IndexKey, rid: RecordId) -> Result<(), PhobosError> {
        self.file.ensure_writable()?;
        self.validate_key(&key)?;
        let mut page_id = self.root_page;
        let mut remaining = self.next_page;
        let mut path = Vec::new();
        loop {
            remaining = remaining
                .checked_sub(1)
                .ok_or_else(|| index_error("index descent exceeded page bound"))?;
            self.ensure_cached(page_id)?;
            let node = self.cached(page_id);
            match node.kind {
                NodeKind::Leaf => break,
                NodeKind::Internal => {
                    // 0.2-C: binary form of the generic rule (the child of
                    // the last entry whose key is < target), over the sorted
                    // separator keys every descent already relies on.
                    let below = node.internal.partition_point(|entry| entry.key < key);
                    let child = match below {
                        0 => node.first_child,
                        n => node.internal[n - 1].child,
                    };
                    path.push(node.id);
                    page_id = child;
                }
            }
        }
        let leaf_id = page_id;
        {
            let _probe = phobos_observability::span("index.insert_probe");
            let mut current = leaf_id;
            loop {
                self.ensure_cached(current)?;
                let node = self.cached(current);
                if node.kind != NodeKind::Leaf {
                    return Err(index_error("leaf chain points to an internal node"));
                }
                let mut past_key = false;
                // 0.2-C: entries below the key are skipped by binary search
                // over the sorted leaf instead of one comparison each.
                let start = node.leaf.partition_point(|entry| entry.key < key);
                for entry in &node.leaf[start..] {
                    match entry.key.cmp(&key) {
                        Ordering::Less => {}
                        Ordering::Equal => {
                            if entry.rid == rid {
                                // The exact physical entry already exists.
                                return Ok(());
                            }
                        }
                        Ordering::Greater => {
                            past_key = true;
                            break;
                        }
                    }
                }
                if past_key || node.next_leaf == NONE_PAGE {
                    break;
                }
                current = node.next_leaf;
            }
        }
        // The probe may have flushed the cache; reload the descended leaf.
        self.ensure_cached(leaf_id)?;
        let batch = self.batch.as_mut().expect("active batch");
        let Cache { nodes, lengths, .. } = batch;
        let (leaf, dirty) = nodes.get_mut(&leaf_id).expect("cached leaf");
        let position = match leaf
            .leaf
            .binary_search_by(|entry| compare_entry(entry, &key, rid))
        {
            Ok(_) => return Ok(()),
            Err(position) => position,
        };
        let before = match lengths.get(&leaf_id) {
            Some(length) => *length,
            None => leaf.encoded_len()?,
        };
        let length = before
            .checked_add(2 + encoded_key_len(&key) + 8 + 2)
            .ok_or_else(|| index_error("index node length overflow"))?;
        leaf.leaf.insert(position, LeafEntry { key, rid });
        debug_assert_eq!(Some(length), leaf.encoded_len().ok());
        if length <= INDEX_PAGE_SIZE {
            lengths.insert(leaf_id, length);
            *dirty = true;
            phobos_observability::certification_crash("during_index_update");
            return Ok(());
        }
        lengths.remove(&leaf_id);
        // Oversized: hand the owned leaf to the generic split, which rewrites
        // it (dirty) before any cache flush can occur.
        let (leaf, _) = batch.nodes.remove(&leaf_id).expect("cached leaf");
        self.split_leaf(leaf, path)
    }

    pub(super) fn cache_node(&mut self, node: Node, dirty: bool) -> Result<(), PhobosError> {
        let cache = self.batch.as_ref().expect("active batch");
        if cache.nodes.len() == 64 && !cache.nodes.contains_key(&node.id) {
            self.flush_batch_nodes()?;
        }
        let cache = self.batch.as_mut().expect("active batch");
        let dirty = dirty || cache.nodes.get(&node.id).is_some_and(|entry| entry.1);
        cache.lengths.remove(&node.id);
        cache.nodes.insert(node.id, (node, dirty));
        Ok(())
    }
    fn flush_batch_nodes(&mut self) -> Result<(), PhobosError> {
        let batch = self.batch.as_mut().expect("active batch");
        batch.lengths.clear();
        let nodes = std::mem::take(&mut batch.nodes);
        // Page-ID order preserves sequential allocation even for plain scratch
        // files; newly allocated pages must never be flushed across a file gap.
        for (id, (node, dirty)) in nodes {
            if dirty {
                write_page(&mut self.file, id, &encode_node(&node)?)?;
                phobos_observability::event("index.batch_page_writes", 1);
            }
        }
        Ok(())
    }
}

/// `PHOBOS_INDEX_BATCH=typed` keeps the 0.2-G typed batch path (A/B switch).
fn encoded_batch_enabled() -> bool {
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ENABLED
        .get_or_init(|| std::env::var("PHOBOS_INDEX_BATCH").map_or(true, |value| value != "typed"))
}

/// Builds the leaf page that `encode_node` would produce after inserting the
/// sorted `incoming` entries into `view` (current format): existing encoded
/// entries and incoming ones merged by (key bytes, rid) — the order
/// `compare_entry` maintains — with the same header rules (parent field
/// reset, CRC32C scheme, zero tail, checksum).
fn merge_leaf<'k>(
    image: &[u8; INDEX_PAGE_SIZE],
    view: &NodeView<'_>,
    id: u64,
    used: usize,
    incoming: impl Iterator<Item = (&'k [u8], RecordId)>,
) -> Result<[u8; INDEX_PAGE_SIZE], PhobosError> {
    let _measurement = phobos_observability::span("index.batch_v2_merge");
    let mut page = [0u8; INDEX_PAGE_SIZE];
    page[0..4].copy_from_slice(&NODE_MAGIC);
    page[4..6].copy_from_slice(&FORMAT_VERSION.to_le_bytes());
    page[6] = 1;
    page[7] = phobos_wal::page_checksum::CRC32C;
    page[8..16].copy_from_slice(&id.to_le_bytes());
    page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
    page[24..32].copy_from_slice(&view.next.to_le_bytes());
    let mut cursor = NODE_HEADER;
    let mut count = 0usize;
    let mut existing = 0usize;
    let put_existing = |page: &mut [u8; INDEX_PAGE_SIZE], cursor: &mut usize, at: usize| {
        let start = view.entry_offset(at);
        let len = 2 + view.key_bytes(at).len() + 10;
        page[*cursor..*cursor + len].copy_from_slice(&image[start..start + len]);
        *cursor += len;
    };
    for (key, rid) in incoming {
        while existing < view.count
            && view
                .key_bytes(existing)
                .cmp(key)
                .then_with(|| view.leaf_rid(existing).cmp(&rid))
                == Ordering::Less
        {
            put_existing(&mut page, &mut cursor, existing);
            existing += 1;
            count += 1;
        }
        let len = u16::try_from(key.len()).map_err(|_| index_error("index key too large"))?;
        if cursor + 2 + key.len() + 10 > INDEX_PAGE_SIZE {
            return Err(index_error("index leaf node exceeds page size"));
        }
        page[cursor..cursor + 2].copy_from_slice(&len.to_le_bytes());
        cursor += 2;
        page[cursor..cursor + key.len()].copy_from_slice(key);
        cursor += key.len();
        page[cursor..cursor + 8].copy_from_slice(&rid.page_id.to_le_bytes());
        page[cursor + 8..cursor + 10].copy_from_slice(&rid.slot_id.to_le_bytes());
        cursor += 10;
        count += 1;
    }
    while existing < view.count {
        put_existing(&mut page, &mut cursor, existing);
        existing += 1;
        count += 1;
    }
    if cursor != used {
        return Err(index_error("index batch merge length mismatch"));
    }
    let count = u16::try_from(count).map_err(|_| index_error("too many index node entries"))?;
    page[32..34].copy_from_slice(&count.to_le_bytes());
    page[34..36].copy_from_slice(&(cursor as u16).to_le_bytes());
    let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
    page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4].copy_from_slice(&checksum.to_le_bytes());
    Ok(page)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn c8_batches_split_evict_preserve_duplicates_and_integrity() {
        let root = std::env::temp_dir().join(format!("phobos-c8-index-{}", std::process::id()));
        std::fs::create_dir(&root).unwrap();
        for unique in [false, true] {
            let path = root.join(if unique { "unique" } else { "plain" });
            let mut tree = BPlusTree::open(&path, unique, 2).unwrap();
            // Wide keys force more than 64 nodes and repeated root/internal splits.
            for start in (0..2048).step_by(512) {
                let entries = (start..start + 512)
                    .rev()
                    .map(|n| {
                        (
                            IndexKey(vec![Value::Int64(n), Value::Text("x".repeat(500))]),
                            RecordId {
                                page_id: n as u64,
                                slot_id: 0,
                            },
                        )
                    })
                    .collect();
                tree.insert_batch(entries).unwrap();
            }
            let key = IndexKey(vec![Value::Int64(5), Value::Text("x".repeat(500))]);
            let duplicate = tree.insert_batch(vec![(
                key.clone(),
                RecordId {
                    page_id: 9999,
                    slot_id: 0,
                },
            )]);
            assert_eq!(duplicate.is_err(), unique);
            assert_eq!(
                tree.point_lookup(&key).unwrap().len(),
                if unique { 1 } else { 2 }
            );
            let null = IndexKey(vec![Value::Int64(7), Value::Null]);
            tree.insert_batch(vec![
                (
                    null.clone(),
                    RecordId {
                        page_id: 3000,
                        slot_id: 0,
                    },
                ),
                (
                    null.clone(),
                    RecordId {
                        page_id: 3001,
                        slot_id: 0,
                    },
                ),
            ])
            .unwrap();
            assert_eq!(tree.point_lookup(&null).unwrap().len(), 2);
            tree.validate().unwrap();
            tree.sync().unwrap();
            drop(tree);
            let mut tree = BPlusTree::open(path, unique, 2).unwrap();
            tree.validate().unwrap();
            assert_eq!(tree.point_lookup(&null).unwrap().len(), 2);
        }
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn v2b_cached_batch_matches_row_by_row_inserts_and_key_lengths() {
        let keys = [
            IndexKey(vec![Value::Int64(-3), Value::Text("a\0b".into())]),
            IndexKey(vec![Value::Null, Value::Binary(vec![0, 1, 0])]),
            IndexKey(vec![
                Value::Boolean(true),
                Value::Float64(-0.0),
                Value::Date(-7),
                Value::Timestamp(9),
                Value::Decimal {
                    unscaled: -12,
                    scale: 2,
                },
            ]),
        ];
        for key in &keys {
            assert_eq!(encoded_key_len(key), encode_key(key).unwrap().len());
        }
        let root = std::env::temp_dir().join(format!("phobos-v2b-batch-{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let entries = |round: i64| {
            (0..700i64)
                .map(|n| {
                    let k = (n * 7919 + round) % 350;
                    (
                        IndexKey(vec![Value::Int64(k), Value::Text("y".repeat(40))]),
                        RecordId {
                            page_id: (n + round * 1000) as u64,
                            slot_id: (n % 3) as u16,
                        },
                    )
                })
                .collect::<Vec<_>>()
        };
        let mut batched = BPlusTree::open(root.join("batched"), false, 2).unwrap();
        let mut single = BPlusTree::open(root.join("single"), false, 2).unwrap();
        for round in 0..3 {
            let mut input = entries(round);
            // Exact duplicates are idempotent on both paths.
            input.push(input[5].clone());
            batched.batch_entries(input.clone(), false).unwrap();
            // The generic path in the batch's (key, rid) order: physical
            // placement of equal keys depends on insertion order.
            input.sort_by(|(a, ar), (b, br)| a.cmp(b).then_with(|| ar.cmp(br)));
            for (key, rid) in input {
                single.insert_entry(key, rid, false).unwrap();
            }
        }
        let collect = |tree: &mut BPlusTree| {
            let mut all = Vec::new();
            tree.inspect_entries(|key, rid| {
                all.push((key.clone(), rid));
                Ok(true)
            })
            .unwrap();
            all
        };
        batched.validate().unwrap();
        single.validate().unwrap();
        let (a, b) = (collect(&mut batched), collect(&mut single));
        assert_eq!(a.len(), 2100);
        assert_eq!(a, b);
        drop((batched, single));
        std::fs::remove_dir_all(root).unwrap();
    }
    /// 0.2-H Batch DML V2: for every scenario the encoded batch path and the
    /// 0.2-G typed batch path, fed the same operations on identical trees,
    /// leave byte-identical index files (same split points, same pages, same
    /// entry order) and valid trees.
    #[derive(Clone, Copy)]
    enum Shape {
        Sorted,
        Reverse,
        Random,
    }
    fn lcg(state: &mut u64) -> u64 {
        *state = state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        *state >> 11
    }
    fn batch(
        keys: &[IndexKey],
        first_rid: u64,
        shape: Shape,
        seed: u64,
    ) -> Vec<(IndexKey, RecordId)> {
        let mut entries = keys
            .iter()
            .enumerate()
            .map(|(i, key)| {
                (
                    key.clone(),
                    RecordId {
                        page_id: first_rid + i as u64 / 7,
                        slot_id: (i % 7) as u16,
                    },
                )
            })
            .collect::<Vec<_>>();
        match shape {
            Shape::Sorted => {}
            Shape::Reverse => entries.reverse(),
            Shape::Random => {
                let mut state = seed;
                for i in (1..entries.len()).rev() {
                    let j = (lcg(&mut state) % (i as u64 + 1)) as usize;
                    entries.swap(i, j);
                }
            }
        }
        entries
    }
    enum Op {
        Batch(Vec<(IndexKey, RecordId)>),
        Delete(IndexKey, RecordId),
    }
    fn run_both(name: &str, columns: usize, ops: &[Op]) -> (usize, usize) {
        let root =
            std::env::temp_dir().join(format!("phobos-h-batch-{}-{name}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).unwrap();
        let mut results = Vec::new();
        for encoded in [false, true] {
            let path = root.join(if encoded { "encoded" } else { "typed" });
            let mut tree = BPlusTree::open(&path, false, columns).unwrap();
            for op in ops {
                match op {
                    Op::Batch(entries) => {
                        if encoded {
                            tree.batch_entries_encoded(entries.clone()).unwrap();
                        } else {
                            tree.batch_entries(entries.clone(), false).unwrap();
                        }
                    }
                    Op::Delete(key, rid) => {
                        assert!(tree.delete(key, *rid).unwrap());
                    }
                }
            }
            let validation = tree.validate().unwrap();
            drop(tree);
            results.push((
                std::fs::read(&path).unwrap(),
                validation.entries,
                validation.height,
            ));
        }
        assert_eq!(results[0].1, results[1].1, "{name}: entry counts differ");
        assert!(results[0].0 == results[1].0, "{name}: index files differ");
        std::fs::remove_dir_all(root).unwrap();
        (results[1].1, results[1].2)
    }
    fn int_keys(range: std::ops::Range<i64>) -> Vec<IndexKey> {
        range.map(|n| IndexKey(vec![Value::Int64(n)])).collect()
    }
    fn wide_keys(range: std::ops::Range<i64>) -> Vec<IndexKey> {
        range
            .map(|n| {
                IndexKey(vec![
                    Value::Int64(n % 97),
                    Value::Text(format!("{n:06}{}", "w".repeat(180))),
                ])
            })
            .collect()
    }

    #[test]
    fn h_batch_v2_matches_typed_path_byte_for_byte() {
        let mut cases = 0;
        // 1 one leaf; 9 sorted / 10 reverse / 11 random input.
        for shape in [Shape::Sorted, Shape::Reverse, Shape::Random] {
            run_both(
                "one-leaf",
                1,
                &[Op::Batch(batch(&int_keys(0..40), 1, shape, 7))],
            );
            cases += 1;
        }
        // 2 adjacent leaves / 3 many leaves: build first, then batches
        // spread across the existing leaves.
        let base = int_keys(0..2000).into_iter().step_by(2).collect::<Vec<_>>();
        let spread = int_keys(0..2000)
            .into_iter()
            .skip(1)
            .step_by(2)
            .collect::<Vec<_>>();
        for shape in [Shape::Sorted, Shape::Reverse, Shape::Random] {
            let mut ops = Vec::new();
            for chunk in base.chunks(500) {
                ops.push(Op::Batch(batch(chunk, 10, Shape::Sorted, 1)));
            }
            ops.push(Op::Batch(batch(&spread[100..140], 900, shape, 3)));
            ops.push(Op::Batch(batch(&spread[..600], 1000, shape, 5)));
            let (entries, height) = run_both("many-leaves", 1, &ops);
            assert_eq!(entries, 1000 + 40 + 600);
            assert!(height >= 2);
            cases += 1;
        }
        // 4 one split / 5 repeated splits / 6 internal split / 7 root split:
        // wide composite keys (13 composite) from an empty tree.
        for shape in [Shape::Sorted, Shape::Reverse, Shape::Random] {
            let keys = wide_keys(0..3000);
            let ops = keys
                .chunks(600)
                .enumerate()
                .map(|(i, chunk)| Op::Batch(batch(chunk, 100 * i as u64 + 1, shape, i as u64)))
                .collect::<Vec<_>>();
            let (entries, height) = run_both("splits", 2, &ops);
            assert_eq!(entries, 3000);
            assert!(height >= 3, "root and internal splits must have happened");
            cases += 1;
        }
        // 12 duplicate keys: equal keys with different rids around split
        // boundaries, and an exact (key, rid) repeated inside one batch.
        let mut dup = Vec::new();
        for n in 0..900i64 {
            dup.push((
                IndexKey(vec![Value::Int64(n / 50), Value::Text("d".repeat(120))]),
                RecordId {
                    page_id: n as u64,
                    slot_id: 0,
                },
            ));
        }
        let mut repeated = dup[..300].to_vec();
        repeated.extend(dup[250..260].iter().cloned());
        run_both(
            "duplicates",
            2,
            &[
                Op::Batch(repeated),
                Op::Batch(dup[300..900].to_vec()),
                Op::Batch(dup[100..400].to_vec()),
            ],
        );
        cases += 1;
        // 8 mixed inserts / deletes (updates are delete + insert of a new
        // version): deletes between batches, then re-inserts.
        let keys = wide_keys(0..1200);
        let mut ops = vec![Op::Batch(batch(&keys[..600], 1, Shape::Random, 11))];
        let first = batch(&keys[..600], 1, Shape::Random, 11);
        for (key, rid) in first.iter().step_by(3) {
            ops.push(Op::Delete(key.clone(), *rid));
        }
        ops.push(Op::Batch(batch(&keys[600..1200], 500, Shape::Random, 13)));
        ops.push(Op::Batch(
            first
                .iter()
                .step_by(3)
                .take(300)
                .map(|(key, rid)| {
                    (
                        key.clone(),
                        RecordId {
                            page_id: rid.page_id + 10_000,
                            slot_id: rid.slot_id,
                        },
                    )
                })
                .collect(),
        ));
        run_both("mixed", 2, &ops);
        cases += 1;
        assert_eq!(cases, 11);
    }
}
