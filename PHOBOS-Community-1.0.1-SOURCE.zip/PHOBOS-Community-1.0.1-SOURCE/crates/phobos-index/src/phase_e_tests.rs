use super::*;

#[test]
fn e2_memcomparable_bytes_match_typed_canonical_order() {
    let corpora = vec![
        vec![
            Value::Int64(i64::MIN),
            Value::Int64(-1),
            Value::Int64(0),
            Value::Int64(i64::MAX),
        ],
        vec![
            Value::Float64(f64::NEG_INFINITY),
            Value::Float64(-7.5),
            Value::Float64(-0.0),
            Value::Float64(0.0),
            Value::Float64(8.25),
            Value::Float64(f64::INFINITY),
            Value::Float64(f64::NAN),
        ],
        vec![
            Value::Text("".into()),
            Value::Text("a".into()),
            Value::Text("a\0b".into()),
            Value::Text("aa".into()),
        ],
        vec![
            Value::Binary(vec![]),
            Value::Binary(vec![0]),
            Value::Binary(vec![0, 1]),
            Value::Binary(vec![1]),
        ],
        vec![Value::Boolean(false), Value::Boolean(true)],
        vec![Value::Date(i32::MIN), Value::Date(0), Value::Date(i32::MAX)],
        vec![
            Value::Timestamp(i64::MIN),
            Value::Timestamp(0),
            Value::Timestamp(i64::MAX),
        ],
        vec![
            Value::Decimal {
                unscaled: -10,
                scale: 2,
            },
            Value::Decimal {
                unscaled: 0,
                scale: 2,
            },
            Value::Decimal {
                unscaled: 10,
                scale: 2,
            },
        ],
    ];
    for values in corpora {
        for left in &values {
            for right in &values {
                let a = IndexKey(vec![left.clone(), Value::Text("suffix".into())]);
                let b = IndexKey(vec![right.clone(), Value::Text("suffix".into())]);
                assert_eq!(
                    a.cmp(&b),
                    encode_key(&a).unwrap().cmp(&encode_key(&b).unwrap())
                );
            }
        }
    }
    assert_eq!(
        encode_key(&IndexKey(vec![Value::Float64(-0.0)])).unwrap(),
        encode_key(&IndexKey(vec![Value::Float64(0.0)])).unwrap()
    );
    assert_eq!(
        encode_key(&IndexKey(vec![Value::Float64(f64::NAN)])).unwrap(),
        encode_key(&IndexKey(vec![Value::Float64(f64::from_bits(
            0xfff8_0000_0000_1234
        ))]))
        .unwrap()
    );
}
