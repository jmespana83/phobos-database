//! C9 bulk index build/merge: sorted-input leaf construction with bottom-up
//! upper levels, plus an ordered probe cursor for bulk uniqueness validation.
//! Pages use the existing node encoding, checksums and private page overlay.
use super::*;
use std::collections::VecDeque;

/// Target bytes per built page, leaving room for later OLTP inserts.
const FILL_BYTES: usize = INDEX_PAGE_SIZE / 10 * 9;
/// Retired page kind: checksummed, identified, unreachable, never decoded as a node.
pub(super) const FREE_KIND: u8 = 3;

/// Public key codec so importers can spill keys in the tree's own encoding.
pub fn encode_key_bytes(key: &IndexKey) -> Result<Vec<u8>, PhobosError> {
    encode_key(key)
}
pub fn decode_key_bytes(bytes: &[u8]) -> Result<IndexKey, PhobosError> {
    decode_key(bytes)
}
/// Physical entry order shared by leaves, the bulk merge and importers' sorts.
#[must_use]
pub fn compare_entries(a: (&IndexKey, RecordId), b: (&IndexKey, RecordId)) -> Ordering {
    a.0.cmp(b.0).then_with(|| a.1.cmp(&b.1))
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct BulkBuildReport {
    pub entries: u64,
    pub existing_entries: u64,
    pub leaves: u64,
    pub internal: u64,
    pub reused_pages: u64,
    pub allocated_pages: u64,
    pub freed_pages: u64,
    pub height: usize,
}

struct Level {
    open: Option<Node>,
    /// First key of the open node's subtree: its separator in the parent.
    first_key: Option<IndexKey>,
    open_bytes: usize,
    closed: u64,
}

struct Allocator {
    reusable: VecDeque<u64>,
    reused: u64,
    allocated: u64,
}

/// Sequential reader over the committed leaf chain, viewed through the private
/// overlay. Consumed leaf pages are released to the allocator.
struct OldChain {
    next: u64,
    current: Vec<LeafEntry>,
    position: usize,
    consumed: u64,
}

struct Builder<'a> {
    tree: &'a mut BPlusTree,
    levels: Vec<Level>,
    pending_leaf: Option<Node>,
    allocator: Allocator,
    report: BulkBuildReport,
}

impl BPlusTree {
    /// Ordered probe: `keys` must be ascending. Visits every physical entry
    /// whose key equals a probe key, as `(probe index, rid)`, in traversal
    /// order. Adjacent keys reuse the current leaf or its sibling; distant keys
    /// re-descend. Through a statement reader this runs under the committed
    /// publication epoch; the caller applies MVCC visibility.
    pub fn probe_sorted(
        &mut self,
        keys: &[IndexKey],
        mut visitor: impl FnMut(usize, RecordId) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        if keys.windows(2).any(|window| window[0] > window[1]) {
            return Err(index_error("bulk probe keys are not ascending"));
        }
        for key in keys {
            self.validate_key(key)?;
        }
        if let Some(reader) = self.reader.clone() {
            for (index, rid) in reader.probe_sorted(keys)? {
                visitor(index, rid)?;
            }
            return Ok(());
        }
        self.probe_sorted_direct(keys, visitor)
    }

    pub(super) fn probe_sorted_direct(
        &mut self,
        keys: &[IndexKey],
        mut visitor: impl FnMut(usize, RecordId) -> Result<(), PhobosError>,
    ) -> Result<(), PhobosError> {
        let Some(first) = keys.first() else {
            return Ok(());
        };
        let mut leaf = self.find_leaf_node(first)?;
        let mut position = 0usize;
        let mut descended = true;
        let mut steps = self.next_page;
        for (index, key) in keys.iter().enumerate() {
            loop {
                if leaf.kind != NodeKind::Leaf {
                    return Err(index_error("leaf chain points to an internal node"));
                }
                let mut past = false;
                while let Some(entry) = leaf.leaf.get(position) {
                    match entry.key.cmp(key) {
                        Ordering::Less => position += 1,
                        Ordering::Equal => {
                            visitor(index, entry.rid)?;
                            position += 1;
                        }
                        Ordering::Greater => {
                            past = true;
                            break;
                        }
                    }
                }
                if past || leaf.next_leaf == NONE_PAGE {
                    break;
                }
                steps = steps
                    .checked_sub(1)
                    .ok_or_else(|| index_error("index probe exceeded page bound"))?;
                // Exhausted this leaf without passing the key: equal keys may
                // continue in the sibling. A sibling entirely below the key
                // means the key is far away: re-descend once instead of walking.
                let sibling = self.read_node(leaf.next_leaf)?;
                if sibling.kind != NodeKind::Leaf {
                    return Err(index_error("leaf chain points to an internal node"));
                }
                position = 0;
                if sibling.leaf.first().is_some_and(|entry| entry.key > *key) {
                    leaf = sibling;
                    break;
                }
                if descended || sibling.leaf.last().is_none_or(|entry| entry.key >= *key) {
                    leaf = sibling;
                    continue;
                }
                leaf = self.find_leaf_node(key)?;
                descended = true;
            }
            descended = false;
        }
        Ok(())
    }

    /// Merge ascending `(key, rid)` entries into this private index by
    /// rebuilding the leaf chain sequentially and the upper levels bottom-up.
    /// Only the private page owner may call this; the committed file is never
    /// modified until the owning transaction publishes its durable images.
    pub fn bulk_merge(
        &mut self,
        stable: u64,
        entries: impl Iterator<Item = Result<(IndexKey, RecordId), PhobosError>>,
    ) -> Result<BulkBuildReport, PhobosError> {
        self.file.ensure_writable()?;
        if self.file.private_owner()? != stable {
            return Err(index_error("index bulk merge/private owner mismatch"));
        }
        if self.batch.is_some() {
            return Err(index_error("bulk merge cannot run inside a batch"));
        }
        let _cost = phobos_observability::span("bulk.leaf_build");
        let (mut old, internal) = self.open_old_chain()?;
        let mut builder = Builder {
            tree: self,
            levels: Vec::new(),
            pending_leaf: None,
            allocator: Allocator {
                reusable: internal.into_iter().collect(),
                reused: 0,
                allocated: 0,
            },
            report: BulkBuildReport::default(),
        };
        let mut entries = entries.peekable();
        let mut previous: Option<(IndexKey, RecordId)> = None;
        loop {
            let take_new = match (
                old.peek(builder.tree, &mut builder.allocator)?,
                entries.peek(),
            ) {
                (None, None) => break,
                (Some(_), None) => false,
                (None, Some(_)) | (Some(_), Some(Err(_))) => true,
                (Some(existing), Some(Ok((key, rid)))) => {
                    compare_entry(existing, key, *rid) == Ordering::Greater
                }
            };
            let (key, rid) = if take_new {
                let (key, rid) = entries.next().expect("peeked entry")?;
                builder.tree.validate_key(&key)?;
                if previous.as_ref().is_some_and(|(last_key, last_rid)| {
                    compare_entries((last_key, *last_rid), (&key, rid)) != Ordering::Less
                }) {
                    return Err(index_error("bulk merge input is not strictly ascending"));
                }
                previous = Some((key.clone(), rid));
                builder.report.entries += 1;
                (key, rid)
            } else {
                builder.report.existing_entries += 1;
                old.take()
            };
            builder.push_leaf_entry(key, rid)?;
        }
        builder.finish()
    }

    /// Collect the reusable internal pages without reading any leaf, and locate
    /// the leftmost leaf. Internal pages are released immediately: the leaf
    /// chain is followed by sibling links only.
    fn open_old_chain(&mut self) -> Result<(OldChain, Vec<u64>), PhobosError> {
        let height = self.height()?;
        let leftmost = self.leftmost_leaf()?;
        let mut internal = Vec::new();
        let mut stack = vec![(self.root_page, 1usize)];
        let mut budget = self.next_page;
        while let Some((id, depth)) = stack.pop() {
            if depth >= height {
                continue; // a leaf: reached through the chain, not read here
            }
            budget = budget
                .checked_sub(1)
                .ok_or_else(|| index_error("index traversal exceeded page bound"))?;
            let node = self.read_node(id)?;
            if node.kind != NodeKind::Internal {
                return Err(index_error("index height does not match node kinds"));
            }
            internal.push(id);
            stack.push((node.first_child, depth + 1));
            stack.extend(node.internal.iter().map(|entry| (entry.child, depth + 1)));
        }
        Ok((
            OldChain {
                next: leftmost,
                current: Vec::new(),
                position: 0,
                consumed: 0,
            },
            internal,
        ))
    }

    fn write_free_page(&mut self, id: u64) -> Result<(), PhobosError> {
        let mut page = [0u8; INDEX_PAGE_SIZE];
        page[0..4].copy_from_slice(&NODE_MAGIC);
        page[4..6].copy_from_slice(&FORMAT_VERSION.to_le_bytes());
        page[6] = FREE_KIND;
        page[7] = phobos_wal::page_checksum::CRC32C;
        page[8..16].copy_from_slice(&id.to_le_bytes());
        page[16..24].copy_from_slice(&NONE_PAGE.to_le_bytes());
        page[24..32].copy_from_slice(&NONE_PAGE.to_le_bytes());
        page[34..36].copy_from_slice(&(NODE_HEADER as u16).to_le_bytes());
        let checksum = checksum_page(&page, NODE_CHECKSUM_OFFSET);
        page[NODE_CHECKSUM_OFFSET..NODE_CHECKSUM_OFFSET + 4]
            .copy_from_slice(&checksum.to_le_bytes());
        write_page(&mut self.file, id, &page)
    }
}

/// A raw page is a retired C9 page: valid magic/checksum/identity and the
/// FREE kind. Such pages are unreachable and are never decoded as nodes.
pub(super) fn is_free_page(page: &[u8; INDEX_PAGE_SIZE], expected_id: u64) -> bool {
    page[0..4] == NODE_MAGIC
        && {
            let version = u16::from_le_bytes([page[4], page[5]]);
            version == FORMAT_VERSION || LEGACY_FORMAT_VERSIONS.contains(&version)
        }
        && page[6] == FREE_KIND
        && u64::from_le_bytes(page[8..16].try_into().expect("node id")) == expected_id
        && validate_node_checksum(page).is_ok()
}

impl OldChain {
    fn fill(&mut self, tree: &mut BPlusTree, allocator: &mut Allocator) -> Result<(), PhobosError> {
        while self.position >= self.current.len() && self.next != NONE_PAGE {
            let id = self.next;
            let node = tree.read_node(id)?;
            if node.kind != NodeKind::Leaf {
                return Err(index_error("leaf chain points to an internal node"));
            }
            self.consumed += 1;
            if self.consumed >= tree.next_page {
                return Err(index_error("index leaf traversal exceeded page bound"));
            }
            self.next = node.next_leaf;
            self.current = node.leaf;
            self.position = 0;
            // The page is fully decoded; its identity may be reused at once.
            allocator.reusable.push_back(id);
        }
        Ok(())
    }
    fn peek(
        &mut self,
        tree: &mut BPlusTree,
        allocator: &mut Allocator,
    ) -> Result<Option<&LeafEntry>, PhobosError> {
        self.fill(tree, allocator)?;
        Ok(self.current.get(self.position))
    }
    fn take(&mut self) -> (IndexKey, RecordId) {
        let entry = &self.current[self.position];
        self.position += 1;
        (entry.key.clone(), entry.rid)
    }
}

impl Allocator {
    fn allocate(&mut self, tree: &mut BPlusTree) -> Result<u64, PhobosError> {
        if let Some(id) = self.reusable.pop_front() {
            self.reused += 1;
            return Ok(id);
        }
        let id = tree.next_page;
        tree.next_page = id
            .checked_add(1)
            .ok_or_else(|| index_error("index page identifier exhausted"))?;
        self.allocated += 1;
        // Private allocations must stay contiguous; the real image follows
        // once the node's parent/sibling identities are known.
        tree.write_node(&Node::new_leaf(id, NONE_PAGE))?;
        Ok(id)
    }
}

fn leaf_entry_bytes(key: &IndexKey) -> Result<usize, PhobosError> {
    Ok(2 + encode_key(key)?.len() + 8 + 2)
}
fn internal_entry_bytes(key: &IndexKey) -> Result<usize, PhobosError> {
    Ok(2 + encode_key(key)?.len() + 8)
}

impl Builder<'_> {
    fn level(&mut self, depth: usize) -> &mut Level {
        while self.levels.len() <= depth {
            self.levels.push(Level {
                open: None,
                first_key: None,
                open_bytes: 0,
                closed: 0,
            });
        }
        &mut self.levels[depth]
    }

    fn open_leaf(&mut self) -> Result<(), PhobosError> {
        let id = self.allocator.allocate(self.tree)?;
        if let Some(mut pending) = self.pending_leaf.take() {
            pending.next_leaf = id;
            self.tree.write_node(&pending)?;
        }
        let level = self.level(0);
        level.open = Some(Node::new_leaf(id, NONE_PAGE));
        level.open_bytes = NODE_HEADER;
        Ok(())
    }

    fn push_leaf_entry(&mut self, key: IndexKey, rid: RecordId) -> Result<(), PhobosError> {
        let bytes = leaf_entry_bytes(&key)?;
        let level = self.level(0);
        if level
            .open
            .as_ref()
            .is_some_and(|node| !node.leaf.is_empty() && level.open_bytes + bytes > FILL_BYTES)
        {
            self.close_leaf(false)?;
        }
        if self.level(0).open.is_none() {
            self.open_leaf()?;
        }
        let level = self.level(0);
        level.open_bytes += bytes;
        let node = level.open.as_mut().expect("open leaf");
        if node.leaf.is_empty() {
            level.first_key = Some(key.clone());
        }
        node.leaf.push(LeafEntry { key, rid });
        Ok(())
    }

    /// Close the open leaf: attach it to its parent level and hold it until the
    /// next leaf identity (or the end of input) resolves its sibling link.
    fn close_leaf(&mut self, finishing: bool) -> Result<(), PhobosError> {
        let level = self.level(0);
        let mut leaf = level.open.take().expect("open leaf");
        let first = level.first_key.take().expect("leaf first key");
        level.open_bytes = 0;
        // Within-leaf order is (key, rid) even where the old chain carried equal
        // keys across leaves without global RID order.
        if leaf
            .leaf
            .windows(2)
            .any(|w| compare_entry(&w[0], &w[1].key, w[1].rid) == Ordering::Greater)
        {
            leaf.leaf.sort_by(|a, b| compare_entry(a, &b.key, b.rid));
        }
        leaf.parent = self.attach(1, first, leaf.id, finishing)?;
        self.levels[0].closed += 1;
        self.report.leaves += 1;
        self.pending_leaf = Some(leaf);
        Ok(())
    }

    /// Register a closed child with its parent level, opening (and allocating)
    /// the parent on demand so the child can carry its parent identity. Returns
    /// NONE_PAGE when the child is the sole node of its level at the end.
    fn attach(
        &mut self,
        depth: usize,
        first_key: IndexKey,
        child: u64,
        finishing: bool,
    ) -> Result<u64, PhobosError> {
        if finishing && self.levels[depth - 1].closed == 0 {
            self.tree.root_page = child;
            return Ok(NONE_PAGE);
        }
        let bytes = internal_entry_bytes(&first_key)?;
        let level = self.level(depth);
        if level
            .open
            .as_ref()
            .is_some_and(|node| !node.internal.is_empty() && level.open_bytes + bytes > FILL_BYTES)
        {
            self.close_internal(depth, false)?;
        }
        if self.level(depth).open.is_none() {
            let id = self.allocator.allocate(self.tree)?;
            let level = self.level(depth);
            level.open = Some(Node::new_internal(id, NONE_PAGE, child));
            level.first_key = Some(first_key);
            level.open_bytes = NODE_HEADER + 8;
            return Ok(id);
        }
        let level = self.level(depth);
        level.open_bytes += bytes;
        let node = level.open.as_mut().expect("open internal");
        node.internal.push(InternalEntry {
            key: first_key,
            child,
        });
        Ok(node.id)
    }

    fn close_internal(&mut self, depth: usize, finishing: bool) -> Result<(), PhobosError> {
        let level = self.level(depth);
        let mut node = level.open.take().expect("open internal");
        let first = level.first_key.take().expect("internal first key");
        level.open_bytes = 0;
        node.parent = self.attach(depth + 1, first, node.id, finishing)?;
        self.tree.write_node(&node)?;
        self.levels[depth].closed += 1;
        self.report.internal += 1;
        Ok(())
    }

    fn finish(mut self) -> Result<BulkBuildReport, PhobosError> {
        if self.level(0).open.is_none() {
            // Nothing at all: the tree is one empty root leaf.
            self.open_leaf()?;
            self.level(0).first_key = None;
        }
        let mut leaf = self.level(0).open.take().expect("open leaf");
        if leaf.leaf.is_empty() {
            self.tree.root_page = leaf.id;
            leaf.parent = NONE_PAGE;
            self.report.leaves += 1;
            self.tree.write_node(&leaf)?;
        } else {
            self.level(0).open = Some(leaf);
            self.close_leaf(true)?;
            let mut pending = self.pending_leaf.take().expect("pending leaf");
            pending.next_leaf = NONE_PAGE;
            self.tree.write_node(&pending)?;
        }
        let _upper = phobos_observability::span("bulk.upper_build");
        let mut depth = 1;
        while depth < self.levels.len() {
            if self.levels[depth].open.is_some() {
                self.close_internal(depth, true)?;
            }
            depth += 1;
        }
        while let Some(id) = self.allocator.reusable.pop_front() {
            self.tree.write_free_page(id)?;
            self.report.freed_pages += 1;
        }
        self.report.reused_pages = self.allocator.reused;
        self.report.allocated_pages = self.allocator.allocated;
        self.report.height = self.levels.len().max(1);
        self.tree.write_meta()?;
        Ok(self.report)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_wal::v2::{Body, FileId, PageAction, Wal};
    use std::fs;

    fn root(label: &str) -> PathBuf {
        let path = std::env::temp_dir().join(format!(
            "phobos-c9-index-{label}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&path).unwrap();
        path
    }
    fn rid(n: u64) -> RecordId {
        RecordId {
            page_id: n / 50,
            slot_id: (n % 50) as u16,
        }
    }
    fn key(n: i64) -> IndexKey {
        IndexKey(vec![Value::Int64(n)])
    }
    fn wide(n: i64) -> IndexKey {
        IndexKey(vec![Value::Int64(n), Value::Text("w".repeat(600))])
    }

    /// Run one private bulk merge, then either publish it durably or roll back.
    fn merge(
        dir: &Path,
        wal: &mut Wal,
        tree: &mut BPlusTree,
        _label: u64,
        entries: Vec<(IndexKey, RecordId)>,
        commit: bool,
    ) -> Result<BulkBuildReport, PhobosError> {
        let stable = wal.begin().unwrap();
        tree.begin_private(&dir.join(format!("private-{stable}")), stable, dir)
            .unwrap();
        let result = tree.bulk_merge(stable, entries.into_iter().map(Ok));
        if result.is_err() || !commit {
            tree.rollback_private().unwrap();
            wal.abort().unwrap();
            return result;
        }
        tree.validate().unwrap();
        tree.prepare_private(|page, bytes, allocated| {
            wal.append(Body::Page {
                action: if allocated {
                    PageAction::Initialize
                } else {
                    PageAction::Index
                },
                file: FileId::Index(1),
                page,
                image: Box::new(*bytes),
            })?;
            Ok(())
        })
        .unwrap();
        let receipt = wal.commit().unwrap();
        tree.install_private(&receipt).unwrap();
        result
    }

    fn all(tree: &mut BPlusTree) -> Vec<(i64, RecordId)> {
        let mut out = Vec::new();
        tree.inspect_entries(|key, rid| {
            let Value::Int64(n) = key.0[0] else { panic!() };
            out.push((n, rid));
            Ok(true)
        })
        .unwrap();
        out
    }

    #[test]
    fn c9_bulk_build_empty_then_merge_multilevel_and_publish() {
        let dir = root("build");
        let mut wal = Wal::create(&dir).unwrap();
        let path = dir.join(FileId::Index(1).name());
        let mut tree = BPlusTree::open(&path, true, 2).unwrap();
        let k = |n: i64| IndexKey(vec![Value::Int64(n), Value::Text("k".repeat(100))]);
        // Empty batch into an empty index leaves one empty root leaf.
        let report = merge(&dir, &mut wal, &mut tree, 1, Vec::new(), true).unwrap();
        assert_eq!((report.leaves, report.internal, report.height), (1, 0, 1));
        assert_eq!(tree.validate().unwrap().pages, 1);
        // Enough entries for hundreds of leaves and two upper levels.
        let batch: Vec<_> = (0..40_000).map(|n| (k(n * 2), rid(n as u64))).collect();
        let report = merge(&dir, &mut wal, &mut tree, 2, batch, true).unwrap();
        assert_eq!(report.entries, 40_000);
        assert!(report.leaves > 100 && report.height >= 3, "{report:?}");
        let validation = tree.validate().unwrap();
        assert_eq!(validation.entries, 40_000);
        assert_eq!(validation.free_pages, 0);
        assert_eq!(tree.point_lookup(&k(31_338)).unwrap(), vec![rid(15_669)]);
        assert!(tree.point_lookup(&k(31_337)).unwrap().is_empty());
        // Interleaved merge into the populated index: odd keys between evens,
        // plus a run below every existing key.
        let batch: Vec<_> = (-2000..20_000)
            .map(|n| if n < 0 { n } else { n * 2 + 1 })
            .map(|n| (k(n), rid(100_000 + (n + 2000) as u64)))
            .collect();
        let count = batch.len() as u64;
        let report = merge(&dir, &mut wal, &mut tree, 3, batch, true).unwrap();
        assert_eq!(report.entries, count);
        assert_eq!(report.existing_entries, 40_000);
        let validation = tree.validate().unwrap();
        assert_eq!(validation.entries as u64, 40_000 + count);
        let entries = all(&mut tree);
        assert!(entries.windows(2).all(|w| w[0].0 < w[1].0));
        assert_eq!(entries.first().unwrap().0, -2000);
        assert_eq!(entries.len() as u64, 40_000 + count);
        drop(tree);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        let mut tree = BPlusTree::open(&path, true, 2).unwrap();
        let validation = tree.validate().unwrap();
        assert_eq!(validation.entries as u64, 40_000 + count);
        // Ordinary OLTP inserts and splits still work on the bulk-built tree.
        for n in 40_000..41_000 {
            tree.insert(k(n * 3), rid(200_000 + n as u64)).unwrap();
        }
        let validation = tree.validate().unwrap();
        assert_eq!(validation.entries as u64, 40_000 + count + 1000);
        assert_eq!(tree.point_lookup(&k(-1999)).unwrap(), vec![rid(100_001)]);
        assert_eq!(tree.point_lookup(&k(39_999)).unwrap(), vec![rid(141_999)]);
        drop(tree);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn c9_bulk_merge_rollback_free_pages_and_duplicates() {
        let dir = root("free");
        let mut wal = Wal::create(&dir).unwrap();
        let path = dir.join(FileId::Index(1).name());
        let mut tree = BPlusTree::open(&path, false, 2).unwrap();
        // Wide keys through the OLTP path leave half-full leaves and several
        // internal nodes; a packed rebuild needs fewer pages.
        for n in 0..3000 {
            tree.insert(wide(n), rid(n as u64)).unwrap();
        }
        let before = tree.validate().unwrap();
        assert!(before.height >= 3);
        let image = fs::read(&path).unwrap();
        // Rollback restores the committed tree and metadata exactly.
        let batch: Vec<_> = (0..500)
            .map(|n| (wide(n), rid(10_000 + n as u64)))
            .collect();
        merge(&dir, &mut wal, &mut tree, 1, batch.clone(), false).unwrap();
        assert_eq!(fs::read(&path).unwrap(), image);
        assert_eq!(tree.validate().unwrap(), before);
        // Non-unique duplicates across the old chain and the batch stay ordered.
        let report = merge(&dir, &mut wal, &mut tree, 2, batch, true).unwrap();
        let after = tree.validate().unwrap();
        assert_eq!(after.entries, 3500);
        assert_eq!(after.pages, before.pages + report.allocated_pages as usize);
        assert!(
            after.free_pages > 0 && report.allocated_pages == 0,
            "{report:?}"
        );
        assert_eq!(after.free_pages as u64, report.freed_pages);
        assert_eq!(tree.point_lookup(&wide(7)).unwrap().len(), 2);
        tree.sync().unwrap();
        // Free pages are never decoded as nodes but keep identity/checksums.
        let free = (1..tree.next_page)
            .find(|page| {
                let bytes = read_page(&mut tree.file, *page).unwrap();
                is_free_page(&bytes, *page)
            })
            .unwrap();
        assert!(tree.read_node(free).is_err());
        // Non-ascending input is rejected before anything is published.
        let bad = vec![(wide(5), rid(1)), (wide(4), rid(2))];
        assert!(merge(&dir, &mut wal, &mut tree, 3, bad, true).is_err());
        assert_eq!(tree.validate().unwrap(), after);
        drop(tree);
        drop(wal);
        drop(Wal::recover(&dir).unwrap());
        let mut tree = BPlusTree::open(&path, false, 2).unwrap();
        assert_eq!(tree.validate().unwrap(), after);
        drop(tree);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn c9_probe_sorted_matches_point_lookups() {
        let dir = root("probe");
        let path = dir.join("probe.idx");
        let mut tree = BPlusTree::open(&path, false, 1).unwrap();
        // Duplicate key 500 straddles leaves; gaps force re-descents.
        for n in 0..3000i64 {
            tree.insert(key(n * 10), rid(n as u64)).unwrap();
        }
        for n in 0..900 {
            tree.insert(key(500), rid(50_000 + n)).unwrap();
        }
        assert!(tree.validate().unwrap().leaves > 5);
        let probes: Vec<IndexKey> = [-5, 0, 10, 500, 505, 510, 15_000, 29_990, 29_995, 40_000]
            .into_iter()
            .map(key)
            .collect();
        let mut seen: std::collections::BTreeMap<usize, Vec<RecordId>> = Default::default();
        tree.probe_sorted(&probes, |index, rid| {
            seen.entry(index).or_default().push(rid);
            Ok(())
        })
        .unwrap();
        for (index, probe) in probes.iter().enumerate() {
            let mut expected = tree.point_lookup(probe).unwrap();
            expected.sort();
            let mut actual = seen.remove(&index).unwrap_or_default();
            actual.sort();
            assert_eq!(actual, expected, "probe {index}");
        }
        assert!(tree.probe_sorted(&[key(2), key(1)], |_, _| Ok(())).is_err());
        drop(tree);
        fs::remove_dir_all(dir).unwrap();
    }
}
