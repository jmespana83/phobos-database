//! Logical UNIQUE identity is independent of physical index order and encoding.
use super::*;

/// Exact canonical component bytes, not a digest. Component boundaries are
/// preserved so concatenated strings cannot alias. NULL keys never conflict.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct LogicalUniqueKey(Vec<Vec<u8>>);

impl IndexKey {
    pub fn logical_unique_key(&self) -> Option<LogicalUniqueKey> {
        (!self.contains_null())
            .then(|| LogicalUniqueKey(self.0.iter().map(Value::canonical_key).collect()))
    }
    /// Within a declared (coerced) column, only zero and NaN have multiple
    /// physical FLOAT representations. Composite positions need not be adjacent.
    pub fn needs_canonical_probe(&self) -> bool {
        self.0
            .iter()
            .any(|v| matches!(v,Value::Float64(f) if *f == 0.0 || f.is_nan()))
    }
}
impl BPlusTree {
    /// SQL callers have already coerced each indexed column to its declared
    /// type. Only ambiguous FLOAT encodings need a broader logical probe.
    pub fn typed_unique_visit(
        &mut self,
        key: &IndexKey,
        visitor: impl FnMut(RecordId) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        if key.contains_null() {
            return Ok(());
        }
        if key.needs_canonical_probe() {
            self.unique_visit(key, visitor)
        } else {
            self.range_visit(Bound::Included(key), Bound::Included(key), visitor)
        }
    }
    /// Logical UNIQUE probe for a typed index. Callers apply MVCC visibility.
    /// Ambiguous float representations require a filtered physical traversal;
    /// ordinary keys retain their bounded equality lookup.
    pub fn unique_visit(
        &mut self,
        key: &IndexKey,
        mut visitor: impl FnMut(RecordId) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let Some(logical) = key.logical_unique_key() else {
            return Ok(());
        };
        if !key.needs_canonical_probe() && !key.0.iter().any(|v| matches!(v, Value::Int64(0))) {
            // Low-level callers can use mixed numeric representations even
            // though SQL storage coerces every column to its declared type.
            // Enumerate exact finite alternatives, with a bounded fan-out.
            let mut probes = vec![IndexKey(Vec::new())];
            for value in &key.0 {
                let alternative = match value {
                    Value::Int64(n) => Some(Value::Float64(*n as f64)),
                    Value::Float64(f) if f.is_finite() => Some(Value::Int64(*f as i64)),
                    _ => None,
                }
                .filter(|other| value.canonical_eq(other) == Some(true));
                let mut next = Vec::new();
                for prefix in probes {
                    let mut first = prefix.clone();
                    first.0.push(value.clone());
                    next.push(first);
                    if let Some(other) = &alternative {
                        let mut second = prefix;
                        second.0.push(other.clone());
                        next.push(second);
                    }
                }
                probes = next;
                if probes.len() > 64 {
                    break;
                }
            }
            if probes.len() <= 64 {
                let mut keep_going = true;
                for probe in probes {
                    self.range_visit(Bound::Included(&probe), Bound::Included(&probe), |rid| {
                        keep_going = visitor(rid)?;
                        Ok(keep_going)
                    })?;
                    if !keep_going {
                        break;
                    }
                }
                return Ok(());
            }
        }
        let mut filter = |entry: &LeafEntry| {
            if entry.key.logical_unique_key().as_ref() == Some(&logical) {
                visitor(entry.rid)
            } else {
                Ok(true)
            }
        };
        if let Some(reader) = self.reader.clone() {
            reader.visit_entries(Bound::Unbounded, Bound::Unbounded, filter)
        } else {
            self.range_entry_visit(Bound::Unbounded, Bound::Unbounded, &mut filter)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn a12_logical_identity_iff_canonical_component_equality() {
        let values = vec![
            Value::Null,
            Value::Int64(0),
            Value::Int64(1),
            Value::Int64(i64::MAX),
            Value::Float64(0.0),
            Value::Float64(-0.0),
            Value::Float64(1.0),
            Value::Float64(1.5),
            Value::Float64(f64::NAN),
            Value::Float64(f64::from_bits(0xfff8000000001234)),
            Value::Float64(f64::INFINITY),
            Value::Float64(f64::NEG_INFINITY),
            Value::Text("ab".into()),
            Value::Text("a".into()),
            Value::Boolean(true),
            Value::Date(1),
            Value::Timestamp(1),
            Value::Decimal {
                unscaled: 10,
                scale: 1,
            },
            Value::Decimal {
                unscaled: 10,
                scale: 2,
            },
        ];
        for a in &values {
            for b in &values {
                let ka =
                    IndexKey(vec![a.clone(), Value::Text("suffix".into())]).logical_unique_key();
                let kb =
                    IndexKey(vec![b.clone(), Value::Text("suffix".into())]).logical_unique_key();
                if a.is_null() || b.is_null() {
                    assert!(ka.is_none() || kb.is_none());
                } else {
                    assert_eq!(ka == kb, a.canonical_eq(b) == Some(true), "{a:?} {b:?}");
                }
            }
        }
        assert_ne!(
            IndexKey(vec![Value::Text("ab".into()), Value::Text("c".into())]).logical_unique_key(),
            IndexKey(vec![Value::Text("a".into()), Value::Text("bc".into())]).logical_unique_key()
        );
    }
    #[test]
    fn a12_tree_typed_and_mixed_numeric_identity() {
        let root = std::env::temp_dir().join(format!(
            "phobos-a12-tree-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&root).unwrap();
        for (i, (a, b)) in [
            (Value::Int64(1), Value::Float64(1.0)),
            (Value::Float64(-0.0), Value::Int64(0)),
            (
                Value::Float64(f64::NAN),
                Value::Float64(f64::from_bits(0xfff8000000000001)),
            ),
        ]
        .into_iter()
        .enumerate()
        {
            let mut tree = BPlusTree::open(root.join(i.to_string()), true, 1).unwrap();
            tree.insert(
                IndexKey(vec![a]),
                RecordId {
                    page_id: 1,
                    slot_id: 0,
                },
            )
            .unwrap();
            assert_eq!(
                tree.insert(
                    IndexKey(vec![b]),
                    RecordId {
                        page_id: 2,
                        slot_id: 0
                    }
                )
                .unwrap_err()
                .code,
                ErrorCode::ConstraintViolation
            );
        }
        std::fs::remove_dir_all(root).unwrap();
    }
}
