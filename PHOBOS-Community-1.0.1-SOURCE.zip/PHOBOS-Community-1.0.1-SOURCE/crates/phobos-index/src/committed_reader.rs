//! Bounded index traversal across ordered MVCC publication. Retained historical
//! entries make an exclusive (key,RID) continuation stable across splits.
use super::*;
use phobos_storage::committed_pages::CommittedReader;
use std::{
    collections::BTreeMap,
    sync::{Arc, Mutex, RwLock},
};

#[derive(Debug, Clone, Copy)]
struct CachedMeta {
    root_page: u64,
    next_page: u64,
    free_head: u64,
}
#[derive(Debug, Default)]
pub(super) struct NavigationCache {
    generation: Option<u64>,
    meta: Option<CachedMeta>,
    internal: BTreeMap<u64, (PageRef, node_view::Layout)>,
    /// 0.2-C: the most recently validated leaf of this generation. Committed
    /// pages are immutable within a publication generation (the premise of
    /// the internal-node cache above), so a leaf validated once need not be
    /// re-read and re-validated by the next probe that reaches it.
    leaf: Option<(u64, PageRef, node_view::Layout)>,
}
#[derive(Debug, Clone)]
pub(super) struct Navigation {
    generation: u64,
    cache: Arc<Mutex<NavigationCache>>,
}
impl NavigationCache {
    fn select(&mut self, generation: u64) {
        if self.generation != Some(generation) {
            if self.meta.is_some() || !self.internal.is_empty() || self.leaf.is_some() {
                // 0.2-F: decoded nodes of an older publication generation are
                // never reused (fallback reason: publication generation changed).
                phobos_observability::event("index.navigation_invalidations", 1);
            }
            self.generation = Some(generation);
            self.meta = None;
            self.internal.clear();
            self.leaf = None;
        }
    }
}
impl Navigation {
    pub(super) fn internal(
        &self,
        page: u64,
    ) -> Result<Option<(PageRef, node_view::Layout)>, PhobosError> {
        let mut cache = self
            .cache
            .lock()
            .map_err(|_| index_error("index navigation cache poisoned"))?;
        cache.select(self.generation);
        let hit = cache
            .internal
            .get(&page)
            .map(|(bytes, layout)| (Arc::clone(bytes), Arc::clone(layout)));
        phobos_observability::event(
            if hit.is_some() {
                "index.navigation_cache_hit"
            } else {
                "index.navigation_cache_miss"
            },
            1,
        );
        Ok(hit)
    }
    pub(super) fn leaf(
        &self,
        page: u64,
    ) -> Result<Option<(PageRef, node_view::Layout)>, PhobosError> {
        let mut cache = self
            .cache
            .lock()
            .map_err(|_| index_error("index navigation cache poisoned"))?;
        cache.select(self.generation);
        let hit = cache
            .leaf
            .as_ref()
            .filter(|(id, _, _)| *id == page)
            .map(|(_, bytes, layout)| (Arc::clone(bytes), Arc::clone(layout)));
        if hit.is_some() {
            phobos_observability::event("index.leaf_cache_hit", 1);
        }
        Ok(hit)
    }
    pub(super) fn remember_leaf(
        &self,
        page: u64,
        bytes: &PageRef,
        layout: &node_view::Layout,
    ) -> Result<(), PhobosError> {
        let mut cache = self
            .cache
            .lock()
            .map_err(|_| index_error("index navigation cache poisoned"))?;
        cache.select(self.generation);
        cache.leaf = Some((page, Arc::clone(bytes), Arc::clone(layout)));
        Ok(())
    }
    pub(super) fn remember_internal(
        &self,
        page: u64,
        bytes: PageRef,
        layout: node_view::Layout,
    ) -> Result<(), PhobosError> {
        let mut cache = self
            .cache
            .lock()
            .map_err(|_| index_error("index navigation cache poisoned"))?;
        cache.select(self.generation);
        if cache.internal.len() < 256 {
            cache.internal.insert(page, (bytes, layout));
        }
        Ok(())
    }
}

#[derive(Clone)]
pub struct IndexReader {
    pages: CommittedReader,
    legacy: Option<Arc<RwLock<()>>>,
    epoch: Arc<publication_epoch::Epoch>,
    path: PathBuf,
    unique: bool,
    columns: u16,
    navigation: Arc<Mutex<NavigationCache>>,
    /// 0.2-F: one opened handle of the index file per read handle. A reader
    /// `PageIo` never reads through its base file (every page comes from
    /// the committed reader), so statements share it via `try_clone`
    /// instead of opening the path again for every probe.
    base: Arc<std::sync::OnceLock<Arc<std::fs::File>>>,
}
impl std::fmt::Debug for IndexReader {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("IndexReader")
            .field("path", &self.path)
            .finish_non_exhaustive()
    }
}
impl BPlusTree {
    /// The publisher must hold the same write guard while installing all heap
    /// and index images and advancing visibility. Never delete historic entries
    /// while a statement pin may require them. No guard spans visitor/network I/O.
    pub fn statement_reader(&self, publication: Arc<RwLock<()>>) -> Result<Self, PhobosError> {
        let mut reader = self.read_handle()?;
        reader.legacy = Some(publication);
        reader.statement_reader()
    }
    pub fn read_handle(&self) -> Result<IndexReader, PhobosError> {
        Ok(IndexReader {
            pages: self.file.committed_reader()?,
            legacy: None,
            epoch: self.publication.clone(),
            path: self.path.clone(),
            unique: self.unique,
            columns: self.key_columns,
            navigation: Arc::new(Mutex::new(NavigationCache::default())),
            base: Arc::default(),
        })
    }
}
impl IndexReader {
    pub fn statement_reader(&self) -> Result<BPlusTree, PhobosError> {
        let reader = self.clone();
        // A statement reader is a lightweight facade. The first actual index
        // operation validates metadata inside its single publication window;
        // constructing readers for unrelated indexes performs no traversal.
        let base = reader.base_file()?;
        let file = PageIo::new_reader_shared(base, reader.pages.clone())?;
        Ok(BPlusTree {
            batch: None,
            publication: reader.epoch.clone(),
            reader: Some(reader.clone()),
            path: reader.path.clone(),
            file,
            root_page: 1,
            next_page: 2,
            free_head: 0,
            unique: reader.unique,
            key_columns: reader.columns,
            private_original: None,
            meta_dirty: false,
            write_counters: IndexWriteCounters::default(),
            navigation: None,
        })
    }
}

impl IndexReader {
    /// A handle of the index file for a reader `PageIo` (see `base`).
    fn base_file(&self) -> Result<Arc<std::fs::File>, PhobosError> {
        // 0.2-G: shared handle (`Arc`), no descriptor dup/close per reader.
        if let Some(file) = self.base.get() {
            phobos_observability::event("view.file_reuse", 1);
            return Ok(file.clone());
        }
        phobos_observability::event("view.file_open", 1);
        let file = Arc::new(OpenOptions::new().read(true).open(&self.path)?);
        let _ = self.base.set(file.clone());
        Ok(file)
    }
    fn consistent<T>(
        &self,
        operation: impl FnMut(u64) -> Result<T, PhobosError>,
    ) -> Result<T, PhobosError> {
        let _legacy = self
            .legacy
            .as_ref()
            .map(|legacy| {
                legacy
                    .read()
                    .map_err(|_| index_error("publication poisoned"))
            })
            .transpose()?;
        phobos_observability::event("publication_windows", 1);
        self.epoch.read_with_token(operation)
    }
    fn current_tree(&self, generation: u64) -> Result<BPlusTree, PhobosError> {
        let base = self.base_file()?;
        let mut file = PageIo::new_reader_shared(base, self.pages.clone())?;
        let cached = {
            let mut cache = self
                .navigation
                .lock()
                .map_err(|_| index_error("index navigation cache poisoned"))?;
            cache.select(generation);
            cache.meta
        };
        let meta = if let Some(meta) = cached {
            phobos_observability::event("point_upper_cache_hits", 1);
            phobos_observability::event("index.navigation_cache_hit", 1);
            meta
        } else {
            phobos_observability::event("point_upper_cache_misses", 1);
            phobos_observability::event("index.navigation_cache_miss", 1);
            let bytes = read_page(&mut file, 0)?;
            validate_meta_checksum(&bytes)?;
            if bytes[..4] != META_MAGIC
                || !matches!(u16::from_le_bytes([bytes[4], bytes[5]]), 1..=3)
                || (bytes[6] != 0) != self.unique
                || u16::from_le_bytes([bytes[8], bytes[9]]) != self.columns
            {
                return Err(index_error("committed index metadata mismatch"));
            }
            let meta = CachedMeta {
                root_page: u64::from_le_bytes(bytes[12..20].try_into().expect("root")),
                next_page: u64::from_le_bytes(bytes[20..28].try_into().expect("next page")),
                free_head: u64::from_le_bytes(bytes[META_FREE_HEAD].try_into().expect("free head")),
            };
            let mut cache = self
                .navigation
                .lock()
                .map_err(|_| index_error("index navigation cache poisoned"))?;
            cache.select(generation);
            cache.meta = Some(meta);
            meta
        };
        let root_page = meta.root_page;
        let next_page = meta.next_page;
        if root_page == 0
            || root_page >= next_page
            || next_page.checked_mul(INDEX_PAGE_SIZE as u64) != Some(file.len()?)
        {
            return Err(index_error("committed index length/root mismatch"));
        }
        Ok(BPlusTree {
            batch: None,
            publication: self.epoch.clone(),
            path: self.path.clone(),
            file,
            root_page,
            next_page,
            free_head: meta.free_head,
            unique: self.unique,
            key_columns: self.columns,
            private_original: None,
            reader: None,
            meta_dirty: false,
            write_counters: IndexWriteCounters::default(),
            navigation: Some(Navigation {
                generation,
                cache: Arc::clone(&self.navigation),
            }),
        })
    }

    /// 0.2-K diagnostics: committed page count (`next_page`, page 0 = meta)
    /// and free-list length, under one publication window.
    pub(super) fn shape(&self) -> Result<(u64, usize), PhobosError> {
        self.consistent(|token| {
            let mut tree = self.current_tree(token)?;
            let free = tree.free_list_len()?;
            Ok((tree.next_page, free))
        })
    }

    pub(super) fn point_lookup(&self, key: &IndexKey) -> Result<Vec<RecordId>, PhobosError> {
        self.consistent(|token| {
            let _wait = phobos_observability::span("mvcc.index_publication_wait");
            let mut tree = self.current_tree(token)?;
            let mut result = Vec::new();
            tree.range_entry_visit(Bound::Included(key), Bound::Included(key), |entry| {
                result.push(entry.rid);
                Ok(true)
            })?;
            Ok(result)
        })
    }

    /// Ordered bulk probe under one consistent traversal window per call.
    pub(super) fn probe_sorted(
        &self,
        keys: &[IndexKey],
    ) -> Result<Vec<(usize, RecordId)>, PhobosError> {
        self.consistent(|token| {
            let _wait = phobos_observability::span("mvcc.index_publication_wait");
            let mut tree = self.current_tree(token)?;
            let mut matches = Vec::new();
            tree.probe_sorted_direct(keys, |index, rid| {
                matches.push((index, rid));
                Ok(())
            })?;
            Ok(matches)
        })
    }

    pub(super) fn visit(
        &self,
        lower: Bound<'_>,
        upper: Bound<'_>,
        mut visitor: impl FnMut(RecordId) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        self.visit_entries(lower, upper, |entry| visitor(entry.rid))
    }

    pub(super) fn visit_prefix(
        &self,
        prefix: &IndexKey,
        mut visitor: impl FnMut(RecordId) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        self.visit_prefix_entries(prefix, |entry| visitor(entry.rid))
    }

    /// 0.2-K: `visit_prefix` that also exposes each entry's key (RID
    /// identity re-validation at the heap dereference).
    pub(super) fn visit_prefix_entries(
        &self,
        prefix: &IndexKey,
        mut visitor: impl FnMut(&LeafEntry) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut after: Option<LeafEntry> = None;
        loop {
            let batch = self.consistent(|token| {
                let _wait = phobos_observability::span("mvcc.index_publication_wait");
                let mut tree = self.current_tree(token)?;
                phobos_observability::synchronization_boundary(
                    "c6_index_batch_read",
                    self.path.parent().expect("index directory"),
                );
                let mut batch = std::collections::BTreeMap::new();
                // 0.2-B: a window that neither stopped early nor dropped an
                // entry holds every remaining match; no confirming traversal.
                let mut truncated = false;
                tree.prefix_entry_visit_from(
                    prefix,
                    after.as_ref().map(|last| &last.key),
                    |entry| {
                        if batch.len() == 128
                            && batch
                                .last_key_value()
                                .is_some_and(|((key, _), _)| entry.key > *key)
                        {
                            truncated = true;
                            return Ok(false);
                        }
                        if after.as_ref().is_none_or(|last| {
                            compare_entry(entry, &last.key, last.rid) == Ordering::Greater
                        }) {
                            batch.insert((entry.key.clone(), entry.rid), entry.clone());
                            if batch.len() > 128 {
                                batch.pop_last();
                                truncated = true;
                            }
                        }
                        Ok(true)
                    },
                )?;
                Ok((batch.into_values().collect::<Vec<_>>(), !truncated))
            })?;
            let (batch, complete) = batch;
            if batch.is_empty() {
                return Ok(());
            }
            after = batch.last().cloned();
            for entry in batch {
                if !visitor(&entry)? {
                    return Ok(());
                }
            }
            if complete {
                phobos_observability::event("index.batch_window_complete", 1);
                return Ok(());
            }
        }
    }

    pub(super) fn visit_entries(
        &self,
        lower: Bound<'_>,
        upper: Bound<'_>,
        mut visitor: impl FnMut(&LeafEntry) -> Result<bool, PhobosError>,
    ) -> Result<(), PhobosError> {
        let mut after: Option<LeafEntry> = None;
        loop {
            let batch = self.consistent(|token| {
                let _wait = phobos_observability::span("mvcc.index_publication_wait");
                let mut tree = self.current_tree(token)?;
                phobos_observability::synchronization_boundary(
                    "c6_index_batch_read",
                    self.path.parent().expect("index directory"),
                );
                let bound = after
                    .as_ref()
                    .map_or(lower, |last| Bound::Included(&last.key));
                // C4 permits equal keys in several leaves without global RID
                // ordering. Select a bounded ordered window across the complete
                // boundary key instead of assuming its first leaf owns every RID.
                let mut batch = std::collections::BTreeMap::new();
                // 0.2-B: see visit_prefix; a complete window ends the scan.
                let mut truncated = false;
                tree.range_entry_visit(bound, upper, |entry| {
                    if batch.len() == 128
                        && batch
                            .last_key_value()
                            .is_some_and(|((key, _), _)| entry.key > *key)
                    {
                        truncated = true;
                        return Ok(false);
                    }
                    if after.as_ref().is_none_or(|last| {
                        compare_entry(entry, &last.key, last.rid) == Ordering::Greater
                    }) && lower_allows(&lower, &entry.key)
                    {
                        batch.insert((entry.key.clone(), entry.rid), entry.clone());
                        if batch.len() > 128 {
                            batch.pop_last();
                            truncated = true;
                        }
                    }
                    Ok(true)
                })?;
                Ok((batch.into_values().collect::<Vec<_>>(), !truncated))
            })?;
            let (batch, complete) = batch;
            if batch.is_empty() {
                return Ok(());
            }
            after = batch.last().cloned();
            for entry in batch {
                if !visitor(&entry)? {
                    return Ok(());
                }
            }
            if complete {
                phobos_observability::event("index.batch_window_complete", 1);
                return Ok(());
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use phobos_storage::committed_pages::{CommittedStore, FlushConfig};
    use phobos_wal::v2::{FileId, PageAction, Wal};
    use std::{
        fs,
        sync::{
            Mutex,
            atomic::{AtomicBool, Ordering as AtomicOrdering},
            mpsc,
        },
        thread,
        time::Duration,
    };

    fn append(
        tree: &mut BPlusTree,
        wal: &mut Wal,
        root: &Path,
        stable: u64,
        ids: std::ops::Range<u64>,
    ) {
        tree.begin_private(&root.join(format!("private-{stable}")), stable, root)
            .unwrap();
        for id in ids {
            tree.insert_version(
                IndexKey(vec![Value::Text(format!("{id:05}{}", "x".repeat(1700)))]),
                RecordId {
                    page_id: id,
                    slot_id: 0,
                },
                stable,
            )
            .unwrap();
        }
        wal.begin_mvcc(stable).unwrap();
        tree.prepare_private_redo(FileId::Index(1), |page, bytes, allocated| {
            wal.append_page(
                if allocated {
                    PageAction::Initialize
                } else {
                    PageAction::Index
                },
                FileId::Index(1),
                page,
                bytes,
            )?;
            Ok(())
        })
        .unwrap();
        tree.stage_private().unwrap();
        let receipt = wal.commit().unwrap();
        tree.install_pending(&receipt).unwrap();
    }

    #[cfg(feature = "db1-diagnostics")]
    fn append_duplicate_split(
        tree: &mut BPlusTree,
        wal: &mut Wal,
        root: &Path,
        stable: u64,
        next_rid: &mut u64,
        target_next_page: u64,
    ) {
        tree.begin_private(&root.join(format!("private-{stable}")), stable, root)
            .unwrap();
        let key = IndexKey(vec![Value::Null]);
        while tree.next_page < target_next_page {
            tree.insert_version(
                key.clone(),
                RecordId {
                    page_id: *next_rid,
                    slot_id: 0,
                },
                stable,
            )
            .unwrap();
            *next_rid += 1;
        }
        wal.begin_mvcc(stable).unwrap();
        tree.prepare_private_redo(FileId::Index(1), |page, bytes, allocated| {
            wal.append_page(
                if allocated {
                    PageAction::Initialize
                } else {
                    PageAction::Index
                },
                FileId::Index(1),
                page,
                bytes,
            )?;
            Ok(())
        })
        .unwrap();
        tree.stage_private().unwrap();
        let receipt = wal.commit().unwrap();
        tree.install_pending(&receipt).unwrap();
    }

    #[cfg(feature = "db1-diagnostics")]
    fn leaf_orders(tree: &mut BPlusTree) -> (Vec<u64>, Vec<u64>) {
        fn visit(tree: &mut BPlusTree, page: u64, leaves: &mut Vec<u64>) {
            let node = tree.read_node(page).unwrap();
            if node.kind == NodeKind::Leaf {
                leaves.push(page);
                return;
            }
            visit(tree, node.first_child, leaves);
            for entry in node.internal {
                visit(tree, entry.child, leaves);
            }
        }
        let mut parent_order = Vec::new();
        visit(tree, tree.root_page, &mut parent_order);
        let mut sibling_order = Vec::new();
        let mut page = tree.leftmost_leaf().unwrap();
        while page != NONE_PAGE {
            sibling_order.push(page);
            page = tree.read_node(page).unwrap().next_leaf;
            assert!(sibling_order.len() <= tree.next_page as usize);
        }
        (parent_order, sibling_order)
    }

    #[cfg(feature = "db1-diagnostics")]
    fn duplicate_overlap(tree: &mut BPlusTree, left: u64, right: u64) -> (usize, usize, usize) {
        let left = tree.read_node(left).unwrap().leaf;
        let right = tree.read_node(right).unwrap().leaf;
        let overlap = left
            .iter()
            .filter(|candidate| {
                right
                    .iter()
                    .any(|entry| entry.key == candidate.key && entry.rid == candidate.rid)
            })
            .count();
        (overlap, left.len(), right.len())
    }

    /// Explicit gate test: run with `--ignored --nocapture` and set
    /// PHOBOS_DB1_RACE_ITERATIONS=50 for the repeated release gate.
    #[cfg(feature = "db1-diagnostics")]
    #[test]
    #[ignore]
    fn db1_cold_leaf_read_racing_split_publication() {
        let iterations = std::env::var("PHOBOS_DB1_RACE_ITERATIONS")
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(1);
        for iteration in 0..iterations {
            let root = std::env::temp_dir().join(format!(
                "phobos-db1-page-race-{}-{iteration}-{}",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ));
            let mut wal = Wal::create_with_versioned_heap(&root).unwrap();
            let root = fs::canonicalize(root).unwrap();
            let store = CommittedStore::new(
                &root,
                FlushConfig {
                    wake_interval: Duration::from_secs(3600),
                    ..FlushConfig::default()
                },
            )
            .unwrap();
            let unique_key = IndexKey(vec![Value::Int64(99)]);
            let mut tree = BPlusTree::open(root.join(FileId::Index(1).name()), true, 1).unwrap();
            tree.insert(
                unique_key.clone(),
                RecordId {
                    page_id: u64::MAX - 1,
                    slot_id: 0,
                },
            )
            .unwrap();
            assert!(
                tree.insert(
                    unique_key.clone(),
                    RecordId {
                        page_id: u64::MAX,
                        slot_id: 0,
                    },
                )
                .is_err()
            );
            tree.attach_committed(&store, FileId::Index(1)).unwrap();
            let mut next_rid = 0;

            // Establish the on-disk initial topology L -> R.
            append_duplicate_split(&mut tree, &mut wal, &root, 1, &mut next_rid, 4);
            tree.force_committed().unwrap();
            let left = tree.leftmost_leaf().unwrap();
            let initial = tree.read_node(left).unwrap();
            let right = initial.next_leaf;
            assert_ne!(right, NONE_PAGE);
            let pages = tree.file.committed_reader().unwrap();
            let _ = pages.diagnostic_evict_clean(left).unwrap();
            let before = pages.diagnostic_state(left).unwrap();
            assert!(before.publication_generation.is_none());
            assert!(!before.clean_cached);

            // Pause the cold read after it captured the old L -> R disk image.
            let (reached_tx, reached_rx) = mpsc::channel();
            let (release_tx, release_rx) = mpsc::channel();
            let release_rx = Mutex::new(release_rx);
            let once = AtomicBool::new(false);
            let hook = phobos_observability::test_hooks::register(
                &root,
                Arc::new(move |point| {
                    if point == "committed_read_after_disk"
                        && !once.swap(true, AtomicOrdering::SeqCst)
                    {
                        reached_tx.send(()).unwrap();
                        release_rx
                            .lock()
                            .unwrap()
                            .recv_timeout(Duration::from_secs(10))
                            .unwrap();
                    }
                }),
            );
            let cold = pages.clone();
            let reading = thread::spawn(move || cold.read(left).unwrap());
            reached_rx.recv_timeout(Duration::from_secs(10)).unwrap();

            // The real private/WAL/index path publishes L -> N1 -> R and a
            // parent containing L,N1,R while the old read is paused.
            append_duplicate_split(&mut tree, &mut wal, &root, 2, &mut next_rid, 5);
            let published = pages.diagnostic_state(left).unwrap();
            let published_left = tree.read_node(left).unwrap();
            let published_provenance = tree.file.page_provenance(left).unwrap();
            let n1 = published_left.next_leaf;
            assert_ne!(n1, right);
            release_tx.send(()).unwrap();
            let returned_bytes = reading.join().unwrap();
            let returned_lsn = u64::from_le_bytes(returned_bytes[40..48].try_into().unwrap());
            let returned = decode_node(&returned_bytes, left).unwrap();
            let after_read = pages.diagnostic_state(left).unwrap();
            drop(hook);

            // Drain the authoritative dirty generation, then split L again.
            tree.force_committed().unwrap();
            let after_force = pages.diagnostic_state(left).unwrap();
            append_duplicate_split(&mut tree, &mut wal, &root, 3, &mut next_rid, 6);

            let current_left = tree.read_node(left).unwrap();
            let n2 = current_left.next_leaf;
            let (parent_order, sibling_order) = leaf_orders(&mut tree);
            let overlap = duplicate_overlap(&mut tree, n1, n2);
            let validation = tree.validate();
            let parent = tree.read_node(tree.root_page).unwrap();
            let parent_provenance = tree.file.page_provenance(parent.id).unwrap();
            println!(
                "DB1_PAGE_RACE iteration={iteration} left={left} right={right} n1={n1} n2={n2} before={before:?} published={published:?} after_read={after_read:?} after_force={after_force:?} returned_lsn={} returned_next={} published_lsn={} published_next={} parent={} parent_lsn={} parent_order={parent_order:?} sibling_order={sibling_order:?} overlap={overlap:?} validation={validation:?}",
                returned_lsn,
                returned.next_leaf,
                published_provenance.page_lsn,
                published_left.next_leaf,
                parent.id,
                parent_provenance.page_lsn,
            );
            assert_eq!(returned_lsn, published_provenance.page_lsn);
            assert_eq!(returned.next_leaf, n1);
            assert_eq!(parent_order, vec![left, n2, n1, right]);
            assert_eq!(sibling_order, parent_order);
            validation.unwrap();
            let null = IndexKey(vec![Value::Null]);
            let mut actual = tree.point_lookup(&null).unwrap();
            actual.sort();
            let expected = (0..next_rid)
                .map(|page_id| RecordId {
                    page_id,
                    slot_id: 0,
                })
                .collect::<Vec<_>>();
            assert_eq!(actual, expected);
            assert_eq!(tree.point_lookup(&unique_key).unwrap().len(), 1);
            tree.force_committed().unwrap();
            store.stop().unwrap();
            drop(tree);
            drop(store);
            drop(wal);
            fs::remove_dir_all(root).unwrap();
        }
    }

    #[test]
    fn c6_range_restarts_across_leaf_internal_and_root_split_publication() {
        let root = std::env::temp_dir().join(format!(
            "phobos-c6-index-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut wal = Wal::create_with_versioned_heap(&root).unwrap();
        let root = fs::canonicalize(root).unwrap();
        let store = CommittedStore::new(&root, FlushConfig::default()).unwrap();
        let mut tree = BPlusTree::open(root.join(FileId::Index(1).name()), false, 1).unwrap();
        tree.attach_committed(&store, FileId::Index(1)).unwrap();
        append(&mut tree, &mut wal, &root, 1, 0..2);
        let mut reader = tree.read_handle().unwrap().statement_reader().unwrap();
        let (reached, waiting) = mpsc::channel();
        let (release, released) = mpsc::channel();
        let released = Mutex::new(released);
        let first = AtomicBool::new(true);
        let hook = phobos_observability::test_hooks::register(
            &root,
            Arc::new(move |point| {
                if point == "c6_index_batch_read" && first.swap(false, AtomicOrdering::AcqRel) {
                    reached.send(()).unwrap();
                    released
                        .lock()
                        .unwrap()
                        .recv_timeout(Duration::from_secs(10))
                        .unwrap();
                }
            }),
        );
        let worker = thread::spawn(move || {
            let mut ids = Vec::new();
            reader
                .range_visit(Bound::Unbounded, Bound::Unbounded, |rid| {
                    ids.push(rid.page_id);
                    Ok(true)
                })
                .unwrap();
            ids
        });
        waiting.recv_timeout(Duration::from_secs(10)).unwrap();
        // This must finish while the reader is paused inside a traversal batch.
        append(&mut tree, &mut wal, &root, 2, 2..90);
        assert!(tree.validate().unwrap().height >= 3);
        release.send(()).unwrap();
        assert_eq!(worker.join().unwrap(), (0..90).collect::<Vec<_>>());
        drop(hook);
        tree.force_committed().unwrap();
        store.stop().unwrap();
        drop(tree);
        drop(store);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn perf2_point_navigation_reuses_upper_pages_and_invalidates_on_publication() {
        let root = std::env::temp_dir().join(format!(
            "phobos-perf2-index-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut wal = Wal::create_with_versioned_heap(&root).unwrap();
        let root = fs::canonicalize(root).unwrap();
        let store = CommittedStore::new(&root, FlushConfig::default()).unwrap();
        let mut tree = BPlusTree::open(root.join(FileId::Index(1).name()), false, 1).unwrap();
        tree.attach_committed(&store, FileId::Index(1)).unwrap();
        append(&mut tree, &mut wal, &root, 1, 0..90);
        assert!(tree.validate().unwrap().height >= 3);
        let handle = tree.read_handle().unwrap();
        let key = IndexKey(vec![Value::Text(format!("{:05}{}", 44, "x".repeat(1700)))]);
        let mut first = handle.statement_reader().unwrap();
        assert_eq!(first.point_lookup(&key).unwrap()[0].page_id, 44);
        let (generation, cached) = {
            let cache = handle.navigation.lock().unwrap();
            (cache.generation, cache.internal.len())
        };
        assert!(cached > 0);
        let mut second = handle.statement_reader().unwrap();
        assert_eq!(second.point_lookup(&key).unwrap()[0].page_id, 44);
        assert_eq!(handle.navigation.lock().unwrap().generation, generation);

        append(&mut tree, &mut wal, &root, 2, 90..100);
        let new_key = IndexKey(vec![Value::Text(format!("{:05}{}", 99, "x".repeat(1700)))]);
        let mut after = handle.statement_reader().unwrap();
        assert_eq!(after.point_lookup(&new_key).unwrap()[0].page_id, 99);
        assert_ne!(handle.navigation.lock().unwrap().generation, generation);
        tree.force_committed().unwrap();
        store.stop().unwrap();
        drop(tree);
        drop(store);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn v2c_leaf_cache_is_generation_scoped_and_sees_leaf_only_publication() {
        let root = std::env::temp_dir().join(format!(
            "phobos-v2c-leaf-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let mut wal = Wal::create_with_versioned_heap(&root).unwrap();
        let root = fs::canonicalize(root).unwrap();
        let store = CommittedStore::new(&root, FlushConfig::default()).unwrap();
        let mut tree = BPlusTree::open(root.join(FileId::Index(1).name()), false, 1).unwrap();
        tree.attach_committed(&store, FileId::Index(1)).unwrap();
        append(&mut tree, &mut wal, &root, 1, 0..90);
        let key = |id: u64| IndexKey(vec![Value::Text(format!("{id:05}{}", "x".repeat(1700)))]);
        let handle = tree.read_handle().unwrap();
        let mut reader = handle.statement_reader().unwrap();
        assert_eq!(reader.point_lookup(&key(89)).unwrap()[0].page_id, 89);
        let leaf = handle
            .navigation
            .lock()
            .unwrap()
            .leaf
            .as_ref()
            .map(|(id, _, _)| *id);
        assert!(leaf.is_some());
        // Same generation: the cached leaf serves the probe.
        assert_eq!(reader.point_lookup(&key(88)).unwrap()[0].page_id, 88);
        assert!(reader.point_lookup(&key(90)).unwrap().is_empty());
        // Publications that only rewrite the cached rightmost leaf (no split)
        // must be seen by the next probe of the same reader handle.
        let mut leaf_only = 0;
        for id in 90..110 {
            // Cache the current rightmost leaf, then publish into it.
            assert_eq!(
                reader.point_lookup(&key(id - 1)).unwrap()[0].page_id,
                id - 1
            );
            let generation = handle.navigation.lock().unwrap().generation;
            let pages = tree.next_page;
            append(&mut tree, &mut wal, &root, id + 2, id..id + 1);
            leaf_only += usize::from(tree.next_page == pages);
            assert_eq!(reader.point_lookup(&key(id)).unwrap()[0].page_id, id);
            let mut after = handle.statement_reader().unwrap();
            assert_eq!(after.point_lookup(&key(id)).unwrap()[0].page_id, id);
            assert_ne!(handle.navigation.lock().unwrap().generation, generation);
        }
        assert!(leaf_only > 0, "no leaf-only publication exercised");
        tree.force_committed().unwrap();
        store.stop().unwrap();
        drop(tree);
        drop(store);
        drop(wal);
        fs::remove_dir_all(root).unwrap();
    }
}
