"""Live Windows TLS/auth/operations lifecycle certification on a fresh database.
Requires Python cryptography to generate an ephemeral test CA and server certificate.
No private credentials or machine certificate stores are changed.
"""
import argparse
import datetime
import json
import socket
import ssl
import struct
import subprocess
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


class Client:
    def __init__(self, port, ca, name='localhost'):
        context = ssl.create_default_context(cafile=str(ca))
        raw = socket.create_connection(('127.0.0.1', port), timeout=5)
        try:
            self.sock = context.wrap_socket(raw, server_hostname=name)
        except BaseException:
            raw.close()
            raise
        self.ident = 0
    def read(self, count):
        value = b''
        while len(value) < count:
            part = self.sock.recv(count-len(value))
            if not part:
                raise RuntimeError('connection closed')
            value += part
        return value
    def message(self, kind, text=''):
        self.ident += 1
        body = text.encode()
        self.sock.sendall(struct.pack('!4sBBHII', b'PHOB', 1, kind, 0, self.ident, len(body))+body)
        magic, version, response, flags, ident, length = struct.unpack('!4sBBHII', self.read(16))
        assert (magic, version, ident) == (b'PHOB', 1, self.ident)
        assert length <= 1024*1024
        payload = self.read(length).decode()
        return response, payload
    def query(self, sql):
        response, text = self.message(10, sql)
        assert response == 11, text
        return text
    def close(self):
        self.sock.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--cycles', type=int, default=25)
    a = parser.parse_args()
    if a.cycles < 1:
        parser.error('cycles must be positive')
    a.out.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[1]
    server = root/'target/release/phobos-server.exe'
    admin = root/'target/release/phobos-admin.exe'
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    def native(*args):
        result = subprocess.run([str(admin), *map(str, args)], capture_output=True, text=True, creationflags=flags)
        with (a.out/'admin.log').open('a') as f:
            f.write(result.stdout+result.stderr)
        if result.returncode:
            raise RuntimeError(result.stderr)
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Phobos ephemeral beta test')])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=5))
            .not_valid_after(now+datetime.timedelta(days=1))
            .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
            .add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost')]), critical=False)
            .sign(key, hashes.SHA256()))
    ca = a.out/'test-cert.pem'
    private = a.out/'test-key.pem'
    ca.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    private.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    auth = a.out/'auth.txt'
    for role in ['reader', 'writer', 'admin']:
        native('user-add', auth, role, 'ephemeral-test-password', role)
    assert '$argon2id$' in auth.read_text()
    records = []
    for cycle in range(a.cycles):
        with socket.socket() as reserve:
            reserve.bind(('127.0.0.1', 0))
            port = reserve.getsockname()[1]
        data = a.out/f'data-{cycle}'
        clients = []
        process = subprocess.Popen([str(server), '--bind', f'127.0.0.1:{port}', '--data-dir', str(data), '--auth-file', str(auth), '--tls-cert', str(ca), '--tls-key', str(private), '--max-connections', '4', '--max-result-bytes', '128', '--lock-wait-ms', '50'], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, creationflags=flags)
        try:
            line = process.stderr.readline()
            if 'listening on' not in line:
                raise RuntimeError('server startup failed: '+line)
            try:
                Client(port, ca, 'wrong-host.invalid')
                raise AssertionError('wrong TLS hostname accepted')
            except ssl.SSLCertVerificationError:
                pass
            c = Client(port, ca)
            clients.append(c)
            assert c.message(10, 'SELECT * FROM t')[0] == 255
            assert c.message(5, 'admin\0wrong')[0] == 255
            assert c.message(5, 'admin\0ephemeral-test-password')[0] == 6
            c.query('CREATE TABLE t (id BIGINT NOT NULL, value TEXT)')
            c.query('CREATE UNIQUE INDEX t_id ON t (id)')
            c.query("INSERT INTO t VALUES (1,'one')")
            for role in ['reader', 'writer']:
                other = Client(port, ca)
                clients.append(other)
                assert other.message(5, role+'\0ephemeral-test-password')[0] == 6
                assert other.query('SELECT id FROM t') == 'id\n1\n'
                if role == 'reader':
                    assert other.message(10, "INSERT INTO t VALUES (2,'forbidden')")[0] == 255
                else:
                    assert other.message(10, 'CREATE TABLE forbidden (id BIGINT)')[0] == 255
                    other.query("UPDATE t SET value='writer' WHERE id=1")
            c.query('BEGIN TRANSACTION')
            assert clients[1].message(10, 'SELECT * FROM t')[0] == 255
            c.query('ROLLBACK')
            c.query("UPDATE t SET value='"+'x'*200+"' WHERE id=1")
            assert c.message(10, 'SELECT * FROM t')[0] == 255
            c.query("UPDATE t SET value='one' WHERE id=1")
            response, metrics = c.message(20)
            assert response == 21, metrics
            assert 'lock_timeouts\t1' in metrics
            fourth = Client(port, ca)
            clients.append(fourth)
            assert fourth.message(1)[0] == 2
            try:
                fifth = Client(port, ca)
            except (ConnectionError, ssl.SSLError):
                pass
            else:
                fifth.close()
                raise AssertionError('maximum connection limit was not enforced')
            c.query('CHECKPOINT')
            locked = subprocess.run([str(admin), 'check', str(data)], capture_output=True, text=True, creationflags=flags)
            assert locked.returncode != 0 and 'in use' in locked.stderr
        finally:
            for c in clients:
                c.close()
            process.terminate()
            process.wait(timeout=15)
            process.stderr.close()
        backup = a.out/f'backup-{cycle}'
        restored = a.out/f'restored-{cycle}'
        native('check', data)
        native('backup', data, backup)
        native('restore', backup, restored)
        native('check', restored)
        # Every handle must be released before deletion. No retries.
        import shutil
        for path in [data, backup, restored]:
            shutil.rmtree(path)
        records.append(dict(cycle=cycle, status='PASS'))
        (a.out/'cycles.json').write_text(json.dumps(records, indent=2))
    private.unlink()
    print(f'BETA TLS AUTH LIFECYCLE PASS cycles={a.cycles}')


if __name__ == '__main__':
    main()
