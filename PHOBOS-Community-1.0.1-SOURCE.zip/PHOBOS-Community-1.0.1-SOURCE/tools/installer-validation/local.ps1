param(
  [Parameter(Mandatory=$true)][string]$RuntimeDirectory,
  [Parameter(Mandatory=$true)][string]$EvidenceDirectory
)
$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path $EvidenceDirectory | Out-Null
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
Copy-Item -LiteralPath (Join-Path $RuntimeDirectory 'bin\phobos-instance.exe') -Destination $EvidenceDirectory -Force
Copy-Item -LiteralPath (Join-Path $RuntimeDirectory 'bin\phobos-instance.exe.config') -Destination $EvidenceDirectory -Force
& (Join-Path $RuntimeDirectory 'bin\phobos-instance.exe') self-test
if($LASTEXITCODE -ne 0){throw 'Configuration self-tests failed'}
$runner=Join-Path $EvidenceDirectory 'portable-boundary.exe'
& $csc /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /r:System.dll /r:System.Core.dll "/r:$RuntimeDirectory\bin\phobos-instance.exe" "/out:$runner" (Join-Path $PSScriptRoot 'PortableBoundary.cs')
if($LASTEXITCODE -ne 0){throw 'Boundary test build failed'}
$instance=Join-Path $EvidenceDirectory ('direct-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
& $runner $RuntimeDirectory $instance
if($LASTEXITCODE -ne 0){throw 'Boundary tests failed'}
$render=Join-Path $EvidenceDirectory 'render-dialog.exe'
& $csc /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /r:System.dll /r:System.Core.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll "/r:$RuntimeDirectory\bin\phobos-instance.exe" "/out:$render" (Join-Path $PSScriptRoot 'RenderDialog.cs')
if($LASTEXITCODE -ne 0){throw 'Dialog render test build failed'}
& $render $EvidenceDirectory
if($LASTEXITCODE -ne 0){throw 'Dialog render failed'}
