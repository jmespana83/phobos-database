using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using Phobos.Windows;

public static class Validation {
    static string logPath;static Instance instance;static string manifest;static bool configured;
    static void Note(string s){Console.WriteLine(s);File.AppendAllText(logPath,DateTime.UtcNow.ToString("o")+" "+s+Environment.NewLine);}
    static void Assert(bool ok,string message){if(!ok)throw new Exception(message);Note("PASS "+message);}
    static int Execute(string exe,string args) {
        var pi=new ProcessStartInfo(exe,args){UseShellExecute=false,CreateNoWindow=true};
        using(var p=Process.Start(pi)){if(!p.WaitForExit(180000))throw new Exception("Installer test timed out; no process was killed.");return p.ExitCode;}
    }
    static void Reject(Action action,string label){try{action();}catch(Exception){Note("PASS rejected "+label);return;}throw new Exception("Did not reject "+label);}
    static string Query(string secret,string sql){using(var p=new Probe(instance.port)){p.Hello();p.Auth(instance.adminUser,secret);return p.Query(sql);}}
    static double Timed(string secret) {
        using(var p=new Probe(instance.port)) {p.Hello();p.Auth(instance.adminUser,secret);for(int n=0;n<50;n++)p.Query("SELECT label FROM survival WHERE id = 2");var timer=Stopwatch.StartNew();for(int n=0;n<1000;n++)p.Query("SELECT label FROM survival WHERE id = 2");timer.Stop();return timer.Elapsed.TotalMilliseconds/1000;}
    }
    public static int Main(string[] args) {
        // Only these dedicated validation locations may be mutated. No user database is selected.
        string suffix=args.Length>2?args[2]:"";
        if(!System.Text.RegularExpressions.Regex.IsMatch(suffix,"^[0-9]{0,3}$"))throw new Exception("Validation suffix must contain up to three digits.");
        string baseDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"PHOBOS-03B-Validation"+suffix);
        string install=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"PHOBOS-03B-Validation"+suffix);
        manifest=Path.Combine(baseDir,"config","instance.json");
        logPath=args[1];Directory.CreateDirectory(Path.GetDirectoryName(logPath));
        try {
            Ops.RequireAdmin();
            if(Directory.Exists(baseDir)||Directory.Exists(install))throw new Exception("Dedicated validation paths already exist. Inspect prior results and preserve data before choosing another run; refusing overwrite.");
            string installer=args[0];
            string parameters="/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /FILESONLY=1 /DIR="+Ops.Quote(install)+" /INSTANCECONFIG="+Ops.Quote(manifest);
            Assert(Execute(installer,parameters)==0,"silent runtime installation in protected custom path");
            Assert(File.Exists(Path.Combine(install,"bin","phobos-server.exe")),"installed engine executable exists");
            instance=new Instance {installDirectory=install,dataDirectory=Path.Combine(baseDir,"data custom"),logDirectory=Path.Combine(baseDir,"logs"),controlDirectory=Path.Combine(baseDir,"control"),authFile=Path.Combine(baseDir,"config","auth.txt"),runtimeConfig=Path.Combine(baseDir,"config","runtime.json"),serviceName="PHOBOSValidation03B"+suffix,port=55439,adminUser="validation_admin"};
            string secret="Validation-"+Guid.NewGuid().ToString("N");
            var occupied=new TcpListener(IPAddress.Loopback,instance.port);
            try {occupied.Start();Reject(()=>InstanceManager.Configure(manifest,instance,secret),"occupied port before initialization");}finally{occupied.Stop();}
            Assert(!File.Exists(manifest),"occupied port did not initialize metadata/data");
            InstanceManager.Configure(manifest,instance,secret);configured=true;Note("PASS clean initialization/admin/service registration/start/owned listener/auth/catalog");
            Assert(Query(secret,"SHOW CATALOG CAPABILITIES").Contains("management_api_version\t1"),"Management API v1");
            Reject(()=>Query("definitely-wrong-password","SHOW CATALOG TABLES"),"wrong administrator password");
            Query(secret,"CREATE TABLE survival (id BIGINT NOT NULL, label TEXT)");
            Query(secret,"CREATE UNIQUE INDEX survival_pk ON survival (id)");
            Query(secret,"INSERT INTO survival VALUES (1, 'first')");Query(secret,"INSERT INTO survival VALUES (2, 'second')");
            string before=Query(secret,"SELECT id, label FROM survival ORDER BY id");
            Assert(before.Contains("first")&&before.Contains("second"),"authenticated SQL data/index fixture");
            string authHash=Convert.ToBase64String(System.Security.Cryptography.SHA256.Create().ComputeHash(File.ReadAllBytes(instance.authFile)));
            InstanceManager.Stop(instance);Note("PASS SCM stop and graceful engine drain");
            Assert(Native.ListenerPid(instance.port)<0,"listener released after SCM stop");
            Ops.Run(instance.Binary("phobos-admin"),"check "+Ops.Quote(instance.dataDirectory),null);Note("PASS offline integrity before repair");
            File.WriteAllText(instance.Shutdown,"stale marker");
            InstanceManager.Configure(manifest,instance,secret);
            Assert(Query(secret,"SELECT id, label FROM survival ORDER BY id")==before,"stale shutdown marker removed on service restart; rows survived");
            InstanceManager.Stop(instance);
            Assert(Execute(installer,parameters)==0,"same-version installer repair/reinstall");
            InstanceManager.Configure(manifest,instance,secret);
            Assert(Query(secret,"SELECT id, label FROM survival ORDER BY id")==before,"data survived installer repair");
            Assert(Query(secret,"SELECT label FROM survival WHERE id = 2").Contains("second"),"indexed query survived repair");
            Assert(Query(secret,"SHOW CATALOG INDEXES FROM survival").Contains("survival_pk"),"catalog/index survived repair");
            Assert(Convert.ToBase64String(System.Security.Cryptography.SHA256.Create().ComputeHash(File.ReadAllBytes(instance.authFile)))==authHash,"authentication file preserved byte-for-byte");
            // Startup failure remains visible to SCM, then a corrected configuration starts cleanly.
            InstanceManager.Stop(instance);string runtime=File.ReadAllText(instance.runtimeConfig);
            try {File.WriteAllText(instance.runtimeConfig,"invalid-json");Reject(()=>Ops.Run(instance.Binary("phobos-instance"),"start "+Ops.Quote(manifest),null),"invalid server runtime configuration/startup failure");}
            finally{File.WriteAllText(instance.runtimeConfig,runtime);}
            InstanceManager.Configure(manifest,instance,secret);
            Assert(Query(secret,"SELECT id, label FROM survival ORDER BY id")==before,"recovery from startup failure preserves rows");
            // Deliberate failure injection, never a normal lifecycle operation.
            var host=Process.GetProcessesByName("phobos-service").Single(p=>String.Equals(p.MainModule.FileName,instance.Binary("phobos-service"),StringComparison.OrdinalIgnoreCase));
            host.Kill();host.WaitForExit();host.Dispose();
            for(int n=0;n<100&&Native.ListenerPid(instance.port)>0;n++)Thread.Sleep(50);
            Assert(Native.ListenerPid(instance.port)<0,"service-host crash containment leaves no orphaned listener");
            InstanceManager.Configure(manifest,instance,secret);
            Assert(Query(secret,"SELECT id, label FROM survival ORDER BY id")==before,"WAL recovery after deliberate service-host crash preserves committed rows");
            double hosted=Timed(secret);InstanceManager.Stop(instance);
            using(var direct=Ops.Launch(instance,s=>{})) {
                try{Ops.Ready(instance,direct,()=>{});double plain=Timed(secret);Note("MEASUREMENT 1000 indexed reads, mean ms: service="+hosted.ToString("F6",System.Globalization.CultureInfo.InvariantCulture)+", direct="+plain.ToString("F6",System.Globalization.CultureInfo.InvariantCulture)+". One short sample, not Standard certification.");}
                finally{Ops.Drain(instance,direct,()=>{});}
            }
            InstanceManager.Stop(instance);Ops.Run(instance.Binary("phobos-admin"),"check "+Ops.Quote(instance.dataDirectory),null);Note("PASS post-repair offline integrity");
            InstanceManager.Configure(manifest,instance,secret);
            string[] sensitive={instance.dataDirectory,instance.logDirectory,instance.controlDirectory,Path.GetDirectoryName(manifest)};
            foreach(string path in sensitive) {
                var acl=Directory.GetAccessControl(path);
                Assert(acl.AreAccessRulesProtected,"ACL inheritance protected: "+Path.GetFileName(path));
                string sddl=acl.GetSecurityDescriptorSddlForm(System.Security.AccessControl.AccessControlSections.Access);
                Assert(!sddl.Contains(";;;WD)")&&!sddl.Contains(";;;BU)"),"no Everyone/Users ACL on mutable/private directory: "+Path.GetFileName(path));
            }
            InstanceManager.Stop(instance);
            foreach(string file in Directory.GetFiles(baseDir,"*",SearchOption.AllDirectories)) {
                if(new FileInfo(file).Length<2000000)Assert(!Encoding.UTF8.GetString(File.ReadAllBytes(file)).Contains(secret),"no plaintext password in "+Path.GetFileName(file));
            }
            var logs=Path.Combine(Path.GetDirectoryName(logPath),"service-logs"+suffix);Directory.CreateDirectory(logs);
            foreach(string file in Directory.GetFiles(instance.logDirectory,"*.log"))File.Copy(file,Path.Combine(logs,Path.GetFileName(file)),true);
            File.WriteAllText(Path.Combine(Path.GetDirectoryName(logPath),"service-config"+suffix+".txt"),Ops.Sc("qc "+instance.serviceName)+Ops.Sc("qfailure "+instance.serviceName)+Ops.Sc("qsidtype "+instance.serviceName));
            InstanceManager.Configure(manifest,instance,secret);
            Assert(Execute(Path.Combine(install,"unins000.exe"),"/VERYSILENT /SUPPRESSMSGBOXES /NORESTART")==0,"installer uninstall-preserve-data");configured=false;
            Assert(!ServiceController.GetServices().Any(s=>s.ServiceName==instance.serviceName),"service removed");
            Assert(!File.Exists(instance.Binary("phobos-server")),"installed server binary removed");
            Assert(File.Exists(instance.authFile)&&Directory.Exists(instance.dataDirectory),"data/auth/config retained on uninstall");
            Note("PASS COMPLETE. Retained validation data: "+baseDir+". No database directory was deleted.");return 0;
        }catch(Exception e){Note("FAIL "+e.ToString());return 1;}
        finally {if(configured){try{InstanceManager.Stop(instance);Note("Cleanup: test service stopped; data retained.");}catch(Exception e){Note("Cleanup requires attention: "+e.Message);}}}
    }
}
