using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Phobos.Windows;
public static class RenderDialog {
    [STAThread] public static void Main(string[] args) {
        Application.EnableVisualStyles();
        var model=new Instance {installDirectory=@"C:\Program Files\PHOBOS",dataDirectory=@"C:\ProgramData\PHOBOS\data"};
        var type=typeof(InstanceManager).Assembly.GetType("SetupForm",true);
        foreach(bool repair in new [] {false,true})using(var form=(Form)Activator.CreateInstance(type,new object[]{@"C:\ProgramData\PHOBOS\config\instance.json",model,repair})) {
            form.ShowInTaskbar=false;form.StartPosition=FormStartPosition.Manual;form.Location=new Point(-2000,-2000);form.Show();Application.DoEvents();form.PerformLayout();
            using(var bmp=new Bitmap(form.Width,form.Height)){form.DrawToBitmap(bmp,new Rectangle(0,0,bmp.Width,bmp.Height));bmp.Save(Path.Combine(args[0],repair?"repair-dialog.png":"setup-dialog.png"));}
            form.Close();
        }
    }
}
