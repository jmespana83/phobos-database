"""Prove the distribution milestone preserves all baseline Rust/build inputs."""
import argparse, hashlib, json, pathlib, zipfile
p=argparse.ArgumentParser();p.add_argument('baseline');p.add_argument('source');p.add_argument('--binaries');p.add_argument('--manifest');a=p.parse_args()
baseline=pathlib.Path(a.baseline);source=pathlib.Path(a.source)
digest=lambda b:hashlib.sha256(b).hexdigest()
assert digest(baseline.read_bytes())=='c9907590f1003f7ee99c5e3fabb30c9de106b778d146fcba23414b8849ce4911'
count=0
with zipfile.ZipFile(baseline) as z:
    for name in z.namelist():
        if '/' not in name or name.endswith('/'):continue
        relative=name.split('/',1)[1]
        if relative.startswith('crates/') or relative in ('Cargo.toml','Cargo.lock','rust-toolchain.toml'):
            assert (source/relative).read_bytes()==z.read(name),relative
            count+=1
if a.binaries and a.manifest:
    m=json.loads(pathlib.Path(a.manifest).read_text(encoding='utf-8-sig'))
    for name,expected in m['candidate']['binaries'].items():
        assert digest((pathlib.Path(a.binaries)/name).read_bytes())==expected,name
print(f'PASS accepted baseline SHA-256 and {count} unchanged core/build files; binaries checked when supplied.')
