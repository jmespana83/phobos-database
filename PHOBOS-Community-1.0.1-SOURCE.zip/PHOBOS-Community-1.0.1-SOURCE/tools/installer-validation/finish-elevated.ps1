param(
  [Parameter(Mandatory=$true)][string]$RuntimeDirectory,
  [Parameter(Mandatory=$true)][string]$Installer,
  [Parameter(Mandatory=$true)][string]$EvidenceDirectory
)
$ErrorActionPreference='Stop'
# Review before running from an elevated PowerShell. No data is deleted.
& (Join-Path $PSScriptRoot 'cleanup.ps1')
& (Join-Path $PSScriptRoot 'run.ps1') -RuntimeDirectory $RuntimeDirectory -Installer $Installer -EvidenceDirectory $EvidenceDirectory -Suffix '2'
