using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Phobos.Windows;

public static class PortableBoundary {
    static void Assert(bool value,string label){if(!value)throw new Exception(label);Console.WriteLine("PASS "+label);}
    public static int Main(string[] args) {
        string root=Path.GetFullPath(args[1]);Directory.CreateDirectory(root);
        try {
            var i=new Instance {installDirectory=Path.GetFullPath(args[0]),dataDirectory=Path.Combine(root,"instance","data"),logDirectory=Path.Combine(root,"logs"),controlDirectory=Path.Combine(root,"control"),authFile=Path.Combine(root,"config","auth.txt"),runtimeConfig=Path.Combine(root,"config","runtime.json"),port=55441,serviceName="PHOBOSBoundary"+Guid.NewGuid().ToString("N")};
            Directory.CreateDirectory(Path.GetDirectoryName(i.authFile));Directory.CreateDirectory(i.logDirectory);Directory.CreateDirectory(i.controlDirectory);
            File.WriteAllText(i.runtimeConfig,"{}");
            string secret="Boundary-é漢字-"+Guid.NewGuid().ToString("N");
            Ops.Run(i.Binary("phobos-admin"),"init "+Ops.Quote(Path.Combine(root,"instance")),null);
            Ops.Run(i.Binary("phobos-admin"),"user-add-stdin "+Ops.Quote(i.authFile)+" admin admin",secret+"\n");
            File.WriteAllText(i.Shutdown,"stale");
            using(var server=Ops.Launch(i,s=>File.AppendAllText(Path.Combine(root,"server.log"),s+Environment.NewLine))) {
                try {
                    Ops.Ready(i,server,()=>{});Ops.ValidateLogin(i,secret);
                    bool refusal=false;try{InstanceManager.Stop(i);}catch(Exception ex){refusal=ex.Message.Contains("server process still exists");}Assert(refusal,"replacement/removal refuses an active owned server even without a registered service");
                    Assert(Native.ListenerPid(i.port)==server.Id,"owned listener readiness and stale-marker handling");
                    using(var p=new Probe(i.port)){p.Hello();p.Auth(i.adminUser,secret);p.Query("CREATE TABLE boundary_test (id BIGINT)");p.Query("INSERT INTO boundary_test VALUES (7)");Assert(p.Query("WITH q AS (SELECT id FROM boundary_test) SELECT id FROM q").Contains("7"),"native setup probe preserves 0.3-A CTE SQL and API");}
                }finally{Ops.Drain(i,server,()=>{});}
            }
            Assert(Ops.Run(i.Binary("phobos-admin"),"check "+Ops.Quote(i.dataDirectory),null).Contains("INTEGRITY OK"),"offline integrity after direct-host drain");
            using(var server=Ops.Launch(i,s=>{})) {
                try{Ops.Ready(i,server,()=>{});using(var p=new Probe(i.port)){p.Hello();p.Auth(i.adminUser,secret);Assert(p.Query("SELECT id FROM boundary_test").Contains("7"),"restart data survival via packaging launcher");}}
                finally{Ops.Drain(i,server,()=>{});}
            }
            var jobType=System.Reflection.Assembly.LoadFrom(i.Binary("phobos-service")).GetType("CrashContainment",true);
            using(var server=Ops.Launch(i,s=>{})) {
                Ops.Ready(i,server,()=>{});
                var job=Activator.CreateInstance(jobType);
                jobType.GetMethod("Assign").Invoke(job,new object[]{server});
                ((IDisposable)job).Dispose();
                Assert(server.WaitForExit(10000),"native crash-containment job terminates its child on host-handle close");
            }
            using(var server=Ops.Launch(i,s=>{})) {
                try{Ops.Ready(i,server,()=>{});using(var p=new Probe(i.port)){p.Hello();p.Auth(i.adminUser,secret);Assert(p.Query("SELECT id FROM boundary_test").Contains("7"),"WAL recovery preserves committed row after crash containment");}}
                finally{Ops.Drain(i,server,()=>{});}
            }
            var listener=new TcpListener(IPAddress.Loopback,55442);listener.Start();
            var thread=new Thread(()=>{using(var c=listener.AcceptTcpClient()){var s=c.GetStream();byte[] b=new byte[128];s.Read(b,0,b.Length);byte[] h=new byte[16];System.Text.Encoding.ASCII.GetBytes("PHOB").CopyTo(h,0);h[4]=1;h[5]=2;h[11]=1;h[12]=127;s.Write(h,0,16);}});thread.Start();
            bool rejected=false;try{using(var p=new Probe(55442))p.Hello();}catch(IOException){rejected=true;}finally{thread.Join();listener.Stop();}
            Assert(rejected,"oversized protocol response rejected before allocation");
            foreach(string file in Directory.GetFiles(root,"*",SearchOption.AllDirectories))if(new FileInfo(file).Length<2000000)Assert(!System.Text.Encoding.UTF8.GetString(File.ReadAllBytes(file)).Contains(secret),"no plaintext secret persisted: "+Path.GetFileName(file));
            return 0;
        }catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
