param(
  [Parameter(Mandatory=$true)][string]$RuntimeDirectory,
  [Parameter(Mandatory=$true)][string]$Installer,
  [Parameter(Mandatory=$true)][string]$EvidenceDirectory,
  [ValidatePattern('^[0-9]{0,3}$')][string]$Suffix=''
)
$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path $EvidenceDirectory | Out-Null
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$runner=Join-Path $EvidenceDirectory 'installer-validation.exe'
& $csc /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /r:System.dll /r:System.Core.dll /r:System.ServiceProcess.dll "/r:$RuntimeDirectory\bin\phobos-instance.exe" "/out:$runner" (Join-Path $PSScriptRoot 'Validation.cs')
if($LASTEXITCODE -ne 0){throw 'Validation runner compilation failed'}
Copy-Item -LiteralPath (Join-Path $RuntimeDirectory 'bin\phobos-instance.exe') -Destination $EvidenceDirectory -Force
Copy-Item -LiteralPath (Join-Path $RuntimeDirectory 'bin\phobos-instance.exe.config') -Destination $EvidenceDirectory -Force
$log=Join-Path $EvidenceDirectory 'installer-validation.log'
& $runner $Installer $log $Suffix
if($LASTEXITCODE -ne 0){throw "Installer validation failed; inspect $log"}
