param([ValidatePattern('^[0-9]{0,3}$')][string]$Suffix='')
$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if(-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Run as administrator. This script only uninstalls the dedicated validation product; it never deletes data.'}
$install=Join-Path $env:ProgramFiles ('PHOBOS-03B-Validation'+$Suffix)
$expected=[IO.Path]::GetFullPath($install)
if(-not $expected.StartsWith([IO.Path]::GetFullPath($env:ProgramFiles).TrimEnd('\')+'\PHOBOS-03B-Validation',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected cleanup target'}
$uninstaller=Join-Path $expected 'unins000.exe'
if(Test-Path -LiteralPath $uninstaller){
  $process=Start-Process -FilePath $uninstaller -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -WindowStyle Hidden -Wait -PassThru
  if($process.ExitCode -ne 0){throw "Validation uninstall failed: $($process.ExitCode)"}
}
$service='PHOBOSValidation03B'+$Suffix
if(Get-Service -Name $service -ErrorAction SilentlyContinue){throw 'Validation service remains; inspect SCM and logs. No data was deleted.'}
if(Test-Path -LiteralPath (Join-Path $expected 'bin\phobos-server.exe')){throw 'Validation binary remains'}
Write-Output "PASS validation service/binaries removed. Database, auth, config and logs retained in ProgramData\PHOBOS-03B-Validation$Suffix."
