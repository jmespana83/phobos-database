param([string]$Python='python',[Parameter(Mandatory=$true)][string]$EvidenceDirectory)
$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
function Native([string]$Name,[scriptblock]$Command){ & $Command; if($LASTEXITCODE -ne 0){throw "$Name failed: $LASTEXITCODE"} }
Native 'formatting' {cargo fmt --all -- --check}
Native 'strict Clippy' {cargo clippy --workspace --all-targets --all-features -- -D warnings}
Native 'workspace tests' {cargo test --workspace}
& "$PSScriptRoot/phase8-validation.ps1" -Python $Python
if(-not $?){throw 'Phase 8 validation failed'}
# Evidence is mandatory. Missing results are failures, never silent skips.
$fingerprint=Join-Path $EvidenceDirectory 'campaign-source.json'
if(-not(Test-Path -LiteralPath $fingerprint)){throw 'Missing source fingerprint for long campaigns'}
$recorded=@(Get-Content $fingerprint -Raw | ConvertFrom-Json)
$current=@(& "$PSScriptRoot/beta-source-fingerprint.ps1")
if(($current|ConvertTo-Json -Compress) -ne ($recorded|ConvertTo-Json -Compress)){throw 'Long campaign evidence belongs to a different source state'}
foreach($scale in @('1m','10m')){
 $proof=Join-Path $EvidenceDirectory "correctness-$scale/PASS.txt"
 if(-not(Test-Path -LiteralPath $proof)){throw "Missing large correctness evidence: $proof"}
 $rows=if($scale -eq '1m'){1000000}else{10000000}
 if((Get-Content $proof -Raw).Trim() -ne "beta correctness PASS rows=$rows seed=8067"){throw "Invalid correctness evidence: $proof"}
 $resource=Get-Content (Join-Path $EvidenceDirectory "$scale/resources.json") -Raw | ConvertFrom-Json
 if($resource.timeout -or $resource.exit_code -ne 0){throw "Failed $scale benchmark campaign"}
 $metadata=Get-Content (Join-Path $EvidenceDirectory "$scale/environment.json") -Raw | ConvertFrom-Json
 $expected=@($current|Where-Object {$_.path.StartsWith('crates/')})
 if(@($metadata.source_files).Count -ne $expected.Count){throw "Stale $scale source inventory"}
 foreach($file in $metadata.source_files){
  $match=@($expected|Where-Object path -eq $file.path.Replace('\','/'))
  if($match.Count -ne 1 -or $match[0].sha256 -ne $file.sha256){throw "Stale $scale executable source: $($file.path)"}
 }
}
$cycles=@(Import-Csv (Join-Path $EvidenceDirectory 'crash/cycles.csv'))
if($cycles.Count -lt 100 -or @($cycles|Where-Object outcome -ne 'PASS').Count){throw 'Crash certification incomplete'}
$soak=Get-Content (Join-Path $EvidenceDirectory 'soak/result.json') -Raw | ConvertFrom-Json
if($soak.status -ne 'PASS' -or -not $soak.two_hour_gate){throw 'Two-hour soak incomplete'}
Native 'resource regression' {cargo test -p phobos-server beta_}
$run=Join-Path target ('beta-security-'+[guid]::NewGuid().ToString('N'))
Native 'live TLS/auth/operations lifecycle' {& $Python tools/beta-security.py --out $run --cycles 25}
Native 'documentation' {cargo doc --workspace --no-deps}
Native 'release build' {cargo build --release --workspace}
$package=Join-Path target ('beta-package-'+[guid]::NewGuid().ToString('N'))
& "$PSScriptRoot/package-beta.ps1" -Python $Python -OutputDirectory $package
if(-not $?){throw 'Package verification failed'}
Write-Host 'PHOBOS BETA CERTIFICATION COMPLETED SUCCESSFULLY'
