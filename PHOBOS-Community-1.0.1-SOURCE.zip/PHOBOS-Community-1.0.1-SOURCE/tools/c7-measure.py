"""Sequential C7-only 100K/1M comparison. Does not invoke PostgreSQL or long soaks."""
import argparse
import csv
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def peak_memory(pid):
    if os.name != 'nt':
        return None
    class Counters(ctypes.Structure):
        _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in (
                'PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
                'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
                'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage')]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x410, False, pid)
    if not handle:
        return None
    try:
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        query = ctypes.WinDLL('psapi').GetProcessMemoryInfo
        query.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        if query(handle, ctypes.byref(counters), counters.cb):
            return counters.PeakWorkingSetSize
    finally:
        kernel.CloseHandle(handle)
    return None


def profile(path):
    with path.open(newline='') as stream:
        return {r['span']: (int(r['calls_or_units']), int(r['inclusive_wall_ns']))
                for r in csv.DictReader(stream)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--resume', action='store_true', help='reuse verified results from this exact binary')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    exe = root / 'target/release/phobos-bench.exe'
    if os.name != 'nt':
        exe = exe.with_suffix('')
    digest = hashlib.sha256(exe.read_bytes()).hexdigest()
    out = args.output.resolve()
    if out.exists():
        if not args.resume:
            raise RuntimeError('existing output requires --resume; successful measurements are never repeated')
        assert json.loads((out/'run.json').read_text())['executable_sha256'] == digest
    else:
        out.mkdir(parents=True)
    (out / 'run.json').write_text(json.dumps({
        'executable_sha256': digest, 'rows': [100000, 1000000],
        'plan': [['c7-bulk', 100000], ['c7-ordinary', 100000], ['c7-bulk', 1000000]],
        'comparison': 'same rows/indexes; bulk one commit; ordinary 256 rows/commit',
        'memory': 'OS peak working set sampled through entire child including verification',
        'profiling': 'build with --features profiling; before/after counter deltas'}, indent=2))
    results = []
    for rows in [100000, 1000000]:
        for mode in (['c7-bulk', 'c7-ordinary'] if rows == 100000 else ['c7-bulk']):
            name = f'{mode}-{rows}'
            saved = out / (name + '.json')
            if saved.exists() and (out / (name + '.verified.txt')).exists():
                results.append(json.loads(saved.read_text()))
                print('REUSE ' + name, flush=True)
                continue
            if (out / (name + '-db')).exists():
                raise RuntimeError(f'{name}: incomplete prior measurement requires review; refusing automatic repeat')
            command = [str(exe), '--mode', mode, '--rows', str(rows),
                       '--dir', str(out / (name + '-db')), '--output', str(out / (name + '.csv'))]
            print('START ' + name, flush=True)
            peak = None
            with (out / (name + '.log')).open('w') as log:
                process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
                while process.poll() is None:
                    value = peak_memory(process.pid)
                    if value is not None:
                        peak = max(peak or 0, value)
                    time.sleep(0.25)
            if process.returncode:
                raise RuntimeError(f'{name} exit={process.returncode}; inspect log')
            assert (out / (name + '.verified.txt')).exists()
            before = profile(out / (name + '.before.csv'))
            after = profile(out / (name + '.after.csv'))
            deltas = {key: {'calls_or_units': after[key][0] - before.get(key, (0, 0))[0],
                            'inclusive_wall_ns': after[key][1] - before.get(key, (0, 0))[1]}
                      for key in after}
            with (out / (name + '.csv')).open(newline='') as stream:
                result = next(csv.DictReader(stream))
            result.update(peak_working_set_bytes=peak, metrics=deltas)
            (out / (name + '.json')).write_text(json.dumps(result, indent=2))
            results.append(result)
            print(f'PASS {name}: {result["rows_per_second"]} rows/s, peak={peak}', flush=True)
    assert hashlib.sha256(exe.read_bytes()).hexdigest() == digest, 'binary changed during run'
    (out / 'summary.json').write_text(json.dumps(results, indent=2))
    (out / 'MEASUREMENTS-COMPLETE.txt').write_text('100K bulk/ordinary pair and single 1M bulk import plus reopen/integrity checks passed. No 1M ordinary run.\n')


if __name__ == '__main__':
    main()
