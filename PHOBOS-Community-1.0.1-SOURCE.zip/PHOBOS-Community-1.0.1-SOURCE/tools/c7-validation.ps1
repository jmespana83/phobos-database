param([string]$Evidence = 'c7-gate')
$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
$Evidence=[IO.Path]::GetFullPath($Evidence)
if(Test-Path -LiteralPath $Evidence) { throw 'Evidence directory must be new' }
New-Item -ItemType Directory -Path $Evidence | Out-Null
Push-Location $repo
try {
    $steps=@(
        @{Name='fmt'; Args=@('fmt','--all')},
        @{Name='fmt-check'; Args=@('fmt','--all','--','--check')},
        @{Name='clippy'; Args=@('clippy','--workspace','--all-targets','--all-features','--','-D','warnings')},
        @{Name='tests'; Args=@('test','--workspace')},
        @{Name='docs'; Args=@('doc','--workspace','--no-deps')},
        @{Name='release'; Args=@('build','--release','--workspace')}
    )
    foreach($step in $steps) {
        $arguments=$step.Args
        & cargo @arguments *> (Join-Path $Evidence ($step.Name+'.log'))
        if($LASTEXITCODE -ne 0) { throw ('Failed '+$step.Name) }
        Write-Output ($step.Name+' PASS')
    }
    'PHOBOS C7 BUILD AND CORRECTNESS GATE PASSED; measurements still required' | Set-Content (Join-Path $Evidence 'PASSED.txt')
} finally { Pop-Location }
