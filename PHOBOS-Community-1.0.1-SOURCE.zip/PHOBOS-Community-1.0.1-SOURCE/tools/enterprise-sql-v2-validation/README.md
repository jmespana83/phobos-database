# Enterprise SQL V2 validation

Run from the source root. Rust 1.85.0 is pinned; cached dependencies permit adding `--offline`. On Windows use an MSVC developer environment, a short CARGO_TARGET_DIR, and the inherited AWS_LC_SYS_PREBUILT_NASM=1 setting if NASM is unavailable. Do not weaken release TLS dependencies.

- `./tools/enterprise-sql-v2-validation/test.ps1`: permanent parser/catalog/semantic/transaction/concurrency/crash/recovery/PITR/replication tests.
- Add `-Full` for inherited workspace regression tests.
- `sh tools/enterprise-sql-v2-validation/test.sh`: platform-neutral Rust tests (not a claim of Linux/macOS execution here).
- `./tools/enterprise-sql-v2-validation/run.ps1 -Mode Smoke -Binaries <absolute-release-bin> -WorkRoot <fresh-validation-parent> -Port 55436`: isolated actual server/CLI default/CHECK/PK, forced termination, restart, backup/restore and integrity validation.
- `./tools/enterprise-sql-v2-validation/run.ps1 -Mode Standard -Binaries <absolute-release-bin> -WorkRoot <validation-parent> -SuiteRoot C:\PHOBOS-BENCH-v1.3.2 -Port 55436 -SourceArchive <delivered-source.zip>`: unmodified frozen benchmark defaults, synchronous server settings. Internal suite identity is 1.3.1-G56. Optional `-CheckBenchmarkData` performs a separate offline full scan after the benchmark.
- `./tools/enterprise-sql-v2-validation/standard.ps1 -Suite "<explicit frozen command>"`: manual-command compatibility wrapper; never guesses a command.
- `dotnet run --project tools/enterprise-sql-v2-validation/client/StudioValidation.csproj -c Release -- <absolute-release-bin> <fresh-evidence-dir>`: unchanged 0.3-D Core protocol/catalog/script/result/cancel/crash compatibility. The test intentionally expects unknown-engine templates to remain disabled.

No identity, foreign-key, view, RETURNING or advanced-query support is claimed. Unsupported declarations are covered by negative tests; they have no fake positive fixtures. Inherited query combinations are exercised in the workspace and unchanged-client suites.

Keep test instances isolated. The Windows wrapper creates fresh timestamped instance directories and stops only the child server it starts. Credentials are generated for each run, retained in memory, supplied to account creation on stdin, and restored/cleared from the child environment afterward. Source packaging excludes all instances, temporary auth stores, build caches and client profile fixtures.

Read the milestone TEST-RESULTS and PERFORMANCE documents for actual commands, logs, platform limits and any failed initial attempts.

For matched comparisons, `benchmark-series.ps1 -Candidate <bin> -Control <accepted-bin> -WorkRoot <validation-parent> -Pairs 2` runs the entire frozen suite serially. It records completed runs and can resume; timestamped run folders are distinguished from generated standard-data. `-Pairs 3 -CandidateFirst` resumes with an additional reverse-order pair when investigating an unresolved signal. All runs remain in evidence. `report-performance.py <validation-parent>` verifies all raw statuses, zero query errors and six result hashes before summarizing all paired values. It marks thresholds exceeded in at least two matched pairs; aggregate values and historical-reference differences remain visible regardless of that flag.
