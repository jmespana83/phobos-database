"""Compare frozen summaries; never change benchmark measurements."""
import argparse,csv,json,statistics
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument("evidence",type=Path);a=ap.parse_args();root=a.evidence
runs=json.loads((root/"benchmark-runs.json").read_text(encoding="utf-8-sig"))
refs={k:json.loads((root/n).read_text()) for k,n in [("K5","reference-standard-k5.json"),("03A","reference-standard-03a.json")]}
def metrics(d):
    out={}
    for n,v in d["bulk"].items():out["bulk/"+n]=(v["median_seconds"],5,"s")
    for n,v in d["queries"].items():
        if isinstance(v,dict):out["read/"+n]=(v.get("median_seconds",v.get("mean_ms")),5,"s" if "median_seconds" in v else "ms")
    for n,v in d["writes"].items():out["write/"+n]=(v.get("seconds",v.get("wall_seconds")),5,"s")
    for n,v in d["oltp"].items():out["oltp/"+n]=(v["wall_seconds"],8,"s")
    return out
reference_metrics={k:metrics(v) for k,v in refs.items()};samples={};correctness=[]
for run in runs:
    result=Path(run["directory"])/"results";d=json.loads((result/"summary.json").read_text())
    assert d["benchmark_version"]=="1.3.1-G56"
    errors=d["phobos_metrics_delta"]["query_errors"];assert errors==0,(run,errors)
    hashes=0
    for name,v in refs["K5"]["queries"].items():
        if isinstance(v,dict) and "sha256" in v:assert d["queries"][name]["sha256"]==v["sha256"];hashes+=1
    with (result/"raw.csv").open(encoding="utf-8-sig",newline="") as f:raw=list(csv.DictReader(f))
    assert raw and all(r["status"]=="ok" for r in raw),(run,"raw status failure")
    samples[(run["label"],run["pair"])]=metrics(d)
    correctness.append(dict(label=run["label"],pair=run["pair"],query_errors=errors,matching_hashes=hashes,raw_rows=len(raw),all_raw_ok=True))
pairs=sorted({pair for label,pair in samples})
assert len(pairs)>=2 and all((label,i) in samples for label in ["control","candidate"] for i in pairs),"Expected complete matched pairs"
rows=[]
for name,(ref,threshold,unit) in reference_metrics["K5"].items():
    controls=[samples[("control",i)][name][0] for i in pairs];candidates=[samples[("candidate",i)][name][0] for i in pairs]
    ctrl=statistics.median(controls);cand=statistics.median(candidates);paired=[(e/c-1)*100 for c,e in zip(controls,candidates)]
    rows.append(dict(name=name,unit=unit,k5=ref,a03=reference_metrics["03A"][name][0],control_median=ctrl,candidate_median=cand,paired_percent=paired,matched_percent=(cand/ctrl-1)*100,k5_percent=(cand/ref-1)*100,a03_percent=(cand/reference_metrics["03A"][name][0]-1)*100,threshold_percent=threshold,reproducible_flag=sum(d>threshold for d in paired)>=2))
(root/"performance-flags.json").write_text(json.dumps(dict(correctness=correctness,rows=rows,reproducible_flags=[r for r in rows if r["reproducible_flag"]]),indent=2),encoding="utf-8")
with (root/"comparison-all.csv").open("w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
text="| Workload | Unit | K.5 Oct 23 | 0.3-A Oct 23 | Fresh control median | 0.3-E median | E vs fresh | E vs K.5 | E vs 0.3-A | Individual pair changes |\n|---|---|---:|---:|---:|---:|---:|---:|---:|---|\n"
for r in rows:
    text+=f"| {r['name']} | {r['unit']} | {r['k5']:.6f} | {r['a03']:.6f} | {r['control_median']:.6f} | {r['candidate_median']:.6f} | {r['matched_percent']:+.1f}% | {r['k5_percent']:+.1f}% | {r['a03_percent']:+.1f}% | {' / '.join(f'{d:+.1f}%' for d in r['paired_percent'])} |\n"
(root/"performance-comparison.md").write_text(text,encoding="utf-8")
print(json.dumps(dict(correctness=correctness,reproducible_flags=[r for r in rows if r['reproducible_flag']]),indent=2))
