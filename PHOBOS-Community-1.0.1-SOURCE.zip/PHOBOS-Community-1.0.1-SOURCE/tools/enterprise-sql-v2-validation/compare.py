"""Compare unchanged Standard 1.3.1-G56 summaries; does not rerun or alter workloads."""
import argparse, csv, json
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument("reference",type=Path)
parser.add_argument("candidate",type=Path)
parser.add_argument("--out",type=Path,required=True)
a=parser.parse_args()
r=json.loads(a.reference.read_text(encoding="utf-8-sig"));c=json.loads(a.candidate.read_text(encoding="utf-8-sig"))
assert r["benchmark_version"]==c["benchmark_version"]=="1.3.1-G56"
rows=[]
def add(group,name,metric,ref,cur,threshold):
    delta=(cur/ref-1)*100
    rows.append(dict(group=group,name=name,metric=metric,reference=ref,candidate=cur,percent_slower=delta,flag=delta>threshold,threshold_percent=threshold))
for name,ref in r["bulk"].items():add("bulk",name,"median_seconds",ref["median_seconds"],c["bulk"][name]["median_seconds"],5)
for name,ref in r["queries"].items():
    if not isinstance(ref,dict):continue
    if "sha256" in ref:assert ref["sha256"]==c["queries"][name]["sha256"],(name,"result hash differs")
    metric="median_seconds" if "median_seconds" in ref else "mean_ms"
    add("read",name,metric,ref[metric],c["queries"][name][metric],5)
for name,ref in r["writes"].items():
    metric="seconds" if "seconds" in ref else "wall_seconds"
    add("write",name,metric,ref[metric],c["writes"][name][metric],5)
for name,ref in r["oltp"].items():add("oltp",name,"wall_seconds",ref["wall_seconds"],c["oltp"][name]["wall_seconds"],8)
a.out.parent.mkdir(parents=True,exist_ok=True)
with a.out.open("w",newline="",encoding="utf-8") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps({"reference":str(a.reference),"candidate":str(a.candidate),"flags":[r for r in rows if r["flag"]]},indent=2))
