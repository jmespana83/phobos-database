"""Package only this milestone; verify all accepted 0.3-D outputs remain unchanged."""
import argparse, hashlib, json, shutil, zipfile
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument("--work-root",type=Path,required=True);args=ap.parse_args()
source=Path(__file__).resolve().parents[2];work=args.work_root.resolve();out=work/"outputs";validation=work/"validation-03e"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prior=out/"PHOBOS-0.3-D-FINAL-HASHES.txt"
prior_count=0
for line in prior.read_text(encoding="utf-8-sig").splitlines():
    if len(line)>66 and line[64:66]=="  ":
        expected,name=line.split("  ",1);assert sha(out/name)==expected,(name,"accepted output changed");prior_count+=1
baseline=out/"PHOBOS-Community-0.3-D-ManagementStudioV2-SOURCE.zip"
assert sha(baseline)=="9b8411867080d6c8335b9ad1c6c829360980bb7fd94689ad93662c4f14aa057f"
harness=json.loads((validation/"benchmark-harness.json").read_text())
for n,h in harness["sha256"].items():assert sha(Path(harness["root"])/n)==h,(n,"frozen harness changed")
manifest=json.loads((validation/"tested-source-manifest.json").read_text())
for name,expected in manifest.items():assert sha(source/name)==expected,(name,"changed after validation manifest")
# Explicit evidence allowlist; never collect test databases, auth files or profiles.
evidence=source/"evidence-03e";evidence.mkdir(exist_ok=True)
for name in ["schema-final.log","workspace-final.log","format.log","benchmark-harness.json","reference-standard-k5.json","reference-standard-03a.json","clippy.log","build-final.log","smoke-final.log","studio-compat-final.log","tested-source-manifest.json","candidate-binaries.json","accepted-control-binaries.json","benchmark-runs.json","performance-comparison.md","performance-flags.json"]:
    p=validation/name
    if p.is_file():shutil.copy2(p,evidence/name)
for p in validation.glob("comparison-*.csv"):shutil.copy2(p,evidence/p.name)
for p in validation.glob("standard-*.log"):shutil.copy2(p,evidence/p.name)
for p in validation.glob("**/results/summary.json"):
    # Both candidate and control wrappers use timestamped isolated runs.
    rel=p.parent.parent.relative_to(validation);dest=evidence/"benchmarks"/rel;dest.mkdir(parents=True,exist_ok=True)
    for name in ["summary.json","raw.csv","environment.json","command.json","plans.json"]:
        f=p.parent/name
        if f.is_file():shutil.copy2(f,dest/name)
(evidence/"boundary-verification.json").write_text(json.dumps({"baseline_sha256":sha(baseline),"prior_artifacts_verified":prior_count,"tested_source_files_verified":len(manifest)},indent=2),encoding="utf-8")
# Required files must exist before archiving.
required=[f"PHOBOS-0.3-E-{name}.md" for name in ["ARCHITECTURE","SQL-COMPATIBILITY","CATALOG-FORMAT","RECOVERY-VALIDATION","PERFORMANCE","TEST-RESULTS","FINAL-REPORT"]]+["PHOBOS-CODEX-HANDOFF.md"]
for name in required:assert (source/name).is_file(),name
excluded={".git","target","obj","__pycache__"}
def source_files():
    files=[]
    for p in source.rglob("*"):
        parts=p.relative_to(source).parts
        if not p.is_file() or any(x in excluded for x in parts):continue
        # Preserve Rust src/bin source targets; exclude only generated .NET bin trees.
        if "bin" in parts and parts[0] in {"studio","tools"}:continue
        files.append(p)
    return sorted(files)
old={}
with zipfile.ZipFile(baseline) as z:
    for name in z.namelist():
        if name.endswith("/"):continue
        parts=name.split("/");rel="/".join(parts[1:]) if parts[0].startswith("PHOBOS-Community-") else name
        old[rel]=hashlib.sha256(z.read(name)).hexdigest()
protected_prefixes=("crates/phobos-storage/","crates/phobos-wal/","crates/phobos-index/","crates/phobos-txn/","crates/phobos-protocol/","crates/phobos-client/","crates/phobos-server/","crates/phobos-auth/","crates/phobos-types/","crates/phobos-config/","studio/","packaging/")
protected={n:h for n,h in old.items() if n.startswith(protected_prefixes)}
for n,h in protected.items():assert sha(source/n)==h,(n,"protected subsystem changed")
(evidence/"boundary-verification.json").write_text(json.dumps({"baseline_sha256":sha(baseline),"prior_artifacts_verified":prior_count,"tested_source_files_verified":len(manifest),"protected_files_unchanged":len(protected),"protected_prefixes":protected_prefixes},indent=2),encoding="utf-8")
changed=[]
for p in source_files():
    name=p.relative_to(source).as_posix()
    if name=="PHOBOS-0.3-E-CHANGED-FILES.txt":continue
    if name not in old:changed.append("ADDED    "+name)
    elif sha(p)!=old[name]:changed.append("MODIFIED "+name)
for name in old:
    if not (source/name).is_file():changed.append("REMOVED  "+name)
changed.append("ADDED    PHOBOS-0.3-E-CHANGED-FILES.txt")
(source/"PHOBOS-0.3-E-CHANGED-FILES.txt").write_text("Compared byte-for-byte with accepted 0.3-D source.\n\n"+"\n".join(sorted(changed))+"\n",encoding="utf-8")
for name in required:
    dest=out/"0.3-E"/name if name=="PHOBOS-CODEX-HANDOFF.md" else out/name
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,dest)
shutil.copy2(source/"PHOBOS-0.3-E-CHANGED-FILES.txt",out/"PHOBOS-0.3-E-CHANGED-FILES.txt")
shutil.copytree(evidence,out/"evidence-03e",dirs_exist_ok=True)
archive=out/"PHOBOS-Community-0.3-E-EnterpriseSQLSchemaV2-SOURCE.zip"
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in source_files():z.write(p,source.name+"/"+p.relative_to(source).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,expected in manifest.items():assert hashlib.sha256(z.read(source.name+"/"+name)).hexdigest()==expected,(name,"archive source mismatch")
    for name in old:
        if (source/name).is_file():assert source.name+"/"+name in z.namelist(),(name,"baseline source omitted")
runtime=out/"PHOBOS-Community-0.3-E-Windows-x64-VALIDATION-RUNTIME.zip"
binary_manifest=json.loads((validation/"candidate-binaries.json").read_text())
with zipfile.ZipFile(runtime,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,expected in binary_manifest["sha256"].items():
        p=Path(binary_manifest["path"])/name;assert sha(p)==expected;z.write(p,"bin/"+name)
    z.write(source/"LICENSE","LICENSE")
    z.writestr("README.txt","PHOBOS 0.3-E EXPERIMENTAL candidate Windows x64 validation runtime. Promotion held for unresolved write-performance regression. Unsigned; not an installer or automatic upgrade. Requires a compatible Windows MSVC runtime. Do not replace an accepted server automatically. Catalog v4 requires a pre-upgrade backup for downgrade. See the source milestone documentation and final report.\n")
    z.writestr("BUILD.json",json.dumps(binary_manifest,indent=2))
files=[archive,runtime,out/"PHOBOS-0.3-E-CHANGED-FILES.txt",*(out/name for name in required if name!="PHOBOS-CODEX-HANDOFF.md"),out/"0.3-E/PHOBOS-CODEX-HANDOFF.md",*(p for p in (out/"evidence-03e").rglob("*") if p.is_file())]
text="SHA-256 of final bytes. External manifest; no self/circular hash. Candidate is not automatically promoted.\n\n"
text+="".join(sha(p)+"  "+p.relative_to(out).as_posix()+"\n" for p in sorted(files))
(out/"PHOBOS-0.3-E-FINAL-HASHES.txt").write_text(text,encoding="utf-8")
print(json.dumps({"source":str(archive),"source_sha256":sha(archive),"runtime":str(runtime),"runtime_sha256":sha(runtime),"files_hashed":len(files),"prior_verified":prior_count},indent=2))
