using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Buffers.Binary;
using System.Text;
using Phobos.Studio.Core;

class Validation {
    static string root="",bin="",secret="";static Process? server;static int port;static Profile profile=null!;
    static void Pass(bool ok,string name){if(!ok)throw new Exception(name);Console.WriteLine("PASS "+name);}
    static async Task<string> Run(string exe,string[] args,string? input=null){var pi=new ProcessStartInfo(exe){UseShellExecute=false,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true,CreateNoWindow=true,StandardInputEncoding=new UTF8Encoding(false)};foreach(var a in args)pi.ArgumentList.Add(a);using var p=Process.Start(pi)!;var o=p.StandardOutput.ReadToEndAsync();var e=p.StandardError.ReadToEndAsync();if(input!=null)await p.StandardInput.WriteAsync(input);p.StandardInput.Close();await p.WaitForExitAsync();if(p.ExitCode!=0)throw new Exception(Path.GetFileName(exe)+": "+await e);return await o;}
    static async Task Start(){string shutdown=Path.Combine(root,"shutdown");if(File.Exists(shutdown))File.Delete(shutdown);var pi=new ProcessStartInfo(Path.Combine(bin,"phobos-server.exe")){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};foreach(var a in new[]{"--data-dir",Path.Combine(root,"instance","data"),"--auth-file",Path.Combine(root,"auth.txt"),"--shutdown-file",shutdown,"--bind","127.0.0.1:"+port,"--wal-mode","flush"})pi.ArgumentList.Add(a);server=Process.Start(pi)!;server.OutputDataReceived+=(_,e)=>{if(e.Data!=null)lock(typeof(Validation))File.AppendAllText(Path.Combine(root,"server.log"),e.Data+"\n");};server.ErrorDataReceived+=(_,e)=>{if(e.Data!=null)lock(typeof(Validation))File.AppendAllText(Path.Combine(root,"server.log"),e.Data+"\n");};server.BeginOutputReadLine();server.BeginErrorReadLine();for(int n=0;n<100;n++){try{using var c=await ProtocolClient.ConnectAsync(profile,secret);return;}catch{if(server.HasExited)throw new Exception("Fixture server exited.");await Task.Delay(100);}}throw new Exception("Fixture did not start.");}
    static async Task Stop(){if(server==null||server.HasExited)return;await File.WriteAllTextAsync(Path.Combine(root,"shutdown"),"stop");await server.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30));server.Dispose();server=null;}
    static async Task<StudioSession> Connect(){var s=new StudioSession();await s.ConnectAsync(profile,secret);return s;}
    public static async Task<int> Main(string[] args){try{
        if(args.Length==1&&args[0]=="--protocol-faults"){await ProtocolFaults.Run();return 0;}
        bin=Path.GetFullPath(args[0]);root=Path.GetFullPath(args[1]);if(Directory.Exists(root))throw new Exception("Use a fresh evidence directory.");Directory.CreateDirectory(root);secret="Studio-漢字-é-"+Guid.NewGuid().ToString("N");var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();profile=new("Validation","localhost",port,"admin");
        await Run(Path.Combine(bin,"phobos-admin.exe"),["init",Path.Combine(root,"instance")]);await Run(Path.Combine(bin,"phobos-admin.exe"),["user-add-stdin",Path.Combine(root,"auth.txt"),"admin","admin"],secret+"\n");await Start();
        using(var s=await Connect()){
            Pass(s.MetadataSupported&&!s.KnownDdl,"authenticated hostname/port connection; API v1; unknown engine keeps SQL and disables templates");
            await s.ExecuteAsync("CREATE TABLE studio_types (id BIGINT NOT NULL, active BOOLEAN, score DOUBLE, name TEXT, empty TEXT, missing TEXT, day DATE, stamp TIMESTAMP, amount DECIMAL(20,4), bytes BINARY)");
            await s.ExecuteAsync("CREATE UNIQUE INDEX studio_id ON studio_types (id)");
            await s.ExecuteAsync("INSERT INTO studio_types VALUES (1,true,1.25,'Ada 漢字 🚀','',NULL,'2026-10-23','2026-10-23 12:34:56','123456789012.3456','abc')");
            var r=await s.ExecuteAsync("SELECT * FROM studio_types");Pass(r.Rows.Count==1&&r.Rows[0].Select(c=>c.Tag).SequenceEqual(new byte[]{1,2,3,4,4,0,6,7,8,5}),"all nine wire value types, Unicode, NULL versus empty text");Pass(r.Rows[0][8].Text=="123456789012.3456","decimal preserves exact scale and precision");
            await s.ExecuteAsync("UPDATE studio_types SET score=2.5 WHERE id=1");
            await s.ExecuteAsync("BEGIN");await s.ExecuteAsync("INSERT INTO studio_types (id,name) VALUES (2,'rollback')");await s.ExecuteAsync("ROLLBACK");Pass((await s.ExecuteAsync("SELECT * FROM studio_types")).Rows.Count==1,"transaction rollback on same persistent session");
            foreach(string q in new[]{"WITH q AS (SELECT id FROM studio_types) SELECT id FROM q","SELECT a.id FROM studio_types a JOIN studio_types b ON a.id=b.id","SELECT id FROM studio_types WHERE id=(SELECT MAX(id) FROM studio_types)"})Pass((await s.ExecuteAsync(q)).Rows.Count==1,"SQL: "+q);
            var c=await s.CatalogAsync();Pass(c["TABLES"].Count==1&&c["COLUMNS"].Count==10&&c["INDEXES"].Count==1&&c["CONSTRAINTS"].Count==2,"all catalog collections reflect real schema");
            await s.ExecuteAsync("ALTER TABLE studio_types RENAME COLUMN name TO display_name");Pass((await s.CatalogAsync())["COLUMNS"].Any(x=>x["column_name"]=="display_name"),"metadata refresh after transactional DDL");
            await s.ExecuteAsync("CREATE TABLE many (id BIGINT)");for(int batch=0;batch<50;batch++)await s.ExecuteAsync("INSERT INTO many VALUES "+string.Join(",",Enumerable.Range(batch*100,100).Select(i=>"("+i+")")));
            int progress=0;Pass((await s.ExecuteAsync("SELECT * FROM many",_=>progress++)).Rows.Count==5000&&progress>1,"5,000 streamed rows across bounded batches");
        }
        foreach(string bad in new[]{"SELEC broken","SELECT * FROM missing_table"}){using var s=await Connect();try{await s.ExecuteAsync(bad);throw new Exception("Expected rejection");}catch(PhobosException){Pass(!s.Connected,"SQL error poisons session; reconnect explicit");}}
        try{using var p=await ProtocolClient.ConnectAsync(profile,"wrong-password");throw new Exception("Expected auth rejection");}catch(PhobosException e){Pass(e.Code=="Authentication"&&!e.Message.Contains("wrong-password"),"wrong password rejected without reflecting secret");}
        using(var p=await ProtocolClient.ConnectAsync(profile,secret)){try{await p.QueryAsync("SELECT * FROM many",rowLimit:10);throw new Exception("Expected client budget");}catch(PhobosException e){Pass(e.Code=="ClientLimit"&&!p.IsOpen,"result budget aborts explicitly and closes session");}}
        using(var s=await Connect()){
            var running=s.ExecuteAsync("SELECT COUNT(*) FROM many a CROSS JOIN many b WHERE a.id+b.id<0");
            for(int n=0;n<100&&!s.CanCancel&&!running.IsCompleted;n++)await Task.Delay(10);
            await Task.Delay(20);string requested=await s.CancelAsync();Console.WriteLine(requested);
            try{await running;throw new Exception("Long query completed before cancellation was observed");}catch(PhobosException e){Pass(e.Code=="StatementCancelled"&&!s.Connected,"out-of-band cancellation observed; target session discarded");}
        }
        using(var p=await ProtocolClient.ConnectAsync(profile,secret)){server!.Kill();await server.WaitForExitAsync();try{await p.QueryAsync("SELECT * FROM many");throw new Exception("Expected disconnect");}catch(IOException){Pass(!p.IsOpen,"abrupt fixture server termination closes client");}}
        await Start();using(var s=await Connect())Pass((await s.ExecuteAsync("SELECT * FROM studio_types")).Rows.Count==1,"reconnect after server crash/WAL recovery; no SQL replay");
        var docs=new SqlDocument{Text="SELECT * FROM studio_types;"};Pass(docs.Modified,"unsaved SQL document tracked");string sqlFile=Path.Combine(root,"document.sql");await docs.SaveAsync(sqlFile);Pass(!docs.Modified,"save clears modified state");var reopened=new SqlDocument();await reopened.OpenAsync(sqlFile);Pass(reopened.Text==docs.Text&&!reopened.Modified,"SQL open/save round trip");
        var store=new ProfileStore(Path.Combine(root,"profiles.json"));await store.SaveAsync([profile]);Pass((await store.LoadAsync()).Single()==profile&&!File.ReadAllText(Path.Combine(root,"profiles.json")).Contains(secret),"profiles round-trip without credential field");
        using(var s=await Connect()) {
            await s.ExecuteAsync("CREATE TABLE schema_v2 (id BIGINT PRIMARY KEY, amount BIGINT DEFAULT 12 CHECK(amount>=0))");
            await s.ExecuteAsync("INSERT INTO schema_v2 (id) VALUES (1)");
            Pass((await s.ExecuteAsync("SELECT amount FROM schema_v2")).Rows[0][0].Text=="12","unchanged 0.3-D client consumes new defaults");
            var catalog=await s.CatalogAsync("schema_v2");
            Pass(catalog["COLUMNS"].Any(x=>x.GetValueOrDefault("has_default")=="true"),"additive default metadata");
            Pass(catalog["CONSTRAINTS"].Any(x=>x["constraint_type"]=="PRIMARY KEY")&&catalog["CONSTRAINTS"].Any(x=>x["constraint_type"]=="CHECK"),"new constraints over unchanged API v1 client");
        }
        await ProductTests.Run(root,Connect);
        await Malformed();
        if(args.Length>2){await Run(args[2],["--evidence",Path.Combine(root,"screenshots"),port.ToString()],secret+"\n");Pass(File.Exists(Path.Combine(root,"screenshots","results.png")),"actual Avalonia window render evidence");}
        await Stop();Pass((await Run(Path.Combine(bin,"phobos-admin.exe"),["check",Path.Combine(root,"instance","data")])).Contains("INTEGRITY OK"),"post-client-validation offline integrity");
        try{using var p=await ProtocolClient.ConnectAsync(profile,secret);throw new Exception("Expected unavailable");}catch(SocketException){Pass(true,"unavailable server refused cleanly");}
        foreach(var f in Directory.GetFiles(root,"*",SearchOption.AllDirectories))if(new FileInfo(f).Length<2000000)Pass(!Encoding.UTF8.GetString(await File.ReadAllBytesAsync(f)).Contains(secret),"no persisted plaintext secret: "+Path.GetFileName(f));
        Console.WriteLine("PASS COMPLETE");return 0;
    }catch(Exception ex){Console.Error.WriteLine(ex);return 1;}finally{await Stop();}}
    static async Task Malformed(){foreach(string defect in new[]{"oversize","wrong-id","flags","magic","eof","utf8"}){
        var l=new TcpListener(IPAddress.Loopback,0);l.Start();int p=((IPEndPoint)l.LocalEndpoint).Port;
        var remote=Task.Run(async()=>{using var c=await l.AcceptTcpClientAsync();var s=c.GetStream();byte[] h=new byte[16];await s.ReadExactlyAsync(h);int length=(int)BinaryPrimitives.ReadUInt32BigEndian(h.AsSpan(12));await s.ReadExactlyAsync(new byte[length]);h[5]=2;BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(12),0);
            if(defect=="eof")return;if(defect=="oversize")BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(12),1048577);if(defect=="wrong-id")h[11]++;if(defect=="flags")h[6]=1;if(defect=="magic")h[0]=0;if(defect=="utf8")BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(12),1);await s.WriteAsync(h);if(defect=="utf8")await s.WriteAsync(new byte[]{255});});
        try{using var c=await ProtocolClient.ConnectAsync(new("mock","127.0.0.1",p,"admin"),"test");throw new Exception("Malformed accepted");}catch(Exception ex)when(ex is IOException or DecoderFallbackException){Pass(true,"reject malformed response: "+defect);}finally{await remote;l.Stop();}
    }}
}
