using System.Buffers.Binary;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Phobos.Studio.Core;

static class ProtocolFaults {
    static byte[] Payload(Action<BinaryWriter> build){using var m=new MemoryStream();using var w=new BinaryWriter(m);w.Write((byte)1);build(w);return m.ToArray();}
    static void U32(BinaryWriter w,uint n){Span<byte>b=stackalloc byte[4];BinaryPrimitives.WriteUInt32BigEndian(b,n);w.Write(b);}
    static void U64(BinaryWriter w,ulong n){Span<byte>b=stackalloc byte[8];BinaryPrimitives.WriteUInt64BigEndian(b,n);w.Write(b);}
    static void Text(BinaryWriter w,string s){var b=Encoding.UTF8.GetBytes(s);U32(w,(uint)b.Length);w.Write(b);}
    static async Task<uint> Request(Stream s){var h=new byte[16];await s.ReadExactlyAsync(h);await s.ReadExactlyAsync(new byte[BinaryPrimitives.ReadUInt32BigEndian(h.AsSpan(12))]);return BinaryPrimitives.ReadUInt32BigEndian(h.AsSpan(8));}
    static async Task Reply(Stream s,uint id,byte type,byte[] b){var h=new byte[16];"PHOB"u8.CopyTo(h);h[4]=1;h[5]=type;BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(8),id);BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(12),(uint)b.Length);await s.WriteAsync(h);await s.WriteAsync(b);}
    static async Task Hello(Stream s){await Reply(s,await Request(s),2,"phobos;stream=1"u8.ToArray());await Reply(s,await Request(s),6,[]);}
    public static async Task Run(){
        foreach(var defect in new[]{"sequence","column-count","unknown-type","boolean","trailing","totals","truncated","duplicate-start"}){
            var l=new TcpListener(IPAddress.Loopback,0);l.Start();int port=((IPEndPoint)l.LocalEndpoint).Port;
            var remote=Task.Run(async()=>{using var socket=await l.AcceptTcpClientAsync();var stream=socket.GetStream();await Hello(stream);uint id=await Request(stream);var start=Payload(w=>{U32(w,1);Text(w,"value");});await Reply(stream,id,13,start);
                if(defect=="duplicate-start"){await Reply(stream,id,13,start);return;}
                if(defect=="totals"){await Reply(stream,id,15,Payload(w=>{U64(w,1);U64(w,0);}));return;}
                var rows=Payload(w=>{U64(w,defect=="sequence"?1ul:0ul);U32(w,1);U32(w,defect=="column-count"?2u:1u);w.Write((byte)(defect=="unknown-type"?99:defect=="boolean"?2:0));if(defect=="boolean")w.Write((byte)7);if(defect=="trailing")w.Write((byte)0);});
                if(defect=="truncated")rows=rows[..^1];await Reply(stream,id,14,rows);
            });
            using var client=await ProtocolClient.ConnectAsync(new("mock","127.0.0.1",port,"user"),"pass");bool rejected=false;try{await client.QueryAsync("SELECT test");}catch(PhobosException e){rejected=e.Code=="InvalidProtocol"&&!client.IsOpen;}await remote;l.Stop();if(!rejected)throw new Exception("Accepted bad stream: "+defect);Console.WriteLine("PASS streaming validator rejects "+defect);
        }
        var future=new TcpListener(IPAddress.Loopback,0);future.Start();int endpoint=((IPEndPoint)future.LocalEndpoint).Port;
        var peer=Task.Run(async()=>{using var socket=await future.AcceptTcpClientAsync();var s=socket.GetStream();await Hello(s);uint id=await Request(s);
            await Reply(s,id,13,Payload(w=>{U32(w,2);Text(w,"capability_name");Text(w,"capability_value");}));
            await Reply(s,id,14,Payload(w=>{U64(w,0);U32(w,1);U32(w,2);w.Write((byte)4);Text(w,"management_api_version");w.Write((byte)4);Text(w,"2");}));await Reply(s,id,15,Payload(w=>{U64(w,1);U64(w,1);}));
            await Reply(s,await Request(s),16,Payload(w=>{Text(w,"MOCK SQL");U64(w,0);}));
        });
        using(var session=new StudioSession()){await session.ConnectAsync(new("future","127.0.0.1",endpoint,"u"),"p");if(!session.Connected||session.MetadataSupported||session.KnownDdl)throw new Exception("Future API gating failed");await session.ExecuteAsync("SELECT arbitrary");Console.WriteLine("PASS future Management API disables metadata/templates but permits SQL");}await peer;future.Stop();
        var partial=new TcpListener(IPAddress.Loopback,0);partial.Start();int partialPort=((IPEndPoint)partial.LocalEndpoint).Port;
        var partialPeer=Task.Run(async()=>{using var socket=await partial.AcceptTcpClientAsync();var stream=socket.GetStream();await Hello(stream);uint id=await Request(stream);await Reply(stream,id,13,Payload(w=>{U32(w,1);Text(w,"value");}));await Reply(stream,id,14,Payload(w=>{U64(w,0);U32(w,1);U32(w,1);w.Write((byte)0);}));await Reply(stream,id,14,Payload(w=>{U64(w,99);U32(w,1);U32(w,1);w.Write((byte)0);}));});
        using(var c=await ProtocolClient.ConnectAsync(new("partial","127.0.0.1",partialPort,"u"),"p")){int displayed=0;try{await c.QueryAsync("SELECT test",onBatch:batch=>{displayed+=batch.Count;return Task.CompletedTask;});throw new Exception("Bad later batch accepted");}catch(PhobosException e){if(e.Code!="InvalidProtocol"||displayed!=1||c.IsOpen)throw;Console.WriteLine("PASS validated prefix delivered, malformed later batch withheld, session poisoned");}}await partialPeer;partial.Stop();
        var metadata=new TcpListener(IPAddress.Loopback,0);metadata.Start();int metadataPort=((IPEndPoint)metadata.LocalEndpoint).Port;
        var metadataPeer=Task.Run(async()=>{using var socket=await metadata.AcceptTcpClientAsync();var stream=socket.GetStream();await Hello(stream);for(int n=0;n<9;n++){uint id=await Request(stream);await Reply(stream,id,13,Payload(w=>{U32(w,2);Text(w,n==0?"capability_name":"table_name");Text(w,n==0?"capability_value":"table_id");}));await Reply(stream,id,14,Payload(w=>{U64(w,0);U32(w,1);U32(w,2);w.Write((byte)4);Text(w,n==0?"management_api_version":n<=4?"before":"after");w.Write((byte)4);Text(w,"1");}));await Reply(stream,id,15,Payload(w=>{U64(w,1);U64(w,1);}));}});
        using(var c=new StudioSession()){await c.ConnectAsync(new("metadata","127.0.0.1",metadataPort,"u"),"p");try{await c.CatalogAsync();throw new Exception("Mixed catalog accepted");}catch(PhobosException e){if(e.Code!="CatalogChanged"||!c.Connected)throw;Console.WriteLine("PASS concurrent metadata change rejected before cache publication; connection is not poisoned");}}await metadataPeer;metadata.Stop();
        using var rsa=RSA.Create(2048);var request=new CertificateRequest("CN=localhost",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);using var generated=request.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1),DateTimeOffset.UtcNow.AddDays(1));using var certificate=X509CertificateLoader.LoadPkcs12(generated.Export(X509ContentType.Pfx),null);var tlsListener=new TcpListener(IPAddress.Loopback,0);tlsListener.Start();int tlsPort=((IPEndPoint)tlsListener.LocalEndpoint).Port;
        var tlsPeer=Task.Run(async()=>{using var socket=await tlsListener.AcceptTcpClientAsync();using var tls=new SslStream(socket.GetStream());try{await tls.AuthenticateAsServerAsync(new SslServerAuthenticationOptions{ServerCertificate=certificate,EnabledSslProtocols=SslProtocols.Tls12});}catch(IOException e){Console.WriteLine("TLS fixture: "+e.Message);}catch(AuthenticationException e){Console.WriteLine("TLS fixture: "+e.Message);}});
        bool refused=false;try{using var c=await ProtocolClient.ConnectAsync(new("tls","localhost",tlsPort,"u",true),"p");}catch(AuthenticationException){refused=true;}await tlsPeer;tlsListener.Stop();if(!refused)throw new Exception("Untrusted TLS certificate accepted");Console.WriteLine("PASS TLS rejects untrusted server certificate without bypass");
    }
}
