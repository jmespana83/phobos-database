#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
cargo test -p phobos-sql -p phobos-catalog -p phobos-execution -p phobos-admin schema_v2 --locked
