param([Parameter(Mandatory=$true)][string]$Suite)
$ErrorActionPreference='Stop'
# Explicit compatibility wrapper: the caller supplies the frozen command.
& ([scriptblock]::Create($Suite))
if ($LASTEXITCODE -ne 0) { throw "Standard suite failed: $LASTEXITCODE" }
