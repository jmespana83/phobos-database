param(
  [ValidateSet('Smoke','Standard')][string]$Mode = 'Smoke',
  [Parameter(Mandatory=$true)][string]$Binaries,
  [Parameter(Mandatory=$true)][string]$WorkRoot,
  [string]$SuiteRoot = 'C:\PHOBOS-BENCH-v1.3.2',
  [string]$SourceArchive = '',
  [switch]$CheckBenchmarkData,
  [int]$Port = 55431
)
$ErrorActionPreference = 'Stop'
$run = Join-Path $WorkRoot ($Mode.ToLower() + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $run | Out-Null
$instance = Join-Path $run 'instance'
$data = Join-Path $instance 'data'
$auth = Join-Path $run 'auth.txt'
$shutdown = Join-Path $run 'shutdown'
$server = Join-Path $Binaries 'phobos-server.exe'
$cli = Join-Path $Binaries 'phobos-cli.exe'
$admin = Join-Path $Binaries 'phobos-admin.exe'
$previousUser = $env:PHOBOS_USER
$previousPassword = $env:PHOBOS_PASSWORD
$process = $null
$launch = 0
function Query([string]$Sql) {
  $result = & $cli query --addr "127.0.0.1:$Port" $Sql 2>&1
  if ($LASTEXITCODE -ne 0) { throw "SQL failed: $Sql : $result" }
  return ($result -join "`n")
}
function Start-Instance([string]$Directory) {
  $script:launch++
  if (Test-Path -LiteralPath $shutdown) { Remove-Item -LiteralPath $shutdown }
  $script:process = Start-Process -FilePath $server -ArgumentList @('--bind',"127.0.0.1:$Port",'--data-dir',('"'+$Directory+'"'),'--auth-file',('"'+$auth+'"'),'--shutdown-file',('"'+$shutdown+'"')) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $run "server-$launch.out") -RedirectStandardError (Join-Path $run "server-$launch.err")
  for ($attempt=0; $attempt -lt 120; $attempt++) {
    if ($process.HasExited) { throw "server exited; inspect server-$launch.err" }
    & $cli ping --addr "127.0.0.1:$Port" *> $null
    if ($LASTEXITCODE -eq 0) { return }
    Start-Sleep -Milliseconds 250
  }
  throw 'Server readiness timeout'
}
function Stop-Instance {
  if ($null -ne $script:process -and -not $script:process.HasExited) {
    New-Item -ItemType File -Path $shutdown -Force | Out-Null
    if (-not $script:process.WaitForExit(30000)) { throw 'Graceful shutdown timeout' }
    if ($script:process.ExitCode -ne 0) { throw "Server shutdown failed: $($script:process.ExitCode)" }
  }
  $script:process = $null
}
try {
  & $admin init $instance
  if ($LASTEXITCODE -ne 0) { throw 'Instance initialization failed' }
  $env:PHOBOS_USER = 'foundation_test'
  $env:PHOBOS_PASSWORD = [Guid]::NewGuid().ToString('N')
  $env:PHOBOS_PASSWORD | & $admin user-add-stdin $auth $env:PHOBOS_USER admin
  if ($LASTEXITCODE -ne 0) { throw 'Test credential setup failed' }
  Start-Instance $data
  if ($Mode -eq 'Standard') {
    $arguments = @((Join-Path $SuiteRoot 'benchmark_suite.py'),'phobos','--host','127.0.0.1','--port',"$Port",'--phobos-cli',$cli,'--phobos-data-dir',$data,'--data-dir',(Join-Path $WorkRoot 'standard-data'),'--out',(Join-Path $run 'results'))
    if ($SourceArchive) { $arguments += @('--phobos-source-archive',$SourceArchive) }
    & (Join-Path $SuiteRoot '.venv\Scripts\python.exe') @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Standard Benchmark failed' }
    Stop-Instance
    if ($CheckBenchmarkData) {
      & $admin check $data
      if ($LASTEXITCODE -ne 0) { throw 'Post-benchmark integrity failed' }
    }
  } else {
    Query "CREATE TABLE original (id BIGINT PRIMARY KEY, parent BIGINT DEFAULT 10 CHECK(parent>=0), name TEXT DEFAULT 'new')"
    Query 'INSERT INTO original (id) VALUES (3)'
    if ((Query 'SELECT parent FROM original WHERE id=3') -notmatch '10') { throw 'Default missing' }
    & $cli query --addr "127.0.0.1:$Port" 'UPDATE original SET parent=-1' *> $null
    if ($LASTEXITCODE -eq 0) { throw 'CHECK was bypassed' }
    Query "INSERT INTO original (name,id) VALUES ('root',1)"
    Query "INSERT INTO original (id,parent,name) VALUES (2,1,' child ')"
    & $cli session --addr "127.0.0.1:$Port" 'BEGIN; ALTER TABLE original RENAME TO renamed; ALTER TABLE renamed RENAME COLUMN id TO key; COMMIT'
    if ($LASTEXITCODE -ne 0) { throw 'Transactional rename failed' }
    $expected = Query 'SELECT key,name FROM renamed ORDER BY key'
    $metadata = Query 'SHOW CATALOG CONSTRAINTS FROM renamed'
    $columnMetadata = Query 'SHOW CATALOG COLUMNS FROM renamed'
    Query 'WITH cleaned AS (SELECT key, TRIM(name) AS name FROM renamed) SELECT c.key,c.name FROM cleaned c ORDER BY c.key'
    Query 'SELECT a.key AS child,b.key AS parent FROM renamed a LEFT JOIN renamed b ON a.parent=b.key AND b.name IS NOT NULL ORDER BY child'
    # Crash only this freshly created child after acknowledged schema/DML commits.
    Stop-Process -Id $process.Id -Force
    $process.WaitForExit()
    $process = $null
    Start-Instance $data
    if ((Query 'SELECT key,name FROM renamed ORDER BY key') -ne $expected) { throw 'Crash recovery rows differ' }
    if ((Query 'SHOW CATALOG CONSTRAINTS FROM renamed') -ne $metadata) { throw 'Crash recovery catalog differs' }
    & $cli query --addr "127.0.0.1:$Port" "INSERT INTO renamed (key) VALUES (1)" *> $null
    if ($LASTEXITCODE -eq 0) { throw 'Unique enforcement was lost' }
    if ((Query 'SHOW CATALOG COLUMNS FROM renamed') -ne $columnMetadata) { throw 'Defaults lost on restart' }
    & $cli query --addr "127.0.0.1:$Port" 'UPDATE renamed SET parent=-1' *> $null
    if ($LASTEXITCODE -eq 0) { throw 'CHECK lost on restart' }
    Stop-Instance
    & $admin check $data
    if ($LASTEXITCODE -ne 0) { throw 'Integrity failed after crash recovery' }
    $backup = Join-Path $run 'backup'
    $restored = Join-Path $run 'restored'
    & $admin backup $data $backup
    if ($LASTEXITCODE -ne 0) { throw 'Backup failed' }
    & $admin restore $backup $restored
    if ($LASTEXITCODE -ne 0) { throw 'Restore failed' }
    & $admin check $restored
    if ($LASTEXITCODE -ne 0) { throw 'Restored integrity failed' }
    Start-Instance $restored
    if ((Query 'SELECT key,name FROM renamed ORDER BY key') -ne $expected) { throw 'Restored rows differ' }
    if ((Query 'SHOW CATALOG CONSTRAINTS FROM renamed') -ne $metadata) { throw 'Restored metadata differs' }
    Stop-Instance
  }
  'PASS' | Set-Content (Join-Path $run 'result.txt')
  Write-Host "PASS $Mode $run"
} finally {
  if ($null -ne $process -and -not $process.HasExited) {
    New-Item -ItemType File -Path $shutdown -Force | Out-Null
    if (-not $process.WaitForExit(30000)) { Stop-Process -Id $process.Id -Force }
  }
  $env:PHOBOS_USER = $previousUser
  $env:PHOBOS_PASSWORD = $previousPassword
}
