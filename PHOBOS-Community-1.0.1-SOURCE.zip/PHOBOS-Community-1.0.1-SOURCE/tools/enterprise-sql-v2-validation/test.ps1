param([string]$Cargo='cargo',[switch]$Full)
$ErrorActionPreference='Stop'
Push-Location (Join-Path $PSScriptRoot '../..')
try {
  if ($Full) { & $Cargo test --workspace --locked -- --test-threads=4 }
  else { & $Cargo test -p phobos-sql -p phobos-catalog -p phobos-execution -p phobos-admin schema_v2 --locked }
  if ($LASTEXITCODE -ne 0) { throw 'Validation failed' }
} finally { Pop-Location }
