param(
 [Parameter(Mandatory=$true)][string]$Candidate,
 [Parameter(Mandatory=$true)][string]$Control,
 [Parameter(Mandatory=$true)][string]$WorkRoot,
 [string]$SuiteRoot='C:\PHOBOS-BENCH-v1.3.2',
 [int]$Port=55436,
 [int]$Pairs=2,
 [switch]$CandidateFirst
)
$ErrorActionPreference='Stop'
$records=@()
$manifest=Join-Path $WorkRoot "benchmark-runs.json"
if(Test-Path -LiteralPath $manifest){$records=@(Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json)}
for($pair=1;$pair -le $Pairs;$pair++) {
 $order=if($CandidateFirst){@('candidate','control')}else{@('control','candidate')}
 foreach($label in $order) {
  if(@($records | Where-Object {$_.label -eq $label -and $_.pair -eq $pair}).Count -gt 0){continue}
  $binaries=if($label -eq 'candidate'){$Candidate}else{$Control}
  $before=@(Get-ChildItem -LiteralPath $WorkRoot -Directory -Filter 'standard-*' -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '^standard-\d{8}-\d{6}$'} | ForEach-Object FullName)
  $log=Join-Path $WorkRoot "standard-$label-$pair.log"
  & (Join-Path $PSScriptRoot 'run.ps1') -Mode Standard -Binaries $binaries -WorkRoot $WorkRoot -SuiteRoot $SuiteRoot -Port $Port *> $log
  if($LASTEXITCODE -ne 0){throw "Benchmark $label/$pair failed; see $log"}
  $runs=@(Get-ChildItem -LiteralPath $WorkRoot -Directory -Filter 'standard-*' | Where-Object {$_.Name -match '^standard-\d{8}-\d{6}$' -and $_.FullName -notin $before})
  if($runs.Count -ne 1){throw 'Expected one isolated benchmark output'}
  $records+=@{label=$label;pair=$pair;directory=$runs[0].FullName;binaries=$binaries}
  $records | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 (Join-Path $WorkRoot 'benchmark-runs.json')
  Write-Output "PASS $label/$pair $($runs[0].FullName)"
 }
}
