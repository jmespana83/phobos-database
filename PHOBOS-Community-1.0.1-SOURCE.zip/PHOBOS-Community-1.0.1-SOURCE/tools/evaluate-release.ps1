param([Parameter(Mandatory=$true)][string]$OutputRoot)
$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$settings=@(
    @{name='default'; config=@()},
    @{name='thin-lto'; config=@('--config','profile.release.lto="thin"')},
    @{name='codegen-one'; config=@('--config','profile.release.codegen-units=1')},
    @{name='panic-abort'; config=@('--config','profile.release.panic="abort"')},
    @{name='native-cpu-nonportable'; config=@(); rustflags='-C target-cpu=native'}
)
$priorFlags=$env:RUSTFLAGS
try {
    foreach($setting in $settings) {
        if($priorFlags){throw 'Unset RUSTFLAGS before controlled profile evaluation'}
        $env:RUSTFLAGS=$setting.rustflags
        $extra=$setting.config
        cargo build --release -p phobos-bench @extra
        if($LASTEXITCODE -ne 0){throw "build failed: $($setting.name)"}
        & "$PSScriptRoot/run-benchmarks.ps1" -Mode micro -Rows 100000 -Samples 7 -Operations 20 -OutputDirectory (Join-Path $OutputRoot $setting.name)
        if(-not $?){throw 'profile benchmark failed'}
        $setting | ConvertTo-Json | Set-Content (Join-Path (Join-Path $OutputRoot $setting.name) 'build-setting.json')
    }
} finally { $env:RUSTFLAGS=$priorFlags }
# Alternative allocators and PGO require separately installed tooling and correctness
# gates; they are documented as not evaluated, not represented by invented numbers.
