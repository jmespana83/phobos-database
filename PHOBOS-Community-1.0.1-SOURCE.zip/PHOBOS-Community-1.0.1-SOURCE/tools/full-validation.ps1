$ErrorActionPreference = "Stop"

Write-Host "== Phobos Phase 0-5 comprehensive validation =="
Write-Host "Rust:"
rustc --version
cargo --version

Write-Host "`n[1/7] Formatting"
cargo fmt --all
cargo fmt --all -- --check

Write-Host "`n[2/7] Clippy"
cargo clippy --workspace --all-targets --all-features -- -D warnings

Write-Host "`n[3/7] Full workspace test suite"
cargo test --workspace

Write-Host "`n[4/7] Cross-phase validation harness (serialized for deterministic filesystem/recovery tests)"
cargo test -p phobos-validation -- --test-threads=1

Write-Host "`n[5/7] Longer deterministic validation/soak tests"
cargo test -p phobos-validation -- --ignored --test-threads=1

Write-Host "`n[6/7] Documentation"
cargo doc --workspace --no-deps

Write-Host "`n[7/7] Release compilation smoke check"
cargo build --workspace --release

Write-Host "`nPHOBOS PHASE 0-5 COMPREHENSIVE VALIDATION COMPLETED SUCCESSFULLY"
