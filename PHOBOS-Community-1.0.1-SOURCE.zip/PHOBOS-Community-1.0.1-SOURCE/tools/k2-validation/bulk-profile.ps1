# 0.2-K.2 BULK per-phase profile at 100K / 1M / 3M (profiling build of the
# harness; same bulk_load workload as bulk-ab.ps1). Prints, per size:
#   BULKINFO    heap/index pages+bytes, index entries, WAL bytes, files
#   BULKPHASE   phase wall time (ms) and ns/row: encode, heap staging (incl.
#               spill writes), index sort/merge/leaf build, commit
#               preparation, WAL generation, WAL force, publication, data
#               page writes, eviction wait, scratch cleanup, total
#   BULKCOUNTER spill bytes, scratch files, page writes/rewrites, WAL bytes,
#               page images, index leaves, flushed/evicted pages
# A phase whose ns/row GROWS with size is the scaling break.
# With build.ps1 -Baseline the same is printed for 0.2-I.
param([string]$Root = "$env:TEMP\phobos-k2-prof", [int[]]$Sizes = @(100000, 1000000, 3000000), [string]$Out = ".\bulk-profile-results")
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"
New-Item -ItemType Directory -Force -Path $Root, $Out | Out-Null
$OutFull = (Resolve-Path $Out).Path
$builds = @(@{ Name = "K2"; Exe = $K2BenchProf })
if ($Base) { $builds += @{ Name = "0.2-I"; Exe = (Join-Path $Here "baseline-harness\target\prof\release\k2bench.exe") } }
$phase = @()
foreach ($b in $builds) {
  foreach ($rows in $Sizes) {
    Write-Host "=== $($b.Name) bulk_load rows=$rows ==="
    $env:PROF_OUT = Join-Path $OutFull "$($b.Name)"
    $lines = & $b.Exe bulk (Join-Path $Root "$($b.Name)-$rows") $rows
    Remove-Item Env:PROF_OUT
    $lines | Set-Content (Join-Path $OutFull "$($b.Name)-$rows.log")
    $lines | Where-Object { $_ -like "BENCH,*" -or $_ -like "BULKINFO*" } | ForEach-Object { Write-Host "  $_" }
    foreach ($l in ($lines | Where-Object { $_ -like "BULKPHASE*" -or $_ -like "BULKCOUNTER*" })) {
      $kv = @{}; foreach ($t in ($l.Split(' ') | Select-Object -Skip 1)) { $p = $t.Split('=', 2); $kv[$p[0]] = $p[1] }
      if ($kv.ContainsKey('phase')) { $phase += [pscustomobject]@{ build = $b.Name; rows = [int]$rows; item = $kv['phase']; value = [double]$kv['ms']; ns_per_row = [double]$kv['ns_per_row'] } }
      else { $phase += [pscustomobject]@{ build = $b.Name; rows = [int]$rows; item = "counter:" + $kv['counter']; value = [double]$kv['units']; ns_per_row = 0 } }
    }
  }
}
$phase | Export-Csv -NoTypeInformation -Path (Join-Path $OutFull "phases.csv")
Write-Host ""
Write-Host ("Per-phase ms (ns/row) for sizes: " + ($Sizes -join " | "))
$phase | Where-Object { $_.item -notlike "counter:*" } | Group-Object build, item | ForEach-Object {
  $g = $_.Group | Sort-Object rows
  $cells = ($g | ForEach-Object { "{0,9:N1} ms ({1,6:N0})" -f $_.value, $_.ns_per_row }) -join " | "
  Write-Host ("{0,-6} {1,-32} {2}" -f $g[0].build, $g[0].item, $cells)
}
Write-Host ""
Write-Host "Counters:"
$phase | Where-Object { $_.item -like "counter:*" } | Group-Object build, item | ForEach-Object {
  $g = $_.Group | Sort-Object rows
  Write-Host ("{0,-6} {1,-40} {2}" -f $g[0].build, $g[0].item, (($g | ForEach-Object { "{0,14:N0}" -f $_.value }) -join " | "))
}
Write-Host "Saved $OutFull\phases.csv (raw profiles: $OutFull\*.csv)"
