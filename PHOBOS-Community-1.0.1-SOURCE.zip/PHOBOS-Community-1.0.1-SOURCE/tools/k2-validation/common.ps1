# Shared helpers for the 0.2-K.2 scripts.
$script:Here = $PSScriptRoot
$script:Repo = (Resolve-Path (Join-Path $Here "..\..")).Path
$script:K2Bench = Join-Path $Here "target\release\k2bench.exe"
$script:K2BenchProf = Join-Path $Here "target\prof\release\k2bench.exe"
$script:Base = $null
$bt = Join-Path $Here "baseline.txt"
if (Test-Path $bt) { $script:Base = (Get-Content $bt -Raw).Trim() }
function Get-Median([double[]]$v) { $s = $v | Sort-Object; $n = $s.Count; if ($n -eq 0) { return [double]::NaN }; if ($n % 2) { return $s[[int](($n-1)/2)] } else { return ($s[$n/2-1] + $s[$n/2]) / 2 } }
function Get-BenchValue($lines, [string]$metric) {
  $l = $lines | Where-Object { $_ -like "BENCH,$metric,*" } | Select-Object -First 1
  if (-not $l) { throw "metric $metric missing" }
  return [double]$l.Split(',')[2]
}
