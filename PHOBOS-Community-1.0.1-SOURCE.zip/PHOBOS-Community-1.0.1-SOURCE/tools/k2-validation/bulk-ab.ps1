# 0.2-K.2 BULK A/B, like-for-like, on the embedded MVCC Coordinator.
# Workload (identical for every variant): Coordinator::bulk_load into
# bench(id, grp, sec, val, payload) with UNIQUE(id) + secondary(sec), one
# transaction (the K.1 bulk-ab workload). Variants: this build (worker on,
# worker off, 64 MiB cache) and, with build.ps1 -Baseline <0.2-I source>,
# 0.2-I running the SAME harness code. The verdict compares against the
# same-run 0.2-I median (+10%). The historical 0.94/7.47/28.18 s Standard
# numbers come from a different workload and are printed for reference only.
param([string]$Root = "$env:TEMP\phobos-k2-bulk", [int]$Rounds = 2, [int[]]$Sizes = @(100000, 1000000, 3000000), [string]$Out = ".\bulk-ab-results.csv")
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"
New-Item -ItemType Directory -Force -Path $Root | Out-Null
$results = @()
$variants = @(
  @{ Name = "K2";            Exe = $K2Bench; Env = @{} },
  @{ Name = "K2-workerOFF";  Exe = $K2Bench; Env = @{ PHOBOS_AUTO_RECLAIM = "0" } },
  @{ Name = "K2-cache64MiB"; Exe = $K2Bench; Env = @{ PHOBOS_PAGE_CACHE_BYTES = "67108864" } }
)
if ($Base) { $variants += @{ Name = "0.2-I"; Exe = (Join-Path $Here "baseline-harness\target\release\k2bench.exe"); Env = @{} } }
else { Write-Host "NOTE: no same-harness 0.2-I build (run .\build.ps1 -Baseline <extracted 0.2-I source>)." -ForegroundColor Yellow }
foreach ($rows in $Sizes) {
  foreach ($round in 1..$Rounds) {
    foreach ($v in $variants) {
      foreach ($k in $v.Env.Keys) { Set-Item "Env:$k" $v.Env[$k] }
      try { $lines = & $v.Exe bulk (Join-Path $Root "$($v.Name)-$rows") $rows }
      finally { foreach ($k in $v.Env.Keys) { Remove-Item "Env:$k" -ErrorAction SilentlyContinue } }
      $s = Get-BenchValue $lines "bulk_$rows"
      Write-Host ("{0,-14} rows={1,8} round={2} {3,9:N3} s" -f $v.Name, $rows, $round, $s)
      $lines | Where-Object { $_ -like "BULKINFO*" } | ForEach-Object { Write-Host "    $_" }
      $results += [pscustomobject]@{ variant = $v.Name; rows = $rows; round = $round; seconds = $s; us_per_row = $s * 1e6 / $rows }
    }
  }
}
$results | Export-Csv -NoTypeInformation -Path $Out
$hist = @{ 100000 = 0.940; 1000000 = 7.470; 3000000 = 28.177 }
Write-Host ""
Write-Host "Medians. PASS/MISS = K2 within +10% of the same-run 0.2-I median (needs -Baseline)."
foreach ($rows in $Sizes) {
  $baseMed = $null
  if ($Base) { $baseMed = Get-Median ($results | Where-Object { $_.variant -eq "0.2-I" -and $_.rows -eq $rows } | ForEach-Object { $_.seconds }) }
  foreach ($v in $variants) {
    $m = Get-Median ($results | Where-Object { $_.variant -eq $v.Name -and $_.rows -eq $rows } | ForEach-Object { $_.seconds })
    $verdict = ""
    if ($baseMed -and $v.Name -like "K2*") { $verdict = if ($m -le 1.10 * $baseMed) { "PASS (<= {0:N3} s)" -f (1.10 * $baseMed) } else { "MISS (> {0:N3} s)" -f (1.10 * $baseMed) } }
    Write-Host ("{0,-14} rows={1,8} median={2,9:N3} s  {3,6:N2} us/row  {4}" -f $v.Name, $rows, $m, ($m * 1e6 / $rows), $verdict)
  }
  Write-Host ("  (historical 0.2-I Standard-suite reference, different workload: {0} s)" -f $hist[$rows])
}
Write-Host "Saved $Out"
