# 0.2-K.2 build. Builds this PHOBOS tree (server/admin) and the k2bench
# harness (plain and with profiling).
# Optional: -Baseline <path to an extracted 0.2-I source tree> builds the SAME
# workloads against 0.2-I so bulk-ab / bulk-profile compare like with like.
param([string]$Baseline = "")
$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
Push-Location (Join-Path $here "..\..")
cargo build --release --locked -p phobos-server -p phobos-admin
Pop-Location
Push-Location $here
cargo build --release --locked
cargo build --release --locked --features prof --target-dir target\prof
Pop-Location
if ($Baseline -ne "") {
  $base = (Resolve-Path $Baseline).Path
  Write-Host "Building baseline (same workloads) from $base"
  # The k2bench harness against the baseline crates (no 0.2-K-only APIs).
  $bh = Join-Path $here "baseline-harness"
  if (Test-Path $bh) { Remove-Item -Recurse -Force $bh }
  New-Item -ItemType Directory -Path $bh | Out-Null
  Copy-Item -Recurse (Join-Path $here "src") (Join-Path $bh "src")
  $toml = Get-Content (Join-Path $here "Cargo.toml") -Raw
  $crates = ($base -replace '\\','/') + "/crates/"
  $toml = $toml.Replace('../../crates/', $crates).Replace('default = ["k"]','default = []').Replace('name = "phobos-k2-validation"','name = "phobos-k2-baseline"')
  Set-Content -Path (Join-Path $bh "Cargo.toml") -Value $toml
  Copy-Item (Join-Path $base "Cargo.lock") (Join-Path $bh "Cargo.lock")
  Push-Location $bh
  cargo build --release
  cargo build --release --features prof --target-dir target\prof
  Pop-Location
  Set-Content -Path (Join-Path $here "baseline.txt") -Value $base
}
Write-Host "Built. k2bench: .\target\release\k2bench.exe ; profiling: .\target\prof\release\k2bench.exe"
