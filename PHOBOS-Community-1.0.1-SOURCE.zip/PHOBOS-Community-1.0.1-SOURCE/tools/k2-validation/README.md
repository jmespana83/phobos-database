# PHOBOS 0.2-K.2: Windows validation bundle

Run from PowerShell in this folder. Use the toolchain from `rust-toolchain.toml` (1.85).

```powershell
cd tools\k2-validation
.\build.ps1                       # or: .\build.ps1 -Baseline C:\src\PHOBOS-0.2-I   (same-harness 0.2-I A/B)
.\bulk-profile.ps1                # per-phase BULK breakdown, 100K / 1M / 3M
.\bulk-ab.ps1                     # BULK A/B: K2 (worker on/off, 64 MiB cache) [+ 0.2-I, same code]
.\quick-ab.ps1                    # quick suite worker ON vs OFF, OLTP gap verdicts
.\oltp-errors.ps1                 # every OLTP error with code/message/op/client/iteration/retryable
.\standard.ps1 -Suite "<your frozen Standard command>"
```

| Script | What it proves |
|---|---|
| `build.ps1` | Builds PHOBOS (server/admin) and `k2bench` (plain + profiling). `-Baseline <0.2-I source>` also builds the identical harness against 0.2-I (`baseline-harness\`). |
| `bulk-profile.ps1` | `BULKINFO` (heap/index pages and bytes, WAL bytes), `BULKPHASE` (ms and ns/row per phase), `BULKCOUNTER` (spill bytes, scratch files, page writes and rewrites, WAL page images, index leaves), per size. A phase whose ns/row grows with size is the scaling break. |
| `bulk-ab.ps1` | Same `bulk_load` workload on every variant. With `-Baseline`, PASS/MISS against the same-run 0.2-I median +10 %. Without it, there is no like-for-like 0.2-I number: the historical Standard figures are a different workload and are printed for reference only. |
| `quick-ab.ps1` | Medians for worker ON and OFF, and the OLTP1/8/16 gap against the targets (≤5 % / ≤8 % / ≤8 %). |
| `oltp-errors.ps1` | Summarizes the `OLTPERROR` lines (`type`, `code`, `message`, `op`, `client`, `iteration`, `retryable`, `correctness_affected`, SQL). |
| `standard.ps1` | Your frozen Standard suite, worker ON then OFF. |

**Switches:**
- `PHOBOS_AUTO_RECLAIM=0`: worker off.
- `PHOBOS_PAGE_CACHE_BYTES`: page cache size (default 256 MiB).
- `PHOBOS_AUTO_RECLAIM_MIN_INTERVAL_MS` (default 100) and `PHOBOS_AUTO_RECLAIM_YIELD_MS` (default 1000): the 0.2-K.2 reclaim publication batching and foreground-yield window.
