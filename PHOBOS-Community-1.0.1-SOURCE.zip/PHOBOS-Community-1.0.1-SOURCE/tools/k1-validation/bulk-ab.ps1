param([string]$Root = "$env:TEMP\phobos-k1-bulk")
$ErrorActionPreference = "Stop"
$bin = ".\target\release\k1bench.exe"
foreach ($worker in @("1","0")) {
  $env:PHOBOS_AUTO_RECLAIM = $worker
  foreach ($rows in @(100000, 1000000, 3000000)) {
    foreach ($round in 1..2) {
      Write-Host "worker=$worker rows=$rows round=$round"
      & $bin bulk "$Root\b-$worker-$rows" $rows
    }
  }
}
Remove-Item Env:PHOBOS_AUTO_RECLAIM
