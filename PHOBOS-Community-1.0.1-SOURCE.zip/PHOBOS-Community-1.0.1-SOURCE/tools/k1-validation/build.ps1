$ErrorActionPreference = "Stop"
Push-Location ..\..
cargo build --release --locked
Pop-Location
cargo build --release --locked
Write-Host "Built: ..\..\target\release (PHOBOS) and .\target\release\k1bench.exe"
