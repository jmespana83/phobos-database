# Runs the frozen Standard benchmark (not shipped here) against this build,
# worker ON then worker OFF. Example:
#   .\standard.ps1 -Suite "python C:\bench\run_standard.py --phobos ..\..\target\release\phobos-server.exe"
param([Parameter(Mandatory=$true)][string]$Suite, [string]$Out = ".\standard-results")
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $Out | Out-Null
foreach ($worker in @("1","0")) {
  $env:PHOBOS_AUTO_RECLAIM = $worker
  Write-Host "Standard benchmark, PHOBOS_AUTO_RECLAIM=$worker"
  Invoke-Expression $Suite *>&1 | Tee-Object -FilePath "$Out\standard-worker-$worker.log"
}
Remove-Item Env:PHOBOS_AUTO_RECLAIM
