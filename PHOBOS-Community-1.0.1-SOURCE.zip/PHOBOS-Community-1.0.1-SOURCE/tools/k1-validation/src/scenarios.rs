use super::*;

const WIDE_ID: u64 = 1000;
const WIDE_LEN: usize = 20_000;
const WIDE_SEED: u64 = 424_242;

fn setup_wide(root: &Path) -> Db {
    let mut d = Db::create(root);
    insert_many(&mut d, 1, 100, 40);
    d.x(&format!("INSERT INTO t VALUES {}", row(WIDE_ID, WIDE_LEN, WIDE_SEED)));
    insert_many(&mut d, 2000, 300, 40);
    d.x("CHECKPOINT");
    d
}

/// Part A: end-to-end reproduction. `variant` = "live" (wide row present) or
/// "freed" (wide row deleted and its overflow chain released before restart).
pub fn repro(root: &Path, variant: &str) {
    let variant = if variant.is_empty() { "live" } else { variant };
    obs("variant", variant);
    let mut d = setup_wide(root);
    let wide_expected = text(WIDE_LEN, WIDE_SEED);
    obs("wide_row.length", WIDE_LEN);
    obs("wide_row.fnv64", format!("{:016x}", fnv(wide_expected.as_bytes())));
    let got = d.scalar(&format!("SELECT pad FROM t WHERE id={WIDE_ID}"));
    obs("1.wide_row_reads_before_restart", got.as_deref() == Ok(wide_expected.as_str()));
    let mut expected_rows: i64 = 401;
    if variant == "freed" {
        d.x(&format!("DELETE FROM t WHERE id={WIDE_ID}"));
        expected_rows -= 1;
        let mut reclaimed = 0;
        for _ in 0..50 {
            let r = d.db().reclaim_once(64).unwrap();
            reclaimed += r.versions_reclaimed;
            if r.versions_reclaimed == 0 && r.candidates_remaining == 0 {
                break;
            }
        }
        obs("freed.versions_reclaimed", reclaimed);
        d.x("CHECKPOINT");
    }
    d.close();
    obs("1.valid_overflow_chain_before_restart", bad_overflow(&d.dir).is_empty() && !overflow_pages(&d.dir).is_empty());
    dump_overflow("before_restart", &d.dir);
    obs("pre_check", d.check().unwrap_or_else(|e| e));
    obs("3.clean_restart_seconds", format!("{:.3}", { let t = Instant::now(); d.db = Some(Arc::new(Coordinator::open(&d.dir).unwrap())); d.s = d.db().new_session(); t.elapsed().as_secs_f64() }));
    // 4. ordinary inserts after restart, one autocommit statement each.
    let medium = 1600usize;
    obs("4.ordinary_row_text_len", medium);
    let mut committed = 0;
    let mut first_symptom: Option<u64> = None;
    for i in 0..40u64 {
        let id = 5000 + i;
        match d.t(&format!("INSERT INTO t VALUES {}", row(id, medium, id))) {
            Ok(_) => {
                committed += 1;
                expected_rows += 1;
            }
            Err(e) => obs(&format!("4.insert_{}_error", i + 1), e),
        }
        if first_symptom.is_none() {
            let symptom = if variant == "live" {
                d.scalar(&format!("SELECT LENGTH(pad) AS n FROM t WHERE id={WIDE_ID}")).is_err()
            } else {
                d.scalar("SELECT COUNT(*) AS n FROM t").ok() != Some(expected_rows.to_string())
            };
            if symptom {
                first_symptom = Some(i + 1);
            }
        }
    }
    obs("4.inserts_committed", format!("{committed}/40"));
    obs("4.insert_number_at_first_symptom", first_symptom.map_or("none".into(), |n| n.to_string()));
    let wide = d.scalar(&format!("SELECT pad FROM t WHERE id={WIDE_ID}"));
    if variant == "live" {
        obs("7.wide_row_read_after", match &wide { Ok(v) => format!("ok identical={}", v == &wide_expected), Err(e) => format!("ERROR {e}") });
    }
    obs("8.full_scan", match d.scalar("SELECT COUNT(*) AS n FROM t WHERE pad<>'q'") { Ok(v) => format!("ok rows={v} (expected {expected_rows})"), Err(e) => format!("ERROR {e}") });
    obs("8b.count_star", format!("{:?} expected={expected_rows}", d.scalar("SELECT COUNT(*) AS n FROM t")));
    obs("8c.count_new_rows_by_scan", format!("{:?} expected=40", d.scalar("SELECT COUNT(*) AS n FROM t WHERE id>=5000 AND pad<>'q'")));
    obs("9.checkpoint", match d.t("CHECKPOINT") { Ok(_) => "ok".into(), Err(e) => format!("ERROR {e}") });
    d.close();
    dump_overflow("after_inserts", &d.dir);
    let bad = bad_overflow(&d.dir);
    obs("5.ordinary_tuples_on_overflow_pages", bad.iter().map(|p| format!("page {} ids {:?}", p.id, p.ordinary_ids)).collect::<Vec<_>>().join("; "));
    obs("6.invalid_overflow_slot_counts", bad.iter().map(|p| format!("page {}: 1 -> {}", p.id, p.slot_count)).collect::<Vec<_>>().join("; "));
    obs("10.phobos_admin_check", d.check().unwrap_or_else(|e| e));
    // Point lookups of misplaced rows (index path).
    d.db = Some(Arc::new(Coordinator::open(&d.dir).unwrap()));
    d.s = d.db().new_session();
    if let Some(p) = bad.first() {
        if let Some(id) = p.ordinary_ids.first() {
            obs("8d.index_point_lookup_of_misplaced_row", format!("id={id} -> {:?}", d.scalar(&format!("SELECT v FROM t WHERE id={id}"))));
        }
    }
    // 11. restarts do not repair.
    for n in 1..=2 {
        d.reopen();
        let w = if variant == "live" {
            format!("{:?}", d.scalar(&format!("SELECT LENGTH(pad) AS n FROM t WHERE id={WIDE_ID}")))
        } else {
            format!("count={:?} expected={expected_rows}", d.scalar("SELECT COUNT(*) AS n FROM t"))
        };
        obs(&format!("11.after_restart_{n}"), w);
    }
    obs("11.check_after_restarts", d.check().unwrap_or_else(|e| e));
    obs("bad_pages_final", bad_overflow(&d.dir).len());
    obs("db_dir", d.dir.display());
}

pub fn open_check(dir: &Path) {
    let mut d = Db::open(dir);
    obs("open_check.count", format!("{:?}", d.scalar("SELECT COUNT(*) AS n FROM t")));
    obs("open_check.check", d.check().unwrap_or_else(|e| e));
}

pub fn wal_inspect(dir: &Path) {
    match phobos_wal::v2::inspect(dir.join("phobos.wal")) {
        Ok(r) => obs("wal", format!("last_lsn={} checkpoint_lsn={} committed={} aborted={} incomplete={} valid_len={} page_format={} tail={:?}", r.last_lsn, r.checkpoint_lsn, r.committed_transactions, r.aborted_transactions, r.incomplete_transactions, r.valid_len, r.page_format, r.tail)),
        Err(e) => obs("wal", format!("ERROR {e:?}")),
    }
}
