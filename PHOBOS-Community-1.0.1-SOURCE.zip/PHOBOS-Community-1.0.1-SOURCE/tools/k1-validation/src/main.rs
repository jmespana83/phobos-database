//! PHOBOS 0.2-I.1 overflow-safety harness (diagnostic/test only).
//! Built twice from this one source: against pristine 0.2-I (h-pristine) and
//! against the 0.2-I.1 tree (h-fix). Drives the engine only through supported
//! public paths (legacy create + migrate_mvcc_copy, Coordinator SQL,
//! phobos-admin). Raw page inspection is read-only.
#![allow(clippy::all)]
mod inspect;

use phobos_server::Coordinator;
use std::{
    fs,
    path::{Path, PathBuf},
    sync::Arc,
    time::Instant,
};

pub const PAGE: usize = 8192;

pub fn obs(key: &str, value: impl std::fmt::Display) {
    println!("OBS {key} = {value}");
}

/// Deterministic, non-repeating-ish text so byte identity is meaningful.
pub fn text(len: usize, seed: u64) -> String {
    let mut x = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    (0..len)
        .map(|_| {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            (b'a' + (x % 26) as u8) as char
        })
        .collect()
}
pub fn fnv(bytes: &[u8]) -> u64 {
    let mut h = 0xcbf2_9ce4_8422_2325u64;
    for b in bytes {
        h ^= u64::from(*b);
        h = h.wrapping_mul(0x100_0000_01b3);
    }
    h
}

pub struct Db {
    pub dir: PathBuf,
    pub db: Option<Arc<Coordinator>>,
    pub s: u64,
}

pub const SCHEMA: &str = "CREATE TABLE t (id BIGINT NOT NULL, k BIGINT, u BIGINT, v BIGINT, pad TEXT)";

impl Db {
    /// Fresh MVCC database via the supported path: legacy create + offline
    /// `migrate_mvcc_copy`, then `Coordinator::open`.
    pub fn create(root: &Path) -> Db {
        let _ = fs::remove_dir_all(root);
        fs::create_dir_all(root).unwrap();
        let source = root.join("source");
        {
            let mut legacy = phobos_execution::Database::open(&source).unwrap();
            legacy.execute(SCHEMA).unwrap();
        }
        let dir = root.join("db");
        phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
        let _ = fs::remove_dir_all(&source);
        let _ = fs::remove_dir_all(root.join("backup"));
        let mut d = Db::open(&dir);
        d.x("CREATE UNIQUE INDEX t_id ON t(id)");
        d.x("CREATE INDEX t_k ON t(k)");
        d
    }
    pub fn open(dir: &Path) -> Db {
        let db = Arc::new(Coordinator::open(dir).unwrap());
        let s = db.new_session();
        Db {
            dir: dir.to_path_buf(),
            db: Some(db),
            s,
        }
    }
    pub fn db(&self) -> &Arc<Coordinator> {
        self.db.as_ref().unwrap()
    }
    pub fn x(&mut self, sql: &str) -> String {
        match self.db().execute(self.s, sql) {
            Ok(r) => r,
            Err(e) => panic!("{}: {e:?}", &sql[..sql.len().min(120)]),
        }
    }
    pub fn t(&mut self, sql: &str) -> Result<String, String> {
        self.db()
            .execute(self.s, sql)
            .map_err(|e| format!("{:?}: {}", e.code, e.message))
    }
    pub fn scalar(&mut self, sql: &str) -> Result<String, String> {
        self.t(sql)
            .map(|r| r.lines().nth(1).unwrap_or("").trim().to_string())
    }
    pub fn close(&mut self) {
        if let Some(db) = self.db.take() {
            db.disconnect(self.s);
            db.shutdown().unwrap();
        }
    }
    pub fn reopen(&mut self) -> f64 {
        self.close();
        let t = Instant::now();
        let db = Arc::new(Coordinator::open(&self.dir).unwrap());
        self.s = db.new_session();
        self.db = Some(db);
        t.elapsed().as_secs_f64()
    }
    pub fn check(&mut self) -> Result<String, String> {
        self.close();
        phobos_admin::check_integrity(&self.dir)
            .map(|r| format!("PASS tables={} indexes={} index_pages={}", r.tables, r.indexes, r.index_pages))
            .map_err(|e| format!("FAIL {:?}: {}", e.code, e.message))
    }
}
impl Drop for Db {
    fn drop(&mut self) {
        self.close();
    }
}

pub fn row(id: u64, padlen: usize, seed: u64) -> String {
    format!("({id},{},{id},{id},'{}')", id % 97, text(padlen, seed))
}
pub fn insert_many(d: &mut Db, from: u64, n: u64, padlen: usize) {
    let mut id = from;
    while id < from + n {
        let end = (id + 49).min(from + n - 1);
        let vals = (id..=end).map(|i| row(i, padlen, i)).collect::<Vec<_>>().join(",");
        d.x(&format!("INSERT INTO t VALUES {vals}"));
        id = end + 1;
    }
}

/// Raw, read-only heap page description.
#[derive(Debug, Clone)]
pub struct PageInfo {
    pub id: usize,
    pub overflow: bool,
    pub slot_count: u16,
    pub slots: Vec<String>,
    pub ordinary_ids: Vec<i64>,
}
pub fn pages(dir: &Path) -> Vec<PageInfo> {
    let Some(path) = inspect::heap_path(dir) else {
        return Vec::new();
    };
    let bytes = fs::read(path).unwrap();
    bytes
        .chunks_exact(PAGE)
        .enumerate()
        .map(|(id, p)| {
            let n = u16::from_le_bytes([p[28], p[29]]);
            let mut slots = Vec::new();
            let mut ids = Vec::new();
            for s in 0..n as usize {
                let o = 40 + 4 * s;
                let off = u16::from_le_bytes([p[o], p[o + 1]]) as usize;
                let len = u16::from_le_bytes([p[o + 2], p[o + 3]]) as usize;
                if len == 0 {
                    slots.push(format!("{s}:tombstone"));
                    continue;
                }
                let r = &p[off..off + len];
                let magic = String::from_utf8_lossy(&r[..4]).to_string();
                if &r[..4] == b"PHOV" {
                    let next = u64::from_le_bytes(r[8..16].try_into().unwrap());
                    let ord = u32::from_le_bytes(r[16..20].try_into().unwrap());
                    let chunk = u32::from_le_bytes(r[20..24].try_into().unwrap());
                    slots.push(format!(
                        "{s}:PHOV-chunk(ordinal={ord},len={chunk},next={})",
                        if next == u64::MAX { "none".into() } else { next.to_string() }
                    ));
                } else if &r[..4] == b"PHMV" && r[4] == 1 && len >= 59 {
                    let id = i64::from_le_bytes(r[51..59].try_into().unwrap());
                    let deleter = u64::from_le_bytes(r[16..24].try_into().unwrap());
                    slots.push(format!("{s}:PHMV-inline(id={id},len={len},deleted={})", deleter != 0));
                    ids.push(id);
                } else if &r[..4] == b"PHMV" && r[4] == 2 {
                    let first = u64::from_le_bytes(r[48..56].try_into().unwrap());
                    let pc = u32::from_le_bytes(r[56..60].try_into().unwrap());
                    slots.push(format!("{s}:PHMV-overflow-envelope(first_page={first},pages={pc})"));
                } else {
                    slots.push(format!("{s}:{magic}(len={len})"));
                }
            }
            PageInfo {
                id,
                overflow: p[30] & 2 != 0,
                slot_count: n,
                slots,
                ordinary_ids: ids,
            }
        })
        .collect()
}
pub fn overflow_pages(dir: &Path) -> Vec<PageInfo> {
    pages(dir).into_iter().filter(|p| p.overflow).collect()
}
pub fn dump_overflow(label: &str, dir: &Path) {
    for p in overflow_pages(dir) {
        obs(
            &format!("{label}.overflow_page[{}]", p.id),
            format!("kind=overflow slot_count={} slots=[{}]", p.slot_count, p.slots.join("; ")),
        );
    }
}
pub fn bad_overflow(dir: &Path) -> Vec<PageInfo> {
    overflow_pages(dir).into_iter().filter(|p| p.slot_count != 1).collect()
}

mod bench;
mod scenarios;
mod validation;

fn main() {
    let a: Vec<String> = std::env::args().collect();
    let arg = |i: usize| a.get(i).cloned().unwrap_or_default();
    match arg(1).as_str() {
        "repro" => scenarios::repro(Path::new(&arg(2)), &arg(3)),
        "matrix" => validation::matrix(Path::new(&arg(2))),
        "repair-validate" => validation::repair_validate(Path::new(&arg(2)), Path::new(&arg(3))),
        "crash-child" => validation::crash_child(Path::new(&arg(2)), &arg(3)),
        "crash-check" => validation::crash_check(Path::new(&arg(2)), &arg(3)),
        "replication" => validation::replication(Path::new(&arg(2))),
        "open-check" => scenarios::open_check(Path::new(&arg(2))),
        "wal" => scenarios::wal_inspect(Path::new(&arg(2))),
        "make-healthy" => validation::make_healthy(Path::new(&arg(2))),
        "reopen-healthy" => validation::reopen_healthy(Path::new(&arg(2))),
        "bench" => bench::run(Path::new(&arg(2))),
        "bulk" => bench::bulk(Path::new(&arg(2)), arg(3).parse().unwrap()),
        "bulksql" => bench::bulksql(Path::new(&arg(2)), arg(3).parse().unwrap()),
        "secondary" => bench::secondary(Path::new(&arg(2))),
        "repl-min" => validation::repl_min(Path::new(&arg(2)), &arg(3)),
        other => eprintln!("unknown mode {other:?}"),
    }
}
