//! Parts C, F, G, H of the 0.2-I.1 validation.
use super::*;
use std::collections::BTreeMap;

/// Expected logical content: id -> (text length, text seed).
#[derive(Default, Clone)]
pub struct Model(pub BTreeMap<i64, (usize, u64)>);

impl Model {
    fn sql_row(id: i64, len: usize, seed: u64) -> String {
        format!("({id},{},{id},{id},'{}')", id.rem_euclid(97), text(len, seed))
    }
    /// One multi-row INSERT statement (rows are recorded only on success).
    pub fn insert(&mut self, d: &mut Db, rows: &[(i64, usize, u64)]) -> Result<(), String> {
        let values = rows
            .iter()
            .map(|(id, len, seed)| Self::sql_row(*id, *len, *seed))
            .collect::<Vec<_>>()
            .join(",");
        d.t(&format!("INSERT INTO t VALUES {values}"))?;
        for (id, len, seed) in rows {
            self.0.insert(*id, (*len, *seed));
        }
        Ok(())
    }
    pub fn insert_range(&mut self, d: &mut Db, from: i64, n: i64, len: usize) -> Result<(), String> {
        let mut id = from;
        while id < from + n {
            let end = (id + 24).min(from + n - 1);
            let rows = (id..=end).map(|i| (i, len, i as u64)).collect::<Vec<_>>();
            self.insert(d, &rows)?;
            id = end + 1;
        }
        Ok(())
    }
    pub fn set_text(&mut self, d: &mut Db, id: i64, len: usize, seed: u64) -> Result<(), String> {
        d.t(&format!("UPDATE t SET pad='{}' WHERE id={id}", text(len, seed)))?;
        self.0.insert(id, (len, seed));
        Ok(())
    }
    pub fn delete(&mut self, d: &mut Db, id: i64) -> Result<(), String> {
        d.t(&format!("DELETE FROM t WHERE id={id}"))?;
        self.0.remove(&id);
        Ok(())
    }
    /// Full logical verification. Returns a list of failures (empty = pass).
    pub fn verify(&self, d: &mut Db) -> Vec<String> {
        let mut bad = Vec::new();
        let n = self.0.len().to_string();
        match d.scalar("SELECT COUNT(*) AS n FROM t") {
            Ok(v) if v == n => {}
            other => bad.push(format!("COUNT(*) {other:?} expected {n}")),
        }
        match d.scalar("SELECT COUNT(*) AS n FROM t WHERE pad<>'#'") {
            Ok(v) if v == n => {}
            other => bad.push(format!("full scan {other:?} expected {n}")),
        }
        for (id, (len, seed)) in &self.0 {
            let want = text(*len, *seed);
            match d.scalar(&format!("SELECT pad FROM t WHERE id={id}")) {
                Ok(v) if v == want => {}
                Ok(v) => bad.push(format!("id {id}: content mismatch (len {} vs {len})", v.len())),
                Err(e) => bad.push(format!("id {id}: {e}")),
            }
            if bad.len() > 10 {
                break;
            }
        }
        // Secondary (non-unique) index agrees with the model.
        for k in [0i64, 7, 42, 96] {
            let want = self.0.keys().filter(|id| id.rem_euclid(97) == k).count().to_string();
            match d.scalar(&format!("SELECT COUNT(*) AS n FROM t WHERE k={k}")) {
                Ok(v) if v == want => {}
                other => bad.push(format!("index k={k}: {other:?} expected {want}")),
            }
        }
        bad
    }
}

fn outcome(label: &str, failures: &[String]) -> bool {
    if failures.is_empty() {
        obs(label, "PASS");
        true
    } else {
        obs(label, format!("FAIL {}", failures.join(" | ")));
        false
    }
}

fn base(root: &Path) -> (Db, Model) {
    let mut d = Db::create(root);
    let mut m = Model::default();
    m.insert_range(&mut d, 1, 100, 40).unwrap();
    (d, m)
}

/// Verify, CHECKPOINT, shut down, check, restart twice (verify + check each).
fn finish(name: &str, d: &mut Db, m: &Model, restarts: &mut u32) -> bool {
    let mut fails = m.verify(d);
    if let Err(e) = d.t("CHECKPOINT") {
        fails.push(format!("CHECKPOINT {e}"));
    }
    d.close();
    let bad = bad_overflow(&d.dir);
    if !bad.is_empty() {
        fails.push(format!(
            "ordinary tuples on overflow pages: {:?}",
            bad.iter().map(|p| (p.id, p.slot_count, p.ordinary_ids.clone())).collect::<Vec<_>>()
        ));
    }
    if let Err(e) = d.check() {
        fails.push(format!("check {e}"));
    }
    for _ in 0..2 {
        d.db = Some(Arc::new(Coordinator::open(&d.dir).unwrap()));
        d.s = d.db().new_session();
        *restarts += 1;
        fails.extend(m.verify(d));
        if let Err(e) = d.check() {
            fails.push(format!("check after restart {e}"));
        }
    }
    d.db = Some(Arc::new(Coordinator::open(&d.dir).unwrap()));
    d.s = d.db().new_session();
    obs(
        &format!("{name}.final"),
        format!(
            "rows={} overflow_pages={} restarts={restarts}",
            m.0.len(),
            overflow_pages(&d.dir).len()
        ),
    );
    outcome(&format!("{name}.result"), &fails)
}

fn restart(d: &mut Db, restarts: &mut u32) {
    d.reopen();
    *restarts += 1;
}

/// Part C: regression matrix. Every variant ends with `finish`.
pub fn matrix(root: &Path) {
    let mut summary = Vec::new();
    let variants: [(&str, fn(&mut Db, &mut Model, &mut u32) -> Result<(), String>); 13] = [
        ("01_wide_near_min_threshold", |d, m, r| {
            // payload just above the inline limit: 2 chunks, 2nd tiny.
            m.insert(d, &[(1000, 8100, 1)])?;
            m.insert_range(d, 2000, 50, 40)?;
            restart(d, r);
            m.insert_range(d, 5000, 40, 1600)
        }),
        ("02_very_wide_multi_page", |d, m, r| {
            m.insert(d, &[(1000, 100_000, 2)])?;
            m.insert_range(d, 2000, 50, 40)?;
            restart(d, r);
            m.insert_range(d, 5000, 60, 1600)
        }),
        ("03_several_wide_rows", |d, m, r| {
            for i in 0..5 {
                m.insert(d, &[(1000 + i, 20_000 + 3000 * i as usize, 10 + i as u64)])?;
            }
            m.insert_range(d, 2000, 50, 40)?;
            restart(d, r);
            m.insert_range(d, 5000, 80, 1600)
        }),
        ("04_wide_interleaved_with_normal", |d, m, r| {
            for c in 0..10i64 {
                m.insert_range(d, 2000 + c * 30, 30, 40)?;
                m.insert(d, &[(1000 + c, 9000 + 2500 * c as usize, 20 + c as u64)])?;
            }
            restart(d, r);
            m.insert_range(d, 5000, 80, 1600)
        }),
        ("05_restart_then_many_small_inserts", |d, m, r| {
            m.insert(d, &[(1000, 20_000, 3)])?;
            m.insert_range(d, 2000, 300, 40)?;
            restart(d, r);
            for i in 0..500 {
                m.insert(d, &[(5000 + i, 10, 5000 + i as u64)])?;
            }
            Ok(())
        }),
        ("06_restart_then_medium_and_large_inserts", |d, m, r| {
            m.insert(d, &[(1000, 20_000, 4), (1001, 30_000, 5)])?;
            m.insert_range(d, 2000, 300, 40)?;
            restart(d, r);
            for i in 0..40 {
                m.insert(d, &[(5000 + i, 1600, 5000 + i as u64)])?;
                m.insert(d, &[(6000 + i, 6000, 6000 + i as u64)])?;
            }
            Ok(())
        }),
        ("07_multiple_restart_cycles", |d, m, r| {
            for c in 0..5i64 {
                m.insert(d, &[(1000 + c, 18_000, 30 + c as u64)])?;
                m.insert_range(d, 2000 + c * 100, 60, 40)?;
                restart(d, r);
                for i in 0..20 {
                    m.insert(d, &[(5000 + c * 100 + i, 1600, (5000 + c * 100 + i) as u64)])?;
                }
                restart(d, r);
            }
            Ok(())
        }),
        ("08_update_normal_rows_after_restart", |d, m, r| {
            m.insert(d, &[(1000, 20_000, 6)])?;
            m.insert_range(d, 2000, 300, 40)?;
            restart(d, r);
            for id in 2000..2100 {
                m.set_text(d, id, 1600, 70_000 + id as u64)?;
            }
            Ok(())
        }),
        ("09_update_creates_and_replaces_wide_rows", |d, m, r| {
            m.insert(d, &[(1000, 20_000, 7)])?;
            m.insert_range(d, 2000, 300, 40)?;
            restart(d, r);
            m.set_text(d, 1000, 26_000, 8)?; // wide -> different wide
            m.set_text(d, 2000, 21_000, 9)?; // normal -> wide
            m.set_text(d, 2001, 40, 10)?;
            restart(d, r);
            m.set_text(d, 2000, 40, 11)?; // wide -> normal
            m.insert_range(d, 5000, 40, 1600)
        }),
        ("10_delete_wide_then_space_reuse", |d, m, r| {
            for i in 0..3 {
                m.insert(d, &[(1000 + i, 20_000, 40 + i as u64)])?;
            }
            m.insert_range(d, 2000, 300, 40)?;
            m.delete(d, 1000)?;
            m.delete(d, 1001)?;
            for _ in 0..20 {
                let p = d.db().reclaim_once(64).map_err(|e| e.message)?;
                if p.versions_reclaimed == 0 && p.candidates_remaining == 0 {
                    break;
                }
            }
            d.t("CHECKPOINT")?;
            restart(d, r);
            m.insert_range(d, 5000, 40, 1600)?;
            m.insert(d, &[(1010, 20_000, 50)])?; // reuses released overflow pages
            m.insert_range(d, 5100, 40, 1600)
        }),
        ("11_checkpoint_before_and_after_restart", |d, m, r| {
            m.insert(d, &[(1000, 20_000, 12)])?;
            m.insert_range(d, 2000, 300, 40)?;
            d.t("CHECKPOINT")?;
            restart(d, r);
            d.t("CHECKPOINT")?;
            m.insert_range(d, 5000, 20, 1600)?;
            d.t("CHECKPOINT")?;
            m.insert_range(d, 5100, 20, 1600)?;
            d.t("CHECKPOINT")?;
            Ok(())
        }),
        ("12_wal_recovery_without_checkpoint", |d, m, r| {
            // Clean reopen paths whose redo comes from WAL, not checkpointed pages.
            m.insert(d, &[(1000, 20_000, 13)])?;
            m.insert_range(d, 2000, 300, 40)?;
            restart(d, r);
            m.insert_range(d, 5000, 40, 1600)?;
            restart(d, r);
            m.insert_range(d, 5100, 40, 1600)
        }),
        ("13_bulk_load_after_restart_with_overflow_tail", |d, m, r| {
            m.insert_range(d, 2000, 300, 40)?;
            m.insert(d, &[(1000, 20_000, 14)])?; // overflow pages at the heap tail
            restart(d, r);
            let rows = (0..200i64)
                .map(|i| {
                    let id = 7000 + i;
                    Ok(phobos_types::Row {
                        values: vec![
                            phobos_types::Value::Int64(id),
                            phobos_types::Value::Int64(id.rem_euclid(97)),
                            phobos_types::Value::Int64(id),
                            phobos_types::Value::Int64(id),
                            phobos_types::Value::Text(text(1600, id as u64)),
                        ],
                    })
                })
                .collect::<Vec<_>>();
            let s = d.s;
            d.db().bulk_load(s, "t", rows).map_err(|e| e.message)?;
            for i in 0..200i64 {
                m.0.insert(7000 + i, (1600, (7000 + i) as u64));
            }
            m.insert_range(d, 5000, 40, 1600)
        }),
    ];
    for (name, run) in variants {
        let dir = root.join(name);
        let (mut d, mut m) = base(&dir);
        let mut restarts = 0u32;
        let t0 = Instant::now();
        let step = run(&mut d, &mut m, &mut restarts);
        if let Err(e) = &step {
            obs(&format!("{name}.workload_error"), e);
        }
        let ok = finish(name, &mut d, &m, &mut restarts) && step.is_ok();
        summary.push(format!("{name}={}", if ok { "PASS" } else { "FAIL" }));
        obs(&format!("{name}.seconds"), format!("{:.1}", t0.elapsed().as_secs_f64()));
        drop(d);
        let _ = fs::remove_dir_all(&dir);
    }
    obs("matrix.summary", summary.join(" "));
}

/// Model of the Part A fixtures (rows that were committed on pristine 0.2-I).
fn fixture_model(variant: &str) -> Model {
    let mut m = Model::default();
    for id in 1..=100 {
        m.0.insert(id, (40, id as u64));
    }
    for id in 2000..2300 {
        m.0.insert(id, (40, id as u64));
    }
    for id in 5000..5040 {
        m.0.insert(id, (1600, id as u64));
    }
    if variant == "live" {
        m.0.insert(1000, (20_000, 424_242));
    }
    m
}

#[cfg(not(feature = "fix"))]
pub fn repair_validate(_root: &Path, _fixture: &Path) {
    obs("repair_validate", "requires the 0.2-I.1 build");
}

/// Part F: repair a database damaged by pristine 0.2-I using 0.2-I.1.
#[cfg(feature = "fix")]
pub fn repair_validate(root: &Path, fixture: &Path) {
    let variant = if fixture.to_string_lossy().contains("freed") { "freed" } else { "live" };
    obs("variant", variant);
    let _ = fs::remove_dir_all(root);
    fs::create_dir_all(root).unwrap();
    let dir = root.join("db");
    fs::create_dir_all(&dir).unwrap();
    for e in fs::read_dir(fixture.join("db")).unwrap() {
        let p = e.unwrap().path();
        fs::copy(&p, dir.join(p.file_name().unwrap())).unwrap();
    }
    let mut m = fixture_model(variant);
    // ---- before repair (0.2-I.1 engine opening the damaged database) ----
    dump_overflow("before", &dir);
    let mut d = Db::open(&dir);
    if variant == "live" {
        obs("before.select_wide_row", format!("{:?}", d.scalar("SELECT LENGTH(pad) AS n FROM t WHERE id=1000")));
    }
    obs("before.full_scan", format!("{:?} expected {}", d.scalar("SELECT COUNT(*) AS n FROM t WHERE pad<>'#'"), m.0.len()));
    obs("before.count_star", format!("{:?} expected {}", d.scalar("SELECT COUNT(*) AS n FROM t"), m.0.len()));
    obs("before.misplaced_point_lookup", format!("{:?}", d.scalar("SELECT v FROM t WHERE id=5014")));
    obs("before.checkpoint", format!("{:?}", d.t("CHECKPOINT").map(|_| "ok")));
    // 0.2-I.1 post-restart inserts must not add damage even on a damaged DB.
    let before_bad = bad_overflow(&dir).iter().map(|p| (p.id, p.slot_count)).collect::<Vec<_>>();
    d.close();
    obs("before.phobos_admin_check", d.check().unwrap_or_else(|e| e));
    // ---- refusal paths ----
    let backup = root.join("backup");
    let snapshot = |dir: &Path| -> Vec<(String, Vec<u8>)> {
        let mut v: Vec<_> = fs::read_dir(dir).unwrap().flatten().filter(|e| e.path().is_file())
            .map(|e| (e.file_name().to_string_lossy().to_string(), fs::read(e.path()).unwrap())).collect();
        v.sort();
        v
    };
    let before_files = snapshot(&dir);
    let dry = phobos_admin::repair_overflow(&dir, &backup, true).unwrap();
    for t in &dry.tables {
        for v in &t.violations {
            obs("dry_run.damaged", v);
        }
        for a in &t.actions {
            obs("dry_run.would", a);
        }
    }
    obs("dry_run.changed_nothing", bad_overflow(&dir).iter().map(|p| (p.id, p.slot_count)).collect::<Vec<_>>() == before_bad && !backup.exists());
    obs("dry_run.every_file_byte_identical", snapshot(&dir) == before_files && !backup.exists());
    // Restore-on-failure: a separate copy whose unrelated index page is
    // corrupted so the post-repair integrity check must fail.
    {
        let fdir = root.join("fault").join("db");
        fs::create_dir_all(&fdir).unwrap();
        for (name, bytes) in &before_files {
            fs::write(fdir.join(name), bytes).unwrap();
        }
        let idx = fs::read_dir(&fdir).unwrap().flatten().map(|e| e.path()).filter(|p| p.extension().is_some_and(|x| x == "idx")).max().unwrap();
        let mut b = fs::read(&idx).unwrap();
        b[8192 + 100] ^= 0xFF; // first tree page: checksum now wrong
        fs::write(&idx, &b).unwrap();
        let heap = inspect::heap_path(&fdir).unwrap();
        let heap_before = fs::read(&heap).unwrap();
        let r = phobos_admin::repair_overflow(&fdir, &root.join("fault").join("backup"), false);
        obs("fault.repair_result", format!("{:?}", r.as_ref().map(|_| "ok").map_err(|e| e.message.clone())));
        obs("fault.heap_restored_byte_identical_to_damaged", fs::read(&heap).unwrap() == heap_before);
        obs("fault.no_temporary_files_left", fs::read_dir(&fdir).unwrap().flatten().all(|e| !e.file_name().to_string_lossy().ends_with(".tmp")));
    }
    {
        // A running server holds an exclusive lock on phobos.lock
        // (`lock_data_directory`); emulate exactly that lock.
        use fs2::FileExt;
        let lock = fs::OpenOptions::new().create(true).read(true).write(true).truncate(false).open(dir.join("phobos.lock")).unwrap();
        lock.try_lock_exclusive().unwrap();
        obs("refuse.while_server_lock_held", format!("{:?}", phobos_admin::repair_overflow(&dir, &backup, false).map(|_| "ran").map_err(|e| e.message)));
        drop(lock);
    }
    obs("refuse.damage_still_present", bad_overflow(&dir).len());
    fs::create_dir_all(&backup).unwrap();
    fs::write(backup.join("junk"), b"x").unwrap();
    obs("refuse.nonempty_backup", format!("{:?}", phobos_admin::repair_overflow(&dir, &backup, false).map(|_| "ran").map_err(|e| e.message)));
    fs::remove_dir_all(&backup).unwrap();
    // ---- repair ----
    let heap_before = fs::read(inspect::heap_path(&dir).unwrap()).unwrap();
    let t0 = Instant::now();
    let report = phobos_admin::repair_overflow(&dir, &backup, false).unwrap();
    obs("repair.seconds", format!("{:.3}", t0.elapsed().as_secs_f64()));
    for t in &report.tables {
        obs("repair.table", format!("{} (id {}) heap {} pages {} -> {}", t.table, t.table_id, t.heap_file, t.pages_before, t.pages_after));
        for a in &t.actions {
            obs("repair.did", a);
        }
    }
    obs("repair.backup_files", report.backup_files);
    obs("repair.integrity", format!("{:?}", report.integrity));
    obs("repair.backup_heap_identical_to_damaged", fs::read(backup.join(inspect::heap_path(&dir).unwrap().file_name().unwrap())).unwrap() == heap_before);
    dump_overflow("after", &dir);
    let heap_after = fs::read(inspect::heap_path(&dir).unwrap()).unwrap();
    let pages_changed = heap_before
        .chunks(PAGE)
        .zip(heap_after.chunks(PAGE))
        .enumerate()
        .filter(|(_, (a, b))| a != b)
        .map(|(i, _)| i)
        .collect::<Vec<_>>();
    obs("repair.pages_changed", format!("{pages_changed:?} appended={}", (heap_after.len() - heap_before.len()) / PAGE));
    // Repairing again is a no-op.
    let again = phobos_admin::repair_overflow(&dir, &root.join("backup2"), false).unwrap();
    obs("repair.second_run_tables", again.tables.len());
    // Index files untouched (no RID moved).
    let idx_same = fs::read_dir(&dir).unwrap().flatten().filter(|e| e.path().extension().is_some_and(|x| x == "idx")).all(|e| {
        fs::read(e.path()).unwrap() == fs::read(backup.join(e.file_name())).unwrap()
    });
    obs("repair.index_files_byte_identical", idx_same);
    // ---- after repair: the 14 checks ----
    let mut d = Db::open(&dir);
    let mut results = Vec::new();
    let mut rec = |n: &str, ok: bool, detail: String| {
        obs(&format!("after.{n}"), format!("{} {detail}", if ok { "PASS" } else { "FAIL" }));
        results.push(ok);
    };
    if variant == "live" {
        let w = d.scalar("SELECT pad FROM t WHERE id=1000");
        let want = text(20_000, 424_242);
        rec("01_wide_row_byte_identical", w.as_deref() == Ok(want.as_str()), format!("fnv={:016x}", w.as_ref().map(|v| fnv(v.as_bytes())).unwrap_or(0)));
    } else {
        rec("01_wide_row_byte_identical", true, "n/a (wide row deleted before damage in this fixture)".into());
    }
    let v = m.verify(&mut d);
    rec("02_all_rows_present_and_correct", v.is_empty(), format!("{} rows {v:?}", m.0.len()));
    let c = d.scalar("SELECT COUNT(*) AS n FROM t");
    rec("03_count_star", c.as_deref() == Ok(m.0.len().to_string().as_str()), format!("{c:?}"));
    let pl: Vec<_> = [1i64, 100, 2000, 2299, 5000, 5014, 5015, 5039].iter().filter(|id| m.0.contains_key(id)).map(|id| (id, d.scalar(&format!("SELECT v FROM t WHERE id={id}")))).collect();
    rec("04_point_lookups", pl.iter().all(|(id, r)| r.as_deref() == Ok(id.to_string().as_str())), format!("{pl:?}"));
    let k = d.scalar("SELECT COUNT(*) AS n FROM t WHERE k=67 OR k=68");
    let want_k = m.0.keys().filter(|id| matches!(id.rem_euclid(97), 67 | 68)).count();
    rec("05_indexed_lookups", k.as_deref() == Ok(want_k.to_string().as_str()), format!("k IN (67,68) [keys of misplaced rows 5014,5015] -> {k:?} expected {want_k}"));
    let dup = d.t(&format!("INSERT INTO t VALUES {}", Model::sql_row(5014, 10, 1)));
    let fresh = m.insert(&mut d, &[(8000, 40, 8000)]);
    rec("06_unique", dup.as_ref().is_err_and(|e| e.contains("ConstraintViolation")) && fresh.is_ok(), format!("duplicate 5014 -> {dup:?}; new 8000 -> {fresh:?}"));
    let u = m.set_text(&mut d, 5014, 50, 99).and_then(|_| m.set_text(&mut d, 5015, 3000, 98));
    rec("07_update", u.is_ok() && m.verify(&mut d).is_empty(), format!("{u:?}"));
    let del = m.delete(&mut d, 5016).and_then(|_| m.delete(&mut d, 2001));
    rec("08_delete", del.is_ok() && d.scalar("SELECT COUNT(*) AS n FROM t WHERE id=5016").as_deref() == Ok("0"), format!("{del:?}"));
    let ins = m.insert_range(&mut d, 8100, 30, 1600);
    rec("09_insert", ins.is_ok(), format!("{ins:?}"));
    let ck = d.t("CHECKPOINT");
    rec("10_checkpoint", ck.is_ok(), format!("{:?}", ck.map(|_| "ok")));
    let chk = d.check();
    rec("11_phobos_admin_check", chk.is_ok(), chk.clone().unwrap_or_else(|e| e));
    d.db = Some(Arc::new(Coordinator::open(&dir).unwrap()));
    d.s = d.db().new_session();
    let v1 = m.verify(&mut d);
    rec("12_clean_restart", v1.is_empty(), format!("{v1:?}"));
    d.reopen();
    let v2 = m.verify(&mut d);
    rec("13_second_restart", v2.is_empty(), format!("{v2:?}"));
    let more = m.insert_range(&mut d, 9000, 60, 1600).and_then(|_| m.insert(&mut d, &[(9500, 20_000, 77)]));
    d.reopen();
    let more2 = m.insert_range(&mut d, 9100, 60, 1600);
    let v3 = m.verify(&mut d);
    d.close();
    let bad = bad_overflow(&dir);
    let chk2 = d.check();
    rec("14_further_inserts_cannot_recreate", more.is_ok() && more2.is_ok() && v3.is_empty() && bad.is_empty() && chk2.is_ok(), format!("bad_pages={} check={:?}", bad.len(), chk2));
    obs("after.summary", format!("{}/{} PASS", results.iter().filter(|r| **r).count(), results.len()));
    obs("after.final_rows", m.0.len());
}

// ------------------------------------------------------------- Part G ---

fn crash_model(phase: &str) -> Model {
    let mut m = Model::default();
    for id in 1..=100 {
        m.0.insert(id, (40, id as u64));
    }
    m.0.insert(1000, (20_000, 1));
    m.0.insert(1001, (30_000, 2));
    for id in 2000..2300 {
        m.0.insert(id, (40, id as u64));
    }
    if phase != "wide" {
        for id in 5000..5040 {
            m.0.insert(id, (1600, id as u64));
        }
    }
    if phase == "ckpt" || phase == "midflight" {
        for id in 5100..5140 {
            m.0.insert(id, (1600, id as u64));
        }
    }
    m
}

/// Child process: perform acknowledged work, then `abort()` (no shutdown,
/// no checkpoint, no destructors): a crash as seen by the database files.
pub fn crash_child(root: &Path, phase: &str) {
    let dir = root.join("db");
    let mut m = Model::default();
    let mut d = if phase == "wide" {
        let mut d = Db::create(root);
        m.insert_range(&mut d, 1, 100, 40).unwrap();
        m.insert(&mut d, &[(1000, 20_000, 1)]).unwrap();
        m.insert(&mut d, &[(1001, 30_000, 2)]).unwrap();
        m.insert_range(&mut d, 2000, 300, 40).unwrap();
        d
    } else {
        Db::open(&dir)
    };
    match phase {
        "wide" => {}
        "post" => m.insert_range(&mut d, 5000, 40, 1600).unwrap(),
        "ckpt" | "midflight" => {
            d.x("CHECKPOINT");
            if phase == "midflight" {
                // Abort while a stream of single-row inserts is in flight;
                // only acknowledged rows are required to survive.
                let db = d.db().clone();
                std::thread::spawn(move || {
                    std::thread::sleep(std::time::Duration::from_millis(150));
                    let _ = &db;
                    println!("OBS crash_child.abort = midflight");
                    std::process::abort();
                });
                for i in 0..100_000i64 {
                    let id = 5100 + i;
                    m.insert(&mut d, &[(id, 1600, id as u64)]).unwrap();
                    println!("OBS acked = {id}");
                }
            }
            m.insert_range(&mut d, 5100, 40, 1600).unwrap();
        }
        "repaired" => {
            // Repaired database: record the pre-crash count, then acknowledged
            // post-repair inserts, then crash.
            let before = d.scalar("SELECT COUNT(*) AS n FROM t").unwrap();
            fs::write(root.join("pre_crash_count"), &before).unwrap();
            m.insert_range(&mut d, 9600, 40, 1600).unwrap();
            m.insert(&mut d, &[(9700, 20_000, 9700)]).unwrap();
        }
        _ => panic!("phase"),
    }
    println!("OBS crash_child.acknowledged_rows_in_phase = {}", m.0.len());
    std::process::abort();
}

/// Parent side: reopen after the crash (WAL recovery), verify everything
/// acknowledged is present and correct, no overflow damage, check passes,
/// then perform post-recovery inserts and verify again.
pub fn crash_check(root: &Path, phase: &str) {
    let dir = root.join("db");
    if phase == "repaired" {
        let before: usize = fs::read_to_string(root.join("pre_crash_count")).unwrap().trim().parse().unwrap();
        let mut d = Db::open(&dir);
        let mut m = Model::default();
        for id in 9600..9640 {
            m.0.insert(id, (1600, id as u64));
        }
        m.0.insert(9700, (20_000, 9700));
        let mut fails = Vec::new();
        for (id, (len, seed)) in &m.0 {
            if d.scalar(&format!("SELECT pad FROM t WHERE id={id}")).as_deref() != Ok(text(*len, *seed).as_str()) {
                fails.push(format!("id {id}"));
            }
        }
        let count = d.scalar("SELECT COUNT(*) AS n FROM t");
        obs("repaired.count_after_crash", format!("{count:?} expected {}", before + 41));
        obs("repaired.rows_after_crash", if fails.is_empty() { "PASS".into() } else { format!("FAIL {fails:?}") });
        d.close();
        obs("repaired.bad_overflow_pages", bad_overflow(&dir).len());
        obs("repaired.phobos_admin_check", d.check().unwrap_or_else(|e| e));
        return;
    }
    let mut m = crash_model(phase);
    if phase == "midflight" {
        // Rows acknowledged before the abort are listed by the child log.
        let acked: Vec<i64> = std::env::var("ACKED")
            .unwrap_or_default()
            .split(',')
            .filter_map(|v| v.trim().parse().ok())
            .collect();
        m.0.retain(|id, _| *id < 5100);
        for id in &acked {
            m.0.insert(*id, (1600, *id as u64));
        }
    }
    let t0 = Instant::now();
    let mut d = Db::open(&dir);
    obs(&format!("{phase}.recovery_open_seconds"), format!("{:.3}", t0.elapsed().as_secs_f64()));
    if phase == "midflight" {
        // An insert that committed but was not yet acknowledged may also exist.
        let max_acked = m.0.keys().filter(|id| **id >= 5100).max().copied().unwrap_or(5099);
        if d.scalar(&format!("SELECT COUNT(*) AS n FROM t WHERE id={}", max_acked + 1)).as_deref() == Ok("1") {
            m.0.insert(max_acked + 1, (1600, (max_acked + 1) as u64));
            obs("midflight.unacknowledged_but_committed", max_acked + 1);
        }
        obs("midflight.acknowledged", m.0.keys().filter(|id| **id >= 5100).count());
    }
    let v = m.verify(&mut d);
    obs(&format!("{phase}.verify_after_crash"), if v.is_empty() { "PASS".to_string() } else { format!("FAIL {v:?}") });
    let post = m.insert_range(&mut d, 6000 + 1000 * (phase.len() as i64), 40, 1600);
    let v2 = m.verify(&mut d);
    d.close();
    let bad = bad_overflow(&dir);
    let chk = d.check();
    obs(&format!("{phase}.post_recovery_inserts"), format!("{post:?} verify={}", if v2.is_empty() { "PASS".into() } else { format!("{v2:?}") }));
    obs(&format!("{phase}.bad_overflow_pages"), bad.len());
    obs(&format!("{phase}.phobos_admin_check"), chk.unwrap_or_else(|e| e));
}

// ------------------------------------------------------------- Part H ---

/// Part H: online backup -> standby init -> receive/replay over wide-row and
/// post-restart activity; PITR to an exact commit LSN.
pub fn replication(root: &Path) {
    let restarts = std::env::var("REPL_NORESTART").is_err();
    obs("restarts_enabled", restarts);
    let nowide = std::env::var("REPL_NOWIDE").is_ok();
    obs("wide_rows_enabled", !nowide);
    let w = |n: usize| if nowide { 40 } else { n };
    let _ = fs::remove_dir_all(root);
    let (mut d, mut m) = base(&root.join("primary"));
    let primary = d.dir.clone();
    m.insert(&mut d, &[(1000, w(20_000), 1)]).unwrap();
    m.insert_range(&mut d, 2000, 300, 40).unwrap();
    if restarts {
        d.reopen();
    }
    m.insert_range(&mut d, 5000, 40, 1600).unwrap();
    let backup = root.join("online-backup");
    let report = d.db().backup_online(&backup);
    obs("backup_online", format!("{:?}", report.as_ref().map(|_| "ok").map_err(|e| e.message.clone())));
    let standby = root.join("standby");
    let init = phobos_admin::initialize_standby(&primary, &backup, &standby, "s1");
    obs("standby_init", format!("{:?}", init.as_ref().map(|s| s.last_replayed_lsn).map_err(|e| e.message.clone())));
    // More activity after the base backup: wide rows, deletes, restarts.
    m.insert(&mut d, &[(1001, w(26_000), 2)]).unwrap();
    m.insert_range(&mut d, 5100, 40, 1600).unwrap();
    m.set_text(&mut d, 2000, w(21_000), 3).unwrap();
    m.delete(&mut d, 1000).unwrap();
    if std::env::var("REPL_REPLAY_BEFORE_RESTART").is_ok() {
        // Workaround for the pre-existing 0.2-I replication defect: the
        // standby replays everything it received before the primary restarts.
        obs("receive_before_restart", format!("{:?}", phobos_admin::receive_wal(&primary, &standby).map(|s| s.last_received_lsn).map_err(|e| e.message)));
        obs("replay_before_restart", format!("{:?}", phobos_admin::replay_received(&standby).map(|s| s.last_replayed_lsn).map_err(|e| e.message)));
    }
    if restarts {
        d.reopen();
    }
    m.insert_range(&mut d, 5200, 40, 1600).unwrap();
    // PITR target: the commit LSN of one more autocommit insert.
    m.insert(&mut d, &[(5300, 1600, 5300)]).unwrap();
    let target = phobos_wal::v2::inspect(primary.join("phobos.wal")).map(|r| r.last_lsn).unwrap_or(0);
    let pitr_model = m.clone();
    m.insert(&mut d, &[(5301, 1600, 5301)]).unwrap(); // after the PITR target
    let archive = root.join("wal-archive");
    obs("wal_archive", format!("{:?}", phobos_admin::archive_wal(&primary, &archive).map_err(|e| e.message)));
    obs("receive", format!("{:?}", phobos_admin::receive_wal(&primary, &standby).map(|s| s.last_received_lsn).map_err(|e| e.message)));
    d.close();
    obs("primary_check", d.check().unwrap_or_else(|e| e));
    obs("replay", format!("{:?}", phobos_admin::replay_received(&standby).map(|s| s.last_replayed_lsn).map_err(|e| e.message)));
    obs("standby.bad_overflow_pages", bad_overflow(&standby).len());
    obs("standby.overflow_pages", overflow_pages(&standby).len());
    {
        let mut s = Db::open(&standby);
        let v = m.verify(&mut s);
        obs("standby.verify", if v.is_empty() { "PASS".to_string() } else { format!("FAIL {v:?}") });
        obs("standby.read_only_write", format!("{:?}", s.t("INSERT INTO t VALUES (1,1,1,1,'x')")));
    }
    obs("standby.check", phobos_admin::check_integrity(&standby).map(|r| format!("PASS {r:?}")).unwrap_or_else(|e| format!("FAIL {}", e.message)));
    let dest = root.join("pitr");
    let p = phobos_admin::pitr_recover_to(&backup, &archive, &dest, target);
    obs("pitr", format!("target={target} {:?}", p.as_ref().map(|s| s.last_replayed_lsn).map_err(|e| e.message.clone())));
    if p.is_ok() {
        obs("pitr.bad_overflow_pages", bad_overflow(&dest).len());
        let mut r = Db::open(&dest);
        let v = pitr_model.verify(&mut r);
        obs("pitr.verify_at_target", if v.is_empty() { "PASS".to_string() } else { format!("FAIL {v:?}") });
        obs("pitr.row_after_target_absent", format!("{:?}", r.scalar("SELECT COUNT(*) AS n FROM t WHERE id=5301")));
        obs("pitr.check", r.check().unwrap_or_else(|e| e));
    }
}

/// Minimal characterisation of the pre-existing replication issue:
/// `variant` = "restart" (restart primary after base backup, before any
/// receive) or "receive_first" (receive before the restart, then restart).
pub fn repl_min(root: &Path, variant: &str) {
    let _ = fs::remove_dir_all(root);
    let (mut d, mut m) = base(&root.join("primary"));
    let primary = d.dir.clone();
    let backup = root.join("online-backup");
    d.db().backup_online(&backup).unwrap();
    let standby = root.join("standby");
    phobos_admin::initialize_standby(&primary, &backup, &standby, "s1").unwrap();
    m.insert_range(&mut d, 3000, 50, 40).unwrap();
    let wal = |label: &str| {
        let r = phobos_wal::v2::inspect(primary.join("phobos.wal")).unwrap();
        obs(&format!("{variant}.wal_{label}"), format!("last_lsn={} checkpoint_lsn={} committed={} valid_len={}", r.last_lsn, r.checkpoint_lsn, r.committed_transactions, r.valid_len));
    };
    wal("before_restart");
    if variant == "receive_first" || variant == "replay_first" {
        obs(&format!("{variant}.receive_1"), format!("{:?}", phobos_admin::receive_wal(&primary, &standby).map(|s| s.last_received_lsn).map_err(|e| e.message)));
    }
    if variant == "replay_first" {
        obs(&format!("{variant}.replay_1"), format!("{:?}", phobos_admin::replay_received(&standby).map(|s| s.last_replayed_lsn).map_err(|e| e.message)));
    }
    d.reopen();
    wal("after_clean_restart");
    m.insert_range(&mut d, 4000, 50, 40).unwrap();
    obs(&format!("{variant}.receive_2"), format!("{:?}", phobos_admin::receive_wal(&primary, &standby).map(|s| s.last_received_lsn).map_err(|e| e.message)));
    d.close();
    obs(&format!("{variant}.replay"), format!("{:?}", phobos_admin::replay_received(&standby).map(|s| s.last_replayed_lsn).map_err(|e| e.message)));
    let mut s = Db::open(&standby);
    obs(&format!("{variant}.standby_rows"), format!("total={:?} expected {} | rows 3000-3049 (committed before restart)={:?} expected 50 | rows 4000-4049 (after restart)={:?} expected 50",
        s.scalar("SELECT COUNT(*) AS n FROM t"), m.0.len(),
        s.scalar("SELECT COUNT(*) AS n FROM t WHERE id>=3000 AND id<3050"),
        s.scalar("SELECT COUNT(*) AS n FROM t WHERE id>=4000 AND id<4050")));
    drop(s);
    obs(&format!("{variant}.standby_check"), phobos_admin::check_integrity(&standby).map(|_| "PASS".to_string()).unwrap_or_else(|e| format!("FAIL {}", e.message)));
}

/// Part K.10: a healthy database written by one build, reopened by another.
pub fn make_healthy(root: &Path) {
    let (mut d, mut m) = base(root);
    m.insert(&mut d, &[(1000, 20_000, 1), (1001, 9_000, 2)]).unwrap();
    m.insert_range(&mut d, 2000, 300, 40).unwrap();
    m.delete(&mut d, 1001).unwrap();
    let mut reclaimed = 0;
    for _ in 0..50 {
        let r = d.db().reclaim_once(64).unwrap();
        reclaimed += r.versions_reclaimed;
        if r.versions_reclaimed == 0 && r.candidates_remaining == 0 {
            break;
        }
    }
    d.x("CHECKPOINT");
    d.close();
    obs("make_healthy.versions_reclaimed", reclaimed);
    obs("make_healthy.released_overflow_pages", pages(&d.dir).iter().filter(|p| p.overflow && p.slots.iter().all(|s| s.ends_with("tombstone"))).count());
    obs("make_healthy.live_overflow_pages", pages(&d.dir).iter().filter(|p| p.overflow && p.slots.iter().any(|s| s.contains("PHOV"))).count());
    obs("make_healthy.rows", m.0.len());
    obs("make_healthy.check", d.check().unwrap_or_else(|e| e));
}
/// Reopen a database made by `make_healthy` (possibly by another build),
/// verify it, write after restart, verify again.
pub fn reopen_healthy(root: &Path) {
    let mut m = Model::default();
    for id in 1..=100 {
        m.0.insert(id, (40, id as u64));
    }
    m.0.insert(1000, (20_000, 1));
    for id in 2000..2300 {
        m.0.insert(id, (40, id as u64));
    }
    let mut d = Db::open(&root.join("db"));
    let v = m.verify(&mut d);
    obs("reopen_healthy.verify", if v.is_empty() { "PASS".to_string() } else { format!("FAIL {v:?}") });
    m.insert_range(&mut d, 5000, 60, 1600).unwrap();
    d.reopen();
    let v = m.verify(&mut d);
    obs("reopen_healthy.verify_after_writes_and_restart", if v.is_empty() { "PASS".to_string() } else { format!("FAIL {v:?}") });
    d.close();
    obs("reopen_healthy.bad_overflow_pages", bad_overflow(&root.join("db")).len());
    obs("reopen_healthy.check", d.check().unwrap_or_else(|e| e));
}
