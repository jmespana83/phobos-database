//! Part I: same-machine performance gate, embedded Coordinator (no TCP).
//! Identical source compiled against 0.2-I and 0.2-I.1; runs are alternated.
use super::*;
use phobos_execution::ResultSink;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

struct Count(u64);
impl ResultSink for Count {
    fn start(&mut self, _c: Vec<String>) -> Result<(), phobos_error::PhobosError> {
        Ok(())
    }
    fn row(&mut self, _r: phobos_types::Row) -> Result<(), phobos_error::PhobosError> {
        self.0 += 1;
        Ok(())
    }
    fn finish(&mut self) -> Result<(), phobos_error::PhobosError> {
        Ok(())
    }
    fn command(&mut self, _t: String, _n: u64) -> Result<(), phobos_error::PhobosError> {
        Ok(())
    }
}

const ROWS: i64 = 100_000;

fn perm(i: i64) -> i64 {
    // Bijective permutation of 0..ROWS (ROWS = 100_000; 7919 is coprime).
    (i * 7919 + 13) % ROWS
}
fn payload(i: i64) -> String {
    format!("p{:058x}", (i as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15))
}
fn bench_row(i: i64) -> String {
    format!("({i},{},{},{},'{}')", i % 100, perm(i), (i * 31) % 1_000_003, payload(i))
}

fn create(root: &Path) -> Db {
    let _ = fs::remove_dir_all(root);
    fs::create_dir_all(root).unwrap();
    let source = root.join("source");
    {
        let mut legacy = phobos_execution::Database::open(&source).unwrap();
        legacy
            .execute("CREATE TABLE bench (id BIGINT NOT NULL, grp BIGINT NOT NULL, sec BIGINT NOT NULL, val BIGINT NOT NULL, payload TEXT NOT NULL)")
            .unwrap();
        legacy
            .execute("CREATE TABLE dimension (id BIGINT NOT NULL, label TEXT NOT NULL)")
            .unwrap();
    }
    let dir = root.join("db");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    let mut d = Db::open(&dir);
    d.x("CREATE UNIQUE INDEX bench_id ON bench(id)");
    d.x("CREATE INDEX bench_sec ON bench(sec)");
    d.x("BEGIN");
    let mut i = 0;
    while i < ROWS {
        let vals = (i..(i + 1000).min(ROWS)).map(bench_row).collect::<Vec<_>>().join(",");
        d.x(&format!("INSERT INTO bench VALUES {vals}"));
        i += 1000;
    }
    d.x("COMMIT");
    let dim = (0..100).map(|i| format!("({i},'d{i}')")).collect::<Vec<_>>().join(",");
    d.x(&format!("INSERT INTO dimension VALUES {dim}"));
    d.x("CHECKPOINT");
    d.reopen();
    d
}

fn pct(sorted: &[f64], p: f64) -> f64 {
    sorted[((sorted.len() as f64 - 1.0) * p).round() as usize]
}
fn median(mut v: Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    pct(&v, 0.5)
}
fn emit(metric: &str, value: f64, unit: &str) {
    println!("BENCH,{metric},{value:.6},{unit}");
}

fn timed<F: FnMut()>(n: usize, mut f: F) -> f64 {
    f(); // warm
    median(
        (0..n)
            .map(|_| {
                let t = Instant::now();
                f();
                t.elapsed().as_secs_f64()
            })
            .collect(),
    )
}

fn stream(d: &Db, sql: &str, expect: u64) -> f64 {
    let db = d.db().clone();
    let s = d.s;
    timed(5, || {
        let mut sink = Count(0);
        db.execute_stream_result(s, sql, &mut sink).unwrap();
        assert_eq!(sink.0, expect, "{sql}");
    })
}

pub fn run(root: &Path) {
    let t0 = Instant::now();
    let mut d = create(root);
    emit("setup_seconds", t0.elapsed().as_secs_f64(), "s");
    let mut seed = 0x1234_5678u64;
    let mut rnd = move |m: i64| {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        (seed % m as u64) as i64
    };
    // Point lookups: latency distribution.
    let mut lat = Vec::new();
    for _ in 0..200 {
        d.x(&format!("SELECT * FROM bench WHERE id={}", rnd(ROWS)));
    }
    for _ in 0..3000 {
        let id = rnd(ROWS);
        let t = Instant::now();
        d.x(&format!("SELECT * FROM bench WHERE id={id}"));
        lat.push(t.elapsed().as_secs_f64() * 1000.0);
    }
    lat.sort_by(|a, b| a.partial_cmp(b).unwrap());
    emit("point_p50", pct(&lat, 0.50), "ms");
    emit("point_p95", pct(&lat, 0.95), "ms");
    emit("point_p99", pct(&lat, 0.99), "ms");
    let a = rnd(ROWS - 1000);
    emit("secondary_range_1pct", stream(&d, &format!("SELECT * FROM bench WHERE sec>={a} AND sec<{}", a + 1000), 1000), "s");
    emit("full_scan", stream(&d, "SELECT * FROM bench", ROWS as u64), "s");
    emit("count", timed(10, || assert_eq!(d.scalar("SELECT COUNT(*) AS n FROM bench").unwrap(), ROWS.to_string())), "s");
    emit("group_by", stream(&d, "SELECT grp AS grp, COUNT(*) AS n FROM bench GROUP BY grp", 100), "s");
    emit("top_k", stream(&d, "SELECT id AS id, val AS val FROM bench ORDER BY val DESC LIMIT 10", 10), "s");
    emit("join", stream(&d, "SELECT bench.id AS id FROM bench INNER JOIN dimension ON bench.grp=dimension.id", ROWS as u64), "s");
    // Autocommit single-row inserts.
    let mut lat = Vec::new();
    let t = Instant::now();
    for i in 0..2000 {
        let s = Instant::now();
        d.x(&format!("INSERT INTO bench VALUES {}", bench_row(1_000_000 + i)));
        lat.push(s.elapsed().as_secs_f64() * 1000.0);
    }
    emit("autocommit_rate", 2000.0 / t.elapsed().as_secs_f64(), "ops/s");
    lat.sort_by(|a, b| a.partial_cmp(b).unwrap());
    emit("autocommit_p95", pct(&lat, 0.95), "ms");
    // 500-row transactions.
    let mut next = 2_000_000i64;
    let txn = timed(10, || {
        d.x("BEGIN");
        for _ in 0..500 {
            d.x(&format!("INSERT INTO bench VALUES {}", bench_row(next)));
            next += 1;
        }
        d.x("COMMIT");
    });
    emit("txn_500_rows", txn * 1000.0, "ms");
    d.x("CHECKPOINT");
    // OLTP mixes.
    for clients in [1usize, 8, 16] {
        let stop = Arc::new(AtomicBool::new(false));
        let ops = Arc::new(AtomicU64::new(0));
        let errors = Arc::new(AtomicU64::new(0));
        let mut handles = Vec::new();
        for w in 0..clients {
            let db = d.db().clone();
            let (stop, ops, errors) = (stop.clone(), ops.clone(), errors.clone());
            handles.push(std::thread::spawn(move || {
                let s = db.new_session();
                let mut x = 0x9E37_79B9u64 ^ (w as u64 + 1) ^ (clients as u64) << 32;
                let mut next = 10_000_000 + (clients as i64) * 1_000_000 + (w as i64) * 50_000;
                while !stop.load(Ordering::Relaxed) {
                    x ^= x << 13;
                    x ^= x >> 7;
                    x ^= x << 17;
                    let id = (x >> 8) as i64 % ROWS;
                    let sql = match x % 10 {
                        0..=4 => format!("SELECT * FROM bench WHERE id={id}"),
                        5..=7 => format!("UPDATE bench SET val=val+1 WHERE id={id}"),
                        _ => {
                            next += 1;
                            format!("INSERT INTO bench VALUES {}", bench_row(next))
                        }
                    };
                    if db.execute(s, &sql).is_err() {
                        errors.fetch_add(1, Ordering::Relaxed);
                    }
                    ops.fetch_add(1, Ordering::Relaxed);
                }
                db.disconnect(s);
            }));
        }
        std::thread::sleep(std::time::Duration::from_secs(10));
        stop.store(true, Ordering::Relaxed);
        for h in handles {
            h.join().unwrap();
        }
        emit(&format!("oltp{clients}"), ops.load(Ordering::Relaxed) as f64 / 10.0, "ops/s");
        emit(&format!("oltp{clients}_errors"), errors.load(Ordering::Relaxed) as f64, "count");
        #[cfg(feature = "k")]
        if let Ok(m) = d.db().reclaim_metrics() {
            println!("RECLAIM after oltp{clients}: {m:?}");
        }
    }
    d.close();
    #[cfg(feature = "prof")]
    {
        let path = std::path::PathBuf::from(std::env::var("PROF_OUT").unwrap_or_else(|_| "/tmp/prof.csv".into()));
        let _ = fs::remove_file(&path);
        phobos_observability::write_profile(&path).unwrap();
    }
    let _ = fs::remove_dir_all(root);
}

/// 0.2-K.1: BULK quick A/B. Fresh database, `rows` rows through
/// `Coordinator::bulk_load` (64-row batches), indexes as in the standard
/// bench table (UNIQUE id + secondary sec), one transaction.
pub fn bulk(root: &Path, rows: i64) {
    let _ = fs::remove_dir_all(root);
    fs::create_dir_all(root).unwrap();
    let source = root.join("source");
    {
        let mut legacy = phobos_execution::Database::open(&source).unwrap();
        legacy
            .execute("CREATE TABLE bench (id BIGINT NOT NULL, grp BIGINT NOT NULL, sec BIGINT NOT NULL, val BIGINT NOT NULL, payload TEXT NOT NULL)")
            .unwrap();
    }
    let dir = root.join("db");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    let mut d = Db::open(&dir);
    d.x("CREATE UNIQUE INDEX bench_id ON bench(id)");
    d.x("CREATE INDEX bench_sec ON bench(sec)");
    let s = d.db().new_session();
    let t = Instant::now();
    let n = d
        .db()
        .bulk_load(
            s,
            "bench",
            (0..rows).map(|i| {
                Ok(phobos_types::Row::new(vec![
                    phobos_types::Value::Int64(i),
                    phobos_types::Value::Int64(i % 100),
                    phobos_types::Value::Int64((i * 7919 + 13) % rows.max(1)),
                    phobos_types::Value::Int64((i * 31) % 1_000_003),
                    phobos_types::Value::Text(payload(i)),
                ]))
            }),
        )
        .unwrap();
    let secs = t.elapsed().as_secs_f64();
    emit(&format!("bulk_{rows}"), secs, "s");
    let heap: u64 = fs::read_dir(&dir)
        .unwrap()
        .flatten()
        .filter(|e| e.file_name().to_string_lossy().ends_with(".heap"))
        .map(|e| e.metadata().unwrap().len())
        .sum();
    println!("BULKINFO rows={n} heap_bytes={heap}");
    d.db().disconnect(s);
    drop(d);
    let _ = fs::remove_dir_all(root);
}

/// 0.2-K.1: secondary-range quick test. 1M rows (bulk), secondary index on a
/// permuted column; 1% range (10,000 rows) `SELECT *`, streamed; plus point
/// lookups (must not regress).
pub fn secondary(root: &Path) {
    const N: i64 = 1_000_000;
    let _ = fs::remove_dir_all(root);
    fs::create_dir_all(root).unwrap();
    let source = root.join("source");
    {
        let mut legacy = phobos_execution::Database::open(&source).unwrap();
        legacy
            .execute("CREATE TABLE bench (id BIGINT NOT NULL, grp BIGINT NOT NULL, sec BIGINT NOT NULL, val BIGINT NOT NULL, payload TEXT NOT NULL)")
            .unwrap();
    }
    let dir = root.join("db");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    let mut d = Db::open(&dir);
    d.x("CREATE UNIQUE INDEX bench_id ON bench(id)");
    d.x("CREATE INDEX bench_sec ON bench(sec)");
    let s = d.db().new_session();
    d.db()
        .bulk_load(
            s,
            "bench",
            (0..N).map(|i| {
                Ok(phobos_types::Row::new(vec![
                    phobos_types::Value::Int64(i),
                    phobos_types::Value::Int64(i % 100),
                    phobos_types::Value::Int64((i * 7919 + 13) % N),
                    phobos_types::Value::Int64((i * 31) % 1_000_003),
                    phobos_types::Value::Text(payload(i)),
                ]))
            }),
        )
        .unwrap();
    d.db().disconnect(s);
    d.x("CHECKPOINT");
    d.reopen();
    let mut seed = 0x9876_5431u64;
    let mut rnd = move |m: i64| {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        (seed % m as u64) as i64
    };
    #[cfg(feature = "prof")]
    {
        let path = std::path::PathBuf::from(format!("{}.pre", std::env::var("PROF_OUT").unwrap_or_else(|_| "/tmp/prof.csv".into())));
        let _ = fs::remove_file(&path);
        phobos_observability::write_profile(&path).unwrap();
    }
    let mut times = Vec::new();
    for _ in 0..11 {
        let a = rnd(N - 10_000);
        let sql = format!("SELECT * FROM bench WHERE sec>={a} AND sec<{}", a + 10_000);
        let db = d.db().clone();
        let t = Instant::now();
        let mut sink = Count(0);
        db.execute_stream_result(d.s, &sql, &mut sink).unwrap();
        assert_eq!(sink.0, 10_000, "{sql}");
        times.push(t.elapsed().as_secs_f64());
    }
    times.remove(0);
    emit("secondary_1pct_of_1m", median(times), "s");
    // Same range repeated (warm page cache): isolates cold page acquisition.
    let a = rnd(N - 10_000);
    let sql = format!("SELECT * FROM bench WHERE sec>={a} AND sec<{}", a + 10_000);
    let mut warm = Vec::new();
    for _ in 0..6 {
        let db = d.db().clone();
        let t = Instant::now();
        let mut sink = Count(0);
        db.execute_stream_result(d.s, &sql, &mut sink).unwrap();
        assert_eq!(sink.0, 10_000);
        warm.push(t.elapsed().as_secs_f64());
    }
    warm.remove(0);
    emit("secondary_1pct_of_1m_warm", median(warm), "s");
    let mut lat = Vec::new();
    for _ in 0..2000 {
        let id = rnd(N);
        let t = Instant::now();
        d.x(&format!("SELECT * FROM bench WHERE id={id}"));
        lat.push(t.elapsed().as_secs_f64() * 1000.0);
    }
    lat.sort_by(|a, b| a.partial_cmp(b).unwrap());
    emit("point_p50_1m", pct(&lat, 0.50), "ms");
    emit("point_p99_1m", pct(&lat, 0.99), "ms");
    d.close();
    #[cfg(feature = "prof")]
    {
        let path = std::path::PathBuf::from(std::env::var("PROF_OUT").unwrap_or_else(|_| "/tmp/prof.csv".into()));
        let _ = fs::remove_file(&path);
        phobos_observability::write_profile(&path).unwrap();
    }
    let _ = fs::remove_dir_all(root);
}

/// 0.2-K.1: BULK as the Standard suite loads it: one transaction of
/// 1,000-row INSERT statements into a table with a UNIQUE index.
pub fn bulksql(root: &Path, rows: i64) {
    let _ = fs::remove_dir_all(root);
    fs::create_dir_all(root).unwrap();
    let source = root.join("source");
    {
        let mut legacy = phobos_execution::Database::open(&source).unwrap();
        legacy
            .execute("CREATE TABLE bench (id BIGINT NOT NULL, grp BIGINT NOT NULL, sec BIGINT NOT NULL, val BIGINT NOT NULL, payload TEXT NOT NULL)")
            .unwrap();
    }
    let dir = root.join("db");
    phobos_admin::migrate_mvcc_copy(&source, &root.join("backup"), &dir).unwrap();
    let mut d = Db::open(&dir);
    d.x("CREATE UNIQUE INDEX bench_id ON bench(id)");
    let statements = (0..rows)
        .step_by(1000)
        .map(|i| {
            let vals = (i..(i + 1000).min(rows)).map(bench_row).collect::<Vec<_>>().join(",");
            format!("INSERT INTO bench VALUES {vals}")
        })
        .collect::<Vec<_>>();
    let t = Instant::now();
    d.x("BEGIN");
    for sql in &statements {
        d.x(sql);
    }
    d.x("COMMIT");
    emit(&format!("bulksql_{rows}"), t.elapsed().as_secs_f64(), "s");
    d.close();
    let _ = fs::remove_dir_all(root);
}
