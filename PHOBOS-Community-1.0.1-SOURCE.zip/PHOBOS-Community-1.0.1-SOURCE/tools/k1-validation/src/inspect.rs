//! Read-only, offline-safe physical inspection of PHOBOS 0.2-I heap and index
//! files. Parses raw 8 KiB page images using the documented 0.2-I layouts:
//!
//! Heap page (`PHOP`): lower @24 u16, upper @26 u16, slot_count @28 u16,
//! flags @30 u8, version @4 u16 (3 = versioned), 40-byte header, 4-byte slots
//! `(offset u16, length u16)`, length 0 = tombstone.
//! Tuple envelope (`PHMV`): creator @8 u64, deleter @16 u64 (0 = none),
//! logical_row @24 u64, previous flag @6.
//! Index node (`PHIN`): kind @6 (1 leaf, 2 internal, 3 free), entry count @32.
//!
//! Nothing here writes to any file.
use std::{fs, path::Path};

pub const PAGE: usize = 8192;
const HEAP_HEADER: usize = 40;
const SLOT: usize = 4;
const FLAG_OVERFLOW: u8 = 0b10;

#[derive(Debug, Default, Clone)]
pub struct HeapStats {
    pub file_bytes: u64,
    pub pages: u64,
    pub overflow_pages: u64,
    pub slots_total: u64,
    pub slot_tombstones: u64,
    pub max_slot_count: u64,
    pub tuples_present: u64,
    pub dead_versions_present: u64,
    pub tuple_bytes: u64,
    pub free_bytes: u64,
    /// Pages whose contiguous free space (upper-lower) fits `need`.
    pub pages_accepting: u64,
    /// Pages that could NOT fit `need` even after a perfect compaction,
    /// purely because of slot-directory consumption: 8192-40-4*slots-live < need.
    pub pages_slot_starved: u64,
    /// Pages that have slot entries but no tuple bytes at all.
    pub pages_zero_tuples: u64,
    /// Slot-directory bytes held by tombstones (permanently unusable today).
    pub tombstone_dir_bytes: u64,
    pub parse_errors: u64,
    /// Per-page slot counts (for histograms / boundary tests).
    pub per_page_slots: Vec<u16>,
}

fn u16_at(b: &[u8], o: usize) -> u16 {
    u16::from_le_bytes([b[o], b[o + 1]])
}
fn u64_at(b: &[u8], o: usize) -> u64 {
    u64::from_le_bytes(b[o..o + 8].try_into().unwrap())
}

pub fn heap(path: &Path, need: usize) -> HeapStats {
    let mut s = HeapStats::default();
    let Ok(bytes) = fs::read(path) else {
        return s;
    };
    s.file_bytes = bytes.len() as u64;
    s.pages = (bytes.len() / PAGE) as u64;
    for page in bytes.chunks_exact(PAGE) {
        if &page[0..4] != b"PHOP" {
            s.parse_errors += 1;
            continue;
        }
        if page[30] & FLAG_OVERFLOW != 0 {
            s.overflow_pages += 1;
            continue;
        }
        let lower = u16_at(page, 24) as usize;
        let upper = u16_at(page, 26) as usize;
        let slots = u16_at(page, 28) as usize;
        if lower != HEAP_HEADER + slots * SLOT || lower > upper || upper > PAGE {
            s.parse_errors += 1;
            continue;
        }
        s.per_page_slots.push(slots as u16);
        s.slots_total += slots as u64;
        s.max_slot_count = s.max_slot_count.max(slots as u64);
        s.free_bytes += (upper - lower) as u64;
        if upper - lower >= need {
            s.pages_accepting += 1;
        }
        let mut live_bytes = 0usize;
        let mut tuples = 0;
        for slot in 0..slots {
            let off = HEAP_HEADER + slot * SLOT;
            let start = u16_at(page, off) as usize;
            let len = u16_at(page, off + 2) as usize;
            if len == 0 {
                s.slot_tombstones += 1;
                continue;
            }
            if start + len > PAGE || len < 48 {
                s.parse_errors += 1;
                continue;
            }
            tuples += 1;
            live_bytes += len;
            let t = &page[start..start + len];
            if &t[0..4] == b"PHMV" && u64_at(t, 16) != 0 {
                s.dead_versions_present += 1;
            }
        }
        s.tuples_present += tuples;
        s.tuple_bytes += live_bytes as u64;
        if tuples == 0 && slots > 0 {
            s.pages_zero_tuples += 1;
        }
        // Slot-starved: cannot fit `need` even after perfect byte compaction
        // with the CURRENT slot directory, but WOULD fit if tombstone slot
        // entries could be reused/trimmed. Pages simply full of live rows
        // are not counted.
        let with_dir = PAGE.saturating_sub(HEAP_HEADER + slots * SLOT + live_bytes);
        let without_tombstones = PAGE.saturating_sub(HEAP_HEADER + tuples as usize * SLOT + live_bytes);
        if with_dir < need && without_tombstones >= need {
            s.pages_slot_starved += 1;
        }
    }
    s.tombstone_dir_bytes = s.slot_tombstones * SLOT as u64;
    s
}

#[derive(Debug, Default, Clone)]
pub struct IndexStats {
    pub file_bytes: u64,
    pub pages: u64,
    pub leaf_pages: u64,
    pub internal_pages: u64,
    pub free_pages: u64,
    pub leaf_entries: u64,
}

pub fn index(path: &Path) -> IndexStats {
    let mut s = IndexStats::default();
    let Ok(bytes) = fs::read(path) else {
        return s;
    };
    s.file_bytes = bytes.len() as u64;
    s.pages = (bytes.len() / PAGE) as u64;
    for page in bytes.chunks_exact(PAGE).skip(1) {
        if &page[0..4] != b"PHIN" {
            continue;
        }
        match page[6] {
            1 => {
                s.leaf_pages += 1;
                s.leaf_entries += u64::from(u16_at(page, 32));
            }
            2 => s.internal_pages += 1,
            3 => s.free_pages += 1,
            _ => {}
        }
    }
    s
}

pub fn sum_indexes(dir: &Path) -> IndexStats {
    let mut total = IndexStats::default();
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            if p.extension().is_some_and(|x| x == "idx") {
                let s = index(&p);
                total.file_bytes += s.file_bytes;
                total.pages += s.pages;
                total.leaf_pages += s.leaf_pages;
                total.internal_pages += s.internal_pages;
                total.free_pages += s.free_pages;
                total.leaf_entries += s.leaf_entries;
            }
        }
    }
    total
}

pub fn heap_path(dir: &Path) -> Option<std::path::PathBuf> {
    fs::read_dir(dir).ok()?.flatten().map(|e| e.path()).find(|p| {
        p.file_name()
            .is_some_and(|n| n.to_string_lossy().starts_with("table-"))
            && p.extension().is_some_and(|x| x == "heap")
    })
}
