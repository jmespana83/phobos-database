param([string]$Root = "$env:TEMP\phobos-k1-quick", [int]$Rounds = 3)
$ErrorActionPreference = "Stop"
$bin = ".\target\release\k1bench.exe"
foreach ($round in 1..$Rounds) {
  foreach ($worker in @("1","0")) {
    $env:PHOBOS_AUTO_RECLAIM = $worker
    Write-Host "round=$round worker=$worker"
    & $bin bench "$Root\q-$worker"
  }
}
Remove-Item Env:PHOBOS_AUTO_RECLAIM
