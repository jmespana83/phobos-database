# PHOBOS 0.2-K.1: Windows validation bundle

These scripts run from PowerShell in this folder (`tools\k1-validation`). Use the Rust toolchain from `rust-toolchain.toml` (1.85).

| Script | Purpose |
|---|---|
| `build.ps1` | Runs `cargo build --release --locked` for the PHOBOS workspace and for this harness. |
| `bulk-ab.ps1` | BULK-only quick A/B: 100K / 1M / 3M rows through `Coordinator::bulk_load`, with the worker on and off. |
| `quick-ab.ps1` | The embedded quick suite (point / secondary 1% / scan / COUNT / GROUP BY / Top-K / join / autocommit / 500-row txn / OLTP1/8/16), worker on then off. |
| `secondary.ps1` | Secondary-only quick test: 1M rows, 1% range, cold and warm cache, point p50/p99. Runs once with the 256 MiB default page cache and once with the old 64 MiB default. |
| `standard.ps1` | Runs YOUR frozen Standard benchmark twice, worker ON and worker OFF. Pass the suite command with `-Suite`. |

Worker switch: `PHOBOS_AUTO_RECLAIM=0` turns automatic reclamation off; it is on by default. Page cache: the `page_cache_bytes` setting or the `PHOBOS_PAGE_CACHE_BYTES` environment variable; the default is 256 MiB (it was 64 MiB).

Results print as `BENCH,<metric>,<value>,<unit>` lines; redirect them to a file to keep them.
