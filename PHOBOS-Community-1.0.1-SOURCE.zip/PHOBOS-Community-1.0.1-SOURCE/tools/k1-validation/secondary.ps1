param([string]$Root = "$env:TEMP\phobos-k1-secondary")
$ErrorActionPreference = "Stop"
$bin = ".\target\release\k1bench.exe"
Write-Host "default page cache (256 MiB)"
& $bin secondary "$Root\s-default"
$env:PHOBOS_PAGE_CACHE_BYTES = "67108864"
Write-Host "old default page cache (64 MiB)"
& $bin secondary "$Root\s-64"
Remove-Item Env:PHOBOS_PAGE_CACHE_BYTES
