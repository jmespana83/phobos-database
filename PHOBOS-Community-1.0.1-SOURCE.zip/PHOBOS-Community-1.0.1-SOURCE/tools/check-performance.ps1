param([Parameter(Mandatory=$true)][string]$Baseline,[Parameter(Mandatory=$true)][string]$Candidate,[double]$MaxRatio=2.0,[double]$NoiseFloorMilliseconds=20)
$ErrorActionPreference='Stop'
function Median($Values) { $v=@($Values|Sort-Object); if($v.Count -eq 0){throw 'No samples'}; if($v.Count%2){return $v[[int][Math]::Floor($v.Count/2)]}; return ($v[$v.Count/2-1]+$v[$v.Count/2])/2 }
$a=@(Import-Csv $Baseline); $b=@(Import-Csv $Candidate)
if($a.Count -eq 0 -or $b.Count -eq 0){throw 'Empty benchmark results'}
foreach($g in ($a|Group-Object workload)) {
    $other=@($b|Where-Object workload -eq $g.Name)
    if($other.Count -lt 3 -or $g.Count -lt 3){ if($g.Name -eq 'bulk_load' -and $other.Count -eq 1){continue}; throw "Insufficient samples for $($g.Name)" }
    foreach($field in @('rows','seed','operations','cache','engine')) { if(@($g.Group.$field|Select-Object -Unique).Count -ne 1 -or @($other.$field|Select-Object -Unique).Count -ne 1 -or $g.Group[0].$field -ne $other[0].$field){throw "Incompatible $field for $($g.Name)"} }
    $old=Median @($g.Group|ForEach-Object {[double]$_.elapsed_ns})
    $new=Median @($other|ForEach-Object {[double]$_.elapsed_ns})
    if($old -le 0 -or $new -le 0){throw 'Invalid timing'}
    if([double]::IsNaN($old) -or [double]::IsNaN($new) -or [double]::IsInfinity($old) -or [double]::IsInfinity($new)){throw 'Non-finite timing'}
    $limit=[Math]::Max($old*$MaxRatio,$old+$NoiseFloorMilliseconds*1000000)
    Write-Host "$($g.Name): median ratio $([Math]::Round($new/$old,3))"
    if($new -gt $limit){throw "Large regression in $($g.Name): $new ns exceeds $limit ns"}
}
