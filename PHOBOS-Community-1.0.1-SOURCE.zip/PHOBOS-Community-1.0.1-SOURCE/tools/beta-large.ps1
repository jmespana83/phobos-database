param([ValidateSet(1000000,10000000)][int]$Rows=1000000,[int]$TimeoutSeconds=3600,[Parameter(Mandatory=$true)][string]$EvidenceDirectory)
$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if(-not(Test-Path -LiteralPath $EvidenceDirectory)){New-Item -ItemType Directory $EvidenceDirectory | Out-Null}
$fingerprint=Join-Path $EvidenceDirectory campaign-source.json
$current=@(& "$PSScriptRoot/beta-source-fingerprint.ps1")
if(Test-Path -LiteralPath $fingerprint){
 if((Get-Content $fingerprint -Raw | ConvertFrom-Json | ConvertTo-Json -Compress) -ne ($current|ConvertTo-Json -Compress)){throw 'Evidence directory belongs to different source; choose a new directory'}
}else{$current|ConvertTo-Json|Set-Content $fingerprint}
$scale=if($Rows -eq 1000000){'1m'}else{'10m'}
cargo build --release --workspace
if($LASTEXITCODE){throw 'Release build failed'}
& "$PSScriptRoot/run-benchmarks.ps1" -Rows $Rows -Samples 3 -Operations 3 -Connections 4 -OutputDirectory (Join-Path $EvidenceDirectory $scale) -TimeoutSeconds $TimeoutSeconds
if(-not $?){throw "$scale benchmark failed; partial evidence retained"}
& ./target/release/beta-check.exe (Join-Path $EvidenceDirectory "$scale/data/base") $Rows (Join-Path $EvidenceDirectory "correctness-$scale")
if($LASTEXITCODE){throw "$scale correctness failed"}
