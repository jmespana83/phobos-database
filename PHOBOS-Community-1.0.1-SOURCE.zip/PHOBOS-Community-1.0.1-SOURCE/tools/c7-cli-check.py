"""Small release CLI file/stdin/late-error acceptance on an explicit migrated copy."""
import argparse
import os
from pathlib import Path
import socket
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True, help='empty legacy C7 measurement source')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = Path(__file__).resolve().parent.parent
    binaries = repo / 'target/release'
    suffix = '.exe' if os.name == 'nt' else ''
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    for name in ['PHOBOS_USER', 'PHOBOS_PASSWORD', 'PHOBOS_TLS_SERVER_NAME', 'PHOBOS_TLS_CA']:
        env.pop(name, None)
    log = (out / 'result.log').open('w')
    def run(tool, arguments, success=True, text=None):
        result = subprocess.run([str(binaries / (tool + suffix)), *map(str, arguments)],
                                input=text, capture_output=True, text=True, env=env, timeout=30)
        log.write(result.stdout + result.stderr)
        log.flush()
        assert (result.returncode == 0) == success, (tool, result.returncode)
        return result.stdout
    run('phobos-admin', ['migrate-mvcc-copy', args.source.resolve(), out/'backup', out/'database'])
    def start():
        with socket.socket() as reservation:
            reservation.bind(('127.0.0.1', 0))
            port = reservation.getsockname()[1]
        address = f'127.0.0.1:{port}'
        process = subprocess.Popen([str(binaries / ('phobos-server' + suffix)), '--bind', address,
                                    '--data-dir', str(out/'database')], stdout=log, stderr=log,
                                   env=env, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        deadline = time.monotonic() + 10
        while True:
            if process.poll() is not None:
                raise RuntimeError('server startup failed')
            try:
                with socket.create_connection(('127.0.0.1', port), timeout=0.2):
                    return process, address
            except OSError:
                if time.monotonic() >= deadline:
                    process.kill()
                    process.wait()
                    raise
                time.sleep(0.02)
    def query(address, sql):
        return run('phobos-cli', ['query', '--addr', address, sql])
    process, address = start()
    try:
        good = ''.join(f'i:{i}\ti:{i % 100}\tt:payload\n' for i in range(1000,1128))
        (out/'good.tsv').write_text(good)
        assert 'IMPORTED 128' in run('phobos-cli', ['ingest', '--addr', address, 'bench', out/'good.tsv'])
        bad = ''.join(f'i:{i}\ti:1\tt:pending\n' for i in range(2000,2128)) + 'malformed\n'
        (out/'bad.tsv').write_text(bad)
        run('phobos-cli', ['ingest', '--addr', address, 'bench', out/'bad.tsv'], success=False)
        assert query(address, 'SELECT COUNT(*) AS n FROM bench WHERE id>=2000').strip() == 'n\n0'
        stdin = ''.join(f'i:{i}\ti:2\tt:stdin\n' for i in range(3000,3032))
        assert 'IMPORTED 32' in run('phobos-cli', ['ingest', '--addr', address, 'bench', '-'], text=stdin)
        assert query(address, 'SELECT COUNT(*) AS n FROM bench').strip() == 'n\n160'
    finally:
        process.kill()
        process.wait()
    run('phobos-admin', ['check', out/'database'])
    process, address = start()
    try:
        assert query(address, 'SELECT COUNT(*) AS n FROM bench').strip() == 'n\n160'
        assert query(address, 'SELECT id FROM bench WHERE id=1000').strip() == 'id\n1000'
    finally:
        process.kill()
        process.wait()
    run('phobos-admin', ['check', out/'database'])
    (out/'PASSED.txt').write_text('Release CLI file import, stdin, late malformed rollback, abrupt stop/reopen and offline integrity passed.\n')
    log.close()
    print('C7 CLI ACCEPTANCE PASSED', flush=True)


if __name__ == '__main__':
    main()
