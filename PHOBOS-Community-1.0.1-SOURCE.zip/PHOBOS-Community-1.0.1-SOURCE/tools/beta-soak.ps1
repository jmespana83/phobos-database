param([ValidateRange(1,86400)][int]$Seconds=7200,[Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if(Test-Path -LiteralPath $OutputDirectory){throw 'Output directory must be new'}
$out=(New-Item -ItemType Directory $OutputDirectory).FullName
$exe=(Resolve-Path target/release/beta-soak.exe).Path
$p=Start-Process $exe -ArgumentList @(('"'+(Join-Path $out 'workload')+'"'),"$Seconds") -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $out 'stdout.log') -RedirectStandardError (Join-Path $out 'stderr.log')
$samples=[Collections.Generic.List[object]]::new()
$watch=[Diagnostics.Stopwatch]::StartNew()
try {
 while(-not $p.HasExited){
  $p.Refresh()
  $sample=[pscustomobject]@{seconds=$watch.Elapsed.TotalSeconds;working_bytes=$p.WorkingSet64;private_bytes=$p.PrivateMemorySize64;handles=$p.HandleCount;cpu_seconds=$p.TotalProcessorTime.TotalSeconds}
  $samples.Add($sample)
  $sample | Export-Csv (Join-Path $out 'resources.csv') -Append -NoTypeInformation
  if($watch.Elapsed.TotalSeconds -gt $Seconds+300){throw 'Soak exceeded duration plus shutdown allowance'}
  Start-Sleep -Seconds 5
 }
 $p.WaitForExit()
 if($p.ExitCode -ne 0){throw "Soak failed: $($p.ExitCode)"}
 # Explicit finite-run leak budgets, not a mathematical proof of bounded growth.
 if($samples.Count -ge 20){
  $first=$samples[10]; $last=$samples[$samples.Count-1]
  if($last.handles-$first.handles -gt 64){throw 'Handle growth exceeds 64 after warmup'}
  if($last.private_bytes-$first.private_bytes -gt 128MB){throw 'Private-byte growth exceeds 128 MiB after warmup'}
 }
 [ordered]@{status='PASS';requested_seconds=$Seconds;elapsed_seconds=$watch.Elapsed.TotalSeconds;two_hour_gate=($Seconds -ge 7200);executable_sha256=(Get-FileHash $exe).Hash;scope='Coordinator sessions and offline lifecycle; TCP/TLS lifecycle is a separate gate'} | ConvertTo-Json | Set-Content (Join-Path $out 'result.json')
} finally { if(-not $p.HasExited){$p.Kill();$p.WaitForExit()};$p.Dispose() }
