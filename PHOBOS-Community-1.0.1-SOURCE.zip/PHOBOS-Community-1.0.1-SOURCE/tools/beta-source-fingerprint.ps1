$root=Split-Path $PSScriptRoot -Parent
$files=@(Get-ChildItem (Join-Path $root crates) -Recurse -File | Where-Object {$_.Extension -in @('.rs','.pem') -or $_.Name -eq 'Cargo.toml'})
$files+=Get-Item (Join-Path $root Cargo.toml),(Join-Path $root Cargo.lock),(Join-Path $root rust-toolchain.toml)
$files+=Get-ChildItem (Join-Path $root tools) -File | Where-Object {$_.Extension -in @('.ps1','.py')}
$files|Sort-Object FullName|ForEach-Object {[pscustomobject]@{path=[IO.Path]::GetRelativePath($root,$_.FullName).Replace('\','/');sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}}
