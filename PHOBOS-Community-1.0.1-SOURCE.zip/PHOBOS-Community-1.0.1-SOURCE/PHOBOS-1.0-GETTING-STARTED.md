# PHOBOS Community Edition 1.0.1 — Getting Started

Run Windows Setup, select Server/tools and optionally Studio, then complete the visible configuration dialog. Defaults: 127.0.0.1:54321, user admin. Choose your own password; no default password exists. Open Studio from Start, connect and execute:

```sql
CREATE TABLE customers (id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO customers(name) VALUES ('Ada'),('Lin') RETURNING id,name;
CREATE TABLE orders (id BIGINT PRIMARY KEY, customer_id BIGINT, amount BIGINT DEFAULT 0 CHECK(amount>=0), FOREIGN KEY(customer_id) REFERENCES customers(id));
INSERT INTO orders(id,customer_id,amount) VALUES (1,1,20);
SELECT c.id,c.name FROM customers c WHERE EXISTS(SELECT 1 FROM orders o WHERE o.customer_id=c.id);
CREATE VIEW customer_names AS SELECT id,name FROM customers;
SELECT * FROM customer_names;
```

F5 executes; each query tab owns independent connections. Scripts execute sequentially and stop on error; use BEGIN/COMMIT for atomicity. Do not automatically replay writes after connection loss: commit may already be durable.

Portable workflow: phobos-admin init NEW_INSTANCE; provision an admin with user-add-stdin; start phobos-server --data-dir NEW_INSTANCE/data --auth-file AUTH --bind 127.0.0.1:54321 --wal-mode flush --shutdown-file STOP_FILE. Use phobos-cli shell for interactive SQL. Read SECURITY before remote access and UPGRADE before using old data.
