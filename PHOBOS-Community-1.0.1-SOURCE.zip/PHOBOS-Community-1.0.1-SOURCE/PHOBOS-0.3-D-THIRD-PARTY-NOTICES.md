# PHOBOS 0.3-D third-party package notices

Studio uses the packages below. Platform-specific assets are selected by the publish target. Upstream license metadata and package notices are retained in licenses/.

- Avalonia/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Angle.Windows.Natives/2.1.25547.20250602: LICENSE — Avalonia Team — https://avaloniaui.net/
- Avalonia.AvaloniaEdit/11.3.0: MIT — Avalonia Team — 
- Avalonia.BuildServices/11.3.2: MIT — Avalonia Team — https://avaloniaui.net/
- Avalonia.Controls.DataGrid/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Desktop/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.FreeDesktop/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Native/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Remote.Protocol/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Skia/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Themes.Fluent/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.Win32/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- Avalonia.X11/11.3.13: MIT — Avalonia Team — https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link
- HarfBuzzSharp/8.3.1.1: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- HarfBuzzSharp.NativeAssets.Linux/8.3.1.1: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- HarfBuzzSharp.NativeAssets.macOS/8.3.1.1: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- HarfBuzzSharp.NativeAssets.WebAssembly/8.3.1.1: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- HarfBuzzSharp.NativeAssets.Win32/8.3.1.1: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- MicroCom.Runtime/0.11.0: MIT — MicroCom.Runtime — 
- SkiaSharp/2.88.9: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- SkiaSharp.NativeAssets.Linux/2.88.9: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- SkiaSharp.NativeAssets.macOS/2.88.9: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- SkiaSharp.NativeAssets.WebAssembly/2.88.9: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- SkiaSharp.NativeAssets.Win32/2.88.9: MIT — Microsoft — https://go.microsoft.com/fwlink/?linkid=868515
- System.Diagnostics.EventLog/10.0.0: MIT — Microsoft — https://dot.net/
- System.ServiceProcess.ServiceController/10.0.0: MIT — Microsoft — https://dot.net/
- Tmds.DBus.Protocol/0.21.3: MIT — Tom Deseyn — 

Dependencies unchanged from accepted 0.3-C. Studio uses SDK 10.0.402 and the self-contained .NET 10 runtime selected by that SDK. Inno Setup 6.7.3 is a build tool; its notices remain with the installer tool distribution.
