# PHOBOS 1.0.1 — Accepted Hotfix Handoff

READY TO RESUME PHOBOS STAGE 28 FINAL VALIDATION.

Work root: C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1. Final deliverables are in outputs. Start with PHOBOS-1.0.1-HOTFIX-REPORT.md and PHOBOS-1.0.1-FINAL-HASHES.txt. The new source archive is PHOBOS-Community-1.0.1-SOURCE.zip; use its external manifest hash. The source archive cannot contain its own hash without a circular dependency.

Authoritative previous source: PHOBOS-Community-1.0.0-SOURCE.zip, SHA-256 b383a259539212468fd76cecde06c764d4bcaa1917d7561d408f9789c4c46f7d. Do not overwrite it. All 205 Rust source files remain identical. Catalog 5, protocol 1, Management API 1. Public version 1.0.1.

Client terminal statement errors preserve the validated session; fatal/malformed/unknown responses and interrupted streams still close it. No SQL replay or transaction reset. Explicit failed transactions require ROLLBACK. The persistent Messages TabItem fixes a separate blank-render defect.

Windows repair validates protected metadata and ownership, recognizes 1.0.0/1.0.1, detects file lockers with Restart Manager, asks for close/Retry without force-kill, stops the owned service gracefully before copy and authenticates/readiness-checks after restart. Auth/config/identity/views/constraints survive. Isolated installer AppIds prevent tests from touching the primary registry entry. Ordinary default AppId remains compatible.

Final evidence: 629 routine tests passed, 4 ignored; strict Clippy and formatting passed; exact packaged Core integration/fault tests, actual Avalonia GUI, new-client/old-server tests, final exact Setup automated fresh and 1.0.0 repair, visible fresh configuration, interactive open-Studio repair, data-preserving uninstall, crash/recovery, backup/restore and integrity passed. See evidence/1.0.1. Never distribute the StudioValidation=true instrumented build; production StudioValidation=false is packaged.

The primary C:\Program Files\PHOBOS / C:\ProgramData\PHOBOS, PHOBOSDatabase service remains 1.0.0 and unchanged. Interactive 1.0.1 test services/binaries were removed; their data/auth/config remain under PHOBOS-101-Interactive and PHOBOS-101-FinalInteractive. Automated fixture data also remains, without active test services. Do not delete preserved databases or historical fixtures without authorization. No password belongs in this handoff, command arguments or logs.

Stop feature development here. Next activity is independent Stage 28 benchmark/stress validation against the published final 1.0.1 bytes. Do not relabel historical benchmark results. No new long-soak, Standard performance, Linux/macOS, signing or production certification is claimed. DROP TABLE remains unsupported. Read the known limitations before independent qualification.
