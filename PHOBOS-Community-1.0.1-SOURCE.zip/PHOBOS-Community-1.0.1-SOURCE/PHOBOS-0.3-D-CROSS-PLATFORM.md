# PHOBOS 0.3-D cross-platform status

| Surface | Actual status |
|---|---|
| Windows x64 Studio | Built and exercised with real PHOBOS connections, GUI render checks, isolated SCM tests, and standalone installer lifecycle |
| Linux desktop | Not qualified. `wsl --list --quiet` reported WSL is not installed; no Docker command was available on this host. No usable Linux desktop was available. |
| Linux package | Not produced: an untested artifact would not satisfy qualification. |
| macOS desktop/package | Not qualified; no macOS environment available. No package produced. |
| Local systemd / launchd administration | Deferred; `NoLocalInstances` remains the non-Windows adapter. |

Core protocol, profiles, exports, script boundaries, layout and session ownership use platform-neutral .NET APIs. Avalonia and conditional platform adapters preserve the architectural boundary, but this is not a Linux/macOS support claim. Windows-specific discovery/SCM code remains isolated. No OS installation, root requirement for SQL, shell-based systemd workaround or speculative distro package was introduced.

Windows qualification includes actual Avalonia rendering, native launch/close, dark/light/system selection and raster renders at 1.0/1.25/1.5/2.0 scale. Render scaling is not equivalent to changing Windows monitor DPI or moving between monitors. See evidence for the actual window RenderScaling. Multi-monitor DPI transitions, keyboard-only/native automation and screen-reader qualification remain work for the next milestone; routed F5/Ctrl+Enter are tested.

A credible Linux gate for 0.3-E requires an actual Linux desktop: locked restore/build, native launch, real server authentication, catalog/SELECT/results, file open/save, disconnect/reconnect, theme/scaling checks, then packaging and retesting the package. macOS needs the same native gate plus signing/notarization planning. The Windows build alone proves neither.
