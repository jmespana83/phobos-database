# PHOBOS 1.0.1 — Known Limitations

This hotfix changes client error handling, installer maintenance and patch-version compatibility. It adds no SQL feature. DROP TABLE remains unsupported. All documented 1.0 SQL, FK serialization/materialization, technical resource and throughput limitations continue to apply. No new performance certification is claimed.

Windows artifacts remain unsigned. Linux/macOS are not qualified by this task. Catalog 5, wire protocol 1 and Management API 1 remain unchanged. The primary Windows installer remains a loopback instance manager; portable-server TLS configuration and strict Studio TLS validation are unchanged. Repair does not introduce a TLS provisioning UI or silently rewrite external certificate/configuration files.

Compatible repair accepts known 1.0.0 and 1.0.1 metadata and executable identities. Unknown/newer versions are not silently downgraded. Ambiguous discovery, ownership, paths, incomplete initialization or uninspectable processes fail closed. Some severely damaged installations require administrator inspection rather than automatic repair. A canceled or failed configuration step makes no readiness claim and never reinitializes existing data.

Restart Manager detects current file lockers; another process can still race to open a file after preflight. PHOBOS does not force-close applications. Save work, close the listed application and retry. If service shutdown cannot be confirmed within the bounded maintenance wait, file replacement stops; investigate the service rather than killing the database.

The server's protocol does not expose a separate transaction-status field. Studio shows the actual error and preserves the transaction; it does not guess a successful rollback. Unknown error codes conservatively close the session. Scripts never resume or replay automatically after an error.
