# PHOBOS 0.3-F architecture

## Product and engine separation

Packaging 0.3-F fixes Windows installation behavior. The stabilization installer/runtime contain the byte-identical accepted 0.3-A engine binaries from the accepted 0.3-B distribution lineage. The accepted GUI is unchanged Studio 0.3-D. This source bundle is derived from the authoritative experimental 0.3-E archive; its Rust implementation remains that candidate and is not silently relabeled 0.3-F.

The engine promotion decision and supporting measurements are recorded in PHOBOS-0.3-F-PERFORMANCE.md. Until promotion is explicitly cleared, do not build this candidate workspace and substitute its output into the accepted-engine installer. The installer build enforces the accepted hashes and writes docs/BUILD.json with packaging version, engine version/status, API version and unsupported identity/RETURNING flags.

## Windows boundary

Inno Setup now invokes interactive configure with SW_SHOWNORMAL, its window handle, and explicit progress feedback explaining the separate dialog. The native WinForms manager uses a valid owner when supplied, centers on that owner, stays discoverable in the taskbar and activates once when shown. Standalone/manual configure falls back to a centered ordinary dialog. Hidden mode is retained only for noninteractive prerequisites, prepare and removal. The existing console-subsystem manager may also expose its console window; required form input is visible.

A durable initializing manifest precedes initialization. Configuration failures never delete data. Registration now compensates a partially created owned service; later startup failures stop/remove the newly registered owned service where safe. Both ownership verification and graceful stop remain prerequisites. If cleanup fails, retained initializing state blocks destructive retries and requires administrator inspection. There is no forced engine termination in ordinary installation/shutdown paths.

Deterministic interruption callbacks exist only in a PHOBOS_INSTALLER_TESTS build. They are compiled out of shipped invocation paths and cannot be enabled by installer arguments/environment. Six boundaries validate retained state, rejected blind retry and absence of orphaned services/listeners. These are exception-injection tests, not simulated power-loss certification.

Instance schema 1 accepts productVersion 0.3-B or 0.3-F only with engineVersion 0.3-A. New manifests identify 0.3-F; existing B manifests retain their creation identity during compatible repair. Registry discovery reports installed packaging 0.3-F and engine 0.3-A separately. This is a deliberate packaging compatibility extension, not a catalog migration. A new F manifest is not promised readable by the old B manager.

## Engine boundary

No production Rust file changed relative to 0.3-E. Storage, WAL, indexes, tuples, MVCC publication, recovery, replication, PITR, backup and integrity formats/semantics are untouched. A release-mode diagnostic catalog example measures actual public definition lookup/validation/clone functions using black_box. A serial TCP microbenchmark measures unconstrained and seven combinations of DEFAULT/CHECK/PK, expected CHECK failure, autocommit, and batched transactions. Explicit transactions roll back after a rejected statement.

Performance evidence includes balanced fresh control/candidate pairs of the frozen PHOBOS Standard Benchmark v1.3.1-G56. The folder name v1.3.2 does not rename the suite. All runs and outliers are retained. No fast-path flag, cached schema state, fsync change, CHECK bypass or benchmark-score optimization was introduced without causal evidence.

## Future milestones

Identity/sequences and RETURNING remain deferred. A future allocator must be a durable, transaction/recovery-aware object with explicit rollback/gap semantics and no MAX(id)+1. RETURNING should reuse the existing typed result protocol and emit rows only after statement validation, with explicit transaction semantics. The accepted GUI remains a public Management API consumer; no internal-file parsing was added.

Linux/macOS engine architecture remains portable Rust. This milestone's executed runtime validation is Windows only; it does not qualify other operating systems.
