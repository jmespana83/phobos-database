# 0.3-C — Management Studio V1

- Added portable .NET protocol/session/catalog/document core and Avalonia desktop GUI.
- Added typed streaming grids, cancellation, catalog explorer, SQL tabs/files/templates, password-free profiles and isolated Windows SCM adapter.
- Added standalone self-contained Windows packaging and client/GUI/SCM/protocol validation.
- Preserved all engine and 0.3-B server-packaging source. See milestone reports for limits.

# 0.3-B — Windows distribution foundation

- Added Inno Setup installer, native instance dialog, LocalService SCM host, protected instance metadata and GUI discovery.
- Preserved all engine source/binaries, SQL features, formats, durability and management API v1.
- Added secure stdin initialization, authenticated transactional smoke, graceful lifecycle, same-version repair, conservative uninstall and reproducible validation tools.
- Final elevated lifecycle qualification passed; see the 0.3-B test report. No production certification, signing or cross-platform packaging test claim.

# 0.3-A — Enterprise SQL Foundation



Added query aliases and composition, general stored-table join predicates, uncorrelated scalar/EXISTS subqueries, limited CTE/derived inputs, column-list INSERT, transactional renames, practical scalar functions and versioned SHOW CATALOG metadata. Preserved K.5 storage/WAL formats. See the 0.3-A compatibility document for explicit limitations and deferred features.



# Changelog



## 0.0.1-alpha.0



- Phase 0 repository foundation and documented architecture.

- Versioned binary handshake protocol with server/client implementations.

- Initial Phase 1 page-file and slotted-page storage primitives with checksums.



## Unreleased â€” Session 002



### Added

- Phase 1 durable catalog bootstrap and typed schema/value model.

- Schema-aware row codec with NULL bitmap and all initial storage types.

- Bounded page buffer pool with dirty tracking, pin/unpin, LRU eviction, and flush.

- Heap-table free-space tracking and sequential scans.

- Phase 1 SQL parser/executor for CREATE TABLE, multi-row INSERT, and SELECT projection.

- Query/QueryResult protocol frames plus client/CLI query support.

- Restart, corruption, golden-format, typed-codec, constraint, and larger-than-buffer tests.



### Not yet claimed

- Phase 1 remains a candidate until the pinned Rust formatting, Clippy, test, and rustdoc gates pass locally.



## Phase 2 candidate â€” 2026-09-11

- Added typed expression parsing/evaluation and SQL three-valued predicate logic.

- Added WHERE, UPDATE, DELETE, ORDER BY, LIMIT, OFFSET, and typed `$n` parameter binding.

- Added heap tombstone/replacement support for single-user DML.

- Added bounded engine-level SELECT batching for non-ordered queries.

- Added Phase 2 regression, restart, NULL semantics, and bounded-batch tests.



## Phase 3 candidate â€” 2026-09-11

- Added BEGIN/COMMIT/ROLLBACK/CHECKPOINT parsing and execution.

- Added durable transaction identifier lifecycle.

- Added private transaction staging with read-your-writes and rollback-by-discard.

- Routed autocommit mutations through the transactional commit path.

- Added framed checksummed WAL records with transaction IDs, LSNs, previous-LSN links, bounded file-image chunks, commit records, and checkpoints.

- Added synchronous WAL-before-main-data commit ordering.

- Added startup redo, incomplete-transaction discard, torn/truncated WAL-tail handling, stale staging cleanup, and generation-based WAL rotation.

- Added subprocess crash injection after durable WAL commit and during an uncommitted transaction.

- Added ADR 0005 documenting the Phase 3 redo-only staging/recovery strategy and its performance tradeoff.



## Phase 4 candidate

- Added a disk-backed checksummed B+ tree index crate.

- Added persistent index catalog metadata and CREATE/DROP INDEX SQL.

- Added composite/unique/range index support, planner selection, DML maintenance, integrity validation, and WAL-protected `.idx` files.



## Phase 5 candidate



- Added persistent multi-client TCP sessions.

- Added connection-scoped transaction ownership, bounded lock waits, and disconnect rollback.

- Added deterministic concurrency tests and a coarse strict-2PL isolation baseline.



## Phase 6 candidate



- Added relational SELECT AST for INNER/LEFT equi-joins and aggregate projections.

- Added GROUP BY/HAVING and COUNT/SUM/AVG/MIN/MAX.

- Added persistent ANALYZE statistics and a first cost-aware access planner.

- Added EXPLAIN / EXPLAIN ANALYZE.

- Added spill-capable external merge sort and bounded join fallback.

- Added Phase 6 execution/parser tests and smoke-gate tooling.



## Phase 7 candidate



- Added Argon2-backed authentication and coarse reader/writer/admin authorization.

- Added rustls TLS server/client transport with certificate validation.

- Added non-loopback safety policy requiring TLS and authentication during alpha.

- Added OS-backed data-directory locking, resource limits, metrics, offline backup/restore, and integrity checks.

- Added Phase 7 operational validation tooling and documentation.



## Unreleased â€” targeted 10M write-path campaign



- Measure staging, storage, index, filesystem and WAL costs with optional profiling.

- Batch private staging heap inserts while preserving statement/commit flush and WAL ordering.

- Reuse a validated insertion leaf; accept valid equal B+ tree separators and reject descending ones.

- Replace linear spill-head selection with stable tournament selection.

- Add dirty-staging and mixed-installation crash coverage and focused regressions.

- Complete the durable 10M target, full large correctness and two-hour soak; PostgreSQL comparison remains pending.



## Unreleased â€” matched PostgreSQL campaign



- Measure the existing TCP comparison driver against PostgreSQL 18.6 at 100K, 1M, and 10M.

- Retain all timings, response-limit failures, timeouts, configuration and postcheck evidence.

- Preserve engine source, release binaries and documented durability/security limits; beta remains uncertified.



## 0.2-B â€” Execution Engine V2 + concurrency performance campaign



- Engine v2 borrowed tuple views: `ValueRef` values decoded only for required columns straight from immutable shared page images; bound predicates, projected aggregates, GROUP BY (borrowed key lookup), join probe and Top-K (materialize only on admission).

- Committed page cache: O(1) CLOCK clean-frame replacement (was a full resident scan per miss), zero-copy shared page reads, small-table scan admission, shared file handles (no `dup` per read), heap images validated once on cache entry.

- Planner: realistic index heap-fetch costing (crossover ~5% selectivity); single-table aggregates use index access (e.g. `COUNT(*) ... WHERE indexed_col = k`).

- Index: complete batch windows skip the confirming traversal; allocation-free node size; in-place batch cache inserts (no node clone per row).

- Commit path: small prepared generations stay memory-resident (no scratch directory/file per commit); batched index maintenance per commit.

- Wire: one write per frame, TCP_NODELAY in the client, 64 KiB buffered result streaming; statement cancellation registration released before the final reply.

- Statement-scoped hint counters (no shared atomic per tuple); per-slot hint lookup without bitmap clone.



## 0.2-C â€” Durable Commit Engine V2 (group commit + WAL batching)



- Pipelined, absorbing group commit: the commit leader stages a batch (prepare + WAL append) under the commit-order lock, releases leadership, then forces the WAL outside every lock; the next batch prepares and appends while the previous force is in flight, and commits that arrive during an in-flight force join the batch before its force (up to 64). Publication stays strictly in batch order.

- Single-flight WAL force (`Wal::begin_force` / `complete_force` / `receipts_for`): `sync_data` runs on a cloned handle outside the WAL lock; a durable receipt is issued only for commit records whose LSN is covered by a completed force. A failed force fences the WAL. The acknowledgement point is unchanged.

- WAL v2 record checksum: CRC32C (hardware) for new non-anchor records, flagged per record; pre-0.2-C FNV-1a records still verify and recover.

- Small schema-free batches whose members share a table prepare inside one physical domain (no per-member catalog clone or worker thread); disjoint members keep C6 parallel preparation.

- Index: zero-allocation in-place leaf insert for the non-unique-enforcing path (byte-identical page image to the generic path); allocation-free v3 key validation in node views; binary-search descent and probe start in batch inserts; a generation-scoped validated-leaf cache for committed readers (invalidated by every index publication).

- Storage: cached canonical paths for private generations and statement readers; scratch retirement checks existence before canonicalizing.

- Maintenance (WAL segment rotation, checkpoint advance) drains the commit pipeline first; checkpoint data forcing remains in the background thread.



## 0.2-D â€” Compact WAL and physiological page redo (WAL V3)



- Compact page redo: a changed page is logged as a `PageDelta` (record kind 15) â€” a bounded program of `WRITE(offset, bytes)` and `MOVE(dst, src, len)` ops against the page's previous logged image, identified by its LSN and embedded CRC32C page checksum â€” instead of a full 8 KB image. A single-row INSERT with a UNIQUE and a secondary index writes ~0.6â€“0.8 KB of WAL instead of ~25 KB. Page and B+tree code is unchanged; the generic encoder finds the shifted tail of a mid-leaf insert/delete (one `MOVE` plus the entry) and only emits a program after replaying it against the base and reproducing the image exactly.

- Full-page images stay where they are needed: pages allocated by the transaction, the first change of every page in each WAL segment (torn-page repair source; segments are the unit of WAL retirement), bases that are not exactly the segment's last logged image of that page (LSN and page checksum), aborted chains, and deltas that are not smaller. The writer, not the caller, decides (per-segment page chain map, cleared at rotation and WAL rewrite). Images with large zero runs are logged zero-elided (kind 16), which decodes to the same full image.

- Recovery: deltas are applied only to an on-disk page whose LSN and page checksum equal the logged base, then re-stamped and required to reproduce the logged result checksum; pages already at or past the record LSN are skipped. A torn or foreign base waits for a later full image of that page; if none follows, recovery fails closed before rewriting the WAL. Redo keeps the pages it read or wrote in a bounded cache, and WAL scans read through a 1 MiB buffer (a segment now holds ~30x more records).

- Compatibility: 0.2-D recovers every 0.2-C record (FNV-1a and CRC32C). Anchors written by 0.2-D carry a new flag (0x10); a writer opened on an older clean WAL rewrites its anchor first, so V3 records only follow a V3 anchor and 0.2-C refuses a 0.2-D WAL during preflight (`unsupported V2 WAL flags`) instead of misreading it. Downgrade is not supported.

- Fewer segment rotations (â‰ˆ1 per 75K single-row commits instead of â‰ˆ1 per 2.9K); WAL record encoding writes straight into the writer's batch buffer.

- Interrupted segment rotation is recovered: a crash after the active WAL was renamed to a sealed segment and before the new active file held a complete anchor (missing, empty or torn new file) previously made startup fail closed; read-only scans now treat the newest sealed segment as the end of the log and writer recovery renames it back before redo.



## 0.2-E â€” Windows durable WAL (preallocated write-through WAL)



- New WAL durability mode E (default on Windows and Linux; `--wal-mode` / `PHOBOS_WAL_MODE`): the active WAL file is preallocated in 4 MiB zero-filled, flushed extents and opened write-through (Windows `FILE_FLAG_WRITE_THROUGH`, Linux `O_DSYNC`). Stage A only encodes records into memory; the single-flight force leader reserves the exact byte range and performs one positional write-through write outside every engine lock. That completed write is the durability event; no per-commit `FlushFileBuffers`/`fdatasync`. Mode A (`flush`) keeps the 0.2-D path for A/B testing.

- Zero-tail recovery rule: a preallocated segment ends at its valid record prefix; the rest must be zero, except non-zero bytes confined to one torn final write (256 KiB piece + 64 KiB record) in the active segment. Anything else is corruption and recovery fails closed. Sealed segments must have an all-zero tail.

- New active files (creation, rotation, checkpoint rewrite) are built complete under the temporary name and renamed into place; an all-zero active file is treated as an interrupted rotation. Writes are issued in â‰¤256 KiB pieces, each completed before the next.

- Failures (short write, failed write, disk full during extension) fence the writer before any receipt, exactly as a failed flush did.

- Compatibility: 0.2-E recovers 0.2-D WAL and rewrites the anchor into the configured mode's format at writer open. Preallocated anchors set flag 0x20, so 0.2-D refuses a 0.2-E WAL (`unsupported V2 WAL flags`) without modifying anything. Downgrade is not supported.

- Behavioural note: in Mode E a COMMIT record appended but not yet forced is no longer in the OS cache, so a process crash before the force loses that (never acknowledged) transaction; tests that asserted the old process-crash visibility now accept all-or-nothing.

- Design and proof: `docs/wal_v3_windows_durable_wal.md`.



## 0.2-F â€” Small-write CPU engine / B+tree fast path V2



- Profile correction: the "~10 node decodes per indexed insert" in 0.2-E profiles came from start-up integrity validation (one full traversal per index at open), amortised over short runs. Steady-state inserts decode no `Node`; the real duplicate work was per-use re-validation of committed index pages, 8 KiB page copies, per-comparison key encoding and per-statement file opens.

- Validated-once immutable index images: the committed page store validates every index image once on entry (disk read or publication) with the registered index validator; readers share the immutable `Arc` image zero-copy and build `NodeView`s without re-validating every key (header/bounds still checked). Private, pending and base-file images are copies and always fully validated.

- Node layout memo: entry offsets are memoised next to the image in the generation-scoped navigation cache and re-checked (`with_layout`) before reuse; the cache is cleared on every publication generation change.

- Encode-once comparisons in `lower_bound` and range upper bounds (equivalent to decoding comparisons for validated V3 keys).

- Statement readers reuse a cached base-file handle (file opens per autocommit 7 â†’ ~0, per 500-row transaction 514 â†’ ~2); batched leaf inserts track the encoded leaf length incrementally; `encode_node` reuses its buffer.

- Publication skips the filesystem probe for transaction scratch roots this process never created (bounded registry; open-time housekeeping guarantees no stale root exists).

- Catalog maps are copy-on-write (`Arc` + `make_mut`): per-statement and per-commit catalog clones are O(1).

- WAL Mode E: one optional background extender prepares (zero-fills and flushes) the next 4 MiB extent when less than 1 MiB of prepared capacity remains; capacity advances only after the flush succeeded; the foreground extension is unchanged and remains the fallback; checkpoint/rotation/close join the extender. `PHOBOS_WAL_BACKGROUND_EXTEND=0` disables it.

- UNIQUE final recheck, isolation, WAL format, durability protocol and recovery rules are unchanged. Design: `docs/index_fast_path_0_2_f.md`.



## 0.2-G â€” Commit pipeline CPU / preparation V2



- Fewer CRC32C passes per changed page: the WAL accepts the image it just stamped through an exact (file, page, LSN, stored checksum) token; installation verifies the checksum once and passes the committed store a borrow-scoped `VerifiedImage` proof bound to those bytes. Images produced in this process and never spilled (`ProducedInProcess` token) enter the store with a structural/layout check (full validation in debug builds); spilled and disk images keep full validation.

- Small same-table Stage A / Stage B run in place under the database mutex (`with_database_in_place`) instead of extracting and re-inserting the physical domain; lock order commits â†’ database â†’ WAL unchanged.

- Private pages: sparse head map (no 3 Ã— 32 KiB memset per commit), resident dirty pages installed without an 8 KiB copy, up to 63 prepared pages resident (500-row transactions no longer spill to a scratch directory).

- Statement readers share the cached base file handle (`Arc<File>`) instead of duplicating it.

- Rebase borrows the table schema and index definitions instead of cloning them per changed row; dirty heap frames are written to the private file without an 8 KiB clone.

- Fix (pre-existing in 0.2-F): while a Stage-A batch yielded to the publisher, a second Stage-A batch could interleave WAL records and break ordered receipts (database fenced). Stage A now admits one batch at a time (`stage_a_active`).

- WAL Mode E background extender: adaptive step (4 MiB doubling to 32 MiB when the commit path waited for or performed an extension; trigger at half a step remaining; reset on file replacement).

- PreparedWritePlan (prepare outside commit order) evaluated and deferred: zero single-client gain, pending-chain bases lack identity. WAL, page and catalog formats, UNIQUE final recheck, isolation and durability protocol unchanged. Design: `docs/commit_pipeline_0_2_g.md`.



## 0.2-H â€” Request path + Batch DML V2



- Plain-TCP connections no longer hand each frame from a per-connection reader thread to the worker (`Direct` transport): the worker that owns the connection reads the frame itself (16 KiB buffer), executes and responds. A per-connection monitor parks in 100 ms ticks and, only while a statement has run â‰¥ 100 ms, peeks the socket (never consuming bytes) and cancels the session on EOF/error. First request of a connection: one non-blocking peek so a connection abandoned while queued is not executed. Terminal read errors cancel the session. Idle deadline covers the complete frame; malformed headers fail immediately. TLS connections and `PHOBOS_REQUEST_PATH=pumped` keep the 0.2-G reader-thread transport.

- Statements without a client-requested cancel handle use a per-connection OS-random base XOR counter (no OS RNG call per statement); disclosed `CancelHandle`s still come from the OS RNG.

- Batch DML V2: MVCC index maintenance encodes every key once into an arena (memcomparable V3 encoding; order equivalence property-tested), sorts encoded bytes, groups keys per leaf by fence descent (internal pages reused within the batch, committed images read shared/trusted) and merges the leaf's encoded entries with the incoming ones into one new image with one checksum. Overflow, fence-equal keys and legacy pages take the 0.2-G typed path; result is byte-identical to 0.2-G (11-scenario test). `PHOBOS_INDEX_BATCH=typed` restores the typed batch.

- Admission builds each index key once per row; the statement keeps earlier rows' logical UNIQUE keys instead of cloning the row change; the table schema is shared. Committed UNIQUE probe and final recheck unchanged.

- Private heap pages are mutated in their buffer frame (`modify_page`); the frame is marked unsealed and its checksum is refreshed once before any exposure (reader copy, private write, eviction). Committed images are never mutated. `PHOBOS_HEAP_IN_PLACE=0` restores the copy path.

- Slow-request trace (inert unless `PHOBOS_SLOW_REQUEST_US` is set): per-request phase accumulation from existing spans, hand-off time, background extent/checkpoint overlap, optional Linux run-queue delay; one CSV line per slow request only.

- Evaluated and deferred: PreparedWritePlan, batched committed-tree UNIQUE probing, parser allocation work. WAL, page, catalog and protocol formats, UNIQUE authority, Stage-A exclusivity and the 0.2-G image proofs are unchanged. Design: `docs/request_batch_0_2_h.md`.



## 0.2-I â€” Platform-aware request transport V3



- Request transport is a runtime platform policy: `PHOBOS_REQUEST_PATH=auto|direct|pumped` (unset = auto; case-insensitive). Auto resolves to the 0.2-G reader-thread transport (`Pumped`) on Windows and to the 0.2-H worker-reads transport (`Direct`) on Linux and other Unix; TLS always uses Pumped; explicit `direct`/`pumped` override auto. Any other value is a start-up configuration error. The policy is read and resolved once per server (`RequestPath::resolve`), logged once (`event=request_path policy=â€¦ resolved=â€¦ platform=â€¦ tls=â€¦`) and counted in profiling builds (`request.transport.auto_resolved_direct|pumped`). Both transports remain unchanged and selectable.

- Shutdown marker: once `--shutdown-file` is observed, shutdown proceeds even if removing the marker hits a transient Windows sharing violation (os error 32/33/5: retried for ~1 s, then left with a warning). Other errors are reported as before. A marker present at start-up still requests an immediate clean shutdown (unchanged); start helpers remove stale markers.

- Tests: transport policy parsing/resolution, shutdown-marker handling, a Direct/Pumped parity test over a real TCP server (identical outcomes, results, heap and index files, and post-restart state), Auto serving plus the unchanged marker-at-start contract.

- Unchanged: the 0.2-H engine, WAL, page, catalog and protocol formats, UNIQUE final recheck, Stage-A exclusivity, durability. Design: `docs/platform_transport_0_2_i.md`.



## 0.2-I.1 â€” Overflow safety hotfix



- Fix (present in 0.2-I): after a restart, `HeapTable::insert_encoded` could accept an "unknown" interior page that was a heap overflow page. It judged the page by its raw free space instead of the overflow-aware value it had just computed. This happened in both the in-place and the copy branch.

  - Ordinary tuples then landed on overflow pages.

  - A live wide row became unreadable: its reads, scans and `CHECKPOINT` failed with "overflow page kind is invalid".

  - On released overflow pages, committed rows silently vanished from `COUNT(*)` and scans.

- Invariant: an overflow page may never store an ordinary heap tuple.

  - `SlottedPage::ordinary_free_space` reports 0 for overflow pages and is used by every ordinary-tuple acceptance test: both `insert_encoded` branches, `insert_version_batch` (bulk; an overflow tail page is never reused) and `reclaim_versions`.

  - `insert_ordinary` / `insert_ordinary_unsealed` refuse overflow pages with `InvalidPage` (fail-safe).

- `phobos-admin check` audits every MVCC heap page read-only and names the table, heap file, page, kind, slot count and slot contents of any overflow page holding ordinary tuples.

- New offline command `phobos-admin repair-overflow DATA_DIR EMPTY_BACKUP_DIR [--dry-run]`.

  - It requires the data-directory lock and a WAL with nothing to redo, and writes a full backup first.

  - It relocates a live chunk to a new overflow page and redirects its single reference, then converts the damaged page to an ordinary page. No ordinary tuple moves, so RecordIds, indexes, UNIQUE references and version chains are unchanged.

  - Each heap is replaced atomically, the integrity check runs afterwards, and the originals are restored on failure.

  - Not WAL-logged: take a new base backup and re-initialise standbys afterwards.

- Tests: end-to-end regressions for the live and released chains (both fail on 0.2-I), plus storage tests for the probe guard, detection, every repair path and refusal.

- Unchanged: page, RID, index, WAL, catalog, status, protocol, replication and PITR formats; recovery rules; query semantics. No migration. Design: `docs/overflow_safety_0_2_i_1.md`.



## 0.2-I.2 â€” Replication / PITR restart safety hotfix



- Fix (present in 0.2-I and 0.2-I.1): every *full* checkpoint replaced the active WAL with a single anchor and deleted all sealed segments, ignoring replication slots. Full checkpoints run at clean shutdown, `CHECKPOINT`, online backup, crash recovery and anchor upgrades. Only the incremental checkpoint honoured slots.

  - A standby that had not replayed WAL before a primary restart lost those transactions.

  - Building a delta then accepted any later format anchor as a "bridge" over the missing LSNs. Replay reported success while committed transactions were missing; the standby's `check` failed with "index references missing tuple".

  - The same bridge made PITR past a restart silently omit pre-restart transactions.

- Retention invariant: a full checkpoint never discards a WAL transaction record after the oldest slot LSN (the slot's replay position). An active file holding only anchors after the slot may be discarded; readers prove such a gap harmless.

  - Such records are moved, unchanged and never rewritten, into `phobos.wal-retained/`. The active file is kept as a hard link (copy fallback); its zero tail is trimmed after the replacement.

  - Files there are named `phobos.wal.<first LSN>.<last LSN>.seg` (`.recovered.seg` for a crash-recovery active file).

  - Readers scan retained files strictly and check the recorded last LSN. Only a crash-recovery file may end torn or inside a dead transaction.

  - Local recovery, segment scanning and backups never read this directory.

  - Files are pruned at checkpoints once every slot has replayed past them, or when no slot remains.

  - Without slots nothing is retained, so behaviour equals 0.2-I.1.

- Delivery invariant: deltas (receive and PITR) must contain every LSN after the consumer's replayed position, and fail closed otherwise.

  - The only gap accepted is one proven to hold no transaction: the following anchor carries the consumer's exact transaction cursor, because WAL transaction IDs are allocated in LSN order.

  - Records of a transaction left incomplete by a crash become neutral checkpoint records in the delta.

  - Receive reads the retained history plus the live WAL.

  - A standby's `next_txn_id` now stays at its replayed position (receive no longer advances it), which fixes a failure when receiving twice before replaying.

  - A stale temporary delta no longer blocks later receives.

- The slot file is replaced atomically and is never missing: 0.2-I.1 removed it before the rename. An unreadable slot file makes checkpoints retain everything instead of failing.

- Operators: 0.2-I.2 cannot detect losses that already happened under 0.2-I or 0.2-I.1. Rebuild standbys and re-take PITR bases that crossed a primary restart or checkpoint before replay. Use 0.2-I.2 tooling for 0.2-I.2 archives. See the design note.

- `wal-archive` also copies the retained history. New `phobos-admin` commands:

  - `wal-retain PRIMARY ONLINE_BACKUP SLOT` registers a slot at a base backup's end LSN, so PITR can cross restarts.

  - `replication-slot-drop PRIMARY SLOT` is the explicit release.

  - `replication-status PRIMARY [STANDBY]` shows slots, protected LSNs, pinned bytes, retained history and standby positions.

- Tests:

  - WAL retention unit tests: no slot; slot advance and drop; sealed segments; crash recovery with a dead transaction.

  - Admin end-to-end: lagging standby across two restarts; PITR across two restarts; dropped-slot gaps refused.

- Unchanged:

  - Page, RID, index and WAL record formats, and wire formats.

  - The slot and standby state file formats.

  - Recovery rules and SQL.

  - No migration is needed. A retained file is an ordinary V2 segment.

- Known limits: retention is unbounded while a slot lags (observable with `replication-status`; drop the slot to release). Design: `docs/replication_retention_0_2_i_2.md`.



## 0.2-I.3: Interrupted WAL rotation recovery hotfix



- Fix (present in 0.2-I through 0.2-I.2): a crash between the two renames of a WAL segment rotation left sealed V2 segments and no `phobos.wal`. Open paths judged the format by `phobos.wal` alone and never reached WAL recovery's existing `repair_interrupted_rotation`.

  - MVCC databases were routed to the legacy engine and failed with "heap tuple capability mismatch".

  - Page-LSN databases took the V1 WAL path, which created an empty V1 `phobos.wal` and `phobos.wal.gen` beside the V2 history.

- New `phobos_wal::v2::interrupted_rotation(dir)`: a well-named sealed segment, plus no active file or an unfinished one (never a V1-headed file).

  - `MvccDatabase::is_capable`, `Database::open` (and `open_v2_config`), `phobos-admin check` and the migration preflight route such directories to V2/MVCC recovery.

  - The format is decided by the validated sealed history; any validation error fails the open closed.

- The repair stays in WAL recovery.

- An empty or torn `phobos.wal` next to `phobos.wal.gen` with sealed segments is refused as ambiguous, with no change on disk and an operator diagnostic. This is the residue of an older binary's V1 fallback, or of a pre-0.2-E crash.

- Tests:

  - end-to-end MVCC and page-LSN recovery through `Coordinator::open`;

  - read-only `check`;

  - damaged history, junk names and the ambiguous residue fail closed with no side effects;

  - V1 detection unchanged;

  - the helper unit test.

- Unchanged: all formats, normal open paths, 0.2-I.2 retention, 0.2-I.1 overflow safety. No migration. Design: `docs/rotation_recovery_0_2_i_3.md`.



## 0.2-K: Storage Lifecycle V1



- Fix: constant-cardinality churn no longer grows the heap without bound. Up to 0.2-I.3, every committed INSERT and UPDATE consumed one 4-byte slot-directory entry forever (about 4.1 B of permanent heap growth per change).

- Two-phase slot lifecycle on ordinary versioned heap pages, encoded in the existing slot entry:

  - Slot states: OCCUPIED; RETIRED (`len 0`, stale offset, identical to every earlier tombstone); FREE (`len 0`, offset 0); VACANT (beyond `slot_count`).

  - Phase 1, LIVE â†’ RETIRED: unchanged reclaim semantics, with the exact `(key, RID)` index entries removed in the same publication.

  - Phase 2, RETIRED â†’ FREE: only once the reclamation horizon has passed the retiring publication's sequence (`horizon > retired_at`, proven in `docs/storage_lifecycle_0_2_k.md`).

  - The allocator reuses the lowest FREE slot before extending the directory, and never reuses a RETIRED one. Bulk/COPY uses the same rule.

  - Trailing FREE entries are trimmed. A page whose slots are all FREE is reset to a fresh page.

  - New page flag bit `0b100` is a FREE-slot hint.

- Defence in depth (Part H): every index-originated RID dereference re-validates the key and logical identity. This covers indexed SELECT (streaming and materialized), indexed UPDATE/DELETE, the UNIQUE recheck, the bulk UNIQUE merge and writes through `SessionWrites::change`. A stale reference is skipped and counted (`mvcc.stale_rid_skipped`).

- Integrity: a `previous` pointer may now name the true predecessor, an empty slot, or a later occupant (reuse). Any other target is still reported as corruption.

- Automatic, bounded, event-driven reclamation: one `phobos-reclaim` worker per database, started by the server.

  - It is not started on physical standbys, and `PHOBOS_AUTO_RECLAIM=0` disables it.

  - Budgets: 128 pages and 8,192 versions per pass; 50 % duty cycle, with pauses capped at 50 ms.

  - A page is rewritten only once it is worth it: â‰¥ 4 new dead versions, or 10 s waited.

  - Fairness: round-robin across tables, rotation within a table, horizon-blocked pages skipped.

  - Metrics in `reclaim_metrics()`, `phobos_metrics` (`reclaim_*`) and `phobos-admin storage-lifecycle DATA [ROW_BYTES]`.

- Fix (present through 0.2-I.3): a reclaim pass could forget a candidate page that a concurrent publication had just re-recorded, delaying that page's reclamation until restart. Candidates now carry a generation.

- Reclaim index pruning:

  - a cursor descent replaces the per-entry whole-tree DFS;

  - sorted batch pruning continues along duplicate runs, descends zero-copy and removes leaf entries in place (byte-identical to the decoded path);

  - duplicate-heavy reclaim went from 196 to 29,271 versions/s on the same machine;

  - reclaim planning decodes full rows only for reclaimed versions.

- Status file: the frozen prefix of `phobos.mvcc-status` is released physically. It is rewritten sparse and atomically renamed (Unix), with no format change. Under sustained load without idle moments the logical freeze does not advance; that remainder is documented and deferred.

- Unchanged:

  - RID, index, WAL record, status, watermark and replication formats.

  - Page format version (3).

  - SQL.

- No migration is needed. Older binaries read FREE entries as tombstones. Existing tombstones are found by the post-open header scan and freed lazily.

- Design: `docs/storage_lifecycle_0_2_k.md`.



## 0.2-K.1: Performance recovery, reclaim resilience, Secondary Access Path V2



- Reclaim resilience:

  - A panic or poisoned bookkeeping in storage maintenance now sets an explicit maintenance fault.

  - Reclaim and CHECKPOINT then return an actionable `Recovery` error. Reads and writes continue, the worker stops, and `storage-lifecycle` reports the fault.

  - Restart resumes maintenance. `retired_at` bookkeeping is never guessed.

- Secondary access:

  - The default `page_cache_bytes` is 256 MiB (was 64 MiB), so a 1M-row working set stays resident. A 1 % range of 1M rows went from 48.6 ms to 16.0-16.8 ms on the same harness.

  - A page-grouped batch fetch was measured slower and is not shipped.

- Bulk: investigated; no change. On a fresh load the 0.2-K first-fit page choice resolves to the tail page. Same-harness 100K/1M loads are equal to 0.2-I.3.

- `tools/k1-validation`: a Windows-ready quick validation harness and scripts (BULK A/B, worker on/off, secondary, Standard suite wrapper).

- Unchanged: all on-disk formats, the slot lifecycle rules, worker pacing, and the durability and correctness checks.



## 0.2-K.2 - Windows bulk diagnostics and reclaim publication cost



- Automatic reclamation batches its publications: a non-catch-up pass runs at most once per 100 ms (`PHOBOS_AUTO_RECLAIM_MIN_INTERVAL_MS`) and takes up to 512 eligible pages, and a due pass first waits up to 1 s (`PHOBOS_AUTO_RECLAIM_YIELD_MS`) for a gap in the foreground commit pipeline. Horizon gating, two-phase RETIRED/FREE, fault handling and crash safety are unchanged.

- `tools/k2-validation`: Windows bundle with same-harness 0.2-I A/B (`build.ps1 -Baseline`), per-phase BULK profile (`bulk-profile.ps1`), BULK A/B, quick worker ON/OFF A/B with gap verdicts, and full OLTP error records (`oltp-errors.ps1`). The harness reports engine heap/index pages and bytes instead of on-disk sizes taken before the background flush.



## 0.2-K.3 - Lower reclaim cost (format-neutral part)



- Deferred heap compaction: reclamation no longer repacks a page when it retires or frees slots. Space of dropped tuples stays in place and counts as usable free space; an insertion that needs it repacks the page first (`heap.compactions`). Slot identifiers, RETIRED/FREE semantics, horizon gating and the on-disk format are unchanged.

- Leaf-grouped exact index pruning: reclaim deletions that fall in the same leaf are removed with one page rewrite instead of one per entry.

- Reclaim prepare reports heap and index time separately (`mvcc.reclaim_heap`, `mvcc.reclaim_index`).

- `tools/k3-validation`: quick worker ON/OFF A/B with PASS/MISS, reclaim microbenchmark, write-locality and index-boundedness tests; `-Baseline` builds the same harness against 0.2-K.2.



## 0.2-K.4 - Lazy Index Pruning V1 + compatibility capability



- New persistent catalog capability `LAZY_INDEX_PRUNING_V1` (catalog format version 3 = version 2 + capability bitmask). It is enabled by a WAL-logged schema publication, at writable-primary open when a non-unique index exists, or before the first lazy reclaim pass. Binaries before 0.2-K.4 refuse such databases ("unsupported catalog format"); unknown capability bits are refused explicitly. `PHOBOS_LAZY_INDEX=0` keeps the database old-compatible with eager pruning.

- Under the capability, reclaim no longer deletes non-unique index entries inside its serialized publication. Stale entries are harmless (every index read revalidates RID lifecycle, key and visibility) and are removed by a budgeted round-robin sweeper (stale ratio target ~10 %, `PHOBOS_LAZY_SWEEP_ENTRIES`, `PHOBOS_LAZY_SWEEP_DIVISOR`) that re-checks each candidate in serialized preparation and rewrites each leaf once. UNIQUE indexes remain eager.

- Online `CHECK` and `phobos-admin check` classify index entries as live / stale / corrupt and report `index_live_entries`, `index_stale_entries`, `index_corrupt_entries`, `stale_ratio`; stale entries are legal only for non-unique indexes under the capability.

- Reclaim metrics: `lazy_stale_created`, `eager_index_deletions`, `sweep_entries_inspected`, `sweep_stale_found`, `sweep_stale_pruned`, `sweep_cycles`, `sweep_passes`. New worker override `PHOBOS_AUTO_RECLAIM_MIN_VERSIONS`.

- `tools/k4-validation`: quick-ab, reclaim-micro, lazy-index-correctness, index-boundedness, sweeper-catchup, integrity-check, standard.



## 0.2-K.5 â€” experimental Reclaim Publication V2 / Write Locality Recovery



Prepared lifecycle patches avoid ordinary private-page scratch spill and move safe slot preparation outside commit order. Ordinary versioned allocation favors transaction-dirty pages, the recent frontier and sufficiently dense reusable capacity. WAL/page formats, eager UNIQUE cleanup and K.4 lazy non-unique policy remain unchanged.



Windows quick A/B gaps: OLTP1 6.90% MISS, OLTP8 7.30% PASS, OLTP16 15.16% MISS. This is a continuation candidate, not an accepted performance milestone. See the root K.5 architecture report, validation bundle and handoff for exact evidence and the unresolved concurrent server boundedness test failure.

