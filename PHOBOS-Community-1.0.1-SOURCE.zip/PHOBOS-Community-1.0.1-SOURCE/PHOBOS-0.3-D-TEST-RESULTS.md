# PHOBOS 0.3-D test results

Qualification date: 2026-10-26. The final delivery gate checks the successful logs listed below; `finalize.py` checks them before producing source/hash deliverables. Windows x64 is the only native platform qualified in this milestone.

## Automated/live results

- `release-check.log`: PASS COMPLETE against fresh isolated data using accepted engine binaries. Authentication, all wire types, Unicode, exact decimal, NULL/empty distinction, DML, transaction rollback, CTE/JOIN/subquery pass-through, catalog, 5K rows, SQL error poisoning, wrong credentials, budget abort, out-of-band cancellation, killed fixture server/recovery, open/save, profiles, malformed headers, GUI evidence and final offline integrity passed.
- New ProductTests: independent transaction visibility, closing/reconnecting one session without affecting the other, quoted/comment script boundaries, unsupported boundary preflight, mixed DDL/DML/transaction/multiple results, stop-on-middle-error with earlier autocommit retained, focused metadata after other-session DDL, 50K progressive rows, independent cancellation, row/memory budgets, CSV/typed JSON exactness and formula mode, profile CRUD/corruption backup, and layout recovery/bounds passed.
- `protocol-faults.log`: malformed sequence/count/value/Boolean/trailing bytes/totals/truncation/duplicate-start rejection; future API SQL fallback; valid prefix before malformed later batch; concurrent catalog change detected before publication; and untrusted TLS rejection passed.
- `screenshots/gui-evidence.log`: actual Avalonia connection/catalog/editor/result UI, selected SQL, unsaved-close Cancel, separate GUI transactions/results, multiple result tabs, streaming 50K grid, execution in another tab during a paused stream, prior completed results after error, explicit reconnect, partial-budget Incomplete label, completed result preserved on later script budget stop, profile/export/completion dialogs, routed F5/Ctrl+Enter, and light/dark/system passed.
- `windows-integration.log`: accepted 0.3-B fixture installation, HKLM discovery, SCM status, Studio helper Stop/Start/Restart, explicit authenticated reconnect/data preservation, unknown-key rejection and uninstall cleanup passed. Dedicated 0.3-D service registration/server binaries were removed; test data remains at `C:\ProgramData\PHOBOS-03D-Validation`. The service adapter itself is byte-identical to 0.3-C.
- `package-test.log`: PASS final standalone installer install, self-contained launch/title, ordinary close, and uninstall. The server is not bundled or modified.
- `dependency-audit.log`: NuGet reported no known vulnerable packages in configured sources. Initial sandboxed restore could not fetch audit metadata; the subsequent network-enabled audit completed successfully.

- `packaged-core.log`: the exact delivered Core DLL is copied with hash verification into the test runner; live integration and fault tests are rerun against those bytes. Finalization requires its PASS marker.

## Measurements and usability

The recorded release-check Core run delivered 50,000 two-column rows in 67 ms, including a deliberate 30 ms first-batch callback delay. Its retained-memory estimate was 16,365,752 bytes. Export of those displayed rows to a 1,377,793-byte CSV took 110 ms. These are one-run local client/fixture measurements, not an engine benchmark or performance guarantee. The GUI adds formatting, observable collections, rendering and a deliberate evidence pause/screenshot; it is not comparable to raw Core timing.

5K and 50K results passed. Progressive UI rows were visually inspected before completion; the grid remains virtualized. Separate-tab operations, completion, export dialogs and theme changes were exercised. No database-engine benchmark was rerun: engine source and binaries are unchanged, and no engine speed claim is made.

Actual Windows window RenderScaling was 1.0. Rendered captures at 1.0, 1.25, 1.5 and 2.0 check raster layout; they do not qualify actual Windows monitor DPI transitions. Main controls, results, explorer and dialogs were visually reviewed. Wrapping result/toolbar controls avoids fixed horizontal overflow. No formal accessibility certification is claimed. Screen-reader, physical keyboard-only navigation, per-monitor transitions and every dialog at every OS scale remain unqualified.

## Limitations / skipped qualification

No usable Linux desktop/WSL/Docker or macOS environment was available. No Linux/macOS artifact was produced. Trusted PHOBOS TLS/certificate display and isolated hostname-mismatch fixture were not configured; only untrusted TLS rejection was exercised. Custom CA/mTLS, real certificate signing, credential-vault integration, log viewer and systemd/launchd are deferred. Export serialization and its dialog were tested; native file-picker automation and spreadsheet-specific import behavior are not exhaustive.

Catalog consistency is two matching read passes, not an atomic revisioned server snapshot. Rapid/ABA DDL can still race between public API queries; the UI publishes only a stable observed set and documents refresh semantics. Tests include deterministic changing metadata rejection, not a distributed schema-churn stress certification.

Early development checks caught and fixed missing built-in SQL highlighting, transparent theme backgrounds in render capture, and completed-result relabelling at a later script budget boundary. Final evidence uses the corrected source. Older exploratory logs are retained in the workspace but are not presented as final passing evidence.
