# C6 — finer transaction / lock coordination design

Status: C6 acceptance complete; frozen with explicit performance qualifications.
The C5 audit and original proposed sequence below were written before edits.
The following implementation record supersedes proposed behavior where stated.
Baseline: frozen C5 source SHA256
`5fdd685955ac1b92906898d390617ec6e0874402cdb3133490a711c45f18ebe9`.
C6 works only in `work/write-v3/c6/phobos`. C5 source, delivery, 193-test evidence,
measurements and 18 qualified budget exceptions remain immutable. No C7/C8,
physical VACUUM, SQL extensions or on-disk changes are proposed.

## Implemented architecture and remaining ordering

Logical SQL resolution uses one connection context and stable MVCC identity. Row
and unique ownership have separate mutex/condition-variable domains. Wait-die
victims, two-second timeouts and cancellation discard all unsubmitted writes and
leases before persisting abort; the SQL connection remains failed until rollback.
NULL unique keys remain nonexclusive. Rechecks use fresh physical readers and the
latest committed validation frontier after waking. Index key size is validated
before ownership/admission using the same physical index contract, including
non-unique indexes; an oversized key cannot become an irrevocable commit failure.

Reader construction clones an immutable schema/heap/index registration directory.
It does not take the mutable database directory. Session bookkeeping and status
I/O have separate mutexes; terminal status cache hits bypass status I/O but inspect
the shared persistence-failure flag. Successful status persistence precedes ordered
snapshot-frontier advancement. The existing stable-ID/WAL-chain mapping is intact.

Physical ownership is moved, not shared: under the short database directory guard,
`take_domain` removes the selected tables' heaps and all their indexes into an owned
temporary Database. The ordered driver validates stable write/permit identity and
partitions its at-most-64 requests into contiguous waves of at most eight disjoint
table domains. Each worker owns every mutable file handle in its domain while
encoding, rebasing, splitting and spilling private pages. All workers join and
return handles before WAL staging. Readers retain immutable registered read handles;
they never borrow these mutable owners. Duplicate/missing owners fail and fence.
The write lease and commit permit outlive preparation, WAL and publication. Errors
after admission fence; unwinding cannot acknowledge or silently abort accepted work.

Same-table operations end a wave even for disjoint logical rows. This intentional
physical dependency preserves allocation, index-root and whole-page predecessor
state. Each predecessor is staged before the next preparation reads its pending
image. Heap installation precedes its index installation; status/frontier publication
then precedes conflict release and successful COMMIT completion. Deterministic tests
prove both 2/4/8 disjoint-file simultaneous preparation and the same-file sequence
prepare -> staged redo -> next prepare, followed by ordered publication/reopen.
Disjoint-row SQL resolution can overlap even on the same heap page.

One commit driver remains. The waves parallelize physical preparation *within an
admitted cohort*, not across an in-flight WAL force or publication. SQL execution,
snapshot creation and unrelated readers continue independently. The original proposal
for speculative preparation across force was not implemented: whole-page pending
chains, allocation and receipt ordering would require a second generation/reservation
protocol. No second unsafe commit path was introduced. This limitation must be
reported and measured; cohort parallelism is not a claim of independent publication.

WAL ownership covers begin/append/page stamping and complete-batch C1 force. Private
page reads/writeback and schema chunk reads occur outside it. Publication also takes
physical owners out of the database directory; it retains the ordered driver while
installing, publishing visibility and cleaning private files. Conservative exclusive
DDL retains the database guard across its schema/file operations. Checkpoint drains
retain their C4 ordering. These exceptions are intentional, not renamed fine locks.

Index readers copy a bounded batch against a per-index even/odd generation. A changed
generation discards the batch and any transient traversal error. A stable-generation
error propagates. After eight restarts, a per-index fair read reservation protects one
bounded batch; it never spans visibility/status evaluation or result delivery. Writers
mark the generation odd during physical installation and fence the epoch on failure.
The global index publication RW lock is removed from MVCC reads. Existing immutable
committed frames need no mutable page latch. Debug structural scopes reject transaction
status lookup under index publication/fair-batch protection. No new page-latch order
or on-disk representation was introduced.

TCP and TLS use one bounded frame reader, one pending complete request and one
executing request. Queue overflow/EOF closes the transport and signals cancellation
without taking the executing connection mutex. TLS has one protocol state; socket
reads/writes occur outside that state mutex, with ciphertext output ordering retained.
Cancellation before admission aborts private state. Atomic admission wins over later
disconnect: the driver finishes force/install/visibility even when no response can be
delivered. Tests cover row/key waits, prior ownership, idle explicit transactions,
and disconnect while admitted preparation is deliberately paused on both transports.

Diagnostics retain fixed row/key counters, eight-bin wait histograms and at most
1024 active waiter records per domain. Profiling is separate from normal timings:
at most 256 static span/event names, 32 logarithmic duration bins each, total/count
and cumulative maximum. Bin i has inclusive upper bound 2^i ns for i=0..30; final
bin is overflow. Snapshot differences provide workload histograms/quantiles; maxima
are explicitly cumulative, not subtractable. Events do not enter duration histograms.
Queue-acquire, commit-order-acquire, WAL-acquire, database-directory-acquire and index
epoch/fair/publication-acquire spans are distinct from inclusive commit/publication
work. Schema admission rejects conflicts immediately; it has no waiting policy.

Two additional durable crash hooks cover partial index publication and persisted
status before visibility frontier. Eight C6 cases retain repeated recovery and
offline integrity; the existing 24 runtime and three schema cases are unchanged.
Volatile owner extraction/wave scheduling adds no durable format or recovery stage.

## Existing C5 synchronization audit

The server's legacy `Coordinator.owner` is already bypassed by capability-4
execute/stream/disconnect/shutdown. Removing or renaming that mutex would do
nothing for MVCC. Legacy C1/C2 preparation/group logic stays intact.

| Domain | Actual C5 owner | Held across / implications |
|---|---|---|
| Server/session map | `MvccDatabase.connections` mutex | Lookup/create/remove; creation enters transaction registry. Removal can drop the last session and perform abort I/O under the map guard. |
| Individual SQL connection | `Arc<Mutex<Connection>>` | DML, conflict waits, explicit COMMIT queue/durability; readers release after constructing their statement. A disconnected waiter retains its Arc until the operation exits. |
| Admission/shutdown | admission `(closing, active)` mutex + condvar | Tracks active statements; shutdown waits for active sessions/pins, without retaining database storage. |
| Transaction/status/schema | `SessionManager.state` mutex | Contexts, active stable IDs, schema owner, status-file lookup/reservation/commit/abort forces. Couples read snapshot admission to status I/O. |
| Snapshot pins | separate registry mutex | Pin/frontier/horizon, nested below session registry. Statement terminal-cache mutex is also below session registry; cache hits retain fencing checks. |
| Logical row and unique keys | one `Ownership.owners` mutex + condvar | Canonical `Key::Row(table, logical)` and `Key::Unique(index, IndexKey)`; only older stable IDs wait (wait-die). Two-second fixed deadline; no cancellation token or bounded diagnostic wait graph. A victim error marks the SQL transaction failed but its locks survive until rollback/disconnect. |
| Schema/catalog | schema lease in session registry + private catalog | Conservative DDL exclusion against other active transactions or pins. `admit` currently reacquires catalog/readers after acquiring row ownership. |
| Database/storage directory | `MvccDatabase.database` mutex | All reader construction, heap/index physical preparation, redo binding, publication installation, checkpoint drains. File opens, scratch I/O, index traversal and status checks occur under this guard. |
| Commit driver | queue mutex/condvar, `running` flag, `commits` mutex | One leader handles up to 64 commits. `commits` spans preparation, WAL force, publication and checkpoint advance. Queued commits cannot prepare independently through this driver. |
| Heap/index mutable state | exclusive `&mut HeapTable/BPlusTree` under database guard | Buffer/free-space metadata, private/pending generations, index root/allocation/splits. Private images preserve old versions; final whole-page images depend on predecessor generation. |
| Index reader | database-wide publication RW lock per bounded batch | Reopens current tree and validates metadata/traversal. Drops guard before heap visibility/status checks and visitor/network delivery. The historical `index_publication_wait` span includes batch work. |
| Dirty frame directory | `CommittedStore::Inner.state` mutex | Owns immutable `Arc<[u8;8192]>` images, page/recLSN, generation and file registration. No mutable page latch currently exists. |
| Physical file cursor | registered-file I/O mutex | Cold read, writeback, force, handle retirement. C5 drops directory before file lock, then reacquires directory under file lock for revalidation. This is a cursor order, not a page-latch API; it must not be copied into a new page-latch hierarchy. |
| WAL | MVCC WAL mutex, exclusive mutable Wal | Redo binding currently happens while database and WAL are both locked. Complete pending batch validation/force yields opaque receipts. Force itself drops database guard, but retains commit-driver serialization. |
| Publication | database then publication write guard | Installs heap/index images, may evict/flush, persists status/frontier, removes scratch, releases conflicts. COMMIT response follows completion. |
| Checkpoint | commit order, database/store, WAL and status | Dirty recLSN frontier plus forced status authorize retirement; background WAL preparation owns copied paths, completion preserves complete chains. No format change needed. |
| TCP/TLS | one blocking session loop per connection | SQL runs on the socket-reading thread; EOF is ordinarily discovered after execution returns or a response write fails. Write timeout exists, but cannot wake a conflict waiter immediately. |

The complete frozen source manifest is the audit inventory. Synchronization-bearing
paths inspected include the full MVCC runtime modules, transaction/session/status
control, storage PageIo/private/pending lifecycle, immutable committed frames and
checkpoint worker, B+ tree descent/split/traversal, WAL append/force/retirement,
legacy group/disjoint preparation and server routing/session cleanup. Other crates
retain their established parser/catalog/codec/auth/protocol contracts; changes to
any called contract require updating this audit and corresponding regression tests.

## Proposed separation and incremental order

1. Establish canonical conflict APIs, independent cancellation state and bounded
   wait diagnostics. Keep wait-die across dynamically discovered statement sets;
   automatically discard unsubmitted victim/timeout/cancelled transaction writes
   before releasing all their resources. Preserve ordinary constraint-error SQL
   failed-transaction semantics. Deterministically prove two-row cycles and wakeup
   cleanup before changing physical coordination.
2. Publish immutable schema/read-handle directories. Acquire a schema handle
   before any conflict lock, clone registrations under the short catalog guard,
   construct/read/validate outside the global database guard. Reuse the same
   schema generation after waits; fresh page/status rechecks remain mandatory.
   DDL remains exclusive and cannot wait while holding transaction conflict locks.
3. Separate session context bookkeeping from durable status I/O. A terminal state
   becomes observable only at ordered publication; reserved IDs cannot escape
   before durable reservation. Preserve cache fencing and monotonically advancing
   snapshot/retirement frontiers. Do not introduce registry -> storage callbacks.
4. Move transaction-private resolution/encoding and private preparation out of
   the database/commit-leader guard. Use stable table/index handles and optimistic
   generation validation/restart for private trees. Whole-page redo cannot replace
   an unrelated newer row update: validate predecessor generations and rebase
   resolved logical changes (never reevaluate SQL) before sealing them for WAL.
   Structural reservations, allocation and split dependencies must be explicit;
   no long-lived global index mutex is an acceptable final substitute.
5. Submit owned sealed redo to the WAL owner. WAL assigns/stamps append-order
   identities and page LSNs without calling execution/storage while locked. Return
   stamped owned images/tickets; group force remains complete-batch C1 semantics.
   Publication keeps a narrow ordered frontier, not an execution-wide owner.
   A bounded pipeline permits useful independent preparation during force and
   unrelated storage work. Retain necessary same-page/split ordering, document it.
6. Complete structural/frame checks, ordinary TCP cancellation/disconnect handling,
   deterministic overlap/split/eviction tests and crash boundaries. Only after
   correctness passes run full C5 regressions and 100K/1M C6-vs-frozen-C5 evidence.

Steps 2–5 are not declared implemented merely by this plan. In particular, physical
parallel preparation, optimistic index restart and a narrower publisher must be
proved by barriers/observations; multiple mutex names are not proof of concurrency.
Any necessary temporary coarse fallback must be labelled and removed before freeze.

## Lock classes, order and forbidden waits

Acquire immutable schema/catalog handles first. Conflict resources are canonical:
`Row(table_id, logical_row_id)` or `Unique(index_id, typed canonical IndexKey)`.
NULL-containing unique keys do not participate in exclusive key ownership. Schema
handles are lifetime/version references, not catalog mutex guards retained during
transaction waits.

Structural order: catalog directory -> stable table/index ID -> page ID. Clone/pin
an immutable frame under its directory guard, release that guard, then latch the
page if mutable latches are introduced. Never reacquire that directory from under
the page latch. Immutable image readers need no mutable page latch. File-cursor
I/O ordering remains separately documented and must not be confused with page
latches; positional I/O or a separate serialized I/O owner can remove cursor order
where needed without changing the format.

Transaction status, conflict condition-variable waits, queue capacity, WAL/group
completion and network delivery MUST occur with no page or structural latch.
Debug/thread-local guard tracking should assert these boundaries. Structural
critical sections may read/copy validated owned page images; cold I/O should be
prepared outside latches and revalidated after reacquisition. Multiple pages are
acquired in increasing page ID or released and restarted; parent/child traversal
must validate generation/links rather than invert the ordering during splits.

Registry, row ownership, unique ownership, schema publication, frame directory and
WAL each have distinct state. No directory mutex is held while destroying a session,
waiting for another transaction, forcing a file or delivering a result. Connection
mutexes protect one connection only; cancellation must not acquire that mutex.

## Deadlock, timeout, cancellation and disconnect

Wait-die is the chosen deterministic policy: a younger stable transaction never
waits for an older owner; all wait edges point toward younger owners. A directed
cycle is therefore impossible even when later statements discover additional keys.
Key sorting is not the proof. On victim selection cancel/discard the entire
unsubmitted write set and release every row/key lease, then abort its status.
Record waiter, owner, resource, duration and victim reason in bounded diagnostics.
Use a finite configured deadline per wait, monotonic time and wake notifications.
Timeout/cancellation are distinguishable outcomes, never silent retry success.

Cancellation token lifetime is a connection/transaction generation; reset cannot
revive an earlier waiter or affect a subsequently reused session ID. Signalling
sets atomic state and wakes the relevant condvars without taking the executing
connection mutex. Waiters check cancellation before acquisition, after wakeup and
before the irreversible commit-admission transition. Drop alone is not enough.

Before commit admission, cancellation/timeout discards private state and aborts.
After a commit is accepted for WAL ownership it is irrevocable: disconnect or
cancellation cannot pretend to roll back a durable transaction. Finish publication
or fence/recover; callers may lose the response but must not receive a false abort.
Queue capacity must be checked before consuming an irrevocable CommitPermit.
Any pre-WAL cancellation of a submitted permit requires an explicit proven state
transition; dropping the current C5 permit would fence the database and is not a
valid cancellation implementation.

TCP must observe disconnect while execution waits, without concurrent consumers
corrupting TLS/framing. A transport reader/control arrangement must retain bounded
request buffering, one executing request per connection, existing authentication
and TLS guarantees, and wake cancellation on EOF. Do not use arbitrary sleep polls
to claim immediate cancellation. OS force calls cannot be cancelled safely; their
completion remains owned even when the transport has closed.

Conservative DDL can reject conflicts immediately (zero-wait policy), rather than
broadening DDL concurrency. Cancellation before schema acquisition must still be
checked and diagnosed. No schema wait may retain transaction conflict resources.

## WAL, publication, recovery invariants

- Stable MVCC identity mapping and capability 4 remain unchanged.
- No uncommitted private bytes enter committed visibility or eviction writeback.
- Every published page LSN is covered by its database/transaction durable receipt.
- Ordered publication advances status/snapshot frontier only after complete
  heap/index installation. No reader may traverse a partially installed split.
- Same-page writers rebase from the correct predecessor; append order, not begin
  order, determines whole-page redo and publication dependencies.
- No execution-layer callback under WAL ownership; transfer owned descriptors.
- Dirty memory, queued redo, active wait diagnostics and snapshot pins are bounded.
- Page/recLSN + forced visibility continue to bound incremental WAL retirement.
- Post-durability installation failure fences deterministically. Abandoning an
  accepted commit cannot release ownership as if it had aborted successfully.
- Old tuple/index references remain valid for pinned statements; no VACUUM here.
- Recovery reconciles mapping/statuses before WAL retirement and is repeatable.

Ownership grant/wait/victim/release before WAL affect only volatile coordination;
crash there must leave no committed private state. Prepare before COMMIT likewise
recovers as uncommitted. WAL-durable, partial publication and visibility-before-
retirement boundaries require explicit repeated recovery and offline integrity.
Existing 24 runtime + 3 schema cases remain; add only relevant C6 durable boundaries.

## Required evidence before freeze

Deterministic normal SQL tests must prove 2/4/8 disjoint-row overlap, both start
orders of a two-row cycle, commit/abort/UPDATE/NULL/composite unique races,
cancellation at row/key/schema/admission waits, timeout ownership cleanup, normal
TCP disconnect at held/waiting/commit states, and unrelated progress behind a
blocked writer. Force leaf/internal/root splits under insert/indexed UPDATE and
point/range/unique readers; retain paused stream snapshots and validate all physical
index references, page identities/checksums and offline integrity after reopen.
Exercise directory pinning against publication/eviction/flush. Use hooks/barriers,
not sleeps; bounded timeouts are failure bounds, not race orchestration.

Diagnostics: fixed-size counters/histograms plus bounded active waiter records;
acquisition/immediate/wait counts, row/key/schema/structural durations, maxima,
victims, timeouts and cancellation. Histogram quantiles must disclose resolution.
No unbounded event log, user keys in unrestricted logs or production timing changes.

Run fmt/check, strict all-feature/all-target Clippy, workspace tests, docs and
release/instrumented builds. Preserve all 193 C5 tests and only historical soak
ignores. Measure 100K/1M against saved C5 raw results (not a rewritten baseline),
including all 18 original exceptions under unchanged thresholds. Report committed
TPS separately from rejected attempts and investigate the 1M 8-vs-4 writer gap.
No PostgreSQL, 10M, long soak, C7 bulk loader or C8 batched indexes. Final report and
freeze require complete evidence; any unresolved significant item means NO freeze.
