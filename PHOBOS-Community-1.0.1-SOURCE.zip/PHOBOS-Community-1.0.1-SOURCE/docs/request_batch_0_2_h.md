# PHOBOS 0.2-H — Request path + Batch DML V2 (design)

Baseline: 0.2-G source `fd0fa3d188a2fa9fc987e4cf0365ac6c022102c00b1c9b9d6e680387f9ac76aa`.

Principle: remove work the client actually waits for. No WAL, page, catalog
or protocol format change; commit order, Stage-A exclusivity, ordered
receipts, the 0.2-G proofs and the 0.2-F fast paths are unchanged.

## 1. Request path (Parts A–H)

### 1.1 What 0.2-G did per request (plain TCP)

Each connection is a job on the worker pool: one worker thread owns the
connection for its lifetime. 0.2-G also spawned one *reader thread* per
connection (`Pumped`):

```
client ──frame──▶ reader thread: recv, parse frame ──sync_channel(1)──▶ worker: recv_timeout
                                                                          execute, commit
client ◀─────────────────────── response written by the worker ──────────┘
```

Why it existed: (1) observe EOF while a statement executes and cancel the
session's work (disconnect while waiting for a row lock, a commit, a long
query); (2) bound pipelining (one pending frame; a further frame closed the
connection); (3) TLS: one rustls state shared by reader and writer; (4)
Windows: a shutdown on a cloned socket may not wake a blocked `recv`, hence
100 ms receive timeouts and a `closed` flag.

Cost per request: the reader wakes on the data, parses, enqueues and wakes
the worker — two thread wake-ups and two context switches instead of one, a
cross-CPU hand-off (on the 2-vCPU Linux VM ~1.4–1.9 CPU migrations per
request) and the channel/futex work (≈ 12 % of server CPU for autocommit,
≈ 34 % for an indexed point SELECT, `perf`).

### 1.2 0.2-H: `Direct` transport (plain TCP, default)

```
client ──frame──▶ worker: recv (16 KiB buffer; header + payload normally one recv)
                  execute, commit, respond (same thread)
monitor thread (per connection): wakes every 100 ms; only while a statement
                  has been executing ≥ 100 ms it peeks the socket (never
                  consuming bytes); EOF/error → coordinator.cancel(session)
```

* Requests that qualify: every request of a plain TCP connection (Hello,
  Auth, Ping, Query, QueryStream, Bulk, Cancel, Metrics …). The connection
  already has a dedicated worker, so direct execution cannot let one
  connection monopolise another's worker: fairness is unchanged (each
  connection is served by its own thread; engine-level ordering — commit
  queue, wait-die ownership — is untouched).
* Fallback (the 0.2-G `Pumped` transport): TLS connections (rustls buffers
  plaintext the raw socket cannot see), and every connection when
  `PHOBOS_REQUEST_PATH=pumped`.
* Cancellation semantics kept: cancel-by-handle comes from another
  connection (unchanged); statement deadlines live in the statement context
  (unchanged); disconnect during a long statement or a wait is detected by
  the monitor within ~100–200 ms (the reader thread detected it at once — a
  statement that finishes within 100 ms simply completes and its response
  write fails, which is indistinguishable for the client from a disconnect
  right after completion); a terminal read error cancels the session like
  the reader thread did; a connection that was abandoned while queued
  (request sent, then closed, before any worker took it) is not executed
  (one non-blocking peek, first request of a connection only).
* Idle deadline, partial frames: the deadline applies to the wait for a
  complete frame (as before); bytes already received survive receive
  timeouts; a malformed header fails immediately without waiting for a
  payload; oversized lengths are rejected before allocation (`Frame`).
* Pipelining: frames are read sequentially by the worker; nothing beyond the
  kernel socket buffer and a 16 KiB buffer is retained, so the 0.2-G
  "third pipelined frame closes the connection" limit (a consequence of the
  one-slot channel) no longer applies. Protocol bytes are unchanged.
* Shutdown: `shutdown(Both)` on the registered socket ends a blocked or the
  next `recv` (100 ms receive timeout + `closed` flag on Windows, as before).
* Response path: already one contiguous buffer and one `send` per small
  response (0.2-B); unchanged.
* Statement registry: statements without a client-requested cancel handle
  get an internal handle from a per-connection OS-random base and a counter
  (no `getrandom` call and no 32 small allocations per statement); handles
  disclosed through `CancelHandle` still come from the OS RNG.

### 1.3 Cancellation and disconnect matrix (Part F)

| moment | 0.2-G (reader thread) | 0.2-H Direct |
|---|---|---|
| cancel by handle before the statement starts | registry miss → no-op | unchanged (registry code shared) |
| connection queued for a worker, then closed | reader starts with the worker; EOF before the frame → nothing executes | first-request non-blocking peek: EOF/reset → nothing executes |
| cancel by handle during execution | statement context flag | unchanged |
| disconnect during execution / row-lock wait | reader sees EOF at once → `coordinator.cancel` | monitor sees EOF within 100–200 ms once the statement has run ≥ 100 ms → `coordinator.cancel` + socket shutdown |
| disconnect while waiting for commit order | admitted transactions complete, held ones abort | same (tests `h_direct_disconnect_*`, `c6_*`) |
| disconnect during WAL force | irrevocable; outcome is the commit's true outcome | same |
| disconnect while the response is written | write error closes the connection | same |
| statement deadline / idle deadline | statement context / reader timeout | statement context / `fill` deadline over the whole frame |

### 1.4 Shutdown

Server shutdown shuts every registered socket down (unchanged): a worker
blocked in `recv` returns (on Windows within one 100 ms receive timeout, via
the `closed` flag) and the connection ends after the current request. The
monitor is stopped, unparked and joined in `Direct::drop`.

## 2. Batch DML V2 (Parts I–O)

### 2.1 Encoded keys (Part I/J)

The V3 index key encoding is memcomparable: `encode(a).cmp(encode(b)) ==
IndexKey::cmp(a, b)` (property test over every declared key type, signed
boundaries, text with NUL bytes and prefixes, NULL, composite and mixed
types, equal keys, min/max). MVCC index maintenance (`insert_versions_batch`)
encodes each key once into one arena and carries the encoded bytes through
sort, leaf grouping, the exact-entry probe and the leaf merge
(`EncodedIndexMutation` = `(arena span, RecordId)`; the operation is insert —
deletes keep their existing per-key path).

### 2.2 Leaf merge (Parts M/N/O)

For consecutive sorted keys that fall into one leaf (keys ≤ the tightest
separator ≥ the first key on the descent path), the leaf's existing encoded
entries and the incoming ones are merged in one pass into a new page image
(same header rules as `encode_node`), one checksum, one private write.
Validated internal pages are reused within the batch (descent prefix reuse)
and dropped whenever a structural change may have happened; nothing is
cached across batches or publications. Committed-store images are read
shared and trusted (validated once on store entry, 0.2-F); private and
pending images are fully validated.

A key takes the typed 0.2-G path (`insert_cached_entry`, which may split) when
it would overflow the leaf, when it equals the fence (a duplicate chain may
continue in the next leaf), or when a page has a legacy format. The merged
prefix is written first, so the split happens at exactly the entry where the
typed path would have split. Result: byte-identical index files to the 0.2-G
typed batch path (test over 11 scenarios: one leaf, adjacent/many leaves,
one/repeated/internal/root splits, sorted/reverse/random input, duplicate
keys and repeated exact entries, composite keys, interleaved deletes).

### 2.3 Admission and UNIQUE (Parts K/L)

Incoming duplicate detection was already hash-indexed per statement
(`StatementOwn::keys`, O(1) per row). 0.2-H removes the per-row cost around
it: each index key of the new row is built once and reused for validation,
key ownership and the recheck (it was built three times, plus an encoding
for the length check, now computed without allocating); the statement keeps
each earlier row's logical UNIQUE keys instead of a clone of the whole row
change; the table schema is shared, not cloned per row. The committed-state
UNIQUE probe and the final recheck are unchanged (authority unchanged).
Batched committed-tree probing (Part L) was evaluated and deferred: probes
must follow key ownership row by row (wait-die), and the 0.2-F navigation
cache already reuses the descent.

## 3. Heap mutation fast path (Parts P–R)

While a heap is private (MVCC preparation), its buffer frames hold this
generation's own page copies. `BufferPool::modify_page` runs the insert on the
frame in place: no 8 KiB copy out and back, no checksum refresh per row. The
frame becomes *dirty-unverified* (`sealed = false`); every path that hands
the bytes out — a reader's copy, the write to the private file, eviction —
seals first (one checksum per page), so no stale checksum is ever stamped,
logged, validated or published; `VerifiedImage`/stamp-token proofs are only
created from sealed private images later, exactly as before. Committed
images (`Arc`) are never mutated: the frame copy was loaded (and fully
validated) from the private/pending/committed image. The borrow cannot leave
the closure; dirty marking happens once. `PHOBOS_HEAP_IN_PLACE=0` restores
the 0.2-G sequence.

Page states (Part R):

| state | frame | checksum | may be exposed |
|---|---|---|---|
| clean | `sealed = true`, `dirty = false` | valid | yes |
| dirty-unverified | `sealed = false`, `dirty = true` | stale | no — every exit path seals first |
| sealed dirty | `sealed = true`, `dirty = true` | valid | yes (reader copy, private file write) |
| stamped / published | not a buffer frame: the WAL stamps the LSN into the sealed private image (stamp token) and the store receives it with `VerifiedImage` / `ProducedInProcess` | valid, new LSN | committed `Arc`, immutable |

All mutation happens during statement execution of the owning transaction,
before Stage A. Stamp tokens and `VerifiedImage` proofs are created at
Stage A / installation from the sealed image, i.e. strictly after the last
mutation; a transaction cannot execute DML after its commit started, so no
proof can describe bytes that are later mutated. The shared-cache (committed
reader) buffer pools never take the in-place path (`uses_shared_cache()`).

## 4. Slow-request trace (Parts U/V)

`PHOBOS_SLOW_REQUEST_US=n` (inert otherwise): per request the existing spans
of the serving thread (statement view, UNIQUE probe, commit-order wait,
Stage A, WAL append, WAL force wait, write-through write, publication turn
and hold, extent wait, checkpoint drain, socket write) are accumulated
thread-locally; a request ≥ n µs appends one CSV line (plus hand-off time,
background extent/checkpoint overlap, worker thread name, Linux run-queue
delay with `PHOBOS_SLOW_REQUEST_SCHED=1`, unaccounted remainder) to
`PHOBOS_SLOW_REQUEST_LOG`. `tools/tail-latency-summary.py` groups causes.

## 5. Not done (DEFER)

PreparedWritePlan (0.2-G analysis unchanged; the new profile shows no
commit-order contention bottleneck), batched committed-tree UNIQUE probing,
heap page batching beyond in-place mutation, parser allocation work.
