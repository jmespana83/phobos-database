# C5 implementation progress — not certified or frozen

Latest heap/capability/migration/session/RAII progress and remaining SQL work:
`write_concurrency_v3_c5_heap_sessions.md`. It supersedes the historical component
and identity-alternative descriptions below. C5 remains incomplete and disabled
on the SQL/server route; no C5 freeze or full Fast marker is claimed.

Follow-on identity implementation is described in `write_concurrency_v3_c5_identity.md`.
It implements stable reservations, WAL mappings, a retained capability gate, and
visibility recovery/retirement barriers. The foundation details below are historical;
the identity design alternatives below are superseded by that implemented mapping.
SQL/session MVCC remains incomplete and disabled.

C4 is user-approved and remains frozen. This isolated C5 source starts from
`phobos-c4-source.zip`, SHA256
`2ad9ba3ddf3463e3fdb0d15375b91b473ec41c5224bf0a518f789c9f8f95a49d`.

**This is an incomplete component implementation, not an MVCC database release.**
No SQL/session path uses these components. Ordinary readers still follow C4's
strict owner/lease path. No existing database has been migrated. No C5 freeze or
Fast-performance acceptance marker is warranted.

## Implemented components

- `phobos-txn::mvcc::StatusFile`: explicit `PHMS` version-1 header and checksummed
  32-byte, transaction-addressed records in `phobos.mvcc-status`. Capacity is fixed
  by the creator; memory use does not grow with historical transaction count.
  Committed records carry their COMMIT WAL LSN. Aborts are explicit records; an
  absent/zero slot is unknown and lookup fails, never infers an abort.
- Durable installation requires the existing opaque WAL receipt, matching
  canonical database directory, and advancing commit order. This provisional
  implementation forces each status before returning. An I/O failure during
  installation fences the store; it cannot be used to claim a successful abort.
- Recovery preflights and forces the WAL, derives final statuses from validated
  BEGIN/COMMIT history, forces the status file, and validates stored records.
  It must precede WAL recovery/checkpoint retirement. Repeated recovery repairs
  retained-WAL status tears and preserves historical statuses after full retirement.
  Corrupt records fail; missing historical records fail at lookup. Heap integrity
  integration must eagerly check every tuple's referenced status before admission.
- `TransactionRegistry`: bounded active IDs over disk lookup, rejection of ID reuse,
  admission checks for both active-memory and status-file capacity, explicit abort
  persistence, and durable-commit status transitions. No historical in-memory map.
- Statement snapshots capture a published sequence and optional own transaction.
  Visibility distinguishes in-progress, committed-before/after-snapshot, own and
  aborted creators/deleters. Unknown status fails closed. Pins constrain a safe
  deletion horizon; admission bounds retained statement metadata. Foreign pins
  cannot remove another registry's pin. Physical reclamation is not implemented.
- `phobos-storage::tuple_version::TupleVersion`: explicit `PHMV` version-1,
  48-byte envelope with stable table-local logical row ID, creator/deleter IDs,
  optional previous physical version RID, and payload length. SQL/public RowCodec
  bytes are unchanged. Unknown versions/flags, malformed envelopes and oversized
  tuples are rejected. **Existing heap pages do not accept these envelopes.**

## Integration decisions still required

The current status component uses WAL transaction IDs. The WAL scanner requires
increasing, non-interleaved transaction chains. Independent sessions can begin in
one order and commit in another; merely assigning their BEGIN IDs to WAL chains
will fail or impose new serialization. Resolve this explicitly before integration:
either a WAL-protected mapping from stable MVCC identity to append-order identity,
or a rigorously scoped private-ID finalization scheme. Recovery, private tuple
references, aborts and unique/conflict locks must agree on that identity.

Production MVCC needs an explicit heap/WAL capability old binaries reject before
modification, plus backup-first offline migration. The standalone envelope/status
codec versions do not provide that database capability. No reserved V2 page bytes
have been repurposed. The current status recovery/retirement ordering exists only
in component tests; database open, backup/integrity, and C4 checkpoint paths are
not yet wired to it. Status forces should be batched or moved to a bounded,
WAL-protected status-page cache before performance claims; C1 is unchanged today.

## Remaining requested implementation

1. Finish identity, capability, persistent status and checkpoint/recovery integration.
2. Introduce per-session transaction contexts and RAII statement/stream pins.
   The current component pin API requires explicit release; a leaked pin applies
   backpressure but is not an adequate final server lifecycle implementation.
3. Integrate versioned heap insert/get/scan and every relational/streaming path.
4. Preserve version index entries and filter point/range/join/group lookups.
5. Replace destructive UPDATE/DELETE with linked versions and visibility metadata.
6. Add logical-row and unique-key conflict ownership, victim/wait policy and stale
   version/uniqueness rechecks after waiting. Test disjoint/same-row transactions.
7. Implement bounded cleanup hooks with snapshot and structural safety. No VACUUM.
8. Prove ordinary reader progress during a paused writer, own writes, fresh
   statements, rollback, NULL/composite unique races, streaming and crash recovery.
9. Run the full C5 Fast gate with 100K/1M reader/writer measurements, latency,
   lock waits and TPS. No PostgreSQL, 10M or long soak. Freeze only after acceptance.

## Component verification and evidence

Evidence directory: `work/write-v3/evidence/c5-foundation-01` outside this source.
Formatting, strict workspace Clippy, workspace tests and docs are recorded there.
These checks are **not** a substitute for the C5 Fast gate or MVCC SQL acceptance.

Two development runs each exercised 20 status-component subprocess exits. The
second run includes the explicit-abort/missing-status correction. The workspace
gate uses two rounds at each of four boundaries (eight more subprocesses), for
48 new component crash executions in this development increment. The unchanged
workspace also contains inherited C1–C4 crash tests. Boundaries are durable WAL
before status, status installed before checkpoint, status after WAL retirement,
and unfinished transaction. Parents require exit 87 and a forced boundary marker,
then reconcile status before WAL recovery twice. These do not prove SQL tuple
visibility, concurrent updates or engine-level C5 crash recovery.

To reproduce the component checks in PowerShell from this source:

```powershell
$env:CARGO_NET_OFFLINE = 'true'
cargo fmt --all
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
# Default crash test: five rounds x four status boundaries = 20 subprocesses.
cargo test --workspace
cargo doc --workspace --no-deps
```

`PHOBOS_C5_STATUS_CRASH_ROUNDS` optionally selects 1–12 rounds per boundary for
component development. No existing failed tests were disabled or removed. No C5
performance measurement has been made because the SQL MVCC route is not enabled.
