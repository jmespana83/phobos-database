# PHOBOS 0.2-G — Commit pipeline CPU / preparation V2 (design)

Baseline: 0.2-F source `fa1232382121f23cfdf964e6456148e68beae74aae4120a36c4fc91f4a76e5a8`.

Principle: prepare early, carry exact dependencies, validate cheaply at
commit, use the prepared result while it is still valid, fall back to the
existing path when it is not. Move CPU, not authority.

## 1. The pipeline of one indexed autocommit INSERT (as built in 0.2-F)

| # | step | where | inputs | mutable dependencies | can run before commit order? | must be revalidated at commit |
|---|---|---|---|---|---|---|
| 1 | parse, bind | statement | SQL text, params | none | yes (already does) | — |
| 2 | statement view (heap/index read handles, catalog) | statement | read directory (`Arc`), statement pin | read-directory generation (DDL) | yes (already does) | no (catalog generation is pinned) |
| 3 | admission view (`AdmissionPass::fresh_view`) | statement | same | same | yes (already does) | — |
| 4 | index key encoding (`index_key_for_row`) | statement **and** commit | row, index definition | none (pure) | yes | no — pure function of row + definition |
| 5 | row ownership + UNIQUE key ownership (`Ownership::acquire`) | statement | logical row, logical unique key | concurrent owners | yes (already does) | no — held until publication |
| 6 | speculative UNIQUE probe (`typed_unique_visit`) | statement | committed index image, validation snapshot | publications after the probe | yes (already does) | yes — but the key ownership in 5 already serialises competitors; the probe is the authority for committed rows |
| 7 | heap target page selection + tuple placement (`insert_version`) | commit, Stage A | newest pending/committed heap image | earlier staged batches on the same table | only against a provably current base | base image identity |
| 8 | index leaf insertion (`insert_version` / batch) | commit, Stage A | newest pending/committed index images | same; splits | same | leaf + path identity |
| 9 | page CRC on modification | commit, Stage A | page bytes | none | with 7/8 | — |
| 10 | stamp (LSN + CRC), WAL delta vs base, record CRC | commit, Stage A, WAL lock | page image, base image, WAL position | WAL order (LSN) | **no** — LSN is assigned in WAL order | — |
| 11 | COMMIT record | Stage A | — | WAL order | **no** | — |
| 12 | write-through force | outside every lock | WAL bytes | — | — | — |
| 13 | receipts, page installation, status publication | Stage B, commit order | durable receipt | publication order | **no** | — |

## 2. Why relocating Stage-A work does not close the low-concurrency gap

With one client the commit path is a strict sequence: statement → Stage A →
force → Stage B → reply. Work moved *out of Stage A but still on the same
request* (steps 7–9 run "earlier") is still on that client's critical path:
the client waits for every microsecond of it. A prepared plan that is
validated and adopted at commit additionally pays the validation, and a stale
plan pays the work twice. Relocation only helps when another request can use
the commit-order lock meanwhile — i.e. at 8/16 clients, which 0.2-F already
handles well (Windows OLTP8 13.2K/s, OLTP16 13.0K/s).

Therefore the single-client targets (autocommit, OLTP1, 500-row) can only
move by **removing** CPU, not by moving it. 0.2-G does that first.

## 3. What 0.2-G removes (fast rebase = cheaper rebase)

Measured on the 0.2-F release build with `perf` (3,000 autocommits):

| duplicate work | 0.2-F | 0.2-G |
|---|---|---|
| CRC32C of every 8 KiB page image | ~8 per changed page per commit (modify, stamp-verify, stamp, WAL post-stamp check, delta base, install, store validator, store LSN) | 5: the WAL accepts the image it just stamped by an exact token; installation verifies the checksum once and hands the store a borrow-scoped proof |
| 32 KiB zeroed bucket table per private file per commit | 3 × 32 KiB `memset` | sparse map |
| 8 KiB copy of every resident dirty page at installation | 1 per page | 0 (visited in place) |
| descriptor `dup`/`close` per statement reader | 2 syscalls × ~7 readers per autocommit | 0 (`Arc<File>` shared; readers never position it) |
| physical-domain extraction for small same-table batches | 2 map rebuilds + struct moves per Stage A and per Stage B | 0 (stage runs in place under the database mutex; lock order commits → database → WAL unchanged) |
| table schema + index definitions cloned per changed row in the rebase | 1 schema + 1 per index, per row | 0 (borrowed; read-only) |
| 8 KiB clone of every dirty heap frame before it is written to the private file | 1 per dirty frame | 0 (written in place) |

## 4. Proofs instead of re-validation (Part M)

* **`VerifiedImage<'a>`** (phobos-storage): constructed only by
  `VerifiedImage::verify(file, page, &bytes)`, which runs the complete
  `page_format::lsn` check (checksum, identity, LSN). It borrows those exact
  bytes, so they cannot change before `CommittedFile::publish_verified`
  consumes it. The store then runs the full *structural* validation (heap
  slot directory; index node layout and **every key**) but does not
  recompute the CRC a second and third time. Externally read images (disk)
  still take the full validator. Nothing is skipped globally.
* **WAL stamp token**: `stamp_next_page` records (file, page, LSN, stored
  checksum). The append that consumes that image for exactly that LSN accepts
  it when the stamped fields are unchanged; any other image takes the full
  `page_format::lsn` check. The installation proof above re-verifies the full
  checksum before the image can become visible, so a caller that changed the
  bytes between stamp and append is still caught before acknowledgement.

## 5. Prepared write plan (Parts B–I): what was evaluated

A `PreparedWritePlan` that builds the private page images before commit
order and adopts them under exact base-image tokens is possible in this
architecture: committed images are immutable `Arc`s (0.2-F), so "base still
current" is an `Arc::ptr_eq` per page. It was **not built** in 0.2-G:

1. Single-client gain is zero by construction (§2); the targets that are
   furthest from PostgreSQL are single-client.
2. Base images for a same-table successor are the *pending* images of the
   previous batch (not yet published), which carry no `Arc` identity; the
   token would have to cover the pending chain as well, i.e. a second
   invalidation system — exactly what the stop gate warns against.
3. The only machine available has 2 vCPUs; a concurrency-only gain cannot be
   measured here, so it could not pass the KEEP rule.

Recorded as DEFER with this analysis; the dependency table in §1 is the
starting point for 0.2-H.

## 6. Bulk: background extent step (Part T)

Profiling the 3M native ingest showed the 0.2-F background extender falling
behind: it starts at < 1 MiB remaining and prepares 4 MiB, while bulk WAL
writes arrive faster, so the commit path waited for it 85 times (0.2-E did
85 foreground extensions instead). Each wait serialises a zero-fill plus a
`FlushFileBuffers`/`fsync` behind the ingest's own write-through writes.
0.2-G doubles the next extension (up to 32 MiB) whenever the commit path had
to wait for or perform an extension, and starts it when less than half a step
remains; the step resets when the active file is replaced. Capacity is still
adopted only after the worker's flush; the foreground path is unchanged.

Linux evidence (release, 3M native ingest, interleaved): 0.2-F median 22.38 s
(5 runs, 22.11–23.09), 0.2-G 22.82 s (5 runs, 22.02–22.93), 0.2-G with the
step capped at 4 MiB 22.53 s (3 runs): differences are inside the run-to-run
range. The adaptive step removes the commit-path waits (85 → 1 per 3M ingest)
and halves the number of extension flushes (86 → 44); its effect on the
Windows 3M regression must be measured there (`RUN-BULK-AB.cmd`).

## 7. Stage-A exclusivity (correctness fix)

While a Stage-A batch yields to a waiting publisher it releases the commit
order lock. In 0.2-F a second Stage-A batch (e.g. a direct commit from
reclamation) could then enter and interleave its WAL records with the first
batch; Stage B's ordered receipts then refused the out-of-order commits and
the database fenced itself (5 of 20 runs of the new maintenance race test on
the unmodified 0.2-F code). 0.2-G marks Stage A as active in the commit order
state; a second batch waits on the commit-turn condition variable until the
first batch finished Stage A (0 of 20 runs fail). Publication of durable
batches still proceeds during the yield.
