# PHOBOS 0.2-K.4 — Compatibility: `LAZY_INDEX_PRUNING_V1`

## Marker

The marker is a **persistent catalog capability bitmask**, stored in `catalog.phc`.

| Catalog format | Meaning |
|---|---|
| version 1 or 2 | No capabilities. This is the 0.2-I … 0.2-K.3 format, written unchanged by K.4 until the capability is enabled. |
| version 3 | Version 2 layout plus a trailing `u32` capability bitmask, before the checksum. Bit `0x1` = `LAZY_INDEX_PRUNING_V1`. |

- K.4 accepts versions 1, 2 and 3.
- **Unknown capability bits** fail the open with `Unsupported: database requires storage capabilities this PHOBOS binary does not support (bits …); open it with a newer release`.
- **Older binaries** (0.2-I … 0.2-K.3) accept only catalog versions 1 and 2. They refuse a version 3 catalog with `InvalidCatalog: unsupported catalog format` before reading any data. That is an explicit refusal, not a corruption report: the catalog checksum is intact, and the version check comes first.

Nothing else changed: no heap, index, WAL, status-file or replication format change.

## When the capability is enabled

1. **At open of a writable primary** (`Coordinator::open`, not a standby), if lazy pruning is allowed and some table has a non-unique index. Nothing can conflict at that moment.
2. **Before a reclaim pass** that could leave a non-unique entry stale (the first pass with candidate pages), if it was not enabled at open, for example after a `CREATE INDEX` on a running database. If active transactions block the schema lease, the pass stays eager and the next pass retries.
3. **Never** when `PHOBOS_LAZY_INDEX=0`. The database then stays catalog version 2, fully old-compatible, with eager exact pruning.

**A database without any non-unique index is never marked.**

## How it is made durable

- Enabling is a **schema publication**, exactly like DDL. A new catalog image (version 3) is staged in a private schema directory, logged as WAL `Metadata` records, and installed atomically at publication.
- **Crash during enabling:** recovery either replays the logged metadata (capability on) or does not see the transaction (capability off, version 2). There is no intermediate state, and no stale entry can exist before the capability is published.
- **Backup / restore:** `catalog.phc` is copied, so the capability is preserved.
- **Physical replication / PITR:** the metadata records replay on standbys and in PITR targets. Standbys never enable it themselves (they are read-only).

## Semantics under the capability

- **Non-unique index entries may be stale at rest.** The RID names a RETIRED, FREE or trimmed slot, or a reused slot whose occupant has a different key.
- **Index reads are unaffected.** Every index read path already revalidates entries (0.2-K Part H):
  - RID lifecycle state: `get_version` / `slot_reclaimed`;
  - key equality against the current occupant;
  - MVCC visibility.
- **Slot reuse under the same key:** `(key, RID)` is a set, so the stale entry becomes the live entry of the new occupant.
- **UNIQUE indexes stay eager and exact.** At rest, every UNIQUE entry names a valid version with a matching key.

## Integrity checking

Online `CHECK` and `phobos-admin check` classify every entry:

| Class | Definition |
|---|---|
| **live** | Names a version whose key matches. |
| **stale** | Non-unique index, capability on, and the RID is RETIRED, FREE or trimmed, or the occupant's key differs. |
| **corrupt** | Anything else. The check fails exactly as before. |

- UNIQUE indexes, and every index when the capability is off, keep the strict 0.2-K.3 rule.
- `phobos-admin check` prints `index_live_entries`, `index_stale_entries`, `index_corrupt_entries=0` and `stale_ratio`.
- A 0.2-K.3 or older `check` refuses a version 3 catalog (see Marker).

## Downgrade

**Not supported once the capability is enabled.**

To return a database to an older release:
1. Dump and reload it.
2. Or open it with K.4 and `PHOBOS_LAZY_INDEX=0`, then rebuild every non-unique index (`DROP INDEX` / `CREATE INDEX`).

Clearing the bit itself is not implemented.

## Switches

- `PHOBOS_LAZY_INDEX=0`: eager pruning for every index; the capability is never enabled.
- `PHOBOS_LAZY_SWEEP_ENTRIES` (default 4096): entries one sweep slice inspects.
