# Phobos Performance Architecture V2: audit and implementation plan

Status: checkpoints S1/S2, P1, indexed DML, W1 and W2 are accepted. W2 passed the full Milestone gate: 120 routine tests, strict Clippy, focused recovery/migration tests, 296 crash cycles, strict 100K/1M read budgets, a ten-minute soak, and separate-process 1M streaming/memory/integrity checks. G1 completed its measured investigation and retained the safe serialized fallback; its complete Fast gate passed. Final 100K/1M TCP comparisons, the 5M full suite and 10K/100K/1M streaming-memory checks passed. See performance_v2_campaign_report.md for the final results. PostgreSQL remains the fixed historical baseline. The initial audit below is retained as context.

## Verified starting point

The starting project is the delivered PostgreSQL-comparison candidate, version `0.0.1-alpha.0`. Source ZIP SHA256: `29d78b831e1e4805873a9d4c6efc592d09af0059fad8766e7bad54738526919c`. Server SHA256: `dfd736803c0f10a912a5bda26ff04553dc9a0ae5e611d771b1fd5031ee7fcf17`. The audit rechecked all 67 recorded engine/build fingerprints, three release binaries, both previous delivery manifests, and the comparison raw archive. All matched. Rust is pinned to 1.85.0 MSVC.

The prior 71 Rust tests, crash campaign, two-hour soak and Phase 7/8 results are unchanged-source evidence, not newly rerun V2 tests. The recent formatting, strict Clippy and four Python comparison tests passed. Beta remains uncertified.

A separate source copy is at `work/performance-v2/phobos`; previous workspaces, live benchmark datasets and published evidence remain intact. PostgreSQL will not be restarted, reconfigured, or benchmarked during ordinary development.

## What the starting code did

Paths below are relative to the Phobos repository. Line references identify the audited starting source.

| Area | Observed implementation | Consequence for V2 |
|---|---|---|
| Protocol | `crates/phobos-protocol/src/lib.rs:8`: version 1, 16-byte header, 1MiB maximum payload, one QueryResult frame | Keep the frame cap; add explicit stream negotiation and state validation |
| Result execution | `crates/phobos-execution/src/lib.rs:34`: `Rows` owns `Vec<Row>`; `to_text` builds one String | Chunking that String alone would retain unbounded result materialization |
| Server | `crates/phobos-server/src/lib.rs:69`: coordinator executes and serializes while holding the database mutex; response-size rejection happens afterward around line 378 | Introduce typed result delivery and release resources on backpressure/disconnect without weakening isolation |
| Existing streaming | `crates/phobos-execution/src/lib.rs:510`: callback-based `stream_select` batches a heap scan, rejects ORDER BY, supports only basic SELECT, returns column names after visiting rows | Reuse the scan machinery, but move schema/start notification before rows and preserve index-based access |
| Relational operators | `Relation.rows`, join inputs and outputs are vectors; `external_sort_rows` around line 2111 accepts and returns vectors despite spill support | Convert producer/consumer boundaries and bounded spill paths; framing is only part of Goal A |
| Client/CLI | `Client::query` returns one String; CLI session also accumulates output; Rust client has five-second socket timeouts | Add a typed incremental API and streaming CLI; preserve the legacy collecting API and existing TLS/auth paths |
| Transaction setup | execution lines 345 and 439 flush existing storage, allocate a durable transaction ID, copy database files, and open another Database | Removing only full-file WAL records would leave database-sized copy/reopen work |
| Commit | execution lines 373-487 flush staging, log snapshots, clear open heaps/indexes, install snapshots, reopen storage, checkpoint and rotate | Replace the transaction storage model as well as WAL encoding; retain the validated Windows handle lifecycle |
| WAL | `crates/phobos-wal/src/lib.rs:153`: BEGIN + file chunks + COMMIT, then WAL sync; checkpoint/rotation adds more synchronization | Changed-page WAL can remove file-sized write amplification and per-commit checkpoints |
| Recovery | WAL lines 239 onward collect records/chunks, then install committed snapshots | V2 needs bounded scanning, commit-order redo, torn-page repair, and an explicit checkpoint recovery horizon |
| Buffer pool | `crates/phobos-storage/src/lib.rs:291`: dirty flag, pin count and LRU already exist; eviction writes and synchronizes dirty pages, without a WAL barrier | Add commit/LSN eligibility; existing private staging currently supplies safety |
| Index I/O | `crates/phobos-index/src/lib.rs`: direct File reads/writes, separate from heap buffer; allocation writes index metadata | A heap-only overlay would omit split/root/meta updates and be unsafe |
| Heap reopening | `HeapTable::open` around storage line 648 scans pages to reconstruct free-space information | Keep live storage handles and apply free-space deltas instead of reopening every commit |
| UPDATE/DELETE | execution lines 787 and 826 scan the whole heap to identify rows, even for indexed predicates | After WAL profiling, reuse the existing index-search machinery for qualifying DML; WAL alone cannot remove this scan cost |
| Transaction IDs | `crates/phobos-txn/src/lib.rs:67` syncs the ID control file on every allocation | Account for this synchronization separately; eventually derive/reserve IDs safely through durable control/WAL state |

The WAL reader checks version, lengths and checksum but does not enforce a small explicit record maximum before payload allocation. V2 must validate its record bound before allocating. Unknown formats must fail before any tail truncation or data mutation.

The current two-second coordinator timeout governs explicit transaction-owner waits. Blocking database-mutex acquisition is not covered by that deadline. This distinction matters: the measured 10M failure was a client socket timeout, not a returned lock-timeout error.

## Stable measured baseline and targets

Use the preserved `comparison.csv` and raw samples. These are median whole-sample durations, not per-operation p95. Three operations are timed per ordinary write sample; concurrent writers use twelve operations across four connections.

| 1M workload | Current Phobos seconds | PostgreSQL reference seconds | Stage 1 ceiling: 10x faster |
|---|---:|---:|---:|
| Autocommit insert | 7.109815 | 0.000706 | 0.710982 |
| Transaction insert | 2.957211 | 0.000679 | 0.295721 |
| Update | 8.488951 | 0.000745 | 0.848895 |
| Delete | 8.700065 | 0.000780 | 0.870007 |
| Concurrent writers | 28.947484 | 0.002272 | 2.894748 |

These are targets, not predictions. Stage 2 divides the baseline by 100 only where measured architecture improvements support it. Within 2x PostgreSQL and within 10% are later, named-workload aspirations, never global acceptance claims.

At 10M the durable TCP bulk load passed in 1,653.5625844 seconds. Oversized scan/join/sort results failed; concurrent writers timed out and mixed work was not reached. Keep these failures as the baseline. Keep the original 10M timeout and all earlier candidates too.

For point/range/concurrent reads, use repeated paired Phobos runs with a proposed 10% median regression review threshold and an absolute-noise floor for sub-millisecond samples. Recheck an apparent regression with new independent runs, retaining both results. This is a review budget, not permission to hide slower samples. Preserve SQL, indexes, seed, cache procedure, batching, isolation, timeouts and durability when claiming speedups.

## Checkpoint S1: versioned streaming contract

Keep version-1 clients and their existing Query behavior working. Negotiate a streaming capability in Hello/HelloAck and use a separate streaming query message; never send unsolicited multi-frame results to an old client. Version the stream payload schema explicitly. A future incompatible envelope change requires a separate protocol version, not an interpretation change hidden behind the old version byte.

The stream state machine is:

1. QueryResultStart: schema/column names and typed value metadata.
2. Zero or more QueryRows frames: monotonically numbered bounded batches, same request ID, declared row counts.
3. QueryResultEnd: total row/batch counts and successful completion.

Commands use a separate CommandResult with tag and affected-row count. Errors carry stable error code and message; an error after Start terminates that result without End. Clients must not interpret a received prefix as complete success. Reject rows before Start, duplicate Start/End, mismatched IDs, malformed lengths/counts/types, invalid sequence and premature EOF. Poison/close an unusable connection rather than accidentally consuming a following request's frames.

Start with a byte budget around 64KiB and a row-count cap around 256, both bounded by the unchanged 1MiB hard frame limit. These are initial tuning values, not measured optimal values. Check schema and individual-row limits explicitly; a too-large single value/row is a distinct bounded error, not a total-result-size policy. Use typed, length-delimited values and explicit NULL tags so TEXT containing tabs/newlines, BINARY, DATE, TIMESTAMP and DECIMAL round-trip without display-string ambiguity. Reuse the existing value/codec definitions where compatible and add wire-specific validation.

Expose a callback/iterator-style Rust API consuming a batch before requesting/decoding the next. Keep a clearly collecting compatibility API for callers who intentionally need an owned result. CLI writes batches incrementally to stdout and reports late errors with a nonzero exit. Auth classification, role checks, certificate validation and non-loopback policy remain on the same query path.

S1 may temporarily use the existing materialized execution result to establish the protocol/client state machine. That is an intermediate runnable checkpoint, explicitly NOT acceptance of bounded-memory streaming. Do not call Goal A complete at S1.

## Checkpoint S2: bounded execution and cleanup

Introduce a typed result sink/cursor at the execution boundary: start(schema), row/batch, command, end. Reuse parser and expression semantics. Adapt the existing heap visitor and index point/range paths rather than routing every SELECT through a full heap scan.

Convert join input/output and sort interfaces to producers/consumers. Reuse existing join algorithms and stable comparison/merge logic; bound build-side memory and spill or use the existing bounded fallback with bounded inputs. Build sort runs incrementally; merge incrementally with bounded fan-in, rather than opening an unbounded number of run readers or collecting the merged result. Group aggregation also needs a bounded partition/spill policy before general bounded-memory claims. Preserve documented ordering and stable ORDER BY ties; do not introduce a new implicit SQL ordering guarantee.

Initially retain the current coarse isolation: a live streaming read holds its execution/read ownership until completion. Do not release it between batches and accidentally observe multiple database states. Bound socket write waits and unwind on disconnect. A stalled client must not retain locks indefinitely. A separate spool-under-lock then transmit design can be considered if measurements show backpressure blocks writers; account for disk quotas and time-to-first-row rather than describing spooling as a free improvement.

RAII guards own query cursors, spill readers/writers and temporary directories. Close handles before removing directories on Windows. Test cancellation/disconnect while scanning, joining and merging, then prove another session can query, mutate and reopen the same database. Keep no arbitrary correctness sleep/retry loops.

Accept Goal A only after >1MiB scans, joins and sorts work with bounded server/client memory and correct terminal semantics. Include empty results, commands, multi-batch order, every specified type, malformed frames, authorization/TLS, late execution errors, disconnects and resource cleanup.

Measure 10K/100K/1M streamed rows: server and client working set/private bytes separately, baseline and peak, wall time, first-row time, bytes including headers, frames, batches, rows and average rows/batch. A collecting compatibility adapter is not the bounded-client measurement. Compare the legacy path only where it succeeds; preserve its larger-result failures.

## Checkpoint P1: fresh commit-path profiling

After streaming validation, run separate uninstrumented and instrumented Phobos baselines at 100K and 1M. Keep headlines uninstrumented. Use both ordinary SQL/TCP and isolated internal commit spans to distinguish execution scan time from commit time. Retain existing profiling and add missing counters rather than replacing the observability subsystem.

Measure transaction setup/copy/open, row qualification, heap and index modifications, dirty-page counts, allocations, cache hits/misses, metadata I/O, WAL records/bytes, WAL fsync count/duration, data-page flush count/bytes, install/reopen, checkpoint/rotation, transaction-ID sync, coordinator waits, commit latency and stream counters. Record absolute counter deltas around each phase; inclusive spans are nested and must not be summed as disjoint time.

A small write must be profiled against a preloaded database, not hidden inside bulk load. Run write and read coverage from the requested fast loop. If UPDATE/DELETE remain dominated by scanning, implement indexed candidate selection as a separate measured change, with predicate rechecks, stable candidate IDs and full statement rollback on constraint/expression errors. Do not replace snapshot-WAL and DML selection in one unreviewable change.

## Checkpoint W1: transaction page overlay and bounded WAL V2

Use a redo-only, no-steal transaction design first. A transaction reads the committed page view and privately overlays changed pages, allocations and metadata. Uncommitted pages never reach main heap/index files. Private memory is bounded; evicted private pages go to transaction scratch storage, not shared database files. Abort discards the overlay and metadata changes. Scratch durability is not a commit guarantee: all required redo bytes must reach durable WAL before publication.

Introduce a page-store abstraction used by BOTH heap and B+ tree I/O, including index meta/root/parent/leaf-link changes. Keep existing page IDs, record IDs, slot layout, key layout and index algorithms. Do not clone entire files or free-space maps per transaction. Preserve live committed handles and apply metadata/free-space deltas. Catalog, statistics invalidation, create/drop/truncate, file identity and allocation state participate in the same atomic transaction.

WAL V2 has a versioned, checksummed envelope with explicit bounded length, transaction ID, LSN, previous-transaction LSN, record type, file/relation identity and generation. Length/type/version validation precedes allocation or side effects. Record families cover Begin, HeapInsert/Update/Delete page changes, IndexPageChange, CatalogChange, PageAllocate, PageInitialize, Commit, Abort and Checkpoint, plus required file lifecycle/control records. Commit includes enough transaction-chain/count information to reject missing or reordered transaction content.

Start with complete after-images of CHANGED 8KiB pages and bounded metadata records. This is page-oriented WAL, not database/file snapshots. The record schema allows operation-tagged byte patches, but compact deltas are a later measured optimization. Always retain sufficient full-page redo to repair a torn page; a byte patch alone cannot repair an arbitrary checksum-corrupt base page. Deduplicate repeated changes to one page within a transaction before final redo emission where semantics permit.

First keep synchronous changed-page installation AFTER durable commit WAL, while removing full-copy/snapshot/reopen work. This conservative checkpoint proves overlay, WAL and recovery behavior before adding deferred writeback. On uncertain WAL I/O failure, do not return success or continue publishing state; fence the database and recover on reopen. Explicit rollback and failed-statement semantics must remain intact.

## Checkpoint W2: page LSN and deferred committed-page flushing

Add a page LSN covered by the page checksum. The audited heap header has space at bytes 16-23; node/meta headers also have candidate reserved space. Confirm every encoder/decoder and golden fixture before assigning offsets. Preserve tuple/index layouts, but explicitly version any changed page semantics. Do not silently write new semantics as format 1 or depend on an independently updated sidecar LSN that could get ahead of a torn data page.

Frame state includes page LSN, recovery LSN/first dirty LSN, dirty generation, pin guard/count, ownership/commit state and flush eligibility. Updating a cached page must preserve its pins. The writer may flush only a committed version whose required WAL is durable. Snapshot a page under its latch, write that image, and clear dirty state only if its generation has not changed. No per-row synchronous data write is required for private changes.

Commit order: finish transaction state; append complete redo and COMMIT; sync WAL through the commit LSN; publish the committed page/catalog view; acknowledge. Publication remains atomic to readers. Durable WAL remains available while data pages lag. Committed dirty-page pressure uses bounded writeback/backpressure rather than unbounded cache growth. Eviction, checkpoint and shutdown all use the same WAL-before-data eligibility checks. Background writeback is added only after this synchronous path is proven.

A checkpoint captures a safe recovery horizon, drains the required committed pages, synchronizes data and catalog/control dependencies, then durably records checkpoint completion. Reclaim WAL only after that completion and retain everything needed by active transactions, dirty pages, catalog/file lifecycle and torn-page recovery. Crash during any checkpoint phase must leave either the older or newer valid recovery horizon usable. No checkpoint/rotation after each small commit.

## Recovery and compatibility contract

Use bounded WAL scanning and redo in commit/LSN order, not transaction-ID map order. Track/verify complete committed chains; use bounded indexes or scratch spooling rather than retaining all WAL payloads in RAM. Ignore/discard uncommitted overlays. For a checksum-valid page, a sufficiently new page LSN can skip redo. For a torn/missing page, reconstruct from a retained full-page image and subsequent redo; never trust an LSN in a corrupt page. Validate file identity/generation to avoid applying old records to reused names/IDs.

Repeated recovery must be idempotent, including allocations, index splits, catalog changes and file lifecycle operations. A committed multi-page change may have reached only some files before a crash; replay completes all of it before serving queries. A missing or invalid non-tail WAL record is a corruption error, not silently discarded work. Interrupted final records can be treated as a torn tail only under the documented framing/commit rules.

Keep the legacy reader for existing format-1 recovery. Migration is explicit and offline: verify/backup legacy data, finish legacy recovery and a durable checkpoint, convert into a separate destination or crash-resumable migration area, then install the V2 control state only after verification. Preserve the original. Unknown/new WAL versions reject before mutation. New-format data must reject cleanly in old binaries; use a retained V2 WAL/control anchor as well as explicit page versions, because old binaries do not know about a new manifest filename. Test old-binary rejection after checkpoints, including empty databases. A raw downgrade after V2 writes is unsupported; restore the legacy backup instead.

Offline backup must capture a recoverable committed state including necessary retained WAL/control files, or perform a correctly ordered checkpoint first. Restore and integrity tools must recognize the formats. Do not copy lagging data pages and omit the WAL needed to recover them.

## Checkpoint G1: group commit, only if profiles justify it

A single database mutex held until fsync cannot form a useful commit group. Do not claim group commit merely by adding a queue or timer. After page commits are correct, measure the fraction of small-write latency attributable to WAL sync versus coordination and execution.

If justified, serialize write execution into bounded commit batches, append transactions in order, and let one flush leader sync through the batch's highest commit LSN. Publish/acknowledge only transactions covered by that durable LSN. Readers cannot observe pending state. Explicit transaction ownership, DDL and rollback are initial batch barriers. Any tentative dependency between queued writers must remain ordered and unexposed; I/O failure fences the batch and recovery decides durable outcomes. Validate dependent writes and uniqueness conflicts, not just independent inserts.

Record actual transactions per WAL fsync, batch sizes, queue delay, commit latency distribution and throughput. Include singleton/no-load behavior and a bounded maximum admission delay. Retain the serialized fallback if measured batching gains do not justify its complexity. No MVCC rewrite is required or promised by this plan.

## Validation and acceptance sequence

| Checkpoint | Required evidence before keeping the change |
|---|---|
| S1 framing/client | Typed golden frames, malformed streams, legacy compatibility, auth/TLS and CLI; explicitly no bounded-execution claim yet |
| S2 streaming | 10K/100K/1M streamed memory/bytes/frame measurements, full scan/join/sort ordering, disconnect and temp/lock cleanup |
| P1 profile | Frozen 100K/1M uninstrumented and instrumented results; no new PostgreSQL run |
| W1 overlay/page WAL | Existing logical suite plus 20-50 targeted crash cycles; proof committed redo works when changed data pages have not been installed |
| W2 page LSN/writeback | Torn-page and partial-flush recovery, tiny buffers/eviction, repeated recovery, catalog/index split/backup checks; 250-cycle milestone |
| G1 optional batching | Durable-LSN ack assertions, ordered/dependent transactions, failure fencing, actual fsync sharing measurements |
| 1M milestone | Full workload and logical suite, 250 crash cycles, 10-15 minute soak, read budgets and Stage 1/2 measured write targets |
| Scale/release | 5M only after milestone; 10M and 1,000 crash cycles only at release-candidate readiness; two-hour final soak and packaging gates |

At each major kept change run formatting, strict all-target/all-feature Clippy, workspace tests, rustdoc and Phase 8 or a documented superset. Do not alter old expected correctness results just to get a pass. Preserve failed runs with source/config hashes.

Crash hooks cover before/during WAL write, before sync, after redo sync, partial COMMIT write, after COMMIT sync, dirty-page flush, checkpoint and index split. Include a diagnostic mode that separates redo sync and commit sync even if normal commits use one fsync covering both. Record parent-observed acknowledgements and durable boundaries. Crashes before acknowledgement can have an ambiguous committed outcome; they must not be incorrectly classified as definitely aborted. Verify acknowledged commits survive, transactions without a valid commit remain invisible, and replay is idempotent. Force recovery from WAL using controlled missing/torn changed pages, rather than relying on already-correct data files. Process-crash tests do not prove hardware power-loss behavior.

Create `tools/performance-v2-validation.ps1` with Fast/Milestone/Certification modes. Fast runs format/Clippy/unit tests, 20-50 focused crashes, the 100K suite and short streaming coverage; it must not invoke 1M/10M or a long soak. Milestone adds 1M, 250 crashes and 10-15 minutes of soak. Certification adds 5M/10M, 1,000 crashes, long soak and packaging. A 5-minute development soak can be a separate explicit fast-loop command rather than forcing every Fast invocation to wait. All native failures stop their gate; an explicitly named evidence-collection runner may record failures and continue but cannot print a certification success marker.

The existing Python comparison driver must learn the negotiated stream without silently changing its SQL or collecting semantics. If its behavior changes, label the new basis and keep old raw files. Use the frozen PostgreSQL numbers as historical references throughout this campaign; do not rerun PostgreSQL without a subsequent explicit user request. Streaming memory benchmarks use an incremental consumer and are not interchangeable with the old fully materializing Python timing.

## Planned change surface and deliverables

This is a planned inventory, not a claim these files are changed yet:

- Protocol/result path: `crates/phobos-protocol/src/lib.rs`, `crates/phobos-client/src/lib.rs`, `crates/phobos-cli/src/main.rs`, `crates/phobos-server/src/lib.rs`, execution result/operator modules and their tests.
- Page/WAL path: `crates/phobos-storage/src/lib.rs`, `crates/phobos-index/src/lib.rs`, `crates/phobos-wal/src/lib.rs`, `crates/phobos-execution/src/lib.rs`, `crates/phobos-catalog/src/lib.rs`, `crates/phobos-txn/src/lib.rs`; extract focused internal modules where that makes recovery/ownership reviewable.
- Operations: `crates/phobos-admin/src/lib.rs`, validation/crash binaries and format fixtures; change only as needed for recoverable V2 backups and integrity.
- Evidence: `crates/phobos-observability/src/lib.rs`, benchmark and comparison adapters, streaming resource sampler, validation script and immutable result directories.
- Documentation: `docs/performance_architecture_v2.md`, protocol/format compatibility notes, checkpoint reports and exact final diff/hash inventories. Cargo dependencies change only when a measured/implemented requirement needs them.

Parser, SQL semantics, table/index logical layout, B+ tree algorithms, authentication primitives and TLS are retained. UPDATE/DELETE access selection and bounded relational execution are narrowly justified changes identified by this audit; they are not a broad SQL rewrite.

Completed development checkpoints are preserved under workspace outputs/performance-v2-s1, performance-v2-s2-scan, performance-v2-s2-sort, performance-v2-s2-join and performance-v2-s2-aggregate. Each records its actual scope and raw evidence; S2 transport and memory acceptance passed. P1 measurements precede indexed DML and storage/WAL changes. No fsync/WAL-volume reduction or PostgreSQL parity is claimed.

## Implemented S2 details and current limits

Simple and relational SELECTs now deliver through ResultSink. Heap/index visitors retain bounded input state; the coordinator holds database execution ownership until delivery completes. Index range traversal can stop before reading another leaf. Callback failures abort active transactions; disconnect rollback and Windows cleanup are tested. The legacy collecting API remains available, and EXPLAIN ANALYZE still uses it.

Sort input obeys the existing row budget and an 8 MiB retained-row target, with bounded extra decoder/vector/merge overhead. Binary-carry runs use 64 fixed metadata slots and at most two merge readers. This bounds memory/handles, but creates additional merge I/O; the 10K ordered validation smoke increased from roughly 163 ms collecting to 302 ms bounded, and is explicitly not a headline throughput comparison. Profiling must address this cost.

Joins build a bounded right-side hash table when actual size and estimates fit; otherwise they spool the right side and stream bounded left blocks through the existing nested-loop semantics. Aggregates retain per-group arithmetic state. Group input is spooled to preserve the existing row-count-based hash/sort grouping semantics, including signed zero and NaN representations. Input and output sorts are bounded. Temporary writers/readers close before directory removal; abrupt-process-exit cleanup is tested.

The stream-check binary uses the official Rust incremental client. v2-stream-memory.ps1 prepares a fresh fixture, restarts the server before each query, synchronizes client start through stdin, samples server/client memory separately every 10 ms and checks final database integrity. Timings include assertions and frame re-encoding for byte accounting; sampling may miss brief private-byte peaks. The client explicitly uses the existing comparison’s 120-second idle timeout; its library default remains five seconds. No PostgreSQL invocation is involved.


## P1 measurements before storage changes

Fresh cloned 100K/1M fixtures isolate BEGIN, staging, COMMIT and autocommit phases. Build `cargo build --release -p phobos-bench --features profiling --target-dir target/v2-profile`, then run `phobos-bench --mode write-profile --dir PRELOADED_BASE --output NEW_DIRECTORY/raw.csv --rows 1000000 --samples 3 --operations 3`. The output parent must exist; fixtures/output files must be new. `tools/v2-profile-summary.py NEW_DIRECTORY` subtracts before/after counters. Instrumented timings are diagnostic; inclusive spans overlap.

At 1M rows, three point UPDATEs inspected 3 million candidates. One explicit three-row INSERT commit emitted 90,825,211 WAL bytes and invoked four WAL synchronizations; three autocommits emitted 272,475,633 bytes and invoked twelve. Heap/index/ID/file-install synchronization is additional. Median explicit INSERT BEGIN was 610.1 ms and COMMIT was 1058.3 ms, versus 75.7/137.4 ms at 100K. These data justify removing both full-table DML qualification and full-database transaction setup/install work. No durability setting was changed.

`tools/v2-matched-phobos.py` runs the existing SQL campaign against an owned fresh Phobos server, with explicit streaming negotiation and the same collecting-client semantics. It has no PostgreSQL execution branch. New transport results are labelled separately from the historical one-frame run. Both 100K and 1M passed all workloads and final offline integrity. One local file-inventory operation overlapped the first 1M run; its metadata retains that caveat and an uncontended repeat is required for headline timings.

Current page-write calls are not unique dirty-page counts. Overlay-specific dirty counts, page LSNs and group-commit batch metrics belong to their subsequent implementation checkpoints. No 10x write speedup or cross-engine parity is claimed from P1.


## Indexed UPDATE/DELETE checkpoint

`indexed_dml.rs` reuses the existing index planner only for conservative, total predicates: AND combinations of exact-typed column/literal or bound-parameter comparisons. NULL constants, floating/decimal coercion, arithmetic, missing bindings, OR and other forms retain the previous heap scan. This preserves the evaluator’s eager error behavior on excluded rows. The full residual predicate is still checked.

Candidate record IDs are frozen and sorted into physical heap order before any mutation. This prevents repeated updates when indexed keys change and preserves existing uniqueness-conflict ordering. Duplicate or dangling index record references produce an integrity error. All original assignment evaluation, per-row index maintenance, transaction abort/rollback and snapshot durability remain intact. Large candidate ranges still use a candidate vector; this checkpoint does not claim bounded mutation memory.

Three focused tests compare indexed/nonindexed paths, residual/composite/duplicate-key behavior, indexed-key changes, rollback/reopen and eager errors. A subprocess test exits with an uncommitted indexed-key update or crashes after durable WAL commit before installation, then verifies two recovery passes and index integrity. Missing crash hooks and ordinary child panics are rejected.

Three point mutations now inspect three candidates at both 100K and 1M; previously three UPDATEs inspected300K/3M candidates. Diagnostic median UPDATE staging fell160.49 to24.53 ms at100K and1531.46 to315.72 ms at1M; DELETE staging fell153.06 to23.13 ms and1448.72 to260.89 ms. These include variable existing synchronization costs, and inclusive spans are not additive.

The first Fast UPDATE timing was worse despite reduced work; it remains in the evidence. Balanced six-sample S2/current TCP UPDATE comparisons on fresh clones did not reproduce it: ratios0.88396 at100K and0.93509 at1M, with value and offline integrity checks after every sample. `tools/v2-dml-update-check.py` reproduces this diagnostic. Fast read ratios versusP1 were0.955–1.089. WAL bytes/fsync counts remain unchanged; no10x end-to-end write improvement is claimed yet.

## W1 private pages and WAL v2 (accepted)

Fresh databases now use WAL v2. Existing databases retain the legacy engine until an explicit offline migration. A V2 transaction keeps the existing heap/index objects and redirects changed pages to private scratch. Each object uses a 64-page cache and a fixed 4,096-bucket on-disk lookup structure; eviction writes only disposable private data. BEGIN does not copy heap/index files or clone the heap free-space vector. Rollback restores derived free-space entries only for changed original pages and restores index root/allocation metadata.

COMMIT freezes each private page set, writes bounded full-page images for changed pages and chunked catalog/statistics images, then appends COMMIT and synchronizes WAL. Only that successful synchronization constructs a durable receipt tied to the transaction and canonical database directory. Installation rejects a missing, mismatched, or unfrozen receipt. The engine fences admissions before the first base-file write and clears the fence only after all installation, synchronization, lifecycle operations and checkpoint cleanup succeed. An error after durable COMMIT requires close/recovery; rollback cannot undo it. Uncommitted base bytes remain unchanged.

W1 installs and forces changed data before acknowledging, then replaces WAL with a complete synchronized anchor. The anchor preserves monotonically increasing LSN/transaction cursors and prevents an old decoder from treating the database as legacy. Each normal commit currently performs three WAL synchronizations including the two checkpoint file forces; heap/index and directory/metadata forces are additional. Deferred writeback, page LSNs and batching are not implemented in W1. Heap/index pages remain version 1; WAL version 2 is a separate format change.

The WAL decoder bounds record allocation at 64 KiB, validates CRCs, transaction chains, metadata extents and record types, and preflights the entire valid prefix before modifying database files. Recovery synchronizes the accepted WAL prefix, replays only complete committed transactions, repairs changed pages from full-page images, forces restored data, and atomically replaces WAL with a complete anchor. It retains WAL on failure. A second recovery is safe. Dropped heap/index identities remain as retired files until a durable checkpoint permits cleanup. Unknown WAL versions are rejected before repair, truncation, catalog creation or migration backup creation. Partial records without a valid COMMIT do not publish data.

File owners close scratch files and removed/replaced heap/index objects before Windows rename/removal. Unix directory synchronization is explicit; the existing Windows directory synchronization limitation remains. Process termination and deliberately torn test files exercise software recovery, not hardware power-loss behavior.

### Explicit migration

Stop the server and all other database users, then run:

```powershell
.\target\release\phobos-admin.exe migrate-wal-v2 C:\path\database C:\path\new-empty-backup
```

The command holds the offline administration lock, validates the old WAL, and creates/forces a separate complete legacy backup before conversion. It recovers legacy changes, forces data, then installs the V2 anchor. The backup must be a new/empty independent directory, outside the source tree. Use the ordinary offline restore command with that untouched backup to return to the legacy format; never substitute an old WAL over a V2 database. Tests cover crashes before/after anchor installation, backup byte preservation, repeated recovery and continued transaction ID allocation. V2 backup/integrity remains offline.

### W1 evidence and measurement caveats

Raw results live under `benchmarks/performance-v2-results/`. Full Fast gates passed for the private storage lifecycle, normal V2 engine, and migration. Engine recovery tests deliberately tear committed heap/index pages before reopening twice. Certification-only injection also tests a half-written page record, half-written COMMIT, and a forced redo prefix before COMMIT. The latter diagnostic adds a synchronization only in the certification injection path, never to ordinary execution.

Three INSERTs at both 100K and 1M emit 16,654 WAL bytes, install two distinct pages (16,384 bytes), and perform three WAL synchronizations. P1's legacy 1M transaction emitted 90,825,211 bytes and performed four WAL synchronizations. Three W1 autocommits emit 49,962 bytes and perform nine WAL synchronizations. These counts exclude setup and include checkpoint WAL forces; page-write calls elsewhere are not distinct-page counts.

The original write profiles included deferred OS writeback of freshly copied fixture files in BEGIN. Retained `w1-profile-100k` and `w1-profile-1m` demonstrate that confounder. The profiling harness now forces cloned files before opening/timing the transaction; `w1-profile-durable-100k` and `w1-profile-durable-1m` are labelled separately. This changes only diagnostic setup, not ordinary workloads or durability. Earlier P1 BEGIN/COMMIT timings have the same unforced-fixture caveat; WAL volume and candidate counts remain useful. Instrumented timings are not headline benchmark results.

The first full uninstrumented W1 1M suite completed all workloads. Relative to historical embedded P1, UPDATE was 10.25x faster and DELETE 10.93x; autocommit INSERT was 8.51x, explicit INSERT 4.03x, and concurrent writers 35.83x. These are local whole-workload observations, not PostgreSQL parity or pure commit latency. Scan aggregation and sort ratios of 1.1035/1.1098 exceed the 10% read threshold and require balanced reference/current confirmation before acceptance. All original raw measurements and failed development budget runs are retained. PostgreSQL has not been rerun.

The completed balanced S2/W1/W1/S2 1M review (`w1-read-review-1m/review.json`, reproducible with its `summarize.py`) passed all read budgets using six samples per build. Ratios: indexed point1.0841, range0.9955, full scan1.0737, scan aggregate1.0628, join1.0297, group1.0085, sort1.0000, concurrent readers0.9169 and startup1.0736. All four full suites completed without timeout/failure. Autocommit INSERT ratio0.05266, explicit INSERT0.18492, UPDATE0.06722, DELETE0.06624 and concurrent writers0.02332. These are comparisons with the frozen Phobos S2 executable, not a new PostgreSQL comparison. The original historical-threshold exceedances remain in evidence; final W1 acceptance still requires the last Fast gate.

Final W1 gate `w1-final-fast` passed after that review: 113 routine Rust tests, zero failures and three existing ignored soak tests; 15 focused WAL tests; two migration tests including interruption/recovery; 22 development crash cycles; strict all-target/all-feature Clippy; Phase 7/8, documentation, 100K performance, ordered/unordered streaming, official-client memory checks and final integrity. W1 is accepted as checkpoint 5. Earlier pending statements above describe the sequence of retained evidence. This does not certify the unfinished W2/G1 campaign or claim hardware power-loss validation.

## W2 page LSNs and flush barriers (accepted)

Fresh V2 databases now opt into physical page version 2 through an explicit WAL-anchor capability. This is separate from the WAL record version. Old V2 databases keep W1 forcing until the offline `migrate-page-lsn DATA_DIR EMPTY_BACKUP_DIR` command validates the WAL, forces a separate backup, completes recovery, and atomically changes that capability. Untouched legacy pages remain readable and upgrade only when logged. Older W1 decoders reject the capability before mutation.

Each changed heap or index image receives its own WAL record LSN and recomputed checksum before logging. The private image installed after COMMIT is exactly that logged image. Installation validates the page identity, full checksum and LSN against the matching durable transaction receipt. Pages cannot reach the base file before the WAL force. A failed installation fences the database until recovery.

After a successful WAL force, W2 writes committed images to the operating-system cache and retains their WAL. It does not force every data file on each commit. BEGIN does not force earlier WAL-protected committed pages. Checkpoint forces pending heap/index pages before replacing the WAL anchor; it runs after 64 commits or 16 MiB of WAL, and conservatively on metadata/file-lifecycle commits. Explicit CHECKPOINT follows the same barrier. This is deferred operating-system writeback, not a background writer or a new shared committed-page cache. Existing public low-level synchronization retains its force semantics.

Recovery preflights the WAL before changing data. It skips an image only when the existing page has a valid full checksum and identity, with an LSN at least as new as that record and no newer than the validated WAL horizon. Even skipped pages are forced before checkpoint, since a process crash may leave them only in the OS cache. Torn pages and checksum-valid impossible future LSNs are repaired from full-page images. Incomplete or aborted transactions never publish. WAL remains available if recovery or forcing fails. The buffer pool also preserves pin counts on dirty replacement and retains ownership of a dirty frame until write and synchronization both succeed.

The new acknowledged-crash runner captures parent-visible acknowledgments before injection, verifies their survival, checks the exact final atomic row model and indexes, and opens each database twice. It exercises partial WAL records, pre/post-COMMIT, page installation, forcing and checkpoint replacement. Controlled page damage is limited to pages covered by retained committed redo. Fast mode adds 24 such cycles to the existing 22; Milestone adds 250 and a ten-minute resource soak. These are software/process-crash tests, not hardware power-loss proof.

### Read measurement resolution

Original single-query indexed samples remain unchanged and retained. W2's initial short-sample review exceeded 10%, including a balanced range ratio of 1.1351. A separately labelled `indexed-profile` diagnostic repeats the identical point and 20-row range SQL 3,000 times per sample, including result validation and disposal. Fixture preparation is excluded. Identical diagnostic code was added to frozen S2/W1 benchmark drivers without changing their engine sources. Four balanced S2/W2/W2/S2 runs produced 14 samples per engine: point ratio 0.98787 and range 1.01202. W1/W2 ratios were 1.01566/1.05920. The physical fixture contents match after excluding format/LSN/checksum fields. Ordinary release profiling output contains only its header, confirming instrumentation is disabled.

The automated read gate now uses these longer indexed intervals with separately recorded raw baseline hashes; its 1.10 maximum ratio and zero noise floor are unchanged. Other read workloads retain their original suite measurements. Reports preserve original short indexed samples as diagnostics. The original failed reports are not overwritten. PostgreSQL's historical results and workload harness remain unchanged and PostgreSQL is not rerun.

### W2 read-regression fixes and accepted performance measurements

The first seven-sample balanced review after adding page LSNs retained a grouped-aggregate regression (1.1157), while startup was within budget (1.0544). Two narrow ownership fixes remove duplicated read work: index range traversal retains the validated first leaf returned by descent, and the collecting external sorter moves owned input rows into spill runs instead of cloning all payloads and retaining a second input through merge. Stable ordering, index checks, aggregate semantics and durability are unchanged. The seven index tests and 30 execution tests passed before the full gate rerun. The legacy collecting sorter still materializes its final output; bounded streaming uses its separate producer/sink path.

The latest `w2-milestone-owned-sort` run passes strict 100K and 1M read budgets using seven current samples per workload. The same fixed S2 baseline files and 1.10 threshold remain in use. At 100K, ratios are point0.7796/range0.9128/fullscan1.0849/scanaggregate1.0414/join1.0201/group1.0217/sort0.8332/readers0.9281/startup1.0087. At 1M they are point0.7862/range0.8982/fullscan1.0094/scanaggregate1.0043/join0.9855/group0.9554/sort0.9456/readers0.8413/startup1.0078. All failed intermediate reports remain available. The checker tests explicitly cover the exact threshold, over-budget rejection, invalid individual samples, incompatible operations and preservation of short-query diagnostics.

Relative to the original embedded P1 runs, median W2 speedups at 100K are INSERT autocommit8.15x, explicit INSERT3.21x, UPDATE9.22x, DELETE13.39x and concurrent writers33.27x. At 1M they are8.95x/6.97x/15.37x/13.76x/52.57x. These are whole embedded workloads, not pure commit latency. Their first small write can include synchronizing a newly copied fixture. `embedded-review.json` retains exact medians, sample counts, hashes and configuration checks; steady TCP and phase-specific profiles must be considered separately. No PostgreSQL result was regenerated or estimated.


W2 final Milestone gate reached `PHOBOS PERFORMANCE V2 MILESTONE CHECKPOINT PASSED` in `w2-milestone-owned-sort`. This includes 120 routine tests (zero failures; three pre-existing ignored long-soak tests), 16 focused WAL tests, four migration tests, 22 existing crash cycles plus 24 and 250 acknowledged page-LSN cycles, Phase 7/8, documentation, all read budgets, and ordered/unordered streaming. The 600-second soak passed in 602.2 seconds. The official client/server memory checks passed scan, sort, join and grouping at both 10K and 1M rows, followed by offline integrity. The earlier failed performance runs remain evidence; none were relabelled as passed. W2 is checkpoint 6, not a release certification or hardware power-loss claim.

## G1 measured commit coordination

`phobos-bench --mode commit-profile --dir PRELOADED_BASE --output NEW_DIR/raw.csv --rows 100000 --samples 3 --operations 32 --connections 1` measures steady coordinator commits. Repeat with 4 and 8 connections. Run ordinary release builds for latency/throughput, then a separate `--features profiling --target-dir target/v2-profile` build for costs. Copied files are forced and one warmup commit establishes the committed WAL-protected state before timing. Every response must acknowledge one insertion; every inserted value is checked through its index after two reopens, followed by offline administration integrity. This is a diagnostic; the historical SQL comparison campaign remains unchanged.

Measured normal-build median throughput was126.19,151.64 and143.20 transactions/s at1,4 and8 clients. Corresponding p50 latencies were6.39,12.26 and12.60 ms; p95 values9.79,42.32 and130.01 ms; p99 values61.10,401.52 and791.61 ms. These are finite local samples, including coordinator admission and full response completion, not guarantees. All2,496 timed commits across normal/profiling runs passed exact value/reopen/integrity checks. `g1-analysis/review.json` contains each profile, workload metadata, hashes and latency distributions; `tools/v2-commit-summary.py` reproduces the calculations.

W2 performed32 WAL fsyncs for32 timed commits with one client,132 for128 with four, and264 for256 with eight. Additional fsyncs are periodic complete-anchor checkpoint forces. Transactions per WAL fsync were1.000,0.970 and0.970. WAL force time accounted for8.1–14.3% of serialized autocommit execution in the profiling runs. Inclusive lock-wait spans overlap across threads and must not be added to execution/force time.

The safe serialized fallback is retained. There is no implemented commit batcher and no acknowledgment before durability. The coordinator holds one mutable Database, and the V2 writer owns only one active transaction until its COMMIT force completes. Releasing that lock around fsync would allow another transaction to interfere with private pages, catalog state and visibility; merely queueing requests outside the lock would not share a force. Real batching requires bounded pending private transaction ownership, dependent uniqueness/read semantics, ordered installation and failure fan-out, plus new crash boundaries. Current measurements identify broader transaction setup/install and coordinator contention, with fsync a minority of serialized time. A batching redesign is not justified as a narrow final change in this campaign. This completes the investigation requested by the approved plan, not a claim that group commit exists.


G1 changes only the benchmark driver, analysis tooling and documentation: every other crate file matches frozen W2, and the server executable SHA256 remains `f39370b3bb5545e38e2eda139484c914cf37c7d1fc6440d6fa62cd1a0079aac2`. Its first Fast run against historical S2 flagged join timing at1.1176; that report is retained in `g1-final-fast`. Iteration now defaults to the last accepted W2 checkpoint (`benchmarks/performance-v2-checkpoints/w2`), whose original raw bytes/hashes are preserved, with the same strict10% limit. Use `-ReadBaselineDirectory benchmarks/performance-v2-reference` for the historical cumulative S2 comparison; W2 already passed that full100K/1M review. Neither baseline directory contains regenerated PostgreSQL results. A per-checkpoint pass is not a claim that every later historical timing sample was within10%.


G1 reached `PHOBOS PERFORMANCE V2 FAST CHECKPOINT PASSED` in `g1-w2-fast`: formatting, strict all-feature Clippy,120 routine tests,16 focused WAL tests,four migration tests,46 crash cycles,100K read budgets, ordered/unordered streaming and separate-process memory/integrity checks all passed. The maximum read ratio against frozen W2 was1.0778 (sort); engine crate sources and server binary remained unchanged. This accepts checkpoint7 as the measured investigation with serialized fallback.


## Final campaign results

All seven checkpoints are complete, with measured serialized commit fallback. The final Phobos-only TCP comparisons passed all workloads and offline integrity at100K and1M. At1M, small-write speedups versus the saved P1 streaming control range520�753x; recorded PostgreSQL remains about9�27x faster on those write workloads. All final1M TCP reads remain within10% of P1. The5M embedded suite passed17 workloads in19.06 minutes, with695.15-second bulk load and2.574 GiB sampled peak private memory in the collecting benchmark process. No10M or new two-hour release certification was run. The clean final report is [performance_v2_campaign_report.md](performance_v2_campaign_report.md); all intermediate failures and baseline provenance remain preserved.
