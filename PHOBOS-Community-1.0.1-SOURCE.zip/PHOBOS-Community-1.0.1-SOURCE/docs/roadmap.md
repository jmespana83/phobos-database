# Roadmap

- Phase 0: foundation and executable specification — complete and validated.
- Phase 1: durable single-user storage — complete and validated.
- Phase 2: SQL data manipulation — complete and validated.
- Phase 3: transactions and crash recovery — complete and validated.
- Phase 4: disk-backed B+ tree indexes — complete and validated.
- Phase 5: multi-client concurrency baseline — complete and comprehensively validated through the coarse strict-2PL milestone.
- Phase 6: relational execution and optimization — **candidate in this tree**, pending local Rust gates and Phase 6 functional validation.
- Phase 7: operational/security hardening.
- Phase 8: measured performance campaign and transparent PostgreSQL comparisons.

## Phase 6 candidate scope

Inner/left equi-joins, hash join plus bounded block nested-loop fallback, GROUP BY/HAVING, COUNT/SUM/AVG/MIN/MAX, ANALYZE statistics, cost-aware scan choice, external sort/spill, and EXPLAIN/EXPLAIN ANALYZE. See `phase6_relational_execution.md`.
