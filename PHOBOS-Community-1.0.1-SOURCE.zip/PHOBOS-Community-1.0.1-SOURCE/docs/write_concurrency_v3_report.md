C3 checkpoint update: see [the C3 report](write_concurrency_v3_c3_report.md) and [C3 writeback design](write_concurrency_v3_c3_design.md). C3 passed Fast correctness and is frozen; performance remains mixed. C4 has not started. The historical C1 report follows unchanged below. [C2 evidence](write_concurrency_v3_c2_report.md) remains available.

# Write & Concurrency V3 — checkpoint evidence

C1 accepted and frozen on 2026-09-13. C2–C8 have not started; the overall V3 campaign
is incomplete. Accepted evidence is `c1-fast-03`, packaged under `outputs/write-v3/c1`.
The certified beta source and saved PostgreSQL measurements remain immutable.

## C1 implementation

`Wal::append_commit` returns an opaque PendingCommit tied to a writer lifetime.
It closes that transaction's WAL chain but does not authorize page installation.
`force_commits` validates the complete ordered pending batch, synchronizes the WAL
under exclusive writer ownership, and only then returns private-field durable
receipts. Tickets from another writer lifetime, reordered/incomplete batches, and
reused tickets are rejected. Physical append/force failure fences the WAL domain;
no affected receipt is returned. The synchronous `commit` adapter remains available.

Frozen scratch pages move into per-file ordered PreparedPages queues owned by the
Database. PreparedCommit owns the matching ticket and transaction-directory identity;
the server queue owns SQL requests and completion senders. These lifetimes jointly
retain every file until force and ordered installation finish. Heap free-space and
index root/allocation state advance with serialized predecessor generations. A
successor reads private predecessors; its rollback restores their pages and derived
state. Public readers cannot enter this view: a Database guard spans preparation,
force and publication, and queued read/DDL/BEGIN admission drains prior groups.

D4 assigns a cache-resident overlay page its final WAL LSN and checksum before its first scratch write, then appends the identical image under the existing writer ownership. Pages evicted from the bounded cache keep the spill-and-rewrite fallback; durability still uses the existing single group force.

The engine group API accepts at most 64 requests. The server permits at most 64
waiting requests plus the executing group, rejecting overload with ResourceLimit.
Before appending a successor's redo, its private frames are drained and changed-page
count provides a conservative bound on WAL bytes. Previous commits are forced before
the group would exceed 1 MiB. An oversized transaction uses the existing bounded
scratch page cache/spool and is forced alone. An active successor's BEGIN can be
incidentally forced with predecessors, but it receives no COMMIT receipt. Its private
state survives that installation; checkpoints still reject active transactions.

Autocommit INSERT/UPDATE/DELETE on page-LSN V2 databases can batch. Statistics-bearing
execution conservatively retains the synchronous path until invalidation is persisted.
DDL, legacy formats and explicit transactions retain synchronous semantics. Buffered
and negotiated streaming protocol DML use the same queue and preserve affected-row
counts. Disconnect after submission cannot cancel a potentially committed request.
Success is delivered only after complete heap/index publication. Any postdurability
installation error fences the owner and requires recovery, never rollback of a commit.

Lock order is owner admission -> group queue; Database is acquired after releasing
the group queue. Batch execution never acquires owner while holding Database. Queue
completion clears running under owner -> queue and notifies owner waiters. Network
delivery occurs after Database execution returns. A completed batch leader hands
leadership to an already queued waiter and promptly returns its own result. It does
not drain other clients' future batches before returning. A deterministic test holds
the Database guard to distinguish current and later batches and checks this handoff.
C2 will further separate the WAL
owner and execution guards; C1 does not claim concurrent writer execution or MVCC.

## Formats and durability

No record codec, heap/index format, on-disk version, migration behavior, durability
setting, authentication, TLS or protocol capability changed. Fresh and existing V2
databases use their recorded capability. Legacy formats remain on the old adapter.
Only durable matching receipts permit page installation. Page-LSN force barriers and
complete checkpoint ordering remain enforced. Database recovery is required after
fencing. Scratch files close before Windows deletion through the existing cleanup
guards. No timing retry loop or durability suppression was introduced.

## Measurement policy

First controls are retained in `c1-fast-01`, including an archive of their exact
source. Normal and instrumented binaries are separate. Controls measured 100K/1M,
1/4/8 clients, three samples of 32 transactions per client, and 0/50/200 us windows.
Windows timed waits made nonzero collection windows cost about 15 ms at low load.
At 1M, normal single-writer median latency was 6.35 ms with zero delay versus
16.28 ms with 200 us. The default is therefore zero collection delay; queued requests
still share forces when they accumulate during execution. The optional environment
control PHOBOS_GROUP_WINDOW_US accepts 0–200 and does not change durability.

One instrumented first-attempt 100K/4-client/zero-window sample committed 128
transactions with 76 commit forces. This is actual Coordinator integration, not a
standalone WAL microbenchmark. Final measurements follow the budget/barrier revision.
No PostgreSQL rerun, 10M run, or soak was performed.

## Accepted validation and measurements

Formatting and format check passed. Strict workspace/all-target/all-feature Clippy
passed without new suppressions. Workspace tests: **132 passed, 0 failed, 3 preexisting
ignored soak tests**. Documentation and normal release builds passed. Both 100K and
1M embedded suites produced 49 successful records; both matched TCP suites produced
43 successful records and passed offline integrity. Every steady-commit fixture
checks acknowledged rows and reopens twice. Separate profiling and certification
builds preserve the normal-binary measurements.

The final gate ran 20 group crash cycles, 24 parent-observed acknowledged page-LSN
cycles and six suite recovery cases: **50 targeted cycles**. Coverage includes
unforced records, durable commits, interrupted installation, dirty-page writes and
forces, checkpoint replacement, damaged/future-LSN pages and repeated recovery.
The page-LSN campaign reached `PAGE LSN CRASH PASS cycles=24`; the complete runner
reached `PHOBOS WRITE V3 FAST GATES PASSED`. These are process-crash/fault checks,
not a hardware power-loss experiment. Earlier development attempts and their
repeated checks are retained separately; 50 is the final gate's count.

Matched TCP medians, milliseconds (three samples; same SQL, scale and operation
counts as the saved V2 Phobos baseline):

| Scale | Workload | Saved V2 | C1 final | C1/V2 |
| --- | --- | ---: | ---: | ---: |
| 100K | Three autocommit inserts | 17.2540 | 12.9705 | 0.752 |
| 100K | Three inserts in one transaction | 5.4481 | 5.4437 | 0.999 |
| 100K | Four clients, twelve inserts | 63.9779 | 56.3086 | 0.880 |
| 1M | Three autocommit inserts | 13.3813 | 13.5023 | 1.009 |
| 1M | Three inserts in one transaction | 6.0315 | 5.0912 | 0.844 |
| 1M | Four clients, twelve inserts | 60.5748 | 50.1651 | 0.828 |

The final 1M autocommit median is 0.9% slower than the saved V2 median. Small sample
counts and observed timing variability do not establish universal speedup. The
matched concurrent-writer median improved 17.2%. The fixed PostgreSQL medians remain
0.7059/0.6788/2.2723 ms for those three 1M workloads; the final campaign's <5x target
remains open. No PostgreSQL timing was rerun or estimated. Saved CSV SHA256:
`047e2ad0cb660845ddbe3f691817a0a4c49b9f2de2cfe1a1ff058234f54c889e`.

Steady commits: zero configured collection delay, three samples, 32 transactions
per client. TPS is median normal-run throughput; latency quantiles pool the normal
samples. Force counts are summed across the separate instrumented samples. WAL
force totals also include checkpoint synchronization.

| Scale | Clients | TPS | p50 ms | p95 ms | p99 ms | Commits | Commit forces | All WAL forces |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100K | 1 | 131.97 | 6.06 | 9.41 | 54.91 | 96 | 96 | 96 |
| 100K | 4 | 153.80 | 22.13 | 60.98 | 86.21 | 384 | 192 | 204 |
| 100K | 8 | 212.32 | 36.77 | 63.70 | 108.64 | 768 | 191 | 211 |
| 1M | 1 | 109.87 | 6.23 | 29.61 | 58.31 | 96 | 96 | 96 |
| 1M | 4 | 174.71 | 21.35 | 60.21 | 82.00 | 384 | 192 | 204 |
| 1M | 8 | 202.31 | 38.45 | 58.37 | 90.53 | 768 | 192 | 216 |

At 1M/eight clients this is **4.00 transactions per commit force**, or **3.56 per
WAL force including checkpoints**. `group-summary.json` retains per-sample batch
size buckets, mean queue wait, and inclusive preparation/publication/force timing.
Inclusive spans overlap and must not be summed as exclusive CPU time. The engine
still serializes execution and installs pages on publication; C2/C3 address those
remaining costs. The source and normal/profile/crash executable hashes are frozen
with the evidence, and normal build-source hashes were checked against the final tree.

## Files changed from the certified source

- `crates/phobos-wal/src/v2.rs`, `v2/log.rs`: pending tickets, force receipts,
  fencing, checkpoint guard, counters and fault/ordering tests.
- `crates/phobos-storage/src/page_io.rs`, `src/lib.rs`: ordered owned page
  generations, predecessor reads/rollback, successor preservation and sizing.
- `crates/phobos-index/src/lib.rs`: pending-generation ownership and sizing while
  retaining derived root/allocation state.
- `crates/phobos-execution/src/lib.rs`, `src/private_transaction.rs`, new
  `src/group_commit.rs`: bounded DML groups, ordered publication, failure handling,
  oversized path, crash and dependent-write tests.
- `crates/phobos-server/src/lib.rs`: bounded admission, drain barriers, shared
  buffered/streaming DML, completion handoff, metrics and coordination tests.
- New `tools/write-v3-fast.ps1`, `tools/write-v3-group-summary.py`: reproducible
  development gates and separate normal/profile measurements.
- `docs/write_concurrency_v3_plan.md`, `docs/write_concurrency_v3_report.md`:
  approved plan, scope and evidence. `changed-files.json` records exact file hashes.

## Reproduction

Use Rust 1.85 MSVC and the existing Python comparison dependencies, then run:

```powershell
.\tools\write-v3-fast.ps1 -OutputDirectory <new-evidence-directory> -Python <python-with-comparison-dependencies> -Windows 0
```

Omit `-Windows 0` to repeat the full timing-window experiment. The runner refuses
to overwrite evidence, runs formatting, strict Clippy, workspace tests, docs,
release, 100K/1M suites, Phobos-only matched TCP workloads, normal/profile writer
controls and focused page-LSN/checkpoint crashes. The final gate includes 20 group
crashes, 24 page-LSN/checkpoint crashes, and six suite recovery cases: 50 targeted
cycles. Existing longer soak tests remain unchanged and explicitly ignored as before.

## Remaining campaign milestones

C2: finer WAL/execution synchronization. C3: background dirty-page flushing.
C4: checkpoint v2. C5: explicit Read Committed tuple/version visibility and migration.
C6: finer transaction/lock coordination. C7: dedicated bulk loader. C8: batched index
maintenance. None is claimed implemented by C1. Final 10M and fixed PostgreSQL target
evaluation remain deferred until the final architecture milestone.
