# Storage format — through Phase 4 candidate

## Heap page files

Heap files use fixed 8192-byte pages and little-endian numeric fields. A heap page begins with magic `PHOP`, format version 1, page type, page ID, lower/upper free-space bounds, slot count, and a 32-bit corruption-detection checksum. Slot entries are 4 bytes: 16-bit tuple offset and 16-bit tuple length. A zero tuple length is a tombstone.

Heap free-space selection is non-durable derived state. It is rebuilt lazily after open, verified against each selected page, and corrected when stale; page contents remain authoritative.

The checksum field is zeroed while the checksum itself is calculated. Every page read validates magic, format version, bounds, slot references, and checksum before exposing tuple bytes.

## Row encoding

Rows are schema-aware. The row begins with a 16-bit column count followed by a NULL bitmap. Non-NULL fields then appear in schema order:

- BIGINT: signed 64-bit little-endian.
- BOOLEAN: one byte, 0 or 1.
- FLOAT/DOUBLE: IEEE-754 f64 bits, little-endian.
- TEXT/BINARY: 32-bit byte length followed by bytes; text must be UTF-8.
- DATE: signed 32-bit days since 1970-01-01.
- TIMESTAMP: signed 64-bit microseconds since 1970-01-01 UTC.
- DECIMAL: signed 128-bit unscaled integer; scale is catalog metadata.

## Catalog

`catalog.phc` retains table metadata with magic `PHOC`, format version 1, next table ID, table count, table/column metadata, and a trailing FNV-1a checksum. Phase 4 adds `indexes.phc` with magic `PHCI`, version 1, next index ID, index/table relationships, ordered index column names, uniqueness, and a checksum. Catalog rewrites go through temporary files and rename.

## B+ tree index files

Each index is stored in `index-<id>.idx` using fixed 8192-byte pages. Page 0 has magic `PHIX`, format version, uniqueness flag, key-column count, root page, next allocatable page, and checksum. Node pages use magic `PHIN`, node type, page ID, parent ID, next-leaf pointer, entry count, used-byte boundary, and checksum.

Leaf entries store an encoded composite key plus `(heap_page_id, slot_id)`. Internal entries store separator keys and right-child page IDs plus a first-child pointer. Leaves are linked from left to right. Inserts split leaf/internal pages and may create a new root. Deletion removes exact entries but does not merge under-full nodes in Phase 4.

## WAL interaction

Phase 3's WAL logs committed transaction snapshots as checksummed file-image chunks. Phase 4 extends the durable database-file set to include `.idx` files, so committed index changes are redone together with catalog and heap files after a crash. Startup removes orphaned `.idx` files that are no longer referenced by `indexes.phc`.

## B3 checksum compatibility (Community 0.1.9-B3+B4+B5)

Heap (`PHOP`), index metadata (`PHIX`) and index node/free (`PHIN`) headers use
byte 7 as an explicit checksum-scheme selector: 0 = legacy FNV-1a, 1 = CRC32C.
Unknown selectors are rejected. The existing four-byte checksum field is treated
as zero during calculation; offsets and physical page sizes are unchanged.
This selector is independent of heap tuple/LSN format versions and of tuple
envelope hint flags. New or rewritten pages use CRC32C; untouched FNV pages remain
readable alongside them. No bulk/destructive migration occurs. Preserve a backup
before upgrading: older binaries cannot read CRC32C pages (downgrade unsupported).

WAL page-image validation dispatches on the same selector. Stamping an image
upgrades its checksum before WAL encoding, and exactly that image is installed.
V1/V2 WAL record framing/checksums, capability numbers, recovery ordering, catalog
and transaction-status formats are unchanged. Private overlay files are temporary,
not restart inputs; their full-record/page checksums now use CRC32C directly.
The `crc32c` crate supplies hardware dispatch and a portable fallback; PHOBOS adds
no custom SIMD.

## B4 borrowed index reads

Ordinary point/range and committed-reader traversal use a read-only page view.
The existing packed format has no persisted slot directory, so the view derives
a bounded stack offset table, validates entry framing/keys, and binary-searches
encoded keys without allocating owned text/binary keys. Only returned entries
are materialized. Mutation, splitting and offline tree validation retain their
owned representation. Key encoding/order, signed-zero/NaN semantics, parent
pointers and physical index layout are unchanged.

## B5 lazy heap open

Heap open checks file-size alignment and the first/tail pages, rather than
checksumming every interior page. Free-space hints for other pages are unknown
until an insert considers them. Physical reads continue to validate checksums,
identity and tuple capability before exposing data. `phobos-admin check` still
traverses every heap/index page; opening a database is not a full integrity check.
WAL/recovery startup is unchanged. The existing A1 compatibility guard for UNIQUE
indexes containing floating-point columns still scans the heap at database open
to reject legacy canonical-equality duplicates; this deliberate exception remains.

## F4 wide-row overflow

Versioned rows whose encoded tuple envelope does not fit one heap page retain a
normal heap slot and `RecordId`. That slot contains a version-2 `PHMV` envelope
with the total payload length, first overflow page, page count and CRC32C. The
payload is split across `PHOP` version-3 pages marked as overflow pages. Each
chunk records its ordinal, checked length, total length and next-page link.
Readers bound the allocation from the declared page count and reject cycles,
missing pages, reordered/truncated chunks, invalid offsets and checksum mismatch.

Overflow pages use the same private-page, page-image WAL, force and install path
as other heap pages. Reclamation validates a complete chain before clearing its
pages. Empty overflow pages are reused without shrinking the heap file. Inline
rows and index key/value formats are unchanged. Encoded row payloads remain
bounded by the 32-bit row/overflow length fields (less than 4 GiB).

## 0.2-D compact page redo (WAL V3 records)

Record framing (44-byte `PHWL` header, version 2, CRC32C record checksum) is
unchanged. Two record kinds are added; both require the CRC32C record flag:

* **15 `PageDelta`** — file (9) · page (8) · action (1) · base LSN (8) · base
  page checksum (4) · result page checksum (4) · ops. Ops are `0x01 WRITE
  u16 offset, u16 length, bytes` and `0x02 MOVE u16 dst, u16 src, u16 length`
  (memmove), applied in order; every op is bounds-checked at decode. The
  checksums are the pages' own embedded CRC32C page checksums. Redo applies the
  ops only to the exact base image, then re-stamps scheme byte, page LSN and
  checksum; the recomputed checksum must equal the logged result checksum.
* **16 zero-elided page image** — file · page · action · ascending `WRITE`
  ops over an all-zero page. It decodes to the same full image as a V2 page
  record (kinds 2/3/4/5/8) and uses the same validation and redo.

Anchors written by 0.2-D set flag bit 0x10 in header byte 7 (page format in
the low bits as before). Older binaries reject the flag during preflight.
Heap, index, catalog and status file formats are unchanged. See
`wal_v3_compact_redo.md` for the full-page-image policy and recovery argument.

## 0.2-E preallocated write-through WAL segments

A Mode E active segment (anchor flag bit 0x20) is preallocated in 4 MiB
zero-filled extents that are flushed before any record is written into them.
Its logical end is the end of the valid record prefix; the remaining bytes
must be zero, except a torn final write (non-zero bytes confined to 320 KiB
after the prefix) in the active segment. Sealed segments must end in zeros.
See `wal_v3_windows_durable_wal.md`.

## 0.2-K slot lifecycle (ordinary versioned heap pages)

The 4-byte slot entry `(offset, len)` encodes four states. No byte was added and the page format version is unchanged:

| State | `len` | `offset` | Meaning |
|---|---|---|---|
| OCCUPIED | > 0 | inside `[upper, 8192)` | a tuple |
| RETIRED | 0 | ≥ 44 (stale) | a reclaimed version whose RID may still be referenced by a running statement. Identical to every tombstone written before 0.2-K. Never reused. |
| FREE | 0 | 0 | reusable. Created only by the horizon-gated RETIRED → FREE transition, and only on format-3 non-overflow pages. |
| VACANT | — | — | slot id ≥ `slot_count` (trimmed, reset or never allocated) |

- Header flag byte 30, bit `0b100` (`PAGE_FLAG_FREE_SLOTS`), is a conservative hint that the page may hold FREE entries.
- Page validation rejects `len 0` with an offset in `1..40`, and FREE entries on format-1/2 or overflow pages.
- Trailing FREE entries may be removed (`slot_count` and `lower` shrink).
- A page whose entries are all FREE may be reset to an empty versioned page.
- Older binaries read FREE entries as tombstones.

See `docs/storage_lifecycle_0_2_k.md`.
