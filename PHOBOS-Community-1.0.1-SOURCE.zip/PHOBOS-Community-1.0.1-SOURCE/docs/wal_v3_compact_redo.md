# WAL V3 — compact page redo (PHOBOS 0.2-D)

Status: implemented in 0.2-D. This note is the design and recovery argument;
measurements are in the 0.2-D report.
The 0.2-C commit pipeline (Stage A prepare + append, out-of-lock single-flight
force, ordered Stage B publication, strict durable receipts) is unchanged;
only the bytes Stage A writes for each changed page change.

## 1. Where 0.2-C WAL volume comes from (measured)

Every changed heap/index page was logged as a full 8,192-byte image in a
44-byte-header record (plus a 17-byte file/page identity). A single-row
INSERT into a table with a UNIQUE and a secondary index writes BEGIN,
MVCC-identity, three page images and COMMIT: **24,899 bytes, of which
24,576 (98.7%) are page images**; the logical change is one ~60-byte tuple
and two ~25-byte index entries. Measured byte-level differences between each
logged image and the previous image of the same page are 29 bytes (UNIQUE
leaf, append), 81 bytes (heap) and ~1.3 KB of *shifted* bytes (secondary
leaf, mid-page insert). See `evidence/wal-amplification/`.

## 2. Options considered

**A. Physical byte-range patches** (`page, offset, length, bytes`, guarded by
the base page identity). Generic: one encoder/decoder for every page type, no
knowledge of heap or B+tree layout. Replay reproduces the exact image the
encoder saw, so its result can be checked bit-for-bit. Weakness: an insert in
the middle of a packed B+tree leaf shifts every later entry, so a pure
byte-range diff is large (~1.3–1.9 KB measured).

**B. Physiological operation records** (`HeapInsert(slot, tuple)`,
`IndexLeafInsert(key, rid)`, `IndexSplit`, ...). Most compact, but redo must
re-execute heap and B+tree page logic inside recovery. Every page-format
detail (slot allocation, free-space compaction, leaf packing, separator
choice, tuple envelopes, overflow chains, reclamation) becomes recovery
code that must stay bit-identical to the forward path, or replay silently
diverges. The proof obligation is "two implementations agree", for every
operation.

**C. Hybrid** — compact records for ordinary modifications, full-page images
where a compact record is unsafe or not smaller.

**Chosen: C, built from A plus one `move` primitive.** A delta is a short
program over the page: `WRITE(offset, bytes)` and `MOVE(dst, src, len)`
(memmove within the page). The encoder finds the shifted run of a mid-leaf
insert/delete (one MOVE plus the new entry), so the secondary-leaf case
drops from ~1.3 KB to ~60 bytes, without recovery knowing what a leaf is.
Operation intent (heap insert/update/delete, index) is still recorded as
the record's action label, as in V2. Correctness reduces to one property
that is checked on both sides: *applying the ops to the base image yields
exactly the logged result image.*

## 3. Record formats

Framing is unchanged (44-byte `PHWL` header, version 2, CRC32C over the
whole record, flag 4). Two record kinds are added:

| Kind | Name | Payload |
|---|---|---|
| 15 | `PageDelta` | file (9) · page (8) · action (1) · base LSN (8) · base checksum (4) · result checksum (4) · ops |
| 16 | `PageImage` (zero-elided) | file (9) · page (8) · action (1) · `WRITE` ops against an all-zero page |

`ops` = sequence of `0x01 WRITE u16 off, u16 len, bytes` and
`0x02 MOVE u16 dst, u16 src, u16 len`. Every op is bounds-checked at decode.
The base/result checksums are the pages' own embedded CRC32C page checksums
(computed over the full page, checksum field zeroed), so they identify the
complete 8 KB images.

Kind 16 decodes to exactly the same in-memory full image as a V2 page record
(kinds 2/3/4/5/8) and goes through the unchanged image redo path. The encoder
picks kind 16 only when it is smaller; a full page stays a raw V2 image.

## 4. When a full-page image (FPI) is written

The WAL writer itself decides, under its own lock, per changed page:

1. **No base** (page allocated by this transaction, new file, legacy
   page-format-1 database) → FPI.
2. **First touch of the page in the active WAL segment** → FPI.
3. **Base mismatch**: the base image the storage layer supplied must carry the
   LSN *and* page checksum of the last image this segment logged for that page
   (tracked in a per-segment map, reset at every rotation/rewrite). Anything
   else → FPI.
4. **Delta not smaller** than the (zero-elided) image → FPI.
5. Encoder self-check: the ops are applied to a copy of the base and must
   reproduce the result image byte-for-byte; otherwise → FPI.

Otherwise a `PageDelta` is written. Structural B+tree changes (split, new
root, new right sibling) are covered without special code: new pages are
case 1, and the left half of a split, a parent receiving a separator and the
metadata page are ordinary deltas when they are small and FPIs when they are
not (case 4).

## 5. Why a first-touch FPI rule is required (and why per segment)

* **Torn pages are possible.** Committed pages are written back by an 8 KB
  positioned write (`committed_pages::flush_target`) on file systems whose
  atomic unit is 4 KB, and Linux can return a short buffered write on a fatal
  signal between page-cache pages. A crash can therefore leave a page whose
  halves come from different versions.
* **The page checksum detects it** (CRC32C over the whole page, validated
  before any redo decision), but detection is not repair.
* **A delta cannot repair a torn page**: it needs a valid, exact base.
  0.2-C repaired torn pages because every retained record was a full image.
* **Retention is segment-granular**: a checkpoint deletes whole sealed
  segments whose last LSN is ≤ the safe LSN; the retained WAL is a suffix of
  segments, and recovery replays all of it.

Claim: if the first record of every page in every segment is an FPI, every
page can be reconstructed from (data file + retained WAL).

* A page that is valid on disk with LSN P: all of its changes > safe are in
  retained segments (they are not retired), and the checkpoint contract
  (fuzzy checkpoint: safe = min(target, oldest dirty/unforced rec_LSN − 1))
  guarantees its on-disk image contains every change ≤ safe. Records ≤ P are
  skipped; the first record > P is either an FPI or a delta whose base is the
  segment-local predecessor, i.e. exactly P.
* A torn page: the torn write wrote a version containing at least one change
  newer than its previous complete write; such a change is > safe (it was
  dirty or unforced when safe was computed, or it was made later), so it lies
  in a retained segment. Recovery meets this page's records in order; the
  first one in the earliest retained segment that holds any of them is an FPI
  by the rule, and it is applied because the page is invalid. Every later
  delta then finds its exact base.

A rule keyed to the checkpoint safe LSN instead of the segment would be wrong
here: a retained segment can start before the safe LSN, so a delta in it could
need a base from a retired segment.

The cost is one image per touched page per 64 MB segment, after rotation,
after recovery and after a full WAL rewrite. PostgreSQL pays the same
(per checkpoint). A double-write buffer would move torn-page protection from
the WAL to background write-back; it is deferred (§9).

## 6. Recovery (idempotent, repeatable)

Per committed record, in commit order, for a paged file:

* **FPI** (V2 image or kind 16): skip if the on-disk page is valid with
  LSN ≥ record LSN; otherwise write the image (unchanged V2 behavior).
* **PageDelta**: read the on-disk page.
  * valid and LSN ≥ record LSN → skip (already applied);
  * valid, LSN = base LSN and page checksum = base checksum → apply ops,
    re-stamp LSN/checksum, require page checksum = result checksum, write;
  * anything else (torn, missing, older/foreign base) → the page is marked
    *unresolved*; a later FPI of the same page clears it. Recovery fails
    closed, before any WAL rewrite, if a page is still unresolved at the end.

Because the skip test uses the page LSN, and the apply test requires the exact
base, a second or third recovery (including one interrupted part-way through
redo) re-derives the same bytes and never re-applies an op.

A segment now holds ~30x more records, so redo keeps the pages it has read or
written in a bounded cache (dropped before, refilled after, every write) and
all WAL scans read through a 1 MiB buffer instead of two system calls per
record.

Segment rotation renames the forced active file to a sealed segment, then
creates and forces the next active file with its anchor. A crash between the
two leaves no active file or one shorter than a complete anchor; scans treat
the newest sealed segment as the end of the log and writer recovery renames it
back before redo (0.2-C failed closed in that window).

## 7. Compatibility

* 0.2-D reads every 0.2-C record (FNV-1a or CRC32C, kinds 0–14) and every
  sealed 0.2-C segment.
* Anchors written by 0.2-D carry a new flag bit (0x10, "compact redo").
  When 0.2-D opens a writer on a WAL whose active anchor lacks it (a cleanly
  shut down 0.2-C database), it first rewrites the anchor; V3 records only
  ever follow a V3 anchor.
* 0.2-C rejects a 0.2-D anchor (`unsupported V2 WAL flags`) during its
  read-only preflight, before any redo or truncation: downgrade is refused,
  never misread.

## 8. Writer cost

Deltas are encoded straight into the WAL write buffer (no per-record `Vec`),
so the record checksum covers ~100 bytes instead of ~8 KB, and the writer
copies a few hundred bytes instead of three 8 KB images. The added work is a
word-wise compare of base and result, a bounded shift search, one verifying
apply, and a CRC of the base image (to validate it); all are bounded by the
page size.

## 9. Not done / deferred

* Physiological B+tree records (option B): not needed for size; risk too high.
* Double-write buffer instead of first-touch FPIs.
* Payload compression of FPIs.
