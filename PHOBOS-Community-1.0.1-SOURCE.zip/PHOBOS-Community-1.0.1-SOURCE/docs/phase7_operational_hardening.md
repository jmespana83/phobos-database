# Phase 7 — Operational hardening

Phase 7 turns the Phase 0–6 engine into a more defensible alpha server for controlled evaluation. It does **not** make Phobos production-ready.

## Implemented in this candidate

- Argon2 password hashing via the maintained `argon2` crate.
- Persistent authentication file with `reader`, `writer`, and `admin` roles.
- Coarse server-side authorization before SQL reaches the execution engine.
- Optional TLS 1.2/1.3 transport through `rustls`; clients validate the configured CA/certificate chain.
- Alpha safety rule: non-loopback binds require both TLS and authentication.
- Data-directory exclusive locking using OS file locks so two servers/admin operations cannot write the same database simultaneously.
- Configurable maximum concurrent connections, result byte limit, and transaction lock-wait interval.
- Operational counters for sessions, queries, query errors, authentication failures, lock timeouts, and response bytes.
- Admin-only protocol metrics request.
- Offline, lock-coordinated backup and restore commands.
- Integrity checking that opens the catalog/database and validates every cataloged B+ tree.
- Phase 7 validation covering password restart, authorization primitives, backup/restore, integrity, directory locking, and regression of Phases 0–6.

## Authentication file

Create users offline:

```powershell
cargo run -p phobos-admin -- user-add .\security\phobos.auth admin1 "change-this-password" admin
cargo run -p phobos-admin -- user-add .\security\phobos.auth app_reader "another-long-password" reader
```

The file stores Argon2 password hashes, never plaintext passwords.

## TLS

Start with a certificate and private key in PEM format:

```powershell
cargo run -p phobos-server -- --bind 0.0.0.0:54321 --data-dir .\data --auth-file .\security\phobos.auth --tls-cert .\certs\server.pem --tls-key .\certs\server-key.pem
```

The Rust client exposes `Client::connect_tls(...)` and validates the supplied CA/certificate material and server name.

## Backups

Phase 7 deliberately begins with an **offline** backup mechanism. The server must not hold the data-directory lock.

```powershell
cargo run -p phobos-admin -- backup .\data .\backup-001
cargo run -p phobos-admin -- restore .\backup-001 .\restored-data
cargo run -p phobos-admin -- check .\restored-data
```

An online checkpoint/WAL-coordinated backup is still future work.

## Roles

- `reader`: SELECT/EXPLAIN
- `writer`: reader permissions plus INSERT/UPDATE/DELETE and transaction control
- `admin`: all currently supported SQL, DDL, ANALYZE, CHECKPOINT, and metrics

These are intentionally coarse Phase 7 roles. Database/schema/table-level GRANT/REVOKE is not yet implemented.
