# C8 — bounded batched index maintenance

C8 changes only index work used by the frozen C7 loader. MVCC, table ownership,
WAL/group forcing, checkpointing, client protocol and durable page formats are
unchanged. Ordinary SQL continues using the existing per-entry index API.

During C7 input staging, unique scratch-tree entries are collected for the bounded
row batch and inserted together. Committed-key probes still use the existing
visibility checks under C7 table ownership. During private-page preparation,
changes are collected for one existing index at a time and inserted together.

The new index API accepts at most 1,024 validated keys (each at most the existing
2,048-byte key limit), sorts them by key/RID, and reuses the existing insertion,
duplicate detection and leaf/internal/root split functions. A batch-scoped cache
holds at most 64 decoded nodes. Changes coalesce in that cache; reaching the bound
flushes dirty nodes in page-ID order and clears the cache. Metadata is written
once at batch close when changed. Decoded-node memory exceeds encoded page size,
but the node count and each input batch are bounded. There is no whole-import
index change list or whole-index cache.

Sorting/page coalescing may produce a different valid tree shape. Equal-key
probe semantics, historical version entries, NULL handling and unique constraints
remain the same. A batch error requires the owning import to abort, as with C7;
its partial work is confined to private pages or disposable uniqueness scratch.
Batch close clears the cache and flushes metadata, including on constraint errors.
WAL preparation sees completed private page images through the existing C6/C7
page visitor. No additional commit, force or recovery mechanism is introduced.

Focused development commands:

```
cargo test -p phobos-index --lib c8_
cargo test -p phobos-server --lib c8_
```

These cover successful reverse-order indexed imports, splits across the cache
limit, duplicate rejection, NULL/composite keys, rollback, reopen/index integrity
and one crash at index publication after WAL durability. The final workspace gate
also retains all existing tests.

Reproduction:

```
./tools/c8-validation.ps1 -Evidence <new-gate-directory>
cargo build --release -p phobos-bench --features profiling
python tools/c8-measure.py --output <new-measurement-directory>
```

The measurement script runs only one final-source 100K C8 bulk import and one 1M
C8 bulk import. It refuses to repeat a verified result; `--resume` reuses successful
results only for the identical executable. Each measurement performs a committed
count, shutdown, one reopen/count/index lookup and one final offline integrity
check. Those verification operations are outside the import timer. The workload,
indexes, profiling flags and durability configuration match saved C7 results.
Compare against saved C7 evidence; do not run C7, ordinary SQL, PostgreSQL, 10M,
repeated performance trials or long soaks. No subsequent milestone is started.
