# Phase 8 performance engineering log

Baseline is the validated Phase 7 fixed ZIP (SHA256
7C26813E21BB09D41448B0650F7081DFE1552173AF8FEE13612044F9FFB82507), Rust 1.85.0,
x86_64-pc-windows-msvc. The starting source is an archive, not a Git checkout: no commit
ID is invented. Baseline validation was rerun before performance edits and passed.

## Measurement and environment

AMD Ryzen 7 5800X, 16 logical processors; Windows NT 10.0.26200, NTFS. RAM capacity and
physical storage type could not be read because the session denied CIM/storage queries;
they are explicitly unavailable. Resource wrapper records source hashes, executable hash,
Rust/OS/CPU, free disk, settings, command, UTC, process CPU and sampled memory.

Seed 8067, 100 buckets, fixed 17-character payloads, BIGINT NOT NULL fields, unique id
index; all normal durability and concurrency guarantees remain enabled. Headline results
use the ordinary portable release profile. No fsync, WAL, checksum, constraint, recovery,
authentication or TLS setting was weakened. Embedded/Coordinator results are not TCP results.
Raw files are under benchmarks/results. CSV times are nanoseconds; summary times are ms.

## Profiling method and limits

WPR GeneralProfile could not start: error 0xc5585011, system profiling privilege unavailable.
The failed attempt is retained. Fallback: opt-in `profiling` feature with inclusive wall-time
spans and event counters; disabled builds compile the span/event calls away. Profiler data
includes its own bookkeeping overhead and is not used as headline throughput data. Nested
span totals overlap; lock waits across threads also overlap. Do not add them as CPU time.
Process CPU comes from the wrapper, not these inclusive spans. Allocation counts and native
CPU stack samples are unavailable; allocation-site observations below are source analysis,
not measured allocation-profiler counts. No unsafe allocator shim was introduced.

Instrumented areas: SQL parsing; heap scans, row codec, buffer reads, hits/misses and flush;
index page I/O, checksums, decoding, lookup and writes; WAL snapshot construction, record
writes and sync latency; snapshot commit; server database lock waits/transaction-owner waits;
hash/nested-loop joins, aggregation, spill sorting; result text and protocol frame I/O.
Some paths require the appropriate workload to produce a nonzero span (e.g. protocol frames
need the TCP driver). Counters are process-local; crash-child work is excluded from parent
profiles. The wal.bytes counter counts emitted WAL records, not retained file size.

Focused baseline observations:
- 2K instrumented mixed suite: server.lock_database 10.79 s cumulative wait, commit_snapshot
  6.24 s, heap fsync 1.423 s / 4236 calls; WAL fsync 0.383 s / 754 calls. These are overlapping
  inclusive totals, not fractions of a common denominator.
- 100K lookup profile: 15000 point lookups; 61313 index checksums = 431.647 ms;
  61312 node decodes = 849.432 ms; index page reads = 306.025 ms.
- Serialization micro profile: 60 conversions of 100K rows = 1324.940 ms in to_text.
- Full-image snapshots, per-row syncs and the coarse coordinator dominate durable write
  costs. Reducing guarantees or redesigning WAL/locking is not justified by this campaign.

## Experiment 1: split index checksum regions — REVERTED

Hypothesis: remove the per-byte checksum-field range check while computing exactly the
same FNV format-v1 checksum. Code split the prefix, four zero bytes and suffix into loops.
Baseline lookup median (7 x 5000 lookups): approximately 646 ms; first candidate ~624 ms.
A controlled old/new/new/old follow-up put both versions around 625–632 ms. The apparent
initial improvement did not survive alternation, so the optimization was reverted.
All five index tests passed during the experiment, including an added reference-equivalence
check mutating every byte under both header offsets. The temporary experiment test was
reverted with its code; no failing test was removed. Raw alternating samples are retained
under checksum-experiment. Final checksum implementation is unchanged from Phase 7,
except optional profiling spans.

## Experiment 2: result text allocations — KEPT (Phase 7 correctness gate passed; final Phase 8 gate below)

Bottleneck: conversion allocated a Vec<String>, a String for every Value, and an additional
joined String per row. The instrumented to_text span and a separate uninstrumented micro
benchmark establish the cost. Source inspection establishes these allocation sites;
allocation counts were not independently instrumented.

Hypothesis: format existing Value Display implementations directly into the output String,
insert the same tab separators and newline terminators, and eliminate intermediate row
strings. The header and public API stay unchanged. No new serialization format is added.

Before: median 474.169 ms for 20 conversions of a 100K-row result (7 samples).
After first run: median 158.255 ms for the same work (7 samples), about 66.6% lower elapsed
time. This is a microbenchmark improvement, not overall database speedup. Full database
results contain both faster and slower workloads and are retained in comparison-100k.md.

Correctness: golden bytes cover NULL, minimum i64, Boolean, float, Unicode, embedded tabs/
newlines, binary, date, timestamp, decimal, empty rows/results and command results.
The Phase 7 superset correctness script passed after the change: formatting, strict Clippy,
workspace tests, auth/admin/server/recovery tests, docs and release build. Final Phase 8
validation additionally checks benchmark generation and performance-budget failure cases.

## Rejected or deferred changes

- Removing/merging heap fsyncs: rejected because this campaign does not alter durability.
- Replacing file-image WAL / coarse transaction locking: rejected as a subsystem redesign.
- Index checksum split: reverted after the apparent benefit disappeared.
- Allocator replacement: not evaluated; allocation-profiler evidence/tooling unavailable.
- PGO: not evaluated; llvm-profdata/LLVM profile tooling is not installed in Rust toolchain.
- 100M dataset: opt-in only after machine/time/storage assessment.
- Genuine cold cache: not run; all startup cache labels explicitly say uncontrolled.

## Release settings

`tools/evaluate-release.ps1` independently evaluates default, thin LTO, codegen-units=1,
panic=abort and target-cpu=native using the same micro suite. Only one override is active
per build; native CPU is explicitly nonportable. Results are under release-evaluation.
No override is adopted as a default from a microbenchmark alone. Compiler build logs and
per-run settings are retained. Allocator/PGO are reported as not evaluated, not fabricated.

## PostgreSQL and remaining scale coverage

PostgreSQL is not installed; the user explicitly authorized proceeding with comparison
results pending. The same TCP Python driver and deterministic schemas/data are provided
for both engines, plus supported PostgreSQL 18 setup instructions. Live PostgreSQL execution,
startup/recovery comparison, authentication/TLS equivalence, and PostgreSQL raw results
remain pending. No result or speed ratio is estimated.

The executed full suites cover 2K smoke and 100K rows. The harness accepts 1M and 10M and
provides exact campaign commands; larger full-suite measurements are not claimed in this
initial result set. They remain follow-up campaign runs rather than extrapolated timings.
Phobos's 1MiB response limit is an explicit limitation for large TCP result workloads;
embedded materialization does not remove that network limit.

## Reproduction

See benchmarks/workloads/README.md for all suite/micro/generator commands;
benchmarks/compare_postgresql/README.md for PostgreSQL setup and matched TCP driver.
Profile with `cargo build --release -p phobos-bench --features profiling`, then use suite,
lookup or micro mode into new output paths. Rebuild without features before comparing
headline timings. Run `tools/phase8-validation.ps1 -Python <python-executable>`.
Performance checks fail only for large median regressions, not small timing variation.

Release evaluation results are in benchmarks/results/release-evaluation/summary.md.
These runs are microbenchmark-only; no release setting was adopted. Normal validation
rebuilds the default portable profile. The native-CPU result is explicitly nonportable.

To reproduce the original serialization baseline with the same final harness, use a
separate checkout/copy, apply benchmarks/restore-phase7-serialization.patch, build the
ordinary release binary, and run the same micro/suite commands. The patch restores only
Phase 7's to_text implementation. Leave optional profiling disabled for timing comparisons.
Executable overrides in the monitor are identified by binary SHA256; the source-file list
is the working tree at invocation, not a claim that an archived executable was built from it.

### Broad-suite variability and losses

The first 100K comparison includes losses: point lookup 0.171 -> 0.194 ms;
autocommit inserts (3) 788.049 -> 1126.025 ms; transaction inserts (3) 246.742 ->
575.463 ms; crash recovery 139.162 -> 166.242 ms. These results are retained, not
cherry-picked away. Other reads and bulk load were faster; none is attributed solely
to the text formatting change because embedded read/write execution does not call to_text.

A monitored repeat of the original executable also slowed: autocommit median 1042.496 ms
and transaction-insert median 402.017 ms. Thus the first 2.33x transaction timing comparison
is not a stable before/after effect. The monitored candidate still measured ~1.43x slower
on transaction inserts than this repeat. This campaign does not establish the cause of
that write variability or claim a write speedup. Raw first runs and repeats are retained.

The monitored 100K candidate used 108.847 s total wall time, 51.109 s sampled parent CPU,
54,390,784 bytes sampled peak working set, and 53,960,704 bytes peak private memory. The
monitored old executable used 108.046 s wall and 52.109 s sampled parent CPU. These are
whole-run resource measurements, not per-query resource counters.

The initial smoke.csv run stopped at an unsupported ORDER BY projection in the new
harness. That harness SQL was corrected to project payload. smoke2.csv is the complete
baseline used by regression checks; the initial partial CSV remains for audit.

## Final validation outcome

PHOBOS PHASE 8 VALIDATION COMPLETED SUCCESSFULLY was reached (exit code 0).
Workspace: 62 passed, 0 failed, 3 pre-existing ignored soak tests. Python driver unit tests:
4 passed. Budget checker tests: identical results accepted, simulated 4x regression,
missing samples, incompatible dataset and NaN timings rejected. Real smoke and micro
budgets passed. Strict Clippy passed with -D warnings; no new allow or unsafe was added.
Documentation and portable release build passed. The unchanged Phase 7 script also
reached its success banner. No failing Phase 0–7 tests were skipped or deleted.

A live 2K-row matched TCP-driver run against the actual Phobos server passed all SQL
workloads with 3 samples, 3 operations and 4 connections; PostgreSQL was not run.
The standalone driver unit tests and actual Phobos run do not validate its PostgreSQL path.
Final validation artifacts are copied from target into results/validation-smoke and
results/validation-micro. Final smoke mixed workload was 1.982x baseline, close to the
2x threshold; this is retained as a concurrency-variability concern, not hidden.

Final instrumented 2K suite (3 samples, 10 operations) recorded 56,854,410 emitted WAL
record bytes in the parent process, including setup and all suite operations. This is
not a per-workload WAL budget. It recorded 1121 WAL sync calls totaling 543.674 ms.
Raw final instrumentation: optimized/profile.profile.csv. Default portable release was
restored after profiling.

## All 100K workloads

| Workload (100K rows) | Baseline median ms | Candidate median ms | Candidate / baseline |
|---|---:|---:|---:|
| bulk_load | 91816.076 | 76063.861 | 0.828 |
| indexed_point | 0.171 | 0.194 | 1.137 |
| indexed_range | 0.467 | 0.305 | 0.652 |
| full_scan | 47.279 | 43.033 | 0.910 |
| scan_aggregate | 41.080 | 35.092 | 0.854 |
| join | 94.298 | 83.732 | 0.888 |
| group_aggregate | 396.466 | 369.192 | 0.931 |
| sort_spill | 455.350 | 380.538 | 0.836 |
| autocommit_insert | 788.049 | 1126.025 | 1.429 |
| transaction_insert | 246.742 | 575.463 | 2.332 |
| update | 848.679 | 818.083 | 0.964 |
| delete | 837.099 | 751.977 | 0.898 |
| concurrent_readers | 1.754 | 1.830 | 1.043 |
| concurrent_writers | 3363.685 | 2552.034 | 0.759 |
| mixed | 1416.892 | 1309.859 | 0.924 |
| startup | 50.901 | 42.154 | 0.828 |
| crash_recovery | 139.162 | 166.242 | 1.195 |

## Independent release-setting results

| Independent release setting | Text (20 × 100K rows), median ms | Encode 100K, ms | Decode 100K, ms | Parse 100K, ms |
|---|---:|---:|---:|---:|
| default | 168.391 | 11.422 | 9.913 | 99.428 |
| thin-lto | 133.894 | 11.361 | 10.464 | 102.275 |
| codegen-one | 139.367 | 11.759 | 10.225 | 102.248 |
| panic-abort | 131.671 | 11.271 | 9.198 | 104.547 |
| native-cpu-nonportable | 160.726 | 11.851 | 9.865 | 102.073 |

## Exact source files changed from validated Phase 7

- CHANGED Cargo.toml
- CHANGED Cargo.lock
- ADDED crates\phobos-bench\Cargo.toml
- ADDED crates\phobos-bench\src\main.rs
- CHANGED crates\phobos-execution\Cargo.toml
- CHANGED crates\phobos-execution\src\lib.rs
- CHANGED crates\phobos-index\Cargo.toml
- CHANGED crates\phobos-index\src\lib.rs
- CHANGED crates\phobos-observability\Cargo.toml
- CHANGED crates\phobos-observability\src\lib.rs
- CHANGED crates\phobos-protocol\Cargo.toml
- CHANGED crates\phobos-protocol\src\lib.rs
- CHANGED crates\phobos-server\src\lib.rs
- CHANGED crates\phobos-sql\Cargo.toml
- CHANGED crates\phobos-sql\src\lib.rs
- CHANGED crates\phobos-storage\Cargo.toml
- CHANGED crates\phobos-storage\src\lib.rs
- CHANGED crates\phobos-wal\Cargo.toml
- CHANGED crates\phobos-wal\src\lib.rs
- ADDED tools\check-performance.ps1
- ADDED tools\evaluate-release.ps1
- ADDED tools\performance-campaign.ps1
- ADDED tools\phase8-validation.ps1
- ADDED tools\run-benchmarks.ps1
- ADDED tools\test-performance-check.ps1
- ADDED docs\performance_engineering.md
- ADDED benchmarks\restore-phase7-serialization.patch
- ADDED benchmarks\summarize_release.py
- ADDED benchmarks\summarize.py
- ADDED benchmarks\compare_postgresql\compare.py
- CHANGED benchmarks\compare_postgresql\README.md
- ADDED benchmarks\compare_postgresql\test_compare.py
- CHANGED benchmarks\workloads\README.md
- ADDED docs/phase8_report.md
- ADDED raw result files and logs under benchmarks/results (see archive manifest).

