# 0.2-I.2 — Replication-aware WAL retention

## Defect (0.2-I, 0.2-I.1)

Two checkpoint kinds exist:

* **Incremental** (`request_checkpoint*`): deletes sealed segments whose last LSN is at or below `min(safe, oldest slot)`. It always honoured slots.
* **Full** (`checkpoint_all_inner`): replaces `phobos.wal` with one format anchor and deletes *every* sealed segment (`remove_all_segments`). It never read the slot file.

Full checkpoints run at clean shutdown (`drain_on_shutdown`), `CHECKPOINT`, online backup, crash recovery and anchor upgrades. After a primary restart, all WAL a lagging standby had not replayed was gone.

`build_delta` then treated the first available record as a "bridge" when it was a format anchor whose `checkpoint_lsn` was at or above the standby's replayed LSN. It wrote a delta starting at that anchor, and replay reported success. The missing transactions were never applied, so the standby's indexes referenced missing tuples. PITR used the same function, so an archive taken after a restart silently dropped the pre-restart transactions.

## Invariants

* **Retention.** No checkpoint discards a WAL *transaction* record whose LSN is above the oldest slot LSN. The slot LSN is the consumer's *replayed* position: receive does not advance it, replay does.
* **Anchors may be discarded.** A full checkpoint may discard an active file that holds only format anchors after the slot (an idle restart). Readers prove such a gap harmless (see Bridging).
* **Delivery.** A delta covers every LSN after the consumer's replayed position, through its target. The only accepted gap is one proven to hold no transaction (see Bridging below).
* **Release.** Advancing a slot past the retained records, or dropping the last slot, is what makes them reclaimable. Pruning happens at the next checkpoint (incremental or full).
* **No slot means no change.** Without slots, behaviour is byte-for-byte the 0.2-I.1 behaviour.

## Mechanism

### Full checkpoint, with a slot whose LSN is `F`

1. Before the new anchor is renamed over `phobos.wal`, the active file is kept if it holds a transaction record after `F`. It is hard-linked (copy fallback) into `phobos.wal-retained/phobos.wal.<first>.<last>.seg`. After the replacement, its preallocated zero tail or torn suffix is trimmed.
   * A file kept by a crash-recovery checkpoint may end torn or inside a transaction. It is named `….recovered.seg`.
   * Readers tolerate a torn tail or a dead transaction **only** in such a file and in the live active file.
   * Every other retained file is scanned strictly and must end exactly at the last LSN in its name, so damage is an error, never a shorter file.
2. Sealed segments whose last LSN is above `F` are renamed into the same directory instead of being deleted. They keep their preallocated zero tail. The others are deleted as before.
3. Retained files whose last LSN is at or below `F` are deleted. If no slot exists, all of them are deleted. The decision uses file names only, so no retained bytes are read.

### What the retained directory is and is not

* Its files are unchanged V2 segments: same records and anchors, never rewritten.
* Local recovery, `scan::segments`, online and offline backups, `check` and `migrate` never read it. Crash recovery and restart cost do not grow with retained history.
* Retention readers use `v2::history_files` and `v2::visit_history`. These cover the retained files, the sealed segments and the active file, deduplicated by LSN. Readers are `receive`, `wal-archive`, `recover-to` and `replication-status`.

### Bridging

* WAL transaction IDs are allocated in LSN order: `BEGIN` refuses an ID below the cursor.
* A gap in front of a format anchor whose `next_txn_id` equals the consumer's cursor therefore contained no `BEGIN`. It held only anchors or checkpoint records.
* Such a gap is filled in the delta with neutral checkpoint records. This happens when a full checkpoint discarded an anchor-only active file (an idle restart), and in front of a base backup's own anchor.
* Any other gap fails with `new base backup required`. This also applies when no commit is visible after the gap.

### Dead transactions

* A transaction left incomplete by a crash is followed by the recovery checkpoint's anchor in the next file.
* In the delta, its records become checkpoint records at the same LSNs, so the delta stays contiguous and never interleaves transactions.

### Standby cursor

* `next_txn_id` in the standby state is now the cursor at the replayed position. Replay advances it; receive does not.
* For a state file written by 0.2-I.1 after an unreplayed receive, the received delta's start anchor supplies the cursor.

## Interfaces

```text
phobos-admin replication-status PRIMARY_DATA [STANDBY_DATA]
phobos-admin replication-slot-drop PRIMARY_DATA SLOT
phobos-admin wal-retain PRIMARY_DATA ONLINE_BACKUP SLOT     # PITR across restarts
```

## Compatibility

* Unchanged: page, RID, index, WAL record and wire formats, the slot file and the standby state file. No migration is needed.
* Back to 0.2-I.1: 0.2-I.1 ignores `phobos.wal-retained/`. Its next full checkpoint deletes all sealed segments (0.2-I.1 behaviour), and the retained directory stays on disk until removed by hand. 0.2-I.1 recovery is unaffected.

## Slot file

Retention depends on the slot file `phobos.replication-slots`.

* Writes now go to a unique temporary file that is renamed *over* the target, followed by a directory fsync. 0.2-I.1 removed the target first, so the file could briefly be missing.
* An unreadable slot file no longer blocks a shutdown, `CHECKPOINT` or crash recovery. In that case the checkpoint retains everything (frontier 0) and prunes nothing.
* Slot-modifying admin commands (`replication-init`, `replication-replay`, `wal-retain`, `replication-slot-drop`) are read-modify-write and are not mutually locked. Running them concurrently can lose a slot update. Run them one at a time. A slot lost this way leads later to a fail-closed `new base backup required`, not to silent loss.

## Operators upgrading from 0.2-I / 0.2-I.1

* 0.2-I.2 cannot detect data that 0.2-I or 0.2-I.1 already lost. Treat as suspect, and rebuild or re-take:
  * any standby that crossed a primary restart, `CHECKPOINT`, online backup or crash before replaying;
  * any PITR restore whose archive was taken after such an event.
* `phobos-admin check` on the standby or restore often (not always) shows the loss as "index references missing tuple".
* Replay or discard any received-but-unreplayed delta built by 0.2-I.1 before upgrading. 0.2-I.2 refuses to bridge gaps for a received delta that cannot vouch for the standby's transaction cursor.
* Archives made by 0.2-I.2 contain `phobos.wal-retained/`. 0.2-I.1's `recover-to` ignores that directory and may bridge silently. Use 0.2-I.2 tooling for 0.2-I.2 archives.

## Limits

* Retention is unbounded while a slot lags; a dead slot pins WAL forever. There is no size limit. Use `replication-status` to watch it, and drop the slot to release.
* The time between taking a base backup and registering its slot is not protected. In that window a restart can discard WAL; receive or recover-to then fails closed.
* `wal-retain` registers the slot first and then verifies the history; if the history is already gone, it removes the slot and fails.
* A slot registered while an incremental checkpoint is preparing can lose the range that checkpoint prunes. Receive or recover-to then fails closed.
* Windows is untested. On Windows, directory fsync is a no-op in the standard library, and the hard link relies on NTFS.
