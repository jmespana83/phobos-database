# Upgrade policy

The campaign starts from 0.0.1-alpha.0. The proposed 0.1.0-beta.1 designation is withheld
until the certification gates pass. This candidate does not change storage format versions.
No rolling upgrade, downgrade, or general future format compatibility is promised.

Before upgrading: stop the server, make an offline backup, retain the previous binaries,
restore into a separate directory, run integrity checking, and compare logical contents.
Never test an upgrade against the only copy of valuable data. Keep the source archive,
Rust 1.85.0 MSVC build instructions and SHA256 manifest with each backup.
