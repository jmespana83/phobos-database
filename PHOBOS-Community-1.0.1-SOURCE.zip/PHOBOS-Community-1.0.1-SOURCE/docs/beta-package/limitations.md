# Candidate limitations

Uncertified alpha candidate / not for irreplaceable production data. Certification remains subject to the report.

- Coarse transaction ownership, not PostgreSQL MVCC.
- Expensive full file-image WAL and installation remain, especially for small commits on large databases.
- Private transaction inserts batch heap flushes; ordinary heap inserts, new-page append, bounded-buffer eviction, statement-end flush and pre-commit flush retain their synchronization rules.
- Spill merge selects run heads in logarithmic work but still opens one reader per run and materializes output.
- Materialized results and a 1 MiB network response limit.
- Single equijoin, simple statistics, no broad PostgreSQL SQL compatibility.
- B+ tree deletion does not merge underfull nodes; heap tombstones are not reclaimed.
- Offline backups only. No online backup or automatic certificate rotation.
- PostgreSQL parity is unestablished. Keep observed regressions and absent measurements visible.
- Process-crash injection does not establish power-loss behavior of storage hardware.
- See the source certification report for actual 1M/10M, soak and security status.

Matched PostgreSQL TCP measurements are available at 100K, 1M and 10M. Full-result Phobos failures prevent a complete comparison pass; see the source PostgreSQL comparison report. PostgreSQL service startup/recovery and matched Phobos emitted WAL remain unmeasured.
