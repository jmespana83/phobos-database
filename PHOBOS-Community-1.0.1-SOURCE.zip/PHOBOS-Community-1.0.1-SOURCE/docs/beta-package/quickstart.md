# Candidate quickstart

Experimental beta campaign candidate; **not for irreplaceable production data**.
Packaging does not mean certification passed. Read the certification report first.

Build with Rust 1.85.0 MSVC, Rust 2024 edition, and Visual Studio C++ build tools:
`cargo build --release --workspace`. The pinned rust-toolchain.toml selects the MSRV.
No target-cpu=native, panic=abort or experimental release flags are required.

In an empty working directory, run:

```powershell
.\phobos-server.exe --bind 127.0.0.1:54321 --data-dir .\data
```

In another terminal:

```powershell
.\phobos-cli.exe query --addr 127.0.0.1:54321 "CREATE TABLE t (id BIGINT NOT NULL)"
.\phobos-cli.exe query --addr 127.0.0.1:54321 "INSERT INTO t VALUES (1)"
.\phobos-cli.exe query --addr 127.0.0.1:54321 "SELECT * FROM t"
```

Stop the server before `phobos-admin.exe backup .\data .\backup`.
Restore into a new destination using `phobos-admin.exe restore .\backup .\restored`,
then `phobos-admin.exe check .\restored`. Never substitute a copy of an active directory
for an offline backup. The bundled CLI currently supports plaintext loopback only;
the Rust client library supports authenticated TLS connections.

Source packaging: `tools/package-beta.ps1 -Python python -OutputDirectory NEW_PATH`.
Zip timestamps/order are fixed. Byte-identical native rebuilds across toolchains or paths
are not promised; retain Rust/MSVC versions and executable hashes for each build.
