# C7 dedicated bulk loader

C7 adds a bounded, all-or-nothing import to the existing capability-4 MVCC
coordinator. It does not change durable file formats, migrate databases, change
WAL forcing, or batch index construction.

## API and ownership

`MvccDatabase::bulk_load(session, table, iterator)` and
`Coordinator::bulk_load` consume `Result<Row, PhobosError>` values. The low-level
API is `bulk_begin`, repeated `bulk_batch`, then ordinary `COMMIT` or `ROLLBACK`.
An import starts its own transaction; mixing SQL or streaming reads into that
session is rejected. Empty iterators commit an empty import. Other sessions read
the committed snapshot while input is staged.

The import takes one table-write ownership key in the existing C6 wait-die
ownership domain. Ordinary writes to that table wait or become victims using the
existing cancellation/timeout policy; reads and writes to other tables remain
independent. Holding that key through publication makes committed uniqueness
checks stable without a row-count-sized in-memory ownership set. This is a
specialized import admission policy, not a replacement for ordinary row locking.

Each accepted chunk is type/NULL checked, encoded into tuple-version envelopes
with the stable MVCC identity and unique logical row ordinals, and written to a
checksummed scratch spool. Existing unique indexes are checked using committed
visibility. Temporary ordinary unique B+ trees detect duplicates across chunks;
NULL-containing keys retain the existing uniqueness semantics. These scratch
trees are validation state, not a new index construction algorithm.

COMMIT uses C6's irrevocable admission, private page preparation, supported page
image WAL, group durability, installation, status persistence and ordered
visibility publication. Preparation replays bounded spool batches, fills heap
pages sequentially, updates free-space metadata once per filled page, and invokes
the existing per-entry versioned index insertion for every existing index. It
appends to the last heap page/new pages rather than searching old free holes.
C1-C6 durability ordering is unchanged. A post-admission installation or force
failure fences the runtime; no success is returned. As with ordinary COMMIT, a
lost response or I/O error can have an uncertain outcome resolved by recovery.
It never permits a partially committed prefix.

Before admission, input, typing, uniqueness, protocol or disconnect errors abort
all staged chunks. RAII closes spool/tree handles before removing scratch on
Windows. C6 validated abandoned-directory housekeeping recognizes the new scratch
prefix on reopen. No scratch data becomes a recovery source; only durable WAL does.

## Bounds and backpressure

- Internal chunk: at most 1,024 rows and 1 MiB encoded tuple bytes.
- Iterator adapters: 64 rows; reject a row exceeding 64 KiB of estimated owned
  value memory before buffering it. The caller still owns its source iterator.
- Client batch: at most 256 rows and 1 MiB estimated owned values, then the
  existing 1 MiB protocol payload limit. One acknowledged request at a time.
- CLI: one line at a time, at most 8,192 bytes including line terminators.
- Scratch: at most 8 GiB checked after every chunk, including validation indexes, queried through live file handles on Windows;
  transient overshoot is bounded by one chunk and its index updates. Input EOF
  never commits unless the explicit end COMMIT succeeds.
- Existing C6 private pages spill through their 64-page per-file cache and fixed
  hash metadata. Existing bounded request queues/TLS buffers are unchanged.
- Heap free-space metadata remains proportional to heap page count. These are
  bounded working batches, not a claim of constant total engine memory or disk.

## Client/CLI

New clients require `bulk=1` in Hello for the iterator API. BulkBegin (30) names a
table; BulkRows (31) reuses the existing typed row codec with sequence zero.
Normal request IDs, frame sizes, authentication, write authorization and TLS
remain in force. An invalid chunk disconnects the logical session transaction so
that a later COMMIT cannot commit previously accepted rows.

```
phobos-cli ingest --addr 127.0.0.1:54321 bench rows.tsv
phobos-cli ingest --addr 127.0.0.1:54321 bench -
```

Input is client-local UTF-8 typed TSV, without a header. Fields are `i:123`,
`f:1.5`, `b:true`, `t:text`, or `\N` for NULL. Empty text is `t:`. Tabs and newlines
are separators, not escaped data. CRLF is accepted. Example for three columns:

```
i:1	i:7	t:hello
i:2	i:8	\N
```

Set `PHOBOS_USER`/`PHOBOS_PASSWORD` for authentication, and both
`PHOBOS_TLS_SERVER_NAME`/`PHOBOS_TLS_CA` for TLS. Passwords are never printed.
The server does not open paths supplied by the ingest client.

## Reproduction and scope

Run `tools/c7-validation.ps1` once for the final workspace build/correctness gate.
The focused C7 tests are selected with `cargo test -p phobos-execution --lib
c7_bulk` and `cargo test -p phobos-server --lib c7_bulk`. The latter includes 16
subprocess crashes over eight boundaries (staged, private prepared, before/after
WAL force, pre-publication, index installation, status/frontier and acknowledged).
All cases require repeated recovery and offline integrity.

Run `python tools/c7-measure.py --output <new-directory>` after building
`cargo build --release -p phobos-bench --features profiling`. It performs only
one 100K bulk/ordinary pair and one 1M bulk Phobos run sequentially and records executable hashes,
profile deltas, process memory when available and recovery/integrity verification.
Use `--resume` to reuse verified results from the identical binary; incomplete
runs require explicit review rather than automatic repetition. There is no 1M
ordinary-SQL run.
Both paths use the same deterministic data and existing unique `id` plus nonunique
`(bucket,id)` indexes. Bulk commits once; ordinary SQL commits 256-row batches
because its existing transaction overlay is bounded. This is a throughput
comparison with different atomicity granularity, not a matched single-transaction
speedup. Profiled timings include instrumentation overhead. No PostgreSQL runs,
10M, long soak, index batching or C8 changes belong to this milestone.
