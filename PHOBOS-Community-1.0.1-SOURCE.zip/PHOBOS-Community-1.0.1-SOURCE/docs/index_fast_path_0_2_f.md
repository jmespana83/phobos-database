# PHOBOS 0.2-F — Index fast path V2 (design)

Status: implemented in 0.2-F (Community). Baseline: 0.2-E source
`c48a40eb4b4497848a8c2fa3c60af0eaf8191c66df5347400042df43bb4556cc`.

Rule followed throughout: **decode / traverse / prepare once, reuse only while
the exact page version still matches, otherwise fall back to the existing
safe path.** No cached structure is ever an authority for UNIQUE, visibility
or publication.

## 1. What the profile actually showed (Part A)

The 0.2-E profile reported ~10 node decodes per indexed insert. Backtraces
(captured with a profiling build) show those `index.read_node` /
`decode_node` calls come from **start-up integrity validation**
(`open_indexes → BPlusTree::validate → validate_subtree`): ~16 300 decodes per
server start, amortised over the commits of a short run. In steady state an
autocommit insert decodes **no** `Node` at all; `read_node`/`decode_node` are
≈0.05 % of server CPU.

The real per-commit duplicate work (release `perf`, frame pointers) was:

| Duplicate work (0.2-E) | Where | Per commit |
|---|---|---|
| Full `NodeView` validation (every key re-validated with `validate_key_v3`, CRC re-checked) on every view of the *same committed image* | descent, leaf view, UNIQUE probe, recheck | 6–10 views |
| 8 KiB page copies of committed images (`read_page` → owned copy) | every page read | 6+ copies |
| Re-encoding the probe key for every comparison in a binary search | `lower_bound` / range bounds | ~log2(n) encodes per view |
| Opening the base heap/index file per statement reader | `statement_reader` | 7 (ac1), 20 (OLTP1), 513 (500-row txn) |
| Recomputing a batched leaf's encoded length after each insert | `insert_versions_batch` | O(entries) per insert |
| `lstat` of a never-created private scratch directory | publication | 1 |
| Deep clone of the catalog (all table/index schemas) | statement view + commit domain | 2 |

## 2. Validated-once immutable page images (Parts B, C, D)

* The committed page store (`CommittedStore`) now owns an **index page
  validator** (`validate_index_page_image`) registered by `phobos-index`
  (`set_index_page_validator`). Every index image entering the store — read
  from disk *or* installed by publication — is fully validated once
  (META checksum, FREE page shape, NODE: complete `NodeView::new` including
  every key). Heap images already had this (`validate_page_image`).
* Store images are immutable `Arc<[u8; 8192]>`; a publication installs a
  *new* `Arc`, it never mutates one in place.
* `PageIo::read_trusted(page) -> (Arc<image>, trusted)` returns the shared
  image zero-copy with `trusted = true` **only** for committed-store images.
  Private (uncommitted), pending (prepared, not yet published) and base-file
  reads return a copy with `trusted = false`.
* `NodeView::new_trusted` skips the per-key re-validation for trusted images
  only; header, magic, version, page id, kind, count, `used` and entry bounds
  are still checked on every view. Untrusted images always take
  `NodeView::new` (unchanged full validation).

Safe lifetime (Part C): a trusted image is valid exactly as long as the `Arc`
is held; it can never be observed changing. Reuse after publication, split,
root change, rebase, reclamation or recovery is impossible by construction:
each of those installs a different image (different `Arc`, re-validated), or
re-opens the store (recovery), which validates on entry again.

## 3. Layout memo and cached navigation (Part E)

`NodeView` entry offsets (`Layout = Arc<[u16]>`) are memoised next to the
image in the reader's **generation-scoped navigation cache**
(`internal: BTreeMap<page, (image, layout)>`, `leaf: (page, image, layout)`).

* Dependency token = (publication generation, page id, image `Arc`). The cache
  is cleared whenever the reader's publication generation changes
  (`index.navigation_invalidations`, reported as fallback reason "publication
  generation changed").
* `NodeView::with_layout(image, id, layout)` re-checks magic, version, id,
  kind, count, `used`, `layout.len() == count` and every offset `< used`; a
  mismatch is an error, never a silent reuse.
* A miss (or any failed check) falls back to building the view (trusted or
  validated) and refreshing the memo.

## 4. Encode-once comparisons

`lower_bound` and range upper bounds encode the probe key once and compare
encoded bytes (`compare_encoded`) for V3 keys. This is exactly the decoding
comparison because every stored key was validated (`validate_key_v3`) and the
V3 encoding is order-preserving; test `f6` checks equality for every position
of a node with mixed types and absent targets.

## 5. UNIQUE recheck (Parts F, G)

The final UNIQUE recheck is **unchanged and always executed** under the same
locks and ordering as 0.2-E. It became cheaper only because its probes use the
zero-copy trusted images, memoised layouts and encode-once comparisons above
(release perf, 500-row txn: `typed_unique_visit` samples 311 → 59). No UNIQUE
result is cached; no recheck is skipped. Batched UNIQUE checks (Part G) were
not changed — DEFER (the 500-row path is dominated by other costs, §8).

## 6. Rebase and preparation outside commit order (Parts H, I, J)

Not changed — DEFER. The profile after §2–§4 shows rebase/prepare at
3–8 % of autocommit CPU; moving authority-bearing work out of commit order
for that gain was judged not worth the risk inside this release window.

## 7. Smaller duplicate-work removals

* Statement readers reuse one cached base-file handle per table/index
  (`try_clone` of a `OnceLock<File>`): file opens per commit 7.0 → 0.01
  (ac1), 20.4 → 0.01 (OLTP1), 513.6 → 1.6 (500-row).
  Invariant: the clones share one file offset, which is safe only because
  a reader `PageIo` never positions or reads its base handle — every page
  comes from the committed store and `len` uses the captured length. Any
  future reader-side use of the base handle must use positional reads.
* Batched leaf inserts track the encoded leaf length incrementally
  (debug-asserted equal to a full recomputation on every insert).
* `encode_node` reuses one scratch buffer.
* Publication skips the `lstat` of a transaction scratch root that this
  process provably never created (process-wide bounded registry, populated
  *before* `create_dir_all`; open-time housekeeping removes every scratch root,
  so an unregistered root cannot exist; any doubt or registry overflow takes
  the unchanged probing path).
* `Catalog` maps are copy-on-write (`Arc<BTreeMap>` + `Arc::make_mut`), so
  per-statement and per-commit catalog clones are O(1); DDL mutates a private
  copy when a view still shares the map.

## 8. WAL extent pre-growth (Part N)

Mode E keeps its zero-filled, flushed capacity. 0.2-F adds **one optional
background extender**:

* Started under the WAL lock when less than 1 MiB of prepared capacity remains
  after the logical end (`EXTEND_AHEAD_BYTES`) and no extender is running.
* The worker opens the active WAL by path, verifies its length equals the
  capacity, writes real zeros over the next 4 MiB extent and flushes it
  (`sync_all` / `FlushFileBuffers`).
* Capacity advances **only** when the writer joins a worker that returned
  success; no record is ever written at or past the confirmed capacity.
* If the extender is still running when capacity is needed, the commit path
  waits for it (`wal.extend_wait`); if it failed, the unchanged foreground
  extension runs (it accepts zeros the failed worker left, never more than the
  worker's bound) — the foreground path is always correct on its own.
* Checkpoint, rotation and `Drop` join the extender before the active file is
  closed or replaced. `check_physical_len` accepts a file length in
  `[capacity, capacity + extent]` only while an unadopted extension exists.
* A crash during preparation leaves a longer zero tail, which recovery
  already treats as clean (tests `n1`–`n5`).
* Switch: `PHOBOS_WAL_BACKGROUND_EXTEND=0` disables it (pure 0.2-E path).

No acknowledgement depends on the extender, and it adds no write to the commit
path.

## 9. Fallback and counters

| Counter | Meaning |
|---|---|
| `index.page_reads_trusted` / `index.page_reads_validated` | shared trusted image vs copied/validated read |
| `index.store_validations` | images validated on store entry |
| `index.view_builds_trusted` / `index.view_builds_validated` | view built without / with key re-validation |
| `index.view_layout_reuse` | view rebuilt from a memoised layout |
| `index.navigation_invalidations` | cache cleared: publication generation changed |
| `view.file_reuse` / `view.file_open` | cached base handle vs open |
| `wal.extends_foreground`, `wal.extents_background`, `wal.extend_wait`, `wal.extend_background_failures` | Part N |
| `scratch.retire_absent_known` | scratch probe skipped (never created) |
