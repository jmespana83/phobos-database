# Phobos Performance Architecture V2 campaign report

All seven approved checkpoints are complete and checkpointed. Negotiated streaming, bounded streaming execution, profiling, indexed DML, private page overlays, WAL v2, page LSNs and flush barriers are implemented. Group commit was measured and the safe serialized fallback was retained; **a commit batcher is not implemented**. This is a development campaign result, not beta/release certification or hardware power-loss proof.

## Architecture and root causes

The original engine copied database files for transaction staging, logged whole-file snapshots, replaced files and reopened storage on COMMIT. Small writes therefore scaled with database size. UPDATE/DELETE also scanned all rows, and the wire protocol required one materialized result inside a 1 MiB frame.

Transactions now retain heap/index ownership and put changes in private scratch overlays. A fixed 4,096-bucket lookup and 64-page cache per file bound additional private-page state. BEGIN does not clone database files or the heap free-space vector. Indexed DML freezes safe candidate record IDs before mutation and still evaluates the full predicate, preserving uniqueness, error ordering and rollback behavior. Conservative unsafe/coercing predicates keep their scan fallback.

COMMIT freezes and stamps changed full-page images with their WAL record LSNs, writes bounded redo records and COMMIT, and synchronizes WAL. Only a matching durable receipt permits base-page installation. A post-COMMIT error fences admissions until recovery. W2 writes committed images to the OS cache and retains WAL, then forces pages before checkpoint replacement. Checkpoints run after 64 commits, 16 MiB of WAL, explicit CHECKPOINT, or conservative metadata/file lifecycle boundaries. There is no new background writer. Buffer replacement preserves pin counts; failed dirty eviction retains the frame until write and force succeed.

```mermaid
flowchart LR
  A[Private changes] --> B[Freeze and stamp images]
  B --> C[Append redo and COMMIT]
  C --> D[Force WAL]
  D --> E[Install committed pages]
  E --> F{Checkpoint due?}
  F -- No --> G[Acknowledge]
  F -- Yes --> H[Force data pages]
  H --> I[Replace complete WAL anchor]
  I --> G
```

Recovery preflights the WAL before changing files, replays only complete committed transactions, and repairs torn pages from full-page images. It skips redo only for checksum-valid, identity-valid pages with a sufficiently new LSN inside the validated WAL horizon. Skipped pages are still forced before checkpoint. Incomplete transactions never publish. Repeated recovery is tested. File owners close scratch, retired and replaced handles before Windows cleanup/replacement.

Two read-ownership fixes retain the already-validated initial index leaf and move owned rows into collecting-sort spill runs instead of cloning them. Sort stability, checksums, predicates, authentication, TLS and transaction isolation remain enforced. No Clippy suppression or failing-test deletion was introduced.

## Compatibility and streaming

Fresh databases use WAL v2 with an explicit page-format capability. Legacy databases require backup-first offline `migrate-wal-v2`; existing W1 databases require backup-first `migrate-page-lsn` to enable deferred forcing/page LSNs. Untouched version-1 pages upgrade lazily when logged. Older decoders reject the new capability before mutation. Restore the complete untouched backup to return to an older format.

Streaming is explicitly negotiated. Typed schema, bounded row batches and terminal messages retain the 1 MiB frame cap. The client validates stream state/counts/types and poisons a connection after interruption or malformed results. The CLI writes incrementally. Scans, indexed reads, stable spill sorting, joins and aggregation use bounded producer/sink paths. Existing collecting APIs remain available for compatibility and still materialize their requested result.

## Matched durable writes: 100K and 1M

These are medians of three unchanged TCP workload samples. INSERT/UPDATE/DELETE rows below represent three operations; concurrent writers represent twelve operations over four connections. Speedups use the saved P1 streaming control, so transport/SQL semantics match. PostgreSQL values are read from the previously recorded comparison CSV; PostgreSQL was not rerun or reconfigured.

| Workload | Operations | 100K final ms | 100K speedup | 1M P1 ms | 1M final ms | 1M speedup | Fixed PG 1M ms | Final / PG |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| autocommit_insert | 3 | 17.254 | 55.0x | 8948.176 | 13.381 | 668.7x | 0.7059 | 18.96x |
| transaction_insert | 3 | 5.448 | 65.3x | 3138.670 | 6.032 | 520.4x | 0.6788 | 8.89x |
| update | 3 | 14.783 | 76.1x | 9683.649 | 13.930 | 695.2x | 0.7448 | 18.70x |
| delete | 3 | 14.168 | 51.3x | 9924.887 | 13.189 | 752.5x | 0.7801 | 16.91x |
| concurrent_writers | 12 | 63.978 | 62.1x | 36444.045 | 60.575 | 601.6x | 2.2723 | 26.66x |

Stage 1's 10x reduction is met for these writes at both scales. Stage 2's 100x reduction is met for the selected 1M workloads. Stage 3's within-2x PostgreSQL write target is **not** met: the remaining recorded gap is about9–27x. There is no cross-engine parity claim. Whole-workload elapsed time is not pure COMMIT latency.

## WAL volume, fsyncs and phase costs

At both 100K and 1M, one explicit three-row INSERT writes 16,594 WAL bytes including BEGIN and installs two distinct pages (16,384 bytes). The original P1 1M profile wrote 90,825,211 WAL bytes: a 99.9817% reduction. Three W2 autocommits write 49,782 WAL bytes. WAL fsyncs for the explicit INSERT fell from 4 in P1 to 3 in W1 to 1 in W2; three W2 autocommits use 3. Checkpoint forces are additional, and these are WAL counts rather than a claim about every OS synchronization.

Diagnostic median BEGIN/stage/COMMIT times were 2.701/1.142/3.355 ms at 100K and 2.610/1.520/6.020 ms at 1M. These instrumented phase timings are separate from the uninstrumented TCP table. Cloned profiling fixtures are forced before timing. Older P1/W1 unforced-clone profiles are retained and have a setup/writeback confounder; their WAL volume/candidate counts remain useful. Point mutations now inspect three candidates for three operations, instead of 300K/3M.

## Read preservation

Final 1M TCP reads compared with the saved P1 streaming control:

| 1M TCP workload | Final seconds | Final / P1 | Final / fixed PG |
| --- | --- | --- | --- |
| indexed_point | 0.000293 | 0.6550 | 1.61 |
| indexed_range | 0.000655 | 1.0809 | 3.05 |
| full_scan | 4.529165 | 0.9979 | 3.18 |
| scan_aggregate | 0.261948 | 0.9561 | 7.16 |
| join | 2.285190 | 1.0149 | 3.15 |
| group_aggregate | 11.976792 | 0.9100 | 115.40 |
| sort_spill | 15.002971 | 1.0133 | 2.46 |
| concurrent_readers | 0.003777 | 0.9901 | 2.11 |

All are within the 10% regression budget; range lookup is 8.1% slower and other reads range from 9% faster to 1.5% slower, with point lookup faster still. Grouping remains particularly far from PostgreSQL.

W2 also passed strict cumulative S2 embedded 100K/1M read budgets. G1 changed only benchmark/reporting code; its engine crates and server executable match accepted W2. The final G1 Fast gate uses frozen W2 as its iteration baseline and passed with a maximum ratio 1.0778. Original S2 baselines and every failed intermediate report remain preserved, including `g1-final-fast`'s historical join ratio 1.1176. A per-checkpoint pass does not relabel those historical measurements. The checker retains short indexed samples as diagnostics and uses separately labelled 3,000-query intervals for a stable indexed-read median. Threshold 1.10 is unchanged; default sample count is seven.

## Streaming memory and 5M scale

Separate-process official client/server scan measurements below include row validation and frame re-encoding, so they are diagnostics rather than headline TCP throughput. Sort, join and grouping also passed at all three sizes. Private memory is sampled and may miss brief peaks.

| Rows | Scan seconds | Frames | Batches | Wire bytes | Rows / batch | Server private MiB | Client private MiB |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 10000 | 0.023 | 44 | 42 | 2741289 | 238.10 | 4.66 | 3.41 |
| 100000 | 0.235 | 421 | 419 | 27412222 | 238.66 | 4.99 | 3.55 |
| 1000000 | 1.958 | 4187 | 4185 | 274121436 | 238.95 | 5.32 | 3.93 |

At 1M the sort/group validation took 40.39/81.80 seconds with roughly 6 MB server private memory. Bounded memory has a substantial spill cost; this is a remaining optimization area.

The 5M embedded full suite passed all 17 workloads (49 records), including startup, injected crash recovery and repeated reopen checks, in19.06 minutes without timeout. Bulk load took695.152 seconds. Median point/range were0.0879/0.2548 ms, full scan2.230s, group18.863s, sort20.597s, startup2.071s and crash recovery2.042s. Sampled whole-process peak private memory was2.574 GiB. This collecting benchmark/DDL path is not universally bounded. First writes on copied fixtures can include file writeback; 5M embedded mutation numbers are not steady TCP commit latency.

10M and a new two-hour soak were not run: those are reserved for a release candidate/final release certification. No 5M PostgreSQL result is estimated or inferred from this embedded run.

## Measured group-commit decision

The new `commit-profile` diagnostic measured 1/4/8 clients, 32 commits each and three samples in separate normal and profiling builds. All 2,496 timed acknowledgments survived exact value checks after two reopens and offline integrity. Normal median throughput was 126.19/151.64/143.20 transactions/s; p50 latency 6.39/12.26/12.60 ms, p95 latency 9.79/42.32/130.01 ms and p99 latency 61.10/401.52/791.61 ms.

There were 32/132/264 WAL fsyncs per 32/128/256 commits, or 1.000/0.970/0.970 transactions per fsync including checkpoint forces. WAL force time represented 8.1–14.3% of serialized execution. Lock-wait spans overlap between threads and are not additive with execution time.

The serialized fallback is retained. One mutable Database/WAL transaction remains active through its force, installation and response. Unlocking around fsync would weaken private-state isolation; merely queueing callers would not batch durability. Real batching needs bounded pending transaction ownership, dependent uniqueness/read rules, ordered installation and failure fan-out. The current data do not justify that redesign as a narrow final change. No response is acknowledged before WAL durability.

## Validation and reproducibility

W2 reached `PHOBOS PERFORMANCE V2 MILESTONE CHECKPOINT PASSED`; G1 reached `PHOBOS PERFORMANCE V2 FAST CHECKPOINT PASSED`. Both Phase 7 and Phase 8 success markers were reached. Latest routine totals are 120 Rust tests passed, zero failed, with three existing long-soak tests still marked ignored by the project. Strict `cargo clippy --workspace --all-targets --all-features -- -D warnings`, formatting and documentation passed. Focused checks include 16 WAL tests and four migration tests. The Milestone ran 22 existing crashes plus 24 and 250 acknowledged page-LSN crashes (296 cycles); final G1 Fast ran 46 cycles. The 600-second soak passed in 602.2 seconds within handle/private-memory growth budgets. Python comparison tests and strict read-checker boundary/error tests passed.

Crash tests cover partial redo/COMMIT, pre/post-WAL force, page installation/forcing, checkpoint replacement, interrupted migration, torn headers and checksum-valid impossible future LSNs. Parent-observed acknowledgments and exact atomic row/index models are checked twice. These are process/file-damage tests, not hardware power-loss simulation. Windows is the tested platform; existing Windows directory-sync limitations remain.

Run `tools/performance-v2-validation.ps1 -Mode Fast` for iteration or `-Mode Milestone` for 1M, 250 additional crashes and the ten-minute soak. The default read baseline is accepted W2; use `-ReadBaselineDirectory benchmarks/performance-v2-reference` for the historical S2 comparison. Certification mode adds 5M/10M, 1,000 crashes, a two-hour soak and package/extracted-source checks; it was implemented but not run as a release certification in this campaign. `v2-matched-phobos.py` has no PostgreSQL execution branch. `v2-matched-review.py` reads saved CSVs only. `v2-commit-summary.py` separates normal timings from instrumented costs. All original raw results, configuration, executable hashes and failed reports remain available in checkpoint evidence.

The final delivery includes deterministic source and Windows candidate packages, SHA256 manifests, an exact original-source change audit, and an extracted-source workspace-test log. Candidate packaging does not assert beta certification.

## Exact files changed

The following 78 source/configuration/documentation files differ from the original delivered PostgreSQL-comparison source. Delivery `changed-files-original.json` records exact before/after hashes. Historical evidence-only files are packaged separately and are not counted as removed functionality.

- `Cargo.lock`
- `benchmarks/compare_postgresql/compare.py`
- `benchmarks/compare_postgresql/streaming.py`
- `benchmarks/compare_postgresql/test_streaming.py`
- `benchmarks/performance-v2-checkpoints/w2/100k.csv`
- `benchmarks/performance-v2-checkpoints/w2/1m.csv`
- `benchmarks/performance-v2-checkpoints/w2/basis.json`
- `benchmarks/performance-v2-checkpoints/w2/indexed-100k.csv`
- `benchmarks/performance-v2-checkpoints/w2/indexed-1m.csv`
- `benchmarks/performance-v2-reference/100k.csv`
- `benchmarks/performance-v2-reference/100k.json`
- `benchmarks/performance-v2-reference/1m.csv`
- `benchmarks/performance-v2-reference/1m.json`
- `benchmarks/performance-v2-reference/indexed-100k.csv`
- `benchmarks/performance-v2-reference/indexed-100k.json`
- `benchmarks/performance-v2-reference/indexed-1m.csv`
- `benchmarks/performance-v2-reference/indexed-1m.json`
- `crates/phobos-admin/Cargo.toml`
- `crates/phobos-admin/src/lib.rs`
- `crates/phobos-admin/src/main.rs`
- `crates/phobos-bench/src/main.rs`
- `crates/phobos-catalog/src/lib.rs`
- `crates/phobos-cli/src/main.rs`
- `crates/phobos-client/src/lib.rs`
- `crates/phobos-execution/src/bounded_sort.rs`
- `crates/phobos-execution/src/indexed_dml.rs`
- `crates/phobos-execution/src/lib.rs`
- `crates/phobos-execution/src/private_transaction.rs`
- `crates/phobos-execution/src/streaming.rs`
- `crates/phobos-execution/src/streaming_aggregate.rs`
- `crates/phobos-execution/src/streaming_relational.rs`
- `crates/phobos-index/Cargo.toml`
- `crates/phobos-index/src/lib.rs`
- `crates/phobos-observability/src/lib.rs`
- `crates/phobos-protocol/Cargo.toml`
- `crates/phobos-protocol/src/lib.rs`
- `crates/phobos-protocol/src/streaming.rs`
- `crates/phobos-server/Cargo.toml`
- `crates/phobos-server/src/lib.rs`
- `crates/phobos-server/tests/fixtures/README.md`
- `crates/phobos-server/tests/fixtures/ca.pem`
- `crates/phobos-server/tests/fixtures/server-key.pem`
- `crates/phobos-server/tests/fixtures/server.pem`
- `crates/phobos-storage/Cargo.toml`
- `crates/phobos-storage/src/lib.rs`
- `crates/phobos-storage/src/page_io.rs`
- `crates/phobos-storage/src/private_pages.rs`
- `crates/phobos-txn/src/lib.rs`
- `crates/phobos-validation/Cargo.toml`
- `crates/phobos-validation/src/bin/beta-crash.rs`
- `crates/phobos-validation/src/bin/page-lsn-crash.rs`
- `crates/phobos-validation/src/bin/stream-check.rs`
- `crates/phobos-wal/Cargo.toml`
- `crates/phobos-wal/src/lib.rs`
- `crates/phobos-wal/src/v2.rs`
- `crates/phobos-wal/src/v2/format.rs`
- `crates/phobos-wal/src/v2/log.rs`
- `crates/phobos-wal/src/v2/page_format.rs`
- `crates/phobos-wal/src/v2/recovery.rs`
- `crates/phobos-wal/src/v2/replay.rs`
- `crates/phobos-wal/src/v2/scan.rs`
- `docs/performance_architecture_v2.md`
- `docs/performance_v2_campaign_report.md`
- `docs/streaming_protocol.md`
- `tools/beta-source-fingerprint.ps1`
- `tools/check-performance.ps1`
- `tools/package-beta.py`
- `tools/performance-v2-validation.ps1`
- `tools/test-performance-check.ps1`
- `tools/test-v2-read-performance.ps1`
- `tools/v2-check-read-performance.ps1`
- `tools/v2-commit-summary.py`
- `tools/v2-dml-update-check.py`
- `tools/v2-matched-phobos.py`
- `tools/v2-matched-review.py`
- `tools/v2-profile-summary.py`
- `tools/v2-stream-memory.ps1`
- `tools/v2-stream-smoke.py`
