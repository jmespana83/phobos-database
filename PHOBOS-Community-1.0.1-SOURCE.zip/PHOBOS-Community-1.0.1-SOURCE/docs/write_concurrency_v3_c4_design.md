# C4 — incremental checkpoint/writeback coordination

This checkpoint preserves the C1 WAL receipt/group-force protocol, C2 private
preparation and ordered publication, and the C3 committed-page store. It changes
ordinary page-LSN DML checkpoints. Explicit CHECKPOINT, legacy-page databases,
lifecycle/DDL commits and clean shutdown retain full durability barriers.

## Measured motivation

Before behavior changes, an instrumented C3 control ran all 12 combinations of
100K/1M, 1/4/8 writers and shared/disjoint tables, three samples of 32 transactions
per client. Normal performance controls are separate because instrumentation
changes timing. Source archive SHA256:
`1c4b68c392629453143c3e58109b4b43fb9b96b33fab7b86ce12342678d5836c`.

The shared 100K/8 case spent 3.086 ms/transaction in publication, including
2.530 ms in scratch retirement. Disjoint 1M/8 spent 1.833 ms in independent
publication, including 1.409 ms in scratch retirement. Store mutex wait was
0.00264/0.00582 ms, and heap/index lock waits were below 0.0002 ms each.
Checkpoint foreground drain was 0.101/0.481 ms and WAL rotation 0.153/0.138 ms.
Inclusive spans overlap; they must not be added as independent costs.

These observations identify synchronous scratch cleanup as a substantial
publication cost. Checkpoint work contributes, but is not the whole explanation
for the C3 regressions. C4 leaves scratch ownership and synchronous retirement
intact; it does not trade cleanup failure semantics for a speed claim.

## Page-side protocol

1. After an ordered published group, capture the last durable COMMIT LSN when
   the 64-commit or 16-MiB-growth checkpoint trigger is due.
2. The existing bounded page worker selects current images with page LSN at
   or below that target. Selection is rechecked after acquiring the file I/O
   guard. WAL durability is still checked immediately before physical writes.
3. Each wake flushes at most the configured batch size and forces at most one
   registered file. Neither database ownership nor the store mutex spans I/O.
   C3 pressure eviction can run concurrently using the same per-file ordering.
4. Publication during a pinned write changes the frame generation. Completion
   never removes a redirtied generation. Its original recovery LSN stays
   conservative; an unforced physical write also retains its recovery dependency.
5. After the file-force pass, atomically compute
   `safe = min(target, minimum(dirty rec_lsn, unforced file rec_lsn) - 1)`.
   With no dependency, `safe = target`. A newer redirty may prevent full target
   retirement. This is a recoverable checkpoint with retained redo, not a claim
   that every target effect is in the data files.

New publications after capture cannot introduce an older dependency. Pending
private generations are excluded from committed state. Explicit drains cancel
page checkpoint bookkeeping before forcing all current committed images. An
already pinned old write remains ordered by its file guard and cannot produce
a stale checkpoint completion after cancellation.

## WAL-side protocol

The WAL writer starts one bounded-memory preparation worker at a complete,
published transaction boundary. The worker reads only the captured byte prefix,
finds the last complete transaction chain at or below `safe`, and creates the
existing V2 replacement temporary containing an anchor plus the retained suffix.
It never splits BEGIN/data/COMMIT. It forces and validates that replacement.
Ordinary transactions can append to the authoritative old WAL while this runs.

The new anchor occupies the last retired record's LSN. Its checkpoint LSN is
conservatively at most anchor LSN minus one, preserving the existing V2 encoding
constraint. The suffix starts at the next contiguous LSN. Transaction identities,
page-format capability, writer identity, commit tickets and LSN allocation remain
unchanged. Existing C3 readers can recover this representation; no on-disk version
or migration is introduced.

At a later publication boundary, the owner polls without waiting. A tail larger
than 1 MiB is copied/forced in the background. A smaller tail is copied and
forced before closing the writer handle, atomically replacing the WAL, reopening
and forcing it, and synchronizing the directory where supported. The old WAL is
never deleted before replacement. No other thread holds a source handle when
replacement occurs. Full checkpoints and Wal Drop join/cancel the worker before
recovery or another replacement can use the directory.

A crash sees either the complete old WAL or the complete new anchor/suffix.
Recovery uses the unchanged bounded preflight and idempotent page-LSN redo,
then a full anchor. An abandoned temporary never supersedes the authoritative
WAL. Partial checkpoints do not remove retired lifecycle files; DDL's full
checkpoint remains responsible for them.

## Failure, bounds and practical limits

- Page I/O/worker errors fence the shared store and its attached databases.
  WAL preparation/finalization errors are returned by polling and fence the WAL
  and publishing database before a successful response. Full checkpoint
  cancellation propagates a worker error; it does not hide it.
- Dirty memory remains at C3's configured high-water mark. Page batches are
  bounded, WAL copy buffers are bounded, and only one WAL preparation task exists.
- Final replacement still requires foreground file/directory synchronization.
  Bounded copied bytes are not a wall-clock limit on operating-system fsync.
- Idle databases may retain a prepared WAL replacement until the next ordinary
  publication poll. Explicit CHECKPOINT/shutdown remains a full completion barrier.
- Hot redirty dependencies can conservatively retain older WAL until a later
  flush/checkpoint. The 16 MiB value is a work trigger, not a hard WAL-size cap.
  No needed WAL is discarded to impose an artificial size bound.
- Scratch-file retirement and logical publication ownership remain synchronous.
  Remaining writer regressions must be reported as such and carried to later
  architecture work; C4 does not introduce MVCC or start C5.

## Instrumentation and validation

Profiles distinguish store/file mutex wait and hold, publication, scratch
retirement, page-LSN validation, foreground drain/finalization, background page
work, WAL preparation/catch-up/force, page batches, redirties, wakeups and WAL
retirement. The raw `checkpoint.batch_pages` counter counts bounded selection
attempts, including a selection that became stale before the file lock;
`flush.checkpoint_pages` counts actual physical writes. Normal benchmark boundary
snapshots include retained WAL bytes.

Deterministic tests cover concurrent preparation/redirty at a paused target,
retained recovery dependencies, later retirement, complete retained transaction
chains with a concurrently appended tail, and checkpoint I/O failure fencing.
The original retention test now waits for asynchronous completion before its
unchanged WAL/page-LSN/rollback/recovery assertions.

The C4 campaign runs 24 process exits: six repetitions each before target flush,
after page completion before WAL preparation, before replacement, and after
replacement. Each verifies a persisted acknowledgment marker and hook marker,
then checks heap payload, unique-index behavior and recovery twice. All inherited
C1/C2/C3 crash tests and Fast-suite regressions remain enabled and are counted
separately. Full Fast evidence, measurements and final status belong in the C4
report; this design document alone does not certify a pass.

## Fast fixture setup correction

The first Fast run hit a 1M mixed admission timeout before the first writer's
private index setup or page WAL records. The fixture copier had left roughly
90 MB of copied pages unforced. Diagnostic profiles showed the initial
transaction setup absorbing that persistence under logical ownership, with no
incremental checkpoint requests. The common benchmark helper now forces copied
fixtures outside timing, as the steady-writer harness already did. Both C3 and
C4 controls use the same helper. Engine synchronization and admission deadlines
are unchanged. The failed attempt and before/after diagnostics are retained in
validation-history.md; this harness correction is not counted as an engine gain.
