# Storage Lifecycle V1 (0.2-K)

This is the in-tree design reference for the 0.2-K storage lifecycle. It assembles the release design documents:

- slot state model and proofs;
- standby safety;
- reclaim scheduler;
- index pruning;
- status-file lifecycle.

Measured results are in the release deliverables (`PHOBOS-0.2-K-STORAGE-LIFECYCLE-IMPLEMENTATION.md`, `PHOBOS-0.2-K-STEADY-STATE-RESULTS.csv`).

**Design rule (Part D, future cursor/portal state):** any structure that keeps heap RIDs beyond one statement MUST keep its snapshot pin registered in `SnapshotRegistry` for its whole lifetime. Only then does the horizon gate (`horizon > retired_at`) cover it.


## PHOBOS 0.2-K — Slot State Model (Parts B, C, D, E, F, G, I)

Base: PHOBOS 0.2-I.3. Size 1,241,407 bytes. SHA-256 `7c5dbeed30dd7c90bed1b22a2811470964ef870d5a837ed77871c7ab3513dcba`.

Code: `crates/phobos-storage/src/lib.rs` (`SlotState`, `insert_unsealed`, `retire_slot`, `free_retired_slot`, `trim_trailing_free`, `all_slots_free`, validation) and `crates/phobos-storage/src/versioned_heap.rs` (`reclaim_lifecycle`). The gate lives in `crates/phobos-execution/src/mvcc_runtime/reclaim.rs`.

### 1. Encoding

No new bytes are added. The existing 4-byte slot entry is `(offset: u16, len: u16)`, plus one spare header flag bit.

| State | `len` | `offset` | Page kinds | Notes |
|---|---|---|---|---|
| **OCCUPIED** | > 0 | in `[upper, 8192)` | all | A tuple (PHMV envelope on format-3 pages). |
| **RETIRED** | 0 | ≥ 44 (stale tuple offset) | all | Bit-identical to every tombstone written by every release before 0.2-K. Its RID is still "owned" by the dead version. |
| **FREE** | 0 | 0 | format-3 ordinary (non-overflow) only | New in 0.2-K. Written only by the horizon-gated reclaim transition. Reusable. |
| **VACANT** | — | — | — | `slot >= slot_count`. The slot was never allocated, or was trimmed or reset away. |

New header flag: `PAGE_FLAG_FREE_SLOTS = 0b100` (byte 30, next to `RECLAIM_CANDIDATE = 0b1` and `OVERFLOW = 0b10`). It is a conservative hint that the page may hold FREE slots:
- It is set every time a slot becomes FREE.
- It is cleared by the allocator when a directory scan finds none, and by the trim/reset paths.
- A stale set bit costs one directory scan. The bit is never missing when FREE slots exist, because `free_retired_slot` sets it in the same mutation.

#### Invalid combinations (rejected by `validate_page_image_checked`, so every page read fails closed)

- `len == 0 && 0 < offset < 40`. This is not a header-free offset and is not a state.
- `len == 0 && offset == 0` on a format-1/2 page or on an overflow page. FREE exists only on ordinary versioned pages.
- `len > 0` with the tuple outside `[upper, 8192)`. This rule is unchanged (`image_get`).
- The `lower`/`slot_count`/`upper` rules are unchanged.

The FREE hint bit on a page with no FREE slot is valid; it is only a hint.

### 2. Per-state semantics (Part B table)

| | OCCUPIED | RETIRED | FREE | VACANT |
|---|---|---|---|---|
| `image_get` returns a tuple | yes | no (`None`) | no (`None`) | no (`None`) |
| Index RID dereference may succeed | yes, and is re-validated by key and identity (Part H) | no: treated as already reclaimed | no: treated as already reclaimed | no: treated as already reclaimed |
| Integrity checker treats it as history | yes (a version) | an empty historical slot (an acceptable `previous` target, Part I) | the same | the same |
| Allocator may reuse it | no | **never** | **yes** (lowest FREE first) | only by extending `slot_count` |
| Compaction moves bytes | yes (offset rewritten) | no (entry untouched, stale offset kept) | no (entry stays `0/0`) | — |
| Recovery reproduces it | yes: WAL page images / PageDeltas of the publishing transaction | the same | the same | the same (`slot_count` is in the page header) |
| WAL special handling | none | none | none | none |

No WAL record type was added or changed. Every transition happens in a private page image of an ordinary MVCC transaction (the reclaim maintenance transaction or a user transaction). That image goes through the existing page-image/PageDelta → force → install → publication pipeline. Crash atomicity is therefore exactly that of any other publication: either the old images or all new images of the pass.

### 3. Transitions

```
              user INSERT/UPDATE (allocator: FREE first, else extend)
   VACANT ─────────────────────────────────────────────────────────▶ OCCUPIED
   FREE   ─────────────────────────────────────────────────────────▶ OCCUPIED
                                                                         │
            reclaim phase 1 (globally_dead + exact (key,RID) index      │
            removal in the SAME publication R)                          ▼
                                                                      RETIRED
            reclaim phase 2, a LATER pass, only if horizon > retired_at  │
                                                                         ▼
                                                                       FREE
   FREE (trailing)  ── Part F trim ──▶ VACANT
   all slots FREE   ── Part G reset ──▶ fresh empty versioned page (all VACANT)
```

- **Phase 1** (`retire_slot`): only OCCUPIED → RETIRED. Before retiring, the planner verifies the exact tuple bytes against the version it planned with. A mismatch aborts the pass (stale plan).
- **Phase 2** (`free_retired_slot`): only RETIRED → FREE. It is only valid on format-3 non-overflow pages. Within one page rewrite, `free` is applied **before** `dead` is retired. A slot retired by this pass can therefore never be freed by the same pass (it was not RETIRED when phase 2 looked at it). The `TransactionState` error aborts the whole pass.
- **Trim** (Part F) removes trailing FREE entries only:
  - `slot_count` shrinks, `lower` moves down, and the released directory bytes are zeroed.
  - OCCUPIED and RETIRED entries are never removed or renumbered.
  - Tests: `FREE FREE FREE` at the end → all trimmed. `FREE OCCUPIED FREE` → only the last is trimmed. `RETIRED` at the end → not trimmed (`phobos-storage` `k_trailing_free_entries_are_trimmed_only_at_the_end`).
- **Reset** (Part G): if every slot is FREE (vacuously so for an empty directory) on an ordinary format-3 page, the page is replaced by `SlottedPage::new_versioned(page_id)`:
  - `slot_count = 0`, `lower = 40`, `upper = 8192`, normal flags, zeroed body.
  - The checksum is refreshed, and the LSN is stamped by redo preparation like any other image.
  - It is never applied to overflow pages, pages with RETIRED slots or pages with occupied slots.
- The allocator hint cache is invalidated for trimmed or reset pages, and `forget_slot` runs on every allocation. A slot number that reappears can therefore never inherit stale hint bits.

### 4. Allocation (Part E)

`SlottedPage::insert_unsealed` is the single tuple-allocation primitive. It is used by:
- INSERT and UPDATE (`insert_encoded`, both branches);
- bulk/COPY (`insert_version_batch`);
- overflow-pointer tuples.

The rules:
1. If `PAGE_FLAG_FREE_SLOTS` is set, take the lowest FREE slot. It needs only `len` bytes, not `len + 4`.
2. Otherwise extend `slot_count`, and clear a stale hint.
3. RETIRED is never a candidate. `first_free_slot` matches `0/0` only.
4. Overflow pages: `ordinary_free_space()` is 0 for them, and the 0.2-I.1 refusal in the insert paths is unchanged. FREE can never exist there, because validation forbids it and `free_retired_slot` refuses.
5. On error nothing is modified. The free-space check happens before any byte is touched.
6. Bulk/COPY uses the same primitive. Its page choice now consults `free_space_map.take_known(needed)` before appending, so freed space is found by bulk loads too.
7. Rollback: all allocation happens in the transaction's private page images. An aborted transaction's images are discarded and never installed or published. A FREE slot taken by a rolled-back insert is therefore FREE again in published state (tests `k_rollback_of_a_private_reuse_leaves_the_committed_free_slot_intact` in storage and `k_rollback_consumes_no_slot_and_keeps_free_slots` in execution).
8. The bounds, checksum (sealed by the caller), LSN and private-page semantics are those of every other private page write.

### 5. The horizon gate (Part C) — exact condition and proof

#### Definitions (traced in `phobos-txn` / `mvcc_runtime`)

- **Publication sequence:** each commit is published with sequence = its WAL COMMIT LSN (`publish_one`, `receipt.lsn()`).
- **Statement pin:** a statement registers its snapshot in `SnapshotRegistry` with the `published` value at pin time, `S`. It reads only committed images, from the published state at or after `S`. Commits with sequence ≤ `S` are visible to it; later ones are not.
- **Reclamation horizon** `H` = min(pinned `S`) over live pins, or `published` if there is none. It is monotone non-decreasing.
- **`retired_at(page)`:** the sequence `R` of the reclaim publication that last retired a slot on that page. It is captured exactly as `last_reclaim_publication = receipt.lsn()` inside `publish_one`, and read back after `commit` returns (passes are serialized by `reclaim_lock`).

#### Condition implemented

```
free RETIRED slots of page P  ⇔  H > retired_at(P)        (strict)
```

#### Proof

1. A stale RID `(P, s)` can only come from:
   - an index entry `(key, (P, s))`;
   - a `previous` pointer;
   - a cached candidate list or a statement-local list built from either.

   Phase 1 removes the exact `(key, RID)` index entries in the same publication `R` that makes the slot RETIRED (C3, `delete_versions_sorted` in the prepare step of `R`). Every index image published at a sequence ≥ `R` no longer contains it.
2. A statement pinned at `S ≥ R` reads index and heap images that include `R`. It cannot obtain `(P, s)` from an index. It can obtain it as a `previous` pointer, but no execution path dereferences `previous` (Part I).
3. Therefore every statement that can hold the stale RID has `S < R`, and it holds a pin while it runs (statements, and the internal reclaim/diagnostic sessions, pin for their whole duration).
4. If `H > R`, then every live pin has `S ≥ H > R`. No live statement holds the stale RID. Every future statement pins at `published ≥ H > R` and is covered by (2).
5. Hence the slot may be handed to a new tuple. `H ≥ R` would already suffice; strict `>` costs nothing and keeps a margin.

#### Independent second line of defence (commit order)

The new occupant of a FREE slot is created by a transaction that commits at `C > R`. Even if a reader with `S < R` somehow dereferenced the RID, the new version's creator is invisible to `S`, so MVCC visibility rejects it. On top of that, the Part H key and identity re-validation turns it into a skip. A premature free would need three independent failures at once:
- the gate;
- the commit order;
- the key check.

### 6. Part D answers (retirement tracking)

1. **What sequence identifies the retiring publication?** The WAL COMMIT LSN of the internal reclaim transaction, which is PHOBOS's publication sequence. It is captured in `publish_one` (`last_reclaim_publication`) and recorded per page as the high-water mark `retired_at`. Until it is known (between planning and publication), the touched pages are marked `u64::MAX` (never freeable). That mark is rolled back only if nothing was published.
2. **Can it be recovered after restart?** It is not persisted and does not need to be. After restart, every RETIRED slot was retired by a publication `R ≤ published_at_open`. Every statement in the new process pins `S ≥ published_at_open ≥ R`. An absent mark is therefore treated as 0, and `H ≥ 1 > 0` holds. The post-restart header scan rediscovers RETIRED pages: those that keep `PAGE_FLAG_RECLAIM_CANDIDATE` while RETIRED slots remain, and every ordinary page whose census shows RETIRED slots. The latter includes pre-0.2-K tombstones on pages whose flag an older release cleared.
3. **Is it safe to treat every RETIRED slot as freeable after restart?** Yes, for the reason in (2): no statement, pin or RID-holding structure survives the process, and recovery reproduces only published page images. This is proven above and exercised by `phobos-server` `k_crash_before_free_after_free_and_after_reuse_recover_exactly` (child-process crash, then reopen).
4. **Other consumers:**
   - **Physical standby readers:** a standby never runs the reclaim worker, and its pages change only by replay. `replication-replay` takes the data-directory lock that a serving standby holds, so replay never runs while a standby statement exists. After replay, standby statements start fresh, which is equivalent to the restart rule. See `PHOBOS-0.2-K-STANDBY-REUSE-SAFETY.md`.
   - **Replication replay:** the standby holds no snapshot during replay (above). Replay installs byte-identical page images, which are trivially correct.
   - **Online backup:** a backup is a byte copy plus WAL. Restoring it runs recovery in a new process, so the restart rule applies.
   - **PITR:** recovery to an LSN replays published page images up to that LSN, in a new process. The restart rule applies, and RETIRED/FREE are just bytes.
   - **Future cursor/portal state:** any structure that keeps RIDs across statements MUST keep its snapshot pin registered for its lifetime. It is then inside the horizon and the proof holds unchanged. This is recorded as a design rule in `docs/storage_lifecycle_0_2_k.md`. No such structure exists today: streaming results pin their statement for the stream's lifetime.
5. **Is the per-page high-water mark sufficient?** Yes. If slots retired at `R1 < R2`, the mark is `R2`. Freeing all of them needs `H > R2 ≥ R1`, which is never premature.
6. **Can different retire publications on one page cause premature freeing or delay?** Premature freeing: no, as shown in (5). Delay: yes, by design, and it is bounded:
   - If `H > mark`, the pass frees the old RETIRED slots **before** retiring new ones in the same page image, and the mark moves to the new `R`.
   - Old slots wait only while `H ≤ mark`, i.e. while some snapshot older than the latest retirement is alive.
   - Once those snapshots end, `H` jumps past every mark.
   - The steady-state runs measure the cost: RETIRED counts stay bounded.
7. **Is per-slot metadata required?** No.
8. **Why not:**
   - The safety predicate is monotone in `R`.
   - A sound upper bound (the max) gives a sound gate.
   - The only cost of the over-approximation is a bounded delay, which ends when the oldest snapshot older than the page's latest retirement ends.
   - Per-slot sequences would be a page-format change (Part U) and would buy only that delay.

### 7. `previous` pointer rule (Part I)

Audit result: execution never dereferences `previous`.
- Visibility is decided by creator/deleter and the transaction status.
- UPDATE locates the current version by RID from its own scan, then re-checks that version's visibility (`SessionWrites::change`).
- Only `phobos-admin` integrity and forensics read `previous`.

New integrity rule (`mvcc_integrity.rs`): for a tuple `T` with `previous = p`, the pointer is **accepted** if `p` names one of:
1. **The true predecessor**: an occupied version with the same `logical_row`, whose `deleter == T.creator`, and whose creator sequence is earlier than `T`'s.
2. **An empty slot**: RETIRED, FREE or VACANT (the predecessor was reclaimed).
3. **A later occupant**: an occupied tuple that is *not* predecessor-shaped and whose creator's commit sequence is **greater** than `T`'s creator sequence (the slot was reclaimed and reused after `T` was written).

Anything else is reported as chain corruption. That covers:
- a same-row tuple with the wrong deleter;
- an older unrelated tuple;
- a tuple from an uncommitted or aborted creator posing as a predecessor;
- a pointer outside the file.

A forged pointer to an older, unrelated occupied tuple is detected (`phobos-admin` `k_previous_pointer_rule_accepts_reuse_and_still_rejects_corruption`).

### 8. Compatibility (Part U)

- No RID, index, WAL record or status-file format change. The page format version is unchanged (3).
- An older binary (0.2-I.3) reads a FREE entry exactly like a tombstone, because its `image_get` returns `None` for `len == 0` regardless of offset. It never reuses the entry; it appends.
- An older binary ignores flag bit 2. Trimmed or reset pages are ordinary valid pages to it.
- Lazy upgrade: databases written before 0.2-K hold only OCCUPIED and RETIRED entries. Their RETIRED slots are found by the first post-open header scan of a 0.2-K process and freed (absent mark ⇒ freeable). No migration step exists or is needed.


## PHOBOS 0.2-K — Standby Reuse Safety (Part J design gate)

### Requirement

A standby statement must never read a reused RID as though it were the old row version.

The primary's reclamation horizon covers only snapshots pinned in the primary's own `SnapshotRegistry`. Standby statements are not in it. When the primary frees and reuses a slot, the slot is only safe for *primary* statements. The question is what protects a statement on a physical standby when the WAL carrying that reuse arrives.

### How a PHOBOS 0.2-I.2/0.2-I.3 physical standby actually works (traced)

- `phobos-admin replication-receive PRIMARY STANDBY` copies durable V2 WAL into the standby's `received` file. It does not touch data files.
- `phobos-admin replication-replay STANDBY` (`replication.rs::replay_received`) applies the received WAL to the standby's data files and WAL. Its first action is `lock_dir(standby)`, an exclusive `try_lock` on `STANDBY/phobos.lock`, which fails with `DataDirectoryLocked`. This is unchanged from 0.2-I.2.
- A serving standby is `phobos-server` on a directory containing `PHOBOS_STANDBY_1`. `serve_with_settings` takes the same exclusive `phobos.lock` before opening the database and holds it for the server's lifetime. `Coordinator` marks the directory read-only and refuses every non-read statement.
- Consequence:
  - Replay and standby statement execution are **mutually exclusive in time**.
  - A standby statement runs against a data directory that does not change while the process is open.
  - Replay happens only while no standby process is serving.
  - A standby server opened after replay is a new process: every statement in it pins a snapshot of the replayed state.

### Options evaluated

| Option | Verdict | Reason |
|---|---|---|
| **A. Key/identity re-validation only** | Insufficient alone (kept as defence in depth) | It prevents wrong rows and false UNIQUE conflicts when a RID now names a different key or logical row. However, a reused slot *could* hold a new version of the **same** key (for example, a delete-then-reinsert of the same key landing in the same slot). Re-validation would accept it, and snapshot semantics would then depend on MVCC visibility alone. That is still correct for the creator-commit-order reason below, but it is not the "proof that every possible access path is protected" the spec demands when used alone. |
| **B. Replay conflict (wait/cancel standby statements before replaying reuse)** | Already satisfied, in its strongest form | PHOBOS's replay never overlaps any standby statement: replay requires the exclusive directory lock the serving standby holds. "Wait for all standby statements" is therefore the existing protocol: the standby must stop serving. No per-record conflict detection is needed, because there is no concurrent replay. |
| **C. Standby horizon feedback to the primary** | Not needed now; rejected for 0.2-K | It would hold back primary reuse for standby snapshots. That is only required once a standby replays *while serving* (continuous hot standby). It also couples primary storage growth to standby liveness, and that coupling would need its own slot semantics (like 0.2-I.2 WAL slots). Recorded as the design to adopt if hot standby is ever introduced. |
| **D. Process-level replay exclusion + restart rule + re-validation** | **Selected** | Proven below and tested. |

### Selected design (D) and proof

1. **The worker never runs on a standby.** `Coordinator::open_configured` starts `MaintenanceWorker` only when the directory is not a standby (`PHOBOS_STANDBY_1` absent) and `PHOBOS_AUTO_RECLAIM` is not `0`. The standby refuses `CHECKPOINT` and every write, so no reclaim pass can run there. Its pages change only through replay. Test: `phobos-server` `k_standby_runs_no_maintenance_worker`.
2. **No standby statement overlaps replay.** `replay_received` takes the exclusive directory lock, and a serving standby holds it. Test: `phobos-admin` `k_standby_replay_is_excluded_while_the_standby_serves`. With the lock held, replay fails with `DataDirectoryLocked` and changes nothing. After the lock is released, replay succeeds and the reopened standby equals the primary.
3. **Restart rule.** Every standby process opens a fully replayed, recovered directory. Every slot that is FREE or reused in it was freed and reused by primary publications at or below the standby's replay position. Every standby statement pins at or above that position. The proof in `PHOBOS-0.2-K-SLOT-STATE-MODEL.md` §5 (steps 2–5) applies verbatim: no standby statement can hold a RID from before the retirement.
4. **Commit order** (independent of 1–3). A reused slot's occupant was created by a transaction committed after the retiring publication. Any reader that could have seen the old entry has an older snapshot and cannot see the new creator.
5. **Re-validation (Part H)**, also independent of 1–4. Every index-originated dereference checks the key and logical identity, so a stale reference to a different row becomes a skip.

Physical WAL reproduces bytes exactly (FREE/RETIRED/trim/reset are ordinary page images). Reuse on the standby is therefore "byte-correct". The safety argument above does **not** rely on that alone, as the spec requires.

### Tests

| Test | Covers |
|---|---|
| `phobos-admin::k_backup_pitr_replication_and_standby_reads_reproduce_reused_slots` | The primary churns with slot reuse (>50 freed slots) across 8 rounds and 2 restarts. The standby receives and replays mid-way and at the end. Standby fingerprints and SQL reads (primary key, secondary index, COUNT) equal the primary's. Integrity passes on the standby. PITR to all 8 round boundaries matches the recorded fingerprints. |
| `phobos-admin::k_standby_replay_is_excluded_while_the_standby_serves` | Replay is refused while the standby serves, then succeeds after release. |
| `phobos-server::k_standby_runs_no_maintenance_worker` | A standby directory opened by `Coordinator` has no worker (`automatic_reclamation() == false`) and still serves reads. |
| `phobos-execution::k_stale_index_references_are_skipped_on_every_path` | Injected stale `(key, RID)` entries whose RID names a row with a different key (exactly what a reused slot looks like to an index reader) are skipped on indexed SELECT (COUNT, projected and full-row paths), indexed UPDATE/DELETE and the UNIQUE recheck. A true UNIQUE conflict is still raised. |
| 0.2-I.2 replication matrix 20/20, PITR 8/8 | Re-run on the 0.2-K tree: see `PHOBOS-0.2-K-REGRESSION-RESULTS.md`. |

### Limitations and conditions for revisiting

- The exclusion relies on the directory lock taken by `phobos-server` and `phobos-admin`. An *embedded* program that opens a standby directory with `MvccDatabase::open` and keeps it open while another process runs `replication-replay` is already unsupported in 0.2-I.2. Replay would change files under an open page cache whether or not slots are reused, and that remains unsupported.
- If PHOBOS adds continuous hot-standby replay (replay while serving), this gate must be re-opened. Option C (standby horizon feedback through the replication slot) or option B with per-publication conflict detection would then be mandatory before replaying any `RETIRED → FREE` image.


## PHOBOS 0.2-K — Reclaim Scheduler (Part K)

Code:
- `crates/phobos-execution/src/mvcc_runtime/maintenance.rs` (worker, config, wake-up signal).
- `crates/phobos-execution/src/mvcc_runtime/reclaim.rs` (the bounded pass, fair rotation, bookkeeping, metrics).
- `crates/phobos-server/src/lib.rs` (`Coordinator` ownership, metrics, admin API).

### 1. Ownership and lifecycle

- **One worker thread per open database** (`phobos-reclaim`), started by `Coordinator::open_configured` when **both** of these hold:
  - the directory is not a physical standby (`PHOBOS_STANDBY_1` absent);
  - `PHOBOS_AUTO_RECLAIM` is not `0`. The default is on.
- Embedded users of `MvccDatabase` may start one explicitly: `MaintenanceWorker::start(Arc<MvccDatabase>, MaintenanceConfig)`.
- **Stop:** `Coordinator::shutdown` stops and joins the worker **before** the database shuts down. `MvccDatabase::shutdown` also signals it (`sql_sessions.rs`). Dropping the `MaintenanceWorker` handle stops and joins it. Stop is interruptible: every wait and pause watches the stop flag.
- The worker runs inside `cancellation::suspend()`, so client cancellation never aborts maintenance. It uses its own session identity `u64::MAX − 2`.
- The thread is marked a maintenance thread (`phobos_observability::mark_maintenance_thread`). Per-directory test hooks (`synchronization_boundary`) therefore fire only for foreground work. Crash-point certification hooks are unaffected.
- A panic inside the worker is caught and counted (`maintenance.worker_panicked`). The database stays usable, and CHECKPOINT and `reclaim_once` still work.

### 2. Not an uncontrolled loop

The worker is **event-driven**. It sleeps on a condition variable (`Signal`) and wakes only when:
- a publication recorded new candidate pages (`note_candidate_pages` → `notify_publication`);
- or, **only while a horizon-blocked backlog exists**, a bounded poll interval elapses (250 ms). A snapshot release advances the horizon without any publication.
- or it is told to stop.

On wake-up it runs passes only while one of these is true:
- **eligible** candidate pages (pages that can progress at the current horizon) ≥ `trigger_pages` (8);
- or eligible > 0 and ≥ `trigger_publications` (64) publications accumulated since the last pass, so small hot tables are maintained too;
- or the post-restart header scan is incomplete.

It stops at the first of:
- a pass that made no progress;
- the backlog falling below the trigger;
- `max_passes_per_wake` (64).

With no writes, the worker performs **zero** passes and blocks indefinitely. The only exception is horizon-blocked work, which is re-checked every 250 ms with one bookkeeping read and no transaction.

### 3. Budget and foreground latency

| Bound | Default | Override |
|---|---|---|
| Candidate pages inspected per pass | 128 | `PHOBOS_AUTO_RECLAIM_PAGES` (1–4096) |
| Dead versions per pass | 8,192 | constant `MAX_VERSIONS_PER_PASS` |
| Wake-up threshold (eligible pages) | 8 | `PHOBOS_AUTO_RECLAIM_TRIGGER_PAGES` |
| Wake-up threshold (publications) | 64 | `PHOBOS_AUTO_RECLAIM_TRIGGER_PUBLICATIONS` |
| Duty cycle | 50 % (pause = pass time × (100 − d)/d) | `PHOBOS_AUTO_RECLAIM_DUTY_PERCENT` (1–100) |
| Pause cap | 50 ms per pause; no pause while the eligible backlog ≥ one full pass (catch-up) | `MaintenanceConfig::max_pause` |
| Page worthiness | ≥ 4 new dead versions on the page, or 10 s waited | `MaintenanceConfig::worth` (`WorthPolicy`) |
| Passes per wake-up | 64 | — |
| Horizon-blocked poll | 250 ms | — |
| Opportunistic status freeze | ≥ 2 s apart, only when the database is idle | — |

- **Serialization.** Every pass, whether from the worker, `CHECKPOINT` or `reclaim_once`, holds `reclaim_lock`, so passes never run concurrently.
- **One transaction per pass.** A pass is one ordinary internal MVCC transaction: private page images → WAL → install → publish. It competes with foreground commits exactly like one more writer. It never holds the database lock across its planning I/O (it plans under a statement snapshot).
- **No transaction identity or status record unless the pass publishes.** The pass uses `begin_deferred`, and an empty pass rolls back without allocating an identity.

#### Why the pause is capped (found during the long runs)

With the uncapped proportional pause, a pass stalled by I/O (a slow WAL force or an incremental checkpoint) was followed by an equally long pause. The foreground kept creating versions throughout.

Observed in the 3M-update hot-table run: one 25-cycle sample took 0.8 s instead of the usual ~0.17 s, and the backlog reached 1,600 versions. The heap file, which never shrinks, then recorded that peak: 18 → 48 pages in the last 2 % of the 3 M run.

Two changes fix this:
- The pause is capped at 50 ms.
- The worker does not pause at all while the eligible backlog exceeds one full pass.

**Evidence (same harness, same machine):**

| Run | Uncapped pause (`auto_prefinal_v1`) | Capped pause (`auto_prefinal_v2`) | Final build (`auto`) |
|---|---|---|---|
| Hot table, 3M updates | 2 → 17 → **48** pages | 2 → 14 → **14** pages | 2 → 16 → 20 pages |
| Hot table, 1M updates | 2 → 14 → 20 | 2 → 14 → 15 | 2 → 16 → 17 |
| 25K rows, 250 generations | 404 → 466 | 404 → **411** | 404 → **410** |
| 25K rows, 1,000 generations | 404 → 486 | 404 → **418** | 404 → **417** |
| OLTP-8, 300 s: heap pages / ops/s | 337 → 342 / 4,709 | 335 → 340 / 4,057 | 336 → 358 (live rows +7.6 %) / **6,257** |

With v2, the faster catch-up cost foreground throughput on this 2-vCPU machine: OLTP-8 ran at 4,057 instead of 4,709 ops/s. The final build runs at 6,257 ops/s against 0.2-I.3's 3,311 ops/s with `CHECKPOINT` every second; see the page-worthiness section below.

All `auto` results in the deliverables were re-measured with the final build, which has capped pacing, page worthiness and in-place pruning. The earlier runs are kept in the CSV as `auto_prefinal_v1` and `auto_prefinal_v2` for transparency.

#### Page worthiness (found with the Part R benchmark)

A pass rewrites every page it touches as one page image, whatever it reclaims on that page.

**Problem.** Under a random-update OLTP mix on a 100,000-row table, the first worker design rewrote pages that held one or two dead versions each. The commit-serialized part of each pass then cost foreground write throughput:
- OLTP-8 ran at about half of 0.2-I.3's rate in the 10-second benchmark windows.
- 0.2-I.3 does not reclaim at all during those windows, so it has no comparable cost.

**Profiling (spans enabled) found three costs:**
- the serial reclaim prepare: 11.5 ms per pass, dominated by index node decode and encode for each removed entry;
- a full-row decode of every version on every planned page;
- passes over pages that were barely worth rewriting.

**Three changes:**
1. **WorthPolicy (automatic passes only).** A candidate page is taken by the worker when one of these holds:
   - at least `min_versions` = 4 of its versions gained a deleter since its last visit (counted per publication);
   - it has waited `max_age` = 10 s;
   - it is unknown to the process (post-open header scan).

   Pages below the threshold hold fewer than 4 unreclaimed dead versions from that period, so the slack the policy adds is bounded per page, independent of time. `CHECKPOINT` and `reclaim_once` ignore the policy.

   Two further rules:
   - Horizon-blocked pages keep their accumulated worth, so a backlog held by a long snapshot is taken as soon as the snapshot ends. Before this rule existed, the long-snapshot run kept 20,000 dead versions for the whole phase after the release.
   - Slots a pass retires count toward the page's next visit, the freeing one, which the horizon gates anyway. RETIRED → FREE therefore follows promptly instead of waiting `max_age`.
2. **Index pruning** uses a zero-copy cursor descent and removes leaf entries in place (`RECLAIM-INDEX-PRUNING.md`). Serial prepare fell from 11.5 ms to 1.9 ms per pass.
3. **Planning** decodes the full row, including overflow chains, only for versions that are reclaimed; other versions are decoded header-only.

Benchmark impact before and after these changes: see `PHOBOS-0.2-K-BENCHMARK-RESULTS.csv` and the implementation report §4.

### 4. Fairness

- **Across tables:** round-robin. Each pass serves exactly **one** table: the first, in rotation order after the previously served table, that has work. A table with a huge backlog can take at most one pass in turn, so it cannot monopolize the worker.
- **Within a table:** candidate pages are taken in page order, starting after the last page served (wrapping around). A page range that keeps getting new dead versions cannot starve the rest of the file.
- **Horizon-blocked pages** are skipped without inspection (`blocked_until`: no progress is possible until the horizon exceeds a recorded threshold). They are counted in `pages_deferred`. The threshold is:
  - for a deferred dead version: its deleter's commit sequence − 1, or `published` if that commit has not happened yet;
  - for RETIRED slots: the page's `retired_at`.

  New dead versions recorded on a page drop its block, so it is reconsidered.

### 5. Bookkeeping correctness fix (pre-existing 0.2-I.3 defect found during this work)

**Defect.** In the 0.2-I.3 C1/C2 bookkeeping, a pass that found nothing reclaimable on a candidate page forgot the page. A concurrent publication that committed new dead versions on the same page *after the pass's snapshot was taken* re-recorded the page before the pass's bookkeeping ran. Its entry was then erased.

**Effect.** The page's dead versions were never reclaimed until a restart's header scan. Under the automatic worker this produced unbounded growth: 17 → 49 pages, with a dead backlog of 2,492, in the server's bounded-churn test.

**Fix.** Each candidate carries the generation of the publication that last recorded it. A pass forgets a page only if no publication re-recorded it since the pass looked at it.

**After.** The same test plateaus at 15 → 18 pages, with a backlog ≤ 200.

The defect is classified under gate F ("additional serious issue found"). It is fixed within scope and does not affect correctness of reads, only reclamation liveness.

### 6. Exposed metrics (Part K / N)

`MvccDatabase::reclaim_metrics()` → `ReclaimMetrics`, cumulative since open:

| Field | Meaning |
|---|---|
| `passes`, `automatic_passes` | passes run (all / by the worker) |
| `pages_examined` | candidate pages inspected |
| `versions_reclaimed` | dead versions retired (LIVE → RETIRED) |
| `slots_freed`, `slots_trimmed`, `pages_reset` | RETIRED → FREE, trailing trims, whole-page resets |
| `index_entries_pruned` | exact `(key, RID)` entries removed |
| `versions_deferred` | Σ dead versions a live snapshot may still need |
| `retired_deferred` | Σ RETIRED slots deferred by the horizon |
| `pages_deferred` | Σ candidate pages skipped as horizon-blocked |
| `elapsed_us` | total pass wall time |
| `candidate_pages` | current candidate pages (all tables) |
| `retired_pages` | current pages holding RETIRED slots awaiting the horizon |
| `last_rate_per_second` | versions/s of the last pass that reclaimed anything |

These metrics are exposed through:
- `Coordinator::reclaim_metrics()`;
- the `phobos_metrics` virtual table rows `reclaim_*`;
- `phobos-admin storage-lifecycle DATA [ROW_BYTES]`, which adds the per-table census (see `PHOBOS-0.2-K-IMPLEMENTATION.md` §Diagnostics).

`Coordinator::stop_automatic_reclamation()` exists for tests and operators that need exact deterministic counters. One existing server test (`b1_b2_hints`) uses it. Measurements are in `PHOBOS-0.2-K-STORAGE-LIFECYCLE-IMPLEMENTATION.md` §Results and `PHOBOS-0.2-K-STEADY-STATE-RESULTS.csv` (mode `auto`).


## PHOBOS 0.2-K — Reclaim Index Pruning (Part L)

Code: `crates/phobos-index/src/lib.rs`:
- `delete_version`;
- `delete_versions_sorted`;
- `prune_run_from`;
- `find_leaf_with_cursor`;
- `advance_leaf_cursor`.

The caller is `crates/phobos-execution/src/mvcc_runtime/publication.rs`, the reclaim prepare step.

**No index format change.** No page layout, entry encoding, node kind or free-list change was made, and the zero-copy `NodeView` reader is reused. Legacy-encoded nodes fall back to the typed path.

### 1. Root cause (0.2-I.3 `delete_version`)

For each dead version, reclaim removed the exact `(key, RID)` entry like this:
1. Descend by `key` to the **first** leaf of the key's run.
2. Search that leaf **linearly**. If the entry is not there, follow `next_leaf` to the right.
3. As soon as the walk left the descent path, it lost all parent information. For **every** deleted entry, whether or not the leaf became empty, it then called `find_path_to_page`. That is a depth-first search of the **whole tree** to rebuild the parent path for a possible detach.

For a duplicate-heavy key (a run of *n* entries spanning *L* leaves), each deletion therefore cost:
- O(L) leaf reads and decodes, because every deletion restarts at the run's first leaf;
- plus O(tree) node reads for the DFS.

Reclaiming *d* versions of the run cost O(d · (L + tree)). Forensics measured roughly 245–299 versions/s. On this Linux VM the same harness measured **196 versions/s** with 0.2-I.3 (20,000 rows on one key, 10,000 dead).

### 2. Changes (all four preferred items of Part L)

| Part L item | Implementation |
|---|---|
| 1. Detach path only if the leaf becomes empty | The detach path is materialized only in the `leaf.leaf.is_empty()` branch. |
| 2. Preserve and use parent/path information while walking right | `find_leaf_with_cursor` records `(internal node, child position)` per level during the descent. `advance_leaf_cursor` moves this cursor to the next leaf in tree order, like a classic B+tree iterator: it ascends to the first ancestor with a right child, then descends leftmost. The cursor is cross-checked against the leaf chain (`== Some(next)`). If they ever disagree, the old DFS is used as a fallback and counted (`index.reclaim_path_dfs`). That case is never expected and was never observed. |
| 3. Search inside each leaf by `(key, RID)` | Each leaf does a binary search to the first entry of `key` (`partition_point`, or `NodeView::lower_bound_bytes` on the zero-copy view), then scans only that leaf's slice of the run for the RID. A leaf whose last key sorts after `key` ends the walk. |
| 4. Avoid whole-tree DFS per deleted entry | DFS remains only as the fallback described in item 2. |

**Batch continuation (`delete_versions_sorted`).** Reclaim prepare now sorts the pass's dead entries by `(key, RID)` per index and prunes them in one call.

For entries of the same key, the walk **continues from the leaf and cursor of the previous deletion** instead of restarting at the run's first leaf. RIDs within a run are in `(key, RID)` order, and the dead RIDs are sorted the same way. Pruning *d* entries of a run therefore walks the run's leaves about once, so the per-pass cost is O(L + d) instead of O(d · L).

If an entry is not found ahead of the current position (RIDs not ordered across leaves, or a legacy node), the run is searched again from its first leaf, exactly as `delete_version` does. The results are therefore identical to calling `delete_version` per entry in order. Leaves are read through the zero-copy `NodeView`; only the leaf that changes is decoded and rewritten.

**Zero-copy descent and in-place removal.** These were added after the Part R profiling.
- `delete_versions_sorted` descends through `NodeView`: internal nodes are never decoded, using the same child rule as the decoded descent (the position is the number of separators `< key`).
- A leaf that keeps at least one entry has the entry spliced out of the page bytes directly:
  - the count, used bytes, zero tail, reserved parent field, page LSN and checksum are written exactly as `encode_node` writes them;
  - only the current format is handled this way, and never in batch-cache mode.
- A leaf that becomes empty takes the decoded path with detach.

The new unit test `phobos-index::k_batch_pruning_equals_per_entry_pruning_page_for_page` checks this. It builds two identical trees of 6,000 entries (long duplicate runs plus distinct keys). It prunes 2,400 entries on one tree with the batch path and on the other with per-entry `delete_version`, including whole emptied leaves. It then asserts that every page is **byte-identical**, as are the root and free-list head, and that the surviving entries are exactly the live versions.

The first version of the in-place splice kept the page-LSN bytes, and this test caught it before any measurement.

In the 100,000-row OLTP benchmark, serial reclaim prepare fell from 11.5 ms to 1.9 ms per pass. Index node decodes during OLTP fell from about 180,000 to about 5,800.

**Unchanged semantics:**
- Exact `(key, RID)` match only.
- Empty-leaf detach rules (not the root; a left sibling under the same parent takes over).
- The durable free list.
- Private-owner checks.
- One publication per pass.

### 3. Measurements (same machine, same harness, release builds)

| Measure | 0.2-I.3 | 0.2-K | Change |
|---|---|---|---|
| Duplicate-heavy reclaim: 20,000 rows on one key, 10,000 dead versions, `reclaim_once(64)` drain (`kh dups 20000`) | 10,000 versions in 50.93 s = **196 versions/s** | 10,000 versions in 0.342 s = **29,271 versions/s** (final build; 22,513 before the zero-copy and in-place pruning) | **×149** (+29,075 versions/s) |
| OLTP reclaim probe: 8 clients for 300 s on 20,000 rows; backlog drained with `reclaim_once(64)` (the forensic method) | 9,392 versions in 34.08 s = **276 versions/s** | 11,483 versions in 0.419 s = **27,411 versions/s** (final build; the earlier builds measured 7,574 and 6,475) | **×99** |
| Forensic reference (Windows/0.2-I) | 245–299 versions/s | — | — |
| Unit test `k_duplicate_heavy_index_pruning_is_exact` (6,000 rows on 2 keys, 3,000 dead; timing printed by the test) | 1,251 versions/s (per-entry 0.2-K cursor path before batch continuation was added; development measurement) | 35,357 versions/s (with `delete_versions_sorted`; development measurement) | ×28 |

The probe numbers include heap work, WAL and publication, not only index pruning. The OLTP probe on 0.2-K drains a backlog that the automatic worker leaves small; on 0.2-I.3 the backlog had grown to more than 200,000 dead versions.

### 4. Correctness evidence

- `phobos-execution::k_duplicate_heavy_index_pruning_is_exact`: runs of 3,000 equal keys across many leaves; 3,000 dead versions. After reclaim, exactly the 3,000 versions are retired, the index holds exactly 6,000 entries (one per live row), and indexed COUNT/SUM over both keys return the exact expected values.
- `phobos-execution::k_indexed_and_unique_churn_keeps_indexes_and_uniqueness_exact` and the steady-state runs: `phobos-admin` integrity reports PASS after every experiment, in all 21 harness runs (see `PHOBOS-0.2-K-STEADY-STATE-RESULTS.csv` and the run logs).
- The existing C3 reclaim tests (`reclaim_tests.rs`), unchanged except for the two-phase expectation documented in `PHOBOS-0.2-K-REGRESSION-RESULTS.md`, pass.

### 5. Not done (out of scope, no format change)

There is no index-node merging or rebalancing. As in 0.2-I.3, only empty leaves with a left sibling under the same parent are detached. Index size in the steady-state runs is flat after warm-up (see the CSV), so no format change was justified by the measurements.


## PHOBOS 0.2-K — Transaction-Status File Lifecycle (Part M)

**Verdict:** **partially implemented, remainder explicitly deferred with quantified justification.**

- A crash-safe, format-neutral **physical release of the frozen prefix** is implemented, tested and measured.
- It bounds the status file's disk allocation whenever the existing logical freeze frontier advances.
- Under **sustained concurrent write load with no idle moment**, or while **old never-updated tuples** pin the frontier, the logical frontier does not advance. The file then still grows by 32 bytes per write transaction.
- Fixing that completely needs either a non-quiescent freeze sweep plus tuple freezing, or a segmented/rebased status file. Tuple freezing and a segmented file are on-disk semantic or format changes. Under Part U that is a STOP condition: it is documented here, not implemented.

### 1. Facts (traced)

- `phobos.mvcc-status` is a fixed-address array. Transaction identity `id` lives at `HEADER + (id − 1) × 32`. Every write transaction appends one 32-byte record. Identities are never reused.
- The logical freeze (0.1.x C4, `freeze_once` → `SessionManager::freeze_if_idle` → `StatusFile::freeze_unreferenced`) advances an exclusive boundary `frozen_before`. It is persisted in the two-slot watermark file `phobos.mvcc-freeze`. Statuses below the boundary are never read again:
  - `read_status` refuses them;
  - recovery validates from the boundary and skips frozen WAL commits.
- The boundary advances only when **both** of these hold:
  1. A **complete heap sweep** proves that no tuple references an identity below it, as creator or deleter. The sweep restarts whenever any transaction identity is allocated between its incremental steps.
  2. The database is **idle**: no pinned snapshot and no open transaction (`freeze_if_idle`, under `lock_commits_quiescent`).
- In 0.2-I.3 the boundary was purely logical. The bytes stayed on disk forever, so the file grew by 32 B per write transaction regardless of freezing. Forensic finding D.

### 2. What 0.2-K implements — physical release (`StatusFile::release_frozen_prefix`)

The prefix is released without changing the format:
- Because the file is fixed-address, its prefix cannot be cut off without renumbering, which would be a format change.
- Instead, once a freeze advances the boundary, the file is **rewritten sparse**:
  - A temporary `phobos.mvcc-status.compact` gets the identical header and every record at or above the release boundary, at its **original offset**. The prefix is never written, so it is a hole.
  - The temporary file is `fsync`ed, atomically renamed over `phobos.mvcc-status`, and the directory is `fsync`ed.
- **Release boundary** = `min(previous.before, new.before)`. Both valid watermark slots have frozen that prefix, so recovery falling back to the older slot still finds every record it can read.
- **Threshold:** a release runs only when at least `DEFAULT_TRIM_RECORDS` = 2^17 records (4 MiB) became releasable since the last release. The copy cost is therefore amortized: each release copies the unfrozen tail once per ≥ 4 MiB freed. The threshold is configurable for tests (`set_status_trim_threshold`).
- **Crash safety:**
  - Building the copy never touches the live file. Any failure there (for example ENOSPC) only skips the release (`mvcc.status_prefix_release_skipped`).
  - A crash before the rename leaves the old file intact, and recovery deletes the leftover temporary file (`recover`).
  - A crash after the rename leaves the new file, which contains every readable byte.
  - Only from the rename onward does a failure fence the store (the handle may be on the replaced inode). Recovery reopens the authoritative file, exactly like other status I/O failures.
- **Format:**
  - The apparent length, header and record layout are unchanged. An older binary reads the file identically: holes read as zeros, and zeros below the boundary are never read.
  - No watermark, WAL or replication format change.
- **Platform:** Unix only (sparse files). On other platforms the rewrite would release nothing, so it is skipped. Windows sparse-file support (`FSCTL_SET_SPARSE` / `FSCTL_SET_ZERO_DATA`) would need `unsafe` FFI. That is forbidden by the workspace lint (`unsafe_code = "forbid"`), so it is deferred.
- **Opportunistic freeze:** the 0.2-K maintenance worker attempts `freeze_once` at most every 2 s, and only when the database is idle (§1, condition 2). A reclaim pass via `reclaim_once`/`CHECKPOINT` also runs it, as in 0.2-I.3.

### 3. Tests

| Test | Covers |
|---|---|
| `phobos-admin::k_status_prefix_release_is_physical_crash_safe_and_format_neutral` | 30,000 write transactions. Nothing is released below the default threshold. With a threshold of 1,000: frozen boundary > 25,000, allocated blocks < ¼ of the apparent length, apparent length unchanged (fixed addressing). A leftover temporary file is ignored and removed. Reopen, write, crash without shutdown, reopen, integrity PASS. |
| `phobos-admin::k_status_prefix_release_preserves_backup_pitr_and_replication` | Prefix released **before** an online backup and repeatedly **after** it, with a restart in between. A lagging standby receives and replays across the releases: its fingerprint equals the primary's and integrity passes. PITR to 4 targets after the backup matches the recorded fingerprints, and integrity passes on each. The primary reopens with integrity PASS. |

### 4. Measurements (same machine, release build)

**A. Hot table, single-client autocommit UPDATE, 300,000 write transactions** (`kh status`). 0.2-I.3 drains every 1,000 updates; 0.2-K runs the automatic worker.

| Updates | 0.2-I.3 apparent / allocated | 0.2-K apparent / allocated |
|---|---|---|
| 100,000 | 3.21 MB / 3.22 MB | 3.25 MB / 3.26 MB |
| 180,000 | 5.78 MB / 5.79 MB | 5.85 MB / 5.86 MB |
| 200,000 | 6.42 MB / 6.43 MB | 6.50 MB / **2.31 MB** (first release: 2^17 records) |
| 300,000 | 9.64 MB / 9.64 MB | 9.75 MB / **5.56 MB** |

0.2-K allocation is a sawtooth:
- It is bounded by **(unfrozen tail) + 4 MiB threshold + 4 KiB**, instead of 32 B × all transactions ever.
- In this workload, each further 131,072 transactions trigger another release.
- The heap stayed at **4 pages**; 0.2-I.3 reached 167.

**B. OLTP, 8 clients for 300 s, 20,000 rows (no idle moment)** (`kh oltp`, final build).

| | 0.2-I.3 | 0.2-K |
|---|---|---|
| Throughput | 3,311 ops/s | 6,257 ops/s |
| Write transactions (status records) | ≈ 497,000 | ≈ 971,000 |
| Status file, apparent = allocated | 15.9 MB | 31.1 MB |
| Growth rate | 53 KB/s | 104 KB/s |

No release happens under OLTP:
- The idle condition never holds, so the logical frontier never advances.
- Projected at this rate: **≈ 373 MB/hour, ≈ 9 GB/day** of status file per sustained ~3,200 write transactions/s. Linear in transactions, exactly as in 0.2-I.3 (32 B per write transaction).
- The heap, by contrast, is flat per live row.

### 5. Why the remainder is deferred

1. **Non-quiescent freeze sweep.**
   - The sweep restarts on every identity allocation. Under continuous load it never completes, so the frontier never moves. A sound concurrent sweep is plausible: references created after the sweep starts carry newer identities, and the boundary loop already stops at in-progress records.
   - But it rewrites the proof obligations of the 0.1.x C4 freeze, which is certified together with old-slot recovery. It needs its own crash and recovery campaign.
   - Estimated risk: medium–high. This would be the first item of a follow-up release.
2. **Old tuples pin the frontier.**
   - A row inserted at load time and never updated keeps its creator identity forever, so the boundary can never pass it.
   - Fixing that is *tuple freezing*: rewriting the creator to a "frozen" marker, as in PostgreSQL. That is a persistent semantic change of the tuple header.
   - The alternative is a **segmented or rebased status file** that keeps referenced records and drops unreferenced ranges. That is a status-file format change.
   - Part U: on-disk format changes stop here. Decision requested.
3. **Windows sparse release** needs `unsafe` FFI (forbidden), or an alternative such as a rebased file, which is again a format change.

**Recommendation:** release 0.2-K with the physical release mechanism. Schedule a dedicated "Status Lifecycle V2" with:
- (a) a concurrent freeze sweep (no format change);
- (b) a design decision between tuple freezing and a segmented status file (format change, explicit migration policy).

The quantified exposure until then is 32 B per write transaction under sustained load, about 3.2 GB (3.0 GiB) per 100 M write transactions.
