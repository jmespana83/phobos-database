# Write and Concurrency Architecture V3 — audited checkpoint plan

Status: C1 and C2 are approved and frozen. C3 passed its Fast gate and is frozen as
a bounded-writeback checkpoint; performance is mixed, with material regressions.
See write_concurrency_v3_c3_report.md and write_concurrency_v3_c3_design.md.
C4–C8 have not started.
The architectural audit below describes the frozen starting point.

## Frozen starting point

Isolated checkout: `work/write-v3/phobos`. Source is the certified frozen archive,
SHA256 `46e1f93da0a8afd8f136100f6a10145238241b28bef0ce628a418bef3d53e527`.
Keep all prior deliveries immutable. Freeze accepted checkpoints into separate
source/evidence archives with SHA256 manifests; preserve failed attempts too.

The current source, rather than old proposal notes, establishes these constraints:

| Boundary | Current implementation | Consequence |
| --- | --- | --- |
| Server | `phobos-server/src/lib.rs`, Coordinator: database Mutex, separate owner Mutex/Condvar; execute and streaming retain database guard | Explicit transactions block other sessions, and streaming holds execution ownership during delivery |
| Execution | `phobos-execution/src/lib.rs`, Database owns mutable catalog, heap/index objects, one PrivateTransaction and Wal | Multiple pending commits cannot safely be introduced merely by dropping the server mutex |
| Commit | `private_transaction.rs::commit_private_transaction`: prepare redo, wal.commit, install pages, metadata/lifecycle, possible checkpoint, cleanup | Private transaction ownership must survive asynchronous completion; durability and publication are currently coupled |
| WAL | `phobos-wal/src/v2/log.rs::commit`: append complete COMMIT, clear active chain, sync_prefix, construct private-field DurableCommit | Codec can represent consecutive complete transactions; API cannot presently return several receipts from one force |
| Page I/O | `phobos-storage/src/page_io.rs`: private images installed after receipt; unforced_lsn/durable_lsn barriers | Data fsync is deferred, but page installation still occurs on the committing path |
| Overlay | `private_pages.rs`: 64 cached pages, 4096 hash heads, validated scratch records, File-before-Cleanup ordering | Reuse bounded storage and cleanup semantics; introduce ownership transfer and pending-generation reads |
| Transactions | `phobos-txn/src/lib.rs`: durable ID allocation, no snapshot/visibility registry | MVCC needs durable visibility state and a bounded retention/reclamation design |
| Heap/index | storage lib.rs HeapTable/BufferPool; index lib.rs BPlusTree | Preserve codecs where compatible, pin guarantees, checksums, and index ordering; introduce versioned tuple envelopes only for MVCC |
| Bulk | execution insert loops heap.insert and insert_index_entries; CREATE INDEX calls heap.scan and tree.insert for every row | Batch heap work first, then safe sorted index construction; existing index algorithm remains available |

## Invariants across every checkpoint

1. COMMIT success requires a complete COMMIT record within the successfully forced
   WAL prefix. An append ticket is never a DurableCommit receipt.
2. Publication is ordered and atomic across heap, indexes, catalog and transaction
   status. Pending generations must not leak to public readers.
3. A write/sync failure fences the affected durability domain. Dependent pending
   transactions cannot continue from uncertain state. Durable-but-unacknowledged
   commits may recover; errors must not falsely promise rollback.
4. Physical page writes require page_lsn <= durable_wal_lsn. Re-dirtied pages and
   failed I/O remain dirty until the correct image has been forced successfully.
5. Queues, frames, snapshots and transaction-status caches have explicit bounds.
   Backpressure replaces unbounded retention; scratch ownership lasts until safe retirement.
6. Old binaries reject incompatible format capabilities before modification.
   Migration is offline and backup-first; never silently reinterpret existing tuples.
7. Preserve current strict transaction semantics on the legacy path. Introduce
   Read Committed explicitly for the new MVCC mode, with its isolation advertised;
   do not silently replace an existing strict transaction with weaker isolation.
8. No source-level Clippy suppression, disabled failing test, durability relaxation,
   PostgreSQL rerun, long soak, or repeated 10M suite is part of this plan.

## C1 — true group commit, including necessary ownership prerequisites

Changes: WAL writer/receipts; execution PrivateTransaction; private page ownership;
server commit admission; observability. Keep WAL v2 record encoding and consecutive,
non-interleaved transaction chains unless a proven incompatibility requires a version.

Implementation steps:

- Split WAL completion into append_commit returning an opaque pending ticket and
  force_through returning receipts only for validated tickets covered by that force.
  Retain the synchronous commit adapter for existing callers.
- Introduce owned PreparedCommit state: transaction identity, WAL end LSN, frozen
  heap/index overlays, root/allocation metadata, catalog/statistics deltas, cleanup
  guards and completion sender. Detach state without dropping backing files.
- Maintain an ordered pending generation chain. Serialized successor writers may
  use predecessor state internally, but public reads stay behind the durable
  publication frontier until MVCC arrives. Rollback restores the predecessor view,
  not stale disk pages. Never let later page images erase earlier pending writes.
- Use bounded queue count/bytes and a deadline-driven batch policy. Initial
  experimental bounds: 64 transactions, 1 MiB queued WAL budget, maximum 200 us
  collection window. A single oversized transaction gets its own bounded/spooled
  path. Measure 0/50/200 us configurations; select from evidence, not sleep loops.
- A single WAL owner drains complete chains and forces the captured prefix. Publish
  covered transactions in order; acknowledge only after their visible state is
  coherent. A queue arrival beyond that captured prefix must await the next force.
- DDL/lifecycle/checkpoint requests are explicit drain barriers initially. Explicit
  transactions retain their current ownership rules until the MVCC checkpoints;
  disclose this initial batching boundary.
- On partial append or sync failure, fail all affected waiters, fence successors,
  preserve recovery evidence and close handles before cleanup. Disconnect after
  submission does not revoke a potentially durable commit.

Acceptance: real server concurrent autocommits share a force (not only synthetic WAL
calls); deterministic barriers prove exact covered receipts and failure fan-out;
dependent A/B writes and B rollback preserve A; public reads cannot see a pending
batch; unique collisions remain enforced. Report actual commits/fsync, WAL fsync
count, batch sizes, queue/force/publication latency, p50/p95/p99 and total latency.
Freeze only after server integration, 100K correctness, short crash smoke and 1M
measurement pass. WAL-only batching is an intermediate substep, not C1 completion.

## C2 — refine commit/WAL synchronization separation

Build on C1's minimum necessary separation. Isolate the WAL owner from execution,
catalog and page guards. Distinguish queue wait, append time, durable wait and
publication wait. No WAL wait or client/network write may retain structural guards.
Use monotonic generation/ticket IDs to prevent stale wakeups or checkpoint races.
Bound queue shutdown and cancellation; fail every accepted waiter exactly once.
Test paused fsync, queue saturation, arrivals during force, disconnect, DDL drain,
and shutdown while commits are pending. Measure 1/4/8 writers at 100K and 1M.

## C3 — committed dirty-page buffering and background writer

Add a shared committed page store in storage, keyed by immutable file identity and
page ID. Reads consult committed frames before disk. C1 publication transfers WAL-
protected images to this store without synchronously installing every page.
Keep page_lsn, earliest unflushed rec_lsn, dirty generation and pin ownership.

Use an initial configurable 64 MiB resident dirty budget, a bounded outstanding
backlog and a worker with page/byte limits per wake. Values are starting measurement
settings, not frozen tuning claims. Transfer large transactions through existing
bounded scratch ownership; do not load all their pages into memory at COMMIT.
Eviction may write only eligible committed images. Excess backlog applies admission
backpressure; it cannot create unlimited scratch or WAL growth.

Copy/pin an eligible image under its page guard, release structural locks for I/O,
and clear dirty state only if its generation still matches after successful I/O.
Serialize writes to the same physical page to prevent an older in-flight image from
overwriting a newer one. Retain dirty state on failed write/force. Provide an explicit
fallible shutdown that drains workers and forces required data; Drop cannot silently
turn an I/O failure into a successful clean-shutdown claim.

Acceptance: ACK before installation with worker deliberately paused, recovery of
never-written acknowledged pages, pin/eviction pressure, stale write completion,
I/O failure retention, bounded memory/backlog and worker shutdown. Measure pages and
bytes written/forced, dirty high-water mark, backlog, stalls and commit latency.

## C4 — checkpoint v2

First implement an explicit drain-and-force recovery boundary on the new page store.
Then allow concurrent writers with a captured checkpoint generation and earliest
unflushed rec_lsn; do not advance the boundary over any unforced dependency.
Keep redo from the minimum required LSN, including redirtied pages, transaction
status and lifecycle effects. The current checkpoint_all guard cannot simply be
weakened: retain WAL conservatively until partial-boundary retention is implemented
and validated. Version any new checkpoint/capability records explicitly.

Flush eligible captured images, force affected files/metadata, durably publish a
complete checkpoint/anchor, then retire only proven-unneeded WAL and tombstones.
Test every ordering boundary with pending commits, writeback and redirty races,
torn pages, stale/future LSNs and repeated recovery. Admin backup must acquire an
exclusive consistent boundary and drain background work. Clean shutdown uses the
same barrier and propagates errors. Freeze with actual recovery-distance/WAL-volume
measurements, not just successful CHECKPOINT syntax.

## C5 — MVCC Read Committed foundation

Introduce per-session TransactionContext and a statement snapshot of the published
commit sequence. Every statement gets a fresh Read Committed snapshot, while own
writes remain visible across statements. Streaming holds its statement snapshot,
not the global transaction-owner mutex, for the result lifetime.

Versioned tuple envelope: stable logical row identity/version link, creator TxID,
deleter/updater TxID where present, and sufficient status/commit-sequence information
to resolve committed/in-progress/aborted visibility after recovery. Keep SQL values
and the public row/client codec unchanged. Use an explicit heap/anchor capability
and offline migration; do not hide metadata in v2 reserved bytes.

Transaction status must be WAL-protected and checkpoint-safe: a bounded cache over
durable status storage, or safely frozen tuple status below a proven visibility
horizon. Do not truncate WAL needed to interpret surviving xmin/xmax. Track oldest
active snapshots; bound retained versions/status with backpressure and incremental
safe reclamation. This foundation must not depend on an ever-growing RAM map.

Index entries point to versions; visibility filtering must cover point, range,
scan, join, grouping and streaming. Preserve old key versions for active readers
until reclamation is safe. Use logical-row and unique-key conflict locks; after
waiting, recheck visibility/version and uniqueness. Overlapping updates cannot
both succeed against the same stale version. Test aborts, own writes, delete/update,
NULL/composite uniqueness, statement refresh, long scans and status recovery.

Acceptance includes a paused ordinary writer while a different session completes
its read, without exposing uncommitted rows. Preserve the legacy strict-mode tests
unchanged and add explicit Read Committed tests; no blanket weakening of assertions.

## C6 — finer transaction/lock coordination

Remove old owner serialization from the MVCC route. Separate transaction registry,
catalog schema publication, table/index structural coordination, page/frame guards
and WAL submission. Keep DDL exclusion conservative until dependencies are covered.

Proposed lock rules to encode in APIs/tests:

- Acquire schema handles before transaction conflict locks; conflict lock identities
  are canonical (table/row or index/key). Use deadlock detection or an explicit
  victim policy for dynamically discovered conflict sets; sorting one statement's
  keys alone does not prevent cross-statement deadlocks.
- Structural acquisition follows catalog -> table/index ID -> page ID. B+ tree
  descent/split exceptions use validated latch coupling/restart, not arbitrary
  nested page locking. Never wait for transaction status while holding page latches.
- Frame-directory lookup pins a frame and releases its directory guard before a
  page latch is acquired; no reverse acquisition while holding that page latch.
- WAL thread never calls execution while holding WAL state; callers drop structural
  locks before waiting for durability, queue capacity or network delivery.

Acceptance: mixed read/write progress, two-row deadlock pattern, unique-key races,
split races, cancellation, timeout/disconnect cleanup, and lock-wait distributions.
No claim of parallel execution based solely on separately named mutexes.

## C7 — dedicated bulk loader

Add an internal iterator/batch bulk API with explicit all-or-nothing transaction
semantics. Encode bounded row batches, reserve/fill heap pages sequentially and update
free-space state per batch/page. Preserve row typing, NULL, uniqueness and rollback.
Log complete page images or other supported WAL records in bounded batches;
use the same coordinator/visibility/durability path as ordinary transactions.

Expose the API through a bounded client/CLI ingest path after the internal path is
validated (the exact command spelling is secondary). No server-side arbitrary file
read shortcut. Preserve auth/TLS and request-frame limits; use bounded chunks and
end-of-import commit. Test input errors midway, disconnect, abort, WAL faults,
existing indexes and spill/backpressure. Measure encode/allocation/index/WAL shares.

## C8 — batched and bulk index maintenance

For fresh unpublished indexes, externally sort bounded key/RID runs, merge with
unique/composite/NULL checks, pack leaves sequentially, then build internal levels
and publish the root/catalog only through the normal durable transaction boundary.
Use the existing comparator, node codec, checksums and recovery identities.

For existing indexes, add sorted page-local batches with guarded traversal reuse
and correct invalidation after splits. Retain the ordinary path as a reference.
Validate against it on duplicate/null/composite inputs, split boundaries, rollback,
MVCC visibility and recovery. Counters must show reduced descents/decodes/page writes;
row throughput alone is insufficient. Do not publish a heap lacking required indexes
or constraints while postponing index construction outside the transaction.

## Checkpoint acceptance and measurement policy

Each major checkpoint: formatting check, strict workspace/all-target/all-feature
Clippy, workspace tests and appropriate focused tests. Storage/WAL checkpoints also
run a total of 24 targeted campaign crash cycles initially (12 boundaries twice),
covering before/after WAL durability, commit publication, dirty write/force and
checkpoint. Account for recovery injections in benchmark harnesses so development
campaign totals stay within 20–50; do not blindly invoke nested V2 Fast/Milestone
scripts that add hidden crash loops, 10M runs or soaks.

Use 100K development tests and 1M primary measurements. Measure direct correctness
and normal release binaries separately from profiling/fault-injection builds.
Record source/build hashes, exact SQL/operations, seed 8067, settings, warmup policy,
raw samples, WAL bytes/fsync counts, latency percentiles and lock/queue waits. Retain
failures and distinguish a harness defect from a runtime failure; never retune until
a test happens to pass. Checkpoint freeze requires correctness, crash recovery and
measurement evidence; an unintegrated foundation is explicitly marked incomplete.

Create `tools/write-v3-validation.ps1` with explicit checkpoint modes, fail-fast
native exit checks and new evidence directories. No long soak is required.

## Final measurements, only after C1–C8 pass

- A: exactly one durable 10M bulk load, no 10M full suite. Report seconds, rows/s,
  WAL bytes/forces, heap/index writes and peak memory, including required indexes
  in the timed atomic load. Saved PG = 65.1579075 s; primary <325.7895375 s,
  stretch <130.315815 s. Flag API/transport/isolation differences explicitly.
- B: on a prepared 1M DB, exactly three autocommit INSERTs per timed sample; report
  median elapsed time across fresh, equivalent samples. Saved PG total = 0.0007059 s;
  primary <0.0035295 s, stretch <0.0014118 s.
- C: three INSERTs in one explicit transaction on the same scale; report COMMIT and
  total separately. Saved PG total = 0.0006788 s; primary <0.003394 s,
  stretch <0.0013576 s. Do not compare commit-only to PG's total.
- D: existing matched 1M concurrent-writer workload, 4 clients x 3 autocommits;
  saved PG total = 0.0022723 s. Report throughput, latency, transactions/force and
  waits. Use a separate clearly labelled short saturation diagnostic if 12 commits
  are insufficient for stable fsync-amortization statistics.

Preserve the previously measured PostgreSQL CSV hash
`047e2ad0cb660845ddbe3f691817a0a4c49b9f2de2cfe1a1ff058234f54c889e`.
Use matched V2 Phobos TCP evidence, not the old pre-V2 Phobos columns in that CSV,
as the Phobos before comparison; collect a new V2 control only when needed for a
compatible metric and never rerun PostgreSQL. Do not use copied-fixture first-force
costs as a substitute for warmed committed small-write latency.

Finish with formatting, strict Clippy, workspace tests, docs, short final crash
smoke and `docs/write_concurrency_v3_report.md`. State target misses plainly. No
checkpoint or final performance result is claimed by this plan.
