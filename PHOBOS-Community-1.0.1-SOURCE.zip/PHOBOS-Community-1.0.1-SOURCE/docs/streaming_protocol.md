# Negotiated result streaming, payload version 1

S1 introduced result transport and the incremental client API. S2 now executes SELECTs through bounded operators and a synchronous ResultSink; transport and process-memory acceptance are being validated. Legacy collecting APIs and EXPLAIN ANALYZE still materialize. No WAL or data format changes are part of these checkpoints.

The existing envelope version 1, 16-byte header and 1 MiB payload maximum remain unchanged. Legacy Hello and Query (10)/QueryResult (11) behavior remains available. A client opts in by including the exact semicolon-delimited `stream=1` token in Hello. It must observe that capability in HelloAck before using QueryStream (12). QueryStream contains UTF-8 SQL; flags must be zero. Every response frame carries the request ID.

Streaming message types are Start (13), Rows (14), End (15), Command (16), and Error (17). Every payload begins with version byte 1. All integer fields use network byte order. Strings and binary values carry a u32 byte length; strings must be UTF-8.

| Message | Fields after the version byte |
| --- | --- |
| Start | u32 column count, length-prefixed column names |
| Rows | u64 zero-based sequence, u32 row count, encoded rows |
| End | u64 total rows, u64 total batches |
| Command | length-prefixed command tag, u64 affected rows |
| Error | length-prefixed error code and message |

A row begins with a u32 value count, equal to the Start column count. Each value has a one-byte type tag followed by its value: 0 NULL (no bytes), 1 INT64 (i64), 2 BOOLEAN (byte 0 or 1), 3 FLOAT64 (u64 IEEE bits), 4 TEXT (length and UTF-8), 5 BINARY (length and bytes), 6 DATE (i32), 7 TIMESTAMP (i64), 8 DECIMAL (i128 unscaled and u8 scale). Values are self-describing; Start supplies names, not static column types. NULL and text containing tabs, newlines or NUL are unambiguous.

Successful rows follow Start, zero or more Rows, then End. Commands are standalone. Error terminates a request, including after a partial result. A received prefix without End is never success. The client validates IDs, sequence, counts, value encodings, flags, payload version, lengths and trailing bytes. Any stream error, malformed response, premature EOF or callback error closes and poisons the connection. A fresh connection is needed afterward.

Batches have at most 256 rows, targeting approximately 64 KiB. Each frame remains within both the 1 MiB protocol cap and the configured result byte limit. A single row may exceed the target batch size but must fit a frame; oversized rows fail explicitly. The old total-result cap still applies to legacy Query. Negotiated streaming treats that configured byte limit as a per-frame limit.

`Client::negotiate_streaming` explicitly negotiates the capability. `Client::query_stream` delivers typed events through a synchronous callback; consuming and releasing a batch before returning permits incremental client memory use. `Client::query` remains the collecting compatibility API. The CLI `stream` command prints batches incrementally; late errors exit unsuccessfully. Transport bytes include headers in stream profiling counters. A five-second socket write timeout bounds a stalled receiver; disconnect releases the coordinator's transaction ownership and rolls back an active transaction.

S1 released the database mutex after producing its owned result snapshot. S2 retains execution ownership through the complete live result or cancellation to preserve statement isolation. Authentication, role checks and TLS use the same server session boundary as legacy queries.

The first development smoke validated 10,000 rows, 42 row batches and 2,741,289 protocol bytes, plus CLI output. Its timing includes assertions and is not a headline performance measurement. Live join/sort and TLS tests now pass. Larger-scale memory acceptance remains a separate gate. Client::set_io_timeout allows an explicit idle timeout for large first-row computations; the existing five-second default is unchanged.
