# Session 005 — Phase 4 candidate

## Objective
Implement Phase 4 disk-backed indexes without beginning Phase 5 concurrency.

## Implemented
- New `phobos-index` crate with fixed-page, checksummed B+ tree storage.
- Leaf/internal/root splits and linked leaf traversal.
- Composite, unique, and non-unique keys; NULL-containing unique keys may repeat.
- Point and bounded range scans.
- Exact entry deletion with under-full pages retained (merge/rebalance deferred).
- Integrity validator for ordering, parent pointers, reachability, checksums, and sibling linkage.
- Separate checksummed index catalog `indexes.phc`.
- `CREATE [UNIQUE] INDEX` and `DROP INDEX` SQL.
- Index maintenance for INSERT/UPDATE/DELETE.
- Rule-based index selection for single-column range/equality and full composite-key equality.
- `.idx` files included in transaction snapshots and Phase 3 WAL recovery.
- Startup cleanup of orphan index files after committed DROP INDEX/recovery.
- Randomized B+ tree mutation/model tests plus crash-recovery coverage through the execution suite.

## Deliberate limits
- No B+ tree merge/rebalance yet; deletion preserves correctness but may leave sparse pages.
- No statistics/cost model, covering indexes, index-only scans, online index builds, prefix compression, or concurrent index modification.
- Phase 5 remains unimplemented.

## Local gate
Run `tools/phase4-smoke.ps1` on Windows. This build environment does not contain Rust, so compile/lint/test status must be confirmed locally before Phase 4 is declared complete.
