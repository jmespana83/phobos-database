# PHOBOS 0.2-I — Platform-aware request transport V3 (design)

Baseline: 0.2-H source `37e3f81d0cecf27322e877430ac430006b5cb3dd311f38dcd532338ed1f061d9`.

0.2-I is a stabilisation release. The 0.2-H engine (Batch DML V2, encoded
index mutations, per-leaf merge, admission key reuse, in-place private heap
pages, slow-request trace) is unchanged. What changes is *which request
transport a server uses*, plus shutdown-marker robustness. No WAL, page,
catalog or protocol format change.

## 1. Why

0.2-H made the connection's worker read its own frames (`Direct`) instead of
receiving them from a per-connection reader thread over a one-slot channel
(`Pumped`, the 0.2-G transport). On Linux this removed one hand-off, one
context switch and ~1.8 CPU migrations per request. On Windows the 0.2-H
formal run kept the engine gains (500-row transaction 7.7 → 5.6 ms, point p50
0.125 → 0.120 ms) but OLTP8 fell 13,374 → 10,125 ops/s and OLTP16 12,391 →
8,945 ops/s. Direct is the primary working hypothesis for that loss, not a
proven cause: there is no same-machine Windows Direct-vs-Pumped run. 0.2-I
therefore makes the transport a platform policy, keeps both transports, and
uses the long-proven one on Windows.

## 2. Policy

```
PHOBOS_REQUEST_PATH   unset | auto | direct | pumped      (case-insensitive, trimmed)

RequestPath::resolve(platform, tls) -> ResolvedPath
  tls                      -> Pumped   (Direct reads the raw socket; rustls
                                        buffers plaintext it cannot see)
  Direct                   -> Direct
  Pumped                   -> Pumped
  Auto, Windows            -> Pumped   (0.2-G OLTP8/16 behaviour)
  Auto, Linux / other Unix -> Direct   (0.2-H measurements)
```

* Read once in `serve_with_shutdown_file` (`RequestPath::from_env`), before
  the data directory is opened; an invalid value (anything else, including
  an empty value) is a start-up error with the existing configuration error
  code and prefix (`ResourceLimit`, "configuration: invalid
  PHOBOS_REQUEST_PATH=…: expected auto, direct or pumped (unset = auto)").
  No new error code: the code set is part of the protocol.
* Resolved once per server (`RequestPath::resolve`, the only place the
  choice is made) into a `ResolvedPath` that every plain-TCP connection's
  job captures by value. Nothing reads the environment per connection or per
  request. `serve_with_request_path(settings, file, policy)` takes the policy
  explicitly (tests, embedding).
* `Platform` is a parameter of `resolve`, so the Windows rule is unit-tested
  on Linux (`i_policy_resolution_matrix`).
* Start-up writes one operator-log line:
  `event=request_path policy=auto resolved=pumped platform=windows tls=false`.
  Profiling counters: `request.transport.auto_resolved_direct`,
  `request.transport.auto_resolved_pumped` (per connection, auto policy only),
  `request.direct`, `request.pumped` (per request, unchanged from 0.2-H).

Both transports stay compiled and runtime-selectable on every platform.

## 3. Pumped exactness (Part D)

The Pumped code path is byte-for-byte the 0.2-H one (reader thread,
`sync_channel(1)`, disconnect detection, bounded pipelining, 100 ms receive
timeout + `closed` flag, shutdown, cancellation, TLS). 0.2-H's only additions
to it — a hand-off timestamp carried with each frame and the profiling events
`request.pumped` / `request.handoff_ns` / the slow-request trace start — are
observability, inert in release builds except one `Instant::now()` per frame;
they were kept (they measure the very hand-off this release reasons about).

## 4. Direct review for Windows (Part E)

No deterministic correctness defect was found; nothing in Direct changed.
Findings, all *hypotheses* that only a Windows measurement can confirm:

| area | Direct behaviour | assessment |
|---|---|---|
| receive timeout | worker blocks in `recv` with the 100 ms `SO_RCVTIMEO` the Pumped reader also used | same Winsock exposure as 0.2-G (Winsock documents a timed-out blocking receive as leaving the socket state indeterminate; 0.2-G has run this way for years) |
| monitor thread | one parked thread per connection, 100 ms ticks | 16 OLTP connections → ~160 wake-ups/s; not visible in Linux profiles; on Windows a hypothesis only |
| monitor creation | one thread spawn per connection | benchmark connections are long-lived; negligible |
| socket peek | only while a statement has run ≥ 100 ms | OLTP statements are milliseconds: practically never runs |
| first-request peek | one non-blocking `peek` per connection | toggles the shared socket's non-blocking flag on the worker thread before execution; the monitor is idle then |
| scheduler | the worker is woken by network I/O instead of by a condition variable signalled from the reader thread | **main hypothesis**: Windows applies different wait-completion priority boosts and processor placement to I/O-woken and event-woken threads; with 32 workers + 16 monitors on Windows this may change how followers arrive during a group commit (OLTP8/16 depend on group formation). Linux showed unchanged group sizes |
| worker ownership, teardown, shutdown | unchanged from 0.2-H (monitor joined in `Drop`; registered socket shut down on server stop) | no issue |

The optional `diagnostics\RUN-TRANSPORT-AB.cmd` (same binary, pumped vs
direct) is the Windows experiment that would settle the hypothesis.

## 5. Engine independence (Part F)

The transport only produces frames and consumes responses; the engine entry
point (`session_requests_configured`) is the same for both. Test
`i_direct_and_pumped_servers_are_logically_and_physically_identical` runs
one deterministic workload over a real TCP server per transport — 500-row
transactions in 2 × 250-row statements (Batch DML V2, encoded leaf merges,
in-place heap pages), statement-level and committed UNIQUE conflicts, a
rolled-back 500-row transaction, an indexed UPDATE, a row-growing UPDATE, an
UPDATE creating a duplicate, DELETE, CHECKPOINT — then restarts the server
(recovery) and re-reads. Statement outcomes, query results, post-restart
results **and every heap and index file byte** are identical between Direct
and Pumped.

## 6. Shutdown marker (Parts G–I)

Failure seen on Windows: a helper wrote `shutdown.request` in place; the
server saw it and `remove_file` failed with os error 32 (sharing violation)
because PowerShell still held the handle; `?` turned that into a server
error.

* Helpers (Part H): `Write-ShutdownSignal` (PowerShell) and `request_stop`
  (Python) write `shutdown.request.tmp`, close it, and rename it into place;
  the marker never exists while a writer holds it. Every helper uses them;
  `package-selfcheck.py` rejects any in-place marker write.
* Server (Part I): once the marker is observed, shutdown proceeds.
  `remove_shutdown_marker` treats only Windows error 32 (sharing), 33 (lock)
  and 5 (access denied, e.g. delete pending) as transient: it retries for up
  to ~1 s, then logs `event=shutdown_marker status=left_in_place` and
  continues the clean shutdown. Any other error is reported as before.
  The start-up contract is unchanged: a marker already present when the
  server starts still requests an immediate clean shutdown (the existing
  `a5_startup` test relies on it). A marker left in place is therefore
  cleaned up by the start helpers, which already delete stale lifecycle
  files (`shutdown.request`, now also `shutdown.request.tmp`) before they
  launch a server; the A/B and profiling helpers use a fresh instance per
  run. (A first 0.2-I draft removed stale markers in the server at start-up;
  it broke that contract — `a5_startup` hung — and was reverted.)

## 7. Not done

PreparedWritePlan, committed-tree batch UNIQUE probing and parser allocation
work remain deferred. No WAL or Direct-transport change. No Windows
performance claim: the user's formal Standard run decides promotion.
