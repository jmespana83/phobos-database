# SQL reference — Community 0.1.9-E4+E5

Phobos supports a deliberately bounded SQL subset. Unsupported syntax should fail explicitly.

## DDL and inserts
- `CREATE TABLE name (column TYPE [NULL|NOT NULL], ...)`
- `CREATE TABLE parent (...) PARTITION BY RANGE (column)`
- `CREATE TABLE child PARTITION OF parent FOR VALUES FROM (lower) TO (upper)` creates one non-overlapping `[lower, upper)` local table.
- `CREATE INDEX name ON table (column [, ...])`
- `CREATE UNIQUE INDEX name ON table (column [, ...])`
- `DROP INDEX name`
- Types: BIGINT/INTEGER, BOOLEAN, FLOAT/DOUBLE/REAL, TEXT/VARCHAR, BINARY/BLOB, DATE, TIMESTAMP, DECIMAL/NUMERIC(p,s) with precision up to 38.
- `INSERT INTO table VALUES (...), (...)`

## Queries
- `SELECT * FROM table`
- `SELECT col1, col2 FROM table`
- Optional `WHERE`, `ORDER BY`, `LIMIT`, and `OFFSET`.
- Qualified column references such as `orders.customer_id` are accepted by the Phase 6 relational path.
- Multiple left-deep `INNER JOIN`, `JOIN`, or `LEFT [OUTER] JOIN` clauses with equality conditions are supported. Join-order search is not implemented.
- `SELECT DISTINCT` uses the same canonical equality as GROUP BY and can spill under `query_memory_bytes`.
- `IN` accepts value/parameter lists or an uncorrelated one-column SELECT. `LIKE` supports `%` and `_` with binary, case-sensitive matching.
- `GROUP BY` and `HAVING` are supported for the declared Phase 6 aggregate subset.
- Aggregates: `COUNT(*)`, `COUNT(col)`, `SUM(col)`, `AVG(col)`, `MIN(col)`, `MAX(col)`.
- Aggregate/output aliases use explicit `AS`.

Example:

```sql
SELECT customers.name AS name,
       COUNT(*) AS order_rows,
       SUM(orders.amount) AS total
FROM customers
LEFT JOIN orders ON customers.id = orders.customer_id
GROUP BY customers.name
HAVING order_rows > 0
ORDER BY name;
```

## Statistics and plans
- `ANALYZE table`
- `EXPLAIN SELECT ...`
- `EXPLAIN ANALYZE SELECT ...`

ANALYZE records row count, approximate distinct values, NULL fraction inputs, and observed min/max text. DML invalidates statistics for the modified table.

## Data modification
- `UPDATE table SET col = expression [, ...] [WHERE predicate]`
- `DELETE FROM table [WHERE predicate]`

## Transactions
- `BEGIN` or `BEGIN TRANSACTION`
- `BEGIN [TRANSACTION] ISOLATION LEVEL SNAPSHOT`
- `SAVEPOINT name`, `ROLLBACK TO [SAVEPOINT] name`, `RELEASE SAVEPOINT name`
- `COMMIT`
- `ROLLBACK`
- `CHECKPOINT`

Read Committed remains the default. Explicit Snapshot transactions retain one committed frontier, see their own writes, and use first-committer-wins row conflict checks. Read-only Snapshot transactions retain a pin without allocating a transaction ID. Savepoints are nested markers over bounded memtables and immutable spill runs; ownership acquired after a marker may be conservatively retained until the outer transaction ends. Savepoints after bulk, maintenance, or staged schema work are rejected; rolling back schema work to an earlier savepoint is supported.

Range partition parents are logical. Inserts route by the partition key, reads aggregate child results with range pruning, and parent DELETE/non-key UPDATE fan out to local children. Cross-partition key UPDATE is rejected. Indexes are local; create indexes explicitly on child tables. Eligible read-only partition scans use at most `parallel_scan_workers` query-local workers after `parallel_scan_min_pages`.

## Expressions
- Literals: integers, floating point, strings, TRUE, FALSE, NULL.
- Column references and `$1`, `$2`, ... typed parameters.
- Boolean: `AND`, `OR`, `NOT`.
- Comparisons: `=`, `!=`, `<>`, `<`, `<=`, `>`, `>=`.
- NULL tests: `IS NULL`, `IS NOT NULL`.
- Numeric arithmetic: `+`, `-`, `*`, `/`.
- Parentheses and standard precedence for the implemented operators.
- Searched `CASE WHEN predicate THEN expression ... [ELSE expression] END`.
- Scalar functions: `LOWER`, `UPPER`, `LENGTH`, `ABS`, `COALESCE`, and `NULLIF`.
- Double-quoted identifiers preserve exact case/text. `--` line and `/* ... */` block comments are accepted.

SQL comparisons involving NULL produce UNKNOWN; WHERE/HAVING retain only TRUE.

## Parameters
The engine API `Database::execute_params(sql, params)` binds typed values directly to `$n` placeholders. It never performs SQL-text interpolation. Typed parameter frames over the network remain a later protocol milestone.

## Prepared statements

The server supports session-local parameterless read preparations:

```sql
PREPARE point AS SELECT value FROM items WHERE id = 42;
EXECUTE point;
DEALLOCATE point;
```

Names are case-insensitive identifiers. Preparation stores and reuses the parsed AST; execution still creates a fresh Read Committed statement view and uses the ordinary E3 planner. CREATE/DROP schema or index changes advance a generation, causing lazy reparse before the next execution so stale metadata cannot run. Prepared state is never persisted and is dropped with the session. `EXECUTE` uses the normal statement timeout and cancellation handle. Typed parameters and prepared mutations are intentionally deferred because they would require a wider protocol/parser change.

## Current SQL boundaries
- equality joins only;
- no table aliases;
- subqueries are uncorrelated and supported only for `IN`; no scalar/correlated subqueries, CTEs, window functions, set operations, or merge join;
- no `COUNT(DISTINCT ...)`;
- HAVING uses projected columns/aggregate aliases rather than repeating aggregate function syntax;
- the ordinary query API materializes UTF-8 text results; the streaming protocol supports typed row batches;
- parser/expression depth is bounded at 64;
- SELECT requires supported column/aggregate projections and FROM; SELECT 1 and INSERT SELECT are unsupported.
- prepared statements are currently parameterless, read-only, and session-local.

The production server refuses the legacy V1 directory-copy executor and requires offline MVCC migration for such stores. The compatibility `Database` implementation remains for migration and historical tests; MVCC is the supported production execution engine.
