# PHOBOS — Handoff to the next coding agent

This file is self-contained: it assumes no prior conversation history. PHOBOS is a from-scratch relational database engine in Rust: an embedded engine plus a server (`phobos-server`) and an admin CLI (`phobos-admin`).

## 1. Authoritative implementation baseline

| | File | SHA-256 |
|---|---|---|
| **Current source (0.2-K.4)** | `PHOBOS-Community-0.2-K.4-LazyIndexPruningV1-SOURCE.zip` | see `PHOBOS-0.2-K.4-FINAL-HASHES.txt` |
| Input (0.2-K.3) | `PHOBOS-Community-0.2-K.3-LowCostReclaim-SOURCE.zip` | `06cc6c6d4709284b2f191f2755f712197fcf373ee9b3cc649f5982868e53c7b6` |
| 0.2-K.2 | `PHOBOS-Community-0.2-K.2-WindowsBulk-ReclaimCost-SOURCE.zip` | `de5be96c2332f4f3790ba10e24647e8bf34ea15ea4780579d6b9bc37183fb834` |
| 0.2-K.1 | `PHOBOS-Community-0.2-K.1-PerformanceRecovery-SIAPV2-SOURCE.zip` | `2a2ab7b46fb040a8a5c0e1ba87acff268082cd8e799ba36a9311bb7deea3e280` |
| 0.2-K | `PHOBOS-Community-0.2-K-StorageLifecycleV1-SOURCE.zip` | `3257dfb971eee8bf638b771dee47e76e17781d4d1fbd71abae61f3b244aee1e8` |
| 0.2-I (historical baseline) | — | `6d24d89bfcaf7e905d86d2c9c63198c3304643086d934bfbc4196d0d4725bad7` |

The 0.2-J and 0.2-JR lines are abandoned. Do not use them.

**Build and toolchain:**
- Cargo workspace under `crates/`. Edition 2024, `rust-toolchain.toml` pins **1.85.0**.
- Development here used stable 1.97, so avoid let-chains and newer std APIs.
- `unsafe_code = "forbid"` in the workspace.
- Gates: `cargo fmt --all -- --check`, `cargo clippy --workspace --all-targets` (warnings deny), `cargo test --release --workspace`.
- **Known test:** `phobos-server` `g34::roles_password_auth_and_secret_safe_audit_are_enforced` fails with `EAGAIN` in sandboxed Linux. It fails identically since 0.2-I.3. It is environmental and still needs to be checked on Windows.

## 2. Architecture summary

### Storage
- Slotted 8 KiB heap pages, one `table-<id>.heap` per table.
- Page format v3 is "versioned"; v1/v2 are legacy.
- Heap pages hold MVCC tuple versions: creator, deleter, `logical_row`, `previous`.
- Wide rows go to overflow chains on dedicated overflow pages. **Invariant:** an overflow page never holds an ordinary tuple (0.2-I.1).
- A free-space map (FSM) does first-fit page selection.
- Committed pages live in a shared committed-page cache: **256 MiB default** (`page_cache_bytes` / `PHOBOS_PAGE_CACHE_BYTES`, since 0.2-K.1), with background flush and checkpoint.

### MVCC
- Snapshot isolation with a transaction-status file (`phobos.mvcc-status`, 32 B per write transaction).
- Commit sequence numbers and a publication horizon.
- Write-write conflicts use wait-die: "younger transaction is victim". These are retryable.
- Every commit goes through a serialized commit pipeline:
  1. admission queue with group commit (up to 64);
  2. serialized "prepare" that rebases the private changes onto the latest images;
  3. WAL append;
  4. group fsync;
  5. ordered publication.

### Slot lifecycle (0.2-K)
- **States** (encoded in the existing 4-byte slot entry): OCCUPIED → RETIRED (`len = 0`, offset kept) → FREE (`offset = 0`), plus Vacant (past the directory end).
- **RETIRED → FREE** only when `horizon > retired_at` (two-phase, horizon-gated).
- **FREE slots are reused first.** Trailing FREE entries are trimmed, and all-FREE pages are reset.
- RIDs (`page_id: u64`, `slot_id: u16`) can therefore be reused. **Every RID dereference revalidates identity** ("Part H"):
  - `get_version` / `slot_reclaimed`;
  - key equality against the current occupant;
  - MVCC visibility.

### Deferred compaction (0.2-K.3)
- Reclaim never repacks pages.
- `ordinary_free_space()` counts the fragmented bytes.
- An insert repacks a page only when it needs the space.

### WAL v2
- Physical page images and deltas, plus logical records.
- Schema changes are logged as whole-file `Metadata` records (`catalog.phc`, `indexes.phc`, `phobos.stats`) by schema publications.
- Segment rotation is crash-safe (0.2-I.3: recovery handles interrupted rotation).
- Retention for replication slots is fixed in 0.2-I.2.

### Indexes
- B+tree, one `index-<id>.idx` per index, entries `(key, RID)`. `(key, RID)` is a **set**: inserting an existing pair is a no-op.
- MVCC: entries are added per version and never updated in place.
- Removal happens only by reclaim (eager exact deletion, now leaf-grouped) or by the 0.2-K.4 sweeper.
- **Leaves are never merged**: a known drift, see §4.

### Reclaim
- `crates/phobos-execution/src/mvcc_runtime/reclaim.rs` and `maintenance.rs`.
- An automatic background worker (`PHOBOS_AUTO_RECLAIM=0` disables it) runs bounded passes over candidate pages.
- **Worth policy:** a page is rewritten once it has ≥ 4 new dead versions or has waited 10 s.
- **Batching:** at most one pass per 100 ms; a pass yields up to 1 s to a busy commit pipeline.
- **One pass = one durable publication:**
  - RETIRE the dead versions;
  - FREE the horizon-proven RETIRED slots;
  - remove the exact UNIQUE index entries;
  - apply a sweep slice (K.4).
- A pass is fault-isolated: a panic marks maintenance faulted; reads and writes continue; a restart resumes (0.2-K.1).

### Lazy index semantics (0.2-K.4)
Under the catalog capability `LAZY_INDEX_PRUNING_V1`:
- Reclaim no longer deletes **non-unique** index entries. Stale entries are harmless because of Part H.
- A **budgeted round-robin sweeper** finds stale entries outside the commit pipeline, on a statement view. It re-checks every candidate inside serialized prepare and removes them with one leaf rewrite per leaf run. Code: `mvcc_runtime/lazy_index.rs`.
- A sweep cycle starts once lazily created stale entries reach `max(2048, entries_last_cycle / 10)`, so the stale ratio is kept near 10 %.
- **UNIQUE indexes stay eager.** An experimental lazy-UNIQUE variant was measured and **removed** (§5).
- `PHOBOS_LAZY_INDEX=0` restores eager pruning for every index and never enables the capability.

### Compatibility marker (0.2-K.4)
- `catalog.phc` version 3 = the version 2 layout plus a `u32` capability bitmask; bit 1 = `LAZY_INDEX_PRUNING_V1`.
- It is enabled by a WAL-logged schema publication, either at writable-primary open (if a non-unique index exists) or before the first lazy reclaim pass.
- Older binaries refuse version 3 with "unsupported catalog format". Unknown bits are refused with an actionable `Unsupported` error.
- Details: `PHOBOS-0.2-K.4-COMPATIBILITY.md`.

### Replication / PITR
- Physical WAL shipping with replication slots, standby receive/replay, archive, and point-in-time recovery to a WAL target.
- A standby is marked by `PHOBOS_STANDBY_1`; it is read-only and has no worker.
- Capability and catalog changes arrive through replayed `Metadata` records.

### Recovery
- WAL redo of page images and deltas, plus metadata.
- Status-file validation from the freeze boundary.
- Overflow repair tool: `phobos-admin repair-overflow`.
- Integrity: `phobos-admin check` (offline) and online `CHECK`. Since K.4 these report live, stale and corrupt index entries.

## 3. What is solved (with the release that solved it)

| Problem | Status |
|---|---|
| Original slot leak (slots never reused, 4.1 B/version floor, abandoned pages) | **Solved, 0.2-K.** Bounded heap under constant-cardinality churn. |
| Post-restart overflow-page misplacement (silent row loss) | **Solved, 0.2-I.1.** Guard, detection (`check`) and offline repair. |
| Replication slot retention across the shutdown checkpoint / WAL retention | **Solved, 0.2-I.2.** |
| Interrupted WAL rotation recovery | **Solved, 0.2-I.3.** 19/19 crash matrix. |
| Bounded storage lifecycle with an automatic worker | **Solved, 0.2-K, hardened in K.1.** Fault isolation. |
| Eager page compaction in reclaim | **Removed, 0.2-K.3.** Deferred compaction. |
| Non-unique index exact deletion in the serialized reclaim path | **Removed, 0.2-K.4.** Lazy pruning plus sweeper, capability-gated. |
| Secondary range latency | **Solved, 0.2-K.1.** 256 MiB cache. Windows 1 % secondary cold: 67.5 → 13.45 ms. |
| "Windows BULK regression" | **Closed.** Same-harness Windows A/B: K.2 equals or beats 0.2-I (100K 0.918 vs 0.936 s; 1M 9.857 vs 12.553 s; 3M 53.29 vs 56.70 s). The earlier "regression" compared different workloads. |

## 4. What remains unsolved

1. **Reclaim worker OLTP gap.** See §5. With K.4 the worker still costs about 26 % at OLTP8 and 26 % at OLTP16 on the 2-vCPU Linux box; the Windows targets are ≤ 8 %. The remaining cost is roughly:
   - the reclaim heap-page publications (each reclaim pass republishes ~0.5 heap page per version);
   - UNIQUE eager deletions;
   - the worker's CPU (planning and sweep inspection decode rows) competing with clients on small machines;
   - lower write locality: FREE-slot reuse scatters new versions, raising heap checksums per commit by about 1.7×.
2. **Status-file sustained growth.** 32 B per write transaction while the freeze frontier cannot advance (under continuous load, or when old never-updated tuples pin it). It needs a concurrent freeze sweep plus tuple freezing or a segmented status file: a format decision. Windows sparse release is impossible without `unsafe`.
3. **Index page no-merge drift.** Leaves are never merged, so index pages grow under churn with monotonically moving keys, on K.2, K.3 and K.4 alike. This is separate from lazy stale entries: entry counts stay bounded.
4. **True Secondary Index Access Path V2.** Index-only and covering scans, bitmap heap scans. Note that index-only scans must account for lazy stale entries: they cannot trust an entry without a heap check unless a visibility map is introduced.
5. **Chunked/Pipelined Bulk V2.** Bulk load writes every byte about 3×: private spill, WAL page images, data files.
6. **SQL feature gaps.** The SQL subset is limited. For example, `%` (modulo) is not supported by the parser.
7. **Compatibility limitations.** A database with `LAZY_INDEX_PRUNING_V1` cannot be opened by 0.2-K.3 or older. There is no tool to clear the bit; dump/reload or a K.4 rebuild with `PHOBOS_LAZY_INDEX=0` is required.
8. The SQL-path bulk insert (1000-row `INSERT` statements in one transaction) is super-linear at 1M rows (pre-existing since 0.2-I).

## 5. Performance baselines (keep them separate)

**Historical 0.2-I Windows Standard suite** (user's frozen suite, TCP): BULK 100K ~0.94 s, 1M ~7.47 s, 3M ~28.2 s. **This is a different workload** from the harness `bulk_load`; do not compare the two.

**Like-for-like Windows, K.2 vs 0.2-I** (same harness, user machine): see §3, BULK closed.

**Windows quick-ab, K.2** (user machine):

| | OLTP1 | OLTP8 | OLTP16 |
|---|---|---|---|
| Worker ON | 3,404.8 | 4,216.3 | 3,502.6 |
| Worker OFF | 3,883.2 | 6,512.3 | 4,891.5 |
| Gap | −12.3 % | −35.3 % | −28.4 % |

**Windows secondary** (K.1): 256 MiB cache, 1 % range cold 13.45 ms, warm 10.28 ms, point p50 0.032 ms.

**Linux, 2 vCPU, same embedded harness (`i1h bench`, 10 s per mix), worker ON vs OFF gap:**

| | OLTP1 | OLTP8 | OLTP16 |
|---|---|---|---|
| K.2 | −4.2 % | −26.9 % | −26.6 % |
| K.3 | −11.3 % | −25.8 % | −27.9 % |
| **K.4** | **−19.7 % (one run contaminated; clean run −8.8 %)** | **−26.4 %** | **−25.5 %** |

Raw values are in `PHOBOS-0.2-K.4-OLTP.csv`.

**Linux reclaim micro** (60K rows, UNIQUE + secondary, 6K scattered dead versions), per reclaimed version:

| Metric | K.2 | K.3 | K.4 |
|---|---|---|---|
| Pass | 70.4 µs | 55.7 µs | 66.5 µs (incl. sweep inspection) |
| Serialized prepare | 44.9 µs | 32.7 µs | 21.1 µs |
| Eager index deletions | 2.0 | 2.0 | 1.0 (UNIQUE only) |

**Experiments that did not reach target (K.4, Linux):**

| Variant | OLTP8 / OLTP16 worker ON, ops/s (OFF ≈ 7.5K / 7.9K) |
|---|---|
| min_versions 8 | 5,782 / 6,239 |
| min_versions 16 + sweep divisor 4 | 5,951 / 6,221 |
| + lazy UNIQUE | 6,022 / 6,608 |

**Still to run on Windows:** everything in §6 for K.4. No K.4 Windows numbers exist yet.

## 6. Exact Windows validation commands (K.4)

```powershell
cd tools\k4-validation
.\build.ps1                                   # optional: -Baseline C:\path\to\PHOBOS-0.2-K.3-source (same harness vs K.3)
.\quick-ab.ps1                                # worker ON/OFF x3; OLTP1/8/16 gap PASS/MISS (5/8/8 %), error counts
.\reclaim-micro.ps1                           # per-version reclaim cost (K.4, and K.3 with -Baseline)
.\lazy-index-correctness.ps1                  # adversarial lazy-index + UNIQUE + lifecycle tests (cargo test)
.\index-boundedness.ps1 -Generations 100      # workload A: stale entries / index entries per generation
.\sweeper-catchup.ps1                         # workload B: 10K rows, 20 s burst then idle; stale_ratio
.\integrity-check.ps1                         # phobos-admin check on a churned DB with stale entries
.\standard.ps1 -Suite "<frozen Standard suite command>"
```

**Switches:**
- `PHOBOS_AUTO_RECLAIM=0`: worker off.
- `PHOBOS_LAZY_INDEX=0`: eager pruning, no capability.
- `PHOBOS_LAZY_SWEEP_ENTRIES` (default 4096): entries per sweep slice.
- `PHOBOS_LAZY_SWEEP_DIVISOR` (default 10): target stale ratio of about 1/divisor.
- `PHOBOS_AUTO_RECLAIM_MIN_VERSIONS` (default 4).
- `PHOBOS_AUTO_RECLAIM_MIN_INTERVAL_MS` (default 100).
- `PHOBOS_AUTO_RECLAIM_YIELD_MS` (default 1000).
- `PHOBOS_PAGE_CACHE_BYTES` (default 256 MiB).

## 7. Next recommended milestones (ranked)

1. **Validate K.4 on Windows** (§6). If OLTP8/16 is still above 8 %, profile with the `prof` build: `.\build.ps1` builds `target\prof\release\k4bench.exe`, and `PROF_OUT` writes span CSVs.
2. **Remove reclaim heap-page publications from the foreground pipeline's critical path.** Options:
   - retire through tiny page-delta records instead of full page publication;
   - or piggyback RETIRE/FREE onto foreground commits that already dirty the page;
   - or make reclaim publications preemptible (split into small groups that never hold the commit order for more than ~1 ms).

   Also restore write locality: prefer tail/hot pages over scattered single FREE slots (the K.3 MRU attempt failed; try reuse only on pages that are already dirty in the cache).
3. **Status Lifecycle V2:** a concurrent freeze sweep (no format change), then a decision between tuple freezing and a segmented status file.
4. **Index leaf merge / rebalance** for no-merge drift, done by the sweeper while it rewrites leaves anyway.
5. **Secondary Index Access Path V2** (bitmap or ordered heap fetch; covering indexes only with a visibility map, because of lazy entries), then **Chunked/Pipelined Bulk V2**.

## 8. Where things are

| Area | Location |
|---|---|
| Lazy index | `crates/phobos-execution/src/mvcc_runtime/lazy_index.rs`; tests in `lazy_index_tests.rs` |
| Reclaim / worker | `mvcc_runtime/reclaim.rs`, `maintenance.rs`; prepare in `publication.rs` (search for `reclaim_prepare`) |
| Capability | `crates/phobos-catalog/src/lib.rs` (`CAPABILITY_LAZY_INDEX_PRUNING_V1`, `VERSION_CAPABILITIES`); enable at open in `crates/phobos-server/src/lib.rs` |
| Integrity | `crates/phobos-admin/src/mvcc_integrity.rs` (offline); `mvcc_runtime/online_ops.rs` (online) |
| Heap / FSM / deferred compaction | `crates/phobos-storage/src/lib.rs`, `versioned_heap.rs` |
| Index leaf-grouped deletion | `crates/phobos-index/src/lib.rs` (`delete_versions_sorted`) |
| Validation bundles | `tools/k1-validation`, `k2-validation`, `k3-validation`, `k4-validation` (standalone cargo projects; the harness sources are in `src/`) |
| Release notes | `CHANGELOG.md` (CRLF in older sections: append bytes, do not rewrite) |
