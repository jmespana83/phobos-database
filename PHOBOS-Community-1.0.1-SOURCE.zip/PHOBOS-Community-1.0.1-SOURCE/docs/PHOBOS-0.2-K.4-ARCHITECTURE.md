# PHOBOS 0.2-K.4 — Lazy Index Pruning V1: architecture and results

## Verdict

**OLTP targets missed. Correctness, boundedness and compatibility goals met.**

- Lazy non-unique pruning works, is capability-gated, bounded and tested.
- It halves the serialized reclaim cost per version.
- The worker ON/OFF gap moved only from −30/−32 % (K.3, same session) to **−26 % / −26 %** at OLTP8/16 on the 2-vCPU Linux box. The targets are ≤ 8 %.

## 1. Compatibility marker

- Catalog capability bitmask (catalog format version 3), bit `LAZY_INDEX_PRUNING_V1`.
- It is enabled by a **WAL-logged schema publication**:
  - in the DDL that creates the first non-unique index;
  - or at writable-primary open when a non-unique index already exists;
  - or before an explicit reclaim pass.
- The automatic worker never starts a schema transaction.
- Older binaries refuse the database with "unsupported catalog format". Unknown bits are refused with an actionable error.
- Details: `PHOBOS-0.2-K.4-COMPATIBILITY.md`.

**Measured on a K.4 database** (`evidence/final/compat-probe.log`):
- The 0.2-K.3 binary is refused with `InvalidCatalog: unsupported catalog format`.
- K.4 opens it, and `check` passes with 854 stale entries and 0 corrupt.

## 2. Lazy pruning design

`crates/phobos-execution/src/mvcc_runtime/lazy_index.rs`

- **Reclaim publication:**
  - RETIRE/FREE are slot-directory-only edits (K.3).
  - **UNIQUE** indexes: exact leaf-grouped deletion (eager, as before).
  - **Non-unique** indexes: no deletion (`plan.lazy`). The entries become *stale*.
- **Stale entry definition:** the RID names a RETIRED, FREE or vacant/trimmed slot, or a slot whose occupant's index key differs.
- **Reads:** every index read path already revalidates (0.2-K Part H): `get_version` / `slot_reclaimed`, key equality, MVCC visibility.
- **Slot reuse:** under the same key, `(key, RID)` set semantics turn the stale entry into the new occupant's live entry. Under a different key, the key check skips it.

**Sweeper:**
- Round-robin over the non-unique indexes, with an in-memory cursor `(key, RID)`.
- Each slice inspects up to `PHOBOS_LAZY_SWEEP_ENTRIES` (4096) entries on a statement view, outside the commit pipeline.
- Candidates are published as `ReclaimPlan::prune`. Inside serialized prepare, each candidate is **re-checked** against the rebased heap (a slot reused under the same key is kept) and removed with one rewrite per leaf run.
- **Trigger:** a cycle starts when lazily created stale entries reach `max(2048, entries_visited_last_cycle / 10)`; a cycle in progress always continues. There is no queue: the debt is a counter, the candidates are bounded per slice, and a restart begins a new cycle.

**Integrity:** online `CHECK` and `phobos-admin check` count live, stale and corrupt entries. Stale is legal only for non-unique indexes under the capability.

## 3. UNIQUE

**UNIQUE stayed eager.** An experimental lazy-UNIQUE variant was measured:

| OLTP8 / OLTP16, worker ON | ops/s |
|---|---|
| Lazy UNIQUE (+ `min_versions` 16, divisor 4) | 6,022 / 6,608 |
| Non-unique-only (same session) | about 5,950 / 6,220 |

It was not enough to reach target. It would also have required relaxing UNIQUE integrity, so **the code was removed**.

## 4. Results

### Reclaim micro, per reclaimed version (60K rows, UNIQUE id + secondary, 6K dead versions)

| Metric | K.2 | K.3 (rerun) | **K.4** |
|---|---|---|---|
| Pass, total incl. sweep inspection | 70.4 µs | 69.2 µs | **66.5 µs** |
| Serialized prepare | 44.9 µs | 41.6 µs | **21.1 µs (−53 % vs K.2)** |
| Publication / commit | 64.3 µs | 61.5 µs | **30.4 µs (−53 %)** |
| Eager exact index deletions | 2.0 | 2.0 | **1.0** (UNIQUE only; non-unique **0**) |
| Lazy stale entries created | — | — | 1.0 |
| Stale entries pruned in the same run | — | — | 0.34 (the rest by later cycles) |
| Heap pages modified | 0.476 | 0.476 | 0.415 |
| Index pages written | 2.0 | 0.78 | **0.31** |
| WAL | 531 B | 313 B | **214 B (−60 %)** |

**Targets:**
- Total reclaim −50 % vs K.2: **MISS** (−5 %). The total now includes the sweeper's off-pipeline inspection.
- Serialized prepare −60 %: **MISS** (−53 %).
- Non-unique eager deletes ≈ 0: **PASS**.

### OLTP, worker ON / OFF (Linux 2 vCPU, same session, `i1h bench`, 10 s per mix; `OLTP.csv`)

| ops/s | OLTP1 | OLTP8 | OLTP16 |
|---|---|---|---|
| K.4 OFF, median of 2 | 3,917 | 7,686 | 8,191 |
| K.4 ON, median of 2 | 3,147 (clean run 3,574) | 5,660 | 6,104 |
| **K.4 gap** | −19.7 % (clean run −8.8 %) | **−26.4 %** | **−25.5 %** |
| K.3 gap, same session | −10.6 % | −30.4 % | −31.7 % |
| Target | ≤ 5 %: **MISS** | ≤ 8 %: **MISS** | ≤ 8 %: **MISS** |

**Errors:** 0–3 per mix, only the known retryable write conflicts, worker on and off alike.

### Remaining cost (profile, worker ON vs OFF, per foreground commit)

| Item | Change |
|---|---|
| `ordered_publication` | +28–31 µs: publication of the reclaim heap pages and the sweep/UNIQUE leaves |
| Commit-order hold | +10–39 µs |
| Heap checksums per commit | 7.9 → 13 (FREE-slot reuse scatters new versions) |
| Worker CPU | ≈ 10 % of one core (planning decodes dead rows; sweep inspection decodes rows) |

The serialized reclaim prepare is now small: 15 µs per commit amortized (K.3: 25). **The gap is dominated by heap-page publication and write locality, not by index deletion any more.** See the handoff, milestone 2.

### Sweeper (OLTP16 cumulative, `SWEEPER.csv`)

| Metric | Value |
|---|---|
| Stale created | 43.3K |
| Pruned | 36.5K |
| Re-check kept | 0 |
| Inspected | 388K |
| Passes | 95 |
| Cycles | 2 |
| Inspection rate | ≈ 13K entries/s off-pipeline (≈ 1–2 % of a core at ~1.2 µs/entry) |
| Prune leaf rewrites | inside the reclaim publication; counted in `reclaim_index` (0.71 s over 30 s, profiling build) |

### Boundedness (`INDEX-BOUNDEDNESS.csv`)

- **Workload A** (2,000 rows, 100 generations: update every secondary key, delete and reinsert 10 %):
  - Heap pages: 61 → 71–75, bounded.
  - Index entries: oscillate between 6.4K and 10.5K, with no trend over 100 generations.
  - Stale entries: 0.7K–5.2K (ratio 8–49 %). The minimum debt of 2048 dominates on a 2K-row table.
  - Index pages grow 41 → 189 with a decreasing slope. This is the pre-existing no-merge drift; K.3 showed 38 → 108 at 25 generations. Stale entries add some leaf splits before they are swept.
  - Integrity: PASS (live 4,800, stale 3,255, corrupt 0).
- **Workload B** (10K rows, 20 s secondary-key UPDATE burst, then idle):
  - The stale ratio stays at 2.7–8.2 % throughout the burst (9 cycles).
  - After the burst it settles at 3.5 % (732 entries, below the trigger: bounded, not zero).
  - Integrity: PASS.

## 5. Correctness and recovery

**New tests:**

| Test | Covers |
|---|---|
| `k4_lazy_stale_entries_are_harmless_survive_restart_and_are_swept` | Stale entries pointing to RETIRED/FREE slots and to slots reused with the same and a different key; point and range reads equal the full-scan answer; restart with stale entries; online check reports stale; a forced sweep cycle brings stale to 0 with the exact live count. |
| `k4_unique_semantics_unaffected_by_lazy_secondary_entries` | Same-key INSERT conflict; no false conflict after delete+reinsert; UPDATE into an occupied UNIQUE key plus rollback; slot reuse under the same key; concurrent same-key INSERT (exactly one wins); restart. |
| `k4_capability_is_persistent_and_absent_until_enabled` | Catalog stays v2 until enabled; v3 after; persists across reopen. |
| `phobos-catalog` `k4_capability_round_trips_and_unknown_bits_are_refused` | Round trip; unknown bits refused. |

**Existing tests adjusted:**
- Tests pinning *eager* exact pruning now call `set_lazy_index_pruning(false)`. The eager path still exists (UNIQUE, and `PHOBOS_LAZY_INDEX=0`):
  - `c3_dead_index_entries_pruned_…`
  - `k_duplicate_heavy_index_pruning_is_exact`
  - `k_retired_slots_become_free_…`
  - `k_bulk_load_reuses_free_slots_…`
- The lifecycle `drain` helper forces one sweep cycle, so exact-count assertions hold.
- The c2 crash test enables the capability before arming the crash point.
- `f5` compares the structural check fields only.
- The test-only reclaim panic hook is now scoped to one data directory. It was a process-wide flag that a concurrent test could consume.

**Observed flake:** `compact_redo_tests::v3_crash_at_commit_pipeline_boundaries_is_atomic` failed once under full-suite load ("visibility state is behind WAL retirement"). It passed 2/2 in isolation and in the full workspace run (see Gates). Not investigated further.

## 6. Gates

See the final report and `evidence/gate/SUMMARY`.
