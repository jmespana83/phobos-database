# Phobos Write & Concurrency V3 — C7 report

C7 FROZEN: YES. C8 — NOT STARTED. C6 durable formats and coordinator ordering remain unchanged.

Final acceptance: **218 passed, 0 failed, 3 inherited soak tests ignored**. Formatting, strict workspace Clippy, docs and release build pass. The workspace gate was run once; after a legacy test race interrupted it, the corrected server tests and every remaining target (including both inherited integration tests and doc tests) were completed. Subsequent C7 bounds corrections received focused tests and refreshed formatting/Clippy/docs/build checks. No failing test was skipped.

Internal iterator/batch and authenticated TCP/TLS client ingestion are all-or-nothing. The CLI accepts bounded client-local typed TSV or stdin and commits only at import completion. Imports hold a table-write key in the existing wait-die domain; other sessions retain committed reads. Existing indexes use ordinary per-entry maintenance. See [API, bounds and reproduction](write_concurrency_v3_c7_bulk.md).

## Measured comparison

Host: Rust/Cargo 1.85.0, x86_64 MSVC, Windows build 26200, 16 logical processors. C6 durability settings were unchanged. Exact environment and binary hashes are in the evidence.

One instrumented final-source 100K bulk/ordinary pair and exactly one final-source 1M bulk measurement, run sequentially. Successful 100K results were retained after the user cost adjustment; 1M ordinary SQL was not run. Both paths use identical generated rows, a unique `id` index and a nonunique `(bucket,id)` index. Bulk commits once; ordinary SQL commits 256-row batches to respect its existing memory limit. These are different atomicity granularities. Timings include profiling overhead; they are not uninstrumented latency or statistical confidence claims. Verification/shutdown time is outside the import timer.

| Rows | Path | Elapsed s | Rows/s | WAL bytes | WAL forces | Peak working set MiB |
|---:|---|---:|---:|---:|---:|---:|
| 100,000 | c7-bulk | 56.550 | 1,768.360 | 20,046,677 | 1 | 37.71 |
| 100,000 | c7-ordinary | 117.996 | 847.487 | 334,994,492 | 391 | 30.69 |
| 1,000,000 | c7-bulk | 591.435 | 1,690.803 | 205,491,587 | 1 | 211.19 |

Bulk/ordinary throughput ratios: 100,000: 2.087×. No 1M ordinary-SQL benchmark was run, per the user cost adjustment.

Peak memory is sampled OS process high-water working set over setup/import/verification, not just the timed interval. Input/encoding batches remain bounded and private pages spill; ordinary engine metadata still grows with page count. WAL values are timed before/after counter deltas, not cumulative setup totals.

| Bulk rows | Encode s | Heap allocate/fill s | Index maintenance s | Unique validation s | Heap page updates | Installed pages (heap+indexes) | Private spill bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 100,000 | 0.073 | 0.825 | 30.589 | 23.205 | 1,226 | 2,429 | 778,063,416 |
| 1,000,000 | 0.708 | 8.608 | 323.773 | 239.189 | 12,252 | 24,899 | 8,807,050,824 |

Heap allocation/fill timing includes page acquisition, tuple checks, filling and free-space updates; it is not a pure allocator microbenchmark. Index timing includes tuple decode and existing index insertions. Scratch unique validation is separate. Spill bytes count I/O traffic, not peak disk allocation. Raw profiles also include all private page writes/allocations and WAL/install/visibility spans. No C8 optimization was performed.

## Acceptance and defects

- Success, halfway iterator/protocol errors, explicit rollback, disconnect, typing/NOT NULL, composite uniqueness, NULL uniqueness semantics, existing indexes and reader visibility pass through the dedicated runtime/client path.
- Oversized row/chunk rejection is verified after prior accepted chunks; text and binary allocations are checked before copying. Scratch accounting uses live file-handle metadata on Windows. Private-page spill is exercised by both large imports; the client sends one acknowledged chunk at a time.
- Injected WAL-force failure returns no success, fences the runtime and recovers atomically. Complete logged commits can recover despite a failed/unknown acknowledgment; this retains ordinary uncertain-COMMIT semantics.
- Sixteen C7 subprocess crash scenarios (eight boundaries, twice each) passed in focused and regression runs: staged input, private preparation, before/after WAL force, pre-visibility, index publication, status/frontier persistence and after acknowledgment. Each recovers twice with offline integrity. Forty-eight case executions were recorded across those runs; no long soak was added.
- Every primary measurement performs two reopen/count/index checks and three offline integrity checks. Release CLI file/stdin ingestion and late-error rollback also pass, including abrupt stop/reopen and offline integrity.
- Defects fixed before freeze: C7 binary-value size accounting; stale Windows directory-entry sizes in C7 scratch quota checks; a legacy test hook assumed only one condition-variable wakeup. The last fix changes test notification synchronization only, not C6 production code.
- An initial low-cardinality-index development fixture exposed expensive existing inverse-index integrity validation. Its post-import verification was interrupted; no validation algorithm was weakened. Both primary paths use the same composite index fixture. Intermediate measurements interrupted for bounds fixes are retained as historical evidence and are not final acceptance results.
- PostgreSQL baseline and frozen C6 packages are hash-verified unchanged. No PostgreSQL rerun, 10M run, long soak, durable-format migration or C8 work occurred.

## Evidence and reproduction

Final evidence directories: `c7-final-gate`, `c7-primary-03`, `c7-cli-acceptance`. Historical focused logs and interrupted development runs remain in the evidence ZIP. Source, evidence and Windows binaries ship with SHA-256 manifests. Run `tools/c7-validation.ps1`, build `cargo build --release -p phobos-bench --features profiling`, then `python tools/c7-measure.py --output <new-directory>`. Run `tools/c7-cli-check.py --source <measurement-db/source> --output <new-directory>` for release CLI acceptance.

## Exact files changed from frozen C6

- `Cargo.lock`
- `crates/phobos-bench/Cargo.toml`
- `crates/phobos-bench/src/c7_bulk.rs`
- `crates/phobos-bench/src/main.rs`
- `crates/phobos-cli/Cargo.toml`
- `crates/phobos-cli/src/ingest.rs`
- `crates/phobos-cli/src/main.rs`
- `crates/phobos-client/Cargo.toml`
- `crates/phobos-client/src/lib.rs`
- `crates/phobos-execution/Cargo.toml`
- `crates/phobos-execution/src/mvcc_runtime.rs`
- `crates/phobos-execution/src/mvcc_runtime/bulk.rs`
- `crates/phobos-execution/src/mvcc_runtime/domains.rs`
- `crates/phobos-execution/src/mvcc_runtime/housekeeping.rs`
- `crates/phobos-execution/src/mvcc_runtime/ownership.rs`
- `crates/phobos-execution/src/mvcc_runtime/publication.rs`
- `crates/phobos-execution/src/mvcc_runtime/sql_sessions.rs`
- `crates/phobos-execution/src/mvcc_runtime/tests.rs`
- `crates/phobos-execution/src/mvcc_runtime/writes.rs`
- `crates/phobos-protocol/src/lib.rs`
- `crates/phobos-server/src/lib.rs`
- `crates/phobos-server/src/tests/c7_bulk.rs`
- `crates/phobos-server/src/tests/mvcc.rs`
- `crates/phobos-storage/src/versioned_heap.rs`
- `crates/phobos-wal/Cargo.toml`
- `crates/phobos-wal/src/v2/log.rs`
- `docs/write_concurrency_v3_c7_bulk.md`
- `docs/write_concurrency_v3_c7_report.md`
- `tools/c7-cli-check.py`
- `tools/c7-measure.py`
- `tools/c7-validation.ps1`
