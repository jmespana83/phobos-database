# C6 acceptance report

Status: QUALIFIED C6 ACCEPTANCE PASSED. C7 and C8 have not started.

The frozen C5 source, results and 18 performance exceptions are preserved. No
on-disk capability, tuple format, WAL format, stable-ID mapping, durability setting
or PostgreSQL result changed. Correctness acceptance and the finite 100K/1M
campaign are complete. Performance qualification is explicit below: this is not
an all-budgets-pass or universal-speedup claim.

## Architecture and defects

The implementation and original C5 audit are in
[the C6 design](write_concurrency_v3_c6_design.md). The important changes are:

- Row and unique ownership use independent domains. Wait-die victims automatically
  release their complete private write set before abort persistence; timeouts and
  cancellations do the same. Previously a failed transaction could retain its
  earlier row/key ownership until explicit rollback and obstruct progress.
- Commit capacity is checked before creating an irrevocable permit. Cancellation
  races acceptance atomically; accepted commits complete or fence, even after EOF.
- The server removes sessions before destroying them outside the session-map guard.
  TCP/TLS EOF detection uses one bounded request reader and can wake an executing
  waiter without acquiring its connection mutex. TLS socket I/O does not hold the
  shared TLS protocol-state mutex. Buffer and ciphertext-order limits are explicit.
- Snapshot bookkeeping is separate from durable transaction-status I/O. Cached
  terminal visibility bypasses status I/O, but a shared latched failure flag still
  fences cached readers after persistence failure. A healthy in-progress status
  write is not incorrectly treated as a failure.
- Readers clone immutable registrations instead of acquiring the mutable database
  directory. Physical heap/index handles move into exclusive domains while private
  preparation, WAL staging and publication operate outside that directory mutex.
- Disjoint domains prepare in bounded parallel waves. Dependent same-file changes
  preserve staged predecessor images, allocation/index structure, and ordered
  publication. Stable write ownership outlives preparation, force, install and
  visibility. Logical resolution can overlap for disjoint rows on the same page.
- WAL locking now surrounds append/stamping and force, not private page I/O or
  schema chunk reads. C1 complete-batch receipts remain the only durability authority.
- MVCC index readers use per-index epoch validation and restart, replacing the
  database-wide reader publication lock. Changed-generation errors are retried;
  stable-generation corruption is returned. Fair fallback covers one bounded batch
  after eight restarts. Status evaluation and visitors run outside structural scope.
- SQL now checks the existing maximum encoded index-key size before ownership and
  irrevocable admission, including non-unique indexes. A reproducer showed INSERT
  previously accepted a key that physical commit preparation would reject. The
  same physical validation remains in the tree; no limit was relaxed.

The ordered commit driver is intentionally retained. Current parallelism is within
an admitted disjoint-file cohort; no preparation runs through a second commit driver
during an in-flight force/publication. Whole-page dependency and index allocation
ordering remain necessary. Conservative DDL and C4 checkpoint drains retain their
stronger exclusion. These are real limits, not claimed removed locks. Per-index
publication/fairness protection can span cold page I/O, but never a SQL visitor,
status lookup or network delivery. Immutable page images need no new mutable latch.

## Correctness evidence

Final complete gate: `work/write-v3/evidence/c6-acceptance-correctness-03`.
212 passed, zero failed, three unchanged historical long-soak ignores. Formatting,
strict workspace/all-target/all-feature Clippy, docs, release workspace and separate
profiling/diagnostics build passed. Engine source hashes were checked before/after.
There are 19 additional tests versus frozen C5's 193. Earlier passing increments
are `c6-coordination-02` (199) and `c6-acceptance-correctness-02` (210). The final
two tests exercise unique UPDATE owner commit/abort with independent-key progress,
and indexed UPDATE/INSERT splits during a paused range snapshot, point visibility,
historic-key reuse and two reopens with integrity. All final measured executables
are byte-identical to their measurement-start hashes; adding these tests changed
no existing engine file and did not require rerunning timing trials.

Deterministic coverage includes both begin orders of a two-row cycle, row/key
cancellation, SQL row/key timeouts, release before rollback, 2/4/8 same-page logical
resolution while the mutable database owner is paused, and 2/4/8 disjoint-file
preparation barriers. The dependent-file test records preparation, redo staging and
visibility order and checks point/range results after reopening. Index split racing
covers leaf/internal/root split publication during a paused traversal and verifies
exactly-once entries after restart. Existing C5 visibility, index, join/grouping,
streaming, unique wait/recheck, pin lifecycle and status/recovery tests remain active.

TCP and TLS cases cover row wait, composite unique wait, ownership acquired before
waiting, disconnect in a held explicit transaction and EOF after irreversible
admission while preparation is paused. Held unsubmitted writes abort; admitted
writes publish despite disconnect. Later SQL updates and offline integrity pass.

The focused runtime campaign is 32 cases: 24 inherited plus eight C6 cases at two
new durable boundaries (partial index-page publication and persisted transaction
status before visibility-frontier advancement). Cases reopen twice, verify SQL
state, and check offline integrity; relevant backup/restore checks remain active.
Three schema crash cases and inherited component/C1–C4 regressions also pass.
No new crash hook is required solely for volatile wave selection/owner extraction.

## Measurement protocol

`tools/write-v3-c6-fast.ps1` runs correctness/builds, measurements and summarization.
The completed staged campaign uses `c6-acceptance-correctness-02` followed by
`c6-fast-01/measurements`, then the final 212-test gate described above.
`write-v3-c6-measure.py` checks source/binary hashes and
uses fresh forced copies of frozen C5 MVCC fixtures. Three ordinary and three
separate profiling/diagnostics processes run at each of 100K and 1M. PostgreSQL,
C5 executables, 10M and long soaks are not run. Saved C5 legacy medians set exactly
the original budget thresholds. Same-row TPS counts successful commits only.

The workloads use the ordinary SQL Coordinator, matching C5; latency excludes TCP
serialization. Warm-up, fixture-copy/setup exclusion, group window, flush limits
and shutdown-drain configuration match C5. OS cache and current machine conditions
are uncontrolled; historical comparisons are not an alternating A/B experiment.
Per-trial percentiles are not pooled. Medians differing by under 5% are classified
unchanged unless the fixed budget boundary is crossed; all raw trials are retained.

Row/key diagnostics have exact counter deltas and fixed wait histograms. Other
coordination spans have fixed logarithmic histograms, total/count and cumulative
maximum. Quantiles are bucket upper bounds; maximum is not subtractable between
snapshots. Inclusive publication/commit durations are distinguished from lock
acquisition/condition-variable spans. Schema rejects conflicts immediately and does
not have a queued wait. Instrumented timings never replace ordinary benchmark TPS.

## Results and qualification

The complete per-workload table and all 18 dispositions are in
[C6 measurements](write_concurrency_v3_c6_measurements.md). Fixed counters,
bucket-quantile tables and status/visibility costs are in
[C6 lock measurements](write_concurrency_v3_c6_lock_measurements.md).

| Median committed throughput | C5 100K | C6 100K | C5 1M | C6 1M |
|---|---:|---:|---:|---:|
| Four disjoint writers tx/s | 179.89 | 196.23 | 178.08 | 186.34 |
| Eight disjoint writers tx/s | 166.95 | 199.22 | 88.22 | 199.31 |
| Same-row writers tx/s | 18.21 | 46.00 | 24.86 | 32.43 |
| Concurrent reader queries/s | 2071.11 | 2864.20 | 2073.03 | 2878.55 |
| Mixed readers AND writers, each per second | 74.76 | 96.22 | 121.59 | 114.35 |

All six normal mixed trials completed 128 reader queries while writer loops were
active. Same-row workloads attempted 128 operations per trial; median conflicts
were 77.34% at 100K and 82.81% at 1M. Successful commits, failed attempts and
their separate latency distributions remain in raw CSV/summary evidence. Rejected
attempts are never counted as writer throughput. Paused-writer readers progressed,
but throughput declined from 287.71 to 258.14 queries/s at 100K and 290.29 to
266.96 at 1M. 1M mixed throughput declined 6.0%; it remains within its legacy budget.

The 1M eight-writer median improves 2.26x and is now within its fixed budget.
However, C6 trial durations were 3.473, 1.164 and 1.284 seconds for 256 commits;
C5 was 2.902, 3.238 and 1.504 seconds. These ranges overlap substantially. This
is a measured median improvement and deterministic overlap proof, not proof that
the slow mode or variability has been eliminated. The same-table physical path
and commit/publication driver still serialize where dependencies require it.

Original C5 debt: **3 resolved; 3 improved but outside budget; 10 unchanged;
2 regressed**. The resolved cases are 100K autocommit insert, 100K concurrent
insert and 1M eight disjoint writers. Joins regress 15.3% at 100K and 5.6% at 1M;
they remain exceptions. **One new exception** is 1M sort/spill: median 36.0967 s
versus the unchanged 35.8397 s limit (0.72% over), and 35.7212 s C5 median
(1.05% slower). It is recorded as a breach even though the C5-relative change
is inside the 5% descriptive noise band. Overall, 16 of 32 fixed comparisons
pass and 16 require qualification. No threshold changed.

Read-regression review compared raw profile snapshots rather than attributing
the whole change to a mutex. At 1M, join page-read time rose 789.8 -> 835.7 ms
and visibility time 244.4 -> 258.0 ms per three-query workload. At 100K these
were 79.9 -> 84.5 ms and 25.0 -> 25.8 ms. Sort's profile remains dominated by
merge/flush work (1M merge 32.35 -> 33.03 s), not ownership waiting. These are
overlapping inclusive instrumented times, not additive explanations of ordinary
latency. A causal attribution to C6 synchronization alone is not proven by this
historical comparison. Fencing checks, tuple visibility, structural restart and
durability were retained; weakening them or redesigning sort/join to clear this
campaign's debt would violate the scope. The regressions and slow mode remain
explicit limitations for later measurement-driven work, not silently waived tests.

The measured profile windows show about 1.664 and 1.644 transactions per WAL
force at 100K and 1M. Commit-completion waits average 13.40/9.66 ms; ordered
publication averages 2.78/1.86 ms per commit. Short commit-order mutex acquisition
itself averages 67/60 ns: the queue/driver and installation work, not that mutex's
uncontended acquisition instruction, are the remaining coordination cost.

Both final offline checks passed: 100K has three tables, one index, 571 index
pages; 1M has three tables, one index, 5681 index pages. Repeated recovery,
runtime/schema crashes and admin backup/restore/integrity acceptance are green.

## Delivery and reproducibility

The source/evidence/binary delivery is `outputs/write-v3/c6`. It contains exact
source and changed-since-C5 manifests, archive checksums, final result metadata,
reports and measured release/profile binaries. Archive hashes live in the external
SHA256SUMS/result metadata to avoid a self-referential source archive. The evidence
contains raw timings, profile snapshots, histogram/counter deltas, trial commands,
source/binary hashes, full gate logs and unchanged baseline checksums. Large
disposable trial databases/build caches are excluded; frozen C5 fixture locations
and hashes are retained in the original workspace. Reproduction requires those
frozen fixtures/results and the documented Rust 1.85 MSVC toolchain/dependencies.

Run `tools/write-v3-c6-fast.ps1 -OutputDirectory <new-directory>
-FrozenC5Measurements <frozen-c5-measurements> -Python <python-executable>`.
It runs only finite 100K/1M work and prints an execution-complete marker; reviewing
unchanged budgets remains mandatory. No C7 bulk loader, C8 index batching, physical
VACUUM, PostgreSQL rerun, 10M or long soak was performed.

C6 freezes as a correctness-passed, explicitly performance-qualified checkpoint.
No correctness/recovery blocker remains in this campaign. Remaining limitations
are the ordered same-file driver, conservative DDL/checkpoint exclusion, bounded
per-index fair fallback, transport pipelining capacity, historical-comparison noise
and the enumerated performance debt. NEXT MILESTONE: C7 — NOT STARTED.

## Exact changed/new files versus frozen C5

- `crates/phobos-bench/src/c5_acceptance.rs`
- `crates/phobos-execution/src/mvcc_runtime/commit_admission.rs`
- `crates/phobos-execution/src/mvcc_runtime/domains.rs`
- `crates/phobos-execution/src/mvcc_runtime/ownership.rs`
- `crates/phobos-execution/src/mvcc_runtime/publication.rs`
- `crates/phobos-execution/src/mvcc_runtime/read_directory.rs`
- `crates/phobos-execution/src/mvcc_runtime/schema.rs`
- `crates/phobos-execution/src/mvcc_runtime/sql_sessions.rs`
- `crates/phobos-execution/src/mvcc_runtime/tests.rs`
- `crates/phobos-execution/src/mvcc_runtime/writes.rs`
- `crates/phobos-execution/src/mvcc_runtime.rs`
- `crates/phobos-index/Cargo.toml`
- `crates/phobos-index/src/committed_reader.rs`
- `crates/phobos-index/src/lib.rs`
- `crates/phobos-index/src/publication_epoch.rs`
- `crates/phobos-observability/src/lib.rs`
- `crates/phobos-server/src/lib.rs`
- `crates/phobos-server/src/request_transport.rs`
- `crates/phobos-server/src/tests/mvcc.rs`
- `crates/phobos-server/tests/c6_acceptance.rs`
- `crates/phobos-storage/src/lib.rs`
- `crates/phobos-storage/src/page_io.rs`
- `crates/phobos-storage/src/versioned_heap.rs`
- `crates/phobos-txn/src/mvcc/sessions.rs`
- `crates/phobos-txn/src/mvcc/status_file.rs`
- `crates/phobos-txn/src/mvcc.rs`
- `docs/write_concurrency_v3_c6_design.md`
- `docs/write_concurrency_v3_c6_lock_measurements.md`
- `docs/write_concurrency_v3_c6_measurements.md`
- `docs/write_concurrency_v3_c6_report.md`
- `tools/write-v3-c6-checks.ps1`
- `tools/write-v3-c6-fast.ps1`
- `tools/write-v3-c6-measure.py`
- `tools/write-v3-c6-summary.py`
