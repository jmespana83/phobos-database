# Session 001 — Phase 0 + minimal Phase 1

## Objective
Establish a professional Rust workspace, executable protocol handshake, design/operations documentation, and the smallest useful storage primitive without pretending SQL/ACID functionality exists.

## Starting state
The supplied directory contained only the master specification; there was no pre-existing Rust repository to preserve.

## Architectural decisions
See `architecture.md` and `adr/0001`–`0004`. Key choices are MVCC target, blocking/async separation, 8 KiB pages, ARIES-inspired future recovery, pull-first execution, no unsafe code, modest dependencies, Rust 1.85 MSRV, Linux-first platform support.

## Vertical slice status
- Server/client handshake: implemented.
- Page-oriented persistent primitive: implemented.
- Slotted heap page + corruption checksum: implemented.
- CREATE TABLE: not implemented.
- Durable INSERT at SQL/catalog level: not implemented.
- Restart SELECT: not implemented.

This intentionally stops before inventing fake SQL/catalog/transaction behavior.
