# Phase 6 — Relational execution and optimization

Phase 6 extends the validated Phase 0–5 engine with a first relational planning/execution layer.

Implemented in this candidate:

- Left-deep chains of `INNER JOIN` or `LEFT JOIN`, using equi-join predicates.
- In-memory hash join when the right/build side is within `query_memory_bytes`.
- Grace hash partitioning when the build side exceeds the byte budget.
- `GROUP BY` with `COUNT`, `SUM`, `AVG`, `MIN`, and `MAX`.
- Hash aggregation within the byte budget and partitioned spill above it.
- `HAVING` against projected group columns / aggregate aliases.
- Persistent `ANALYZE <table>` statistics with row count, approximate distinct count, NULL count, and textual min/max observations.
- Cost-aware index-vs-sequential scan choice using collected statistics.
- `EXPLAIN SELECT ...` and `EXPLAIN ANALYZE SELECT ...` with estimated access/join/sort choices and actual elapsed time/row count.
- External merge-sort runs for general `ORDER BY`; bounded Top-K for eligible LIMIT/OFFSET queries.
- Spill directories are deleted on success and cleaned at database startup after an interrupted process.

## Current execution model

The relational path remains row-oriented. Operators account approximate bytes rather than rows. Grace join, spilled grouping, and external sort use temporary files guarded for cleanup on all normal error/cancellation paths.

The protocol still returns a materialized textual result frame, so truly streaming network results are not yet claimed for arbitrary relational queries.

## Current SQL boundaries

The E4 surface extends the narrow relational subset with DISTINCT, IN lists and uncorrelated one-column IN subqueries, LIKE `%`/`_`, searched CASE, direct scalar built-ins, quoted identifiers, comments, and multiple left-deep joins.

- equality join conditions only;
- no table aliases yet;
- aggregate aliases require explicit `AS`;
- `HAVING` refers to projected group columns or aggregate aliases rather than repeating aggregate function syntax;
- no correlated/scalar subqueries, CTEs, window functions, set operations, join reordering, or merge join;
- `COUNT(DISTINCT ...)` is not implemented.

Unsupported syntax must fail rather than silently return a different result.

## Statistics and cost model

`ANALYZE table_name` persists checksummed `phobos.stats`. DML adjusts row/change counters and marks distinct statistics stale rather than deleting them; ANALYZE refreshes distinct counts, advances the generation, and resets staleness.

The initial cost model is deliberately simple and transparent. It estimates filter selectivity from distinct counts where possible, compares sequential-scan and index-scan costs, and uses table row estimates to choose join strategy. It is a foundation for later histogram/sample-based costing, not a PostgreSQL-equivalent optimizer.
