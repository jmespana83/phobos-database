# C3 — committed dirty pages and background writeback

C3 builds on the frozen C2 source archive with SHA256
`992390c3fcead7216fb3e3c6ee6c813274cf8721d25e1cb7f8133056ef6e5552`.
The checkpoint report records acceptance separately from this design.

## Durability and visibility

WAL v2 encoding, the page-LSN/checksum capability, C1 group selection/force/receipt
semantics, and C2 disjoint preparation and ordered publication are unchanged.
No migration, capability upgrade, or reinterpretation of existing data is needed.
Legacy page-format-1 databases retain direct installation. New-file DDL remains on
the conservative synchronous creation/rename/checkpoint path.

The database owns one `CommittedStore`, shared with its heap/index page handles
and C2 preparation domains. Existing paged files attach on their first private
transaction; copied-file synchronization still occurs before attachment. New DDL
files attach only after installation and rename, on a later transaction.

`PageIo::install_private` still requires its exact transaction/database durable
receipt and frozen file identity. Page-format-2 publication validates each image's
checksum/LSN and transfers it into the committed store. The receipt must cover
that image. Scratch images are visited one at a time; a large transaction is never
expanded into an unbounded in-memory commit vector. Scratch handles close before
the existing transaction-root cleanup.

C1/C2 retain logical execution ownership until all heap/index images and metadata
are coherent. Readers therefore cannot see partial publication or private pages.
The worker can physically write a subset of a durable transaction before its
publication completes; complete durable WAL is already available to reconstruct
the entire transaction if installation fails. COMMIT acknowledgment remains after
successful WAL force and complete logical publication. A failed publication fences
the owner; a background I/O failure fences the shared store and all attached handles.

Reads consult active private images, newest pending predecessor images, committed
frames, then disk. Virtual file length and rollback's original-page reads also
consult committed state. Heap cache invalidation after WAL stamping is preserved.
Thus an acknowledged but unflushed heap/index update remains visible to subsequent
transactions without exposing aborted pages.

## Bounded writeback and pin ownership

A registration uses a monotonic in-memory file generation plus the immutable WAL
FileId. Duplicate live FileIds are rejected. File paths must match the canonical
database directory and FileId name. Reopened files never reuse an old registration.
Each registration opens an independent file cursor; it does not clone PageIo's
cursor. Frames are keyed by registration generation/page ID and contain immutable
image ownership (`Arc`), page LSN, earliest still-unwritten record LSN, and a dirty
generation counter. A file also retains the earliest written-but-unforced LSN.

One database worker writes bounded batches. The frame-directory mutex is released
before physical I/O. A per-file I/O guard serializes writes and file-handle closure;
this is deliberately coarser than a page latch but independent of WAL/execution
guards. The worker pins an immutable image under the directory mutex and verifies
`page_lsn <= durable_wal_lsn` again immediately before writing. Publication may
replace its frame while I/O proceeds. Completion removes the dirty frame only when
its generation matches the pinned generation. Old physical writes cannot follow
newer physical writes to the same page. Resident reads can use a newer frame while
an older image is pinned. Disk misses acquire the file guard and recheck frames.

At the high-water limit, publication flushes an eligible committed frame before
admitting another distinct frame. This is explicit synchronous backpressure, not
an unbounded queue. A replacement does not increase frame-directory occupancy.
The production engine has one publisher and one background worker, hence at most
two additional pinned old images beyond the configured dirty-frame limit during
redirty races. With 8192-byte pages, the default payload limit is 64 MiB plus at
most 16 KiB of pinned old payloads, frame/map bookkeeping and existing bounded
private scratch caches. This is not a bound on total database/process memory.
The worker batch-page limit also bounds batch bytes (`pages * 8192`). Existing
64-commit/16-MiB WAL checkpoint triggers and C1/C2 pending bounds remain in force.

Write failure retains the selected dirty frame and records a shared failure. Force
failure retains the file's unforced dependency and fences the store. Shutdown
returns the failure. A worker panic is caught and recorded as a recovery-required
failure. No retry/sleep loop substitutes for correct ownership or WAL ordering.

## Checkpoint, shutdown and Windows handles

CHECKPOINT retains the existing exclusive drain-all barrier. It flushes each file's
remaining frames, waits for pinned writes, forces affected files, synchronizes the
directory where supported, then calls the unchanged WAL checkpoint/retirement API.
No concurrent partial checkpoint or new redo-retention boundary is introduced.
Those changes belong to C4. Calling the storage force primitive requires the
execution owner's publication exclusion; it does not independently retire WAL.

`Database::shutdown` is explicit and fallible; server shutdown uses it after C2
admission/owner drain. Default drain mode checkpoints, stops and joins the worker.
Retain-WAL mode stops/joins without retiring WAL and requires recovery on next open;
it is a recoverable shutdown, not a clean checkpoint claim. Drop never claims
successful clean shutdown or hides a force error behind such a claim.

When a page owner is dropped (including a committed DROP INDEX), registration
teardown waits for its active I/O, removes its frames, and closes the actual OS
handle inside the registration. A worker's earlier selected Arc cannot keep that
handle open across Windows rename/removal. Discarding such frames is safe only
because WAL is retained or the deletion itself is WAL-protected. Database field
ordering releases heaps, indexes and transaction-held dropped indexes before the
last store owner stops/joins the worker, and releases WAL afterward. No detached
worker survives database teardown. Offline admin recovery/backup retains its
existing exclusive directory boundary.

## Configuration and observability

| Environment setting | Default | Meaning |
| --- | ---: | --- |
| `PHOBOS_DIRTY_HIGH_WATER_PAGES` | 8192 | Maximum resident dirty frame entries; nonzero |
| `PHOBOS_FLUSH_BATCH_PAGES` | 128 | Maximum writes selected per worker batch; nonzero |
| `PHOBOS_FLUSH_WAKE_MS` | 10 | Worker wake interval in milliseconds; nonzero |
| `PHOBOS_FLUSH_SHUTDOWN_DRAIN` | 1 | 1 drains/checkpoints on explicit shutdown; 0 retains WAL |

`FlushConfig` and `Database::open_v2_with_flush_config` expose equivalent embedded
configuration. A high-water wake or explicit bounded flush request can wake the
worker earlier. Invalid values fail open. Defaults are development settings, not
claims of universally optimal tuning. The C3 Fast gate fixes all four explicitly.

`Database::flush_stats` and `Coordinator::flush_stats` expose current and peak dirty
pages, pages/bytes flushed, background batch time, eviction pages, durable WAL LSN
and maximum published page LSN. The store's durable frontier is the highest durable
commit receipt it has observed; it can conservatively lag a later checkpoint/anchor
force or a commit without dirty pages. It never represents an unforced WAL append.
Benchmark `.flush.csv` files capture these outside
the timed interval. They are cumulative per database; before/after subtraction
distinguishes measured writes from warmup. Profiling records background, eviction
and checkpoint page counts separately and records background/eviction wait time.
The synchronous-publication span excludes WAL force and checkpoint; disjoint
groups retain C2's existing publication span. Normal release timings and instrumented
spans are collected with separate binaries. Background time counts completed batch
wall time; a concurrent batch can straddle a snapshot boundary. End-of-run shutdown
drain is outside these snapshots, and remaining dirty entries are reported rather
than counted as already persisted. C1 force counters remain authoritative.

## Acceptance coverage

Deterministic tests cover acknowledged buffered heap/index reads, duplicate-key
enforcement and rollback, two-page memory pressure, pinned stale completion,
WAL-frontier recheck, write-error retention/fencing, Windows selected-handle closure,
drain/retain shutdown and repeated recovery. Four process cases crash after ACK
before writeback, after a background physical write, after an eviction physical
write, and during checkpoint drain after a physical write. Each records an ACK
oracle and a reached-boundary marker and validates heap/index state on two reopens.
The eviction case pauses only the background worker before any file guard.

The final Fast gate keeps all 40 inherited C1/C2 campaign cycles, adds these four
C3 cases, and runs six suite recovery cases: 50 targeted cycles. Other pre-existing
subprocess regression tests remain enabled. Development reruns and harness defects
are recorded separately; the count is not a claim that the entire engineering
session launched only 50 children. PostgreSQL, 10M and long soaks are excluded.
