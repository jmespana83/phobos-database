# Authorization and mutual TLS

The server enforces three coarse roles at its protocol boundary. `reader` permits SELECT, EXPLAIN, and the metrics relation. `writer` adds INSERT, UPDATE, DELETE, and bulk input. `admin` adds DDL and other server administration. The local `phobos-admin` executable remains an operating-system/data-directory administration boundary; it must be restricted to database administrators. Table-level ACL catalogs and SQL GRANT/REVOKE are not implemented.

Password authentication remains compatible. Optional mutual TLS uses the existing rustls listener. Set `client_ca_path` to a PEM CA, and map each lowercase 16-hex certificate fingerprint to an existing PHOBOS username in `mtls_identities`. The mapping resolves that user's existing role; it does not create users or issue certificates. With `mtls_required: true`, clients without a trusted certificate are rejected during TLS negotiation. With a client CA configured and `mtls_required: false`, either a mapped client certificate or the existing password exchange may authenticate. Without a client CA, behavior is password-only.

The fingerprint is the deterministic 64-bit FNV-1a digest of the DER certificate, formatted as 16 lowercase hexadecimal characters. Certificate renewal changes it and requires an explicit mapping update. PHOBOS does not manage certificates, revocation, rotation, OCSP, or a PKI.
