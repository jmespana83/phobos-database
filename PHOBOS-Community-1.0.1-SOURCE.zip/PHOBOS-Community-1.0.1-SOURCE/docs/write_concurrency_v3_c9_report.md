# Phobos C9 — true bulk index build / merge

Development branch `c9-bulk-index` on top of the frozen C8 source. The frozen
C8 source is unchanged.

**227 passed, 0 failed, 3 existing soaks ignored** in one full workspace test
run after the focused C9 tests passed (`benchmarks/results/c9-bulk-index/workspace-test.log`).
Formatting is clean; Clippy with the `profiling` feature is clean across the
workspace. Toolchain note: the pinned 1.85.0 toolchain could not be downloaded in
the build environment, so the gate ran on stable 1.95.0; without the `profiling`
feature that newer Clippy flags two pre-existing `drop(span)` calls in
`phobos-index/src/publication_epoch.rs` (`drop_non_drop`), which C9 did not touch.

## What changed

The dedicated import no longer performs one B+ tree insertion and one committed
lookup per row. See [the algorithm guide](write_concurrency_v3_c9_bulk_index.md).

| Stage | Frozen C8 | C9 |
|---|---|---|
| Staging | per row: committed `range_visit` + heap visibility, per chunk: scratch unique-tree `insert_batch` | per row: key derivation into a bounded run buffer; runs sorted and spilled |
| COMMIT before admission | — | k-way merge of runs; linear duplicate scan; ordered probe of the committed index in 1,024-key windows |
| COMMIT after admission | per 1,024 rows: `insert_versions_batch` (ordinary `insert_entry` under a 64-node cache) | per index: stream sorted keys ⋈ existing leaf chain → packed leaves → bottom-up upper levels |
| Publication | unchanged | unchanged (private overlay → page-image WAL → force → install under the publication epoch) |

Behaviour change: a unique violation is reported by COMMIT (which then requires
ROLLBACK, as any failed bulk transaction does) instead of by the chunk that
carried the offending row. Atomicity is unchanged; two existing tests were updated
for the new detection point.

Format note: a bulk merge that needs fewer pages than the committed tree marks the
surplus old pages with a `FREE` node kind (magic, identity and checksum intact).
`validate` accounts for them (`IndexValidation::free_pages`); `decode_node`
rejects them; ordinary allocation does not reuse them.

## Measurements

Same instrumented `--features profiling` release build and `c8-bulk` workload as
C8 (unique `id`, non-unique `(bucket,id)`, timing includes COMMIT; reopen and
offline integrity outside the timer). Single samples. Hardware for the new runs:
2 vCPU Intel Xeon 2.80 GHz Linux sandbox; the saved C8 numbers were produced on
the C8 machine, so the frozen C8 binary was also run once at 100K on this sandbox
(`benchmarks/results/c9-bulk-index/c8-100k.csv`).

| Rows | Frozen C8 saved | Frozen C8, same hardware | C9 | Speedup (saved / same hardware) |
|---:|---:|---:|---:|---:|
| 100,000 | 31.552 s / 3,169 rows/s | 26.973 s / 3,707 rows/s | 2.111 s / 47,375 rows/s | 14.9× / 12.8× |
| 1,000,000 | 308.738 s / 3,239 rows/s | not run (no repeated benchmarking) | 22.009 s / 45,437 rows/s | 14.0× |

PostgreSQL reference (saved): 8.858 s at 1M. New PHOBOS / PostgreSQL ratio: 2.48×
(was 34.85×).

1M phase costs (inclusive wall, profiling build):

| Phase | C9 seconds |
|---|---:|
| key generation (`bulk.key_generate`, staging) | 1.496 |
| sort: run sorts + k-way merge (`bulk.sort`, minus nested probe) | ≈1.80 |
| in-batch unique check (`bulk.unique_check_ns`) | 0.056 |
| existing-index ordered probe + visibility (`bulk.existing_merge`) | 0.105 |
| leaf build/merge (`bulk.leaf_build`) | 1.659 |
| upper-level build (`bulk.upper_build`) | 0.0003 |
| WAL records + force (`wal.write_record` + `wal.fsync`) | 1.568 |
| installation/visibility publication (`mvcc.ordered_publication`) | 1.237 |
| heap allocate/fill (`bulk.heap_allocate_fill`, of which `heap.checksum` 10.358) | 11.338 |
| total import | 22.009 |

For comparison the frozen C8 100K run on the same hardware spent 14.7 s in
`bulk.index_maintenance` and 10.4 s in `bulk.unique_validate` (827,709 node reads,
306,371 node writes) out of 26.97 s. C9 spends 0.5 s on all index work at 100K.
The remaining bottleneck is outside the index path: the heap page checksum is
recomputed for every inserted tuple (1,022,728 checksums, 10.4 s at 1M).

## Correctness

Focused tests (`cargo test -p phobos-index --lib c9_`, `cargo test -p phobos-server --lib c9_bulk`):

- empty index bulk build; merge into a populated index (interleaved, below and
  above existing keys); non-unique duplicates across the old chain and the batch;
  unique, composite unique and NULL semantics; duplicates inside the batch;
  conflicts with committed keys; rollback before publication; non-ascending
  input rejection; free-page accounting and reopen.
- text-key tables whose indexes need hundreds of leaves and height ≥ 3, with
  reopen and offline integrity.
- failure during index construction (corrupted sorted scratch after admission):
  no success, runtime fenced, recovery leaves table and indexes intact.
- process crash after the private build before any WAL (import absent after
  recovery) and during index page installation after the durable force (import
  complete after recovery); two reopens and offline integrity each.
- existing C7/C8 chunk, disconnect, malformed-input, WAL-fault, sixteen-point
  crash and C8 publication-crash tests pass unchanged apart from the detection
  point noted above.

## Files changed from frozen C8

- `crates/phobos-index/src/bulk.rs` (new): ordered probe cursor, bulk builder/merger, free pages, tests
- `crates/phobos-index/src/lib.rs`: module wiring, `FREE` kind, `validate` free-page accounting
- `crates/phobos-index/src/committed_reader.rs`: epoch-consistent `probe_sorted`
- `crates/phobos-execution/src/mvcc_runtime/bulk.rs`: key runs, external sort, COMMIT finalize, bulk index preparation
- `crates/phobos-execution/src/mvcc_runtime/sql_sessions.rs`: finalize before commit admission
- `crates/phobos-execution/src/mvcc_runtime/tests.rs`, `crates/phobos-server/src/tests/c7_bulk.rs`: detection point of unique violations
- `crates/phobos-server/src/tests/c9_bulk.rs` (new), `crates/phobos-server/src/tests/mvcc.rs`, `crates/phobos-server/Cargo.toml` (dev-dependencies)
- `docs/write_concurrency_v3_c9_bulk_index.md`, `docs/write_concurrency_v3_c9_report.md`
- `benchmarks/results/c9-bulk-index/` (evidence)

## Known limitations

- A merge rewrites the whole leaf chain of an index: cost and WAL volume are
  proportional to the existing index plus the batch, so a tiny import into a very
  large index pays for the existing leaves. The ordinary SQL path remains the
  right tool for small writes.
- Retired (`FREE`) pages are not reused by later allocations.
- Unique violations surface at COMMIT rather than at the offending chunk.
- The ordinal→RID map holds one entry per heap page filled by the import; run
  buffers are bounded per index, but the number of run files grows with the import.
- Key derivation encodes each key more than once (validation and size
  estimate); a small, unmeasured saving remains there.
