# Write & Concurrency V3 — C4 report

C4 implements incremental target-based checkpoint/writeback coordination. C5 has not started. Final freeze status is recorded by the delivery PASS marker and checksum manifests.

## Outcome and performance review

The campaign measured C3 before behavior changes, then ran fresh C3/C4 controls. Scratch retirement dominated a substantial part of C3 publication: 2.530 ms/transaction at shared 100K/8 and 1.409 ms at disjoint 1M/8. Dirty-store/file-lock waits were far smaller. C4 removes ordinary full data drains and prepares retained WAL replacements outside ownership; it preserves synchronous scratch retirement. Checkpoint changes cannot be credited with eliminating the remaining cleanup bottleneck.

- Priority case shared/100,000/8: C3 166.06 → C4 203.40 tx/s (+22.5%).
- Priority case domains/1,000,000/8: C3 272.70 → C4 216.14 tx/s (-20.7%).

### Alternating-order confirmation

The normal and profiling timings disagreed in one disjoint control, so a separate confirmation used unchanged normal binaries, five paired rounds per case and alternating C4/C3 versus C3/C4 execution order. These are additional results, not replacements for the original gate. Every round, latency distribution and paired ratio is retained in confirmation.json.

| Case | C3 median tx/s | C4 median tx/s | Change of medians | Median paired change |
| --- | ---: | ---: | ---: | ---: |
| shared/100,000/8 | 159.33 | 151.17 | -5.1% | +2.9% |
| domains/100,000/8 | 178.69 | 163.96 | -8.2% | +7.6% |
| domains/1,000,000/8 | 172.99 | 191.15 | +10.5% | +11.1% |

**Assessment: a validated checkpoint-coordination milestone, not a general writer-speedup claim.** The original priority gains/regressions do not reproduce uniformly. In the alternating confirmation, 1M disjoint median throughput improved 10.5%, while 100K shared and disjoint medians regressed 5.1% and 8.2%. Paired ratios and ratios of medians answer different questions; both are retained. The campaign does not establish that the C3 writer regressions are eliminated.

Foreground checkpoint work was materially reduced: shared 100K/8 decreased from 0.2759 to 0.0953 ms/transaction, and disjoint 1M/8 from 0.4485 to 0.1496 ms/transaction (about two-thirds). These sum the old drain/rotation spans versus the new foreground finalization span, excluding overlapping background work. Ordinary foreground page-drain time was zero in the C4 measured intervals.

The remaining costs are larger than that saving. Scratch retirement remains around 1.6–2.1 ms/transaction in the priority C4 profiles. One 1M disjoint profile also showed substantially higher WAL/data-force latency and preparation time; file-lock waits alone did not explain the difference. This is evidence of variable I/O costs, not proof of a single OS cause. Synchronous publication/cleanup and WAL/data-I/O contention remain explicitly open for later investigation. No safety setting, group-commit policy or admission timeout was relaxed; C5/MVCC has not started.


All paired results, including regressions, appear below. Three samples are development measurements, not a statistical guarantee or a PostgreSQL parity claim. The unchanged saved PostgreSQL baseline was not rerun.

## Correctness and implementation

A checkpoint captures the published durable COMMIT target. The existing worker drains current page images at or below it in bounded batches and forces at most one file per batch. Redirtied generations remain dirty; both dirty recovery LSNs and written-but-unforced file dependencies restrict the safe retirement frontier. C1 receipt/group-force semantics and C2 preparation/publication ordering remain intact.

One WAL worker constructs and forces an anchor plus complete retained transaction chains from a captured byte prefix while ordinary transactions append to the authoritative WAL. The owner polls rather than waits; tail catch-up above 1 MiB returns to the worker. Final bounded catch-up, force and atomic replacement still require ownership. Full checkpoints, DDL, legacy-page databases and clean shutdown keep their complete durability barriers. Failures fence, and Windows source handles are joined/closed before replacement or recovery.

The existing V2 anchor encoding, page formats, contiguous LSNs and transaction identities are preserved; no database migration occurs. See write_concurrency_v3_c4_design.md for the retirement proof, cancellation lifecycle, failure handling and practical limits.

## Validation

- Formatting and formatting check: PASS.
- Strict all-target/all-feature workspace Clippy with -D warnings: PASS; no new allow suppression.
- Workspace: 155 passed, 0 failed, 3 pre-existing ignored long soaks.
- Docs and normal/profiling release builds: PASS.
- C4 targeted process crashes: 24 (four boundaries × six repetitions), with persisted ACK/hook markers, payload and unique-index validation, and two recoveries each.
- All inherited crash regressions remain enabled: 40 C1/C2 campaign cycles, four C3 cycles, and six Fast-suite recovery cases, plus other inherited subprocess tests. These are additional to the 24 C4 development cycles.
- Deterministic target/redirty/preparation, retained chain/tail recovery, successful retirement, and checkpoint failure fencing tests pass. The existing 64-commit retention test waits for asynchronous completion while preserving its retirement/page-LSN/rollback/recovery assertions.
- 100K/1M embedded suites: 49 records each. Fresh C3 and C4 matched TCP: 43 successful records per scale/engine, plus offline integrity.
- 24 normal/profiling controls: shared/disjoint × 100K/1M × 1/4/8 writers × C3/C4; three samples of 32 transactions/client, acknowledged payloads verified on two reopens.
- No PostgreSQL connection, 10M measurement or long soak. Process exits do not simulate every hardware power-loss mode.

## Fresh matched TCP latency

Median total milliseconds across three samples; these are complete SQL workloads, not isolated COMMIT calls.

| Rows | Workload | C3 ms | C4 ms | Change |
| --- | --- | ---: | ---: | ---: |
| 100,000 | 3 autocommits | 16.7314 | 12.0639 | -27.9% |
| 100,000 | 3 inserts / explicit transaction | 6.3216 | 5.3317 | -15.7% |
| 100,000 | 4 clients / 12 autocommits | 49.2117 | 47.6263 | -3.2% |
| 1,000,000 | 3 autocommits | 17.0996 | 12.2542 | -28.3% |
| 1,000,000 | 3 inserts / explicit transaction | 6.7946 | 5.3995 | -20.5% |
| 1,000,000 | 4 clients / 12 autocommits | 50.6363 | 50.3014 | -0.7% |

## Normal writer controls

| Layout / rows / clients | C3 tx/s | C4 tx/s | Change | C3 p50/p95/p99 ms | C4 p50/p95/p99 ms |
| --- | ---: | ---: | ---: | --- | --- |
| shared/100,000/1 | 130.48 | 135.49 | +3.8% | 5.957/7.472/59.789 | 5.957/7.799/54.129 |
| shared/100,000/4 | 163.19 | 200.19 | +22.7% | 22.226/30.543/71.918 | 20.738/30.556/74.065 |
| shared/100,000/8 | 166.06 | 203.40 | +22.5% | 45.900/119.488/215.638 | 42.134/71.830/111.798 |
| shared/1,000,000/1 | 165.42 | 172.91 | +4.5% | 6.088/10.008/13.806 | 6.020/10.550/18.701 |
| shared/1,000,000/4 | 146.04 | 145.17 | -0.6% | 25.544/67.326/78.460 | 25.050/38.511/69.284 |
| shared/1,000,000/8 | 149.07 | 201.61 | +35.2% | 46.019/84.235/110.611 | 39.610/65.442/77.065 |
| domains/100,000/1 | 191.31 | 145.41 | -24.0% | 5.074/6.157/10.833 | 5.953/9.135/22.487 |
| domains/100,000/4 | 128.16 | 109.90 | -14.3% | 22.776/65.707/128.882 | 27.340/63.768/97.703 |
| domains/100,000/8 | 386.37 | 278.12 | -28.0% | 19.193/38.669/92.214 | 25.796/64.275/105.496 |
| domains/1,000,000/1 | 169.66 | 157.22 | -7.3% | 5.907/8.498/10.175 | 5.689/8.198/9.212 |
| domains/1,000,000/4 | 157.17 | 180.29 | +14.7% | 21.970/71.973/115.644 | 19.915/80.741/128.619 |
| domains/1,000,000/8 | 272.70 | 216.14 | -20.7% | 24.606/85.382/147.474 | 31.130/78.802/125.228 |

## Instrumented eight-writer attribution

Milliseconds per committed transaction, inclusive wall spans. Parallel worker spans overlap and must not be summed into a critical path. Instrumented timing is separate from normal throughput.

| Layout / rows / engine | Publication | Scratch retirement | Foreground drain | Foreground WAL finish | WAL preparation | Background flush | Store wait | Heap / index wait |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| shared/100,000/C3 | 2.6687 | 2.0258 | 0.0657 | 0.2102 | 0.0000 | 0.0192 | 0.00264 | 0.00003/0.00009 |
| shared/100,000/C4 | 2.7645 | 2.1405 | 0.0000 | 0.0953 | 0.1751 | 0.1239 | 0.00266 | 0.00490/0.00021 |
| shared/1,000,000/C3 | 1.9936 | 1.5504 | 0.0490 | 0.1348 | 0.0000 | 0.0163 | 0.00260 | 0.00002/0.00011 |
| shared/1,000,000/C4 | 2.0856 | 1.6293 | 0.0000 | 0.1228 | 0.1729 | 0.0869 | 0.00257 | 0.00291/0.00713 |
| domains/100,000/C3 | 2.0150 | 1.5297 | 0.6813 | 0.1851 | 0.0000 | 0.0385 | 0.00507 | 0.00011/0.00011 |
| domains/100,000/C4 | 1.7636 | 1.2912 | 0.0000 | 0.0234 | 0.0832 | 0.1065 | 0.00386 | 0.00117/0.00155 |
| domains/1,000,000/C3 | 2.0551 | 1.6389 | 0.3214 | 0.1271 | 0.0000 | 0.0514 | 0.00537 | 0.00767/0.00812 |
| domains/1,000,000/C4 | 2.3037 | 1.6152 | 0.0000 | 0.1496 | 0.3061 | 1.2317 | 0.00453 | 0.00006/0.03096 |

## Writeback and WAL counters

Normal snapshots exclude setup and shutdown. WAL bytes are the retained physical length at each timed sample end. Background batches can straddle snapshots. Profile forces and redirties are separate instrumented measurements.

| Layout / rows / clients / engine | Peak dirty | Pages / bytes flushed | Retained WAL bytes (3 samples) | Commit / all WAL forces | Tx per commit force | Checkpoint completions / redirties |
| --- | ---: | ---: | --- | ---: | ---: | ---: |
| domains/100,000/1/C3 | 5 | 73 / 598,016 | 572421, 572421, 572421 | 96 / 96 | 1.00 | 0 / 0 |
| domains/100,000/1/C4 | 5 | 89 / 729,088 | 572421, 572421, 572421 | 96 / 96 | 1.00 | 0 / 0 |
| domains/100,000/4/C3 | 8 | 761 / 6,234,112 | 49842, 66436, 66436 | 192 / 204 | 2.00 | 0 / 0 |
| domains/100,000/4/C4 | 8 | 621 / 5,087,232 | 1128452, 1128452, 1128452 | 192 / 201 | 2.00 | 3 / 151 |
| domains/100,000/8/C3 | 16 | 1521 / 12,460,032 | 66436, 99624, 66436 | 192 / 216 | 4.00 | 0 / 0 |
| domains/100,000/8/C4 | 16 | 855 / 7,004,160 | 1261204, 3318860, 3318860 | 191 / 200 | 4.02 | 3 / 696 |
| domains/1,000,000/1/C3 | 2 | 76 / 622,592 | 547662, 547662, 547662 | 96 / 96 | 1.00 | 0 / 0 |
| domains/1,000,000/1/C4 | 2 | 71 / 581,632 | 547662, 547662, 547662 | 96 / 96 | 1.00 | 0 / 0 |
| domains/1,000,000/4/C3 | 8 | 747 / 6,119,424 | 66436, 66436, 66436 | 192 / 204 | 2.00 | 0 / 0 |
| domains/1,000,000/4/C4 | 8 | 572 / 4,685,824 | 1128452, 1128452, 1128452 | 192 / 201 | 2.00 | 3 / 102 |
| domains/1,000,000/8/C3 | 16 | 1530 / 12,533,760 | 16654, 132812, 132812 | 192 / 216 | 4.00 | 0 / 0 |
| domains/1,000,000/8/C4 | 16 | 828 / 6,782,976 | 1178234, 3318860, 3318860 | 192 / 207 | 4.00 | 5 / 591 |
| shared/100,000/1/C3 | 5 | 84 / 688,128 | 572421, 572421, 572421 | 96 / 96 | 1.00 | 0 / 0 |
| shared/100,000/1/C4 | 5 | 87 / 712,704 | 572421, 572421, 572421 | 96 / 96 | 1.00 | 0 / 0 |
| shared/100,000/4/C3 | 5 | 281 / 2,301,952 | 60, 60, 60 | 192 / 204 | 2.00 | 0 / 0 |
| shared/100,000/4/C4 | 5 | 248 / 2,031,616 | 1062076, 1062076, 1062076 | 192 / 201 | 2.00 | 3 / 62 |
| shared/100,000/8/C3 | 5 | 535 / 4,382,720 | 1012294, 1028888, 1012294 | 192 / 214 | 4.00 | 0 / 0 |
| shared/100,000/8/C4 | 5 | 439 / 3,596,288 | 796572, 597444, 531068 | 190 / 217 | 4.04 | 9 / 82 |
| shared/1,000,000/1/C3 | 2 | 79 / 647,168 | 547662, 547662, 547662 | 96 / 96 | 1.00 | 0 / 0 |
| shared/1,000,000/1/C4 | 2 | 82 / 671,744 | 547662, 547662, 547662 | 96 / 96 | 1.00 | 0 / 0 |
| shared/1,000,000/4/C3 | 5 | 341 / 2,793,472 | 60, 60, 60 | 191 / 203 | 2.01 | 0 / 0 |
| shared/1,000,000/4/C4 | 5 | 298 / 2,441,216 | 1062076, 1062076, 1062076 | 192 / 201 | 2.00 | 3 / 48 |
| shared/1,000,000/8/C3 | 5 | 515 / 4,218,880 | 60, 60, 1053647 | 192 / 216 | 4.00 | 0 / 0 |
| shared/1,000,000/8/C4 | 5 | 439 / 3,596,288 | 671985, 638797, 539233 | 192 / 219 | 4.00 | 9 / 137 |

## Limitations and reproduction

The 16 MiB threshold triggers checkpoint work; it is not a hard WAL-size bound. Hot redirty dependencies may retain older WAL. An idle database can keep a prepared replacement until another publication poll; explicit CHECKPOINT/shutdown completes a full barrier. Final file synchronization can still stall ownership. Synchronous scratch retirement and logical publication remain limitations for later work. No safety invariant was relaxed to improve a number.

C3 normal controls use the hash-verified frozen source with only the benchmark’s untimed WAL-size snapshot added. Profiling controls use the separately frozen pre-change instrumentation archive. Exact control-source bytes, normal/profiling feature sets, gate source hashes and raw result counts are audited before freeze. Delivery changed-files.json identifies every changed/new source file; no inherited file or failing test is removed.

```powershell
.\tools\write-v3-validation.ps1 -Checkpoint C4 `
  -OutputDirectory C:\phobos-benchmark\c4-new-evidence `
  -Python C:\path\to\comparison-venv\Scripts\python.exe `
  -C3SourceArchive C:\path\to\phobos-c3-source.zip `
  -C3InstrumentedArchive C:\path\to\c3-instrumented-source.zip
```

Use Rust 1.85 MSVC and the existing comparison Python dependencies. The output directory must be new. Fixed settings: group window 0, 8192 dirty pages, 128 pages/batch, 10 ms wake, drain shutdown. Instrumented source, control source, raw logs/CSV/profiles, scripts and development history are retained in evidence. Compiler targets and reproducible fixture databases are excluded.

The pre-change diagnostic can be reproduced with tools/write-v3-c4-profile-c3.ps1 against the instrumented archive and the frozen C3 fixture evidence. Its source SHA256 is 1c4b68c392629453143c3e58109b4b43fb9b96b33fab7b86ce12342678d5836c.

To reproduce the confirmation after the Fast gate: tools/write-v3-c4-confirmation.ps1 -GateEvidence <gate-directory> -OutputDirectory <new-directory> -Python <comparison-python>. See validation-history.md for the failed first gate, fixture setup correction, and diagnostic measurements.

Saved PostgreSQL CSV SHA256: 047e2ad0cb660845ddbe3f691817a0a4c49b9f2de2cfe1a1ff058234f54c889e. Not rerun. C5 has not started.
