# PHOBOS protocol — Community 0.1.9-A5+A6

Protocol version 1 uses a fixed 16-byte big-endian frame header:

| Offset | Size | Field |
| --- | ---: | --- |
| 0 | 4 | ASCII magic `PHOB` |
| 4 | 1 | protocol version (`1`) |
| 5 | 1 | message type |
| 6 | 2 | flags |
| 8 | 4 | request ID |
| 12 | 4 | payload length |

Maximum payload size is 1 MiB. The decoder rejects an oversized declared payload before allocating its payload buffer.

Implemented message types:

- `1` Hello
- `2` HelloAck
- `3` Ping
- `4` Pong
- `5` Auth, `6` AuthOk
- `10` Query (UTF-8 SQL text)
- `11` QueryResult (UTF-8 tabular/command text for the collecting query API)
- `12` QueryStream, `13` QueryResultStart, `14` QueryRows, `15` QueryResultEnd
- `16` CommandResult, `17` StreamError
- `20` Metrics, `21` MetricsResult
- `30` BulkBegin, `31` BulkRows
- `40` CancelHandle, `41` CancelHandleResult, `42` Cancel, `43` CancelResult
- `255` Error (UTF-8 structured-error rendering; a richer binary error payload is planned)

The server supports persistent multi-client sessions, authentication/roles, TLS, typed streaming row batches, bulk ingestion and out-of-band cancellation. Typed parameter request frames remain unimplemented. Frame version/limits are unchanged. See [streaming protocol](streaming_protocol.md) for streaming negotiation and payloads.

## Session lifetime

A TCP connection is now a persistent Phobos session. Multiple Query frames may be sent on one connection, and explicit transaction state belongs to that connection. Closing a connection with an active transaction causes server-side rollback. One-shot clients remain supported for autocommit statements.

## Cancellation and timeouts

A2 reserves a random single-use statement handle through CancelHandle before the next SQL/bulk request. Another authenticated connection of the same username sends Cancel while that target is active; the executing request loop need not resume. Unknown/completed handles return CancellationTarget and another username receives Authorization. Repeated active cancellation is safe. After irreversible commit admission, execution finishes with its true outcome. Old clients retain ordinary query compatibility; new cancellation methods require an A2-or-later server.

ParserDepth, StatementCancelled, StatementTimeout and IdleTimeout distinguish the new limits. Streaming failure retains the existing client connection-poisoning/reconnect behavior. Defaults and startup config are documented in [operations](operations.md); idle expiry closes the connection and rolls back uncommitted work. Cancellation is cooperative, not forced interruption of OS/durability operations.
