# Matched PostgreSQL certification campaign

Measured on September 12, 2026. This is a continuation of the completed Phobos write-path campaign, using the same engine and the existing Python TCP comparison driver. The earlier source/results packages are preserved. This report does not compare embedded Phobos timings with PostgreSQL TCP timings.

PostgreSQL passed all fifteen SQL workloads at 100K, 1M, and 10M. Phobos passed the 10M bulk target in 1,653.563 seconds, but oversized results failed and the 10M concurrent-write sample timed out, preventing mixed-workload measurement. Beta remains uncertified. Durability settings and engine code were unchanged.

## Configuration and method

- PostgreSQL 18.6, x86_64 Windows MSVC 19.44.35228, supplied dedicated cluster at `127.0.0.1:55432`, database/user `phobos_bench`. Credentials were supplied to libpq through `PGPASSFILE`; the password file was never read into reports or logs.
- Phobos `0.0.1-alpha.0`, release executable SHA256 `dfd736803c0f10a912a5bda26ff04553dc9a0ae5e611d771b1fd5031ee7fcf17`, pinned Rust 1.85.0 MSVC. Existing release executable and engine source were unchanged.
- Python 3.12.14 and psycopg/psycopg-binary 3.3.5; the complete dependency lock is included. Driver SHA256: `2c17fed2077f9d46a482454e901157c7adf9f3f8ac37c70b34d87d0550513c93`.
- Same Windows host, AMD Ryzen 7 5800X, 16 logical CPUs, build 10.0.26200, C: NTFS storage. Windows reported 34,266,562,560 bytes of physical RAM and 24,355,344,384 available at preflight. This is a capacity snapshot, not process peak memory. A storage device model was not established.
- PostgreSQL checksums, `fsync`, `synchronous_commit`, and `full_page_writes` were verified on before/after each run. `shared_buffers=128MB`, `work_mem=4MB`, `max_connections=20`, `max_parallel_workers_per_gather=0`, `wal_level=replica`. No cluster settings were changed. Phobos retained its existing synchronous durable WAL/commit behavior, checksum checks, transaction ownership, and 1MiB response limit.
- The same deterministic seed 8067, BIGINT/BIGINT/TEXT schema, NOT NULL constraints, unique id index, dimension table, 1,000-row SQL batches, and one explicit bulk transaction were used. Every scale used three samples, three operations, and four concurrent connections on both engines. Bulk has one sample. SQL generation precedes the bulk timer; COMMIT acknowledgement is included.
- PostgreSQL ran first and Phobos second at each scale, serially on the same machine. PostgreSQL used a new isolated schema per scale in the supplied database; Phobos used a new data directory and server per scale. Earlier PostgreSQL schemas were retained. This is fresh logical data, not a freshly initialized cluster at every scale. Neither OS caches nor PostgreSQL shared buffers were forcibly reset. SELECT workloads include a warmup; background maintenance and fixed engine order can influence results. These are observations from one campaign, not randomized repeated-trial confidence estimates.
- Both adapters use plaintext TCP loopback and fully materialize results. PostgreSQL uses SCRAM; the fresh Phobos benchmark server uses its documented unauthenticated loopback defaults. Connection establishment is excluded. No configured service security was disabled and no TLS-performance claim is made. PostgreSQL sessions use SERIALIZABLE; Phobos uses coarse transaction-owner locking rather than PostgreSQL MVCC. Buffer and concurrency architectures are not equivalent.
- Wrapper limits were 3,600 seconds without an observed successful bulk record and 7,200 seconds for each engine's full driver. Phobos's existing 120-second socket timeout was unchanged. Query errors, timeouts, and nonzero driver exits are retained. The pair wrapper can return zero after recording a nonzero engine exit; its exit is not a certification success gate.

## Reading the evidence

`comparison.csv` and `comparison.json` retain every workload and scale. Timings are complete sample durations: three operations for ordinary mutations and twelve operations across four connections for concurrent workloads. They are not individual operation latency distributions. The reported median uses successful samples; a ratio is emitted only when both workloads have their complete expected set of successful samples. Min/max and sample counts are included. With only three samples, a reliable p95 is unavailable; bulk has no timing distribution.

Whole-driver wall times include setup, warmups, cleanup, and failed attempts. Since completion differs between engines, they are not used to claim a whole-suite speed ratio.

A zero-nanosecond `unsupported_or_failed` row is the driver's untimed failure sentinel, not zero execution cost. In particular, the full-result queries which exceed the Phobos response cap are retained as failures. The cap is an enforced safety limit; this campaign neither raises it nor replaces queries with aggregates or pagination. A rejected workload does not establish successful full-result TCP parity.

The original driver verifies row counts and aggregate result shapes; it is not a full value-by-value SQL equivalence oracle. The previous final-source 1M/10M logical certification provides separate correctness evidence. Additional reopen checks from this campaign are explicitly identified as untimed postchecks.

Raw driver `environment.json` files were preserved byte-for-byte. Their Phobos-side `postgresql_results: pending` field and the driver's opening docstring are legacy static text, not the campaign's current measured status. PostgreSQL's actual raw records and invocation metadata establish the measurements here.

## Scope limits

PostgreSQL emitted WAL is the `pg_stat_wal.wal_bytes` delta for the whole dedicated cluster during each driver, including setup, cleanup, and background activity. The statistics reset timestamp is verified unchanged. No other client backend was present at the before/after checks; this does not continuously prove exclusive activity. These values are not per-workload WAL counters. Retained WAL file length is not emitted WAL volume.

The normal Phobos TCP build does not report emitted WAL byte counters to this harness. Its emitted WAL remains unmeasured in this matched campaign; no ratio is fabricated from retained files or the separate instrumented embedded run. Database footprint measurements also have different accounting boundaries: PostgreSQL per-schema relations include heap, indexes, and auxiliary relation files, whereas the Phobos directory includes catalog and engine metadata. The complete PostgreSQL database size includes earlier retained schemas.

The existing SQL comparison driver does not measure service startup or matched crash recovery. PostgreSQL was not stopped or crashed. Previous Phobos recovery certification is retained as separate evidence, with no PostgreSQL ratio. This campaign also does not collect comparable per-process CPU/peak-memory samples. Those are unmeasured, not zero. Do not interpret the memory capacity snapshot as a benchmark resource peak.

The previous final-source gates remain separate: 71 distinct Rust tests (68 routine plus three explicitly run long tests), strict all-target/all-feature Clippy, Phase 7/8 validation, full 1M/10M logical and backup/restore checks, 1,000 controlled process-crash cycles, a two-hour soak, and 25 live TLS/operations cycles. This comparison does not rerun or inflate those counts. The source fingerprint and release hash audit ties the measurements to that engine.


## Measured bulk load

| Rows | PostgreSQL seconds | Phobos seconds | Phobos / PostgreSQL |
|---:|---:|---:|---:|
| 100,000 | 0.526085 | 13.084792 | 24.872006 |
| 1,000,000 | 5.748338 | 144.920202 | 25.210800 |
| 10,000,000 | 65.157907 | 1653.562584 | 25.377773 |

## Driver completion and failures

| Engine | Rows | Driver exit | Whole seconds | Successful timed samples | Wrapper timeout |
|---|---:|---:|---:|---:|---|
| postgresql | 100,000 | 0 | 6.000 | 43 | none |
| phobos | 100,000 | 1 | 49.031 | 37 | none |
| postgresql | 1,000,000 | 0 | 44.015 | 43 | none |
| phobos | 1,000,000 | 1 | 457.203 | 34 | none |
| postgresql | 10,000,000 | 0 | 488.188 | 43 | none |
| phobos | 10,000,000 | 1 | 3946.844 | 28 | none |

- phobos 100,000, `full_scan`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 100,000, `sort_spill`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 1,000,000, `full_scan`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 1,000,000, `join`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 1,000,000, `sort_spill`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 10,000,000, `full_scan`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 10,000,000, `join`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 10,000,000, `sort_spill`, sample -1, `unsupported_or_failed`: result exceeds configured maximum

- phobos 10,000,000, `concurrent_writers`, sample 0, `error`: timed out

- phobos 10,000,000 incomplete/unmeasured workloads: mixed.

## All workloads: 100,000 rows

Median seconds per complete timed sample; ratio greater than one means Phobos took longer.

| Workload | PostgreSQL seconds | Phobos seconds | Ratio | Phobos status |
|---|---:|---:|---:|---|
| bulk_load | 0.526085 | 13.084792 | 24.872006 | complete |
| indexed_point | 0.000166 | 0.000207 | 1.244431 | complete |
| indexed_range | 0.000247 | 0.000373 | 1.513788 | complete |
| full_scan | 0.128529 | unmeasured | unmeasured | failed |
| scan_aggregate | 0.003711 | 0.034159 | 9.204991 | complete |
| join | 0.077681 | 0.126294 | 1.625794 | complete |
| group_aggregate | 0.010013 | 0.311746 | 31.135029 | complete |
| sort_spill | 0.482388 | unmeasured | unmeasured | failed |
| autocommit_insert | 0.000899 | 0.706240 | 785.933452 | complete |
| transaction_insert | 0.000738 | 0.211906 | 287.018962 | complete |
| update | 0.000937 | 0.793984 | 847.640013 | complete |
| delete | 0.002128 | 0.741631 | 348.461683 | complete |
| concurrent_readers | 0.001733 | 0.002149 | 1.239975 | complete |
| concurrent_writers | 0.001940 | 3.645805 | 1879.280979 | complete |
| mixed | 0.001644 | 2.300446 | 1399.212943 | complete |

## All workloads: 1,000,000 rows

Median seconds per complete timed sample; ratio greater than one means Phobos took longer.

| Workload | PostgreSQL seconds | Phobos seconds | Ratio | Phobos status |
|---|---:|---:|---:|---|
| bulk_load | 5.748338 | 144.920202 | 25.210800 | complete |
| indexed_point | 0.000182 | 0.000197 | 1.083608 | complete |
| indexed_range | 0.000215 | 0.000373 | 1.737529 | complete |
| full_scan | 1.426450 | unmeasured | unmeasured | failed |
| scan_aggregate | 0.036607 | 0.353085 | 9.645278 | complete |
| join | 0.724677 | unmeasured | unmeasured | failed |
| group_aggregate | 0.103788 | 3.492998 | 33.655089 | complete |
| sort_spill | 6.098032 | unmeasured | unmeasured | failed |
| autocommit_insert | 0.000706 | 7.109815 | 10071.986825 | complete |
| transaction_insert | 0.000679 | 2.957211 | 4356.528285 | complete |
| update | 0.000745 | 8.488951 | 11397.624597 | complete |
| delete | 0.000780 | 8.700065 | 11152.499680 | complete |
| concurrent_readers | 0.001790 | 0.002141 | 1.196201 | complete |
| concurrent_writers | 0.002272 | 28.947484 | 12739.287858 | complete |
| mixed | 0.001733 | 15.837589 | 9137.246120 | complete |

## All workloads: 10,000,000 rows

Median seconds per complete timed sample; ratio greater than one means Phobos took longer.

| Workload | PostgreSQL seconds | Phobos seconds | Ratio | Phobos status |
|---|---:|---:|---:|---|
| bulk_load | 65.157907 | 1653.562584 | 25.377773 | complete |
| indexed_point | 0.000176 | 0.000223 | 1.263755 | complete |
| indexed_range | 0.000205 | 0.000391 | 1.906296 | complete |
| full_scan | 14.370071 | unmeasured | unmeasured | failed |
| scan_aggregate | 0.508186 | 4.149741 | 8.165783 | complete |
| join | 7.402391 | unmeasured | unmeasured | failed |
| group_aggregate | 1.139228 | 38.179516 | 33.513502 | complete |
| sort_spill | 74.151029 | unmeasured | unmeasured | failed |
| autocommit_insert | 0.001030 | 100.990812 | 98049.331845 | complete |
| transaction_insert | 0.000900 | 32.892538 | 36551.325481 | complete |
| update | 0.001007 | 108.464428 | 107689.067017 | complete |
| delete | 0.000938 | 106.590893 | 113600.014068 | complete |
| concurrent_readers | 0.001778 | 0.002594 | 1.459250 | complete |
| concurrent_writers | 0.002447 | unmeasured | unmeasured | failed |
| mixed | 0.001866 | unmeasured | unmeasured | incomplete |

## Size and WAL evidence

Bytes, measured at completion/postcheck. These are the accounting boundaries described above.

| Rows | PostgreSQL schema relations total | PostgreSQL whole database | PostgreSQL whole-run emitted WAL delta | Phobos retained directory files |
|---:|---:|---:|---:|---:|
| 100,000 | 9,142,272 | 17,356,479 | 15,809,883 | 9,111,945 |
| 1,000,000 | 90,832,896 | 108,230,335 | 155,907,212 | 90,818,953 |
| 10,000,000 | 907,542,528 | 1,015,789,247 | 2,922,391,583 | 908,035,421 |

## Untimed postchecks

| Engine | Rows | Logical checks passed / attempted | Offline integrity exit | Combined pass |
|---|---:|---:|---:|---|
| postgresql | 100,000 | 10 / 10 | not run | True |
| phobos | 100,000 | 10 / 10 | 0 | True |
| postgresql | 1,000,000 | 10 / 10 | not run | True |
| phobos | 1,000,000 | 10 / 10 | 0 | True |
| postgresql | 10,000,000 | 10 / 10 | not run | True |
| phobos | 10,000,000 | 0 / 0 | 0 | False |

Checks cover row count, id/bucket sums, dimension count, deterministic payloads at six indexed points and a twenty-row range. Phobos is reopened before querying and checked offline afterward. These checks do not substitute for the previously completed full 1M/10M logical, composite-index, backup/restore campaign. Full actual/expected results and integrity output are retained.


The initial 10M Phobos postcheck failed before SQL: its one-second TCP readiness probe timed out before the server logged readiness, and the helper aborted that attempt. It still passed offline integrity. The initial failure is preserved. A separate follow-up waits for the explicit readiness message within the same 120-second startup budget; it observed readiness in 4.031s. No benchmark timeout changed and no SQL was retried to turn a failed benchmark sample into success.


The follow-up passed 9 of 10 logical checks, including all original-range aggregates and indexed point/range values. Offline integrity again exited 0. The whole-table original-row-count check correctly failed because 6 concurrent-write rows remain after the driver aborted before cleanup. These rows match their deterministic seed values and were not deleted. Their IDs are 10000072, 10000073, 10000075, 10000078, 10000081, 10000082. The driver does not log individual commit acknowledgements, so this follow-up cannot determine which timed-out requests were acknowledged. It is evidence of an intact original range plus surviving writes, not a complete concurrent-write pass. See `postcheck-followup.json` for exact results.

## Certification decision and remaining blockers

**Beta certification is not complete; the package remains `0.0.1-alpha.0`.** PostgreSQL installation is no longer a blocker and no PostgreSQL result in this report is estimated. PostgreSQL completed the fifteen SQL workloads at each of the three scales. Phobos's 10M TCP bulk load passed the unchanged one-hour target, but successful bulk loading does not make the entire comparison pass.

The unchanged full-result scan, join, and sort workloads encounter Phobos's documented materialized-response limit, as recorded individually above. This is correct enforcement of the existing resource policy, not evidence that durability or integrity failed. It nevertheless prevents those mandatory full-result TCP workloads from passing. The protocol and client both bound a result frame to 1MiB; outputs of millions of rows cannot fit that frame. Satisfying the unchanged workloads would require a separately justified result-delivery/protocol change. Raising or removing the cap, silently paging, or replacing the workload with COUNT would not certify this configuration.

Any additional error or incomplete workload is explicitly listed in the raw-derived completion section. Successful samples before a failure are retained, but a partially measured workload receives no successful-pair ratio. No exception was suppressed, test removed, timeout extended, durability setting weakened, or failure relabeled as success.

At 10M, the first concurrent-writer sample failed with `TimeoutError: timed out` while receiving a response frame. The sample recorded 154.4665685 seconds before propagating a worker failure; the original per-socket timeout was 120 seconds. These are different clocks because worker requests and future collection are sequential within each client/task. Remaining writer samples and all mixed-workload samples were not run after that fatal error. The whole driver exited 1 after 3,946.844 seconds. The wrapper's `timeout: null` means its outer bulk/whole deadline did not fire; it does not mean no socket timeout occurred. The raw CSV and traceback are authoritative, and the driver did not reach its final `limitations.json` write for this run.

The inspected coordinator holds the shared `database` mutex through statement execution and result serialization (`crates/phobos-server/src/lib.rs`, `Coordinator::execute`, lines 69–83). `lock_database` uses blocking `Mutex::lock` (lines 221–224). The two-second owner wait applies to an explicit transaction owner; it does not bound acquisition of the database mutex for these autocommit queries. Durable small commits measured tens of seconds each at 10M. That serialization is consistent with queued responses exceeding the client deadline, although the unchanged driver does not provide a per-request lock-wait breakdown. Increasing timeouts would change this certification configuration, not demonstrate acceptable completion under the recorded one. The timeout and absent mixed sample remain release blockers.

Matched Phobos emitted WAL volume and comparable PostgreSQL startup/crash recovery are still unmeasured. No WAL, startup, recovery, CPU, or peak-memory parity is claimed. The separate earlier Phobos durability, security, large logical correctness and soak evidence remains valid for the unchanged source. Measured small-commit costs and every workload where Phobos loses remain in the tables.

## Changes, validation, and reproduction

No Rust engine code, protocol code, original comparison driver, Cargo versions, PostgreSQL configuration, or release executable changed in this campaign. Changes are the comparison/status documentation and retained evidence. The external run wrapper, untimed postcheck, derivation and packaging helpers accompany the raw evidence. `changed-files.json` inventories every source-package change against the prior write-path candidate; `postgresql-docs.patch` contains the documentation diff.

See the delivered `validation.log` for the checks actually performed in this continuation, and `source-audit.json` for the 67 engine/build fingerprints and three binary hashes. The earlier 71-test, strict-Clippy, Phase 7/8, crash, soak and large-correctness totals are inherited unchanged-source evidence, not a claim that this TCP driver reran them. No beta success marker was emitted.

Fresh continuation checks passed: formatting, strict workspace Clippy with all targets/features and `-D warnings`, all four existing Python comparison-harness tests, and the source/binary fingerprint audit. Five datasets passed all ten initial logical postchecks. The separate 10M Phobos follow-up passed nine of ten logical checks as described above; its extra-row count failure and the initial readiness-helper failure are retained rather than included in a fabricated all-pass total.

Use `REPRODUCE.md` in the comparison package for exact folder layout, commands, dependency lock, fresh-run names and credential handling. `raw-results.zip` retains the original driver CSV/JSON/logs, wrapper invocation metadata, before/after PostgreSQL settings, whole-run WAL deltas, source audit and postchecks. Large live database files and the password file are not bundled. The new `phobos-source.zip` contains the updated project and comparison evidence; `phobos-windows-candidate.zip` contains the unchanged executables with updated limitations. `SHA256SUMS.txt` covers the delivered files.

Earlier archives under the write-path candidate output were preserved. The historical write-path report describes the earlier state when PostgreSQL was unavailable; this report supersedes that installation/comparison status while retaining its original measurements and limitations.

