# Session 003 — Phase 2 candidate

## Objective
Implement the Phase 2 single-table SQL/DML milestone on top of the gated Phase 1 storage foundation.

## Implemented
- Owned expression AST with precedence-aware parsing.
- `WHERE` predicates with SQL three-valued NULL logic.
- Comparisons: `=`, `!=`, `<>`, `<`, `<=`, `>`, `>=`.
- Boolean `AND`, `OR`, `NOT`, `IS NULL`, and `IS NOT NULL`.
- Numeric `+`, `-`, `*`, `/` with checked integer arithmetic and division-by-zero errors.
- `UPDATE ... SET ... [WHERE ...]`.
- `DELETE FROM ... [WHERE ...]`.
- `ORDER BY` with multiple columns and ASC/DESC.
- `LIMIT` and `OFFSET`.
- Typed `$1`, `$2`, ... binding through `Database::execute_params`; parameters are values, never SQL string substitution.
- Heap record tombstoning/replacement required by UPDATE/DELETE.
- Bounded row-batch SELECT API (`Database::stream_select`) for queries that do not require ordering.
- Tests for DML, NULL logic, parameters, restart persistence, constraints, and bounded batches.

## Deliberate limitations
- No transaction atomicity or WAL yet; those are Phase 3. An I/O failure midway through UPDATE/DELETE is therefore not crash-atomic.
- ORDER BY materializes matching rows in memory. External sort/spill is a later execution milestone.
- The existing text network query path still materializes a complete textual response in one protocol frame. The new bounded streaming API is engine-level in this candidate; end-to-end wire result batching must be added before calling network result streaming complete.
- Single-table statements only. Joins and aggregation remain later milestones.
- No indexes; scans are sequential until Phase 4.

## Gate status
Candidate only until formatting, Clippy, workspace tests, rustdoc, manual DML/restart checks, and the remaining end-to-end streaming concern are resolved.
