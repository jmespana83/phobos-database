# Physical replication and PITR

G3 provides one-primary physical replication over the existing segmented V2 WAL. It does not add logical replication, automatic failover, promotion, timelines, quorum commit, or archive management.

Create an F5 online backup, then initialize a standby and transfer/replay WAL:

```text
phobos-admin replication-init PRIMARY_DATA ONLINE_BACKUP STANDBY_DATA SLOT
phobos-admin replication-receive PRIMARY_DATA STANDBY_DATA
phobos-admin replication-replay STANDBY_DATA
```

The base backup contains its start/end LSN and database identity. The standby durably records its received and replayed positions, rejects another system identity, and resumes from its last replayed LSN. `replication-receive` is safe while the standby serves reads; `replication-replay` takes the data-directory lock and therefore requires the standby server to be stopped. Restarting it exposes the newly replayed snapshot. Standby SQL is read-only: SELECT/EXPLAIN/metrics work subject to the normal role, while DML, DDL, bulk input, and other mutations fail.

A durable replication slot pins the oldest WAL required by the standby: its LSN is the standby's *replayed* position (receiving alone does not advance it). Checkpoint still applies its normal recovery frontier, but no checkpoint — incremental, `CHECKPOINT`, online backup, clean shutdown, or crash recovery — discards a record after the oldest slot. Since 0.2-I.2, records a full checkpoint would otherwise discard are kept in `phobos.wal-retained/` (outside the recovery path) until every slot has replayed past them. Replaying advances the slot. Remove an abandoned slot explicitly with `phobos-admin replication-slot-drop PRIMARY_DATA SLOT`; its WAL is released at the next checkpoint. `phobos-admin replication-status PRIMARY_DATA [STANDBY_DATA]` shows slots, protected LSNs, pinned/retained bytes and standby positions. If a requested range is no longer present, receive fails with `new base backup required`; a gap is bridged only when it provably holds no transaction (see `docs/replication_retention_0_2_i_2.md`).

For minimal LSN-based PITR, copy a consistent WAL archive and recover from a matching online backup:

```text
phobos-admin wal-archive PRIMARY_DATA EMPTY_ARCHIVE_DIR
phobos-admin recover-to ONLINE_BACKUP WAL_ARCHIVE EMPTY_DESTINATION TARGET_COMMIT_LSN
```

To let PITR cross primary restarts and checkpoints, protect the base backup's WAL right after taking it (and drop the slot when the archive is no longer needed):

```text
phobos-admin wal-retain PRIMARY_DATA ONLINE_BACKUP SLOT
phobos-admin replication-slot-drop PRIMARY_DATA SLOT
```

`wal-archive` copies the live WAL and the retained history. The target must be an exact committed LSN at or after the backup end. Recovery reuses normal WAL validation/redo, includes the target commit, excludes later commits, and produces an ordinary writable database. Identity mismatches and missing/retired WAL fail closed.
