# Audit logging

Set `audit_enabled: true` and `audit_log_path` to enable the append-only JSON Lines audit sink. Each record contains a millisecond timestamp, event type, authenticated principal, session id, action, bounded target, success flag, and bounded detail. The file is flushed after security-critical events; ordinary successful reads are not audit events and do not add a per-query sync.

Current events cover successful and failed login, mTLS mapping, permission denial, DDL success/failure, and server start/shutdown. Local offline administration remains protected and attributable through operating-system access and is outside the server session audit sink.

Audit fields are capped at 256 characters. Passwords, password hashes, raw authentication payloads, private keys, and full certificates are never recorded. Protect the audit path with operating-system permissions and arrange external rotation/retention; PHOBOS does not rotate or compress it.
