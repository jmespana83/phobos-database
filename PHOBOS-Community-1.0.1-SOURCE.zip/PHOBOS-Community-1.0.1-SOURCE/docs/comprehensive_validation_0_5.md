# Phobos Phase 0-5 comprehensive validation

This campaign is the post-Phase-5 system validation gate. It does not replace subsystem unit tests; it combines public APIs across storage, SQL, transactions/WAL, indexes, and multi-client coordination.

## Automated gate

Run from the repository root on Windows PowerShell:

```powershell
.\tools\full-validation.ps1
```

The script performs formatting, strict Clippy, the complete workspace test suite, the dedicated cross-phase tests, longer ignored soak tests, rustdoc generation, and a release build.

## Dedicated cross-phase scenarios

`phobos-validation` covers:

- Phase 0-5 end-to-end create/insert/index/transaction/checkpoint/restart behavior.
- Atomic failure and rollback across restart.
- Randomized disk-backed B+ tree mutations against a trusted `BTreeMap/BTreeSet` model, followed by reopen and range verification.
- Torn final WAL tail recovery and idempotent redo, including `.idx` file images.
- Eight concurrent autocommit writers with a unique index and no lost rows.
- Explicit-transaction disconnect rollback with a blocked waiter.
- SQL NULL, ordering, limit/offset, update, delete, and restart semantics.
- A 25-cycle deterministic transaction/restart soak (ignored by default).
- A 12-writer concurrent insertion soak (ignored by default).

## Passing criteria

The gate is considered clean only when every command in `tools/full-validation.ps1` exits successfully. Do not infer production readiness from this gate. Phobos remains alpha and currently uses coarse strict locking rather than MVCC for Phase 5 concurrency.

## Still outside this gate

Phase 6+ relational operators and optimizer work, production authentication/TLS, online backup, platform matrix testing, power-loss/fsync hardware validation, fuzzing infrastructure, sanitizer/Miri runs, long multi-hour soak workloads, and PostgreSQL performance comparisons remain future milestones.
