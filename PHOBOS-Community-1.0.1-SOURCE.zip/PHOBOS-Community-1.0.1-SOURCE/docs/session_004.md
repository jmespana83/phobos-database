# Session 004 — Phase 3 candidate

## Objective

Add single-user transactional atomicity and crash recovery without starting Phase 4 indexes or Phase 5 concurrency.

## Implemented

- SQL `BEGIN`, `COMMIT`, `ROLLBACK`, and `CHECKPOINT`.
- Durable transaction ID control file.
- Private transaction staging directories with read-your-writes semantics.
- Autocommit routed through the same transactional commit path.
- Framed checksummed WAL with record type, transaction ID, LSN, previous LSN, payload length, and checksum.
- Bounded 1 MiB WAL file-image chunks.
- Synchronous WAL-before-main-data commit ordering.
- Startup redo for committed transactions and discard of incomplete transactions.
- Torn/truncated final WAL record handling.
- Checkpoint and generation-based WAL rotation.
- Recovery cleanup of stale transaction staging directories.
- Unit tests for WAL checksums, torn tails, idempotent redo, transaction ID restart, commit/rollback, and subprocess crash behavior.

## Deliberate boundary

The WAL currently stores full changed database file images rather than page-delta physiological records. This is slower and more verbose, but gives a small, auditable correctness surface for Phase 3. Phase 4 indexes will consume the same transactional contract; later performance work can narrow WAL records without changing SQL transaction semantics.

## Gate

Do not mark Phase 3 complete until local formatting, strict Clippy, full workspace tests including subprocess crash tests, rustdoc, and manual commit/rollback/restart checks all pass.
