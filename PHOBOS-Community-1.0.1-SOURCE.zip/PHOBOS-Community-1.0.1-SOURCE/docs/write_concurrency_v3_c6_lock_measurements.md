# C6 lock and status measurements

Instrumented processes only. Histogram quantiles are inclusive bucket upper bounds; maxima are cumulative across a process. Duration windows can overlap. Row/key waits include unsuccessful outcomes. Ordinary TPS remains in the separate measurement table.

| Rows | Domain | Acquisitions | Immediate | Waits | Victims | Timeouts | Cancel | p50 upper ns | p95 upper ns | p99 upper ns | Maximum ns |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 100000 | row | 1777 | 1756 | 24 | 203 | 0 | 0 | 1000000 | 100000000 | 100000000 | 18796200 |
| 100000 | unique | 1678 | 1675 | 3 | 0 | 0 | 0 | 10000000 | 10000000 | 10000000 | 8693200 |
| 1000000 | row | 1779 | 1762 | 18 | 201 | 0 | 0 | 100000000 | 100000000 | 100000000 | 13917000 |
| 1000000 | unique | 1661 | 1658 | 3 | 0 | 0 | 0 | 10000000 | 10000000 | 10000000 | 4513800 |

All workload-boundary active waiter snapshots are zero. Cancellation and timeout are exercised by deterministic correctness tests rather than injected into throughput trials.

| Rows | Coordination duration | Calls | Mean ns | p50 upper ns | p95 upper ns | p99 upper ns | Cumulative maximum ns |
|---:|---|---:|---:|---:|---:|---:|---:|
| 100000 | mvcc.commit_order_acquire | 1003 | 67.4 | 128 | 128 | 256 | 500 |
| 100000 | mvcc.commit_queue_acquire | 1669 | 72.68 | 128 | 128 | 256 | 400 |
| 100000 | mvcc.commit_completion_wait | 1874 | 13397094.93 | 16777216 | 67108864 | 67108864 | 122395800 |
| 100000 | mvcc.wal_writer_acquire | 7841 | 55.45 | 128 | 128 | 256 | 8700 |
| 100000 | mvcc.database_directory_acquire | 6010 | 43.13 | 1 | 128 | 128 | 400 |
| 100000 | index.epoch_wait | 16114 | 12429.41 | 128 | 256 | 524288 | 522600 |
| 100000 | index.publication_acquire | 1669 | 42.3 | 1 | 128 | 128 | 200 |
| 100000 | mvcc.ordered_publication | 1669 | 2782966.15 | 2097152 | 8388608 | 16777216 | 227923300 |
| 100000 | mvcc.rebase_preparation | 1669 | 2612082.98 | 2097152 | 8388608 | 16777216 | 32571900 |
| 100000 | mvcc.schema_admission | 0 | 0 | None | None | None | 1000 |
| 1000000 | mvcc.commit_order_acquire | 1005 | 59.6 | 128 | 128 | 256 | 400 |
| 1000000 | mvcc.commit_queue_acquire | 1652 | 77.72 | 128 | 128 | 256 | 2700 |
| 1000000 | mvcc.commit_completion_wait | 1855 | 9664236.06 | 8388608 | 33554432 | 33554432 | 61025300 |
| 1000000 | mvcc.wal_writer_acquire | 7754 | 53.38 | 128 | 128 | 256 | 600 |
| 1000000 | mvcc.database_directory_acquire | 5961 | 43.11 | 1 | 128 | 128 | 600 |
| 1000000 | index.epoch_wait | 16076 | 11561.88 | 128 | 256 | 524288 | 522200 |
| 1000000 | index.publication_acquire | 1652 | 44.37 | 1 | 128 | 128 | 400 |
| 1000000 | mvcc.ordered_publication | 1652 | 1862701.51 | 2097152 | 4194304 | 8388608 | 22610100 |
| 1000000 | mvcc.rebase_preparation | 1652 | 2115112.35 | 2097152 | 4194304 | 8388608 | 22432200 |
| 1000000 | mvcc.schema_admission | 0 | 0 | None | None | None | 1100 |

Schema uses immediate admission/rejection, not a blocking wait. The admitted cohorts had no contested physical-owner acquisition because ownership is moved after disjointness validation. Ordered preparation time is work, not a lock-wait measurement. Fair fallback was not needed in these measured windows; deterministic split testing exercises generation changes.

| Rows | Snapshot ns/call | Visibility ns/call | Status read ns/call | Status write ns/call | Status force ns/call | Transactions / WAL force |
|---:|---:|---:|---:|---:|---:|---:|
| 100000 | 258.79 | 4239.05 | 16557.0 | 19764.58 | 1235586.87 | 1.664 |
| 1000000 | 255.47 | 400.18 | 16712.18 | 18954.35 | 639221.77 | 1.6438 |

These are weighted inclusive costs across measured windows, not isolated microbenchmarks. Visibility includes variable cache misses and ownership rechecks, so cardinalities have different mixes. Status force includes OS durability. Unique wait/recheck samples: 100K 6.395/7.408/11.759 ms; 1M 6.983/5.759/5.745 ms. Each waiter rejected the duplicate after the owner committed.

Raw histograms, event counts, per-outcome same-row latency and all deltas are retained in the evidence summary.json.
