# C5 stable identity increment — SQL integration incomplete

C5 is not frozen. This increment resolves the status/WAL identity model and
implements its low-level mapping, reservation, recovery and retirement barriers.
It does not enable SQL MVCC or satisfy the full C5 acceptance campaign.

## Identity model

The stable MVCC ID is reserved and forced at session BEGIN, before private writes.
The durable status file supplies a monotonically increasing, bounded namespace.
Reservation records are distinct from committed and aborted records. Its
checksummed header persists the reservation boundary; losing the reserved extent
fails recovery instead of reusing an ID. Unfinished reservations become aborted
only during exclusive recovery after retained commit mappings have been replayed.

WAL chain IDs remain monotonically allocated at submission. Each MVCC chain has
exactly one `MvccIdentity(stable_id)` record immediately after BEGIN and before
data. The record participates in the existing CRC and previous-LSN chain checks.
The opaque durable receipt carries both identities; COMMIT's WAL LSN remains the
ordered visibility sequence. Two appended commits still share the existing C1
force operation. A can reserve ID 1, B reserve ID 2, and B submit WAL chain 1 before
A submits chain 2. No transaction waits for an earlier BEGIN to commit.

Tuples, session state, logical-row ownership and unique-key ownership must use the
stable identity. WAL submission/replay bookkeeping uses chain identity. The tuple
envelope already accepts stable IDs without changing SQL RowCodec. **Private-page
ownership validation and SQL conflict ownership are not integrated yet**: their
current C4 comparisons still use the WAL receipt's chain ID. They must explicitly
bind to the mapped stable ID for the MVCC route before that route is enabled.

## Persistent gate and compatibility

Capability 3 uses retained WAL anchor flag 2, with new record kind 14 for the
mapping. The existing `page_format` field carries that anchor capability; heap
LSN images remain version 2 at this stage. This is not permission to store tuple
envelopes in legacy heap pages. The future versioned-heap gate is still required.

`PHMS` status format 2 records stable reservations and their boundary. Format 1
remains for the earlier component tests and cannot be mixed with capability 3.
No existing database is upgraded automatically. Fresh low-level creation is
explicit. Ordinary Database and admin preflight reject capability 3 while the
SQL/admin integrations are unfinished.

The frozen C4 admin executable was run against a capability-3 anchor fixture.
It returned `InvalidWal: unsupported V2 WAL flags`; every fixture file retained
its original hash. Full retirement preserves the capability. Incremental MVCC retirement remains
gated until the visibility horizon is integrated.

## Durability and recovery

Status installation needs a matching-directory durable mapped receipt, a live
reservation and increasing commit sequence. It forces the status before allowing
ordered publication to advance. Failure during installation fences the store.
The current per-reservation/status forces are deliberately not performance-tuned.

`StatusFile::recover_database` reconciles visibility before WAL redo and full
retirement. Recovery first validates/forces WAL, replays mapped commits into their
stable slots (including repair of covered torn status records), resolves remaining
reservations to aborts, validates all reserved slots and forces status storage.
Repeated recovery is idempotent. Unknown historical status fails closed.

Ordinary `Wal::recover` rejects capability 3. Explicit recovery requires the
visibility-reconciliation callback. Ordinary full checkpoint also rejects it;
the registry's visibility barrier forces status and supplies a frontier covering
the last committed WAL sequence before full retirement. Incremental MVCC WAL
retirement is currently rejected until C4's dirty-page horizon is combined with
the visibility frontier. Legacy C1–C4 paths retain their existing operation.

## Verification

Evidence: `work/write-v3/evidence/c5-identity-03` outside this source tree.
The preceding `c5-identity-01` preserves a strict-Clippy range-pattern failure,
fixed without suppression. `c5-identity-02` records the earlier identity revision;
revision 03 adds reservation-truncation and retained-WAL status-repair safeguards.

Focused tests cover reverse commit order with one group force; abort after a later
transaction commits; capability and mapping-position errors; missing status
barriers; truncated reservation extents; torn committed-status repair; repeated
recovery; and 20 new identity subprocess crash cases. The identity crash cases
exit after B's WAL force, after B's status force, after A's status force before WAL
retirement, and after retirement (five repetitions each). Parents require an
explicit forced boundary marker and exit 87, then recover twice. The workspace
gate also runs four earlier status-component crash cases, plus inherited C1–C4
tests. Counts are per gate; development reruns remain in their respective logs.

No PostgreSQL, 10M, long soak, or C5 performance run was executed. The full SQL path
still follows C4's strict isolation. The remaining ordered work is explicit
backup-first migration, session contexts and RAII pins, versioned heap/index and
relational paths, versioned mutations, conflict/unique ownership with wait/recheck,
bounded reclamation, and full 100K/1M SQL/session Fast acceptance.
