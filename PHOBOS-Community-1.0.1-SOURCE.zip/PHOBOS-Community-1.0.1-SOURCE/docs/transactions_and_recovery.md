# Transactions and recovery — Community 0.1.9-D1+D2+D3

## MVCC contract

Explicitly migrated capability-4 stores provide **Read Committed** isolation. Every statement pins its own snapshot; a later statement may see another transaction's newly committed work. Transactions see their own staged/spilled writes. BEGIN, COMMIT, ROLLBACK and autocommit are supported. There are no savepoints or selectable snapshot isolation. Legacy V1/V2 databases keep their pre-MVCC transaction path until offline migration.

A3 changed status capacity from a fixed lifetime grant into checked growth extents (default 1,048,576 records). A grant expansion writes and forces the new header before a record beyond the prior grant can be persisted. Records remain at fixed offsets; the grant does not preallocate that eventual space. The former 16,777,216 ceiling is not permanent. IDs remain monotonic, with existing representability/resource bounds; C4 now logically freezes a proven-unreferenced prefix, without wraparound reuse or physical status compaction. BEGIN/identity reservation and status transitions retain their existing sync behavior; A5 only connects the growth-extent knob.

## Visibility hints and status caching (0.1.9-B1/B2)

Tuple visibility still resolves creator/deleter transaction status under the same Read Committed rules; B1/B2 only change how often that resolution touches the status store. B1 keeps two **settled-visibility hints** per tuple version (creator committed, deleter committed) in a bounded per-table, cache-resident structure (two bits per slot, sharded by page). A hint is recorded only after an ordinary lookup returned Committed with a commit sequence at or below the statement's hint bound (the minimum live snapshot sequence, which never moves backwards), so every live and future snapshot already sees that commit; InProgress and Aborted transactions, own uncommitted writes and commits newer than a live older snapshot are never hinted. Hints are an optimization only: they never change a query result, are **not persisted** (they vanish on restart or eviction and are relearned by the next scan), and are never written into pages or WAL. `hint_bits_enabled` (default true) turns them off entirely; the tuple envelope reserves its flag byte for a future durable form.

B2 replaces the per-statement status map with one **bounded shared cache** of final statuses (16 shards, 4,096 direct-mapped slots each, Committed/Aborted only, overwrite eviction). InProgress is never cached, so a transaction that later commits or aborts is always re-resolved through the registry. Cache and hint hits check the fencing flags without taking the session-state or status-file mutexes. Remaining misses read the status file in 4 KiB pages through a 16-page direct-mapped cache inside the status store; every reserve/commit/abort write patches the cached page in place, header rewrites (growth, reservation boundary) and recovery drop the affected window, and a failed record write drops its window. No status-file, WAL or page format changed.

## Pending writes and interruption

A4 keeps a transaction memtable up to the write-spill threshold (default 64 MiB, plus a crossing change), then writes immutable sorted runs under `.phobos-mvcc-writes-*`. Newer changes shadow older ones; overlays and UNIQUE checks include spilled writes. The default per-transaction scratch quota is 2 GiB. Commit iterates the merged write set without rebuilding one giant change vector. Run metadata, two 64 KiB buffers per run and statement-local ID lists are still costs; there is no run compaction.

The transaction spill threshold is separate from the **64 MiB one-statement** resolution/candidate limit. A large single INSERT/UPDATE/DELETE may still fail ResourceLimit. Scratch is private, disposable workspace, never durable WAL data. Rollback, interruption, disconnect and normal completion release it; startup removes abandoned scratch after recovery.

A2 cancellation or timeout before commit admission discards an autocommit write's effects. An interrupted explicit write aborts/discards the whole transaction and requires ROLLBACK; an interrupted read preserves the transaction where safe. Cleanup releases row/unique ownership and statement pins. Ordinary timeout/cancel does not fence the database. Real durability failures retain existing fencing.

## Commit and recovery

MVCC staging and bulk finalization run before irrevocable commit admission. Cancellation atomically competes with admission; once admitted, preparation, WAL append/force, committed-page installation, publication epoch and transaction-status publication complete through the existing machinery. Late cancellation cannot turn an already committed transaction into a reported rollback. Synchronous commit remains enabled; no commit/fsync redesign was made.

Current V2 WAL contains transaction-framed page redo/images and commit/checkpoint records. F1 validates and analyzes it in one forward scan, replays committed ranges in commit order, and forces each touched data file once after its redo batch. F2 keeps the record encoding unchanged while sealing 64 MiB segments between transactions. Only the active segment may have a torn tail; corruption in an older segment fails recovery. Checkpoint deletes only fully retired sealed segments and never copies the retained suffix. Existing single-file V2 WAL remains readable. Committed data is installed/published only with its WAL durability authorization, and repeated recovery remains idempotent.

F3 uses one database-level page cache for committed heap and index reads plus WAL-authorized dirty images. Clean reads are sharded; sequential scans receive low-priority admission; dirty membership is tracked per file. The byte limit is `page_cache_bytes`. Private transaction overlays remain separate disposable state and the existing WAL-before-data/checkpoint rules are unchanged.

Legacy V1 uses file-image chunks and its original staging/recovery path. These are capability-specific formats; A1–A5 did not automatically migrate an old directory or change the durable format. The checksum remains the existing one. Dead-version reclamation (C1–C3) is horizon-safe and runs as an internal maintenance transaction through the ordinary private-page → page-image WAL → force → install → publication path (one `CHECKPOINT` statement or `reclaim_once` call per bounded pass); a crash around it leaves either the old or the fully reclaimed heap+index state. Status records are not frozen or reclaimed. The system has no VACUUM command, online backup, PITR or replication. Use the existing offline backup/migration/integrity tools with the server stopped.

## Status freezing and reclamation certification (0.1.9-C4/C5)

After the existing bounded C1–C3 reclamation pass, `CHECKPOINT`/`reclaim_once`
attempt one bounded freeze pass. `MvccDatabase::freeze_once(limit)` can continue
an idle multi-pass sweep without allocating maintenance transaction IDs. The
pass inspects at most `limit` heap pages and freezes at most 4,096 status IDs.
It certifies that **no surviving tuple creator/deleter refers below the proposed
exclusive ID boundary**, then checks every newly skipped status is terminal and
its commit sequence is at or below the reclamation horizon. It never assumes an
old transaction committed. No tuple normalization or persistent B1 hint change
is needed. All active transactions and pinned snapshots conservatively defer
freezing, including readers that could hold copied tuples. Admission is held
idle during each bounded proof/persistence step; any intervening ID allocation
restarts the heap reference sweep. An unchanged live tuple can hold the boundary
indefinitely. Busy databases may need an idle maintenance window for progress.

`phobos.mvcc-freeze` is a 128-byte, version-1 sidecar with two alternating 64-byte
CRC32C-protected slots (generation, boundary, frozen commit frontier, reservation
floor). The inactive slot is written and forced before publishing its boundary
in memory. A crash observes the previous or new valid slot; physical status
bytes are retained, so falling back never loses old statuses. Missing metadata
means boundary 1 for existing databases; status headers/record offsets, WAL
record types, A3 reservations and IDs are unchanged. Offline backup/restore and
integrity copies include the sidecar. Frozen history is not physically removed.

Startup validates/reconciles only the unfrozen status range, carrying forward
the frozen frontier; retained WAL parsing/redo is unchanged. Frozen-ID lookups
fail closed without record I/O: no live tuple may reference them, rather than
returning a guessed Committed/Aborted status. The B2 final-status and page caches
are cleared when advancing; the boundary is checked before cache lookup. B1
hint semantics and Read Committed visibility remain unchanged. Full admin check
still validates every surviving tuple/index relationship and fails on an invalid
frozen reference. Long-lived snapshots delay both reclaim and freeze progress.

## Commit path efficiency and independent batch results (0.1.9-D1/D2/D3)

**Lazy identities (D1).** `BEGIN` allocates nothing: no transaction ID, no
status record, no force. Statements of a transaction that has not written run
against the committed state exactly as before (Read Committed, own snapshot per
statement). The first write statement — INSERT/UPDATE/DELETE, DDL or a bulk
import — allocates exactly one stable ID, which every later statement of the
transaction reuses; `BEGIN; SELECT; COMMIT` and `BEGIN; SELECT; ROLLBACK`
consume no ID and touch the status store not at all. Autocommit writes still
receive one ID each. IDs stay monotonic and are never reused for anything
durable; A3 growth, the C4 freezing watermark (a read-only transaction cannot
reset a bounded sweep; a write's allocation still does) and the sidecar
formats are unchanged. A failed read-only transaction still requires ROLLBACK.

**One durability force per commit (D1).** The forced WAL COMMIT record (one
group force per batch) is the durability boundary of every commit. Status
records — reservation, commit, abort — are written through the page cache and
are no longer forced individually; the status header's reservation boundary is
forced only by checkpoint, freeze and recovery. Before D1 a write transaction
cost four forces (two for the reservation, one WAL group force, one for the
status install) and a read-only BEGIN/ROLLBACK three; now a write commit costs
the WAL force alone and a read-only transaction none. Durability is unchanged:
a commit is acknowledged only after its WAL force, the WAL COMMIT records are
retained until a checkpoint has first forced the status file (records, then
the boundary), and recovery reconciles statuses from the retained WAL before
redo, so an acknowledged commit whose status record was lost is reconstructed
as Committed. Records below the durable boundary are still validated strictly
(a zero or torn slot there refuses recovery); at or beyond it a lost or torn
record means a reservation that never became durable: it resolves as Aborted
when a durable WAL record names the ID, and otherwise the ID was never
observable and may be re-issued after the crash. The status-file format, WAL
record format and protocol are unchanged; existing databases open normally.

**Independent batch results (D2).** A commit batch returns one result per
member. A member that fails before anything of it is durable — a constraint or
validation error, an ownership/transaction conflict, cancellation before
admission, a clean I/O failure while preparing its private images — is rolled
back alone (private images undone, status Aborted, session idle) and the other
members of the batch continue and are published normally. Only failures whose
outcome is uncertain fence the database, as before: a WAL append or force
failure, a committed-page install failure after the WAL was forced, a status
publication or private-undo failure, a DDL preparation failure, or a worker
panic. A fenced member is never reported as rolled back after a durable
receipt; the A2 cancellation boundary (cancel before admission aborts, after
admission the true outcome is reported) is unchanged.

**Single-pass admission (D3).** A write statement builds one committed view of
its table (heap reader plus that table's index readers) for the whole
statement instead of two full database views per admitted change; after each
ownership acquisition the reader only drops its page-frame cache, so no page
cached before a wait can validate a row head or uniqueness afterwards, and the
per-change validation snapshot is still pinned after the waits. Table schema
and UNIQUE definitions are resolved once per statement. The A4 spilled-write
path is unchanged.

C5 covers ten modest UPDATE/DELETE/INSERT churn rounds, heap/index space reuse,
reopen/offline integrity, pinned-horizon preservation and post-release freezing.
This certifies the requested fixture, not permanent file-size bounds: heap slots
are still never reused, files do not shrink, and retained live references or
continuous activity can prevent status watermark progress. Phase C is complete;
D1–D3 are complete; D4 and later are not started.

## Compact page redo (0.2-D)

The WAL now logs most page changes as compact deltas against the page's
previous logged image (see `wal_v3_compact_redo.md`). Durability and the
acknowledgement point are unchanged: a COMMIT is acknowledged only after a
completed WAL force covers its commit record and its images were published in
commit order. Torn data pages remain repairable because the first change of
every page in each WAL segment is still logged as a full image, and WAL
retirement is segment-granular. Redo is idempotent: a page at or past a
record's LSN is skipped, and a delta is applied only to its exact base (LSN and
page checksum), so repeated or interrupted recovery converges to the same
bytes. A delta whose base is neither on disk nor repaired by a later full
image fails recovery closed. 0.2-D recovers 0.2-C WALs; 0.2-C refuses 0.2-D
WALs.

## Write-through durability (0.2-E)

In Mode E (default) the durability event of a commit batch is the completed
write-through write (Windows `FILE_FLAG_WRITE_THROUGH`, Linux `O_DSYNC`) of
its WAL byte range into an already preallocated, flushed segment; COMMIT is
still acknowledged only after that event and ordered publication. Mode A
(`--wal-mode flush`) keeps the 0.2-D `FlushFileBuffers`/`fdatasync` force.
See `wal_v3_windows_durable_wal.md` for the proof, the device (FUA)
assumption and the crash cases.
