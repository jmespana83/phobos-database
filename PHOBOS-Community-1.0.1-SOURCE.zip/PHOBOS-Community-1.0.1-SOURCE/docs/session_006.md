# Session 006 — Phase 5 multi-client concurrency candidate

## Objective

Establish correct multi-client session ownership and isolation without weakening Phase 3 durability or Phase 4 index correctness.

## Implementation

- persistent TCP sessions;
- thread-per-connection server baseline;
- shared database coordinator;
- coarse strict two-phase locking transaction owner;
- bounded lock waits;
- rollback on disconnect;
- simultaneous writer serialization;
- persistent Rust client `Client` API;
- CLI `session` command for multi-statement transactions on one connection.

## Isolation decision

Phase 5 intentionally uses a coarse strict-2PL correctness baseline. It prevents dirty reads and lost concurrent autocommit writes, but explicit transactions block other sessions. MVCC remains the long-term architecture.

## Gate

Run formatting, strict Clippy, workspace tests, rustdoc, then perform two-client manual contention/disconnect tests. Do not call Phase 5 complete until those pass.
