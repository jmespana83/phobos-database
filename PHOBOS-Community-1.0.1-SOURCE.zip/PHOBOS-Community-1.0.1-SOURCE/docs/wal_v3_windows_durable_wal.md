# PHOBOS 0.2-E — Windows Durable WAL: design and proof

Baseline: PHOBOS 0.2-D Compact WAL (`PHOBOS-Community-0.2-D-CompactWAL-SOURCE.zip`,
SHA-256 `6e8dfa0837ca9146ae3dd923d67a14219663033cd6e6bdffa783bb9552a02900`).
Written before implementation (Phase 1) and updated only where the
implementation made a decision explicit.

## 1. What 0.2-D does today (code facts)

* One active file `phobos.wal` plus sealed `phobos.wal.<lsn16>.seg` files.
  The active file is opened with `OpenOptions::read+write` (no flags) and grows
  by appends; its physical EOF is the logical end of the log.
* **Stage A** (commit-order lock held) encodes records into `write_buffer` and
  calls `flush_buffer()` = `seek` + `write_all` into the OS cache **twice per
  autocommit**: once after `BEGIN`+`MvccIdentity` (`begin_mvcc`) and once after
  `COMMIT` (`append_commit`). The Windows profile shows exactly this: 20,036
  write calls for 10,018 commits.
* **Force**: the single-flight leader (`force_through`) takes `begin_force()`
  (length check + `try_clone` of the handle) under the WAL mutex, calls
  `File::sync_data()` with no engine lock, then `complete_force()` advances
  `durable_lsn`; `receipts_for()` issues receipts only for commits at or below
  it; Stage B publishes in order and only then is COMMIT acknowledged.
* Rust's `File::sync_data()` on Windows is `FlushFileBuffers(handle)` (std
  implements both `sync_all` and `sync_data` with it); on Linux it is
  `fdatasync(2)`.

## 2. Windows semantics (Part A answers)

1. **`sync_data` → `FlushFileBuffers`.** Same call as `sync_all`.
2. **WAL open**: `CreateFileW` with `GENERIC_READ|GENERIC_WRITE`, share
   `READ|WRITE|DELETE` (std default), no `FILE_FLAG_*`.
3. **`FlushFileBuffers`** writes the file's dirty cached data, commits the NTFS
   metadata changes of the file (an append changes file size and valid data
   length, i.e. an NTFS log transaction), and then sends a *flush cache*
   request to the device (`IRP_MJ_FLUSH_BUFFERS` → NVMe `Flush` / ATA
   `FLUSH CACHE`). The device flush drains the drive's *entire* volatile write
   cache, not just this file's sectors. On the Ryzen probe: append+flush
   2,061 µs, preallocated+flush 1,143 µs → roughly 0.9 ms is the size/metadata
   commit and ~1.1 ms the device-wide flush.
4. **`FILE_FLAG_WRITE_THROUGH`** (Microsoft, *File Caching*): "data is still
   written into the cache, but the cache manager writes the data immediately
   to disk rather than incurring a delay by using the lazy writer", and "file
   system metadata is always cached ... to store any metadata changes to disk,
   the file must either be flushed or be opened with FILE_FLAG_WRITE_THROUGH".
   The storage stack issues these writes with *Force Unit Access* (FUA).
5. **Is completion of a write-through write a durability point?** SQL Server
   relies on exactly this for its log ("`FILE_FLAG_WRITE_THROUGH` makes sure
   that when a write operation returns a successful completion, the data is
   correctly stored in stable storage", *SQL Server logging and data storage
   algorithms*), and PostgreSQL's default Windows `wal_sync_method` is
   `open_datasync`, i.e. write-through on pre-zeroed segments. The guarantee
   is FUA: the device must place the written sectors on non-volatile media
   before completing the command. NVMe requires this for a FUA write (NVM
   command set); SATA depends on the drive/driver supporting FUA. **Assumption
   made explicit:** on a device that ignores FUA but honours FLUSH, Mode A is
   stronger. PostgreSQL documents the same caveat for `open_datasync` on
   Windows. Mode A therefore stays available (`PHOBOS_WAL_MODE=flush`).
6. **Metadata still needing an explicit flush:** file creation, size change
   (extension), rename, delete. None of them happens on the commit path once
   the region being written is preallocated, zero-filled and flushed.
7. **File extension**: an extending write changes size and valid data length;
   with write-through NTFS must commit that metadata too (Ryzen probe: append
   + write-through 155 µs vs preallocated + write-through 90 µs).
8. **Rename** (`MoveFileExW` without `MOVEFILE_WRITE_THROUGH`) is an NTFS log
   transaction committed lazily; it becomes durable when the log is flushed,
   e.g. by `FlushFileBuffers` on a handle of the renamed file. NTFS log
   records are applied in order, so a later flush also commits earlier renames.
9. **Segment creation** = create + size change: needs `FlushFileBuffers` before
   any record in it may be acknowledged.
10. **Directory durability**: Windows has no directory fsync; directory entries
    are NTFS metadata covered by the same log, made durable by the file flush
    above (0.2-C/0.2-D already rely on this for checkpoint replacement).
    On Linux the directory is `fsync`ed as before.
11. **NTFS size metadata vs appends**: each append moves EOF and valid data
    length; `FlushFileBuffers` must commit that, a write-through append must
    too. Writing *inside* an already-written region changes neither.
12. **What pre-sizing eliminates**: the per-commit size/VDL metadata commit.
    Combined with write-through it also removes the device-wide cache flush:
    only the written sectors are forced (FUA).

`FILE_FLAG_NO_BUFFERING` (sector-aligned I/O) and `SetFileValidData` (exposes
old disk contents, needs a privilege) are **not used**.

## 3. Durability modes

| Mode | Name (`PHOBOS_WAL_MODE`) | Active file | Commit-path I/O | Durable event |
|---|---|---|---|---|
| A | `flush` | 0.2-D: grows by appends | Stage A: buffered `write` ×2 per txn; force: `sync_data` | `FlushFileBuffers` / `fdatasync` completed |
| E | `write-through` (default on Windows and Linux) | preallocated, zero-filled extents | Stage A: **no I/O**; force leader: one positional write per batch on a write-through handle | the write-through write completed |

Write-through handle: Windows `FILE_FLAG_WRITE_THROUGH` (`0x8000_0000`,
`std::os::windows::fs::OpenOptionsExt::custom_flags`, no new dependency).
Linux: `O_DSYNC`, whose completion is defined by POSIX as *synchronized I/O
data integrity completion* — exactly `fdatasync` of the written range. Other
platforms run Mode A.

## 4. On-disk format (0.2-E preallocated active segment)

* The anchor header carries a new flag bit `0x20` (`ANCHOR_PREALLOC`) next to
  the 0.2-D `0x10` (V3). 0.2-D's header check requires `flags & 0xe0 == 0`,
  so **0.2-D refuses a 0.2-E WAL with "unsupported V2 WAL flags" before
  reading or changing anything**. 0.2-E accepts both flags.
* A preallocated file is `[anchor][records…][zero bytes up to capacity]`.
  Capacity grows in **4 MiB extents**: each extent is written with zeros and
  the file is flushed (`sync_all`) *before* any record is written into it.
  The writer never writes a record beyond the durable capacity.
* Records are unchanged (0.2-D V3 records, CRC32C, compact deltas, images).
* Why extents instead of 64 MiB up front: 0.2-D rotates the active segment on
  every checkpoint that covers the complete prefix, not only when 64 MiB are
  full; zero-filling 64 MiB per rotation would add a 64 MiB write and stall to
  every such checkpoint. 4 MiB is written and flushed once per 4 MiB of WAL
  (≈ 7,000 autocommits at 600 B), never per commit. The 64 MiB rotation
  threshold is unchanged.

## 5. Logical end of log and the zero-tail rule

Let `E` be the end of the longest prefix of complete, CRC-valid, LSN-contiguous
records (the existing scanner). For a preallocated segment:

* `E` stops at the first record that cannot be decoded (zero header, bad
  magic/length, short, CRC mismatch). A record that *decodes* but violates LSN
  contiguity, chains or anchors is still a hard error, as in 0.2-D.
* **Clean**: every byte in `[E, EOF)` is zero.
* **Torn tail** (active segment only): non-zero bytes exist after `E`, but all
  of them lie below `E + TORN_WINDOW`, `TORN_WINDOW = PIECE + MAX_RECORD`
  = 256 KiB + 64 KiB.
* **Corruption → hard error**: any non-zero byte at or beyond
  `E + TORN_WINDOW`, or any non-zero byte after `E` in a sealed segment.

Proof sketch. (i) Zero-fill means no byte after the last write was ever
non-zero: there is no stale data to mistake for WAL. (ii) The writer issues
physical writes strictly in file order, in pieces of at most `PIECE` bytes,
and a piece starts only after the previous one completed; with write-through
a completed piece is durable. So at a crash at most one piece `[S, S+PIECE)`
is indeterminate, every byte before `S` is durable, and every byte after
`S+PIECE` is still zero. (iii) Records end before or straddle `S`; a record is
at most `MAX_RECORD` long, so `E ≥ S − MAX_RECORD`. Hence every non-zero byte
after `E` is `< S + PIECE ≤ E + TORN_WINDOW`. (iv) Bytes after the first
undecodable record are never replayed, so a torn piece cannot make a later
record visible without its predecessors (prefix property). (v) Conversely,
corruption inside the committed prefix stops `E` early while later
committed bytes remain non-zero; if they reach past the window the scan fails
closed. The residual ambiguity — damage inside the last 320 KiB that looks
like a torn final write — is the same class 0.2-D accepts for its final record
(checksum failure at EOF is treated as torn) and is documented, not hidden.
A second writer (in-lock durable advance, §6) rewrites the in-flight range
with *identical* bytes before its own pieces, so it never adds a second
indeterminate region with different content.

## 6. Commit pipeline in Mode E

```
Stage A (commit order + WAL mutex, per append):  encode records into write_buffer
                                                 (no syscalls)
force leader (single flight, WAL mutex briefly): begin_force: ensure capacity
                                                 (extent, rare), move buffer into an
                                                 Arc'd in-flight range [D, D+n), target LSN
force leader (no engine lock, no WAL mutex):     positional write-through write of the range
                                                 in ≤256 KiB pieces  ← the durable event
force leader (WAL mutex briefly):                complete_force: D += n, durable_lsn = target
Stage B:                                         receipts_for (≤ durable_lsn), ordered publish, ACK
```

Invariants (all enforced in `Wal`, not by callers):

* **Single in-flight range**: `begin_force` refuses while one is outstanding;
  the range always starts at the durable offset `D`, so ranges never overlap
  and never leave gaps.
* **No out-of-order durability**: `durable_lsn` only advances in
  `complete_force` (to the range's target, all of whose bytes are in the
  range or before `D`) or after an in-lock durable advance that wrote *every*
  byte from `D`.
* **In-lock durable advance** (rare: >1 MiB single batch, synchronous
  `commit()`, rotation/checkpoint preparation, certification hooks): writes
  `[D, written)` — including the in-flight range's identical bytes — and then
  sets `D`/`durable_lsn`; a later `complete_force` of the old range is a no-op
  for `D`.
* **Rotation/checkpoint never race a write**: both already require no pending
  commit (an in-flight range always belongs to a pending commit); they also
  refuse while a range is in flight.
* **Failures**: a short write is continued (`write_all_at` loop); a failed or
  zero-length write, `ENOSPC` during extension, or any error fences the writer
  (`fenced = true`) before any receipt; every pending commit fails and the
  database requires recovery, exactly as a failed `FlushFileBuffers` in 0.2-D.
  A partially written range is a torn tail (§5).
* **Acknowledgement contract**: a COMMIT reply is sent only after Stage B
  publication, which requires a receipt, which requires `durable_lsn ≥` the
  commit record LSN, which requires a completed write-through write of every
  byte up to that record. Unchanged from 0.2-D except the durable event.

Process-crash visibility changes: in 0.2-D a complete COMMIT record reached the
OS cache in Stage A, so a *process* crash before the force could still recover
it. In Mode E it may be lost. Such a commit was never acknowledged; the
certification tools already classify this point as ambiguous
(`v2_after_commit_record` → either outcome).

## 7. Segment lifecycle and crash cases

* **New active file** (create, rotation, checkpoint rewrite, recovery rewrite)
  is built under the temporary name `phobos.wal.v2-checkpoint.tmp`: anchor +
  first zero extent, `sync_all`, then renamed into place, reopened with the
  write-through flag, `sync_all` (Windows: commits the rename in the NTFS log;
  Linux: plus directory `fsync`). Recovery deletes a leftover temporary.
* **Rotation**: durable advance of everything buffered → build temporary →
  rename active → sealed → rename temporary → active → flush. A crash between
  the renames leaves no active file: 0.2-D's interrupted-rotation repair
  renames the newest sealed segment back. The active file therefore always
  begins with a complete anchor. An active file containing only zero bytes
  (it never received an anchor) is treated the same way: it holds no record.

| Crash during / after | State on disk | Recovery |
|---|---|---|
| preallocating a new file | only the temporary exists (partial zeros) | temporary deleted; old active intact |
| after prealloc, before rename | complete temporary + old active | temporary deleted |
| between rotation renames | sealed segments, no active | newest sealed becomes active (0.2-D repair) |
| after rotation, before first record | active = anchor + zeros | clean, zero tail |
| during first transaction write | anchor + torn piece + zeros | torn tail, transaction absent (never acked) |
| extending (zero-fill) | zeros past old capacity, any length | zero tail |
| checkpoint rewrite | old WAL or new anchor file | as 0.2-D |

## 8. Compatibility

* **0.2-D → 0.2-E**: 0.2-E reads 0.2-D (non-preallocated) WAL with the old
  EOF rules and recovers it; on writer open it rewrites the anchor into the
  configured mode's format (as 0.2-D did for V3).
* **0.2-E → 0.2-D**: refused (flag `0x20`), no file touched. Switching a 0.2-E
  database to Mode A (`PHOBOS_WAL_MODE=flush`) rewrites a non-preallocated
  anchor at open; a cleanly shut down database is then readable by 0.2-D's
  flags check only if it was last opened in Mode A — documented, not relied on.

## 9. Stop gate

The synchronous durability contract is preserved: the acknowledgement point is
still "a completed OS durability operation covering the commit record". The
only change is *which* operation (write-through/FUA write of the commit's bytes
into an already-durable-sized file instead of a whole-file + device flush),
with the device-level assumption stated in §2.5. Linux mapping (O_DSYNC) is
exactly equivalent by POSIX definition.
