# 0.2-I.1 — Overflow safety hotfix

0.2-I.1 is 0.2-I plus one correctness fix and the tooling to find and repair
databases that the defect has already damaged. It changes no format and no
performance-relevant code path.

## Defect (0.2-I)

`HeapTable::insert_encoded` chose a page for an ordinary heap tuple from the
free-space map. On open, only page 0 and the last page are inspected; every
interior page is *unknown*. When an insert probed an unknown page, the code
computed the overflow-aware value

```text
actual = if page.is_overflow() { 0 } else { page.free_space() }
```

and recorded it in the map, but **accepted the page by its raw
`page.free_space()`**. This happened in both the in-place branch (`modify_page`)
and the copy branch. An overflow page with a short last chunk, or a released
chunk, has most of its 8 KiB free, so after any restart ordinary tuples could
be stored on it.

Consequences on 0.2-I (reproduced end to end):

* **Live chain (wide row present).** The last chunk page gets `slot_count > 1`.
  * Reading the wide row, any scan that decodes it, and `CHECKPOINT` fail with
    `overflow page kind is invalid`.
  * `phobos-admin check` fails. Restarts do not repair it.
* **Released chain (wide row deleted and reclaimed).** Scans and `COUNT(*)`
  skip overflow pages, so the misplaced committed rows **silently disappear**
  from counts and scans. Point lookups of those rows fail with
  `RecordId references an overflow page`.

## Invariant

**An overflow page may never store an ordinary heap tuple.** A valid overflow
page has exactly one slot, slot 0. That slot holds either a `PHOV` chunk record
or a tombstone (a released chunk).

## Fix

* `SlottedPage::ordinary_free_space()` returns 0 for overflow pages. Every
  ordinary-tuple acceptance test uses it:
  * both `insert_encoded` branches;
  * the bulk path `insert_version_batch`, which also never reuses an overflow
    tail page;
  * the free-space value published by `reclaim_versions`.
* `insert_ordinary` / `insert_ordinary_unsealed` are the only insertion
  primitives used for ordinary tuples. They refuse an overflow page with an
  `InvalidPage` error (fail-safe: the statement fails, and the page is never
  corrupted, even if bookkeeping were wrong). Overflow chunk records are still
  written only by `write_overflow` through `insert`.

## Detection

`phobos-admin check` (MVCC databases) audits every heap page before decoding
tuples (`phobos_storage::overflow_safety::scan_overflow_violations`). It is
read-only. It reports:

* table name and id, and heap file;
* number of damaged pages;
* for each damaged page: page id, kind, slot count, slot-0 state and the slots
  holding ordinary tuples.

## Repair

```text
phobos-admin repair-overflow DATA_DIR EMPTY_BACKUP_DIR [--dry-run]
```

Repair is offline only and refuses to run:

* while the data-directory lock is held, i.e. while a server is running;
* while the WAL still holds anything to redo. A clean shutdown leaves
  `committed=0`, `incomplete=0` and a clean tail.

Before any change it copies every database file that `phobos-admin` recognises
to the empty backup directory and forces them to disk.

**No ordinary tuple is moved,** so RecordIds, index entries, UNIQUE
references and `previous` version pointers stay valid. For each damaged page:

1. If slot 0 holds a live chunk, the chunk record is copied byte-for-byte to a
   new overflow page appended to the heap, stamped with the damaged page's LSN.
   Its single reference is redirected to the new page:
   * normally the previous chunk's `next` field;
   * for a first chunk, the overflow row envelope's `first_page`.
2. The damaged page becomes an ordinary heap page:
   * slot 0 is tombstoned (it was never a RecordId target);
   * the overflow flag is cleared and the reclaim-candidate flag is set;
   * the page is compacted.

The tool refuses rather than guesses when:

* a live chunk has no reference, or more than one;
* slot 0 is not a chunk;
* a slot holds an unrecognised record.

Before writing, it verifies that every page validates, that no violation
remains and that every overflow chain walks cleanly. Each heap file is then
replaced atomically: a temporary file is written and forced, re-read and
re-audited (streaming), then renamed over the heap file, and the directory is
forced on POSIX. On Windows the standard library cannot force a directory, so
rename durability relies on the file system and is not verified.

Afterwards the full integrity check runs. On any failure after the backup,
every planned heap file is restored atomically from the backup (temporary
copy, force, rename). The error reports both the cause and the restore result;
if the restore fails too, it says to restore every file from the backup
directory before starting PHOBOS.

The read-only audit in `check` streams one page at a time. The repair plan
holds one table's heap in memory.

The repair writes data files directly; it is not WAL-logged. After a repair,
take a new base backup and re-initialise any physical standby. Older backups
and WAL archives would restore the damaged state, and post-repair WAL deltas do
not apply to unrepaired base pages (they fail closed).

## Compatibility

* **Unchanged:** page, tuple-envelope, RID, index, WAL, catalog, status-file,
  protocol, replication and PITR formats.
* **Migration:** none. Healthy 0.2-I databases open unchanged.
* **Repaired pages:** byte-valid 0.2-I pages, readable by 0.2-I.
