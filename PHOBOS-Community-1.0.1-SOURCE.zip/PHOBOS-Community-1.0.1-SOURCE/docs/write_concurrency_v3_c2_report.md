# Write & Concurrency V3 — C2 acceptance report

C2 is independently runnable and frozen after the final Fast gate and measurement review. C3 has not started. C1 remains immutable in outputs/write-v3/c1. The source is an isolated C1 extraction; WAL/heap/index format capabilities and durability settings are unchanged.

## Result and scope

C2 provides actual concurrent preparation for 2–8 disjoint table/index domains within an admitted group. It separates preparation from ordered WAL binding/force, and replaces the long-held server database mutex with short ownership transfers. It does not provide same-table parallel execution or MVCC reads. Same-table DML, explicit transactions, legacy formats, and databases with persisted statistics retain C1 execution. Ordered publication and checkpoint drain remain synchronous.

Performance gains are workload-specific. The independent-table controls exercise the new path; the original shared-table and matched TCP workloads retain necessary C1 ordering. Regressions and target misses below are retained, not averaged away or presented as general write-latency improvement.

## Final validation

- cargo fmt --all and cargo fmt --all -- --check: PASS.
- cargo clippy --workspace --all-targets --all-features -- -D warnings: PASS; no new allow attributes.
- cargo test --workspace: 144 passed, 0 failed, 3 pre-existing ignored long-soak tests. No failing tests were removed or disabled.
- cargo doc --workspace --no-deps and normal/profile release builds: PASS.
- Final Fast gate: 46 targeted campaign crash/recovery cycles: 20 unchanged C1 group cycles, 20 C2 cycles, six benchmark recovery cases. Existing regression subprocess tests and pre-freeze development reruns are additional, not included in 46.
- 100K and 1M embedded suites: 49 raw records each. Matched Phobos-only TCP suites: 43 successful records each, followed by offline integrity checks.
- 24 paired normal/profile writer controls: two layouts × two cardinalities × three client counts × two engine versions. Three samples, 32 transactions per client per sample; every acknowledged inserted payload is checked after two reopens.
- No PostgreSQL connection, 10M run, long soak, durability relaxation or on-disk migration was performed.

Focused tests prove concurrent disjoint preparation, WAL force while another domain is still preparing, unchanged base pages before force, ordered dependent updates/deletes, unique-collision rollback, WAL-budget/index-split/checkpoint boundaries, repair after heap-before-index installation failure, paused-force queue saturation/disconnect/DDL barriers, bounded shutdown admission waits, stale-admission rechecking, correct wakeup of heterogeneous waiters, and error completion/fencing after a durable execution panic. Process-crash tests do not claim hardware power-loss certification.

## Matched TCP results

Median milliseconds across three samples. Autocommit and explicit-transaction values are total time for exactly three INSERTs; four-client values cover 12 autocommits. These are the original matched SQL workloads, not the partitioned diagnostic. The before column is frozen C1; fresh paired coordinator controls follow.

| Rows | Workload | C1 ms | C2 ms | Change |
| --- | --- | ---: | ---: | ---: |
| 100,000 | 3 autocommit inserts | 12.9705 | 12.1809 | -6.1% |
| 100,000 | 3 inserts in one explicit transaction | 5.4437 | 4.8323 | -11.2% |
| 100,000 | 4 clients × 3 inserts | 56.3086 | 51.4683 | -8.6% |
| 1,000,000 | 3 autocommit inserts | 13.5023 | 12.8704 | -4.7% |
| 1,000,000 | 3 inserts in one explicit transaction | 5.0912 | 5.3000 | +4.1% |
| 1,000,000 | 4 clients × 3 inserts | 50.1651 | 71.4479 | +42.4% |

## Shared-table steady writers

Normal release medians in transactions/sec. p95/p99 are pooled per-transaction milliseconds across the three samples. Each engine copies the same fixture; setup, initial force and validation are untimed. This is the original shared-table steady diagnostic, separate from the 12-transaction TCP comparison.

| Rows | Clients | C1 tx/s | C2 tx/s | Change | C1 p95 / p99 ms | C2 p95 / p99 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 100,000 | 1 | 109.80 | 91.46 | -16.7% | 8.83 / 59.06 | 14.66 / 62.18 |
| 100,000 | 4 | 233.99 | 171.54 | -26.7% | 28.59 / 73.47 | 41.38 / 80.73 |
| 100,000 | 8 | 174.87 | 201.03 | +15.0% | 93.08 / 111.72 | 53.96 / 93.08 |
| 1,000,000 | 1 | 95.62 | 89.77 | -6.1% | 23.64 / 65.82 | 40.57 / 94.10 |
| 1,000,000 | 4 | 174.91 | 157.16 | -10.1% | 37.73 / 72.93 | 70.93 / 118.56 |
| 1,000,000 | 8 | 225.26 | 163.21 | -27.5% | 99.50 / 139.42 | 80.00 / 122.55 |

## Independent-table steady writers

Normal release medians in transactions/sec. p95/p99 are pooled per-transaction milliseconds across the three samples. Each engine copies the same fixture; setup, initial force and validation are untimed. The cardinality is total rows evenly partitioned across one table per client. This is a separate diagnostic and must not be compared directly with the saved PostgreSQL shared-table target.

| Rows | Clients | C1 tx/s | C2 tx/s | Change | C1 p95 / p99 ms | C2 p95 / p99 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 100,000 | 1 | 194.94 | 187.63 | -3.8% | 6.33 / 6.80 | 7.29 / 9.18 |
| 100,000 | 4 | 139.86 | 155.34 | +11.1% | 40.28 / 89.08 | 51.15 / 91.97 |
| 100,000 | 8 | 76.43 | 313.43 | +310.1% | 151.02 / 174.41 | 61.07 / 88.86 |
| 1,000,000 | 1 | 150.64 | 149.57 | -0.7% | 8.96 / 11.19 | 11.64 / 34.43 |
| 1,000,000 | 4 | 77.52 | 145.62 | +87.8% | 87.64 / 128.66 | 68.06 / 116.27 |
| 1,000,000 | 8 | 72.90 | 310.56 | +326.0% | 229.93 / 538.75 | 62.96 / 97.66 |

## Queueing and WAL force amortization

The following counters come from separate profiling builds, not the normal timing runs. Values aggregate all three samples. Commit-force counts exclude additional checkpoint/anchor forces; all-WAL-force counts include them.

| Layout / rows / clients | C1 queue ms/tx | C2 queue ms/tx | C1 tx/commit force | C2 tx/commit force | C1 all forces / tx per force | C2 all forces / tx per force |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| shared / 100,000 / 1 | 0.001 | 0.002 | 1.000 | 1.000 | 96 / 1.000 | 96 / 1.000 |
| shared / 100,000 / 4 | 8.914 | 8.482 | 2.000 | 2.000 | 204 / 1.882 | 204 / 1.882 |
| shared / 100,000 / 8 | 21.191 | 14.816 | 4.000 | 4.021 | 214 / 3.589 | 211 / 3.640 |
| shared / 1,000,000 / 1 | 0.001 | 0.001 | 1.000 | 1.000 | 96 / 1.000 | 96 / 1.000 |
| shared / 1,000,000 / 4 | 12.746 | 9.353 | 2.000 | 2.000 | 204 / 1.882 | 204 / 1.882 |
| shared / 1,000,000 / 8 | 24.828 | 19.346 | 4.000 | 4.021 | 212 / 3.623 | 215 / 3.572 |
| domains / 100,000 / 1 | 0.001 | 0.002 | 1.000 | 1.000 | 96 / 1.000 | 96 / 1.000 |
| domains / 100,000 / 4 | 16.820 | 9.961 | 2.000 | 2.010 | 204 / 1.882 | 203 / 1.892 |
| domains / 100,000 / 8 | 52.480 | 14.346 | 4.021 | 4.000 | 215 / 3.572 | 216 / 3.556 |
| domains / 1,000,000 / 1 | 0.001 | 0.001 | 1.000 | 1.000 | 96 / 1.000 | 96 / 1.000 |
| domains / 1,000,000 / 4 | 16.077 | 10.345 | 2.000 | 2.010 | 204 / 1.882 | 203 / 1.892 |
| domains / 1,000,000 / 8 | 41.257 | 11.512 | 4.063 | 4.000 | 213 / 3.606 | 216 / 3.556 |

## Synchronization profile at 1M / eight clients

Inclusive wall milliseconds per transaction, aggregated across profiling samples. Concurrent preparation spans overlap each other and the owner wait; these columns must not be added as an exclusive time breakdown. There is no dedicated WAL mutex in either implementation. Actual record-write/fsync spans and C2 exclusive writer-stage spans are reported instead of inventing a WAL-lock duration. C1 guard instrumentation covers batch execution under its database mutex; C2 also reports the retained logical ownership duration, so releasing the structural mutex is not presented as removing reader exclusion.

| Span (ms/tx) | Shared C1 | Shared C2 | Domains C1 | Domains C2 |
| --- | ---: | ---: | ---: | ---: |
| Database structural guard | 7.220039 | 0.000143 | 12.522033 | 0.000110 |
| Database logical ownership (new lease) | not on this path | 6.143478 | not on this path | 3.174420 |
| WAL record writes | 0.107442 | 0.106515 | 0.109338 | 0.094459 |
| All WAL force calls | 1.364384 | 0.925909 | 1.005559 | 0.294369 |
| C1 transaction setup | 1.728538 | 1.481921 | 4.732377 | 0.076028 |
| C1 prepare/redo stage | 0.444474 | 0.435645 | 0.540525 | 0.008414 |
| C1 force/publication/checkpoint stage | 3.869679 | 3.315564 | 6.322511 | 0.076754 |
| Concurrent domain preparation | not on this path | not on this path | not on this path | 2.408423 |
| Owner waiting for prepared domain | not on this path | not on this path | not on this path | 0.580121 |
| C2 WAL binding/append ownership | not on this path | not on this path | not on this path | 0.322316 |
| C2 force-stage ownership | not on this path | not on this path | not on this path | 0.253365 |
| C2 heap/index install and cleanup | not on this path | not on this path | not on this path | 1.575710 |

C2 continues to spend time under exclusive logical ownership, particularly during installation and the C1 fallback. The independent-table gain includes both concurrent preparation and avoiding setup/retirement of untouched tables’ scratch handles. No claim is made that concurrency alone explains the full improvement. Profiling can perturb scheduling; normal and profiling results remain separate. Three-sample controls are not a statistical guarantee for other machines or workloads.

## Preserved durability work

| Independent layout | Engine | Commits | Commit forces | WAL bytes | Installed pages |
| --- | --- | ---: | ---: | ---: | ---: |
| 100,000 / 8 clients | C1 | 768 | 191 | 12,744,912 | 1,536 |
| 100,000 / 8 clients | C2 | 768 | 192 | 12,744,912 | 1,536 |
| 1,000,000 / 8 clients | C1 | 768 | 189 | 12,744,912 | 1,536 |
| 1,000,000 / 8 clients | C2 | 768 | 192 | 12,744,912 | 1,536 |

C1’s group execution module is byte-for-byte preserved. Its force/ticket validation algorithm is unchanged; WAL additions are the next-ID accessor and diagnostic-only pause boundaries. The normal build enables neither profiling nor test hooks. Global request-order WAL chains and publication, unique/index dependencies, no dirty reads, durable-before-ACK, and post-durability fencing remain mandatory.

## Saved PostgreSQL target

The saved comparison CSV SHA256 remains 047e2ad0cb660845ddbe3f691817a0a4c49b9f2de2cfe1a1ff058234f54c889e. No PostgreSQL rerun was made. Its matched 1M totals are 0.7059 ms for three autocommits, 0.6788 ms for three inserts in one explicit transaction, and 2.2723 ms for four clients × three autocommits. C2 does not reach these targets or establish general same-table performance parity.

## Exact source changes

| File | Change |
| --- | --- |
| crates/phobos-execution/src/independent_prepare.rs | New bounded table-domain ownership, concurrent preparation, ordered WAL binding/publication and focused tests. |
| crates/phobos-execution/src/lib.rs | Register the module; make legacy TransactionManager optional only for private worker construction. Normal databases retain it. |
| crates/phobos-execution/src/private_transaction.rs | Reuse private setup with an externally assigned ID; ordinary begin still allocates/logs through WAL first. |
| crates/phobos-catalog/src/lib.rs | Clone metadata snapshots for disjoint DML workers. |
| crates/phobos-storage/src/page_io.rs | Bind an unlogged frozen pending generation to its WAL-stamped images; reject repeated binding. |
| crates/phobos-storage/src/lib.rs and crates/phobos-index/src/lib.rs | Forward the pending-redo binding operation through existing heap/index ownership. |
| crates/phobos-wal/src/v2/log.rs | Expose next transaction ID under exclusive ownership; add no-op-in-release synchronization diagnostics. |
| crates/phobos-server/src/lib.rs | Short database-slot mutex, admission release/recheck, notify-all handoff, owned batch execution, panic error completion, shutdown drain and focused regressions. |
| crates/phobos-server/Cargo.toml; crates/phobos-observability/Cargo.toml; crates/phobos-observability/src/lib.rs | Dev-only, directory-scoped force/admission pause hooks; no normal release state. |
| crates/phobos-bench/src/main.rs | Reusable partitioned fixture and steady domain workload; shared workload retained. |
| tools/write-v3-validation.ps1; tools/write-v3-c2-summary.py | Reproducible Fast gates, immutable C1 controls, both scales/layouts and telemetry summaries. |
| docs/write_concurrency_v3_c2_design.md; this report; plan/report status links | Document ownership, bounds, failure semantics, measurements and checkpoint state. |

The delivery changed-files.json and source-files.json are the authoritative per-file SHA256 lists. The evidence includes interrupted and failed attempts. In particular, the matched mixed test caught a real notify-one lost wakeup, fixed with notify-all plus deterministic admission-order tests. See validation-history.md in the evidence archive for all attempts; earlier passing unit gates were not treated as a freeze.

## Reproduction

Extract the C2 source and keep the frozen C1 source ZIP available. Use Rust 1.85 MSVC and the existing Python comparison virtual environment (with the repository’s comparison dependencies installed). From the extracted phobos directory:

```powershell
.\tools\write-v3-validation.ps1 -Checkpoint C2 `
  -OutputDirectory C:\phobos-benchmark\c2-new-evidence `
  -Python C:\path\to\comparison-venv\Scripts\python.exe `
  -C1SourceArchive C:\path\to\phobos-c1-source.zip
```

The output directory must be new. The C1 source hash is checked before building a disposable control copy. Only its measurement harness and a profiling guard span are added; no C1 engine behavior is retuned. The driver uses window zero for the steady controls. This run inherited no group-window override, so the original suite/TCP runs also used the documented zero default. The harness invokes the comparison tool with engine=phobos and removes PostgreSQL environment variables from that child. Fixtures and compiler targets are reproducible and excluded from the compact evidence ZIP; raw samples, logs, profiles, control source and hashes are included.

Final markers: PHOBOS WRITE V3 C2 FAST GATES PASSED and PHOBOS WRITE V3 C2 CHECKPOINT PASSED. C3 has not started.
