# C9 true bulk index build / merge

C9 replaces the per-entry index maintenance and per-row uniqueness probes of the
dedicated C7/C8 bulk import with a sort/merge/bulk-build algorithm. Ordinary
OLTP insertion, MVCC, WAL, group commit, checkpointing and publication are
unchanged; the import still commits through the existing C6 admission, private
page preparation, page-image WAL, force, installation and visibility publication.

## Where the old cost was (frozen C8, 1M rows)

- `Spool::append` (staging): for every row and every unique index, one
  `range_visit` against the committed index through the statement reader
  (re-opens the tree per call) plus a heap visibility lookup, then an
  `insert_batch` into a scratch unique B+ tree per 64-row chunk. Profiled as
  `bulk.unique_validate`: 166 s.
- `Spool::prepare` (commit): per 1,024-row batch, decode tuples, derive keys,
  and `insert_versions_batch` — the ordinary `insert_entry` path (descend, probe
  sibling chain, insert, split) under the C8 64-node cache over private pages.
  Profiled as `bulk.index_maintenance`: 155 s.

## New algorithm

1. **Collect** (staging, `Spool::append`): rows are type-checked, encoded and
   spooled exactly as before. For every index the key `(IndexKey, ordinal)` is
   appended to a bounded in-memory run buffer; full buffers are sorted by
   `(key, ordinal)` and written as checksummed run files under the import's
   scratch directory. No index is touched while staging.
2. **Sort** (COMMIT, before admission, `Spool::finalize`): runs of each index
   are k-way merged (cascading when there are more than 128 runs) into one
   sorted key file per index. Ordinal order equals heap RID order for bulk
   appends, so the output is in physical `(key, rid)` order.
3. **In-batch uniqueness**: for unique indexes the merge output is scanned once;
   two adjacent equal non-NULL keys are a constraint violation.
4. **Existing-index validation**: the sorted non-NULL unique keys are probed
   against the committed index in ascending order with an ordered cursor
   (`BPlusTree::probe_sorted`): the traversal stays on the current leaf, steps to
   the sibling leaf when the next key is adjacent, and re-descends only when the
   next key is beyond the sibling. Matching entries are resolved with the same
   committed-snapshot visibility check as before. Errors here abort the
   transaction cleanly (no permit exists yet); the committed index is untouched.
5. **Leaf build / merge** (post-admission, `Spool::prepare`): heap pages are
   filled as before and an ordinal→RID map (one entry per filled heap page) is
   kept. For each index a `BulkBuilder` streams the sorted key file and the
   existing committed leaf chain (read through the private overlay; empty index
   = one empty leaf) as two sorted inputs, merges them and packs leaves
   sequentially at a fixed fill target. Old page IDs (leaves once consumed,
   internal pages immediately) are reused first; new pages are appended
   contiguously through the existing private page overlay.
6. **Upper levels**: one open node per level; when a leaf/internal node closes,
   `(first key, page)` is pushed into the parent level, opening/allocating the
   parent on demand. Parent IDs are therefore known before a child is written.
   The last open node of the highest level becomes the root; metadata is written
   with the new root and page count. Old pages that the merged tree no longer
   needs are stamped with a `FREE` node kind (checksummed, identified) so the
   file remains fully accounted for by `validate`.
7. **Publication**: unchanged. Every changed page is a private page image that
   the existing `prepare_private_redo` logs (page LSN stamping), `stage_private`
   chains, group force makes durable and `install_pending` publishes under the
   index publication epoch. Rollback before admission drops the private overlay
   and scratch; the committed index was never modified.

Small merges are still handled by the same builder; the merge cost is
proportional to the existing leaf chain plus the batch (see limitations).

## Bounds

- Run buffer: 65,536 keys or 8 MiB estimated key bytes per index, then spilled.
- Merge: up to 128 open run readers (64 KiB buffers each), cascaded beyond that.
- Unique probe batches: 1,024 keys per consistent traversal window.
- RID map: one 16-byte entry per heap page filled by the import.
- Builder: one open node per tree level plus the current old leaf.

## Timings

The `profiling` feature records `bulk.key_generate`, `bulk.sort`,
`bulk.unique_check`, `bulk.existing_merge`, `bulk.leaf_build`,
`bulk.upper_build`, and the existing WAL/publication spans.

## F6 scratch roots and index workers

`bulk_scratch_directories` extends this same spool across configured filesystem
roots. Sorted runs are assigned round-robin, paths remain fixed for their
lifetime, and every directory uses a transaction-specific PHOBOS child. The
aggregate limit is `bulk_scratch_quota_bytes` times the number of roots; exact
existing byte accounting and the final physical measurement remain authoritative.
All owned children are removed on success, rollback, cancellation or drop.

After the heap RID map is complete, independent indexes are removed from the
private database map and passed to at most `bulk_index_build_workers` scoped
workers. Each worker runs the unchanged `BulkBuilder`; completed trees return to
the map before publication. Heap construction, WAL preparation, force and final
publication remain ordered exactly as before. A one-index table remains
effectively sequential.
