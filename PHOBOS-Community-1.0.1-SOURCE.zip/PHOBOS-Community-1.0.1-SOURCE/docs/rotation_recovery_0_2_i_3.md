# 0.2-I.3: Interrupted WAL rotation recovery

## Defect (0.2-I … 0.2-I.2)

`Wal::rotate_segment` works in three steps:

1. Build the new active file under `phobos.wal.v2-checkpoint.tmp`.
2. `rename(phobos.wal → phobos.wal.<first LSN>.seg)`.
3. `rename(tmp → phobos.wal)`.

A crash between steps 2 and 3 leaves sealed V2 history and no `phobos.wal`. WAL recovery already repairs this layout (`repair_interrupted_rotation`). However, every open path first decided the storage format from `phobos.wal` alone and never reached that repair:

* **MVCC database.** `MvccDatabase::is_capable` returned `false`, so `Coordinator::open` fell back to the legacy engine, which failed with `Unsupported: heap tuple capability mismatch`. No file was changed.
* **Page-LSN (non-MVCC V2) database.** `Database::open` took the legacy **V1** WAL path. It **created** an empty V1 `phobos.wal` and `phobos.wal.gen` beside the V2 history and opened the V1 copy engine, which the server then refused. Embedded callers could write through that V1 engine, past un-replayed V2 commits.
* **`phobos-admin check`** (`is_versioned`) and the migration preflight (`preflight_wal`) treated the directory as V1 or as having no WAL.

## Fix: detection routes to recovery; recovery performs the repair

`phobos_wal::v2::interrupted_rotation(dir)` is true when both hold:

* a regular file named `phobos.wal.<16 hex>.seg` exists in the directory;
* `phobos.wal` is either absent, or not a V1-headed file and not yet a complete V2 anchor. The second test is the one `scan::segments` already applies.

The helper reads names and the active file's header only. Each open path then treats such a directory as "V2 WAL present":

| Path | Change |
|---|---|
| `MvccDatabase::is_capable` | `inspect` (segment-aware, validates every sealed segment) decides `page_format == 4`; any error fails the open |
| `Database::open_internal` | V2 path, never the V1 path |
| `open_v2_config` (page-LSN engine) | `WalV2::recover` (repair) instead of `create_with_page_lsn`; the MVCC guard applies |
| `phobos-admin check` (`is_versioned`) | MVCC check on a recovered scratch copy (the source is untouched) |
| `preflight_wal` | V2, never "no WAL = V1" |

The repair itself is unchanged and stays in WAL recovery (`repair_interrupted_rotation`): it is reached through `StatusFile::recover_database` (MVCC) or `WalV2::recover` (page-LSN).

## What still fails closed

The open is refused, with no file created or changed, in these cases:

* **Damaged or truncated sealed history:** `inspect` errors.
* **A `phobos.wal.<16 hex>.seg` name holding junk:** the same `inspect` error.
* **An empty or torn (shorter than a header) `phobos.wal` next to `phobos.wal.gen`.** Two different events leave this shape:
  * an older binary misrouted an interrupted page-LSN rotation through the V1 path, and V1 writes may have followed;
  * a pre-0.2-E binary crashed while creating the new active file.

  The error message gives the operator step: remove the empty `phobos.wal` (and `phobos.wal.gen` if the database never used the V1 WAL), then reopen.
* **A missing `phobos.wal` with no sealed segments.** Nothing exists to recover from, and the behaviour is unchanged.

## Unchanged

* Recognisable V1 legacy databases (V1 header, or no WAL and no sealed segments) still select the V1 path.
* Normal databases with an active `phobos.wal`.
* The 0.2-I.2 retained history: the subdirectory is not scanned.
* All formats. No migration.
