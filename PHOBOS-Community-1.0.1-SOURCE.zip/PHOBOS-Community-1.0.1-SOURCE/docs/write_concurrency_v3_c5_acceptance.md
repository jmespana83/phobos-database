# C5 acceptance campaign

C5 is frozen as a qualified Read Committed foundation checkpoint after full Fast
acceptance. Correctness, recovery, visibility and measurement execution passed.
There are 18 documented performance-budget exceptions; performance parity and beta
certification are not claimed. C6 has not started. The historical runtime report
remains the record of the previously approved source archive.

## Changes since the approved runtime increment

- Capability-4 CREATE TABLE, CREATE/DROP INDEX and ANALYZE now use a session-owned
  catalog/statistics image and the existing mapped WAL metadata/create/delete
  records. Explicit transactions can combine schema and row changes, see their
  own changes and roll back both. Schema changes acquire an exclusive schema
  lease only when no other active transaction or statement pin exists; otherwise
  they fail with a retryable transaction-state error. This conservative DDL rule
  does not extend to ordinary DML. Index construction validates visible unique
  keys and then retains entries for every physical version at publication.
- Publication forces required metadata and page state before releasing schema
  ownership. Failure after durability fences the database and recovery replays
  the same WAL mapping. Three added process-crash cases cover durable WAL before
  visibility, metadata installation and visibility publication, including a
  dropped index, newly created table/index, rows and ANALYZE. Each reopens twice
  and passes offline integrity. No on-disk version or stable identity encoding
  changed; existing capability-4 gating and backup-first migration remain.
- Sequential/indexed joins, grouping and paused streams now have explicit normal
  SQL coordinator acceptance. A stream keeps its statement snapshot while a
  writer publishes; subsequent statements observe the new frontier.
- DML candidate collection and resolved writes enforce the configured logical
  byte budget before growth, including bounded index visitors. This bounds each
  transient candidate/change set, not exact allocator overhead or total process
  memory. ANALYZE retains the existing implementation and is not a VACUUM path.
- After recovery obtains the exclusive directory lock, startup removes validated
  abandoned private/schema scratch and catalog-unreferenced exact heap/index
  filenames. Recursive cleanup rejects links/reparse points and paths outside
  the canonical database directory. Unrelated names remain untouched.

## Defects found by acceptance measurements

The initial 100K shared-row writer campaign found `index references missing tuple`.
Statement index batches can observe a later committed index entry, but the heap
reader had captured an earlier file length and could also retain a page without
that entry's new slot. Direct tuple reads now obtain current committed bytes from
the committed-reader lease and validate page identity/checksum. Tuple visibility
still uses the original statement snapshot; sequential scans retain their captured
traversal bound. Missing physical references still fail closed. The regression
holds an old statement across 130 publications and checks bounded DML resolution
after every publication, crossing both new slots and new pages.

A separate instrumented 100K diagnostic found 3.04 seconds of status-file lookups
in a 3.29-second three-scan workload. A statement now caches at most 1,024 terminal
statuses. Stable IDs are never reused and final statuses cannot change. Active
statuses, including own writes, are never cached. Every hit checks session and
status-store fencing; unknown IDs and corruption remain errors. Cache eviction
only causes another durable lookup; it cannot relax visibility. The cache dies
with the RAII statement pin. A focused test checks active-to-abort transitions,
unknown IDs and cached lookups after a durable-commit fencing failure.

## Reproduction and scope

From the C5 repository, with Rust 1.85 MSVC and the saved C4 Fast fixtures:

```powershell
.\tools\write-v3-c5-fast.ps1 `
  -OutputDirectory <new-evidence-directory> `
  -Python <python-executable> `
  -Fixtures <path-to-c4-fast-02>
```

The script runs formatting, strict all-target/all-feature Clippy, workspace tests,
docs, release/profile builds and `write-v3-c5-measure.py`. An optional
`-CorrectnessDirectory` reuses a passing gate only when every engine hash matches.
The focused runtime crash campaign remains 24 cases, plus the three schema cases;
inherited component/C1–C4 regression tests remain enabled. The three pre-existing
long-soak tests remain ignored. No PostgreSQL, 10M or long soak is invoked.

Both 100K and 1M use three fresh processes per normal route and three separate
instrumented MVCC processes. Every process gets an owned, forced fixture copy.
Migration is explicit, backup-first and excluded from timing; frozen input hashes
are checked. Legacy and MVCC order alternates. The legacy control is the current
executable's preserved C1–C4 route on equivalent data, not a rerun of PostgreSQL or
an assertion that an archived binary was used. Ordinary SQL Coordinator and a
bounded ResultSink are timed, excluding TCP serialization. OS cache is uncontrolled;
queries are warmed after startup/count/no-op write/checkpoint. Durability remains
window 0 us, 8,192 dirty pages, 128-page flush batches, 10 ms wake, shutdown drain.

Raw per-operation latency, commit/conflict counts, reader/writer successes,
progress during active writers, paused-writer reads, and profile deltas are saved.
Unique-key wait/recheck uses deterministic hooks in the separate diagnostic binary.
Profile spans are inclusive and may overlap; their times must not be summed as an
exclusive decomposition. Shared-row tests use fixed attempts with deterministic
victim policy: compare committed TPS and conflict rate as well as latency, never
interpret rejected attempts as successful throughput. Three insert operations and
short concurrency bursts are development measurements, not steady-state capacity
or a long-soak substitute.

Read budgets retain the existing 1.10x policy; other elapsed-time budgets retain
max(2x, +20ms). `budgets.json` reports every breach without relaxing thresholds.
`FAST-GATES-COMPLETE.txt` means execution/outcome checks completed; C5 freeze also
requires an explicit review of those breaches and immutable source/evidence hashes.

If the saved fixtures are unavailable, generate equivalent *new* legacy inputs
with the existing deterministic seed-8067 loader (generation is not part of timed
C5 queries). Use a new fixture root; do not overwrite the frozen C4 directory:

```powershell
cargo build --workspace --release
.\tools\run-benchmarks.ps1 -Mode bulk -Rows 100000 -OutputDirectory <new-fixtures>/100000
.\tools\run-benchmarks.ps1 -Mode bulk -Rows 1000000 -OutputDirectory <new-fixtures>/1000000
```

Pass that new root to `-Fixtures`. Record its generated hashes as a new campaign;
these commands do not reproduce archived byte hashes by assertion. The benchmark
schema is `bench(id BIGINT NOT NULL, bucket BIGINT NOT NULL, payload TEXT NOT NULL)`
with a unique `bench_id` index and a separate 100-row dimension table. Each measured
process adds its own eight-row join probe outside the timed workload.

Concurrent writer rounds issue 32 operations per client on hot IDs 0–7; the
shared-row round targets ID 0. The mixed round has four such writers and four
readers, with a separate count of reads completed before the writer loops end.
Standalone concurrent readers use the same deterministic 32 keys within the
first 100K IDs at both cardinalities. Point/range loops target ID 0 and IDs below
8. These are controlled hot-key measurements on databases of different size,
not uniform random access across every one of the million rows. Full scans,
grouping, join input and sorting traverse the stated database cardinality.

The historical profile name `mvcc.index_publication_wait` encloses the entire
bounded index batch (guard acquisition, tree reopening and traversal), not pure
lock wait. It must be interpreted as inclusive batch time. Snapshot cost measures
registry pin creation; SQL statement/session setup is additionally reflected in
end-to-end reader latency. Unique wait/recheck wall time includes the deliberately
blocked owner commit; the owner's commit time is recorded separately.

For concurrent workloads, diagnostic before/after snapshots also include the
post-round `SUM(bucket)` lost-update check, which is outside the normal elapsed
and latency timers. Consequently visibility/status totals in those diagnostic
windows are not an exclusive writer-only profile. Preparation/publication/queue
spans describe the commits; aggregate visibility lookup means include verification
reads. Use the read-only profile windows for isolated scan visibility costs.


## Final acceptance evidence and disposition

Evidence: `work/write-v3/evidence/c5-acceptance-fast-01`; correctness evidence:
`c5-acceptance-correctness-02`. **193 tests passed, 0 failed**, with only the three
pre-existing long-soak tests ignored. Formatting, strict Clippy, docs, release and
profile builds passed. The 24 focused runtime crash cases and three new schema
cases passed, together with inherited C5 component and C1–C4 regression coverage.
All 18 measured processes completed (six legacy, six MVCC, six instrumented MVCC).
Final recovered-state offline integrity passed at 100K and 1M; the latter checked
3 tables, 1 index and 5,680 index pages. Source and binary hashes matched across
measurement execution. No PostgreSQL, 10M or long soak ran.

Every normal MVCC mixed trial completed all 128 reader queries while writer loops
were active. Every disjoint writer attempt committed; all lost-update checks
passed. Paused writers exposed no uncommitted values. All six forced unique waits
woke and rejected the duplicate after the owner committed. Correctness tests also
cover owner abort, NULL/composite races, stream visibility and repeated recovery.

Selected normal results (medians across three processes):

| Measurement | 100K | 1M |
|---|---:|---:|
| Concurrent reader queries/s | 2071.107 | 2073.026 |
| Readers/s in mixed writer round | 74.760 | 121.586 |
| Reader p50 while writer paused, ms | 3.463 | 3.441 |
| Four disjoint writers, committed tx/s | 179.894 | 178.085 |
| Eight disjoint writers, committed tx/s | 166.953 | 88.217 |
| Same-row committed tx/s | 18.214 | 24.862 |
| Same-row conflict rate, % | 86.719 | 87.500 |
| Same-row attempt p95, ms | 63.884 | 43.202 |

Separate instrumented costs (weighted means unless stated otherwise):

| Measurement | 100K | 1M |
|---|---:|---:|
| Snapshot registry pin, ns | 232.75 | 214.59 |
| Isolated full-scan visibility, ns/version | 77.32 | 78.39 |
| Status-file lookup, us | 14.64 | 12.64 |
| Status-file write, us | 17.49 | 16.84 |
| Status-file force, us | 687.19 | 471.89 |
| Stable-ID reservation force, us | 657.06 | 437.83 |
| Row ownership acquisition/wait, us | 2.95 | 1.24 |
| Unique ownership acquisition/wait, us | 10.23 | 6.98 |
| Full uniqueness recheck, ms | 4.13 | 3.39 |
| Forced unique wait + recheck, median ms | 7.98 | 6.64 |

The all-window visibility means (including point/version-history and verification
work) are 2.07 us at 100K and 0.23 us at 1M; they are a different workload mix from
the isolated scan result. Unique recheck includes retained-version traversal and
status work. Full raw per-workload counts and distributions are in
`measurements/profile-costs.csv`, `summary.json`, latency CSVs and unique-wait CSVs.

### Explicit performance exception review

The unchanged raw budget checker reports **14/32 within budget and 18/32 breaches**.
It remains `REVIEW_REQUIRED`; `budget-review.json` records the separate qualified
C5 disposition and a justification for every breach. No threshold was raised.

| Rows | Workload | Clients | MVCC / legacy elapsed | Disposition |
|---:|---|---:|---:|---|
| 100000 | autocommit_insert | 1 | 2.580x | writer exception |
| 100000 | concurrent_insert | 4 | 2.250x | writer exception |
| 100000 | concurrent_readers | 4 | 4.682x | indexed exception |
| 100000 | full_scan | 1 | 1.745x | scan exception |
| 100000 | indexed_point_loop | 1 | 11.649x | indexed exception |
| 100000 | indexed_range_loop | 1 | 12.853x | indexed exception |
| 100000 | join | 1 | 1.586x | scan exception |
| 100000 | mixed | 8 | 2.814x | writer exception |
| 100000 | scan_aggregate | 1 | 1.813x | scan exception |
| 100000 | startup | 1 | 1.304x | startup exception |
| 1000000 | concurrent_readers | 4 | 5.049x | indexed exception |
| 1000000 | disjoint_writers | 8 | 2.477x | writer exception |
| 1000000 | full_scan | 1 | 1.677x | scan exception |
| 1000000 | indexed_point_loop | 1 | 11.618x | indexed exception |
| 1000000 | indexed_range_loop | 1 | 13.748x | indexed exception |
| 1000000 | join | 1 | 1.552x | scan exception |
| 1000000 | scan_aggregate | 1 | 1.815x | scan exception |
| 1000000 | startup | 1 | 1.498x | startup exception |

**Startup:** Capability-4 open validates transaction visibility and versioned heap state and performs scoped recovery housekeeping. The larger versioned representation and additional open validation add cost. This is a source-supported explanation, not an exclusive startup profile; accept for the C5 correctness foundation only.

**Indexed:** The conservative statement reader recreates committed heap/index views and reopens/traverses bounded index batches, rather than retaining the legacy cached execution view. A 100K point diagnostic records 9.84 ms inclusive index-batch time across 64 batches, plus node/checksum/status work. Sub-millisecond clean point medians still regress by more than 11x. Retain this correctness-first lifecycle for C5; no parity claim or claim that the overhead is inherent to MVCC.

**Scan:** Version envelopes increase physical bytes and every tuple receives visibility evaluation. The measured per-row status-I/O defect was fixed: isolated scan visibility now averages about 78 ns and 900K/9M cache hits across three profiles need only 18 status-file lookups. Remaining 1.55-1.82x scan/join elapsed ratios are accepted as a documented C5 foundation cost, not treated as meeting the 10% budget.

**Writer:** Stable identity reservation and visibility status retain their required durable forces, conflict rechecks traverse retained versions, and rebasing/publication remain serialized. Profiles record these force, queue, recheck and install costs; the short trials also vary materially. Preserve the approved identity/group-WAL/writeback guarantees rather than weaken them to pass a speed threshold. Accept this explicit C5 performance debt only; mixed and 1M eight-writer regressions are not resolved.

Same-row MVCC committed throughput is substantially below the legacy serialized
control and is not made comparable by an elapsed-time budget pass: rejected
attempts do less work. The 86.72%/87.50% conflict rates above remain a prominent
limitation. No starvation-freedom, steady-state capacity or throughput-equivalence
claim is made from these short fixed-attempt trials.

Freeze disposition: **C5 qualified foundation checkpoint passed**, with the
listed performance debt retained. This follows the requested allowance for
explicitly documented Fast-budget regressions while preserving correctness and
durability. Physical VACUUM remains absent, terminal IDs are not reused, and bounded
pin/status capacity continues to apply backpressure. No C6 work is included.

Failed development attempts are retained: `c5-acceptance-measure-01` incorrectly
required the legacy control to satisfy MVCC reader-progress acceptance;
`c5-acceptance-measure-02` exposed the real stale heap-bound/index-reference defect.
`c5-direct-read-profile-01` proves its fix before the terminal-status cache change.
They are not counted as passing final measurements.
