# Phobos beta certification status

**Not beta certified.** Version remains `0.0.1-alpha.0`.

Matched PostgreSQL 18.6 TCP comparisons are now measured at 100K, 1M, and 10M. The installation blocker is resolved. PostgreSQL completed all 15 SQL workloads at every scale. Phobos failures and any incomplete workloads are release blockers for the requested complete comparison; the enforced 1MiB response cap rejects oversized full results. No limit or durability setting was weakened.

See [the PostgreSQL comparison report](postgresql_comparison_report.md) for exact timings, ratios, errors, postchecks, hashes, reproduction, and remaining measurement limits. The matched driver does not measure service startup/recovery or Phobos emitted WAL volume.

The earlier final-source campaign passed the 10M durable bulk target in 27m04s, full 1M/10M logical and backup/restore certification, a two-hour soak, 71 distinct Rust tests, 1,000 controlled process-crash cycles, strict Clippy, Phase 7/8 validation, live security checks, documentation and release build. Those embedded timings are separate from this TCP comparison. All 67 recorded source fingerprints and three release binaries match the prior validated candidate.

See [the write-path campaign report](writepath_campaign_report.md) for that historical evidence. The delivered Windows package remains an uncertified alpha candidate. The beta version and success banner are withheld.
