# Phase 4 indexes

Phobos Phase 4 adds a Rust-native, disk-backed B+ tree index implementation. Index files use the `.idx` extension and fixed 8192-byte pages. Page 0 is a checksummed metadata page; all remaining pages are checksummed leaf or internal nodes.

Implemented behavior:

- `CREATE INDEX` and `CREATE UNIQUE INDEX`.
- `DROP INDEX`.
- Single-column and composite keys.
- Unique and non-unique indexes. As in PostgreSQL-style SQL semantics, unique indexes permit multiple rows when any indexed key component is NULL.
- Point lookup and inclusive/exclusive bounded range scans.
- Linked leaf pages for ordered range traversal.
- Leaf splits, internal-node splits, and root splits.
- Deletion removes exact `(key, RecordId)` entries. Under-full nodes are intentionally left in place in this phase; merge/rebalancing is deferred without changing search correctness.
- Persistent index catalog metadata in `indexes.phc`.
- Startup integrity validation for checksums, ordering, reachability, and leaf sibling linkage. The legacy parent field remains readable but is reserved as zero on rewritten nodes; mutation propagates splits with its descent path.
- Private transactions retain root/allocation/free-list metadata in memory and emit one meta-page image at preparation when it changed.
- Index maintenance on INSERT, UPDATE, and DELETE.
- Phase 3 WAL/snapshot protection for `.idx` files.

The Phase 4 planner recognizes equality predicates for complete composite keys and equality/range predicates for single-column indexes. It still re-evaluates the SQL predicate after fetching heap rows, so an index is an access path rather than a substitute for semantic validation.

This implementation is intentionally conservative. It does not yet implement covering indexes, prefix-compressed keys, page merges, online index builds, bitmap scans, statistics-driven costing, or index-only scans.
