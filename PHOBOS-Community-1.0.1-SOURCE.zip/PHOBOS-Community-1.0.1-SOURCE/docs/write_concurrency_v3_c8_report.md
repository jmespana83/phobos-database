# Phobos C8 — batched index maintenance

C8 FROZEN: YES. No subsequent milestone started.

**220 passed, 0 failed, 3 existing soaks ignored.** The two focused C8 tests passed, followed by exactly one successful full workspace gate: formatting, strict Clippy, workspace tests, docs and release build. No failing test was suppressed or skipped.

## Implementation

C7 preparation now collects bounded changes for one index at a time; uniqueness scratch trees receive bounded batches as well. The batch API sorts at most 1,024 key/RID entries and coalesces reads/writes in a cache capped at 64 decoded nodes. It reuses existing insertion, duplicate detection and leaf/internal/root split logic. Dirty nodes flush in page-ID order at the cache bound and batch close; changed metadata flushes at batch close.

MVCC, C7 ownership and visibility probes, all-or-nothing transaction handling, WAL/group commit, checkpointing, durable formats and client/CLI protocol remain unchanged. Existing non-bulk SQL does not opt into batching. The private-owner check remains mandatory for versioned batches. See [bounds and reproduction](write_concurrency_v3_c8_batch.md).

## Saved C7 versus C8

Exactly one final-source C8 run at each size; no C7 rerun, ordinary-SQL comparison, PostgreSQL, 10M, repeated trials or long soak. Both C7 and C8 timings use the same instrumented release build configuration, generated data and existing unique `id` plus nonunique `(bucket,id)` indexes. Timing includes import COMMIT; reopen/integrity work is outside the timer. Single samples provide measured comparisons, not confidence intervals.

| Rows | Saved C7 seconds / rows per second | C8 seconds / rows per second | Speedup | WAL forces |
|---:|---:|---:|---:|---:|
| 100,000 | 56.550 / 1,768.36 | 31.552 / 3,169.36 | 1.792× | 1 |
| 1,000,000 | 591.435 / 1,690.80 | 350.005 / 2,857.10 | 1.690× | 1 |

| 1M cost | C7 seconds | C8 seconds | Reduction |
|---|---:|---:|---:|
| Index maintenance | 323.773 | 155.247 | 52.1% |
| Uniqueness validation | 239.189 | 166.108 | 30.6% |

1M WAL bytes: 205,532,852; batch node writes: 159,712; sampled whole-process peak working set: 214.26 MiB. Raw before/after profiles are included. Node and row batches are bounded; ordinary database metadata and allocator working set are not claimed constant. Sorting may change valid tree shape/page count, without changing durable formats.

## Correctness and integrity

- Focused wide-key index test forces cache eviction, leaf/internal/root splits, unique duplicate rejection, nonunique duplicates and composite NULL handling, then reopens and validates the tree.
- Focused runtime test exercises reverse-order indexed bulk load, existing-key duplicate rejection, explicit rollback, composite/NULL uniqueness and one crash during batched index publication after durable WAL. Recovery runs twice with count/index checks and offline integrity.
- Existing C7 disconnect, rollback, malformed-input, WAL-fault and crash tests pass in the one full workspace gate.
- Each measured database passed committed row count, clean shutdown, one reopen with count and indexed-point verification, and one final offline heap/index integrity check. No additional performance trial followed the successful 1M run.
- Frozen C7 source/evidence/binary packages and the saved comparison data were hash-verified unchanged.

## Evidence and reproduction

Evidence contains `c8-final-gate`, both focused-test logs, `c8-measurements` and copies/hash manifests of the saved C7 baseline. Source, evidence and Windows binaries have SHA-256 manifests. Reproduction commands are in the batching guide and `tools/c8-validation.ps1` / `tools/c8-measure.py`. The measurement tool refuses automatic repetition of successful runs and supports resuming only with the identical executable.

## Exact changed/new files from frozen C7

- `crates/phobos-bench/src/c7_bulk.rs`
- `crates/phobos-bench/src/main.rs`
- `crates/phobos-execution/src/mvcc_runtime/bulk.rs`
- `crates/phobos-index/src/batch.rs`
- `crates/phobos-index/src/committed_reader.rs`
- `crates/phobos-index/src/lib.rs`
- `crates/phobos-server/src/tests/c7_bulk.rs`
- `docs/write_concurrency_v3_c8_batch.md`
- `docs/write_concurrency_v3_c8_report.md`
- `tools/c8-measure.py`
- `tools/c8-validation.ps1`
