# Operations — Community 0.1.9-G3+G4

## Startup configuration

Pass exactly one optional JSON file explicitly:

```powershell
phobos-server --data-dir .\data --bind 127.0.0.1:54321 --config .\config.json
```

Relative config paths resolve against the server process's current working directory. There is **no automatic config.json search**, no environment-file search and no hot reload. Omit `--config` to keep existing defaults; an explicitly named missing/unreadable file fails startup. `{}` and omitted fields use defaults. Unknown/duplicate fields, malformed JSON, wrong numeric types, invalid zero/negative values and checked size/offset overflows are rejected with a configuration error before opening the database.

Durations use milliseconds; byte/page/row/record units are explicit in the field names. A complete default file on a host with at least 16 available CPUs is:

```json
{
  "max_connections": 64,
  "worker_threads": 16,
  "parallel_scan_workers": 4,
  "parallel_scan_min_pages": 256,
  "role_connection_limits": {},
  "slow_query_ms": 1000,
  "log_format": "text",
  "mtls_required": false,
  "client_ca_path": null,
  "mtls_identities": {},
  "audit_enabled": false,
  "audit_log_path": null,
  "max_result_bytes": 1048576,
  "statement_timeout_ms": 1800000,
  "idle_timeout_ms": 900000,
  "lock_timeout_ms": 2000,
  "status_growth_extent_records": 1048576,
  "write_spill_threshold_bytes": 67108864,
  "write_spill_scratch_quota_bytes": 2147483648,
  "query_memory_bytes": 67108864,
  "bulk_scratch_quota_bytes": 8589934592,
  "bulk_scratch_directories": [],
  "bulk_index_build_workers": 4,
  "merge_fan_in": 512,
  "page_cache_bytes": 268435456,
  "hint_bits_enabled": true
}
```

`query_memory_bytes` is an approximate per-operator byte budget used by join,
grouping, sort, and Top-K execution. The retired `query_memory_rows` name is
rejected as an unknown setting. Existing index formats 1/2 require an offline
`phobos-admin reindex DATA_DIR EMPTY_BACKUP_DIR` before normal open; the command
backs up the database and rebuilds only index files with the V3 binary
memcomparable encoding.

`hint_bits_enabled` (0.1.9-B1) switches the cache-resident settled-visibility hints; `false` returns every tuple to ordinary (shared-cached, paged) status resolution. It is a performance setting only and never affects results.

`max_connections` is 1..1024 (the existing session capacity); `worker_threads` and `parallel_scan_workers` are 1..64. `parallel_scan_workers` defaults to 4 and `parallel_scan_min_pages` to 256; they bound query-local fan-out for eligible read-only range-partition scans. `merge_fan_in` is 2..512. Other sizes/counts/deadlines must be positive and representable. Scratch quotas are independent; a small quota may deliberately cause ResourceLimit, and a threshold does not reserve that amount of RAM at startup.

Existing `--max-connections`, `--max-result-bytes` and `--lock-wait-ms` flags remain accepted and override their JSON fields regardless of argument order. Other connection/path/auth/TLS flags are unchanged. `PHOBOS_PAGE_CACHE_BYTES` supplies the byte budget when JSON omits it. The old `PHOBOS_DIRTY_HIGH_WATER_PAGES` environment setting remains an alias and is converted from 8 KiB pages; the retired JSON field is rejected as unknown. Explicit JSON wins. No settings change while running.

`log_format` accepts `text` (the default) or newline-delimited `json`. Structured events cover startup/recovery/shutdown, connections, authentication, slow queries, checkpoints and fenced storage errors. `slow_query_ms` defaults to 1000; zero disables slow-query events. SQL in those events is capped at 512 bytes with string-literal contents replaced by `?`; passwords, authentication payloads and TLS material are never logged.

## Metrics

`SELECT * FROM phobos_metrics` returns a read-only virtual relation with `name`, integer `value`, and `kind` (`counter` or `gauge`). The stable subset includes connections/sessions, active and peak workers, queries/errors, authentication failures, lock timeouts, cancellation, slow/prepared-query activity, connection rejections, output bytes, status-cache activity, and available page-cache/flush gauges. Reading it takes atomic snapshots and existing cache statistics; it creates no catalog object and changes no engine state. The existing admin-only protocol metrics frame remains available.

## Worker and connection admission

The acceptor places accepted sockets into a bounded queue serviced by `worker_threads` ordinary Rust workers. At most that many connection handlers execute concurrently; up to `max_connections` accepted connections may be active or queued. Queue/global overflow is rejected. Shutdown closes accepted sockets, drains the workers, and then uses the existing bounded database shutdown path. Statement timeout, cancellation, disconnect rollback, and true outcomes after irreversible commit admission are unchanged.

`role_connection_limits` is an optional JSON object keyed by `reader`, `writer`, or `admin`, for example `{"reader": 20, "writer": 8}`. Each value is an additional 1..=`max_connections` cap. Omitted roles have only the global cap. A slot is acquired after successful authentication and released on reauthentication, disconnect, I/O error, or panic. The map is startup configuration and does not change the durable auth-file format.

Status growth, write-spill and C9 bulk settings apply to explicitly migrated MVCC stores. `page_cache_bytes` bounds shared clean and dirty heap/index page images for stores using committed-page storage; it is not a whole-process memory cap. Old V1 stores have no such cache.

## Sessions and cancellation

Defaults are 64 connections, 30-minute statements, 15-minute idle sessions and 2-second lock waits. Idle means waiting for the next complete frame, including a partial-frame stall, while no statement executes. Idle expiry/disconnect closes the connection, rolls back uncommitted state and releases ownership/pins. Authentication waiting is bounded too. Parser/expression depth is 64.

Use `Client::cancellation_handle()` before starting the next SQL/bulk request. A second authenticated connection with the **same username** calls `Client::cancel(handle)` while it is active. Unknown/completed targets are rejected; active repeated cancel requests are safe. No-auth loopback clients share the trusted domain. Cancellation is cooperative, and already-admitted durability work finishes with its true outcome. A cancelled stream follows the existing client reconnection requirement. See [transactions and recovery](transactions_and_recovery.md).

## Security, lifecycle and recovery

Loopback is the default. Authentication and TLS are implemented; non-loopback bind requires authentication, and TLS certificate/key must be supplied together. Data-directory locking and the existing shutdown-file drain mechanism are implemented. Existing Windows init/start/stop/shell/lifecycle validation scripts are unchanged; their wrapper options are not expanded in A5. To select a JSON file, invoke the server CLI with `--config` (and the existing auth/TLS/shutdown arguments as appropriate).

Offline backup/migration/integrity commands remain available. For an MVCC
instance, the Coordinator/admin `backup_online` operation takes a commit frontier,
forces durable heap/index/status state, checkpoints the segmented WAL, and copies
the durable files plus the active/required WAL into an empty ordinary directory.
The `PHOBOS_BACKUP_2` marker records start/end LSNs; restore is a directory copy
and normal open/recovery. PHOBOS-owned scratch directories are excluded. A short
commit-publication pause covers the copy; statement readers remain available.

Coordinator/admin `check_online` traverses live checksummed heap/overflow and
index pages under the existing publication boundary, validates catalog/index
relationships and both index-to-tuple and tuple-to-index references, and creates
no database copy. `phobos-admin check` remains the full offline checker. G3
physical replication and LSN-based PITR reuse this backup and the segmented WAL.
See [physical replication and PITR](replication_and_pitr.md). There is no automatic
archive service, failover orchestration, backup compression/encryption, or cloud
backup.

`bulk_scratch_directories` lists spill roots. An empty list preserves the data
directory default. Relative entries resolve below the data directory; every
import uses a conservative `.phobos-mvcc-bulk-<transaction>` child in each root.
Each listed directory contributes one `bulk_scratch_quota_bytes` unit to the
bounded aggregate quota. Runs are placed across the roots and commit, rollback,
cancellation and drop remove only those owned children. `bulk_index_build_workers`
is 1..16 (default 4); independent indexes build concurrently up to this bound,
while each index keeps the existing bottom-up builder and publication order.
