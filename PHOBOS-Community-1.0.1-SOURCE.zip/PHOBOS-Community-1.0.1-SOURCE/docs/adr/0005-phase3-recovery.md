# ADR 0005: Phase 3 transaction staging and redo-only recovery

Status: Accepted for Phase 3 alpha; intended to evolve behind stable transaction/WAL interfaces.

## Decision

Phase 3 uses private transaction staging directories plus a synchronous redo WAL containing checksummed committed file-image chunks. Uncommitted work never modifies the main database files. Commit fsyncs the WAL before installing staged images. Startup redoes committed images and ignores incomplete transactions.

## Why

This keeps the first crash-recovery algorithm small enough to test exhaustively while preserving the essential contract: atomic multi-statement transactions, WAL-before-main-data, durable commit, rollback, idempotent redo, and no visibility of uncommitted effects after crash.

## Tradeoffs

File-image logging has poor WAL volume and commit amplification compared with page-level physiological logging. It is not the intended performance endpoint. Phase 4 index recovery must use the same transaction boundary, and later performance work may replace file images with page/record redo records after equivalent crash tests prove the replacement.

## Concurrency interaction

This ADR does not replace ADR 0001. Phase 5 still targets MVCC and session-scoped Read Committed semantics. The Phase 3 staging model is single-user only.
