# ADR 0003: Network/runtime boundary

Status: Accepted.

Phase 0 uses blocking standard-library TCP because the handshake is tiny and this avoids a foundational async dependency prematurely. The future server may use async networking, but blocking file I/O/fsync and CPU-heavy execution will not run on async reactor threads.
