# ADR 0002: 8 KiB pages

Status: Accepted.

Format v1 uses 8192-byte pages. The size is stored in file metadata in a later catalog/bootstrap milestone and will be configurable only at database creation. The current page codec uses little-endian integer fields and checksummed page payloads.
