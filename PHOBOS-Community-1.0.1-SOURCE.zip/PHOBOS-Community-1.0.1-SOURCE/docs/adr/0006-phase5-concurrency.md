# ADR 0006: Phase 5 multi-client concurrency baseline

Status: Accepted for Phase 5 alpha.

## Decision

Phase 5 uses a correctness-first, coarse strict two-phase locking baseline at the server session level. A persistent TCP connection is a database session. Multiple sessions may connect concurrently. Autocommit statements are serialized through a shared coordinator. An explicit `BEGIN` claims the transaction owner until `COMMIT`, `ROLLBACK`, or disconnect.

Other sessions wait for the transaction owner with a bounded timeout. Because Phase 5 uses one coarse owner, deadlock cycles cannot form; timeout is still implemented so a stalled client cannot block others forever. Disconnect automatically rolls back an owned transaction and wakes waiters.

## Isolation

The implemented behavior is stronger than Read Committed for conflicting work: an explicit transaction excludes other statements while it is active. Therefore dirty reads are impossible, but reader/writer concurrency is intentionally limited in this alpha baseline.

This is not the long-term Phobos concurrency architecture. ADR 0001's MVCC target remains valid. MVCC is still preferred so readers do not unnecessarily block writers. The coarse strict-2PL phase exists to establish correct session ownership, lifecycle, transaction cleanup, deterministic tests, and protocol behavior before replacing the lock manager with MVCC/finer-grained coordination.

## Tradeoffs

Advantages:

- straightforward isolation argument;
- no dirty reads;
- no deadlock cycles with one lock domain;
- deterministic disconnect cleanup;
- protects the Phase 3 WAL and Phase 4 B+ tree from unsynchronized multi-writer access.

Costs:

- explicit transactions block other sessions;
- autocommit statements are serialized at execution;
- this is not a performance-oriented concurrency design;
- lock granularity must become finer or move to MVCC before production claims.
