# ADR 0004: Dependency policy

Status: Accepted.

Phase 0 intentionally has no third-party Rust dependencies. Future dependencies must solve supporting concerns only, use minimal features, have acceptable licenses/security posture, and be documented before becoming foundational. Phobos will own storage, catalog, transaction, planning, and execution code.
