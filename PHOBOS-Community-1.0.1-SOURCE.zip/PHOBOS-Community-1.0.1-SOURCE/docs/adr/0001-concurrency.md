# ADR 0001: MVCC target

Status: Accepted for architecture; not yet implemented.

Phobos will target MVCC so readers do not unnecessarily block writers. Before MVCC lands, no multi-client transaction isolation guarantee is claimed. Read Committed is the first intended isolation level; stronger levels follow after correctness tests.
