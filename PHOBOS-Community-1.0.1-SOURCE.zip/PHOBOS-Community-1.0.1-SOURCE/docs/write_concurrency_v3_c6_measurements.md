# C6 measurements versus frozen C5

Three process medians; per-trial percentiles not pooled. Profiling separate. Histogram quantiles are bucket upper bounds. Maximum fields are cumulative. Fixed C5 historical baseline, OS cache and machine conditions uncontrolled.

| Rows | Workload | Clients | C5 writer TPS | C6 writer TPS | C5 reader TPS | C6 reader TPS | C6 p95 ms | Conflict % |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 100000 | autocommit_insert | 1 | 79.22 | 130.49 | 0.00 | 0.00 | 7.114 | 0.00 |
| 100000 | concurrent_insert | 4 | 105.84 | 237.45 | 0.00 | 0.00 | 19.626 | 0.00 |
| 100000 | concurrent_readers | 4 | 0.00 | 0.00 | 2071.11 | 2864.20 | 1.595 | 0.00 |
| 100000 | disjoint_writers | 4 | 179.89 | 196.23 | 0.00 | 0.00 | 28.553 | 0.00 |
| 100000 | disjoint_writers | 8 | 166.95 | 199.22 | 0.00 | 0.00 | 55.696 | 0.00 |
| 100000 | explicit_insert | 1 | 73.33 | 88.74 | 0.00 | 0.00 | 11.141 | 0.00 |
| 100000 | full_scan | 1 | 0.00 | 0.00 | 22.23 | 23.34 | 42.732 | 0.00 |
| 100000 | group_aggregate | 1 | 0.00 | 0.00 | 1.04 | 1.12 | 889.829 | 0.00 |
| 100000 | indexed_point_loop | 1 | 0.00 | 0.00 | 1138.56 | 1169.30 | 0.874 | 0.00 |
| 100000 | indexed_range_loop | 1 | 0.00 | 0.00 | 1061.88 | 1080.37 | 0.969 | 0.00 |
| 100000 | join | 1 | 0.00 | 0.00 | 19.78 | 17.16 | 56.629 | 0.00 |
| 100000 | mixed | 8 | 74.76 | 96.22 | 74.76 | 96.22 | 54.464 | 0.00 |
| 100000 | paused_writer_readers | 1 | 0.00 | 0.00 | 287.71 | 258.14 | 3.897 | 0.00 |
| 100000 | scan_aggregate | 1 | 0.00 | 0.00 | 25.98 | 25.86 | 38.267 | 0.00 |
| 100000 | shared_row_writers | 4 | 18.21 | 46.00 | 0.00 | 0.00 | 26.770 | 77.34 |
| 100000 | sort_spill | 1 | 0.00 | 0.00 | 1.04 | 1.07 | 920.536 | 0.00 |
| 100000 | startup | 1 | 0.00 | 0.00 | 13.74 | 13.16 | 76.015 | 0.00 |
| 1000000 | autocommit_insert | 1 | 107.99 | 111.91 | 0.00 | 0.00 | 6.792 | 0.00 |
| 1000000 | concurrent_insert | 4 | 182.48 | 225.40 | 0.00 | 0.00 | 21.787 | 0.00 |
| 1000000 | concurrent_readers | 4 | 0.00 | 0.00 | 2073.03 | 2878.55 | 1.540 | 0.00 |
| 1000000 | disjoint_writers | 4 | 178.08 | 186.34 | 0.00 | 0.00 | 33.270 | 0.00 |
| 1000000 | disjoint_writers | 8 | 88.22 | 199.31 | 0.00 | 0.00 | 53.718 | 0.00 |
| 1000000 | explicit_insert | 1 | 70.75 | 68.41 | 0.00 | 0.00 | 14.483 | 0.00 |
| 1000000 | full_scan | 1 | 0.00 | 0.00 | 2.38 | 2.36 | 422.368 | 0.00 |
| 1000000 | group_aggregate | 1 | 0.00 | 0.00 | 0.09 | 0.08 | 11866.122 | 0.00 |
| 1000000 | indexed_point_loop | 1 | 0.00 | 0.00 | 1169.74 | 1153.02 | 0.862 | 0.00 |
| 1000000 | indexed_range_loop | 1 | 0.00 | 0.00 | 1078.17 | 1038.35 | 1.008 | 0.00 |
| 1000000 | join | 1 | 0.00 | 0.00 | 2.04 | 1.93 | 517.934 | 0.00 |
| 1000000 | mixed | 8 | 121.59 | 114.35 | 121.59 | 114.35 | 45.541 | 0.00 |
| 1000000 | paused_writer_readers | 1 | 0.00 | 0.00 | 290.29 | 266.96 | 3.797 | 0.00 |
| 1000000 | scan_aggregate | 1 | 0.00 | 0.00 | 2.64 | 2.60 | 386.803 | 0.00 |
| 1000000 | shared_row_writers | 4 | 24.86 | 32.43 | 0.00 | 0.00 | 35.775 | 82.81 |
| 1000000 | sort_spill | 1 | 0.00 | 0.00 | 0.08 | 0.08 | 11888.069 | 0.00 |
| 1000000 | startup | 1 | 0.00 | 0.00 | 1.51 | 1.54 | 649.871 | 0.00 |

## Original C5 exceptions

| Rows | Workload | Clients | C6/C5 elapsed | Disposition |
|---:|---|---:|---:|---|
| 100000 | autocommit_insert | 1 | 0.607 | RESOLVED |
| 100000 | concurrent_insert | 4 | 0.446 | RESOLVED |
| 100000 | concurrent_readers | 4 | 0.723 | IMPROVED BUT STILL OUTSIDE BUDGET |
| 100000 | full_scan | 1 | 0.952 | UNCHANGED |
| 100000 | indexed_point_loop | 1 | 0.974 | UNCHANGED |
| 100000 | indexed_range_loop | 1 | 0.983 | UNCHANGED |
| 100000 | join | 1 | 1.153 | REGRESSED |
| 100000 | mixed | 8 | 0.777 | IMPROVED BUT STILL OUTSIDE BUDGET |
| 100000 | scan_aggregate | 1 | 1.005 | UNCHANGED |
| 100000 | startup | 1 | 1.044 | UNCHANGED |
| 1000000 | concurrent_readers | 4 | 0.720 | IMPROVED BUT STILL OUTSIDE BUDGET |
| 1000000 | disjoint_writers | 8 | 0.443 | RESOLVED |
| 1000000 | full_scan | 1 | 1.005 | UNCHANGED |
| 1000000 | indexed_point_loop | 1 | 1.014 | UNCHANGED |
| 1000000 | indexed_range_loop | 1 | 1.038 | UNCHANGED |
| 1000000 | join | 1 | 1.056 | REGRESSED |
| 1000000 | scan_aggregate | 1 | 1.016 | UNCHANGED |
| 1000000 | startup | 1 | 0.982 | UNCHANGED |

New C6 threshold breaches: 1000000/sort_spill/1

Raw counters, histogram quantiles, cumulative maxima, active-reader proof and unique rechecks are in summary.json. Budgets are unchanged; this report does not itself authorize a freeze.
