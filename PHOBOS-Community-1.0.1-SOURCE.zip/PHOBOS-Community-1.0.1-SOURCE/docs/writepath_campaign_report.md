# Phobos targeted write-path campaign

**Primary 10M load target: PASS. Full beta certification: pending PostgreSQL comparison.**

The complete certification run committed 10,000,000 rows in **1,624.0055042 seconds (27m04s)**. The unchanged bulk gate was 3,600 seconds; first observed completion was 1,627.4859192 seconds including startup and polling. All 17 workloads and 49 samples completed in 4,733.3953859 seconds (78m53s) under a separately documented 7,200-second whole-suite allowance. The whole-suite allowance does not relax the one-hour bulk gate.

Full 10M and final-source 1M logical certification passed. PostgreSQL remains uninstalled and unconfigured by the user’s earlier instruction. No PostgreSQL timings or ratios are claimed. Version remains `0.0.1-alpha.0`; `0.1.0-beta.1` and the beta success banner are withheld.

## Source, environment and provenance

Windows NT 10.0.26200.0, x86_64 MSVC, Rust 1.85.0, AMD Ryzen 7 5800X, 16 logical processors, NTFS. RAM capacity and drive model were inaccessible through CIM and are not invented. Every benchmark run retains environment, executable hash and per-file source hashes. Cargo used cached dependencies in offline mode. No repository commit identity exists for the supplied archive; content hashes identify it instead.

The final measured engine is preserved in `merge-source.zip` in the audit archive (SHA256 `27cdc7f431d75b4db94e2b66815fd7ab66dfab17614fe5e55a537d63a6d3665a`); `merge-archive-sha256.json` and `merge-source.json` identify it. Final documentation was added after measurement. `beta-complete/campaign-source.json` matches the final 67-file Rust/manifest/tool fingerprint. The deliverable SHA256 manifest identifies the final source and Windows candidate archives.

## Measured causes and lifecycle fixes

The complete before-profile at 100K measured 100,100 heap fsync calls taking 45.4884914 inclusive seconds within 73.106 seconds of private staging. This established per-row heap synchronization as the largest measured cost. Private staging now defers insert-triggered flushes, while bounded-buffer eviction, new-page append synchronization, statement-end flush and pre-commit flush remain intact. Normal HeapTable users retain immediate insert flushes. Ownership is explicit through Database::open_staging, not inferred from a path name. After this change, 100K heap fsync calls fell to 641 and 0.3159402 seconds; heap page writes fell from 99,459 to 638. Complete data/index/catalog files were byte-identical to baseline at all four progression scales.

Index work then dominated staging: 21.745 seconds at 100K after heap batching. Insert previously repeated validated leaf descent. The retained validated leaf is now used for duplicate probing and insertion, preserving sibling scanning, exact-RID idempotence, unique NULL handling, page checksums and split behavior. Reads/decodes fell from 662,904 before to 232,113 after at 100K. The regression exposed a pre-existing integrity-validator defect: equal separators are legal when duplicate keys span leaves, but the validator rejected them. The original algorithm reproduced this failure. Validation now rejects descending separators while accepting equal separators. A descending-separator corruption regression remains enforced.

The first optimized 10M load met the primary gate, but a GROUP BY sample took 725.162096 seconds. External merge selected each next row by scanning all run heads, with about 9,766 runs at 10M. A tournament tree now updates the winning path in logarithmic work, preserving comparisons, errors, run format and stable tie order. The final 10M GROUP BY samples took about 41–42 seconds. This fixes measured selection work; it does not reduce the one-reader-per-run handle count or materialize less output.

The WAL protocol is unchanged: flush complete staged state, drop staging handles, write file-image snapshots and Commit record, synchronize WAL covering those records, install, checkpoint/rotate, then acknowledge. There is one existing sync covering the Commit record, not a newly introduced two-sync protocol. No weakening of committed durability, checksums, constraints, recovery, auth or TLS is intended or used to obtain the timing result.

The separate final 10M profiling run committed in 1,684.2611786 seconds and completed all bulk-mode postchecks in 1,739.8689397 seconds. Actual staging recorded 10M index-maintenance calls / 1,462.8422066 inclusive seconds, 64,055 heap sync calls / 30.6774288 seconds, 63,784 heap page writes / 1.1623191 seconds, and 10,000 buffer flushes / 6.8371106 seconds. Free-space lookup took 64.359468 seconds for 10M calls; row encoding took 2.3781738 seconds for 10M calls. The commit phase recorded one snapshot construction / 4.7076135 seconds and one installation / 9.0278484 seconds. Its four WAL sync calls / 2.8184905 seconds include checkpoint/rotation work; the commit-covering WAL sync ordering remains unchanged. The one-hour objective has substantial margin, so no broader WAL or free-space redesign was added.

## Before/after progression

Normal release; unchanged schema, seed 8067, durability and 1,000-row statements inside one explicit transaction. Each cell is elapsed seconds / rows per second. These are single-run measurements, not confidence intervals. The merge candidate used full-suite mode; the earlier progression used bulk mode, with the same load body.

| Rows | Before | Heap batching | Index reuse | Final merge source |
|---:|---:|---:|---:|---:|
| 100,000 | 67.812 / 1474.7 | 22.622 / 4420.5 | 12.746 / 7845.4 | 13.040 / 7668.5 |
| 500,000 | 375.403 / 1331.9 | 128.641 / 3886.8 | 72.545 / 6892.3 | 72.699 / 6877.7 |
| 1,000,000 | 744.732 / 1342.8 | 261.900 / 3818.3 | 140.553 / 7114.7 | 146.737 / 6814.9 |
| 2,000,000 | 1521.980 / 1314.1 | 523.241 / 3822.3 | 283.387 / 7057.5 | 296.778 / 6739.0 |

All 32 checked baseline database files across the four scales were byte-identical for each kept candidate (heap, index and merge). Final progression load timings were slightly slower than index-only timings; both are retained. No 10M speedup ratio is computed from the original incomplete load.

## Full large-scale results

Three samples per workload except the single bulk load. Values are median seconds; the raw CSV and final-summary.json retain all samples and min/max. No confident p95 estimate is asserted from three samples. Autocommit/transaction/update/delete samples perform three operations; concurrent samples use four connections and three operations per connection. Consult each raw row for exact units.

| Workload | 1M median seconds | 10M median seconds |
|---|---:|---:|
| bulk_load | 153.114968 | 1624.005504 |
| indexed_point | 0.000106 | 0.000124 |
| indexed_range | 0.000274 | 0.000291 |
| full_scan | 0.414460 | 4.613294 |
| scan_aggregate | 0.355956 | 4.169974 |
| join | 0.844317 | 11.760666 |
| group_aggregate | 3.411487 | 41.852220 |
| sort_spill | 3.922127 | 45.645879 |
| autocommit_insert | 5.744897 | 68.611782 |
| transaction_insert | 2.116839 | 20.668711 |
| update | 6.875774 | 78.179241 |
| delete | 8.174493 | 80.073233 |
| concurrent_readers | 0.001793 | 0.002137 |
| concurrent_writers | 26.076019 | 294.668662 |
| mixed | 15.015958 | 159.783489 |
| startup | 0.411884 | 4.017365 |
| crash_recovery | 0.927311 | 10.001864 |

1m: 49 samples; whole wall 435.518s; sampled parent CPU 319.172s; peak working bytes 482,729,984; peak private bytes 503,513,088; bulk database bytes 90,808,513; bulk cumulative parent WAL bytes 90,834,333. Sampling interval was 100ms and can miss peaks; child recovery CPU is excluded.

10m: 49 samples; whole wall 4733.395s; sampled parent CPU 3409.516s; peak working bytes 4,868,067,328; peak private bytes 5,523,337,216; bulk database bytes 908,026,049; bulk cumulative parent WAL bytes 908,123,917. Sampling interval was 100ms and can miss peaks; child recovery CPU is excluded.

Logical certification at both scales checks every deterministic base row, point/range results, aggregates, joined identities, sorted payloads, persisted statistics, EXPLAIN stability, unique composite index enforcement, update/delete index maintenance, commit/rollback, failed-transaction rollback, reopened contents, backup/restore equivalence, integrity and strict cleanup. Both final PASS files exist.

## Actual profiling counts and time

Profiling builds run separately from normal timing. Spans are inclusive and nested: **do not sum them**. These are instrumented Rust API calls, not kernel I/O tracing. The embedded bulk path does not use the server coordinator, so coordinator lock time is not applicable; server lock spans remain available for server workloads. Complete per-phase counters are in each profile directory’s phase-deltas.csv.

| Run | Phase | Span | Calls / units | Inclusive seconds |
|---|---|---|---:|---:|
| before-profile-complete-100k | begun->staged | execution.index_maintenance | 100,000 | 24.120173 |
| before-profile-complete-100k | begun->staged | fs.file_metadata | 100,541 | 1.138952 |
| before-profile-complete-100k | begun->staged | fs.heap_metadata | 100,541 | 1.156276 |
| before-profile-complete-100k | begun->staged | fs.sync_data | 100,200 | 45.532835 |
| before-profile-complete-100k | begun->staged | heap.append_page | 541 | 0.259684 |
| before-profile-complete-100k | begun->staged | heap.checksum | 100,541 | 0.719180 |
| before-profile-complete-100k | begun->staged | heap.free_space_lookup | 100,000 | 0.011638 |
| before-profile-complete-100k | begun->staged | heap.fsync | 100,100 | 45.488491 |
| before-profile-complete-100k | begun->staged | heap.write_page | 99,459 | 2.188630 |
| before-profile-complete-100k | begun->staged | index.checksum_page | 765,360 | 5.468456 |
| before-profile-complete-100k | begun->staged | index.decode_node | 662,904 | 11.030564 |
| before-profile-complete-100k | begun->staged | index.encode_node | 101,888 | 3.268452 |
| before-profile-complete-100k | begun->staged | index.read_node | 662,904 | 14.501726 |
| before-profile-complete-100k | begun->staged | index.write_page | 102,456 | 1.267500 |
| before-profile-complete-100k | begun->staged | storage.encode | 100,000 | 0.044050 |
| before-profile-complete-100k | begun->staged | storage.flush_all | 99,559 | 47.535968 |
| heap-profile-100k | begun->staged | execution.index_maintenance | 100,000 | 21.745385 |
| heap-profile-100k | begun->staged | fs.file_metadata | 1,720 | 0.018829 |
| heap-profile-100k | begun->staged | fs.heap_metadata | 1,720 | 0.019098 |
| heap-profile-100k | begun->staged | fs.sync_data | 741 | 0.387437 |
| heap-profile-100k | begun->staged | heap.append_page | 541 | 0.277846 |
| heap-profile-100k | begun->staged | heap.checksum | 100,541 | 0.710584 |
| heap-profile-100k | begun->staged | heap.free_space_lookup | 100,000 | 0.010144 |
| heap-profile-100k | begun->staged | heap.fsync | 641 | 0.315940 |
| heap-profile-100k | begun->staged | heap.write_page | 638 | 0.012032 |
| heap-profile-100k | begun->staged | index.checksum_page | 765,360 | 5.411341 |
| heap-profile-100k | begun->staged | index.decode_node | 662,904 | 10.436606 |
| heap-profile-100k | begun->staged | index.encode_node | 101,888 | 3.045251 |
| heap-profile-100k | begun->staged | index.read_node | 662,904 | 13.375614 |
| heap-profile-100k | begun->staged | index.write_page | 102,456 | 0.837893 |
| heap-profile-100k | begun->staged | storage.encode | 100,000 | 0.027988 |
| heap-profile-100k | begun->staged | storage.flush_all | 100 | 0.068540 |
| index-profile-100k | begun->staged | execution.index_maintenance | 100,000 | 11.576068 |
| index-profile-100k | begun->staged | fs.file_metadata | 1,720 | 0.017113 |
| index-profile-100k | begun->staged | fs.heap_metadata | 1,720 | 0.017356 |
| index-profile-100k | begun->staged | fs.sync_data | 741 | 0.370456 |
| index-profile-100k | begun->staged | heap.append_page | 541 | 0.260700 |
| index-profile-100k | begun->staged | heap.checksum | 100,541 | 0.710683 |
| index-profile-100k | begun->staged | heap.free_space_lookup | 100,000 | 0.009842 |
| index-profile-100k | begun->staged | heap.fsync | 641 | 0.298790 |
| index-profile-100k | begun->staged | heap.write_page | 638 | 0.011699 |
| index-profile-100k | begun->staged | index.checksum_page | 334,569 | 2.365631 |
| index-profile-100k | begun->staged | index.decode_node | 232,113 | 3.549164 |
| index-profile-100k | begun->staged | index.encode_node | 101,888 | 3.012168 |
| index-profile-100k | begun->staged | index.read_node | 232,113 | 4.611641 |
| index-profile-100k | begun->staged | index.write_page | 102,456 | 0.806638 |
| index-profile-100k | begun->staged | storage.encode | 100,000 | 0.025175 |
| index-profile-100k | begun->staged | storage.flush_all | 100 | 0.066541 |
| merge-profile-10m | setup->begun | fs.copy_database | 1 | 0.003288 |
| merge-profile-10m | setup->begun | fs.file_metadata | 6 | 0.000065 |
| merge-profile-10m | setup->begun | fs.heap_metadata | 1 | 0.000013 |
| merge-profile-10m | setup->begun | fs.sync_data | 5 | 0.002867 |
| merge-profile-10m | setup->begun | heap.fsync | 1 | 0.000604 |
| merge-profile-10m | setup->begun | index.checksum_page | 6 | 0.000042 |
| merge-profile-10m | setup->begun | index.decode_node | 5 | 0.000035 |
| merge-profile-10m | setup->begun | index.read_node | 5 | 0.000059 |
| merge-profile-10m | setup->begun | storage.flush_all | 1 | 0.000604 |
| merge-profile-10m | begun->staged | execution.index_maintenance | 10,000,000 | 1462.842207 |
| merge-profile-10m | begun->staged | fs.file_metadata | 171,894 | 1.641516 |
| merge-profile-10m | begun->staged | fs.heap_metadata | 171,894 | 1.666060 |
| merge-profile-10m | begun->staged | fs.sync_data | 74,055 | 39.038588 |
| merge-profile-10m | begun->staged | heap.append_page | 54,055 | 26.692148 |
| merge-profile-10m | begun->staged | heap.checksum | 10,054,055 | 72.410900 |
| merge-profile-10m | begun->staged | heap.free_space_lookup | 10,000,000 | 64.359468 |
| merge-profile-10m | begun->staged | heap.fsync | 64,055 | 30.677429 |
| merge-profile-10m | begun->staged | heap.write_page | 63,784 | 1.162319 |
| merge-profile-10m | begun->staged | index.checksum_page | 40,383,245 | 290.934620 |
| merge-profile-10m | begun->staged | index.decode_node | 30,100,231 | 499.739819 |
| merge-profile-10m | begun->staged | index.encode_node | 10,226,226 | 333.049349 |
| merge-profile-10m | begun->staged | index.read_node | 30,100,231 | 655.053101 |
| merge-profile-10m | begun->staged | index.write_page | 10,283,014 | 89.247274 |
| merge-profile-10m | begun->staged | storage.encode | 10,000,000 | 2.378174 |
| merge-profile-10m | begun->staged | storage.flush_all | 10,000 | 6.837111 |
| merge-profile-10m | staged->committed | fs.file_metadata | 54,058 | 0.396367 |
| merge-profile-10m | staged->committed | fs.heap_metadata | 54,056 | 0.402274 |
| merge-profile-10m | staged->committed | fs.snapshot_metadata | 2 | 0.001571 |
| merge-profile-10m | staged->committed | fs.sync_all | 4 | 0.262235 |
| merge-profile-10m | staged->committed | fs.sync_data | 9 | 2.824202 |
| merge-profile-10m | staged->committed | heap.checksum | 54,055 | 0.381229 |
| merge-profile-10m | staged->committed | heap.fsync | 3 | 0.000686 |
| merge-profile-10m | staged->committed | index.checksum_page | 113,292 | 0.810233 |
| merge-profile-10m | staged->committed | index.decode_node | 113,291 | 1.562568 |
| merge-profile-10m | staged->committed | index.read_node | 113,291 | 2.184119 |
| merge-profile-10m | staged->committed | storage.flush_all | 3 | 0.000690 |
| merge-profile-10m | staged->committed | wal.bytes | 908,106,462 | 0.000000 |
| merge-profile-10m | staged->committed | wal.fsync | 4 | 2.818490 |
| merge-profile-10m | staged->committed | wal.install_snapshot | 1 | 9.027848 |
| merge-profile-10m | staged->committed | wal.snapshot_read | 8 | 0.463732 |
| merge-profile-10m | staged->committed | wal.write_record | 872 | 1.199820 |
| merge-profile-10m | staged->committed | wal.write_transaction_snapshot | 1 | 4.707613 |
| merge-profile-10m | committed->profile | execution.index_maintenance | 100 | 0.000006 |
| merge-profile-10m | committed->profile | fs.copy_database | 2 | 0.494357 |
| merge-profile-10m | committed->profile | fs.file_metadata | 270,302 | 2.040465 |
| merge-profile-10m | committed->profile | fs.heap_metadata | 270,288 | 2.067811 |
| merge-profile-10m | committed->profile | fs.snapshot_metadata | 4 | 0.003281 |
| merge-profile-10m | committed->profile | fs.sync_all | 11 | 0.592184 |
| merge-profile-10m | committed->profile | fs.sync_data | 40 | 11.973777 |
| merge-profile-10m | committed->profile | heap.append_page | 1 | 0.001177 |
| merge-profile-10m | committed->profile | heap.checksum | 270,377 | 1.911971 |
| merge-profile-10m | committed->profile | heap.free_space_lookup | 100 | 0.000003 |
| merge-profile-10m | committed->profile | heap.fsync | 19 | 2.114602 |
| merge-profile-10m | committed->profile | heap.write_page | 1 | 0.000121 |
| merge-profile-10m | committed->profile | index.checksum_page | 453,168 | 3.263753 |
| merge-profile-10m | committed->profile | index.decode_node | 453,164 | 6.620000 |
| merge-profile-10m | committed->profile | index.read_node | 453,164 | 9.425686 |
| merge-profile-10m | committed->profile | storage.encode | 100 | 0.000022 |
| merge-profile-10m | committed->profile | storage.flush_all | 18 | 2.113726 |
| merge-profile-10m | committed->profile | wal.bytes | 1,816,221,398 | 0.000000 |
| merge-profile-10m | committed->profile | wal.fsync | 8 | 9.408208 |
| merge-profile-10m | committed->profile | wal.install_snapshot | 2 | 15.674327 |
| merge-profile-10m | committed->profile | wal.snapshot_read | 20 | 0.816821 |
| merge-profile-10m | committed->profile | wal.write_record | 1,746 | 2.239731 |
| merge-profile-10m | committed->profile | wal.write_transaction_snapshot | 2 | 12.849373 |

## Regression, crash and longevity gates

Final source: **71 distinct Rust tests passed**: 68 routine tests plus the three existing long tests run explicitly. No failing test was deleted or skipped. Formatting, strict workspace Clippy with all targets/features and `-D warnings`, workspace tests and Phase 8 passed after every kept optimization. The final Phase 8 run reached its success marker and includes Phase 7. Rustdoc and release build passed.

Final-source controlled process crashes: **1,000 cycles across 11 points passed**. The prior heap and index candidates each also passed 1,000 cycles; those are separate source states, not 3,000 cycles on final source. Every cycle checks two reopens, expected rows, integrity and cleanup. Dirty private staging, large staging, pre/post WAL sync, Commit record, pre/during installation, checkpoint, index update and backup preparation are covered. These are process kills, not hardware power-loss tests; large staging hooks use 1,001 rows, not 10M for every cycle. The full 10M suite also passed three large recovery samples.

Two-hour soak: **PASS**, requested 7200 seconds, observed 7200.952 seconds, 68,201 successful mixed cycles. After warmup, private-byte change 3,448,832, handle change 0; peak handles 93, peak private bytes 11,943,936. The finite-run budgets are +128 MiB private bytes and +64 handles after warmup; this is evidence over two hours, not a proof against every possible leak. All workload assertions passed, implying zero unexpected errors/lock timeouts. Database, backup and restored directories were removed at completion. Every 100 cycles includes offline backup/restore/integrity. The soak uses coordinator sessions; TCP/TLS lifecycle is a separate gate.

The supplemental filesystem sampler records WAL directory-entry sizes and temporary directory presence. Windows metadata can lag open-file writes; samples are not exact peak WAL volume. Raw resource and per-cycle CSVs retain memory, handles and throughput drift; final-summary.json contains fifteen-minute throughput windows.

Final security/operations checks include the Phase 7 suite, server resource regressions and 25 live TLS/auth/start-stop/backup/restore cycles. They retain role enforcement, certificate validation, non-loopback safeguards, data-directory locking, connection and result limits, lock timeouts, metrics and strict Windows cleanup.

| Soak interval (minutes) | Successful cycles | Cycles/second |
|---|---:|---:|
| 0–15 | 11,799 | 13.110 |
| 15–30 | 10,841 | 12.046 |
| 30–45 | 9,241 | 10.268 |
| 45–60 | 8,318 | 9.242 |
| 60–75 | 7,652 | 8.502 |
| 75–90 | 7,161 | 7.957 |
| 90–105 | 6,817 | 7.574 |
| 105–120 | 6,371 | 7.079 |

Throughput changed from 13.110 cycles/second in the first 15-minute interval to 7.079 in the last (-46.0%). This observed drift is retained; the existing soak gate enforces correctness and resource growth, not a throughput threshold. Separate soak profiling would be needed to apportion its causes.

Supplemental samples: 1,429; peak observed database-file bytes 7,440,985; peak observed WAL-file bytes 1,606,365; peak observed private staging directories 1. Sampling began about one minute into the soak. Filesystem races during normal lifecycle changes are counted separately from engine errors. This workload has stable logical row count; unreclaimed heap tombstones can still increase physical size and full-image commit cost.

## Failures retained and remaining limits

The original 10M timeout after 3,600.0538 seconds with approximately 4.7M uncommitted rows is preserved, including its recovery proof of zero visible uncommitted rows. The index candidate committed 10M in 1,645.8528257 seconds but timed out in group aggregation under the original whole-suite cap. Final merge source committed in 1,610.5079624 seconds but reached that whole-suite cap during concurrent writes. Neither whole-suite timeout is called a pass. The complete rerun uses the explicit separate limits described above. The wrapper has passing fast-run and intentional zero-budget rejection tests. The baseline duplicate-separator failure is retained.

Small commits at 10M still incur expensive full file-image WAL and installation work. Coarse transaction ownership, materialized query results, one spill reader per run, the 1 MiB network response limit, limited SQL coverage, heap tombstones and non-merging B+ tree deletion remain. The optimization does not establish PostgreSQL parity.

PostgreSQL comparison is the outstanding external certification gate. Follow `benchmarks/compare_postgresql/README.md` for PostgreSQL 18 setup with checksums, `fsync=on`, `synchronous_commit=on`, `full_page_writes=on`, matched schema and loopback TCP. PostgreSQL 18.6 was the supported current minor checked for this campaign; use the current supported 18.x patch when installing. Official references: [version support](https://www.postgresql.org/support/versioning/), [Windows installer](https://www.postgresql.org/download/windows/), [initdb](https://www.postgresql.org/docs/18/app-initdb.html). Run both engines through the same Python TCP driver on this hardware; do not compare these embedded Phobos timings with PostgreSQL TCP timings. No installation was performed.

## Reproduction

Extract the source archive, keeping run-complete-suite.ps1 beside the phobos directory. Use PowerShell, pinned Rust 1.85.0 MSVC and Python with cryptography. All evidence directories must be new. The delivered raw results are immutable audit inputs.

```powershell
cd phobos
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace
cargo test -p phobos-validation -- --ignored --test-threads=1
cargo build --release --workspace
..\run-complete-suite.ps1 -Rows 10000000 -Samples 3 -Operations 3 -Connections 4 -Mode suite -BulkTimeoutSeconds 3600 -TimeoutSeconds 7200 -OutputDirectory benchmarks/repro/10m
.\target\release\beta-check.exe benchmarks/repro/10m/data/base 10000000 benchmarks/repro/correctness-10m
cargo build --release -p phobos-bench --features profiling --target-dir target/profile
.\tools\run-benchmarks.ps1 -Rows 10000000 -Mode bulk -Samples 1 -Operations 1 -Executable target/profile/release/phobos-bench.exe -OutputDirectory benchmarks/repro/profile-10m
cargo build --release -p phobos-validation --features certification --target-dir target/certification
.\target\certification\release\beta-crash.exe parent benchmarks/repro/crash 1000
.\tools\beta-soak.ps1 -Seconds 7200 -OutputDirectory benchmarks/repro/soak
.\tools\beta-large.ps1 -Rows 1000000 -EvidenceDirectory benchmarks/repro-final
.\tools\phase8-validation.ps1 -Python python
cargo test -p phobos-server beta_
python tools/beta-security.py --out benchmarks/repro/security --cycles 25
cargo doc --workspace --no-deps
cargo build --release --workspace
```

Normal distribution binaries exclude certification crash hooks and profiling. Packaging fixes ZIP ordering/timestamps and verifies content hashes; identical native binary output across different MSVC installations or build paths is not promised. Use the delivered changed-files.json and writepath-final.patch for the exact change inventory against the prior Beta candidate. Prior reports and source are preserved in the audit archives. No beta-certification success banner was emitted.
