# C5 heap/session integration progress — NOT frozen

The SQL/server MVCC route is still disabled. This increment does **not** satisfy
C5 acceptance, and its correctness checks are not the full Fast gate. C6 has not
started. The approved stable reservation and WAL-chain mapping remain unchanged.

## Implemented and checked

* WAL capability 4 (retained anchor flags 3) explicitly requires heap page version
  3 with PHMV version-1 tuple envelopes. Legacy capability 1/2 heaps remain legacy;
  capability 3 preserves the approved stable-identity-only format. WAL append,
  scanning, page publication and replay reject inconsistent heap formats. Page
  stamping preserves the tuple capability instead of downgrading it to version 2.
* `phobos-admin migrate-mvcc-copy SOURCE BACKUP NEW_DESTINATION` locks the source,
  forces a complete backup first, recovers a working copy, converts in a separate
  staging directory, rebuilds indexes for the new physical RIDs, validates and
  forces output, closes handles, then publishes the new destination by rename.
  Source data is never recovered or rewritten. The existing source and backup
  remain usable with C4. Only eligible V2 capability 1/2 sources are accepted.
* The source, backup and destination must be disjoint. The backup must be empty;
  the destination must not exist, and its parent must already exist. Rows whose
  existing payload plus the 48-byte envelope cannot fit a page fail conversion
  safely. Abandoned hidden staging/working directories are retained on failure;
  there is no automated resume or source-switch operation.
* The migration preserves authentication data and includes `phobos.mvcc-status`
  in database-file enumeration. It uses bounded page buffers and a single mapped,
  WAL-protected conversion transaction. All migrated rows have stable creator 1
  and nonzero table-local logical IDs. Index definitions and public row codecs
  are preserved. Runtime historical-index uniqueness is not yet integrated.
* SessionManager owns bounded per-session Idle/Active/Committing state, stable ID
  allocation, failed-transaction state, disconnect/abort handling, and commit
  permits. A disconnected submitted commit remains owned by its commit permit.
  Failed/abandoned publication fences the manager and never falsely aborts a
  durable transaction. Receipt validation precedes the installation callback.
* Snapshot pins now have RAII release. Statement objects retain pins and can be
  shared by heap readers using Arc. The final statement owner releases the pin
  and clears the session's statement flag. Session generation identity prevents
  a stale statement from changing a reused connection ID. Unwinding releases
  pins; deliberately leaked pins conservatively retain the reclamation horizon
  and consume bounded capacity. Unknown/poisoned state fails closed.
* Versioned heap insert/get/scan decode envelopes explicitly. Ordinary heap
  `get`, `scan` and `scan_visit` apply visibility when given a statement reader;
  versioned heaps without a statement cannot use legacy row methods. A statement
  is checked against the canonical database directory before binding a reader.
* Independent read-only committed leases bypass active private pages and pending
  WAL generations. They share acknowledged dirty images, use a fresh bounded
  cache per statement, and capture a traversal page bound. Private writes are
  prohibited on those handles. The final logical reader/writer closes the file;
  background-worker Arc references cannot prolong Windows file handles. Runtime
  admission must still retain database/WAL ownership until all readers finish.
* Private-page owners and tuple creators match the stable ID on mapped receipts;
  legacy receipts retain chain-ID behavior. Pending installation still follows
  queue order. Page-LSN and capability checks now also cover capabilities 3/4,
  including committed-buffer publication. C1 group forcing is unchanged.
* Heap UPDATE creates a successor with the same logical ID and a previous-RID
  link; DELETE sets the deleting stable ID without destroying the old payload.
  Both require private ownership and reject a changed/deleted expected head.
  The caller must own and recheck the logical row; that runtime ownership is not
  implemented yet. Any mutation failure requires transaction rollback/fencing.

## Evidence and limits

`work/write-v3/evidence/c5-heap-migration-03/cli-smoke.json` records an actual CLI
copy migration. The frozen C4 admin binary rejects the destination with
`InvalidWal: unsupported V2 WAL flags`; every destination file hash remains
unchanged. The current admin also refuses unintegrated MVCC integrity/open paths
without changing destination bytes. This fixture has no user data.

`work/write-v3/evidence/c5-heap-session-04` contains the final component gate for
this increment, with engine hashes and counts in `result.json`. The reproducible
command, from this source directory, is:

```powershell
.\tools\write-v3-c5-component-checks.ps1 -OutputDirectory C:\path\to\new-evidence
```

It runs formatting, strict workspace/all-target/all-feature Clippy, all workspace
tests, documentation and an admin build. C5 cases include 20 stable-identity
crashes, 20 copy-migration crashes and four earlier status crashes; inherited
C1-C4 regression tests also run. No tests are filtered out. Three pre-existing
long-soak tests remain ignored as before. This is a component-check command, not
a replacement or a passing marker for the requested C5 Fast campaign.

New integrated heap tests prove reader progress on another thread while UPDATE
is private, own-version lookup, old-statement visibility after publication,
fresh-statement visibility, linked RIDs, DELETE rollback, rejection of stale
heads, read-only enforcement, and pin retention by heap owners. A committed update
is recovered twice from WAL while its heap file had remained zero bytes. These
are heap/session tests, **not SQL/TCP acceptance tests or physical crash cycles**.

Earlier evidence is retained. `c5-heap-migration-01` encountered an existing
timestamp-only catalog test-directory collision. A parallel name-generation
regression reproduced 6,986 unique paths out of 8,000, rather than relying on a
timing hypothesis. A PID/atomic-sequence suffix fixes the test helper; production
catalog behavior is unchanged. Subsequent gates pass without warning suppression
or deletion of tests.

## Work still required before enabling or freezing C5

1. Wire SessionManager and statement lifetimes into Coordinator/TCP execution,
   cancellation/disconnect and database shutdown; keep WAL ownership through
   active streams. Add bounded session-owned logical deltas and own-write overlay
   merging for fresh Read Committed statements.
2. Rebase those resolved row deltas under ordered preparation/publication. Two
   independently prepared full-page images for disjoint rows on the same page
   cannot be installed successively without losing one writer's changes. Stable
   owner IDs alone do not solve this. Do not re-execute arbitrary SQL at COMMIT.
3. Preserve historical index entries and implement logical unique checks, including
   composite/NULL keys. Index point/range access needs visibility filtering and
   structural publication coordination; tuple visibility alone cannot make a
   partially installed B+tree split safe for concurrent readers.
4. Connect all SQL sequential/index/join/group/stream paths and versioned mutations;
   implement logical-row/key ownership, bounded waits, deterministic victim policy,
   stale-head and uniqueness rechecks after wakeup, and bounded reclamation hooks.
5. Integrate status-aware open/admin integrity and C4 incremental retirement with
   the durable visibility frontier. Incremental MVCC retirement remains explicitly
   rejected. Legacy C1-C4 paths continue to work.
6. Prove full SQL/session correctness and recovery; run the normal Fast gate and
   required 100K/1M reader/writer/conflict/status/visibility measurements. No C5
   performance results or full Fast acceptance are claimed. No PostgreSQL rerun,
   10M run or long soak was performed.

These are remaining engineering tasks, not a proven architectural impossibility.
No additional approval is needed to continue the already-authorized C5 work.
