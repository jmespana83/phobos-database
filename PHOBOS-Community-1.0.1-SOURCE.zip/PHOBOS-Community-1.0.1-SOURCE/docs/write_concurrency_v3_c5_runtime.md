# C5 runtime SQL integration — historical approved increment

This is the historical runtime-increment record. Current acceptance status and
subsequent changes are in [the C5 acceptance report](write_concurrency_v3_c5_acceptance.md).

Capability-4 databases now route ordinary server reads and DML through MVCC.
The legacy C1–C4 database route remains available with its existing format and
ownership behavior. Stable MVCC identity reservation, mapped WAL-chain encoding,
and C1 opaque group-durability receipts are unchanged. C6 has not started.

This report supersedes the runtime-disabled status in the historical
`write_concurrency_v3_c5_heap_sessions.md` report. It does not claim complete C5
acceptance or a performance improvement.

## Runtime lifecycle

Each SQL connection owns its stable-ID session context and a bounded retained
logical write set. Statements use RAII snapshot pins and independent committed
heap/index readers. Own writes are immutable statement overlays; their synthetic
record IDs never enter WAL or persistent pages. UPDATE creates linked versions;
DELETE records the deleting stable identity. Old tuples and index entries remain
available to pinned snapshots.

Logical-row and non-NULL unique-key ownership uses wait-die: younger transactions
are victims; older transactions may wait for a bounded interval. After wakeup the
runtime reconstructs its committed readers, checks the expected row version, and
validates uniqueness against a fresh publication snapshot. Unique validation
visits bounded index batches rather than materializing all historical versions.
Missing physical references fail closed. Ownership is released after publication
or rollback, not after WAL append alone.

The commit queue gathers at most 64 requests. Under ordered publication ownership,
resolved logical changes are rebased on the latest pending/committed heap pages;
SQL expressions are not reevaluated. WAL append/force uses the separate writer
mutex. Complete durable receipts authorize heap/index installation followed by
transaction-status publication. Failure after durability fences the runtime.
The existing one-MiB WAL batch boundary splits oversized successors without losing
their private state. This is a correctness foundation: physical rebasing and
installation still serialize and are not claimed to match C2 performance.

Index streaming re-seeks bounded batches under the publication read guard and
releases that guard before delivering rows. Heap visibility uses the statement's
original snapshot even when a later writer publishes. Re-seeking accounts for
legacy equal keys whose RIDs are not globally sorted across leaf splits.

MVCC open now uses the existing environment-derived dirty-page flush settings.
Full and incremental checkpoints force visibility state before authorizing WAL
retirement. Incremental retirement retains later complete mapped chains; snapshot
pins separately constrain the reclamation horizon. No physical VACUUM runs.

## Offline integrity

The source remains exclusively locked. Capability-4 integrity checking copies
its database files to a unique temporary directory and performs visibility-aware
recovery there. This includes acknowledged pages that are still only in WAL.
It then verifies required catalogs/heaps/indexes, tuple envelopes and committed
identities, predecessor/deleter linkage, strictly descending chain commit
sequences, index key/RID correspondence, exactly one index entry per physical
version, and uniqueness of visible non-NULL keys.

Recovery, catalog, heap, index and status handles leave scope before temporary
cleanup. The source is never repaired by an integrity check. Backup/restore retain
WAL plus transaction status. Legacy integrity and migration eligibility remain
unchanged. Capability-3 identity-only databases remain unsupported for SQL and
admin integrity.

## Evidence

Final recorded correctness gate: `work/write-v3/evidence/c5-runtime-07`.
Run from the C5 repository:

```powershell
.\tools\write-v3-c5-runtime-checks.ps1 -OutputDirectory <new-evidence-directory>
```

The script runs formatting, strict all-target/all-feature Clippy, all workspace
tests, and documentation. Raw logs and an engine-source manifest are retained. Final result: **188 passed,
0 failed, 3 pre-existing ignored long soaks**; formatting, strict Clippy and docs
passed. Engine hashes were rechecked after the gate. The exact 30 changed/new
files versus the approved heap/session increment are recorded in
`changed-since-heap-session-04.json` in that evidence directory.
The 24 new runtime crash cases are six boundaries repeated four times:

- durable WAL before visibility publication;
- COMMIT returned and its acknowledgment marker forced, with dirty pages unflushed;
- background flush after a page write;
- eviction flush after a page write;
- checkpoint drain after a page write;
- visibility status forced before full WAL retirement.

Children exit directly at a directory-scoped hook without Rust destructors. Each
case passes source-preserving offline integrity, SQL recovery twice, committed
UPDATE/DELETE/INSERT checks, and absence of the abandoned transaction's row.
One case per boundary additionally checks backup/restore. The eviction test parks
the background worker at a synchronization boundary so it cannot consume the
victim first; no timed sleep/retry is the correctness mechanism.

Focused SQL tests cover a real TCP paused writer, own writes, statement refresh,
rollback, younger same-row victims, disjoint-row progress, composite uniqueness,
NULL allowance, older unique wait followed by commit/rollback, and stale row-head
recheck. Stream tests pause delivery across 512-row publication and duplicate-key
index batches, and prove pin release on delivery errors. Separate tests cover
oversized same-heap WAL batch splits and incremental visibility retirement with
reverse commit order plus a later WAL tail. Nine corruption variants are rejected
without source changes, including missing catalogs and broken status/index/chain
state. Inherited C5 component crash tests and C1–C4 regression tests also run;
the 24-case count describes the new runtime campaign only.

## Remaining C5 acceptance work

C5 is NOT frozen. The current increment has not run the full 100K/1M Fast
performance campaign. No C5 reader/writer TPS, wait-cost, snapshot/visibility,
status-I/O or uniqueness-cost measurements are claimed. PostgreSQL, 10M and long
soaks were not run.

Capability-4 DDL/ANALYZE still requires schema/session integration; those commands
fail closed rather than using a legacy mutator on versioned pages. The legacy
route retains its existing functionality. Broader normal-path MVCC joins/grouping
acceptance, complete concurrent writer measurements, bounded transient write
resolution, and abandoned-private-directory housekeeping remain to be completed
and audited before C5 freeze. Existing statement pins constrain reclamation;
physical version reclamation is deliberately absent.
