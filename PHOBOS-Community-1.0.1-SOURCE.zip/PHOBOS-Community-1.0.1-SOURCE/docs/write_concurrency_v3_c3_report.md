# Write & Concurrency V3 — C3 acceptance report

C3 is independently runnable and frozen after the full Fast gate and evidence review. C4 has not started. C1/C2 frozen deliveries and the saved PostgreSQL baseline remain unchanged.

**Performance remains mixed.** This is a validated bounded-writeback checkpoint, not a general throughput improvement. At 1M, eight shared writers are effectively flat (+0.8%), while eight disjoint writers regress 28.9%. At 100K, eight shared writers regress 38.7%. Synchronous publication time also regresses in several controls. The matched 1M TCP improvement uses the historical C2 baseline and does not override these fresh paired regressions.

## Implementation

Committed page-format-2 heap/index images now publish into a bounded shared store after durable WAL receipts. One background worker writes eligible pages; generation checks preserve redirtied images, and memory pressure invokes safe synchronous eviction. Reads, virtual lengths and rollback metadata consult committed frames. The existing exclusive checkpoint drains and forces before WAL retirement. New-file DDL and legacy formats keep conservative installation. No on-disk format or migration change was made.

C1 group commit and C2 preparation/publication ordering remain intact. COMMIT is acknowledged only after WAL durability and coherent logical publication. Background failure fences the shared store. Explicit shutdown is fallible; default mode drains/checkpoints and joins the worker. See write_concurrency_v3_c3_design.md for ownership, limits, settings and retain-WAL shutdown.

## Validation

- Formatting and formatting check: PASS.
- Strict workspace/all-target/all-feature Clippy with -D warnings: PASS; no new warning suppression.
- Workspace: 151 passed, 0 failed, 3 pre-existing ignored long-soak tests.
- Documentation and normal/profile release builds: PASS.
- Final gate: 50 targeted crash/recovery cycles (40 inherited C1/C2, four C3, six suite cases). Other pre-existing regression subprocesses and development reruns are additional.
- Four C3 process crashes explicitly reach after-ACK/before-writeback, background write, eviction write, and checkpoint-drain write boundaries. All verify the ACK oracle and committed heap/index state on two reopens.
- 100K and 1M embedded suites: 49 records each. Matched Phobos-only TCP suites: 43 successful records each and offline integrity.
- 24 paired normal/profile writer controls: two layouts, two cardinalities, 1/4/8 clients, C2/C3. Three samples of 32 transactions per client; acknowledged payloads verified on two reopens.
- No PostgreSQL connection, 10M workload or long soak. Process crashes do not certify real hardware power-loss behavior.

## Matched TCP latency

Median total milliseconds across three samples. These are three INSERTs per client, not commit-only instrumentation. C2 is the frozen prior measurement; fresh simultaneous-campaign C2/C3 controls follow.

| Rows | Workload | Frozen C2 ms | C3 ms | Change |
| --- | --- | ---: | ---: | ---: |
| 100,000 | 3 autocommits | 12.1809 | 12.0240 | -1.3% |
| 100,000 | 3 inserts / explicit transaction | 4.8323 | 4.9285 | +2.0% |
| 100,000 | 4 clients / 12 autocommits | 51.4683 | 49.3722 | -4.1% |
| 1,000,000 | 3 autocommits | 12.8704 | 11.5899 | -9.9% |
| 1,000,000 | 3 inserts / explicit transaction | 5.3000 | 4.8669 | -8.2% |
| 1,000,000 | 4 clients / 12 autocommits | 71.4479 | 48.2665 | -32.4% |

## Shared steady writers

Normal release median throughput. ACK latency includes queueing, execution, WAL and publication. Setup, warmup, statistics snapshots, shutdown and verification are outside timing. Domains use total cardinality evenly partitioned across one table per client; they are not the saved PostgreSQL shared-table workload.

| Rows | Clients | C2 tx/s | C3 tx/s | Change | C2 p50/p95/p99 ms | C3 p50/p95/p99 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 100,000 | 1 | 110.36 | 81.61 | -26.0% | 7.626 / 11.371 / 65.975 | 9.201 / 22.966 / 74.132 |
| 100,000 | 4 | 169.87 | 135.90 | -20.0% | 22.597 / 28.393 / 41.512 | 24.643 / 52.064 / 79.689 |
| 100,000 | 8 | 201.53 | 123.49 | -38.7% | 37.949 / 54.791 / 93.980 | 54.606 / 99.377 / 141.502 |
| 1,000,000 | 1 | 104.54 | 108.59 | +3.9% | 6.602 / 23.450 / 61.485 | 6.350 / 12.293 / 55.032 |
| 1,000,000 | 4 | 200.47 | 168.74 | -15.8% | 19.412 / 49.017 / 95.790 | 20.994 / 31.944 / 77.398 |
| 1,000,000 | 8 | 155.46 | 156.68 | +0.8% | 39.280 / 90.157 / 108.633 | 48.434 / 89.707 / 116.705 |

## Domains steady writers

Normal release median throughput. ACK latency includes queueing, execution, WAL and publication. Setup, warmup, statistics snapshots, shutdown and verification are outside timing. Domains use total cardinality evenly partitioned across one table per client; they are not the saved PostgreSQL shared-table workload.

| Rows | Clients | C2 tx/s | C3 tx/s | Change | C2 p50/p95/p99 ms | C3 p50/p95/p99 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 100,000 | 1 | 139.48 | 188.02 | +34.8% | 5.845 / 9.489 / 36.604 | 5.076 / 5.881 / 13.825 |
| 100,000 | 4 | 168.78 | 111.30 | -34.1% | 21.480 / 42.025 / 75.487 | 27.252 / 65.044 / 86.337 |
| 100,000 | 8 | 203.52 | 383.22 | +88.3% | 31.162 / 69.307 / 125.615 | 18.745 / 61.020 / 86.232 |
| 1,000,000 | 1 | 168.45 | 147.58 | -12.4% | 5.660 / 15.214 / 26.947 | 6.261 / 12.279 / 17.504 |
| 1,000,000 | 4 | 145.73 | 169.15 | +16.1% | 20.468 / 65.331 / 99.563 | 18.202 / 54.345 / 96.649 |
| 1,000,000 | 8 | 284.54 | 202.30 | -28.9% | 24.842 / 109.213 / 151.213 | 29.961 / 72.722 / 178.272 |

## Publication, writeback and group durability

Separate profiling builds; aggregate three samples. Publication excludes WAL force and checkpoint; domains use C2’s existing independent-publication span. Background time is inclusive batch wall time and can overlap execution. C2 has no dirty-frame telemetry. Logical publication still visits and retires bounded scratch; it is not zero-cost.

| Layout / rows / clients | C2 publication ms/tx | C3 publication ms/tx | C2 tx/commit force | C3 tx/commit force | C3 background pages | C3 checkpoint pages | C3 background ms/tx |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| shared/100,000/1 | 5.7192 | 5.3762 | 1.000 | 1.000 | 117 | 0 | 0.0625 |
| shared/100,000/4 | 2.2806 | 3.1497 | 2.000 | 2.000 | 304 | 12 | 0.0215 |
| shared/100,000/8 | 2.2517 | 2.5920 | 4.000 | 4.021 | 498 | 23 | 0.0172 |
| shared/1,000,000/1 | 4.4071 | 3.7951 | 1.000 | 1.000 | 78 | 0 | 0.0234 |
| shared/1,000,000/4 | 2.1256 | 2.2714 | 2.000 | 2.000 | 282 | 12 | 0.0158 |
| shared/1,000,000/8 | 1.9229 | 2.4266 | 4.000 | 4.000 | 529 | 14 | 0.0176 |
| domains/100,000/1 | 2.7329 | 2.1533 | 1.000 | 1.000 | 81 | 0 | 0.0250 |
| domains/100,000/4 | 2.3866 | 2.6944 | 2.000 | 2.000 | 698 | 27 | 0.0463 |
| domains/100,000/8 | 1.5912 | 1.8864 | 4.000 | 4.063 | 1480 | 40 | 0.0369 |
| domains/1,000,000/1 | 2.1891 | 2.1674 | 1.000 | 1.000 | 78 | 0 | 0.0615 |
| domains/1,000,000/4 | 2.8125 | 2.5362 | 2.000 | 2.000 | 729 | 18 | 0.0294 |
| domains/1,000,000/8 | 1.8432 | 1.9406 | 4.000 | 4.000 | 1497 | 15 | 0.0311 |

### Preserved WAL work: 1M / eight clients

Instrumented totals across three samples; published images count logical publication, not physical writes.

| Layout | Engine | Commits | Commit forces | WAL bytes | Published images |
| --- | --- | ---: | ---: | ---: | ---: |
| shared | C2 | 768 | 192 | 12,893,286 | 1,554 |
| shared | C3 | 768 | 192 | 12,893,406 | 1,554 |
| domains | C2 | 768 | 192 | 12,744,912 | 1,536 |
| domains | C3 | 768 | 192 | 12,744,912 | 1,536 |

## Normal-build dirty memory and WAL frontier

Peak entries are per sample; writes/bytes below subtract the warmup snapshot. LSN columns show the final snapshot of each sample as durable WAL / maximum published page. Retained WAL remains authoritative for frames and written-but-unforced pages. Physical write counts can fall below logical published-image counts through coalescing and unflushed ending frames. Shutdown drain is outside the timed snapshots; background batches can straddle snapshot boundaries. The WAL frontier is the highest durable commit receipt observed by the store, conservatively excluding later anchor forces.

| Layout / rows / clients | Peak dirty entries | Dirty after each sample | Pages / bytes written | WAL / page LSN per sample |
| --- | ---: | --- | ---: | --- |
| shared/100,000/1 | 5 | 2, 2, 2 | 121 / 991,232 | 1268/1267; 1268/1267; 1268/1267 |
| shared/100,000/4 | 5 | 0, 0, 0 | 298 / 2,441,216 | 1653/1652; 1653/1652; 1653/1652 |
| shared/100,000/8 | 5 | 0, 1, 2 | 571 / 4,677,632 | 2170/2169; 2170/2169; 2170/2169 |
| shared/1,000,000/1 | 2 | 2, 2, 2 | 85 / 696,320 | 11242/11241; 11242/11241; 11242/11241 |
| shared/1,000,000/4 | 5 | 0, 0, 0 | 278 / 2,277,376 | 11630/11629; 11630/11629; 11630/11629 |
| shared/1,000,000/8 | 5 | 2, 3, 1 | 512 / 4,194,304 | 12147/12146; 12147/12146; 12147/12146 |
| domains/100,000/1 | 5 | 0, 2, 2 | 71 / 581,632 | 1260/1259; 1260/1259; 1260/1259 |
| domains/100,000/4 | 8 | 0, 6, 8 | 757 / 6,201,344 | 1698/1697; 1698/1697; 1698/1697 |
| domains/100,000/8 | 16 | 2, 2, 16 | 1514 / 12,402,688 | 2280/2279; 2280/2279; 2280/2279 |
| domains/1,000,000/1 | 2 | 2, 2, 2 | 82 / 671,744 | 11234/11233; 11234/11233; 11234/11233 |
| domains/1,000,000/4 | 8 | 3, 6, 6 | 757 / 6,201,344 | 11675/11674; 11675/11674; 11675/11674 |
| domains/1,000,000/8 | 16 | 2, 6, 0 | 1531 / 12,541,952 | 12257/12256; 12257/12256; 12257/12256 |

## Limits and interpretation

The data above retain every regression; three samples are development evidence, not a statistical guarantee. Shared-table execution and explicit transactions retain strict C1 ownership. C3 moves eligible base-page writes out of publication, while checksum validation, frame transfer, scratch cleanup and conservative periodic checkpoint remain synchronous. C4 checkpoint redesign and MVCC work have not started.

C2 controls come from a hash-verified disposable copy of the frozen archive, with only an inclusive profiling span added around existing publication. Its timed harness is unchanged. C3 adds statistics snapshots and explicit shutdown outside the timed region. Normal and profiling builds are separate; profiling, certification and test-hooks features are disabled in normal builds. Existing explicit legacy crash environment hooks are retained for the inherited benchmark recovery cases.

Saved PostgreSQL CSV SHA256: 047e2ad0cb660845ddbe3f691817a0a4c49b9f2de2cfe1a1ff058234f54c889e. It was not rerun. No PostgreSQL parity claim follows from disjoint-table diagnostics.

## Exact files and reproduction

The delivery’s changed-files.json and source-files.json give exact paths and SHA256 values. Production changes are in storage committed_pages/page_io and heap forwarding, index forwarding, execution lifecycle/domain store sharing and publication spans, server shutdown/stats, and benchmark telemetry. New focused tests and test-only hook dependencies, C3 Fast tooling, design/report and status links complete the change.

```powershell
.\tools\write-v3-validation.ps1 -Checkpoint C3 `
  -OutputDirectory C:\phobos-benchmark\c3-new-evidence `
  -Python C:\path\to\comparison-venv\Scripts\python.exe `
  -C2SourceArchive C:\path\to\phobos-c2-source.zip
```

Use Rust 1.85 MSVC and the repository comparison Python dependencies. The output directory must be new. The gate fixes 8192 dirty pages, 128 pages/batch, 10 ms wake, drain shutdown and C1 group window zero. Compact evidence retains raw logs/CSV/profiles and control sources; reproducible fixture databases and compiler targets are excluded. Earlier failures and stopped attempts are in validation-history.md.

Markers: PHOBOS WRITE V3 C3 FAST GATES PASSED and PHOBOS WRITE V3 C3 CHECKPOINT PASSED. C4 has not started.
