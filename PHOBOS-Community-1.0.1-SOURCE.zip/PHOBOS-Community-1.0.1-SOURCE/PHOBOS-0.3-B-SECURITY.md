# PHOBOS 0.3-B packaging security

## Credentials

Fresh setup has no default password. The native form masks password and confirmation fields. It passes the password to `phobos-admin user-add-stdin` through redirected stdin, then uses the existing public auth frame for the readiness check. No password is passed in argv, environment variables, installer logs, registry, instance JSON or a temporary response file. The persistent auth file contains the existing PHOBOS password hash format. The setup helper does not log its secret input, and protocol errors are reported without including credential payloads.

Password controls are cleared after use; wire buffers are explicitly cleared. .NET strings and the inherited auth process can retain transient copies until memory is reclaimed. This is not a secure-heap guarantee. Do not enable full process dumps for setup/auth tools, and treat administrator-accessible diagnostic dumps as sensitive; this milestone cannot prevent an administrator or OS-level dump policy from reading process memory. No crash report upload/dump facility is added by PHOBOS packaging. The supplied validation runner generates credentials in memory and scans retained instance artifacts for the test secret after shutdown.

## Filesystem and executable boundary

- Binary directory: Administrators/SYSTEM FullControl, Users Read/Execute; protected inheritance and Administrators ownership.
- Config/auth directory: Administrators/SYSTEM FullControl, the instance service SID Read/Execute; no Users/Everyone access.
- Data/log/control directories: Administrators/SYSTEM FullControl, the instance service SID Modify; no shared LocalService write grant.
- Newly needed parent directories are secured; existing parents that permit non-administrator replacement/DACL manipulation are rejected. User-profile installation locations are not supported for a privileged service.
- Canonical local paths only; no UNC paths, drive roots, parent-directory components or reparse points in configured path ancestors. Binary/data/config/log/control directories must be distinct and non-nested. New-instance directories must be empty.

The service runs as LocalService, **not LocalSystem**, with its own enabled service SID. ACL access is granted to that SID rather than the shared LocalService SID. This is not a complete isolation boundary against other processes sharing the same Windows account, nor a sandbox against administrators. Executables are launched by absolute paths with quoted arguments, from the protected binary directory, with a minimal system PATH. Child PHOBOS and CLR-injection environment overrides are removed. No downloaded DLL is searched from the data directory. This foundation does not claim a hostile-administrator threat model or a complete DLL-load hardening proof across all Windows versions.

## Network and lifecycle

Loopback-only by design in this release. Remote selection and firewall provisioning are deferred, so no installer-created or unrelated firewall rules are added/removed. Local TCP is the normal PHOBOS protocol; TLS PKI provisioning is not added. Authentication is not weakened. Missing auth causes startup refusal. An occupied port reports a listening PID when available and is never resolved by killing another process or silently changing ports.

The instance helper verifies the owned service's executable/config path and account before lifecycle operations. Normal stop uses the existing graceful marker. Crash-only job containment is documented separately. No automatic restart policy is configured, preventing restart loops from hiding startup failures. Logs are private but retention is manual.

## Repair, uninstall and privileges

Setup and lifecycle administration require an elevated Windows token. The non-elevated rejection is tested. Metadata is protected before secret initialization. A durable initialization state prevents blind reinitialization after an interrupted attempt. Existing data/auth/config are preserved on repair and uninstall. Service stop/removal failure blocks uninstall rather than removing live binaries. No destructive uninstall switch is implemented: deletion of data is a separate, deliberate administrator operation after backup verification.

Same-version repair is tested; arbitrary cross-version upgrades and complete interrupted-install rollback are not claimed. The installer leaves tools/data available after failed post-copy configuration and clearly reports that the instance is not ready. The new release does not silently reinterpret existing binary formats.

## Supply chain and signing

PHOBOS installer and executables are **unsigned**. Verify SHA-256 through a trusted channel; SmartScreen may warn. The build validates the downloaded Microsoft redistributable's Authenticode signature and publisher. Inno Setup's compiler installer was downloaded from its official release and its signature verified. These vendor signatures do not sign PHOBOS. Signing hooks are documented but no certificate is fabricated or claimed.

The bundled Visual C++ runtime is shared system software and is retained on uninstall. Its clean-machine install/reboot branches require clean-VM qualification; passing on a developer workstation with the prerequisite already installed is not equivalent coverage. Framework 4.8 is checked, not downloaded automatically.

## Remaining qualification

Read the test report for actual results. A broad Windows/AV/domain-policy matrix, actual machine shutdown/reboot, forced interruption at every installer phase, full dump-policy behavior, long-running log retention, accessibility/high-DPI qualification and a new clean VM without runtimes remain future release qualification. The two-hour milestone delivers a working foundation, not a claim that these omitted scenarios passed.
