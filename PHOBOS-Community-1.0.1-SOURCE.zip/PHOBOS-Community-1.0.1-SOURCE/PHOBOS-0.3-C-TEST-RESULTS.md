# PHOBOS Studio 0.3-C — Test results

Date: October 23, 2026. Windows x64; .NET SDK 10.0.402; Avalonia 11.3.13. Accepted server engine binaries from 0.3-B/0.3-A were used unchanged. Tests use fresh isolated database directories and generated in-memory credentials.

## Passed client/engine integration

- Local IP and remote-style localhost hostname/port connections, authentication, wrong-password rejection, unavailable server and explicit reconnect.
- Management API v1 capability detection; tables, columns, ordered index metadata and constraints; refresh after column rename.
- INSERT, UPDATE, SELECT, BEGIN/ROLLBACK, CTE, alias/self-join and scalar subquery. Syntax/execution errors close the streaming session and require reconnect as documented.
- All nine typed wire values: NULL, Int64, Boolean, Float64, Unicode text, binary, date, timestamp and exact decimal. Empty text is distinct from NULL. Decimal precision/scale is asserted.
- 5,000 rows across multiple bounded streaming batches. A deliberately lower row budget causes explicit abort and connection disposal.
- Actual sufficiently long cross join cancelled via an authenticated second connection; target returned StatementCancelled and became unusable until reconnect.
- Deliberate isolated server termination produces a closed client; server restart/WAL recovery preserves committed data, with no replay. Offline integrity passes after testing.
- SQL document create/save/open, modified-state tracking and password-free profile serialization. Closed fixture artifacts scanned for the generated plaintext credential.

## Passed hostile-peer / TLS tests

Oversized frame declaration, bad magic, flags, request ID, premature EOF and invalid UTF-8 are rejected. Typed-stream fixtures exercise wrong sequence, column count, unknown type, invalid Boolean, trailing bytes, incorrect End totals, truncation and duplicate Start. Future API version 2 disables metadata/templates while SQL remains usable. TLS rejects an untrusted self-signed server certificate.

## GUI checks and evidence

A validation-only build launches the real Avalonia application, authenticates against the real fixture, executes through the same handlers and renders the actual controls. It checks selected-SQL execution (invalid unselected prefix ignored), multiple editor tabs and unsaved-close Cancel retaining the tab. Images cover the connection dialog, connected window, expanded catalog, editor/results, Messages/error state, light/dark themes and real Windows service status. Images were visually inspected. These are application-rendered screenshots; they are not a full external mouse/keyboard automation or accessibility audit.

## Windows integration

An elevated test installed the accepted 0.3-B package into dedicated Program Files/ProgramData PHOBOS-03C-Validation directories. Studio's adapter discovered its real HKLM metadata and Running status. The actual Studio --service-action helper performed Stop, Start and Restart through SCM; a subsequent Studio session read the committed row. Unknown registry instance keys were rejected. The accepted uninstaller removed test registration/service/binaries and preserved test data. No primary user database was selected. Test data remains in C:/ProgramData/PHOBOS-03C-Validation.

The suite exercised the privileged helper under an elevated test parent. The GUI's runas launch path is implemented, but a separate manual click-through of every UAC deny/approve combination is not claimed. Normal connection/query rendering runs independently of this service suite.

## Corrections during validation

Initial GUI evidence input used the console's default encoding and failed authentication for a generated Unicode password; the validation-only stdin reader now explicitly uses UTF-8. A TLS fixture initially closed before certificate validation due to Windows certificate-handle loading; loading a PKCS#12-backed fixture certificate corrected it. These were test harness issues; successful reruns are retained. No engine patch was needed. The vulnerable transitive D-Bus dependency was upgraded before release packaging.

## Standalone package lifecycle

The per-user Inno package installed into a fresh workspace test directory. Its self-contained executable opened the real main window, then closed normally through CloseMainWindow. Uninstall removed the Studio executable without touching the server. The first package check exposed an unnecessary unsaved warning caused by welcome SQL; the startup tab is now empty/unmodified and the complete package test passes. Later repackaging updates documentation only; tested production executable hashes are retained in package-tested-hashes.json.

## Qualification limits

No full Standard benchmark was rerun because engine binaries are unchanged. GUI timings are client timings only. No Linux/macOS GUI/package qualification, real remote-host network deployment, trusted-CA PHOBOS TLS integration, mTLS UI, clean Windows VM, screen-reader/high-DPI matrix, very large long-duration UI stress, full native file-picker interaction, OS reboot or production code signing is claimed. Result presentation is bounded collection after streaming completion, not a live incremental grid. One statement/result is supported per execution.

Evidence is under evidence-03c in source and outputs/0.3-C/evidence. Final packaging verification and hash manifests identify delivered bytes separately from validation-only binaries.
