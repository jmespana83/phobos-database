# PHOBOS Community Edition 1.0.1 — Management Api

API v1 uses authenticated SQL and ordinary typed results:

```sql
SHOW CATALOG CAPABILITIES;
SHOW CATALOG TABLES;
SHOW CATALOG COLUMNS;
SHOW CATALOG INDEXES;
SHOW CATALOG CONSTRAINTS;
SHOW CATALOG VIEWS;
SHOW CATALOG COLUMNS FROM customers;
```

TABLES includes base tables and VIEW. COLUMNS includes default_expression/has_default and is_identity/identity_generation. INDEXES gives ordered index columns/uniqueness. CONSTRAINTS describes NOT NULL, UNIQUE INDEX, PRIMARY KEY, CHECK and FOREIGN KEY, including referenced object/column and action fields. VIEWS exposes SQL/dependency count. Capabilities include version, edition, catalog maximum, ddl_core, identity, insert_returning, foreign_keys, views, union, insert_select, correlated_exists and authorization.

Bind by column name and tolerate additive fields. IDs are opaque and instance-local. Hidden allocators are excluded. Metadata reflects the statement catalog generation plus own transactional DDL. Separate requests may race DDL; Studio double-reads and rejects mixed refreshes. View output nullability is conservative; composite constraint rows repeat by column. No GUI should parse internal files. Coarse roles are external; SQL grants are absent.

## Result contracts

All ordinals are one-based BIGINT; IDs are opaque TEXT. Names, SQL definitions, type names and capability values are TEXT. Flags are BOOLEAN. A missing optional value is SQL NULL, never the literal string "NULL". Use the typed protocol to preserve that distinction.

| Query | Columns, in emitted order |
|---|---|
| CAPABILITIES | capability_name, capability_value |
| TABLES | table_id, table_name, table_type, column_count |
| COLUMNS | table_id, table_name, ordinal_position, column_name, data_type, is_nullable, has_default, default_expression, is_identity, identity_generation |
| INDEXES | table_id, table_name, index_id, index_name, is_unique, ordinal_position, column_name |
| CONSTRAINTS | table_id, table_name, constraint_name, constraint_type, ordinal_position, column_name, definition, referenced_table_id, referenced_table_name, referenced_column_name, delete_rule, update_rule |
| VIEWS | view_id, view_name, definition, is_updatable, dependency_count |

TABLES types are TABLE, PARTITIONED TABLE or VIEW. A NOT NULL constraint may have no name. Reference/action fields are NULL for non-FK constraints. identity_generation is ALWAYS or BY DEFAULT only for identity columns. has_default distinguishes an explicit DEFAULT NULL from no default. View is_updatable is false. Group composite constraints/indexes by their identity/name and order by ordinal_position.

Capability names: management_api_version, server_version, edition, ddl_core, identity, insert_returning, foreign_keys, views, union, insert_select, correlated_exists, authorization, licensing_resource_limits, database_scope, catalog_visibility, table_aliases, cancel, multiple_databases, schema_definitions, catalog_format_max. Interpret descriptive values as descriptions, not booleans. An unknown API version should disable object-management assumptions while retaining ordinary SQL connectivity, as Studio does.
