# PHOBOS 0.3-F build and validation commands

All commands ran from `C:\Users\195doctor\Documents\Codex\2026-10-26`, or the extracted source root beneath it. The code block defines paths, not credentials. Retained fixtures are intentionally not overwritten; choose fresh output paths when repeating tests.

```powershell
$root='C:\Users\195doctor\Documents\Codex\2026-10-26'
$src=Join-Path $root 'work03f\PHOBOS-Community-0.3-E-EnterpriseSQLSchemaV2-SOURCE'
$a='C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b\bin'
$e=Join-Path $root 'target03e\release'
$val=Join-Path $root 'validation-03f'
$cargo='C:\Users\195doctor\.cargo\bin\cargo.exe'
$dotnet='C:\Users\195doctor\Documents\Codex\2026-10-23\tools\dotnet\dotnet.exe'
$iscc='C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\inno\ISCC.exe'
$redist='C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\vc_redist.x64.exe'
Set-Location $src
python -X utf8 tools/release-stabilization-03f/check-installer.py
.\packaging\windows\build.ps1 -EngineBinaries $a -Iscc $iscc -VcRedist $redist -OutputDirectory "$root\build03f" -StageDirectory "$root\runtime03f"
$env:AWS_LC_SYS_PREBUILT_NASM='1'
$env:CARGO_TARGET_DIR="$root\profile03f"
& $cargo +stable build --release -p phobos-catalog --example schema_access_profile --locked --offline
& "$root\profile03f\release\examples\schema_access_profile.exe" "$val\profile-fixture" > "$val\profile.csv"
python -X utf8 tools/release-stabilization-03f/micro.py --candidate $e --control $a --out "$val\micro-final" --pairs 7 --operations 1000
.\tools\release-stabilization-03f\benchmark-series.ps1 -Candidate $e -Control $a -WorkRoot "$val\standard" -Pairs 5
python -X utf8 tools/release-stabilization-03f/micro.py --candidate $a --control $a --out "$val\micro-aa" --pairs 7 --operations 1000 --plain-only
python -X utf8 tools/release-stabilization-03f/micro.py --candidate $e --control $a --out "$val\micro-trace" --pairs 3 --operations 1000 --plain-only --trace
python -X utf8 tools/release-stabilization-03f/analyze.py $val
python -X utf8 tools/release-stabilization-03f/analyze-diagnostics.py $val
.\tools\release-stabilization-03f\test.ps1 -Cargo $cargo -TargetDirectory "$root\test03e"
.\tools\enterprise-sql-v2-validation\run.ps1 -Mode Smoke -Binaries $e -WorkRoot $val -Port 55436
& $dotnet run --project tools/enterprise-sql-v2-validation/client/StudioValidation.csproj -c Release -- $e "$val\studio-client"
```

The source pins Rust 1.85.0 for workspace validation. Both unchanged release engine distributions used stable Rust 1.98.1 (`48a229cea`, 2026-09-01); release benchmarks were not rebuilt with different compilers. The frozen suite directory is `C:\PHOBOS-BENCH-v1.3.2`; its internal identity remains PHOBOS Standard Benchmark v1.3.1-G56. Every benchmark run retains its exact command/environment JSON. No timed benchmark overlapped a build/test run.

Installer elevation and fixture ownership requirements are in `tools/release-stabilization-03f/README.md`. The real interactive journey is documented separately and cannot be replaced by a command-line test. The final installer is repacked with final documentation from the already validated runtime binaries; the report distinguishes that package from the earlier interactive build.
