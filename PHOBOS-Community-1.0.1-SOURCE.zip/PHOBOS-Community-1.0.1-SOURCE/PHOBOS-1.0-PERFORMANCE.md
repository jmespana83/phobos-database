# PHOBOS Community Edition 1.0.0 — Performance

Promotion follows the final user's causal-regression policy, not the superseded noisy 5% gate. Historical evidence includes 608 passing tests, recovery validation, five balanced Standard pairs with matching hashes, nanosecond empty-definition lookup and WAL-force-dominated requests. Identical binaries showed major timing variation.

All new diagnostic samples are retained. A-versus-E autocommit pairs: +252.538%, +33.939%; batch: +0.085%, -4.117%. SAME E binary under both labels: autocommit +39.052%, +53.791%. These are noisy/poor timings, not proof of equivalence. They do not isolate a reproducible causal code regression; repeated diagnostics were stopped as requested. Final Standard results are below.

Suite folder C:/PHOBOS-BENCH-v1.3.2 internally identifies PHOBOS Standard Benchmark v1.3.1-G56. Never relabel it official v1.4. Final runs preserve semantics and explicit flush durability. No scoring optimization or durability relaxation. Standard's no-FK score does not represent the documented FK serialization cost.

## Final Standard comparison

Two balanced AB/BA pairs (four complete runs), exact frozen 1.3.1-G56 suite, identical explicit flush durability. All 152 raw measurements report ok; all 24 query-hash comparisons match the October 23 reference; every run reports zero query errors. No concurrent builds or heavy validation were run during these measurements.

| Workload | Unit | K.5 Oct 23 | 0.3-A Oct 23 | Fresh control median | 1.0.0 median | 1.0 vs fresh | 1.0 vs K.5 | 1.0 vs 0.3-A | Individual pair changes |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| bulk/100000 | s | 0.856535 | 0.986729 | 0.931642 | 1.201412 | +29.0% | +40.3% | +21.8% | +49.3% / +11.4% |
| bulk/1000000 | s | 7.652972 | 9.170931 | 8.555082 | 15.992071 | +86.9% | +109.0% | +74.4% | +110.0% / +65.7% |
| bulk/3000000 | s | 25.245647 | 30.613100 | 36.183036 | 45.058958 | +24.5% | +78.5% | +47.2% | +46.6% / +4.2% |
| read/indexed_point | ms | 0.140923 | 0.190682 | 0.131526 | 0.137478 | +4.5% | -2.4% | -27.9% | +8.4% / +0.6% |
| read/secondary_range_1pct | s | 0.037997 | 0.046374 | 0.038576 | 0.038706 | +0.3% | +1.9% | -16.5% | -1.0% / +1.7% |
| read/full_scan_zero_match | s | 0.075274 | 0.074689 | 0.063385 | 0.062977 | -0.6% | -16.3% | -15.7% | +0.4% / -1.6% |
| read/count_all | s | 0.031836 | 0.038760 | 0.033272 | 0.032338 | -2.8% | +1.6% | -16.6% | -1.9% / -3.7% |
| read/group_by_bucket | s | 0.107117 | 0.114329 | 0.102523 | 0.107631 | +5.0% | +0.5% | -5.9% | +7.7% / +2.3% |
| read/topk_payload | s | 0.078498 | 0.092821 | 0.080175 | 0.078133 | -2.5% | -0.5% | -15.8% | -1.9% / -3.2% |
| read/join_aggregate | s | 0.089904 | 0.099435 | 0.082481 | 0.083307 | +1.0% | -7.3% | -16.2% | +1.7% / +0.3% |
| write/autocommit_insert | s | 0.217338 | 0.233767 | 1.112589 | 1.126627 | +1.3% | +418.4% | +381.9% | +20.0% / -23.3% |
| write/single_transaction_insert | s | 0.005645 | 0.006787 | 0.009072 | 0.008041 | -11.4% | +42.4% | +18.5% | -22.0% / -0.5% |
| oltp/1 | s | 0.856149 | 0.986507 | 1.703175 | 1.943874 | +14.1% | +127.0% | +97.0% | -6.9% / +36.7% |
| oltp/8 | s | 2.337920 | 2.742254 | 5.478259 | 4.933620 | -9.9% | +111.0% | +79.9% | -1.1% / -20.5% |
| oltp/16 | s | 4.677305 | 5.869560 | 7.544312 | 7.279232 | -3.5% | +55.6% | +24.0% | -0.6% / -6.7% |

The bulk measurements are materially worse and must not be hidden: 1M bulk was +110.0% and +65.7% in the two matched pairs. Autocommit and single-client OLTP varied in opposite directions; older October 23 timing is substantially faster for both fresh control and candidate on this host. Read results are close to the fresh control. These data do not establish general performance equivalence.

## Bounded bulk investigation

The unchanged 1M-row frozen TSV/schema/two indexes were then loaded into fresh fixtures in A/E/1.0/1.0/E/A order. This is a targeted diagnostic, not a substitute for Standard and not an official benchmark variant.

| Binary | Wall seconds, samples | Median wall | Server CPU seconds, samples |
|---|---|---:|---|
| Accepted control | 9.297 / 9.297 | 9.297 | 7.172 / 7.281 |
| Enterprise-schema development baseline | 9.453 / 8.860 | 9.156 | 6.844 / 6.641 |
| 1.0.0 | 9.250 / 10.078 | 9.664 | 7.500 / 7.000 |

Candidate median wall was approximately +3.95% versus control; median server CPU approximately +0.32%. Inspection found the new FK/identity bulk eligibility checks execute once at import admission, not once per row; the bulk storage/build loop is unchanged from the schema baseline. The large Standard slowdown was not reproduced or causally isolated by this bounded diagnostic. Its precise environmental/state-history cause remains unresolved. No performance optimization, durability relaxation or benchmark-semantic change was made. Further repetitive timing runs were stopped under the requested policy.

Promotion conclusion: no demonstrated large causal code-level regression; promote after correctness/recovery qualification. This is not a guarantee of throughput parity. Treat bulk throughput variability and FK serialization/full-scan costs as deployment considerations and independently validate the intended workload/hardware. All unfavorable samples, binary hashes, raw measurements and references remain in source evidence.

## Final binary provenance

The paired Standard campaign and bounded bulk diagnostic used the pre-clock-fix 1.0.0 executable hashes recorded in evidence/1.0/standard/binaries.json. A subsequent correctness-only fix propagates the statement timestamp into parallel partition workers. The final package contains that corrected build; the historical timing samples are not relabeled as measurements of its exact bytes. The focused regression passed in debug and optimized release; formatting, strict Clippy, the workspace suite and shipped-client checks were rerun. No bulk path or durability setting changed in this correction.
