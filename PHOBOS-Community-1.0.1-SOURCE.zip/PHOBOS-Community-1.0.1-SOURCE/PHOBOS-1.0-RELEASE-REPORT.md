# PHOBOS Community Edition 1.0.0 — Final Release Report

**RELEASE PHOBOS COMMUNITY EDITION 1.0.0**

Windows x64 is the qualified distribution. This is a bounded release qualification, not independent long-duration production certification. Linux remains unqualified and no Linux binary is supplied. Windows artifacts are unsigned.

## Required release record

| Item | Final result |
|---|---|
| 1. Source provenance | Began from PHOBOS-Community-0.3-F-SOURCE.zip, SHA-256 `606632e701ee975b581c1eff6f7b0e3c85e487fc8c5c7cd14d6036accc53e6ed`. Earlier deliverables were not overwritten. |
| 2. Elapsed scope | Started 2026-10-26 23:37:53 UTC. Release record finalized **2026-10-27 03:18:11 UTC**; elapsed **3:40:18**, including approval/wait time. Five-hour deadline: 2026-10-27 04:37:53 UTC. Work covered implementation, tests, installer/Studio qualification, packaging and documentation. No extension was taken. |
| 3. Public version | Community Edition, Server, CLI, Admin and Management Studio **1.0.0**. |
| 4. Engine baseline | Enterprise-schema branch from the authoritative source, converged with K.5 storage/WAL/MVCC architecture. No storage redesign or reclaim optimization campaign. |
| 5. Catalog | Format **5**. Public server rejects older catalogs pending explicit copy upgrade; older accepted binaries reject format 5. |
| 6. Protocol | Version **1**, retained typed framing, authentication, streaming, cancellation and errors. |
| 7. Management API | Version **1**, additive metadata/capabilities; no unnecessary protocol break. |
| 8. Promotion | Enterprise-schema engine promoted after correctness/recovery qualification. Bounded performance work found no demonstrated large causal code regression; substantial Standard bulk variability remains documented. |
| 9. DEFAULT | Literal defaults; transactional SET/DROP DEFAULT. Dynamic-expression defaults deferred. |
| 10. CHECK | Enforced supported column/literal comparisons, including negative cases and integrity checks. General expression CHECK deferred. |
| 11. PRIMARY KEY | Single/composite key constraints with NOT NULL and UNIQUE enforcement. |
| 12. Identity | Durable BIGINT BY DEFAULT/ALWAYS, concurrency/crash/restart/replay tested; hidden ordinary MVCC allocator rows, never MAX(id)+1. Rollback may reuse uncommitted allocations; explicit BY DEFAULT values do not advance the allocator. |
| 13. RETURNING | Typed multirow INSERT RETURNING columns or `*`, including INSERT SELECT. UPDATE/DELETE RETURNING deferred. Autocommit remains committed if result delivery subsequently fails. |
| 14. Foreign keys | Single/composite table-level FK, immediate NO ACTION/RESTRICT, MATCH SIMPLE; parent unique/type checks, concurrent writers serialized, rollback/restart/replay/integrity tested. CASCADE/deferred constraints unsupported. |
| 15. INSERT SELECT | Snapshot materialization, type/default/identity/constraint enforcement and statement atomicity. |
| 16. UNION/ALL | Compatible column counts/types, duplicate/NULL handling and final ordering/limit behavior; documented numeric promotion rules. |
| 17. Correlation | Qualified correlated WHERE EXISTS/NOT EXISTS on the same snapshot. General correlated scalar/IN/LATERAL forms deferred. |
| 18. Views | Durable read-only definitions, output schema/dependencies, restart and DDL guards. No materialized/updatable views; joins over view/derived/CTE sources remain limited. |
| 19. ALTER TABLE | Defaults, nullability, rename and ADD COLUMN on physically empty tables. No general backfill/type rewrite or DROP COLUMN. |
| 20. Authorization | Server-enforced admin, reader and writer roles via the existing account store/admin tools. Reader cannot write; writer cannot perform DDL. SQL CREATE ROLE/GRANT/REVOKE and object ACLs deferred explicitly. |
| 21. TLS | Existing TLS productized and documented; trusted TLS 1.3, hostname rejection and role enforcement tested with shipped Core. No validation bypass; temporary trust certificate removed. |
| 22. Windows installer | Unified Server/Studio/tools setup. Normal visible configuration, restart, repair, cancellation, uninstall and data preservation passed. Exact corrected setup additionally passed automated install/service/repair/uninstall in PHOBOS-10-Validation03. |
| 23. Studio | 1.0 branding and metadata for keys/defaults/identity/views. Existing tabs, scripts, progressive results, cancellation, export, profiles, completion and themes retained and tested. Final corrected server passed shipped-Core integration. |
| 24. Linux | No usable execution environment was available. Cross-platform source retained; Linux RC/unqualified, no tarball or claimed Linux execution. macOS not qualified. |
| 25. Backup/restore | Existing functionality revalidated; new offline backup-base command retains the owner lock, checks integrity and emits the checkpointed base format. |
| 26. PITR | Existing checkpointed base and WAL replay retained; identity/catalog/FK recovery tests pass. No durability relaxation. |
| 27. Replication | Existing standby replay retained and tested with new schema/state. Automatic failover/multi-master deferred. |
| 28. Lifecycle | Existing churn/reclamation, MVCC/UNIQUE/restart and storage reuse tests pass. No reintroduced permanent slot leak observed in these tests. |
| 29. Performance | Two balanced Standard pairs: 152 raw rows OK, 24 matching query hashes, zero query errors. 1M bulk +66–110% versus fresh control; bounded identical-data diagnostic approximately +3.95% median wall and +0.32% server CPU, not reproducing that large gap. Precise cause unresolved; no throughput-parity claim. |
| 30. Community policy | No artificial licensing limits on CPU/RAM/database size, tables/indexes/users/connections, backup/PITR, replication, Studio or performance features. Technical/admin safety limits documented. |
| 31. Tests | 629 routine Rust tests passed, zero failed, four routine ignores; three correctness soaks separately passed. Only the ignored delta microbenchmark was not run. Formatting, strict Clippy, release build, crash/recovery/upgrade, million-row, protocol/GUI/TLS and installer gates passed. |
| 32. Limitations | FK writer serialization/full scans, materializing operators, constrained SQL/ALTER/view scopes, unsigned Windows artifacts, Linux unqualified and unresolved throughput variability. See KNOWN-LIMITATIONS and SQL-COMPATIBILITY. |
| 33. Deferred scope | Tier 2 SQL/administration expansion and Tier 3 optimizer/distributed/storage/driver/ecosystem work remain deferred. No parser-only feature is advertised as working. |
| 34. Artifacts | SOURCE.zip, Windows-x64-Setup.exe, Windows-x64-Runtime.zip; Studio included coherently. Seventeen product documents, this report, handoff, changed-file list, component hashes and external final hashes supplied. |
| 35. Hashes | PHOBOS-1.0-FINAL-HASHES.txt hashes every final deliverable except itself. COMPONENT-HASHES.json separately records engine and Studio bytes. No circular self-hash. |
| 36. Reproduction | Exact commands and prerequisites below; archived source contains locks, tests and release tools. |
| 37. Decision | **RELEASE PHOBOS COMMUNITY EDITION 1.0.0**, within the documented Windows qualification and SQL/operational scope. |

## Qualification details and evidence provenance

The final timestamp regression deliberately uses persisted partitions to activate parallel workers. It failed before the fix, then passed in debug and optimized release after propagating the statement clock into workers. Full workspace, strict Clippy, formatting, release build, shipped-Core integration and published SQL examples were rerun. The corrected runtime ZIP was checked byte-for-byte against all 327 staged files and the qualified engine/Studio components.

The paired Standard campaign, million-row workload, actual GUI/TLS and normal interactive setup tests precede this isolated clock correction. Their exact hashes/logs remain historical evidence and are not relabeled as tests of the final engine bytes. The final automated installer and Core tests use the corrected binaries; installer/Studio/TLS implementation was unchanged by the clock fix. Standard's internal identity is **1.3.1-G56**, regardless of its directory name.

All four post-Standard databases passed offline integrity: 13 tables, 24 indexes, about 20.6 million live index entries each, zero corrupt entries. Small retained stale-entry counts are reported, not hidden. One earlier serial read-only integrity run was interrupted to run the four checks independently; its abandoned temporary scratch copy was removed, leaving source fixtures intact.

The separate million-row test checked counts/sums, indexing, indexed lookup, 1,000 updates/deletes, restart, 999,000 remaining rows and zero stale/corrupt index entries. Actual accepted-era binaries created the upgrade fixture; copy upgrade preserved all eight original files byte-for-byte and the old server rejected the new catalog. Experimental catalog 4 requires explicit consent.

Primary C:\Program Files\PHOBOS, C:\ProgramData\PHOBOS and PHOBOSDatabase were not used for destructive tests; the primary service remained running. Isolated test databases/auth/config are preserved after uninstall. A shared legacy Start menu group issue was corrected and missing original shortcuts restored. Temporary test trust certificates were removed. No private validation keys, passwords, auth stores or live databases are included in the source archive.

## Reproduce the Windows release

Prerequisites: Windows x64, MSVC build tools/Windows SDK, Rust 1.85.0 and 1.98.1, .NET SDK 10.0.402, .NET Framework 4.8, Inno Setup, Python 3, and the signed Microsoft VC++ x64 redistributable. Dependency caches or network access are required. Use a fresh output directory. Build timestamps may differ; this is functional reproduction, not a promise of identical compiler output bytes.

From the extracted source root in PowerShell, the original machine's exact tool locations are:

```powershell
& .\tools\release-1.0\build-release.ps1 `
  -Dotnet 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\dotnet\dotnet.exe' `
  -Iscc 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\inno\ISCC.exe' `
  -VcRedist 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\vc_redist.x64.exe' `
  -ReleaseToolchain '1.98.1' `
  -OutputRoot 'C:\Users\195doctor\Documents\Codex\PHOBOS-1.0-Reproduction'
```

This script runs formatting/workspace tests, strict Clippy, the release build, locked self-contained Studio publication and unified Windows packaging. On another machine substitute only the tool/output locations. Packaging does not sign PHOBOS. Offline reproduction can add `--offline` to Cargo commands when all locked dependencies are cached.

Additional isolated validation, from the source root after that build:

```powershell
python .\tools\release-1.0\sql_examples.py --bin C:\Users\195doctor\Documents\Codex\PHOBOS-1.0-Reproduction\release-target\release --source . --out C:\Users\195doctor\Documents\Codex\PHOBOS-1.0-Reproduction\sql-examples
python .\tools\release-1.0\large_dataset.py --bin C:\Users\195doctor\Documents\Codex\PHOBOS-1.0-Reproduction\release-target\release --out C:\Users\195doctor\Documents\Codex\PHOBOS-1.0-Reproduction\million --rows 1000000
python .\tools\release-1.0\report_performance.py .\evidence\1.0\standard
```

The retained frozen benchmark distribution is external and is not repackaged or renamed. Its raw measurements, binary hashes and October 23 references are archived under evidence/1.0/standard. InstallerValidation.cs and tools/studio-validation retain the executable acceptance harness sources; normal credential/UAC interactions require a person. Source packaging is reproducible with:

```powershell
python .\tools\release-1.0\package_source.py --source . --baseline C:\Users\195doctor\Documents\Codex\2026-10-26\outputs\PHOBOS-Community-0.3-F-SOURCE.zip --out C:\Users\195doctor\Documents\Codex\PHOBOS-1.0-Reproduction\artifacts
```

Consult the individual product documents for deployment/upgrade commands, technical boundaries, rollback behavior and protocol contracts. Future independent qualification should use the published final hashes and an isolated copy of the intended workload.
