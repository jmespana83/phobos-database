# PHOBOS 0.3-F performance investigation and promotion decision

## Decision: B — partial promotion

Accept the Windows installer hotfix with byte-identical accepted engine 0.3-A. Keep 0.3-E Enterprise SQL & Schema V2 experimental. Identity, sequences and RETURNING are deferred. No engine optimization or durability change was made.

The new full Standard series does not clear the write guardrail: autocommit INSERT median is +13.8248%, with 3/5 pairs above +5%; single-transaction INSERT median is +6.1123%, with 2/5 pairs above +5%. This is recurring adverse timing evidence, not proof that a specific schema lookup caused it. Identical-binary calibration also shows substantial host variability. The instruction to hold when equivalence cannot be established therefore applies.

## Full frozen Standard method

PHOBOS Standard Benchmark v1.3.1-G56, stored in C:\PHOBOS-BENCH-v1.3.2, unchanged harness. Five fresh matched pairs ran C/E, E/C, C/E, E/C, C/E. Every run is retained, including candidate pair 2's broadly slower results. No outlier was discarded. Same Windows host (32 logical CPUs), compiler (stable Rust 1.98.1), accepted A and unchanged E release binaries, default 16 workers and flush durability. No builds/tests overlapped these timed runs. The restored original database service was idle; the desktop was not a dedicated isolated performance lab. No claim is made that OS/background activity was controlled completely.

All ten runs completed. Each has 38 raw records marked ok, zero query errors, and all six hashed query outputs equal to the October 23 K.5 reference. Default full bulk (100k/1M/3M), read, point, write and OLTP 1/8/16 phases ran. Optional churn/enterprise additions were not enabled, consistent with the frozen default suite. This is not a relabeled v1.4 or v1.3.2 benchmark.

The table preserves the October 23 K.5 and 0.3-A references and compares fresh medians. Positive values mean slower. Detailed exact command/environment, raw rows, summaries, plans and harness hashes are in evidence-03f.

| Workload | Unit | K.5 Oct 23 | 0.3-A Oct 23 | Fresh control median | 0.3-E median | E vs fresh | E vs K.5 | E vs 0.3-A | Individual pair changes |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| bulk/100000 | s | 0.856535 | 0.986729 | 0.955234 | 0.931482 | -2.5% | +8.8% | -5.6% | -1.4% / -0.5% / +0.2% / -3.7% / +10.2% |
| bulk/1000000 | s | 7.652972 | 9.170931 | 8.523219 | 8.375839 | -1.7% | +9.4% | -8.7% | -0.9% / -11.0% / +3.0% / -3.6% / +9.9% |
| bulk/3000000 | s | 25.245647 | 30.613100 | 31.720420 | 32.443134 | +2.3% | +28.5% | +6.0% | +9.2% / +8.0% / +2.3% / -5.4% / +4.3% |
| read/indexed_point | ms | 0.140923 | 0.190682 | 0.138416 | 0.138599 | +0.1% | -1.6% | -27.3% | -3.8% / +32.4% / -0.9% / +0.2% / -1.7% |
| read/secondary_range_1pct | s | 0.037997 | 0.046374 | 0.039269 | 0.039550 | +0.7% | +4.1% | -14.7% | -0.7% / +21.8% / +0.4% / -1.6% / +4.9% |
| read/full_scan_zero_match | s | 0.075274 | 0.074689 | 0.063971 | 0.064575 | +0.9% | -14.2% | -13.5% | +2.7% / +24.6% / -0.8% / +1.2% / +0.7% |
| read/count_all | s | 0.031836 | 0.038760 | 0.033069 | 0.032622 | -1.4% | +2.5% | -15.8% | -1.0% / +14.1% / -2.9% / +0.9% / -1.4% |
| read/group_by_bucket | s | 0.107117 | 0.114329 | 0.104220 | 0.105150 | +0.9% | -1.8% | -8.0% | +5.0% / +15.7% / -0.2% / +0.9% / +0.3% |
| read/topk_payload | s | 0.078498 | 0.092821 | 0.082687 | 0.080089 | -3.1% | +2.0% | -13.7% | +3.6% / +26.8% / -2.6% / -4.5% / -5.1% |
| read/join_aggregate | s | 0.089904 | 0.099435 | 0.083757 | 0.084870 | +1.3% | -5.6% | -14.6% | +2.2% / +16.6% / +0.6% / +2.7% / -1.5% |
| write/autocommit_insert | s | 0.217338 | 0.233767 | 0.170842 | 0.194461 | +13.8% | -10.5% | -16.8% | +13.8% / +81.2% / +0.6% / -6.7% / +14.9% |
| write/single_transaction_insert | s | 0.005645 | 0.006787 | 0.005515 | 0.005852 | +6.1% | +3.7% | -13.8% | +6.9% / +26.4% / +4.1% / -0.8% / +4.1% |
| oltp/1 | s | 0.856149 | 0.986507 | 0.808470 | 0.797791 | -1.3% | -6.8% | -19.1% | -3.3% / +23.0% / +2.6% / -2.0% / -8.1% |
| oltp/8 | s | 2.337920 | 2.742254 | 2.195817 | 2.170339 | -1.2% | -7.2% | -20.9% | -1.3% / +35.1% / -5.7% / -1.2% / -8.0% |
| oltp/16 | s | 4.677305 | 5.869560 | 4.274479 | 4.333364 | +1.4% | -7.4% | -26.2% | +5.5% / +36.4% / +2.4% / -0.5% / +1.4% |

## Interpreting the guardrails

Read/write guard: +5%; OLTP guard: +8%. Besides the write cases, bulk 3M and GROUP BY have two pairs over their guard, although their median changes are only +2.28% and +0.89%. Other read/OLTP median changes remain inside the guards, but a small noisy sample cannot establish universal equivalence. The descriptive 20,000-resample paired-median intervals (seed 8067, five pairs) are wide. They are recorded as unresolved evidence, not as proof that every workload regressed. The direct autocommit/batch median and recurring write failures already suffice to hold promotion; the conservative bootstrap rule is additional uncertainty reporting.

## Targeted microbenchmarks

Seven balanced pairs; fresh instances, 16 workers, explicit flush durability. 1,000 INSERT statements per successful case. Autocommit commits each statement; batch uses one explicit transaction. CHECK rejection is 1,000 failed autocommit statements, or one failed explicit-transaction statement followed by ROLLBACK. No failed transaction is reused for further writes. Count/sum validation and offline integrity passed in all 14 instances. There were 140 samples, 133,007 attempted operations and 7,007 expected constraint rejections.

Two earlier harness attempts are retained: the first adapter closed on a SQL error, and the second incorrectly continued inside a failed explicit transaction. The corrected harness uses the frozen typed adapter and rolls back after rejection. These were harness failures, not hidden engine failures or discarded timing outliers.

| Plain table mode | A median seconds | E median seconds | Change | Pair changes |
|---|---:|---:|---:|---|
| autocommit | 0.932653 | 0.829012 | -11.11% | +59.58% / -46.26% / -4.57% / +72.37% / +17.48% / -53.25% / -45.60% |
| batch | 0.152015 | 0.152481 | +0.31% | +2.77% / +0.46% / -1.97% / -2.00% / +8.84% / -3.56% / +0.48% |

The microbenchmark uses fresh small tables and a different client/workload history from Standard's post-load write phase. Its faster autocommit median contradicts the Standard direction and has very wide pairs. It does not overrule the Standard gate. Batch plain-table time is near parity (+0.31%). The candidate batch plain case also runs with other schema definitions present. Variant order is fixed; the following numbers describe exercised cases, not randomized causal feature costs.

| Mode | Variant | Median microseconds/operation | BEGIN ms | COMMIT/ROLLBACK ms |
|---|---|---:|---:|---:|
| autocommit | plain | 829.012 | 0.000 | 0.000 |
| autocommit | default | 670.041 | 0.000 | 0.000 |
| autocommit | check | 672.438 | 0.000 | 0.000 |
| autocommit | pk | 689.980 | 0.000 | 0.000 |
| autocommit | default_check | 665.921 | 0.000 | 0.000 |
| autocommit | default_pk | 687.596 | 0.000 | 0.000 |
| autocommit | check_pk | 685.207 | 0.000 | 0.000 |
| autocommit | default_check_pk | 680.213 | 0.000 | 0.000 |
| autocommit | check_reject | 104.212 | 0.000 | 0.000 |
| batch | plain | 152.481 | 0.107 | 2.481 |
| batch | default | 150.921 | 0.108 | 2.940 |
| batch | check | 149.296 | 0.106 | 2.393 |
| batch | pk | 166.474 | 0.108 | 4.447 |
| batch | default_check | 156.614 | 0.110 | 2.794 |
| batch | default_pk | 161.190 | 0.110 | 4.080 |
| batch | check_pk | 160.138 | 0.103 | 5.214 |
| batch | default_check_pk | 161.772 | 0.107 | 3.240 |
| batch | check_reject | 544.100 | 0.095 | 0.101 |

## Same-binary calibration

Seven additional balanced plain-table pairs use the exact accepted A server hash on both sides. All 14 instances passed row checks and offline integrity. This tests whether substantial variability can occur without any code difference; it cannot subtract noise from the Standard measurements or prove E equivalent.

| Mode | First-label median seconds | Second-label median seconds | Apparent change with identical code | Pair changes |
|---|---:|---:|---:|---|
| autocommit | 1.937851 | 1.260317 | -34.96% | -0.67% / -49.58% / +63.54% / -36.36% / -22.35% / -48.30% / -14.19% |
| batch | 0.149441 | 0.154460 | +3.36% | +1.42% / -3.70% / -0.64% / -0.15% / +4.10% / +4.92% / +3.51% |

## Component and request-path profiling

The native release diagnostic uses real catalog APIs and black_box, seven samples. It measures empty/nonempty definition access, unconstrained validation, DEFAULT/PK access, CHECK pass/reject, catalog clone/drop and an extra Arc clone/drop. These are single-thread micro-costs and do not capture cache contention or establish a wall-clock regression cause.

| Component | Median ns/operation |
|---|---:|
| loop_control | 0.408 |
| empty_definition_lookup | 1.468 |
| unconstrained_row_validation | 1.907 |
| catalog_clone_drop | 65.872 |
| extra_arc_clone_drop | 3.378 |
| nonempty_missing_table_lookup | 2.112 |
| default_lookup | 3.180 |
| primary_metadata_lookup | 2.336 |
| check_pass | 9.224 |
| check_reject | 59.728 |

Separate three-pair trace runs enable the existing request tracer at 1 microsecond, using the same release binaries. These are instrumented diagnostics, excluded from promotion timings. Each role has 3,000 autocommit INSERT records and 3,006 batch records (including BEGIN/COMMIT). Trace records contain timing/request classes, not SQL/passwords. Inclusive phases overlap: commit_total includes its WAL and publication subphases, so columns must not be summed as independent costs.

| Role/mode | Records | Total sum ms | Commit sum ms | WAL force wait sum ms | View sum ms | Unaccounted sum ms |
|---|---:|---:|---:|---:|---:|---:|
| control/autocommit | 3000 | 5115.214 | 4877.670 | 4342.286 | 11.144 | 131.978 |
| control/batch | 3006 | 373.493 | 11.433 | 7.704 | 199.809 | 81.387 |
| candidate/autocommit | 3000 | 3934.410 | 3704.978 | 3209.685 | 11.349 | 126.924 |
| candidate/batch | 3006 | 362.666 | 9.585 | 3.748 | 195.060 | 80.156 |

In these traced autocommit runs, commit time accounts for about 95% (A) and 94% (E) of server request time; WAL force waiting accounts for about 85% and 82%. The candidate is faster in this diagnostic, another reason not to treat it as proof of a schema overhead regression. Statement-view median is 3 microseconds for both; unaccounted median is 41/40 microseconds. The batch trace shifts work toward statement-view construction while amortizing commit. Client-side BEGIN/COMMIT and total DML timing are recorded separately in micro.csv.

The data identifies durability/commit waiting as the dominant measured autocommit cost in this environment, but it does not establish which OS/storage/background effect caused the Standard difference. Empty-definition lookup is approximately 1.5 ns in the isolated component test; no causal evidence supports attributing the +13.8% result to it. No cached flag or alternate enforcement path was introduced, and no CHECK, DEFAULT, PK, WAL, flush, MVCC or publication guarantee was weakened.

## Next investigation

Use a quieter dedicated Windows test environment and repeat the frozen suite with the same durable binaries. Correlate storage latency, scheduling and write/commit traces in separate diagnostic runs; preserve all measurements and identical compiler/worker settings. Establish repeatable causality before changing the schema-definition path. Do not change fsync batching to pass the benchmark. Only after the promotion gate clears should 0.3-G add durable identity and typed RETURNING.

