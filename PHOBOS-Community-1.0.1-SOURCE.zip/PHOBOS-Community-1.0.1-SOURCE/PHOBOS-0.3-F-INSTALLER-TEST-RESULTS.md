# PHOBOS 0.3-F Windows installer test results

Status: main real-user clean-install acceptance PASS, with explicit coverage gaps below. This report distinguishes real interactive testing from automation.

## Real-user clean-install acceptance

On October 26, 2026, the original running installation was stopped, all 23 original data/config/auth/log files copied and SHA-256 verified, and the old runtime uninstalled. The preserved original data was moved aside. Both primary paths and PHOBOSDatabase were absent before normal Setup.

The user advanced the real elevated installer, without FILESONLY. The configuration window appeared naturally; the user confirmed this and Computer Use inspected the actual dialog with data, port, username, masked password and confirmation fields. Welcome identified packaging 0.3-F and accepted engine 0.3-A. Initialization completed, including authenticated SQL/catalog readiness. The service ran under LocalService and the listener belonged to the installed phobos-server.exe.

Accepted, unchanged Studio 0.3-D connected. Through its actual SQL editor/results grid we executed SHOW CATALOG CAPABILITIES, CREATE TABLE, CREATE UNIQUE INDEX, INSERT and SELECT. The row `(1, persisted)` was visible. After graceful service stop, offline INTEGRITY OK, service start and manual reconnect, the same row and unique index were visible. The same installer was rerun normally; the user completed its repair dialog. Instance ID, authentication-file SHA-256, row and index remained unchanged.

Server uninstall removed service/binaries and preserved data/auth/config/logs. Installed Studio remained present. Deferred uninstaller self-cleanup briefly left the binary directory; the test waited/preserved the remnant rather than treating immediate directory absence as guaranteed.

The original database was then copied back from the verified protected backup, verified again, checked offline (one table, one index, three live index entries), and restarted with the unchanged accepted 0.3-A binaries and corrected packaging. Original credentials were unchanged. Both original backup copies and the acceptance database are retained; historical 0.3-B/C/D validation fixtures were untouched.

## Coverage matrix

| Case | Result | Evidence / limit |
|---|---|---|
| Default-path normal interactive install | PASS | User participation plus actual window inspection; no FILESONLY |
| Visible configuration fields | PASS | Actual owned configuration window, user-confirmed |
| Progress feedback | Implemented | Explicit separate-dialog instructions in Setup; source assertion |
| Authenticated startup/catalog SQL | PASS | Configure success requires existing bounded authenticated probe |
| Studio script and result grid | PASS | Real installed Studio 0.3-D, unchanged Core hash |
| Graceful restart, reconnect, row/index survival | PASS | Offline integrity and actual Studio result inspection |
| Normal interactive repair | PASS | Same instance/auth hash and persisted row/index |
| Server uninstall retains data and Studio | PASS | Lifecycle helper plus files/service checks |
| Custom-path FILESONLY install/repair/uninstall | PASS | Dedicated PHOBOS-03F-Validation1 fixture |
| Custom-path normal configuration cancellation | PASS | Actual final-code normal installer; user clicked Cancel; explicit incomplete-install warning; no manifest/service; runtime retained then uninstalled |
| Occupied port and retry | PASS | No initialization on occupied port; successful retry after release |
| Wrong password | PASS | Rejected by native probe in isolated automation |
| Initialization intent interruption | PASS | Test-build deterministic failure, durable initializing state, no orphan service/listener, retry refuses reinitialization |
| Post-initialization interruption | PASS | Same checks; data/auth retained |
| Partial service registration interruption | PASS | Failure after service creation; owned service compensated |
| Post-registration interruption | PASS | Owned service compensated; data retained |
| Before-start / after-start interruptions | PASS | Safe stop/removal, retained data, no orphan listener |
| Invalid server runtime configuration | PASS | Startup failure surfaced; corrected configuration recovered |
| Service-host crash containment | PASS | No orphan listener; WAL recovery retained rows |
| Protected ACLs | PASS | Existing validation checks, no Everyone/Users private-data grants |
| Plaintext secret persistence | PASS | Random test secrets absent from fixture files/logs; no argv/environment/response-file passwords in installer paths |
| Abrupt interruption during file copy | NOT RUN | No destructive interruption of restored user installation; requires another isolated system/install registration |
| Abrupt process/OS kill at all six configure boundaries | NOT RUN | Six tests inject managed exceptions, not power loss; distinguish from engine crash tests |
| Custom path successful interactive initialization | NOT RUN | Custom-path success automated; interactive cancellation tested separately |
| Linux/macOS installer/runtime qualification | NOT RUN | Windows-specific hotfix; no runtime environment available |

The initial real clean install/repair used the visibility fix before service-failure compensation was added. The final compensation code passed isolated installer lifecycle tests and six fault cases; the final-code installer also passed the normal interactive cancellation path. No claim is made that the entire initial clean-install journey was repeated byte-for-byte on the final documentation-repacked executable.

## Failure/retry behavior

Cancellation after copy deliberately retains runtime files and reports incomplete setup (custom exit 2). Uninstall the incomplete runtime before retrying. A durable initializing manifest is never automatically erased/reinitialized. New service cleanup verifies ownership and safe stop; if Windows prevents cleanup, an administrator must inspect retained state. Test-only failure callbacks are compiled only with PHOBOS_INSTALLER_TESTS and are absent from the distributed manager.

## Interactive test limitations

Windows blocked synthetic input to elevated windows. The human user handled the actual installer controls and authentication dialogs; the agent inspected windows, ran SQL in connected Studio, and verified lifecycle evidence. This is a collaborative real-user test, not an unattended installer certification.
