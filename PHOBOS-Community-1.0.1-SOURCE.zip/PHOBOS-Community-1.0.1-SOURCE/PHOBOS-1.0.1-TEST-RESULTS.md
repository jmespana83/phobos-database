# PHOBOS 1.0.1 — Test Results

Validation date: October 27, 2026, Windows x64. Evidence is in `evidence/1.0.1`. This is hotfix regression qualification, not Stage 28 certification.

| Check | Result / scope |
|---|---|
| Rust full routine workspace | 629 passed, 0 failed, 4 ignored; Rust 1.85.0, locked dependencies |
| Formatting / strict Clippy | Passed; Clippy all targets with warnings denied on Rust 1.98.1 |
| Release engine | Rust 1.98.1 build passed; 205 `.rs` files byte-identical to accepted 1.0.0 |
| Exact packaged Studio Core | Integration and malformed-protocol suites passed using the shipped Core DLL, without rebuilding it |
| SQL errors | CHECK, FK, PK, duplicate table, missing table, bad column, syntax and reader authorization failure; SELECT 1 succeeds on the same connection after each |
| Transactions | Failure retained; subsequent work rejected; explicit ROLLBACK restores usability; original rows preserved |
| GUI | Actual Avalonia window: seven SQL error cases, visible Messages, same query tab, explicit rollback, independent sessions, multi-results, 50K progressive grid, export/completion/dialogs and routed shortcuts |
| Fatal responses | Malformed/truncated terminal errors, unknown/fatal codes, malformed rows/headers, client budget interruption, cancellation and server crash still fail closed |
| TLS | Strict rejection of untrusted server certificate passed; no trust bypass. No new positive-certificate trust ceremony in this hotfix |
| 1.0.0 wire compatibility | New client against accepted 1.0.0 server passed all statement-error/transaction cases |
| Final exact installer | Fresh fixture 04 and actual 1.0.0 repair fixture 05 passed installation, pre-copy lock rejection, graceful service stop/restart, wrong-password rejection, preservation, recovery, integrity, backup/restore and uninstall |
| Interactive repair | See INSTALLER-REPAIR-VALIDATION for visible maintenance, running-Studio warning and persistence checks |
| Archive validation | Runtime CRC and all 327 files match final stage; BUILD.json component hashes match; exact tested Core/production Studio included |
| Primary protection | Original 1.0.0 install path, version, server hash and Running service state unchanged |

The four ignored routine tests remain opt-in long-running tests. They were not rerun or represented as passing in this hotfix. Prior 1.0 performance/soak evidence is retained with its original provenance. The installer runner includes a short 1,000-indexed-read service/direct sample; it is not a Standard score or regression certification. No engine performance tuning was performed.

Earlier local candidates exposed an Inno `{app}` initialization-order error before file copy, and screenshot review exposed a detached Messages control. Both were fixed before the final package. Earlier test expectations for missing-column and failed-transaction diagnostics were corrected to match the unchanged engine contract. Final passing logs supersede those exploratory failures; no failed final check was suppressed.

## Reproduction

From the extracted source root, use the provided locked build wrapper with installed .NET 10.0.402, Inno Setup 6.7.3, Microsoft VC++ x64 redistributable, Rust 1.85.0 and Rust 1.98.1:

```powershell
& tools/release-1.0.1/build-release.ps1 -Dotnet '<dotnet.exe>' -Iscc '<ISCC.exe>' -VcRedist '<vc_redist.x64.exe>' -OutputRoot 'C:\PHOBOS-101-Reproduction'
```

OutputRoot must be new. The wrapper runs formatting, routine tests, strict Clippy, builds production Studio/runtime/Setup, and tests the exact packaged Core. To reproduce just routine checks:

```powershell
$env:AWS_LC_SYS_PREBUILT_NASM='1'
cargo +1.85.0 fmt --all -- --check
cargo +1.85.0 test --workspace --locked --offline -- --test-threads=4
cargo +1.98.1 clippy --workspace --all-targets --locked --offline -- -D warnings
```

For the actual-window harness, publish Studio with `-p:StudioValidation=true` to a separate evidence-only directory, then run `StudioValidation.dll <engine-bin> <new-evidence-directory> <evidence-Studio.exe>`. Never distribute that instrumented build. Production uses `StudioValidation=false`. The runner builds under `tools/studio-validation/StudioValidation.csproj`; `--protocol-faults` runs malformed-response tests, and a third argument `--errors-only` runs SQL/transaction cases against a supplied compatible engine.

Installer runner compilation and elevated isolated invocation are documented in INSTALLER-REPAIR-VALIDATION. Source archive generation:

```powershell
python tools/release-1.0.1/package_source.py --source . --baseline '<accepted-1.0.0-SOURCE.zip>' --out '<artifact-directory>'
```
