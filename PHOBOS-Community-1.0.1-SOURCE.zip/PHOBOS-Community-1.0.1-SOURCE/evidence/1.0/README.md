# Curated PHOBOS 1.0 evidence

Final routine/soak, protocol/GUI/TLS, installer, upgrade, large-data, formatting/Clippy, component and performance evidence. These files retain measured failures/limitations and the superseding final outcomes. The first cross-connection documentation attempt failed with a retriable schema lease conflict; the persistent-session run passed. Earlier detailed development failures remain in the local validation directory and are described in TEST-RESULTS.

Standard uses its exact frozen 1.3.1-G56 measurements. Relative run directories make report_performance.py portable. Promotion diagnostics and the bounded A/E/1.0 bulk diagnostic are separate and never substituted into Standard scores. Original paths and binary hashes are provenance, not commands to execute.

No live database, auth store, newly generated private certificate/key, password, compiler output or frozen benchmark executable distribution is copied here. The inherited non-production TLS certificates and public test key material under crates/phobos-server/tests/fixtures remain necessary test source; never use them in deployment. Representative actual GUI rasters are in gui/; the full set remains in the local validation/studio-gui-1.0/screenshots directory.

The final corrected engine is identified by component-hashes-final.json and release-clock-environment.json. Use workspace-clock-summary.json (629 passed), workspace-clock-final.log, studio-core-clock.log, runtime-clock-verification.json and installer-clock-final/ for the superseding final gates. Older workspace-summary.json records 628 tests before the persisted-partition clock regression was added. Standard, GUI and TLS logs retain their original binary provenance. All four integrity-*.log runs completed successfully.
