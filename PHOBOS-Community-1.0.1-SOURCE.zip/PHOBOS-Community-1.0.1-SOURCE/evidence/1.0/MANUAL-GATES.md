# Manual gates completed
- Normal 1.0 install/configuration: user completed visible wizard; service running; Setup exit 0.
- Shipped Studio: user connected and observed INSERT RETURNING id=1,label=accepted and the persisted view SELECT.
- Isolated service restart + offline integrity: pass. Normal repair: exit 0; user reconnected and confirmed the same row.
- Uninstall: owned service/binaries removed; test database/auth/config preserved.
- Configuration Cancel: user canceled; Setup exit 2 (incomplete), no service/database; fixture binaries then removed.
- Final packaged Core + final release server trusted TLS 1.3/hostname/roles: pass; temporary certificate removed, zero matching certificates remain.
- Earlier Computer Use approval timeout and failed trust attempt are retained as superseded diagnostics.
- Original primary database/service unchanged. Missing original shortcuts from inherited shared group behavior were restored; new product has its own group.
- No pending interactive acceptance gates. Final artifact verification remains automatic.
