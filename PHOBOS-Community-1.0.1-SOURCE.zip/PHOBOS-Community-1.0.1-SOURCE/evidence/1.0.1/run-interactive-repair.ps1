$ErrorActionPreference='Stop'
$root='C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1'
$folder=Join-Path $root 'validation\interactive'
function Snapshot($name) {
 $i=Get-Content 'C:\ProgramData\PHOBOS-101-Interactive\config\instance.json' -Raw | ConvertFrom-Json
 [ordered]@{instanceId=$i.instanceId;port=$i.port;dataDirectory=$i.dataDirectory;serviceName=$i.serviceName;authSHA256=(Get-FileHash $i.authFile).Hash;runtimeSHA256=(Get-FileHash $i.runtimeConfig).Hash} | ConvertTo-Json | Set-Content (Join-Path $folder $name)
}
Snapshot 'before.json'
$setup=Join-Path $root 'outputs\PHOBOS-Community-1.0.1-Windows-x64-Setup.exe'
(Get-FileHash $setup).Hash | Set-Content (Join-Path $folder 'repair-setup.sha256')
$p=Start-Process -FilePath $setup -ArgumentList '/INSTANCEKEY=HotfixInteractive /DIR="C:\Program Files\PHOBOS-101-Interactive" /INSTANCECONFIG="C:\ProgramData\PHOBOS-101-Interactive\config\instance.json" /SERVICENAME=PHOBOS101Interactive /PORT=55462 /GROUP="PHOBOS 101 Interactive" /LOG="C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1\validation\interactive\repair.log"' -PassThru -Wait
$p.ExitCode | Set-Content (Join-Path $folder 'repair.exit')
Snapshot 'after.json'
