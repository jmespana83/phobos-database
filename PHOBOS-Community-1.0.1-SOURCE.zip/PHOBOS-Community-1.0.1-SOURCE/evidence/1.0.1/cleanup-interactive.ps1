$ErrorActionPreference='Stop'
$root='C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1'
$log=Join-Path $root 'validation\interactive-cleanup.log'
foreach($suffix in @('Interactive','FinalInteractive')) {
 $install='C:\Program Files\PHOBOS-101-'+$suffix
 $homePath='C:\ProgramData\PHOBOS-101-'+$suffix
 $service='PHOBOS101'+$suffix
 $manifest=Join-Path $homePath 'config\instance.json'
 $i=Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json
 if($i.installDirectory -ne $install -or $i.serviceName -ne $service){throw 'Fixture ownership mismatch'}
 $gui=Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -eq (Join-Path $install 'studio\PHOBOS-Studio.exe')}
 if($gui){throw 'Test Studio remains open; close it before uninstall'}
 $auth=(Get-FileHash $i.authFile).Hash
 $config=(Get-FileHash $i.runtimeConfig).Hash
 $p=Start-Process (Join-Path $install 'unins000.exe') -ArgumentList '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART' -Wait -PassThru
 if($p.ExitCode -ne 0){throw 'Test uninstaller failed'}
 if(Get-Service $service -ErrorAction SilentlyContinue){throw 'Test service remains'}
 if(Test-Path (Join-Path $install 'bin\phobos-server.exe')){throw 'Test server binary remains'}
 if(!(Test-Path $i.dataDirectory) -or !(Test-Path $manifest)){throw 'Fixture data/config was not preserved'}
 if((Get-FileHash $i.authFile).Hash -ne $auth -or (Get-FileHash $i.runtimeConfig).Hash -ne $config){throw 'Auth/config preservation failure'}
 "PASS $suffix service/binaries removed; database, auth and configuration retained. No database directory deleted." | Add-Content $log
}
