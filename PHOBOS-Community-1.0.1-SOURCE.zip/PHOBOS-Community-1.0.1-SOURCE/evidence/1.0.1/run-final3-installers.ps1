$ErrorActionPreference='Stop'
$root='C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1'
$runner=Join-Path $root 'build\helper\installer-validation.exe'
$setup=Join-Path $root 'outputs\PHOBOS-Community-1.0.1-Windows-x64-Setup.exe'
foreach($suffix in @('04','05')) {
 $folder=Join-Path $root ('validation\installer-'+$suffix)
 New-Item -ItemType Directory -Path $folder -Force | Out-Null
 (Get-FileHash $setup).Hash | Set-Content (Join-Path $folder 'setup.sha256')
 $log=Join-Path $folder 'result.log'
 if($suffix -eq '05'){& $runner $setup $log $suffix 'C:\Users\195doctor\Documents\Codex\PHOBOS-1.0\build\runtime-clock-final'}else{& $runner $setup $log $suffix}
 $code=$LASTEXITCODE
 $code | Set-Content (Join-Path $folder 'exit-code.txt')
 if($code -ne 0){exit $code}
}

