$ErrorActionPreference='Stop'
$root='C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1'
$folder=Join-Path $root 'validation\final-interactive'
New-Item -ItemType Directory -Path $folder -Force | Out-Null
if((Test-Path 'C:\Program Files\PHOBOS-101-FinalInteractive') -or (Test-Path 'C:\ProgramData\PHOBOS-101-FinalInteractive')){throw 'Fresh fixture paths already exist'}
$setup=Join-Path $root 'outputs\PHOBOS-Community-1.0.1-Windows-x64-Setup.exe'
(Get-FileHash $setup).Hash | Set-Content (Join-Path $folder 'setup.sha256')
$p=Start-Process -FilePath $setup -ArgumentList '/INSTANCEKEY=HotfixFinalInteractive /DIR="C:\Program Files\PHOBOS-101-FinalInteractive" /INSTANCECONFIG="C:\ProgramData\PHOBOS-101-FinalInteractive\config\instance.json" /SERVICENAME=PHOBOS101FinalInteractive /PORT=55463 /LOG="C:\Users\195doctor\Documents\Codex\PHOBOS-1.0.1\validation\final-interactive\fresh.log"' -PassThru -Wait
$p.ExitCode | Set-Content (Join-Path $folder 'fresh.exit')
if($p.ExitCode -ne 0){throw 'Setup did not complete'}
$i=Get-Content 'C:\ProgramData\PHOBOS-101-FinalInteractive\config\instance.json' -Raw | ConvertFrom-Json
[ordered]@{instanceId=$i.instanceId;port=$i.port;dataDirectory=$i.dataDirectory;serviceName=$i.serviceName;state=$i.state;version=$i.productVersion;serviceStatus=(Get-Service $i.serviceName).Status.ToString()} | ConvertTo-Json | Set-Content (Join-Path $folder 'result.json')
