#ifndef RuntimeDir
  #error RuntimeDir must identify the staged runtime
#endif
#ifndef OutputDir
  #error OutputDir must identify the output directory
#endif
[Setup]
AppId={code:ProductId}
UsePreviousLanguage=no
AppName=PHOBOS
AppVersion=1.0.1
AppVerName=PHOBOS Community Edition 1.0.1
AppPublisher=PHOBOS Community
DefaultDirName={autopf}\PHOBOS
DefaultGroupName={code:ProductGroup}
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir={#OutputDir}
OutputBaseFilename=PHOBOS-Community-1.0.1-Windows-x64-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=no
RestartApplications=no
UninstallDisplayName=PHOBOS Community Edition 1.0.1 (keeps database data)
SetupLogging=yes
VersionInfoVersion=1.0.1.0
DisableWelcomePage=no
InfoBeforeFile={#RuntimeDir}\docs\INSTALLER-NOTICE.txt

[Types]
Name: "full"; Description: "Server, command-line tools and Management Studio"
Name: "server"; Description: "Server and command-line tools"
Name: "custom"; Description: "Custom"; Flags: iscustom

[Components]
Name: "server"; Description: "PHOBOS Database Server and command-line tools"; Types: full server custom; Flags: fixed
Name: "studio"; Description: "PHOBOS Management Studio"; Types: full

[Files]
Source: "{#RuntimeDir}\bin\*"; DestDir: "{app}\bin"; Flags: ignoreversion
Source: "{#RuntimeDir}\docs\*"; DestDir: "{app}\docs"; Flags: ignoreversion recursesubdirs
Source: "{#RuntimeDir}\bin\phobos-instance.exe"; Flags: dontcopy
Source: "{#RuntimeDir}\bin\phobos-instance.exe.config"; Flags: dontcopy
Source: "{#RuntimeDir}\prerequisites\vc_redist.x64.exe"; Flags: dontcopy

Source: "{#RuntimeDir}\studio\*"; DestDir: "{app}\studio"; Flags: ignoreversion recursesubdirs createallsubdirs; Components: studio

[Icons]
Name: "{group}\PHOBOS Management Studio"; Filename: "{app}\studio\PHOBOS-Studio.exe"; Components: studio
Name: "{group}\PHOBOS Documentation"; Filename: "{app}\docs\QuickStart.html"
Name: "{group}\PHOBOS Command Prompt"; Filename: "{cmd}"; Parameters: "/K cd /d ""{app}\bin"""; WorkingDir: "{app}\bin"
Name: "{group}\Uninstall PHOBOS (keep data)"; Filename: "{uninstallexe}"

[Code]
var ConfigPath: String;
    FilesOnly: Boolean;
    Configured: Boolean;
    RepairMode: Boolean;
    RepairInfo: String;
    MaintenancePage: TOutputMsgWizardPage;

function ProductId(Param: String): String;
var Key: String;
begin
  Key := ExpandConstant('{param:INSTANCEKEY|}');
  Result := '{ABC7A100-1326-4569-B59A-78D1F83F1000}';
  if Key <> '' then Result := Result + '-' + Key;
end;

function ProductGroup(Param: String): String;
begin
  Result := 'PHOBOS Community Edition 1.0';
  if ExpandConstant('{param:INSTANCEKEY|}') <> '' then Result := Result + ' - ' + ExpandConstant('{param:INSTANCEKEY|}');
end;

function InspectInstance(Command: String; var Details: String): Integer;
var Code, N: Integer; Lines: TArrayOfString;
begin
  ExtractTemporaryFile('phobos-instance.exe');
  ExtractTemporaryFile('phobos-instance.exe.config');
  Details := '';
  if not Exec(ExpandConstant('{tmp}\phobos-instance.exe'), Command + ' "' + ConfigPath + '" "' + WizardDirValue + '" "' + ExpandConstant('{tmp}\phobos-maintenance.txt') + '"', '', SW_HIDE, ewWaitUntilTerminated, Code) then begin
    Details := 'Could not start PHOBOS maintenance inspection.'; Result := 1; exit;
  end;
  if not LoadStringsFromFile(ExpandConstant('{tmp}\phobos-maintenance.txt'), Lines) then Details := 'PHOBOS maintenance inspection did not return a report.'
  else for N := 0 to GetArrayLength(Lines) - 1 do begin
    if N > 0 then Details := Details + #13#10;
    Details := Details + Lines[N];
  end;
  Result := Code;
end;

procedure InitializeWizard();
begin
  MaintenancePage := CreateOutputMsgPage(wpWelcome, 'Installation or maintenance', 'PHOBOS validates the instance before replacing files.', 'Instance inspection runs before file replacement.');
end;

procedure RefreshMaintenance();
var Details: String; Code: Integer;
begin
  Code := InspectInstance('setup-inspect', Details);
  RepairMode := (Code = 0) and (Pos('REPAIR', Details) = 1);
  if RepairMode then begin
    RepairInfo := Copy(Details, 9, Length(Details));
    WizardForm.WelcomeLabel1.Caption := 'Repair PHOBOS Community Edition';
    WizardForm.WelcomeLabel2.Caption := RepairInfo;
    MaintenancePage.MsgLabel.Caption := RepairInfo;
  end else if Code <> 0 then MaintenancePage.MsgLabel.Caption := 'Setup cannot safely use this location. ' + Details
  else MaintenancePage.MsgLabel.Caption := 'Fresh installation. A visible configuration dialog will request new instance settings after files are installed. Existing database directories are never reinitialized.';
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var Details: String;
begin
  Result := True;
  if (CurPageID = wpWelcome) or (CurPageID = wpSelectDir) or (CurPageID = wpSelectComponents) or (CurPageID = MaintenancePage.ID) then begin
    if InspectInstance('setup-inspect', Details) <> 0 then begin
      MsgBox(Details, mbError, MB_OK); Result := False; exit;
    end;
    RepairMode := Pos('REPAIR', Details) = 1;
    if RepairMode then begin
      RepairInfo := Copy(Details, 9, Length(Details));
      MaintenancePage.MsgLabel.Caption := RepairInfo;
      WizardForm.PageNameLabel.Caption := 'Repair existing PHOBOS installation';
    end;
  end;
end;

function UpdateReadyMemo(Space, NewLine, MemoUserInfoInfo, MemoDirInfo, MemoTypeInfo, MemoComponentsInfo, MemoGroupInfo, MemoTasksInfo: String): String;
begin
  Result := MemoDirInfo + NewLine + MemoComponentsInfo;
  if RepairMode then Result := RepairInfo + NewLine + NewLine + Result;
end;

function InitializeSetup(): Boolean;
var FrameworkRelease: Cardinal;
    ExistingDir, Key: String; Location: TArrayOfString; N: Integer;
begin
  Key := ExpandConstant('{param:INSTANCEKEY|}');
  if Key <> '' then begin
    if Length(Key) > 48 then begin Result := False; exit; end;
    for N := 1 to Length(Key) do if Pos(Key[N], 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-') = 0 then begin Result := False; exit; end;
    if (ExpandConstant('{param:INSTANCECONFIG|}') = '') or (ExpandConstant('{param:DIR|}') = '') or (ExpandConstant('{param:SERVICENAME|PHOBOSDatabase}') = 'PHOBOSDatabase') or (ExpandConstant('{param:PORT|}') = '') then begin
      MsgBox('A separate INSTANCEKEY requires explicit isolated DIR, INSTANCECONFIG, SERVICENAME and PORT parameters.', mbError, MB_OK); Result := False; exit;
    end;
  end;
  ConfigPath := ExpandConstant('{param:INSTANCECONFIG|}');
  if (ConfigPath = '') and RegQueryStringValue(HKLM64, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\' + ProductId('') + '_is1', 'InstallLocation', ExistingDir) then begin
    if not LoadStringsFromFile(AddBackslash(ExistingDir) + 'config-location.txt', Location) or (GetArrayLength(Location) <> 1) then begin
      MsgBox('Existing installation has missing or ambiguous instance metadata. Repair stopped.', mbError, MB_OK); Result := False; exit;
    end;
    ConfigPath := Location[0];
  end;
  if ConfigPath = '' then ConfigPath := ExpandConstant('{commonappdata}\PHOBOS\config\instance.json');
  if (Key <> '') and (CompareText(ConfigPath, ExpandConstant('{commonappdata}\PHOBOS\config\instance.json')) = 0) then begin
    MsgBox('A separate INSTANCEKEY cannot target the primary instance configuration.', mbError, MB_OK); Result := False; exit;
  end;
  FilesOnly := ExpandConstant('{param:FILESONLY|0}') = '1';
  Configured := False;
  Result := True;
  if not RegQueryDWordValue(HKLM64, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', FrameworkRelease) or (FrameworkRelease < 528040) then begin
    MsgBox('PHOBOS Windows tools require .NET Framework 4.8 (included with current Windows 10/11). Install this Windows prerequisite and run Setup again.', mbError, MB_OK);
    Result := False;
    exit;
  end;
  if WizardSilent and not FilesOnly then begin
    MsgBox('Silent installation requires /FILESONLY=1. Credentials must be entered in the configuration dialog or passed through the documented stdin automation interface.', mbError, MB_OK);
    Result := False;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var Code: Integer;
    VersionMS, VersionLS: Cardinal;
    ExistingDir, RequestedDir, Details: String;
begin
  Result := '';
  if RegQueryStringValue(HKLM64, 'Software\Microsoft\Windows\CurrentVersion\Uninstall\' + ProductId('') + '_is1', 'InstallLocation', ExistingDir) then begin
    RequestedDir := WizardDirValue;
    while (Length(ExistingDir) > 3) and (Copy(ExistingDir, Length(ExistingDir), 1) = '\') do Delete(ExistingDir, Length(ExistingDir), 1);
    while (Length(RequestedDir) > 3) and (Copy(RequestedDir, Length(RequestedDir), 1) = '\') do Delete(RequestedDir, Length(RequestedDir), 1);
    if CompareText(ExistingDir, RequestedDir) <> 0 then begin
      Result := 'An existing PHOBOS installation is registered at ' + ExistingDir + '. Repair must use that directory. Uninstall it (keeping data) before selecting another binary directory.'; exit;
    end;
  end;
  if not GetVersionNumbers(ExpandConstant('{sys}\vcruntime140.dll'), VersionMS, VersionLS) or (VersionMS < ((14 shl 16) or 44)) then begin
    ExtractTemporaryFile('vc_redist.x64.exe');
    if not Exec(ExpandConstant('{tmp}\vc_redist.x64.exe'), '/install /quiet /norestart', '', SW_HIDE, ewWaitUntilTerminated, Code) then begin
      Result := 'Could not launch the Microsoft Visual C++ runtime prerequisite.'; exit;
    end;
    if Code = 3010 then begin
      NeedsRestart := True; Result := 'The Microsoft runtime requires a Windows restart. Restart and rerun PHOBOS Setup.'; exit;
    end;
    if (Code <> 0) and (Code <> 1638) then begin
      Result := 'Microsoft runtime installation failed with code ' + IntToStr(Code) + '.'; exit;
    end;
  end;
  repeat
    Code := InspectInstance('setup-prepare', Details);
    if Code = 0 then begin Result := ''; exit; end;
    if (Code <> 20) or WizardSilent then begin Result := Details; exit; end;
    if MsgBox(Details, mbInformation, MB_RETRYCANCEL) <> IDRETRY then begin Result := 'Repair cancelled before file replacement. ' + Details; exit; end;
  until False;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var Code: Integer;
    Location: TArrayOfString;
begin
  if CurStep = ssPostInstall then begin
    SetArrayLength(Location, 1); Location[0] := ConfigPath;
    if not SaveStringsToUTF8File(ExpandConstant('{app}\config-location.txt'), Location, False) then
      RaiseException('Could not save the installation config locator. Instance setup has not started.');
    if not FilesOnly then begin
      WizardForm.StatusLabel.Caption := 'Configuring PHOBOS database instance...';
      WizardForm.FilenameLabel.Caption := 'Complete the separate PHOBOS configuration dialog to continue.';
      WizardForm.Refresh;
      // Interactive input must be visible. Noninteractive prepare/remove remain hidden.
      Configured := Exec(ExpandConstant('{app}\bin\phobos-instance.exe'), 'configure "' + ConfigPath + '" "' + ExpandConstant('{app}') + '" ' + IntToStr(WizardForm.Handle) + ' ' + ExpandConstant('{param:SERVICENAME|PHOBOSDatabase}') + ' ' + ExpandConstant('{param:PORT|54321}'), '', SW_SHOWNORMAL, ewWaitUntilTerminated, Code) and (Code = 0);
      WizardForm.FilenameLabel.Caption := '';
      if not Configured then begin
        WizardForm.FinishedLabel.Caption := 'PHOBOS binaries were installed, but instance setup did not complete. No readiness claim is made. Data is preserved. Run phobos-instance configure using the documented command to inspect/retry.';
        MsgBox('Instance setup did not complete. Binaries remain installed for diagnosis; data has been preserved. See the installation guide.', mbError, MB_OK);
      end;
    end;
  end;
end;

procedure CurPageChanged(CurPageID: Integer);
begin
  if CurPageID = wpWelcome then RefreshMaintenance();
  if (CurPageID = wpReady) and RepairMode then WizardForm.NextButton.Caption := 'Repair';
  if CurPageID = wpFinished then begin
    if FilesOnly then WizardForm.FinishedLabel.Caption := 'PHOBOS runtime files installed. FILESONLY mode does not initialize, start or validate an instance.'
    else if Configured then begin
      if RepairMode then WizardForm.FinishedLabel.Caption := 'PHOBOS Community Edition 1.0.1 repaired successfully.' + #13#10 + RepairInfo + #13#10 + 'Status: Running. Authenticated SQL / Management API v1 checks passed. Existing database and credentials were preserved.'
      else WizardForm.FinishedLabel.Caption := 'PHOBOS Community Edition 1.0.1 instance is running and authenticated SQL / Management API v1 checks passed.';
    end
    else WizardForm.FinishedLabel.Caption := 'PHOBOS files are installed, but instance setup did not complete. No readiness claim is made. Data is preserved; inspect the installation guide and logs before retrying.';
  end;
end;

function GetCustomSetupExitCode(): Integer;
begin
  if not FilesOnly and not Configured then Result := 2 else Result := 0;
end;

function InitializeUninstall(): Boolean;
var Code: Integer;
    Location: TArrayOfString;
begin
  Result := False;
  if not LoadStringsFromFile(ExpandConstant('{app}\config-location.txt'), Location) then begin
    MsgBox('Missing configuration locator. Uninstall stopped to avoid removing binaries from an unknown running instance.', mbError, MB_OK);
    exit;
  end;
  if GetArrayLength(Location) <> 1 then begin
    MsgBox('Invalid configuration locator. Uninstall stopped.', mbError, MB_OK); exit;
  end;
  if not UninstallSilent then
    if MsgBox('Uninstall PHOBOS? Database data, authentication, configuration, logs and backups will be KEPT. Destructive data removal is deliberately a separate administrator operation.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) <> IDYES then exit;
  Result := Exec(ExpandConstant('{app}\bin\phobos-instance.exe'), 'remove "' + Location[0] + '"', '', SW_HIDE, ewWaitUntilTerminated, Code) and (Code = 0);
  if not Result then MsgBox('PHOBOS could not stop/remove its service safely. Uninstall is blocked; binaries and data are retained. Inspect service/logs and retry.', mbError, MB_OK);
end;

[UninstallDelete]
Type: files; Name: "{app}\config-location.txt"

