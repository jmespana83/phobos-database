using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Phobos.Windows;

// Native SCM boundary, deliberately outside all platform-neutral engine crates.
internal static class ServiceHost {
    [StructLayout(LayoutKind.Sequential)] struct Status { public uint type,state,accepted,win32,specific,checkpoint,hint; }
    [UnmanagedFunctionPointer(CallingConvention.Winapi)] delegate void MainFn(uint count,IntPtr args);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)] delegate uint HandlerFn(uint control,uint kind,IntPtr data,IntPtr context);
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct Entry { [MarshalAs(UnmanagedType.LPWStr)] public string name; public MainFn main; }
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool StartServiceCtrlDispatcher(Entry[] entries);
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr RegisterServiceCtrlHandlerEx(string name,HandlerFn handler,IntPtr context);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool SetServiceStatus(IntPtr handle,ref Status status);
    static readonly MainFn mainFn=ServiceMain;
    static readonly HandlerFn handler=Control;
    static readonly ManualResetEvent stop=new ManualResetEvent(false);
    static readonly object logLock=new object();
    static Instance instance;static IntPtr statusHandle;static uint checkpoint;static string manifest;static StreamWriter log;
    static void Report(uint state,uint error) {
        Status s=new Status {type=0x10,state=state,accepted=state==4?0x105u:0u,win32=error==0?0u:1066u,specific=error,checkpoint=(state==2||state==3)?++checkpoint:0,hint=(state==2||state==3)?15000u:0u};
        if(!SetServiceStatus(statusHandle,ref s)) throw new Win32Exception(Marshal.GetLastWin32Error());
    }
    static uint Control(uint command,uint kind,IntPtr data,IntPtr context) {if(command==1||command==5||command==15)stop.Set();return 0;}
    static void Log(string text) {lock(logLock){if(log!=null){log.WriteLine(DateTime.UtcNow.ToString("o")+" "+text);log.Flush();}}}
    static void ServiceMain(uint argc,IntPtr argv) {
        Process child=null;uint error=0;CrashContainment job=null;
        statusHandle=RegisterServiceCtrlHandlerEx(instance.serviceName,handler,IntPtr.Zero);
        if(statusHandle==IntPtr.Zero)return;
        try {
            Report(2,0);
            string path=Path.Combine(instance.logDirectory,"server-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+".log");
            log=new StreamWriter(new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.Read),new UTF8Encoding(false));
            Log("PHOBOS 1.0.1 service starting; config="+manifest+"; recovery policy: "+instance.recoveryPolicy);
            job=new CrashContainment();
            child=Ops.Launch(instance,Log);
            job.Assign(child);
            Ops.Ready(instance,child,()=>Report(2,0));
            Log("Server ready PID="+child.Id+" endpoint="+instance.Endpoint);Report(4,0);
            while(!stop.WaitOne(250)) if(child.HasExited) throw new Exception("Server exited unexpectedly: "+child.ExitCode);
            Log("Graceful service stop requested");Report(3,0);
            Ops.Drain(instance,child,()=>Report(3,0));Log("Graceful service stop completed");
        } catch(Exception ex) {
            error=1;Log("Service failure: "+ex.Message);
            // Even failed startup requests a normal drain. No routine taskkill/TerminateProcess.
            try {if(child!=null&&!child.HasExited){Report(3,0);Ops.Drain(instance,child,()=>Report(3,0));}}catch(Exception e){Log("Shutdown failure: "+e.Message);}
        } finally {
            if(child!=null){if(child.HasExited)child.WaitForExit();child.Dispose();}
            if(job!=null)job.Dispose();
            lock(logLock){if(log!=null){log.Dispose();log=null;}}
            Report(1,error);
        }
    }
    static int Main(string[] args) {
        try {
            if(args.Length!=2||args[0]!="--config")throw new Exception("Usage: phobos-service --config ABSOLUTE_INSTANCE_JSON (SCM only)");
            manifest=args[1];instance=Ops.Load(manifest);
            if(!StartServiceCtrlDispatcher(new [] {new Entry {name=instance.serviceName,main=mainFn},new Entry()}))throw new Win32Exception(Marshal.GetLastWin32Error());
            return 0;
        }catch(Exception e){Console.Error.WriteLine("PHOBOS service: "+e.Message);return 1;}
    }
}

// Crash containment only: if the service host is externally terminated, its child
// must not become an orphaned database server. Normal Stop drains before closing
// the job. An external crash follows the engine's existing WAL recovery path.
internal sealed class CrashContainment : IDisposable {
    [StructLayout(LayoutKind.Sequential)] struct Basic {public long processTime,jobTime;public uint flags;public UIntPtr minWorking,maxWorking;public uint activeProcesses;public UIntPtr affinity;public uint priority,scheduling;}
    [StructLayout(LayoutKind.Sequential)] struct Io {public ulong readOps,writeOps,otherOps,readBytes,writeBytes,otherBytes;}
    [StructLayout(LayoutKind.Sequential)] struct Extended {public Basic basic;public Io io;public UIntPtr processMemory,jobMemory,peakProcess,peakJob;}
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr security,string name);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int kind,ref Extended info,uint size);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    IntPtr handle;
    public CrashContainment() {
        handle=CreateJobObject(IntPtr.Zero,null);if(handle==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
        var info=new Extended();info.basic.flags=0x2000;
        if(!SetInformationJobObject(handle,9,ref info,(uint)Marshal.SizeOf(typeof(Extended)))){int error=Marshal.GetLastWin32Error();Dispose();throw new Win32Exception(error);}
    }
    public void Assign(Process process) {if(!AssignProcessToJobObject(handle,process.Handle))throw new Win32Exception(Marshal.GetLastWin32Error());}
    public void Dispose(){if(handle!=IntPtr.Zero){CloseHandle(handle);handle=IntPtr.Zero;}}
}
