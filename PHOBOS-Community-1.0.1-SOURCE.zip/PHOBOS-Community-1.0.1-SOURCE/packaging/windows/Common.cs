// Windows distribution boundary. No engine dependency or file-format implementation.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

[assembly: System.Reflection.AssemblyProduct("PHOBOS Community Edition 1.0.1")]
[assembly: System.Reflection.AssemblyVersion("1.0.1.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.1.0")]

namespace Phobos.Windows {
public sealed class Instance {
    public int schemaVersion = 1;
    public string productVersion = "1.0.1";
    public string engineVersion = "1.0.1";
    public string serviceName = "PHOBOSDatabase";
    public string installDirectory;
    public string dataDirectory;
    public string logDirectory;
    public string controlDirectory;
    public string authFile;
    public string runtimeConfig;
    public string bindAddress = "127.0.0.1";
    public int port = 54321;
    public string adminUser = "admin";
    public string serviceAccount = @"NT AUTHORITY\LocalService";
    public string walMode = "flush";
    public string recoveryPolicy = "none; administrator investigates and restarts";
    public string state = "initializing";
    public string instanceId = Guid.NewGuid().ToString("D");
    public string Endpoint { get { return bindAddress + ":" + port; } }
    public string Shutdown { get { return Path.Combine(controlDirectory, "shutdown.request"); } }
    public string Binary(string name) { return Path.Combine(installDirectory, "bin", name + ".exe"); }
    public static bool Compatible(string version) { return version=="1.0.0" || version=="1.0.1"; }
    public void Validate() {
        if (schemaVersion != 1 || !Compatible(productVersion) || !Compatible(engineVersion)) throw new Exception("Unsupported installation metadata version; cross-version upgrade requires an explicit migration.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(serviceName ?? "", "^PHOBOS[A-Za-z0-9_-]{0,48}$")) throw new Exception("Invalid service name.");
        if (bindAddress != "127.0.0.1" || port < 1 || port > 65535) throw new Exception("Windows setup requires loopback IPv4 and a port from 1 to 65535.");
        if (serviceAccount != @"NT AUTHORITY\LocalService" || walMode != "flush") throw new Exception("Unsupported identity or durability setting.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(adminUser ?? "", "^[A-Za-z][A-Za-z0-9_-]{0,63}$")) throw new Exception("Administrator name must start with a letter and contain only letters, digits, underscore or hyphen (maximum 64 characters).");
        foreach (string p in new [] { installDirectory, dataDirectory, logDirectory, controlDirectory, authFile, runtimeConfig }) Ops.SafePath(p);
        string configRoot = Path.GetDirectoryName(authFile);
        foreach (string p in new [] {installDirectory, configRoot, dataDirectory, logDirectory, controlDirectory})
          foreach (string q in new [] {installDirectory, configRoot, dataDirectory, logDirectory, controlDirectory})
            if (p != q && Ops.Within(p,q)) throw new Exception("Binary, config, data, log and control directories must be separate, non-nested directories.");
        if (new [] {installDirectory, configRoot, dataDirectory, logDirectory, controlDirectory}.Select(Path.GetFullPath).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=5) throw new Exception("Instance directories must be distinct.");
        if (!String.Equals(Path.GetDirectoryName(runtimeConfig),configRoot,StringComparison.OrdinalIgnoreCase)) throw new Exception("Runtime config must reside beside auth metadata.");
    }
}

public static class Ops {
    public static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    public static string Quote(string s) {
        var b=new StringBuilder("\"");int slashes=0;
        foreach(char c in s){if(c=='\\'){slashes++;continue;}if(c=='"'){b.Append('\\',slashes*2+1);b.Append(c);}else{b.Append('\\',slashes);b.Append(c);}slashes=0;}
        b.Append('\\',slashes*2);b.Append('"');return b.ToString();
    }
    public static bool Within(string p,string parent) { return Path.GetFullPath(p).StartsWith(Path.GetFullPath(parent).TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase); }
    public static void SafePath(string p) {
        if (String.IsNullOrWhiteSpace(p) || !Path.IsPathRooted(p) || p.StartsWith(@"\\") || p.IndexOfAny(new [] {'"','\r','\n','\0'})>=0 || Path.GetFullPath(p).Length<4 || p.Length>200) throw new Exception("Use an absolute local path (not a drive root, network path or path over 200 characters).");
        if(p.Length<3||p[1]!=':'||p[2]!='\\'||p.Substring(2).IndexOfAny(new [] {':','~','*','?','<','>','|'})>=0||p.Split('\\').Skip(1).Any(part=>part.EndsWith(".")||part.EndsWith(" ")))throw new Exception("Use normal long directory names without alternate streams, short-name aliases, wildcard characters or trailing dots/spaces.");
        string full=Path.GetFullPath(p);
        if (!String.Equals(full.TrimEnd('\\'),p.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase)) throw new Exception("Paths must be canonical, without parent-directory components.");
        for (string x=full; !String.IsNullOrEmpty(x); x=Path.GetDirectoryName(x))
            if ((Directory.Exists(x)||File.Exists(x)) && (File.GetAttributes(x)&FileAttributes.ReparsePoint)!=0) throw new Exception("Reparse points are not accepted in installation paths.");
    }
    public static void RequireAdmin() {
        if (!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator)) throw new Exception("Administrator elevation is required. Run the installer or management command as administrator.");
    }
    public static void SecretCheck(string s) {
        if (s==null || s.Length<12 || s.Length>256 || s.IndexOfAny(new [] {'\0','\r','\n'})>=0) throw new Exception("Use a password of 12 to 256 characters with no line breaks or NUL.");
    }
    public static Instance Load(string path) {
        SafePath(path);
        var i=Json.Deserialize<Instance>(File.ReadAllText(path)); i.Validate();
        if (!String.Equals(Path.GetDirectoryName(path),Path.GetDirectoryName(i.authFile),StringComparison.OrdinalIgnoreCase)) throw new Exception("Instance manifest must reside in the protected config directory.");
        return i;
    }
    public static void UpdateVersions(string path,Instance i) {
        // Preserve extension fields and all operational settings during patch repair.
        var document=Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path));
        document["productVersion"]=i.productVersion;document["engineVersion"]=i.engineVersion;
        string temporary=path+".new";
        File.WriteAllText(temporary,Json.Serialize(document),new UTF8Encoding(false));
        File.Replace(temporary,path,null);
    }
    public static void Save(string path,Instance i) {
        string temp=path+".new";
        File.WriteAllText(temp,Json.Serialize(i),new UTF8Encoding(false));
        if(File.Exists(path)) File.Replace(temp,path,null); else File.Move(temp,path);
    }
    public static void SecureDirectory(string path,string sid, bool writable, bool publicRead) {
        SafePath(path); Directory.CreateDirectory(path);
        var acl=new DirectorySecurity(); acl.SetAccessRuleProtection(true,false);
        var admin=new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null);
        acl.SetOwner(admin);
        var inherit=InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit;
        foreach(var id in new [] {admin,new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null)})
            acl.AddAccessRule(new FileSystemAccessRule(id,FileSystemRights.FullControl,inherit,PropagationFlags.None,AccessControlType.Allow));
        if(publicRead) acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid,null),FileSystemRights.ReadAndExecute,inherit,PropagationFlags.None,AccessControlType.Allow));
        if(sid!=null) acl.AddAccessRule(new FileSystemAccessRule(new NTAccount(sid),writable ? FileSystemRights.Modify:FileSystemRights.ReadAndExecute,inherit,PropagationFlags.None,AccessControlType.Allow));
        Directory.SetAccessControl(path,acl);
    }
    public static void SecureNewParents(string path) {
        string parent=Path.GetDirectoryName(path);
        if(!String.IsNullOrEmpty(parent)&&!Directory.Exists(parent)){SecureNewParents(parent);SecureDirectory(parent,null,false,true);}
    }
    public static void ProtectedParents(string directory) {
        for(string p=Path.GetDirectoryName(directory);!String.IsNullOrEmpty(p);p=Path.GetDirectoryName(p)) {
            if(!Directory.Exists(p))continue;
            var acl=Directory.GetAccessControl(p);
            foreach(FileSystemAccessRule rule in acl.GetAccessRules(true,true,typeof(SecurityIdentifier))) {
                string sid=rule.IdentityReference.Value;
                if(sid=="S-1-5-18"||sid=="S-1-5-32-544"||sid=="S-1-3-0"||sid.StartsWith("S-1-5-80-"))continue;
                var dangerous=FileSystemRights.DeleteSubdirectoriesAndFiles|FileSystemRights.ChangePermissions|FileSystemRights.TakeOwnership;
                if(rule.AccessControlType==AccessControlType.Allow&&(rule.FileSystemRights&dangerous)!=0&&(rule.PropagationFlags&PropagationFlags.InheritOnly)==0) throw new Exception("A directory parent is writable by a non-administrator: "+p+". Choose an administrator-controlled local path.");
            }
        }
    }
    public static ProcessStartInfo StartInfo(string exe,string args) {
        var p=new ProcessStartInfo(exe,args);p.UseShellExecute=false;p.CreateNoWindow=true;
        p.WorkingDirectory=Path.GetDirectoryName(exe);p.RedirectStandardOutput=true;p.RedirectStandardError=true;
        p.StandardOutputEncoding=Encoding.UTF8;p.StandardErrorEncoding=Encoding.UTF8;
        foreach(string key in p.EnvironmentVariables.Keys.Cast<string>().Where(k=>k.StartsWith("PHOBOS_",StringComparison.OrdinalIgnoreCase)||k.StartsWith("COMPLUS_",StringComparison.OrdinalIgnoreCase)||k.StartsWith("COR_",StringComparison.OrdinalIgnoreCase)).ToArray()) p.EnvironmentVariables.Remove(key);
        p.EnvironmentVariables["PATH"]=Environment.GetFolderPath(Environment.SpecialFolder.System)+";"+Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        return p;
    }
    public static string Run(string exe,string args,string input) {
        var pi=StartInfo(exe,args);pi.RedirectStandardInput=true;
        using(var p=new Process {StartInfo=pi}) {
            p.Start(); var stdout=p.StandardOutput.ReadToEndAsync();var stderr=p.StandardError.ReadToEndAsync();
            if(input!=null) {using(var writer=new StreamWriter(p.StandardInput.BaseStream,new UTF8Encoding(false),1024,true)){writer.Write(input);writer.Flush();}} p.StandardInput.Close();
            if(!p.WaitForExit(120000)) throw new Exception("Operation timed out; inspect instance logs before retrying. No process was killed.");
            string text=stdout.Result;string err=stderr.Result;
            // Never include credential-bearing invocation input in errors/logging.
            if(p.ExitCode!=0) throw new Exception(Path.GetFileName(exe)+" failed (exit "+p.ExitCode+"): "+err);
            return text;
        }
    }
    public static string Sc(string args) { return Run(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"sc.exe"),args,null); }
    public static void PortFree(int port) {
        var listener=new TcpListener(IPAddress.Loopback,port);
        try {listener.Server.ExclusiveAddressUse=true;listener.Start();}
        catch(SocketException) {throw new Exception("Port "+port+" is unavailable (listening PID "+Native.ListenerPid(port)+"). Choose another port; no existing process was stopped.");}
        finally {listener.Stop();}
    }
    public static Process Launch(Instance i,Action<string> log) {
        i.Validate();
        if(!File.Exists(i.authFile)) throw new Exception("Authentication file missing; refusing unauthenticated startup.");
        if(File.Exists(i.Shutdown)) File.Delete(i.Shutdown);
        PortFree(i.port);
        var p=new Process {StartInfo=StartInfo(i.Binary("phobos-server"),"--config "+Quote(i.runtimeConfig)+" --data-dir "+Quote(i.dataDirectory)+" --auth-file "+Quote(i.authFile)+" --shutdown-file "+Quote(i.Shutdown)+" --bind "+Quote(i.Endpoint)+" --wal-mode flush")};
        p.OutputDataReceived+=(s,e)=>{if(e.Data!=null)log(e.Data);};p.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)log(e.Data);};
        p.Start();p.BeginOutputReadLine();p.BeginErrorReadLine();return p;
    }
    public static void Ready(Instance i,Process child,Action tick) {
        var until=DateTime.UtcNow.AddSeconds(120);
        while(DateTime.UtcNow<until) {
            if(child.HasExited) throw new Exception("Server exited during startup ("+child.ExitCode+"). Inspect logs.");
            if(Native.ListenerPid(i.port)==child.Id) {using(var p=new Probe(i.port)) p.Hello();return;}
            tick();Thread.Sleep(250);
        }
        throw new Exception("Server did not become ready within 120 seconds.");
    }
    public static void Drain(Instance i,Process child,Action tick) {
        if(child==null) return;
        if(child.HasExited){child.WaitForExit();return;}
        File.WriteAllText(i.Shutdown,"shutdown\n",new UTF8Encoding(false));
        // Never forcibly kill the engine. Checkpoints keep SCM informed while WAL drains.
        while(!child.WaitForExit(1000)) tick();
        child.WaitForExit();
        if(child.ExitCode!=0) throw new Exception("Server shutdown failed ("+child.ExitCode+"). Recovery may be required.");
    }
    public static void ValidateLogin(Instance i,string password) {
        using(var p=new Probe(i.port)) {
            p.Hello();p.Auth(i.adminUser,password);
            string capabilities=p.Query("SHOW CATALOG CAPABILITIES");
            if(!capabilities.Contains("management_api_version\t1") || !capabilities.Contains("server_version\t1.0.1")) throw new Exception("Unexpected management API/engine capabilities.");
            p.Query("SHOW CATALOG TABLES");
            string table="phobos_install_check_"+Guid.NewGuid().ToString("N");
            p.Query("BEGIN");
            try {
                p.Query("CREATE TABLE "+table+" (id BIGINT NOT NULL)");
                p.Query("INSERT INTO "+table+" VALUES (1)");
                string result=p.Query("SELECT id FROM "+table);
                if(!result.Split(new [] {'\t','\r','\n'},StringSplitOptions.RemoveEmptyEntries).Contains("1"))throw new Exception("Installation SQL smoke returned an unexpected row.");
            } finally {p.Query("ROLLBACK");}
            if(p.Query("SHOW CATALOG TABLES").Contains(table))throw new Exception("Installation SQL smoke rollback did not remove its private table.");
        }
    }
}

// A bounded installer health probe using the existing public wire protocol.
// Queries never pass through the service host during normal operation.
public sealed class Probe : IDisposable {
    TcpClient client; NetworkStream stream; uint id;
    public Probe(int port) {client=new TcpClient();client.NoDelay=true;client.ReceiveTimeout=5000;client.SendTimeout=5000;client.Connect(IPAddress.Loopback,port);stream=client.GetStream();}
    static void Put(byte[] b,int n,uint v) {b[n]=(byte)(v>>24);b[n+1]=(byte)(v>>16);b[n+2]=(byte)(v>>8);b[n+3]=(byte)v;}
    static uint Get(byte[] b,int n) {return ((uint)b[n]<<24)|((uint)b[n+1]<<16)|((uint)b[n+2]<<8)|b[n+3];}
    void Read(byte[] b) {int n=0;while(n<b.Length){int k=stream.Read(b,n,b.Length-n);if(k==0)throw new IOException("Health probe connection closed.");n+=k;}}
    string Exchange(byte type,byte expected,byte[] body) {
        uint request=++id;byte[] frame=new byte[16+body.Length];Encoding.ASCII.GetBytes("PHOB").CopyTo(frame,0);frame[4]=1;frame[5]=type;Put(frame,8,request);Put(frame,12,(uint)body.Length);body.CopyTo(frame,16);
        try {stream.Write(frame,0,frame.Length);} finally {Array.Clear(frame,0,frame.Length);Array.Clear(body,0,body.Length);}
        byte[] h=new byte[16];Read(h);
        if(Encoding.ASCII.GetString(h,0,4)!="PHOB"||h[4]!=1||h[6]!=0||h[7]!=0||Get(h,8)!=request||Get(h,12)>1048576) throw new IOException("Invalid health probe frame.");
        byte[] payload=new byte[(int)Get(h,12)];Read(payload);
        if(h[5]==255) throw new Exception("PHOBOS rejected the health-check request (credentials or SQL). No secret was logged.");
        if(h[5]!=expected) throw new IOException("Unexpected health probe response.");
        return Encoding.UTF8.GetString(payload);
    }
    public string Hello() {return Exchange(1,2,Encoding.UTF8.GetBytes("phobos-installer-1.0.1"));}
    public void Auth(string user,string password) {Exchange(5,6,Encoding.UTF8.GetBytes(user+"\0"+password));}
    public string Query(string sql) {return Exchange(10,11,Encoding.UTF8.GetBytes(sql));}
    public void Dispose() {if(stream!=null)stream.Dispose();if(client!=null)client.Close();}
}

public static class Native {
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr OpenSCManager(string machine,string database,uint access);
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr OpenService(IntPtr manager,string name,uint access);
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool ChangeServiceConfig2(IntPtr service,uint level,ref uint value);
    [DllImport("advapi32.dll")] static extern bool CloseServiceHandle(IntPtr handle);
    public static void Preshutdown(string name) {
        IntPtr manager=OpenSCManager(null,null,1);if(manager==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        try{IntPtr service=OpenService(manager,name,2);if(service==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());try{uint milliseconds=180000;if(!ChangeServiceConfig2(service,7,ref milliseconds))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}finally{CloseServiceHandle(service);}}finally{CloseServiceHandle(manager);}
    }
    [DllImport("iphlpapi.dll",SetLastError=true)] static extern uint GetExtendedTcpTable(IntPtr p,ref int size,bool order,int family,int table,int reserved);
    public static int ListenerPid(int port) {
        int size=0;GetExtendedTcpTable(IntPtr.Zero,ref size,true,2,3,0);
        IntPtr p=Marshal.AllocHGlobal(size);
        try {if(GetExtendedTcpTable(p,ref size,true,2,3,0)!=0)return -1;int count=Marshal.ReadInt32(p);for(int n=0;n<count;n++) {int off=4+n*24;int state=Marshal.ReadInt32(p,off);int raw=Marshal.ReadInt32(p,off+8);int localPort=((raw&255)<<8)|((raw>>8)&255);if(state==2&&localPort==port)return Marshal.ReadInt32(p,off+20);}return -1;}finally{Marshal.FreeHGlobal(p);}
    }
}
}
