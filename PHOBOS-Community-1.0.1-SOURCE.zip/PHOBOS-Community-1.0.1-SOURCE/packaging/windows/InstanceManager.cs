using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using Phobos.Windows;

public static class InstanceManager {
#if PHOBOS_INSTALLER_TESTS
    public static Action<string> TestCheckpoint;
#endif
    [Conditional("PHOBOS_INSTALLER_TESTS")]
    static void Checkpoint(string point) {
#if PHOBOS_INSTALLER_TESTS
        if(TestCheckpoint!=null)TestCheckpoint(point);
#endif
    }
    // Setup passes its window handle, never credentials. An owned modal stays discoverable.
    sealed class SetupOwner : IWin32Window {
        public IntPtr Handle { get; private set; }
        public SetupOwner(IntPtr handle) { Handle=handle; }
    }
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr handle);
    public static Instance Inspect(string manifest,string directory) {
        Ops.RequireAdmin();Ops.SafePath(manifest);Ops.SafePath(directory);
        if(!File.Exists(manifest)) {
            if(Directory.Exists(directory)&&Directory.EnumerateFileSystemEntries(directory).Any())throw new Exception("No compatible instance manifest was found. Select an empty installation directory; existing files/data will not be initialized or overwritten.");
            return null;
        }
        var i=Ops.Load(manifest);
        ProtectedMetadata(manifest);ProtectedMetadata(directory);
        if(!String.Equals(i.installDirectory,directory,StringComparison.OrdinalIgnoreCase)||i.state!="ready")throw new Exception("Repair requires the original binary directory and a ready compatible instance. Incomplete or ambiguous state requires administrator inspection.");
        using(var k=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\PHOBOS\Instances\"+i.serviceName)) {
            if(k==null||!String.Equals(Convert.ToString(k.GetValue("Manifest")),manifest,StringComparison.OrdinalIgnoreCase)||!Instance.Compatible(Convert.ToString(k.GetValue("ProductVersion"))))throw new Exception("Protected instance discovery metadata does not match. Repair stopped before replacing files.");
        }
        if(Exists(i.serviceName))Owned(i);
        foreach(string name in new [] {"phobos-server","phobos-cli","phobos-admin"}) {
            string exe=i.Binary(name);ProtectedMetadata(exe);
            string version=Ops.Run(exe,"--version",null).Trim();
            string label=name=="phobos-server"?"Server":name=="phobos-cli"?"Cli":"Admin";
            if(version!="PHOBOS "+label+" 1.0.0 Community Edition"&&version!="PHOBOS "+label+" 1.0.1 Community Edition")throw new Exception("Incompatible installed engine identity: "+name+". Repair stopped.");
        }
        return i;
    }
    static void ProtectedMetadata(string path) {
        Ops.SafePath(path);Ops.ProtectedParents(path);
        var acl=Directory.Exists(path)?(System.Security.AccessControl.FileSystemSecurity)Directory.GetAccessControl(path):File.GetAccessControl(path);
        var dangerous=System.Security.AccessControl.FileSystemRights.WriteData|System.Security.AccessControl.FileSystemRights.AppendData|System.Security.AccessControl.FileSystemRights.WriteAttributes|System.Security.AccessControl.FileSystemRights.WriteExtendedAttributes|System.Security.AccessControl.FileSystemRights.Delete|System.Security.AccessControl.FileSystemRights.DeleteSubdirectoriesAndFiles|System.Security.AccessControl.FileSystemRights.ChangePermissions|System.Security.AccessControl.FileSystemRights.TakeOwnership;
        foreach(System.Security.AccessControl.FileSystemAccessRule rule in acl.GetAccessRules(true,true,typeof(System.Security.Principal.SecurityIdentifier))) {
            string sid=rule.IdentityReference.Value;
            if(sid=="S-1-5-18"||sid=="S-1-5-32-544"||sid.StartsWith("S-1-5-80-"))continue;
            if(rule.AccessControlType==System.Security.AccessControl.AccessControlType.Allow&&(rule.FileSystemRights&dangerous)!=0&&(rule.PropagationFlags&System.Security.AccessControl.PropagationFlags.InheritOnly)==0)throw new Exception("Installation metadata/binaries are writable by a non-administrator. Refusing repair: "+path);
        }
    }
    public static void Prepare(string manifest,string directory) {
        var i=Inspect(manifest,directory);
        if(i!=null) {
            RuntimeLocks.RequireClosed(directory,true);
            Stop(i);
            RuntimeLocks.RequireClosed(directory,false);
        }
        Ops.SecureNewParents(directory);Ops.ProtectedParents(directory);
        Ops.SecureDirectory(directory,null,false,true);
    }
    static bool Exists(string name) {return ServiceController.GetServices().Any(s=>s.ServiceName.Equals(name,StringComparison.OrdinalIgnoreCase));}
    static void Owned(Instance i) {
        using(var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\"+i.serviceName)) {
            string expected=Ops.Quote(i.Binary("phobos-service"))+" --config "+Ops.Quote(Path.Combine(Path.GetDirectoryName(i.authFile),"instance.json"));
            if(key==null||!String.Equals(Convert.ToString(key.GetValue("ImagePath")),expected,StringComparison.OrdinalIgnoreCase)||!String.Equals(Convert.ToString(key.GetValue("ObjectName")),i.serviceAccount,StringComparison.OrdinalIgnoreCase))throw new Exception("Service ownership/path/account does not match this instance. Refusing to control another service.");
        }
    }
    static void Discovery(Instance i,string manifest) {
        using(var k=Registry.LocalMachine.CreateSubKey(@"SOFTWARE\PHOBOS\Instances\"+i.serviceName)) {
            k.SetValue("Manifest",manifest);k.SetValue("ProductVersion","1.0.1");k.SetValue("EngineVersion",i.engineVersion);k.SetValue("Host",i.bindAddress);k.SetValue("Port",i.port,RegistryValueKind.DWord);k.SetValue("LogDirectory",i.logDirectory);k.SetValue("ServiceName",i.serviceName);k.SetValue("Authentication","PHOBOS username/password; credentials never stored here");
        }
    }
    public static void Stop(Instance i) {
        if(!Exists(i.serviceName)){NoOwnedServer(i);return;}
        Owned(i);
        using(var s=new ServiceController(i.serviceName)) {
            if(s.Status==ServiceControllerStatus.Stopped){NoOwnedServer(i);return;}
            if(s.Status!=ServiceControllerStatus.StopPending)s.Stop();
            s.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromMinutes(3));
        }
        if(Native.ListenerPid(i.port)>0)throw new Exception("A listener remains after service stop; refusing replacement/removal. Inspect the process and logs.");
        NoOwnedServer(i);
    }
    static void NoOwnedServer(Instance i) {
        foreach(var process in Process.GetProcessesByName("phobos-server"))using(process) {
            string path=null;
            try {if(!process.HasExited)path=process.MainModule.FileName;}catch(InvalidOperationException){}catch(System.ComponentModel.Win32Exception){throw new Exception("Cannot verify a PHOBOS server process identity; refusing binary replacement/removal.");}
            if(String.Equals(path,i.Binary("phobos-server"),StringComparison.OrdinalIgnoreCase))throw new Exception("An installed PHOBOS server process still exists outside a running service. Inspect it and shut it down gracefully before replacement/removal.");
        }
    }
    static void Start(Instance i) {
        Owned(i);
        using(var s=new ServiceController(i.serviceName)) {
            if(s.Status!=ServiceControllerStatus.Running){
                s.Start();var deadline=DateTime.UtcNow.AddMinutes(3);
                while(true){s.Refresh();if(s.Status==ServiceControllerStatus.Running)break;if(s.Status==ServiceControllerStatus.Stopped)throw new Exception("Service stopped during startup. Inspect its SCM exit code and server log.");if(DateTime.UtcNow>=deadline)throw new Exception("Service startup timed out; no process was killed.");Thread.Sleep(200);}
            }
        }
        // Host validates ownership before reporting RUNNING; verify its child executable too.
        int pid=Native.ListenerPid(i.port);
        if(pid<=0)throw new Exception("Configured listener missing.");
        using(var p=Process.GetProcessById(pid))
            if(!String.Equals(p.MainModule.FileName,i.Binary("phobos-server"),StringComparison.OrdinalIgnoreCase))throw new Exception("Listener is not the installed PHOBOS executable.");
    }
    static void Register(Instance i,string path) {
        Ops.Sc("create "+i.serviceName+" binPath= "+Ops.Quote(Ops.Quote(i.Binary("phobos-service"))+" --config "+Ops.Quote(path))+" start= auto obj= "+Ops.Quote(i.serviceAccount)+" DisplayName= "+Ops.Quote("PHOBOS Database Server"));
        try {
        Checkpoint("service-created");
        Ops.Sc("description "+i.serviceName+" "+Ops.Quote("PHOBOS relational database server"));
        Ops.Sc("sidtype "+i.serviceName+" unrestricted");
        // No automatic restart, no restart storm. Service failures remain visible in SCM.
        Ops.Sc("failure "+i.serviceName+" reset= 0 actions= \"\"");
        Native.Preshutdown(i.serviceName);
        } catch {
            // Only compensate our newly created, still owned service. Never delete data.
            try { Stop(i);Owned(i);Ops.Sc("delete "+i.serviceName); } catch { }
            throw;
        }
    }
    public static void Configure(string manifest,Instance desired,string password) {
        Ops.RequireAdmin();Ops.SafePath(manifest);desired.Validate();Ops.SecretCheck(password);
        if(Path.GetFileName(manifest)!="instance.json")throw new Exception("Instance manifest must be named instance.json.");
        bool existing=File.Exists(manifest);
        Instance i=existing?Ops.Load(manifest):desired;
        if(existing) {
            if(i.state!="ready")throw new Exception("A prior initialization is incomplete. Data is preserved. Inspect config/logs; do not reinitialize it.");
            if(!String.Equals(i.installDirectory,desired.installDirectory,StringComparison.OrdinalIgnoreCase))throw new Exception("Repair must use the original binary directory.");
            if(!Exists(i.serviceName)) Register(i,manifest);
            Start(i);Ops.ValidateLogin(i,password);i.productVersion="1.0.1";i.engineVersion="1.0.1";Ops.UpdateVersions(manifest,i);Discovery(i,manifest);return;
        }
        if(Exists(i.serviceName))throw new Exception("The service name already exists without matching installation metadata. Refusing to replace it.");
        Ops.PortFree(i.port);
        string configRoot=Path.GetDirectoryName(manifest);
        if(!String.Equals(configRoot,Path.GetDirectoryName(i.authFile),StringComparison.OrdinalIgnoreCase))throw new Exception("Invalid configuration directory.");
        foreach(string p in new [] {configRoot,i.dataDirectory,i.logDirectory,i.controlDirectory})
            if(Directory.Exists(p)&&Directory.EnumerateFileSystemEntries(p).Any())throw new Exception("Fresh installation requires empty instance directories: "+p);
        foreach(string bin in new [] {"phobos-server","phobos-admin","phobos-cli","phobos-service"})if(!File.Exists(i.Binary(bin)))throw new Exception("Required runtime executable missing: "+bin);
        Ops.SecureDirectory(i.installDirectory,null,false,true);
        foreach(string p in new [] {configRoot,i.dataDirectory,i.logDirectory,i.controlDirectory}) {Ops.SecureNewParents(p);Ops.ProtectedParents(p);Ops.SecureDirectory(p,null,false,false);}
        // Durable intent precedes initialization. Failure never deletes user data or retries init blindly.
        Ops.Save(manifest,i);
        Checkpoint("initialization-intent");
        File.WriteAllText(i.runtimeConfig,"{\"worker_threads\":"+Math.Min(16,Math.Max(1,Environment.ProcessorCount))+",\"log_format\":\"text\"}",new UTF8Encoding(false));
        string stage=Path.Combine(i.dataDirectory,"initialization-"+i.instanceId);
        Ops.Run(i.Binary("phobos-admin"),"init "+Ops.Quote(stage),null);
        foreach(string p in Directory.GetFileSystemEntries(Path.Combine(stage,"data"))) {
            string dest=Path.Combine(i.dataDirectory,Path.GetFileName(p));
            if(Directory.Exists(p))Directory.Move(p,dest);else File.Move(p,dest);
        }
        // Preserve the tiny initialization backup/staging area for diagnosis; never recursively delete it here.
        Ops.Run(i.Binary("phobos-admin"),"user-add-stdin "+Ops.Quote(i.authFile)+" "+i.adminUser+" admin",password+"\n");
        Checkpoint("initialized");
        bool registered=false;
        try {
            Register(i,manifest);registered=true;
            Checkpoint("registered");
            string sid=@"NT SERVICE\"+i.serviceName;
            Ops.SecureDirectory(configRoot,sid,false,false);
            foreach(string p in new [] {i.dataDirectory,i.logDirectory,i.controlDirectory})Ops.SecureDirectory(p,sid,true,false);
            Checkpoint("before-start");
            Start(i);Checkpoint("started");Ops.ValidateLogin(i,password);
            i.state="ready";Ops.Save(manifest,i);
            // Discovery is installation metadata only, never engine/catalog file parsing.
            Discovery(i,manifest);
        }catch {
            if(registered){try{Stop(i);Owned(i);Ops.Sc("delete "+i.serviceName);}catch{}}
            // An initializing manifest is retained and blocks destructive automatic retries.
            throw;
        }
    }
    public static void Remove(string manifest) {
        Ops.RequireAdmin();if(!File.Exists(manifest))return;var i=Ops.Load(manifest);Stop(i);
        if(Exists(i.serviceName)){Ops.Sc("delete "+i.serviceName);for(int n=0;n<40&&Exists(i.serviceName);n++)Thread.Sleep(250);if(Exists(i.serviceName))throw new Exception("Service is still marked for deletion; close service-management handles and retry.");}
        Registry.LocalMachine.DeleteSubKeyTree(@"SOFTWARE\PHOBOS\Instances\"+i.serviceName,false);
        // Data, auth, configuration and logs always survive uninstall, including silent uninstall.
    }
    static Instance Defaults(string binRoot,string manifest) {
        string home=Path.GetDirectoryName(Path.GetDirectoryName(manifest));
        return new Instance {installDirectory=binRoot,dataDirectory=Path.Combine(home,"data"),logDirectory=Path.Combine(home,"logs"),controlDirectory=Path.Combine(home,"control"),authFile=Path.Combine(Path.GetDirectoryName(manifest),"auth.txt"),runtimeConfig=Path.Combine(Path.GetDirectoryName(manifest),"runtime.json")};
    }
    [STAThread] public static int Main(string[] args) {
        try {
            if(args.Length==1&&args[0]=="self-test")return SelfTest.Run();
            if(args.Length<2)throw new Exception("Usage: phobos-instance configure|configure-stdin|stop|start|remove|status INSTANCE_JSON [INSTALL_DIRECTORY]");
            string command=args[0],manifest=Path.GetFullPath(args[1]);
            if(command=="setup-inspect"||command=="setup-prepare") {
                try {
                    var found=Inspect(manifest,args[2]);
                    if(command=="setup-prepare")Prepare(manifest,args[2]);
                    File.WriteAllText(args[3],found==null?"FRESH":("REPAIR\r\nExisting PHOBOS installation detected. Setup will repair the current installation.\r\nDatabase data and credentials will be preserved.\r\nService: "+found.serviceName+"\r\nDatabase: "+found.dataDirectory+"\r\nEndpoint: "+found.Endpoint),new UTF8Encoding(true));
                    return 0;
                } catch(RuntimeLocks.BusyException e){File.WriteAllText(args[3],e.Message,new UTF8Encoding(true));return 20;}
                  catch(Exception e){File.WriteAllText(args[3],e.Message,new UTF8Encoding(true));return 1;}
            }
            if(command=="prepare") {Prepare(manifest,args[2]);Console.WriteLine("Prepared protected binary directory.");return 0;}
            if(command=="configure") {
                Ops.RequireAdmin();Application.EnableVisualStyles();
                var model=File.Exists(manifest)?Ops.Load(manifest):Defaults(args[2],manifest);
                if(!File.Exists(manifest)){if(args.Length>4)model.serviceName=args[4];if(args.Length>5)model.port=Int32.Parse(args[5]);model.Validate();}
                using(var form=new SetupForm(manifest,model,File.Exists(manifest))) {
                    long handle;
                    if(args.Length>3 && Int64.TryParse(args[3],out handle) && IsWindow(new IntPtr(handle))) {
                        form.StartPosition=FormStartPosition.CenterParent;
                        return form.ShowDialog(new SetupOwner(new IntPtr(handle)))==DialogResult.OK?0:2;
                    }
                    return form.ShowDialog()==DialogResult.OK?0:2;
                }
            }
            if(command=="configure-stdin") {
                // Test/automation input is an anonymous pipe, not argv/env/a password file.
                string config=Console.ReadLine();string password=Console.ReadLine();
                try {Configure(manifest,Ops.Json.Deserialize<Instance>(config),password);}finally{password=null;}
            } else if(command=="stop") {Ops.RequireAdmin();if(File.Exists(manifest))Stop(Ops.Load(manifest));}
            else if(command=="start") {Ops.RequireAdmin();Start(Ops.Load(manifest));}
            else if(command=="remove")Remove(manifest);
            else if(command=="status") {var i=Ops.Load(manifest);Console.WriteLine(Ops.Json.Serialize(i));Console.WriteLine(Exists(i.serviceName)?new ServiceController(i.serviceName).Status.ToString():"Not installed");}
            else throw new Exception("Unknown command.");
            Console.WriteLine("PHOBOS Community Edition 1.0.1: "+command+" completed.");return 0;
        }catch(Exception e){Console.Error.WriteLine("PHOBOS setup: "+e.Message);if(args.Length>0&&args[0]=="configure")MessageBox.Show(e.Message,"PHOBOS setup failed",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}
    }
}

internal sealed class SetupForm : Form {
    readonly Instance instance;readonly string manifest;readonly bool repair;
    bool busy;
    TextBox data,port,user,password,confirmation;Label status;Button install;
    TextBox Field(string label,string value,int y,bool secret,bool enabled) {
        Controls.Add(new Label{Text=label,Left=18,Top=y+4,Width=180});
        var t=new TextBox{Text=value,Left=205,Top=y,Width=370,UseSystemPasswordChar=secret,Enabled=enabled};Controls.Add(t);return t;
    }
    public SetupForm(string path,Instance model,bool existing) {
        manifest=path;instance=model;repair=existing;
        Text="PHOBOS Community Edition 1.0.1 — "+(repair?"Repair instance":"Configure primary instance");ClientSize=new Size(610,460);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;ShowInTaskbar=true;StartPosition=FormStartPosition.CenterScreen;
        Controls.Add(new Label{Text="One database per instance. Windows Service: "+model.serviceName+"\nLocal connections only (127.0.0.1). No firewall exception is needed.",Left=18,Top=15,Width=565,Height=45});
        data=Field("Data directory",model.dataDirectory,75,false,!repair);
        port=Field("TCP port",model.port.ToString(),115,false,!repair);
        user=Field("Administrator username",model.adminUser,155,false,!repair);
        password=Field(repair?"Existing admin password":"Administrator password","",195,true,true);
        confirmation=Field("Confirm password","",235,true,!repair);
        Controls.Add(new Label{Text="Service starts automatically as LocalService with an isolated service SID.\nNo default password. Passwords travel through memory/stdin only.\nRemote access and firewall provisioning are deferred in this foundation.\nUninstall keeps data, authentication, configuration and logs.",Left=18,Top=278,Width=565,Height=75});
        status=new Label{Left=18,Top=360,Width=570,Height=45};Controls.Add(status);
        install=new Button{Text=repair?"Start and verify":"Initialize and start",Left=365,Top=415,Width=150};Controls.Add(install);
        var cancel=new Button{Text="Cancel",Left=520,Top=415,Width=75,DialogResult=DialogResult.Cancel};Controls.Add(cancel);CancelButton=cancel;
        Shown+=(s,e)=>{Activate();};
        FormClosing+=(s,e)=>{if(busy)e.Cancel=true;};
        install.Click+=(s,e)=> {
            try {
                if(!repair&&password.Text!=confirmation.Text)throw new Exception("Passwords do not match.");
                instance.dataDirectory=data.Text.Trim();int number;if(!Int32.TryParse(port.Text,out number))throw new Exception("Port must be an integer.");instance.port=number;instance.adminUser=user.Text.Trim();
                Ops.SecretCheck(password.Text);instance.Validate();
                string secret=password.Text;password.Clear();confirmation.Clear();busy=true;
                foreach(Control control in Controls)if(control is TextBox||control is Button)control.Enabled=false;
                status.Text="Initializing / starting and verifying. This can take up to three minutes.";
                var worker=new System.ComponentModel.BackgroundWorker();
                worker.DoWork+=(sender,ev)=>{try{InstanceManager.Configure(manifest,instance,secret);}catch(Exception failure){ev.Result=failure.Message;}finally{secret=null;}};
                worker.RunWorkerCompleted+=(sender,ev)=> {
                    busy=false;
                    if(ev.Error!=null||ev.Result!=null) {
                        status.Text="Setup did not complete. Data is preserved.";
                        MessageBox.Show(ev.Error!=null?"Unexpected setup failure; inspect logs.":(string)ev.Result,"PHOBOS setup",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        install.Enabled=true;cancel.Enabled=true;password.Enabled=true;confirmation.Enabled=!repair;data.Enabled=!repair;port.Enabled=!repair;user.Enabled=!repair;
                    }else {
                        MessageBox.Show("PHOBOS Community Edition 1.0.1 "+(repair?"repaired":"installed")+" successfully.\n\nService: "+instance.serviceName+"\nStatus: Running\nServer: "+instance.Endpoint+"\nAdministrator: "+instance.adminUser+"\nData: "+instance.dataDirectory+"\n\n"+(repair?"Existing database and credentials were preserved.":"PHOBOS is ready for connections."),"PHOBOS",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        DialogResult=DialogResult.OK;Close();
                    }
                    worker.Dispose();
                };
                worker.RunWorkerAsync();
            }catch(Exception ex){password.Clear();confirmation.Clear();status.Text="Setup did not complete. Data is preserved.";MessageBox.Show(ex.Message,"PHOBOS setup",MessageBoxButtons.OK,MessageBoxIcon.Error);install.Enabled=true;cancel.Enabled=true;}
        };
    }
}

internal static class SelfTest {
    static void Reject(Action a) {try{a();}catch{return;}throw new Exception("Expected rejection.");}
    public static int Run() {
        Ops.SecretCheck("strong-test-password");Reject(()=>Ops.SecretCheck("short"));Reject(()=>Ops.SecretCheck("long-password\nline"));
        Reject(()=>Ops.SafePath(@"C:\"));Reject(()=>Ops.SafePath(@"\\server\share\data"));Reject(()=>Ops.SafePath(@"C:\data\..\Windows"));
        Reject(()=>Ops.SafePath(@"C:\PROGRA~1\data"));Reject(()=>Ops.SafePath(@"C:\data.\config"));Reject(()=>Ops.SafePath(@"C:\data\auth:stream"));
        var i=new Instance {installDirectory=@"C:\PHOBOSTest\binroot",dataDirectory=@"C:\PHOBOSTest\data",logDirectory=@"C:\PHOBOSTest\logs",controlDirectory=@"C:\PHOBOSTest\control",authFile=@"C:\PHOBOSTest\config\auth.txt",runtimeConfig=@"C:\PHOBOSTest\config\runtime.json"};
        i.Validate();i.port=0;Reject(()=>i.Validate());i.port=65536;Reject(()=>i.Validate());i.port=54321;i.bindAddress="0.0.0.0";Reject(()=>i.Validate());i.bindAddress="127.0.0.1";
        i.dataDirectory=i.installDirectory;Reject(()=>i.Validate());i.dataDirectory=@"C:\PHOBOSTest\binroot\data";Reject(()=>i.Validate());
        Console.WriteLine("PASS configuration/secret/path boundary tests");return 0;
    }
}

// Restart Manager only enumerates lockers. It never shuts down or kills an application.
internal static class RuntimeLocks {
    internal sealed class BusyException : Exception {public BusyException(string message):base(message){}}
    [StructLayout(LayoutKind.Sequential)] struct UniqueProcess {public int pid;public System.Runtime.InteropServices.ComTypes.FILETIME started;}
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct ProcessInfo {
        public UniqueProcess process;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=256)]public string app;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=64)]public string service;
        public uint type,status,session;
        [MarshalAs(UnmanagedType.Bool)]public bool restartable;
    }
    [DllImport("rstrtmgr.dll",CharSet=CharSet.Unicode)]static extern int RmStartSession(out uint session,int flags,StringBuilder key);
    [DllImport("rstrtmgr.dll",CharSet=CharSet.Unicode)]static extern int RmRegisterResources(uint session,uint count,string[] files,uint apps,IntPtr processes,uint services,string[] names);
    [DllImport("rstrtmgr.dll")]static extern int RmGetList(uint session,out uint needed,ref uint count,[In,Out]ProcessInfo[] processes,ref uint reasons);
    [DllImport("rstrtmgr.dll")]static extern int RmEndSession(uint session);
    public static void RequireClosed(string directory,bool allowOwnedService) {
        if(!Directory.Exists(directory))return;
        string[] files=Directory.GetFiles(directory,"*",SearchOption.AllDirectories);
        foreach(string file in files)Ops.SafePath(file);
        if(files.Length==0)return;
        uint session;int error=RmStartSession(out session,0,new StringBuilder(33));
        if(error!=0)throw new Exception("Cannot inspect running PHOBOS applications (Restart Manager "+error+"). No files were replaced.");
        try {
            error=RmRegisterResources(session,(uint)files.Length,files,0,IntPtr.Zero,0,null);
            if(error!=0)throw new Exception("Cannot register PHOBOS files for lock checking ("+error+").");
            for(int attempt=0;attempt<5;attempt++) {
                uint needed,count=0,reasons=0;error=RmGetList(session,out needed,ref count,null,ref reasons);
                if(error==0&&needed==0)return;
                if(error!=234)throw new Exception("Cannot inspect PHOBOS file locks ("+error+").");
                var items=new ProcessInfo[needed];count=needed;error=RmGetList(session,out needed,ref count,items,ref reasons);
                if(error==234)continue;
                if(error!=0)throw new Exception("Cannot inspect PHOBOS lockers ("+error+").");
                var names=new System.Collections.Generic.List<string>();
                for(int n=0;n<count;n++) {
                    try {using(var p=Process.GetProcessById(items[n].process.pid)) {
                        if(p.HasExited)continue;
                        string path=p.MainModule.FileName;
                        if(allowOwnedService&&(String.Equals(path,Path.Combine(directory,"bin","phobos-server.exe"),StringComparison.OrdinalIgnoreCase)||String.Equals(path,Path.Combine(directory,"bin","phobos-service.exe"),StringComparison.OrdinalIgnoreCase)))continue;
                        names.Add((String.Equals(Path.GetFileName(path),"PHOBOS-Studio.exe",StringComparison.OrdinalIgnoreCase)?"PHOBOS Management Studio":items[n].app)+" (PID "+p.Id+")");
                    }}catch(ArgumentException){}catch(InvalidOperationException){}
                }
                if(names.Count>0)throw new BusyException("PHOBOS applications are currently running.\r\n\r\n"+String.Join("\r\n",names)+"\r\n\r\nPlease close PHOBOS Management Studio and the listed applications to continue the repair. Save unsaved SQL first. Choose Retry after closing them, or Cancel. No application will be force-closed.");
                return;
            }
            throw new Exception("Running applications changed during inspection. Retry repair; no files were replaced.");
        }finally{RmEndSession(session);}
    }
}
