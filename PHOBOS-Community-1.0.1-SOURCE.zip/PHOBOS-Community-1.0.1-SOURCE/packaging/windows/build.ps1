param(
  [Parameter(Mandatory=$true)][string]$EngineBinaries,
  [Parameter(Mandatory=$true)][string]$Iscc,
  [Parameter(Mandatory=$true)][string]$VcRedist,
  [Parameter(Mandatory=$true)][string]$OutputDirectory,
  [Parameter(Mandatory=$true)][string]$StudioRuntime,
  [Parameter(Mandatory=$true)][string]$StageDirectory
)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $StageDirectory){if(Get-ChildItem -LiteralPath $StageDirectory -Force | Select-Object -First 1){throw 'Use an empty staging directory.'}}
$source = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
New-Item -ItemType Directory -Force (Join-Path $StageDirectory 'bin'),(Join-Path $StageDirectory 'docs'),$OutputDirectory | Out-Null
if((Get-AuthenticodeSignature -LiteralPath $VcRedist).Status -ne 'Valid'){throw 'The Microsoft runtime prerequisite signature must be valid'}
if((Get-AuthenticodeSignature -LiteralPath $VcRedist).SignerCertificate.Subject -notmatch 'O=Microsoft Corporation'){throw 'The runtime prerequisite must be published by Microsoft'}
New-Item -ItemType Directory -Force (Join-Path $StageDirectory 'prerequisites') | Out-Null
Copy-Item -LiteralPath $VcRedist -Destination (Join-Path $StageDirectory 'prerequisites\vc_redist.x64.exe') -Force
$bin=Join-Path $StageDirectory 'bin'
foreach($name in @('phobos-server','phobos-cli','phobos-admin')) { Copy-Item -LiteralPath (Join-Path $EngineBinaries ($name+'.exe')) -Destination $bin }
# Verify the unified public version and record the exact bytes that are packaged.
$engineHashes=@{}
foreach($name in @('phobos-server','phobos-cli','phobos-admin')) {
 $exe=Join-Path $bin ($name+'.exe')
 $version=& $exe --version
 if($LASTEXITCODE -ne 0 -or $version -notmatch '1\.0\.1 Community Edition'){throw "Unexpected component version: $name $version"}
 $engineHashes[$name]=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
}
if(-not (Test-Path -LiteralPath (Join-Path $StudioRuntime 'PHOBOS-Studio.exe'))){throw 'Published Studio runtime is required for unified Setup.'}
Copy-Item -LiteralPath $StudioRuntime -Destination (Join-Path $StageDirectory 'studio') -Recurse
$studioDocs=Join-Path $StageDirectory 'studio\docs'
New-Item -ItemType Directory -Force $studioDocs | Out-Null
Get-ChildItem -LiteralPath $source -Filter 'PHOBOS-1.0*.md' | Where-Object { $_.Name -notmatch '(TEST-RESULTS|RELEASE-REPORT|HOTFIX-REPORT|INSTALLER-REPAIR-VALIDATION|STUDIO-ERROR-RESILIENCE)' -and $_.Name -ne 'PHOBOS-1.0-RELEASE-NOTES.md' } | Copy-Item -Destination $studioDocs
Copy-Item -LiteralPath (Join-Path $source 'LICENSE'),(Join-Path $source 'packaging\studio\QuickStart.html') -Destination $studioDocs -Force
Copy-Item -LiteralPath (Join-Path $source 'packaging\studio\licenses') -Destination $studioDocs -Recurse -Force

$studioHashes=@{}
foreach($name in @('PHOBOS-Studio.exe','PHOBOS-Studio.dll','Phobos.Studio.Core.dll')){$studioHashes[$name]=(Get-FileHash -LiteralPath (Join-Path $StageDirectory ('studio\'+$name)) -Algorithm SHA256).Hash.ToLowerInvariant()}
@{product='PHOBOS Community Edition';version='1.0.1';management_api_version=1;protocol_version=1;catalog_version=5;identity=$true;insert_returning=$true;foreign_keys='restrict/no action';source_baseline_sha256='b383a259539212468fd76cecde06c764d4bcaa1917d7561d408f9789c4c46f7d';engine_sha256=$engineHashes;studio_sha256=$studioHashes;signing='unsigned'} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $StageDirectory 'docs\BUILD.json') -Encoding UTF8
$common=Join-Path $PSScriptRoot 'Common.cs'
& $csc /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /r:System.Web.Extensions.dll /r:System.Core.dll /r:System.dll "/out:$bin\phobos-service.exe" $common (Join-Path $PSScriptRoot 'ServiceHost.cs')
if($LASTEXITCODE -ne 0){throw 'Service host compilation failed'}
& $csc /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /r:System.Web.Extensions.dll /r:System.Core.dll /r:System.dll /r:System.ServiceProcess.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "/out:$bin\phobos-instance.exe" $common (Join-Path $PSScriptRoot 'InstanceManager.cs')
if($LASTEXITCODE -ne 0){throw 'Instance manager compilation failed'}
foreach($name in @('phobos-service','phobos-instance')) { '<configuration><startup><supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8" /></startup><runtime><loadFromRemoteSources enabled="false" /></runtime></configuration>' | Set-Content -LiteralPath (Join-Path $bin ($name+'.exe.config')) -Encoding UTF8 }
Get-ChildItem -LiteralPath $source -Filter 'PHOBOS-1.0*.md' | Where-Object { $_.Name -notmatch '(TEST-RESULTS|RELEASE-REPORT|HOTFIX-REPORT|INSTALLER-REPAIR-VALIDATION|STUDIO-ERROR-RESILIENCE)' -and $_.Name -ne 'PHOBOS-1.0-RELEASE-NOTES.md' } | Copy-Item -Destination (Join-Path $StageDirectory 'docs')
Copy-Item -LiteralPath (Join-Path $source 'LICENSE') -Destination (Join-Path $StageDirectory 'docs\LICENSE.txt')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'QuickStart.html') -Destination (Join-Path $StageDirectory 'docs\QuickStart.html')
@'
PHOBOS Community Edition 1.0.1
One cross-platform engine, with a Windows distribution layer.
Windows x64 and .NET Framework 4.8 are required. No Rust/Cargo or PowerShell is needed for interactive installation.
The signed Microsoft Visual C++ x64 prerequisite is included and installed if missing/outdated. It is shared with other applications and is not removed on PHOBOS uninstall.
The installer is unsigned. Verify its published SHA-256 before running it.
Installation is administrator-only. Localhost connections only; no firewall exception is created.
While Setup waits, an owned, visible native dialog asks for data path, port and administrator credentials.
Uninstall ALWAYS KEEPS database data, auth, configuration, logs and backups.
Patch repair accepts compatible 1.0.0 or 1.0.1 instance metadata without catalog migration. Pre-1.0 databases require the explicit backup-first copy upgrade; never initialize over existing data.
PATH is not modified. Start Menu provides documentation and a command prompt in the bin directory.
'@ | Set-Content -LiteralPath (Join-Path $StageDirectory 'docs\INSTALLER-NOTICE.txt') -Encoding UTF8
& (Join-Path $bin 'phobos-instance.exe') self-test
if($LASTEXITCODE -ne 0){throw 'Packaging self-tests failed'}
# Signing hook: sign staged EXEs here before ISCC; sign the resulting installer afterward.
# No signing is claimed or attempted without a real configured certificate.
& $Iscc "/DRuntimeDir=$StageDirectory" "/DOutputDir=$OutputDirectory" (Join-Path $PSScriptRoot 'phobos.iss')
if($LASTEXITCODE -ne 0){throw 'Inno Setup compilation failed'}
Compress-Archive -Path (Join-Path $StageDirectory '*') -DestinationPath (Join-Path $OutputDirectory 'PHOBOS-Community-1.0.1-Windows-x64-Runtime.zip') -Force
