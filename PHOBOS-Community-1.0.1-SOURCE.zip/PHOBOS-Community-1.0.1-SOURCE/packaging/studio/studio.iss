#ifndef RuntimeDir
 #error RuntimeDir is required
#endif
#ifndef OutputDir
 #error OutputDir is required
#endif
[Setup]
AppId={{2AE91E24-2E50-4B10-81C6-2D38741A1000}
AppName=PHOBOS Management Studio
AppVersion=1.0.0
AppVerName=PHOBOS Management Studio 1.0.0
DefaultDirName={localappdata}\Programs\PHOBOS Studio 1.0.0
DefaultGroupName=PHOBOS Management Studio 1.0.0
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir={#OutputDir}
OutputBaseFilename=PHOBOS-Management-Studio-1.0.0-Windows-x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\PHOBOS-Studio.exe
CloseApplications=yes
RestartApplications=no
#ifdef SignEnabled
SignTool=phobos
SignedUninstaller=yes
#endif
[Files]
Source: "{#RuntimeDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\PHOBOS Management Studio"; Filename: "{app}\PHOBOS-Studio.exe"
Name: "{group}\Studio User Guide"; Filename: "{app}\docs\QuickStart.html"
Name: "{group}\Uninstall PHOBOS Studio"; Filename: "{uninstallexe}"
[Run]
Filename: "{app}\PHOBOS-Studio.exe"; Description: "Launch PHOBOS Management Studio"; Flags: nowait postinstall skipifsilent
; Never delete profiles, SQL files, database files or server installations.
