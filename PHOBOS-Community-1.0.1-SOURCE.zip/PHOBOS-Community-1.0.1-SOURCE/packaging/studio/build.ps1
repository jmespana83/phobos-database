param(
 [Parameter(Mandatory=$true)][string]$Dotnet,
 [Parameter(Mandatory=$true)][string]$Iscc,
 [Parameter(Mandatory=$true)][string]$StageDirectory,
 [Parameter(Mandatory=$true)][string]$OutputDirectory,
 [string]$SignToolPath,
 [string]$CertificateThumbprint,
 [string]$TimestampUrl
)
$ErrorActionPreference='Stop'
$source=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$project=Join-Path $source 'studio\Phobos.Studio\Phobos.Studio.csproj'
$signing= -not [string]::IsNullOrWhiteSpace($SignToolPath)
if($signing){
 if(-not (Test-Path -LiteralPath $SignToolPath -PathType Leaf)){throw 'Signing tool not found.'}
 if($CertificateThumbprint -notmatch '^[0-9A-Fa-f]{40}$'){throw 'Supply a SHA-1 certificate thumbprint from the current user certificate store.'}
 if($TimestampUrl.Contains('$') -or $TimestampUrl.Contains('"')){throw 'Unsupported timestamp URL characters.'}
 $timestamp=[Uri]$TimestampUrl
 if(-not $timestamp.IsAbsoluteUri -or $timestamp.Scheme -ne 'https'){throw 'Supply an HTTPS RFC3161 timestamp endpoint.'}
 if($SignToolPath.Contains('"') -or $SignToolPath.Contains('$')){throw 'Unsupported signing tool path characters.'}
}elseif($CertificateThumbprint -or $TimestampUrl){throw 'Signing parameters require SignToolPath; never silently produce unsigned artifacts when signing was requested.'}
if(Test-Path -LiteralPath $StageDirectory){if(Get-ChildItem -LiteralPath $StageDirectory -Force | Select-Object -First 1){throw 'Use a fresh empty staging directory to avoid stale release files.'}}
New-Item -ItemType Directory -Force $StageDirectory,$OutputDirectory | Out-Null
& $Dotnet publish $project -c Release -r win-x64 --self-contained true -p:RestoreLockedMode=true -p:NuGetLockFilePath=packages.win-x64.lock.json -p:StudioValidation=false -p:UseSharedCompilation=false -p:DebugType=None -p:DebugSymbols=false -p:PublishReadyToRun=false -o $StageDirectory
if($LASTEXITCODE -ne 0){throw 'Studio publish failed'}
$docs=Join-Path $StageDirectory 'docs'
New-Item -ItemType Directory -Force $docs | Out-Null
Get-ChildItem -LiteralPath $source -Filter 'PHOBOS-1.0-*.md' | Copy-Item -Destination $docs
Copy-Item -LiteralPath (Join-Path $source 'LICENSE'),(Join-Path $PSScriptRoot 'QuickStart.html') -Destination $docs
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'licenses') -Destination $docs -Recurse -Force
if($signing){
 foreach($name in @('PHOBOS-Studio.exe','PHOBOS-Studio.dll','Phobos.Studio.Core.dll')){
  $file=Join-Path $StageDirectory $name
  & $SignToolPath sign /sha1 $CertificateThumbprint /fd SHA256 /tr $timestamp.AbsoluteUri /td SHA256 $file
  if($LASTEXITCODE -ne 0){throw "Signing failed: $name"}
  & $SignToolPath verify /pa $file
  if($LASTEXITCODE -ne 0){throw "Signature verification failed: $name"}
 }
 $signCommand='$q'+[IO.Path]::GetFullPath($SignToolPath)+'$q sign /sha1 '+$CertificateThumbprint+' /fd SHA256 /tr $q'+$timestamp.AbsoluteUri+'$q /td SHA256 $f'
 & $Iscc "/DRuntimeDir=$StageDirectory" "/DOutputDir=$OutputDirectory" '/DSignEnabled=1' "/Sphobos=$signCommand" (Join-Path $PSScriptRoot 'studio.iss')
}else{& $Iscc "/DRuntimeDir=$StageDirectory" "/DOutputDir=$OutputDirectory" (Join-Path $PSScriptRoot 'studio.iss')}
if($LASTEXITCODE -ne 0){throw 'Studio installer build failed'}
$installer=Join-Path $OutputDirectory 'PHOBOS-Management-Studio-1.0.0-Windows-x64.exe'
if($signing){& $SignToolPath verify /pa $installer;if($LASTEXITCODE -ne 0){throw 'Installer signature verification failed'}}
Compress-Archive -Path (Join-Path $StageDirectory '*') -DestinationPath (Join-Path $OutputDirectory 'PHOBOS-Management-Studio-1.0.0-Windows-Runtime.zip') -Force
'Build complete. Generate final SHA-256 hashes only after signing and packaging.'
