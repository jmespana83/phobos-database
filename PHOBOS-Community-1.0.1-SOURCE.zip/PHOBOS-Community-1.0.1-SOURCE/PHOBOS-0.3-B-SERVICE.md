# PHOBOS 0.3-B Windows service

Default name: `PHOBOSDatabase`. Display name: **PHOBOS Database Server**. Description: **PHOBOS relational database server**. Startup: Automatic. Account: `NT AUTHORITY\LocalService` with a per-service SID. Recovery policy: **no automatic restart**; inspect the failure and restart explicitly.

The SCM image path is quoted, for example:

```text
"C:\Program Files\PHOBOS\bin\phobos-service.exe" --config "C:\ProgramData\PHOBOS\config\instance.json"
```

The host starts the unchanged `phobos-server.exe` directly. TCP traffic goes to the engine, never through the host. Working directory is the protected binary directory; all data/auth/control/config paths are explicit. PHOBOS and CLR instrumentation environment overrides are removed from child startup. Normal engine performance is not intentionally changed.

Startup is START_PENDING while the engine opens/replays its instance. The host verifies that the configured listening TCP port belongs to its exact child PID and performs a normal PHOBOS handshake before reporting RUNNING. The installer then verifies the child's executable path, authenticates the configured administrator, and issues `SHOW CATALOG CAPABILITIES` and `SHOW CATALOG TABLES`. There is no disabled-auth startup window: a missing auth file prevents launch.

STOP, SHUTDOWN and PRESHUTDOWN request the existing shutdown marker. The host reports STOP_PENDING/checkpoints while waiting for the server to exit after its durability drain. Stale markers are removed before launch. No `taskkill` or forced termination is used for normal lifecycle. SCM preshutdown allowance is 180 seconds; this is an OS allowance, not proof that every workload can drain before physical power loss or an OS deadline. The instance helper waits up to three minutes for SCM operations and fails safely without killing a still-draining server.

A Windows Job object provides kill-on-host-crash containment. If the host crashes externally, the child is terminated as a crash so it cannot silently keep serving as an orphan; subsequent startup uses normal WAL recovery. This path is distinct from graceful stop and is tested by deliberate failure injection. There is a small managed-process-launch to job-assignment window; if failure occurs there, an administrator may need to inspect a surviving process. Occupied-port startup always fails without killing its owner.

Logs: one `server-<UTC timestamp>.log` per start in the configured log directory. stdout/stderr include engine startup, WAL mode, recovery messages and shutdown completion; host messages include readiness PID and lifecycle transitions. Log files are administrator/service readable; ordinary users do not receive filesystem access. No automatic retention/rotation during a single long-running process is implemented. Back up/rotate old closed logs according to operational policy. Service failure reports nonzero SCM exit status; configuration failures before logging is available can surface as a generic SCM start failure, so run `phobos-instance status` and inspect protected configuration.

Before repair/removal, the helper compares the SCM ImagePath and account with the protected instance manifest. It refuses to control a mismatched service. Uninstall blocks on failed service stop/removal and always retains mutable state. If initialization failed halfway through registration, inspect the preserved `initializing` manifest and SCM entry; do not assume rollback erased the instance.

Native lifecycle commands from an elevated Command Prompt:

```text
sc.exe query PHOBOSDatabase
sc.exe start PHOBOSDatabase
sc.exe stop PHOBOSDatabase
```

Restart means wait for STOPPED, then START. Do not start a second direct server on the same data directory while the service is active. Offline integrity, backup, restore, migration and PITR retain the existing engine rules. The installer never creates a second database namespace.

For future 0.3-C, discover the connection from `HKLM\SOFTWARE\PHOBOS\Instances`, inspect service state through SCM, and request elevation only for service/configuration administration. Database operations use ordinary PHOBOS authentication/protocol and catalog API 1. Linux systemd and macOS launchd adapters should call the same engine interfaces and implement their own identities, paths and stop signaling; they do not depend on this Windows host.
