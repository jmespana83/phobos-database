# PHOBOS 0.3-B installation

## Install and connect

1. Verify `PHOBOS-Community-0.3-B-Windows-Installer.exe` against the supplied SHA-256 manifest. This build is unsigned; Windows may show an unknown-publisher/SmartScreen warning. Do not mistake that for a signed release.
2. Run the installer and approve administrator elevation. Use Windows x64 with .NET Framework 4.8. A signed Microsoft Visual C++ prerequisite is included for machines that need it; a prerequisite reboot may require rerunning Setup.
3. Select a binary directory (default `C:\Program Files\PHOBOS`). Custom directories must be administrator-controlled and local. User-profile/Downloads folders, network paths and junction/symlink paths are rejected for service safety.
4. After files are installed, the native instance dialog asks for the data directory (default `C:\ProgramData\PHOBOS\data`), TCP port (default 54321), initial administrator name (default `admin`) and password/confirmation. Use 12–256 characters without line breaks. There is no default password.
5. PHOBOS initializes one primary instance, creates an automatic LocalService service, verifies listener ownership, handshakes, authenticates, and queries Management API v1. The success dialog shows endpoint, administrator name and data path, never the password.

This foundation binds to **127.0.0.1 only**. Remote interface selection and Windows Firewall provisioning are deferred; no firewall exception is created or needed. Service installation is the normal path; optional files-only mode is described below. The installer never silently picks another port or stops another application's listener.

Use the PHOBOS Command Prompt Start Menu shortcut, then:

```text
phobos-cli.exe shell --addr 127.0.0.1:54321 --user admin
```

Enter the password at the masked prompt, then:

```sql
SHOW CATALOG CAPABILITIES;
SHOW CATALOG TABLES;
```

Use `\q` to disconnect. The existing Windows CLI uses built-in PowerShell for its masked interactive password prompt; installer setup itself does not require PowerShell. The CLI, admin and server tools are installed in `bin`; PATH is not modified. There is no Management Studio shortcut yet.

## Manage the instance

Use Windows Services (`services.msc`) to start, stop or restart **PHOBOS Database Server** (`PHOBOSDatabase`). Stop is graceful. In an administrator Command Prompt:

```text
sc.exe stop PHOBOSDatabase
sc.exe start PHOBOSDatabase
"C:\Program Files\PHOBOS\bin\phobos-instance.exe" status "C:\ProgramData\PHOBOS\config\instance.json"
```

Configuration and auth reside in `C:\ProgramData\PHOBOS\config`; logs in `C:\ProgramData\PHOBOS\logs`; the chosen database directory is recorded in `instance.json`. Logs/config/auth are protected from ordinary users. Do not change the data directory by editing metadata: moving a live instance is not a supported wizard operation. For supported engine worker/resource settings, stop the service, edit **runtime.json** as administrator using the inherited engine schema, then restart. Keep durable WAL mode and loopback policy intact. Port changes are an administrator stop/edit/start operation on `instance.json`; update discovery registry Port consistently. A reconfiguration GUI and atomic reconfiguration command are future work.

Offline administration requires the service stopped:

```text
phobos-admin.exe check "C:\ProgramData\PHOBOS\data"
phobos-admin.exe backup "C:\ProgramData\PHOBOS\data" "D:\PHOBOS-Backups\backup-001"
```

Restore uses the existing `phobos-admin restore BACKUP DESTINATION` interface and a safe offline recovery plan; do not restore over a running database. See inherited administration documentation for restore/PITR/replication details. The installer does not change those interfaces.

## Repair, failure and uninstall

Rerun the same 0.3-B installer using the same binary directory and existing manifest. It stops the service before replacing binaries. The setup dialog asks for the **existing** administrator password; it does not reset credentials or recreate data. Same-version repair is the supported scope. Arbitrary upgrades/downgrades are not supported or claimed.

If initialization fails, data and the `initializing` manifest remain. Do not delete them or repeatedly initialize over them. Inspect startup logs and configuration and recover the instance deliberately. A repair failure after binary replacement leaves the new binaries installed and data retained; it is not a tested cross-version rollback system. If setup is cancelled after file copy, tools remain available for diagnosis; the database is not reported ready.

Uninstall through Windows Installed Apps or the Start Menu shortcut. The uninstaller stops/removes its owned service, removes installed binaries and shortcuts, and **always keeps data, auth, configuration, logs and backups**. It aborts if service stop/removal fails. There is deliberately no one-click destructive data-deletion option in this foundation. Decommission retained directories only as a separate explicit administrator action after checking backups and exact paths. The shared Microsoft runtime is not uninstalled.

## Advanced files-only and automated setup

`/FILESONLY=1` installs runtime files but does not initialize/start/verify an instance. It is required for silent setup. `/INSTANCECONFIG="absolute\config\instance.json"` selects a manifest for isolated deployments/tests; normal users use the default. `phobos-instance configure MANIFEST INSTALL_DIRECTORY` opens the native setup dialog after files-only installation.

For trusted automation, `phobos-instance configure-stdin MANIFEST` accepts exactly two stdin lines: the non-secret instance JSON and the password. Use an anonymous pipe as in the validation runner. Never put the second line in a response file, shell history, argv, environment variable or a transcript. The bundled `tools/installer-validation` creates a random test credential in memory and does not persist it.

## Reproduce the package

Build machine: Windows x64, .NET Framework 4.8 C# compiler, Rust/MSVC toolchain if building the engine, Inno Setup **6.7.3**, and the official signed Microsoft Visual C++ x64 redistributable. Preserve the recorded tool versions/hashes for reproducibility; this is a repeatable build workflow, not a claim of byte-deterministic installer output.

From the source root, to build the unchanged engine (offline assumes cached dependencies):

```powershell
$env:AWS_LC_SYS_PREBUILT_NASM = '1'
$env:CARGO_TARGET_DIR = 'C:\PHOBOS-build\target'
cargo +stable build --release --offline
```

The delivered engine binaries were built with Rust **1.98.1** as recorded in the 0.3-A manifest. Pin that toolchain rather than assuming a future `stable` is identical. Engine source still pins/supports Rust 1.85.0; no toolchain policy was changed.

Exact packaging command used in this workspace:

```powershell
.\packaging\windows\build.ps1 `
  -EngineBinaries 'C:\Users\195doctor\Documents\Codex\2026-10-23\stable-target\release' `
  -Iscc 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\inno\ISCC.exe' `
  -VcRedist 'C:\Users\195doctor\Documents\Codex\2026-10-23\tools\installer-build\vc_redist.x64.exe' `
  -OutputDirectory 'C:\Users\195doctor\Documents\Codex\2026-10-23\outputs' `
  -StageDirectory 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b'
```

The runtime ZIP includes the prerequisite and user documentation. The source ZIP contains packaging/build/test code, not compiler installations or test databases. Future signing hooks are noted in `build.ps1`: sign the staged PHOBOS EXEs before ISCC, then sign the final installer with the project's real certificate and timestamp service. Current PHOBOS binaries/installer remain unsigned.

Run lifecycle tests **from an elevated PowerShell**, after reading their fixed isolated path safeguards:

```powershell
.\tools\installer-validation\run.ps1 `
  -RuntimeDirectory 'C:\Users\195doctor\Documents\Codex\2026-10-23\runtime-03b' `
  -Installer 'C:\Users\195doctor\Documents\Codex\2026-10-23\outputs\PHOBOS-Community-0.3-B-Windows-Installer.exe' `
  -EvidenceDirectory 'C:\Users\195doctor\Documents\Codex\2026-10-23\validation-03b'
```

Tests use `PHOBOS-03B-Validation` binary/ProgramData paths and refuse preexisting test paths. They retain test data by design. Review `PHOBOS-0.3-B-TEST-RESULTS.md` for actual coverage and omissions; source-level tests are not a substitute for a clean VM qualification run.
