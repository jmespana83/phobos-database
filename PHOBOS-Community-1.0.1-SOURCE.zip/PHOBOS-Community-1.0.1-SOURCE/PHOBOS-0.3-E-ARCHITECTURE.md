# PHOBOS 0.3-E — Enterprise SQL & Schema V2

**EXPERIMENTAL CANDIDATE — promotion held: fresh-control autocommit median +5.9%, exceeding 5% in two of three pairs. Correctness tests passed; the write-performance cause remains unresolved.**

This candidate extends the accepted 0.3-D source, whose engine is 0.3-A on K.5. It does not redesign storage, reclaim, services, or Studio. Baseline archive SHA-256: `9b8411867080d6c8335b9ad1c6c829360980bb7fd94689ad93662c4f14aa057f`.

## Implemented boundary

Durable, typed schema definitions in catalog.phc: literal column defaults, restricted row CHECKs, and a primary-key reference to the existing unique index infrastructure. New DDL uses the existing schema lease, transaction-private directory, Catalog clone, metadata WAL images, durable commit queue and atomic schema publication. Both implicit and explicit transactions use this route. Rollback discards private definitions, indexes and heap files. This is not an autocommit-only feature.

Definition maps are keyed by stable table ID; column references are ordinal. Table/column rename therefore preserves definitions without reparsing SQL. A primary key has one generated backing UNIQUE index, with all key columns NOT NULL. The backing index cannot be dropped independently. The table is new at declaration, so no equivalent pre-existing index exists. Composite keys use existing canonical key equality and conflict ownership. No new key format or locking scheme is introduced.

DEFAULT is bound/coerced once at DDL execution. INSERT column-list expansion obtains omitted values from the statement catalog; explicitly supplied NULL is left untouched. Resolved values follow the existing logical-write/redo path and are not reevaluated during commit rebasing or replay. ALTER COLUMN SET/DROP DEFAULT changes future omission behavior, not stored rows.

CHECK is a bound column comparison with a typed constant, or IS [NOT] NULL. Only FALSE violates a CHECK; NULL/UNKNOWN comparisons pass. Multiple CHECK clauses provide conjunction. There are no subqueries, functions, parameters, time-dependent expressions, cross-table references, or arbitrary executable expression strings in durable definitions. BIGINT/DOUBLE comparisons preserve the existing exact canonical comparison, without rounding the constraint literal to DOUBLE.

Enforcement covers normal MVCC INSERT/UPDATE, legacy direct DML where a compatible catalog is loaded, and dedicated bulk import. A failing SQL statement cannot partially publish rows. Existing transaction error/abort rules remain intact. Bulk imports supply complete rows: NULL is explicit, and defaults are not a substitute for omitted bulk fields. Existing UNIQUE checks remain the primary-key enforcement mechanism.

## Concurrency and recovery

DDL retains the existing global schema-lease behavior: competing catalog statements/new readers or schema writers can receive a retryable schema-transaction error. This milestone does not add online DDL. No transaction can use a partially published definition. Existing snapshot/schema-generation checks, row/key ownership, cancellation, commit ordering, WAL forcing and fencing remain in place.

Catalog version 4 is used only after new schema-definition DDL. Unused old workloads retain version 2/3 and the old physical representations. Heap, index, WAL framing and protocol formats are unchanged. Metadata rides the existing Tables FileId images through crash recovery, backup, PITR and physical standby replay. Older binaries reject version 4; downgrade requires restoring a pre-upgrade backup. See the catalog-format document.

Catalog opening validates references and types; offline integrity validates visible row CHECKs and primary-key metadata/backing structures. Online integrity checks bound definitions and retained physical rows. CHECK definitions can only be installed at CREATE TABLE in this release, so all retained versions must satisfy them. No automatic semantic repair is performed.

## Management contract

Management API remains version 1. Existing columns retain their names and positions. SHOW CATALOG COLUMNS appends has_default (Boolean) and default_expression (nullable text). SHOW CATALOG CONSTRAINTS appends definition (nullable text), reports PRIMARY KEY distinctly, and adds CHECK rows with generated stable table-ID/ordinal names. SHOW CATALOG INDEXES continues exposing the real backing index. CAPABILITIES reports server_version=0.3-E, catalog_format_max=4 and the restricted schema feature scope. IDs remain opaque strings. Cargo package and wire-handshake identifiers retain their inherited compatibility values; discover the feature release through SHOW CATALOG CAPABILITIES.

Expressions in metadata are normalized display representations, not a guaranteed executable DDL round trip; DATE/TIMESTAMP/BINARY retain the existing typed value display notation. has_default distinguishes DEFAULT NULL from no default. A future schema scripting API should explicitly version executable rendering rather than assuming display text is SQL.

The unchanged 0.3-D Studio Core tolerates appended columns and uses ordinary SQL/typed results. Its KnownDdl whitelist recognizes only 0.3-A, so editable object-template buttons remain disabled on 0.3-E. Query editing/execution and catalog browsing remain available. No Studio V3, installer or service changes are included.

## Portability and future work

New engine code uses portable Rust and existing crates only. No dependency, Windows API, physical datatype or wire-message addition is required. Windows is the actual validation platform; Linux/macOS builds are not claimed without execution evidence.

Future catalog kinds (foreign keys, sequences, views) belong in this schema-definition subsystem with an explicit new format version and bounded tagged encoding. No placeholder objects or accepted-but-ignored SQL are shipped. Identity requires durable allocator semantics; foreign keys require concurrent parent/child ownership; views require dependency tracking. These remain separate milestones.

See TEST-RESULTS, RECOVERY-VALIDATION and PERFORMANCE for actual evidence and promotion status.
