# PHOBOS 0.3-D — Management Studio V2 architecture

Built from accepted `PHOBOS-Community-0.3-C-ManagementStudio-SOURCE.zip`, SHA-256 `0219f7ab8f6891ab7d84143bd7f9eaab7c53d4e032c2842f61f697434de0b6ed`.

## Boundary

Zero engine changes. The Rust crates, Cargo inputs, accepted Windows server packaging and Windows service adapter are preserved byte-for-byte. Studio speaks the existing typed PHOBOS public protocol and Management API v1 directly. There is no CLI scraping, storage-file parsing, HTTP proxy, new SQL grammar, or new server management API.

SDK 10.0.402 / .NET 10.0.13; Avalonia 11.3.13; AvaloniaEdit 11.3.0; DataGrid 11.3.13. Studio product 0.3-D uses assembly version 0.3.4; the accepted server still reports engine 0.3-A and packaging 0.3-B.

## Ownership

`QueryPane` owns one `SqlDocument`, `StudioSession`, query state, cancellation state, stopwatch, limits, in-memory history, catalog cache, result tabs and Messages. The parent window owns only navigation, dialogs, layout and platform integration. Asynchronous execution captures its originating pane; switching tabs cannot redirect results or cancellation.

Each authenticated tab uses one SQL connection and, when supported, one cancellation connection. Eight tabs maximum means at most sixteen active connections. New Query against a profile prompts for credentials and opens a fresh session. Closing a tab disposes both sockets; server-side open transactions end with connection teardown. Transaction-open indication follows acknowledged BEGIN/COMMIT/ROLLBACK command tags. No transaction or credentials are restored across application launches.

Generated SQL and opened files create disconnected editable tabs carrying only a preferred profile. Connect explicitly before executing them. A profile is endpoint configuration, not a shared SQL session or password vault.

## Script boundaries

`SqlScripts` scans statement boundaries using the accepted lexer conventions: single-quoted strings with doubled apostrophes, double-quoted identifiers with doubled quotes, line comments and non-nested block comments. It is not a SQL parser. The server parses each resulting statement. The entire script is boundary-checked before submission, limited to 1 MiB and 32 statements. Unterminated quotes/comments, nested comments, unsupported dollar/backtick/bracket quoting, unbalanced parentheses and semicolons inside parentheses are rejected before submission.

Execution is sequential on the tab session. Each row-producing statement gets a result tab; commands append affected-row information to Messages. First failure or cancellation stops later statements. Earlier autocommits are not rolled back. An explicit transaction has normal server semantics; a poisoned connection closes it. SQL is never automatically replayed, including reconnect and service restart.

## Streaming and budgets

The strict decoder validates each complete batch before calling an awaited consumer. The worker prepares display rows, then awaits UI-thread insertion. The next batch is not decoded until that callback completes: there is no unbounded dispatcher queue. The DataGrid retains virtualization and binds an observable collection.

A result remains visibly Incomplete until a valid end frame verifies row and batch totals. Errors preserve validated prefixes as Incomplete; malformed batches are never presented. A previous completed run remains available after failure. Results belong to their originating pane.

Defaults per execution: 50,000 rows and estimated 32 MiB retained memory across all statement results; 120-second deadline per statement. Configurable bounds are 1–100,000 rows, 1–64 MiB, and 1–600 seconds. Remaining memory is rounded down to whole MiB for subsequent statements, so the script may stop conservatively. At the budget boundary, later commands as well as SELECTs are not submitted. A valid completed result remains Complete even if the next statement cannot be admitted.

Memory estimates include wire content and conservative CLR/display overhead, not exact process RSS. A previous completed run may coexist with the current run; eight maximum-size tabs can therefore retain roughly 1 GiB of result budgets plus UI/runtime overhead. This is bounded, not a process-wide hard memory quota. History is at most 20 entries/tab, each retaining at most 65,536 SQL characters, and is never persisted.

## Catalog and product layers

Table-scoped refresh uses `SHOW CATALOG ... FROM` for all four collections, avoiding mixed partial group replacement. Two consecutive matching reads are required before cache publication. A detected change in a scoped read triggers a full refresh; a changing full read reports an error and retains the previous published cache. Server errors poison the SQL session and clear the active explorer. Management API v1 has no atomic catalog revision token: this is stability detection, not a linearizable metadata snapshot. Refresh after DDL, or retry explicitly during active schema churn.

Explorer sorting/filtering and lazy child construction remain bounded to 2,000 tables. Completion is explicit keyword/catalog prefix matching, including `table.column` prefixes; it does not infer aliases, semantic scope or types. The bundled highlighting definition is lexical presentation only.

Core export, profiles and layout have no platform dependencies. Windows discovery/SCM remains behind `ILocalInstances`; Linux/macOS use `NoLocalInstances`. Ordinary SQL is unprivileged. Only constrained Windows service operations invoke elevation.

## Deferred

Custom CA/mTLS UI, credential vaults, log viewer, Linux/systemd qualification, macOS/launchd qualification, installer unification, signed release qualification, session restore, grid-width persistence, schema designer and semantic completion remain deferred. No untested Linux package is delivered.
