# PHOBOS 0.3-F recovery validation

## Engine candidate revalidation

The unchanged 0.3-E source passed a fresh pinned-Rust-1.85.0 workspace run: 608 passed, 0 failed, 4 inherited ignored tests. All eleven schema-v2 tests passed. Performance promotion remains held independently; correctness success does not imply performance acceptance.

The schema-v2 crash test actually terminates child processes at six commit/publication boundaries:

- c6_private_redo_staged
- wal.before_force
- wal.after_force
- mvcc.before_publication
- c5_schema_metadata_installed
- mvcc.after_publication

Each expected exit is checked, followed by two database reopens and integrity checks. Schema and row publication remain atomic. Pre-force recovery may retain or discard the transaction consistently; after durable force the committed schema/row must survive. Recovered PRIMARY KEY/CHECK/default metadata is checked and enforcement retried. This is process-crash coverage, not physical power-loss/storage-device certification.

The schema-v2 administration integration test passed online/offline backup, restore, archived-WAL PITR, standby initialization/receive/replay (including repeated replay), constraint/default preservation and integrity. The full workspace also reran inherited WAL/rotation, MVCC/transaction, UNIQUE/index, reclaim/lifecycle, checkpoint, backup and replication tests. Four inherited optional soak/benchmark tests are listed in TEST-RESULTS.md, not silently counted as executed.

## Actual release binary smoke

The unchanged E release server ran against a fresh isolated fixture. DEFAULT/CHECK/PK, transactional rename and catalog metadata were checked; expected CHECK/UNIQUE failures were rejected. The harness forcibly terminated only its own child after acknowledged commits, reopened it, compared rows and metadata, and retried enforcement. Offline integrity passed, seven-file backup/restore passed, restored integrity passed, and restored rows/catalog matched.

The Studio D Core compatibility harness separately tests cancellation, explicit reconnect, abrupt fixture-server termination/WAL recovery and final offline integrity. See its fresh result in TEST-RESULTS.md. Neither harness touched the user's primary database.

## Accepted installed engine

The actual default-path accepted-A installation was initialized through visible Setup, used through Studio, stopped gracefully, checked offline, restarted and reconnected. The row and unique index survived. Interactive repair preserved the same instance/auth and data. Server uninstall retained database files and Studio.

The user's original database was restored from a protected verified backup, all original files checked before startup, and offline integrity reported one table, one index and three live index entries. It is running with the original credentials and accepted A binary. Backup and acceptance fixture copies are retained. Restoration did not reinitialize or rewrite authentication.

## Installer failure boundaries

Six deterministic managed exceptions cover initialization intent, post-initialization, service creation, registration, before start and after start. They verify retained initialization state/data/auth, rejection of unsafe blind retry and no surviving owned service/listener. These exception tests are distinct from engine subprocess crash tests. Abrupt interruption during file copy and OS/process kill at every configuration boundary were not executed.

No identity/sequence allocator was introduced, so no identity recovery guarantees are claimed. No storage/WAL/catalog migration was introduced by F; the separately held E source retains its v4 definitions architecture. Windows execution only; Linux/macOS qualification remains deferred.
