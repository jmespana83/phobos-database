# PHOBOS Community Edition 1.0.1 — Release Notes

Focused usability and repair hotfix. Catalog 5, wire protocol 1 and Management API 1 remain unchanged. No SQL/storage/performance redesign or new SQL feature is included. DROP TABLE remains unsupported.

Recognized, fully received SQL statement errors retain the Studio connection and useful server code/message. Scripts stop at the error; no statement is replayed. Aborted explicit transactions require explicit ROLLBACK. Malformed protocol, transport failures, unknown/fatal errors, cancellation and interrupted result budgets still fail closed.

Windows Setup identifies compatible patch repair before replacing files, validates instance/service/binary ownership, and uses Restart Manager to identify file lockers. Save SQL, close Studio and choose Retry; no application is force-closed. The owned service is stopped gracefully before replacement. Repair uses the existing password, starts and authenticates the service, and reports the preserved endpoint/data location. Data, auth, runtime configuration, identity, views and constraints are preserved; only patch-version metadata changes. Extension metadata is retained.

Unsigned Windows x64 distribution; Linux remains unqualified. Existing SQL limitations, coarse roles and 1.0.0 performance evidence remain applicable. This hotfix makes no new performance claim. Detailed final acceptance results and hashes are supplied beside the artifacts.
